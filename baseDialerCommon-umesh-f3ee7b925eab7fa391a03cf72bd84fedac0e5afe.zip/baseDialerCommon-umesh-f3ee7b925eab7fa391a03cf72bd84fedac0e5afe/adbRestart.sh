sudo adb start-server
