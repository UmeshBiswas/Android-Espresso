package com.revesoft.itelmobiledialer.dialer.contact;

import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.contact.FavoriteContactsActivity;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObjectNotFoundException;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollAndSearch;
import static junit.framework.TestCase.fail;
import static org.hamcrest.core.AllOf.allOf;

@RunWith(AndroidJUnit4.class)
public class Favorites {

    private UiDevice uiDevice;



    //Add a contact in the favourite list
    @Test
    public void AddContactFavoritesList() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        lunchContactDetailsForPin(Supplier.getString(R.string.favorites_number_add));
        ViewInteraction fab_click=onView(allOf(withId(R.id.make_fav)));
        fab_click.perform(click());

    }
    //check favorite list by name
    @Test
    public void FavoritesListCheck() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        FavoriteContactsActivity.start(TestApplication.getAccess().getContext());

        //ScrollAndSearch Method Call
        ScrollAndSearch(Supplier.getString(R.string.favorites_number_check));

    }

    private void lunchContactDetailsForPin(String pin) {
        Executor.ex(()->{
            String contactId = ContactRepo.get().getContactIdByFlatNumber(pin);
            if(TextUtils.isEmpty(contactId)){
                fail();
            }
            Gui.get().run(()->{
                ContactDetailsActivity.startForTesting(TestApplication.getAccess().getContext(),contactId,pin);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        });

    }

}

