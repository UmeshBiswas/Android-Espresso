package com.revesoft.itelmobiledialer.dialer.contact;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;

import com.koushikdutta.ion.Ion;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.contact.details.ContactDetails;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;

import androidx.test.espresso.ViewInteraction;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.internal.util.Checks;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.core.util.Preconditions.checkNotNull;
import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.swipeDown;
import static androidx.test.espresso.action.ViewActions.swipeUp;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static junit.framework.TestCase.fail;
import static org.hamcrest.EasyMock2Matchers.equalTo;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;


@RunWith(AndroidJUnit4.class)
public class Contact {
    private static final String DIALER_PACKAGE_NAME = "com.reve.base";
    private static final String PICTURE_UPLOAD="com.android.contacts:id/photo_touch_intercept_overlay";

    private UiDevice uiDevice;


    //ContactTabEdit Method Start//Contact->Select a Number->Edit button->Edit Some Fields
    @Test
    public void ContactTabEdit() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        uiDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Select A Dialer using customize scroll method


        UiScrollable settingsItem = new UiScrollable(new UiSelector().scrollable(true));
        settingsItem.setAsVerticalList();


        boolean settingsFound = false;
        while(!settingsFound) {
            settingsItem.scrollForward();
            try {
                UiObject settingsApp = settingsItem.getChildByText(new UiSelector().className(android.widget.TextView.class.getName())
                        , Supplier.getString(R.string.umesh), true);
                settingsApp.clickAndWaitForNewWindow();
                settingsFound = true;
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Edit Contact start
        ViewInteraction editButton=onView(withId(R.id.edit_contact));
        editButton.perform(click());


        //Update photo

        UiObject Picture_Uploaad=uiDevice.findObject(new UiSelector()
                .resourceId(PICTURE_UPLOAD));
        assertEquals(true,Picture_Uploaad.exists());
        Picture_Uploaad.click();


        UiObject TakePhoto =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_take_photo))
                .className("android.widget.TextView"));
        if(TakePhoto.exists() && TakePhoto.isEnabled()) {
            TakePhoto.click();
        }
        //clicking camera for picture
        uiDevice.findObject(new UiSelector().resourceId("com.sonyericsson.android.camera:id/center_container")).click();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Photo Resize and done otherwise cancel

        UiObject DoneButton =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.done_small))
                .className("android.widget.Button"));

        if(DoneButton.exists() && DoneButton.isEnabled()) {
            DoneButton.click();
        }

        //Click the Expansion View
        UiObject ExpansionView =uiDevice.findObject(new UiSelector()
                .resourceId("com.android.contacts:id/expansion_view")
                .className("android.widget.ImageView"));
        ExpansionView.click();

        //Enter the Name Prefix
        UiObject NamePrefix = uiDevice.findObject(new UiSelector()
                .index(0)
                .className("android.widget.EditText"));
        assertEquals(true,NamePrefix.exists());
        NamePrefix.setText(Supplier.getString(R.string.contact_name_prefix));

        //Enter the First Name
        UiObject FirstName = uiDevice.findObject(new UiSelector()
                .index(1)
                .className("android.widget.EditText"));
        assertEquals(true,NamePrefix.exists());
        FirstName.setText(Supplier.getString(R.string.contact_name_first));

        //Enter the Middle Name
        UiObject MiddleName = uiDevice.findObject(new UiSelector()
                .index(2)
                .className("android.widget.EditText"));
        assertEquals(true,MiddleName.exists());
        MiddleName.setText(Supplier.getString(R.string.contact_name_middle));

        //Enter the Last Name
        UiObject LastName = uiDevice.findObject(new UiSelector()
                .index(3)
                .className("android.widget.EditText"));
        assertEquals(true,LastName.exists());
        LastName.setText(Supplier.getString(R.string.contact_name_last));

        //Enter the Suffix Name
        UiObject SuffixName = uiDevice.findObject(new UiSelector()
                .index(4)
                .className("android.widget.EditText"));
        assertEquals(true,SuffixName.exists());
        SuffixName.setText(Supplier.getString(R.string.contact_name_suffix));

        UiScrollable test = new UiScrollable(new UiSelector().scrollable(true));
        test.setAsVerticalList();
        test.scrollForward();



        //Enter the Mobile Number
        UiObject MobileNumber = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_mobile_1))
                .className("android.widget.EditText"));
        assertEquals(true,MobileNumber.exists());
        MobileNumber.setText(Supplier.getString(R.string.contact_mobile_2));


        //Enter the Option
        UiObject SelectOption = uiDevice.findObject(new UiSelector()
                .resourceId("android:id/text1")
                .className("android.widget.TextView"));
        assertEquals(true,SelectOption.exists());
        SelectOption.click();

        //Select an Option
        UiObject SelectAnOption = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_main))
                .className("android.widget.CheckedTextView"));
        assertEquals(true,SelectAnOption.exists());
        SelectAnOption.click();

        //Enter the Phone Number
        UiObject PhoneNumber = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_phone))
                .className("android.widget.EditText"));
        assertEquals(true,PhoneNumber.exists());
        PhoneNumber.setText(Supplier.getString(R.string.contact_phone_1));

        //Enter the Mail
        UiObject MailId = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.email_text))
                .className("android.widget.EditText"));
        assertEquals(true,MailId.exists());
        MailId.setText(Supplier.getString(R.string.contact_email));

        //Save button
//        UiObject save_but = uiDevice.findObject(new UiSelector()
//                .resourceId("com.android.contacts:id/menu_save")
//                .className("android.widget.TextView"));
//        assertEquals(true,save_but.exists());
//        save_but.click();


        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        //Edit Contact End



        //Block the contact Number
//        ViewInteraction blockNumber=onView(withId(R.id.tvBlock));
//        blockNumber.perform(click());
//
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }
    //ContactTabEdit Method End


    //Call List Check Method Start
    //Call->Check a Number or Name if it exists or not
    @Test
    public void CallTabCheck() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        uiDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));

        contacts_click.perform(click());

        //Check the number in recycle view, it exists or not

        onView((withText(Supplier.getString(R.string.contact_time)))).check(matches(isDisplayed()));


        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Call List Check Method End


    //Add a Number into Favorites Start
    @Test
    public void BlockList() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        uiDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Select the All portion
        ViewInteraction allcontacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_details_all)),(withId(R.id.tvAll))));
        allcontacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button=onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView=onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.contact_search_text)),closeSoftKeyboard());

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView (withIndex(withId(R.id.content), 1)).perform(click());

        ViewInteraction block_click=onView(allOf(withId(R.id.tvBlock)));
        block_click.perform(click());
        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Add a Number into Favorites End

    //Number into BlockListCheck Start
    @Test
    public void BlockListCheck() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        uiDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Select the ViewGroup
        UiObject toolbar =uiDevice.findObject(new UiSelector()
                .resourceId("com.reve.base:id/toolbar")
                .className("android.view.ViewGroup"));
        assertEquals(true,toolbar.exists());


        //Selcet the LinearLayoutCompat
        UiObject CompactLayout =uiDevice.findObject(new UiSelector()
                .index(2)
                .className("androidx.appcompat.widget.LinearLayoutCompat"));
        assertEquals(true,CompactLayout.exists());

        //Selcet the ImageView for group Chat
        UiObject CompactLayout2 =uiDevice.findObject(new UiSelector()
                .index(1)
                .className("android.widget.ImageView"));
        assertEquals(true,CompactLayout2.exists());
        CompactLayout2.click();

        //Selcet the New Group for the chat
        ViewInteraction blocked=onView(allOf(withText(Supplier.getString(R.string.blocked)),(withId(R.id.title))));
        blocked.perform(click());
        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        onData(withText(Supplier.getString(R.string.umesh_rn))).perform(swipeDown());


    }
    //Number into BlockListCheck End


}

