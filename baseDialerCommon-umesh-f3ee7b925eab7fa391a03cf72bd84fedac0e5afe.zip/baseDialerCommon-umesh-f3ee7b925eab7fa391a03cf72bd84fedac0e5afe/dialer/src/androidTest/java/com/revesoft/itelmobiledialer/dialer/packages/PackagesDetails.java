package com.revesoft.itelmobiledialer.dialer.packages;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.packageselection.PackageHomeActivity;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollAndSearch;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollForward;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;


@RunWith(AndroidJUnit4.class)
public class PackagesDetails {

    private UiDevice uiDevice;


    @Test
    public void CheckAvailablePlans() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        PackageHomeActivity.startForTesting(TestApplication.getAccess().getContext());

        Thread.sleep(4000);

        ViewInteraction packagesExpand = onView(allOf((withText(""))
                , withId(R.id.textview_title))).check(matches(isDisplayed()));
        packagesExpand.perform(click());

       // onView(allOf((withText(Supplier.getString(R.string.package_BD_calls))))).check(matches(isDisplayed()));

      //  onView(allOf((withText(Supplier.getString(R.string.package_valid_for_90_days))))).check(matches(isDisplayed()));

        ScrollForward();

//        ViewInteraction sendSms=onView(allOf((withText("MyPCKG")),withId(R.id.textview_title)));
//        sendSms.perform(click());

        Thread.sleep(2000);

    }
}
