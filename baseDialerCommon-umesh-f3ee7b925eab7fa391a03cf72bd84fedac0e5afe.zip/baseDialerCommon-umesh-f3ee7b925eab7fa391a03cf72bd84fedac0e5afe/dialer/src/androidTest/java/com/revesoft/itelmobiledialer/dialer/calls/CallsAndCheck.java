package com.revesoft.itelmobiledialer.dialer.calls;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.View;

import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.Client;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.Communicator;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.Response;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.ResponseListener;
import com.revesoft.itelmobiledialer.service.firebase.FireListener;
import com.revesoft.itelmobiledialer.service.firebase.FireListenerPool;
import com.revesoft.itelmobiledialer.util.CallMaker;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;
import static org.hamcrest.core.StringEndsWith.endsWith;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


public class CallsAndCheck {
    private static final long MAX_TIMEOUT = 30000;
    private static String TARGET_PIN = "8801847291974";
    private UiDevice mDevice;



    private static final TaggedLogger logger = new TaggedLogger("serverComTest");
    private static String status = null;


    // lunch the app start
    private void lunchCallWindowForPin(String pin) {
        CallMaker.makeFreeCall("8801847291974");

    }
    // lunch the app end


    @Test
    public void MessageSendingToTargetPinAndCheckIfReached() {
        String testPin = "Call From: 8801847291974";
        TestApplication.getAccess().lunch();
        lunchCallWindowForPin(TARGET_PIN);
        useTASToEnsureMessageGotThere(testPin);
    }


    private void useTASToEnsureMessageGotThere(String messageToCheck) {
        CountDownLatch lock = new CountDownLatch(2);
        AtomicReference<String> status = new AtomicReference<>(null);
        logger.log("sending message to receiver over TAS");
        HashMap<String, String> data = new HashMap<>();
        data.put("command", "receiveCall");
        data.put("fromPin", UserDataManager.getUserName());
        data.put("messageContent", messageToCheck);
        Communicator.get().talk(TARGET_PIN, data, (response, e) -> {
            lock.countDown();
            assertEquals("success", response.getStatus());
            if (e == null) {
                assertTrue(FireListenerPool.listen(fireData -> {
                    logger.log("data received from 2nd party");
                    if (fireData.containsKey("commandResponse")) {
                        String commandResponse = fireData.get("commandResponse");
                        assert commandResponse != null;
                        if (commandResponse.equals("checkForMessageResponse")) {
                            status.set(fireData.get("status"));
                            lock.countDown();
                        }
                    } else {
                        fail();
                    }
                }));
            } else {
                fail();
            }
        });
        try {
            lock.await(MAX_TIMEOUT * 4, TimeUnit.MILLISECONDS);
            assertEquals("success", status.get());
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }


    //Matcher Class for identify id end
    CountDownLatch tasLock = new CountDownLatch(5000);

    @Test
    public void ListenAndObey() {
        logger.log("ListenAndObey ");
        TestApplication.getAccess().lunch();

        boolean canListen = FireListenerPool.listen(new FireListener() {
            @Override
            public void onDataReceived(Map<String, String> data) {
                tasLock.countDown();
                logger.log("count left " + tasLock.getCount());
                logger.log("onDataReceived ");
                logger.log(data);
                if (data.containsKey("command")) {
                    String command = data.get("command");
                    if (command != null) {
                        switch (command) {
                            case "checkForMessage":

                                break;
                            case "receiveCall":
                                String fromPin = data.get("fromPin");
                                checkCallAndSendResponse(fromPin);
                                break;
                        }
                    }
                }
            }
        });
        if (canListen) {
            logger.log("started listening to TAS");
        } else {
            logger.error("cannot listen to TAS");
        }
        try {
            logger.log("waiting for 1 day :)");
            tasLock.await(1, TimeUnit.DAYS);
            logger.log("tasLock wait ended somehow");
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }


    private boolean checkCallAndSendResponse(String forPin) {
        logger.log("checkMessageAndSendResponse for pin " + forPin);
        lunchCallWindowForPin(forPin);
        sleepFor(1);
        String status = TestApplication
                .getAccess()
                .getUiDevice()
                .findObject(new UiSelector())
                .exists() ? "success" : "fail";
        logger.log("checkMessageAndSendResponse status = " + status);
        HashMap<String, String> data = new HashMap<>();
        data.put("commandResponse", "checkForMessageResponse");
        data.put("status", status);
        logger.log("sending reply to " + forPin);
        logger.log(data);
        Communicator.get().talk(forPin, data, new ResponseListener() {
            @Override
            public void onResponse(Response response, Exception e) {

                if (e == null) {
                    logger.log("checkMessageAndSendResponse command send to TAS");
                } else {
                    logger.error("checkMessageAndSendResponse failed to" +
                            " send command to TAS for " + e.getLocalizedMessage());
                }
                tasLock.countDown();
            }
        });
        logger.log("returning from checkMessageAndSendResponse");
        return true;
    }

    private void sleepFor(long sec) {
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }
}
