package com.revesoft.itelmobiledialer.dialer.account;

import org.junit.runner.RunWith;

import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class Account {



}
