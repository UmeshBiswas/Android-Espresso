package com.revesoft.itelmobiledialer.dialer.contact;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.openLinkWithText;
import static androidx.test.espresso.action.ViewActions.pressBack;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.swipeDown;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withChild;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static junit.framework.TestCase.fail;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;


@RunWith(AndroidJUnit4.class)
public class AllContact {

    private UiDevice uiDevice;


    //Check A dialer & All list exist or not
    @Test
    public void ContactCategoryCheck() throws UiObjectNotFoundException,IOException{
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Check a dialer & all list exist or not
        ViewInteraction aDialer=onView(allOf(withId(R.id.tvApp)))
                                .check(matches(withText("A Dialer")));
        aDialer.check(matches(isDisplayed()));

        ViewInteraction all=onView(allOf(withId(R.id.tvAll)))
                .check(matches(withText("All")));
        all.check(matches(isDisplayed()));

    }


    //check all the dialer contact exists in the all contactlist or not?
    @Test
    public void DialerContactExistsInAllContact() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button=onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView=onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.umesh_rn)),closeSoftKeyboard());

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView (withIndex(withId(R.id.content), 0)).perform(click());

    }


    //check Audio call,video call, chat option for A dialer installer
    @Test
    public void AudioVideoChatOptionInAllContact() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_a_dialer));

        onView(withIndex(withId(R.id.ivAudioCall), 0)).check(matches(isDisplayed()));
        onView(withIndex(withId(R.id.ivVideoCall), 0)).check(matches(isDisplayed()));
        onView(withIndex(withId(R.id.ivChat), 0)).check(matches(isDisplayed()));

    }

    //check callOut option for who didn't install dialer
    @Test
    public void CheckCallOutOptionInAllContact() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_all));

        onView(withIndex(withId(R.id.ivOutCall), 0)).check(matches(isDisplayed()));

    }

    //check callOut option for who didn't install dialer
    @Test
    public void SearchByTypingNamePhoneNumber() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_text)), (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Select the All portion
        ViewInteraction allcontacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_details_all)), (withId(R.id.tvAll))));
        allcontacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button = onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView = onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.chat_search_text)), closeSoftKeyboard());
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withIndex(withId(R.id.content), 0)).check(matches(isDisplayed()));


    }

    //Search any name then go any other page & then go back to contact page
    @Test
    public void SearchAnyNameThenGoBack() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_text)), (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());


        //Select the All portion
        ViewInteraction allcontacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_details_all)), (withId(R.id.tvAll))));
        allcontacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button = onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView = onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.chat_search_text)), closeSoftKeyboard());

        //go any other page
        //Select the Call menu from the tab view
        ViewInteraction calls_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));
        calls_click.perform(click());

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click1 = onView(allOf(withText(Supplier.getString(R.string.contact_text)), (withId(R.id.tvTabLabel))));
        contacts_click1.perform(click());

        onView(withIndex(withId(R.id.content), 0)).check(matches(isDisplayed()));


    }



    // lunch the app start
    private void lunchContactDetailsForPin(String pin) {
        Executor.ex(()->{
            String contactId = ContactRepo.get().getContactIdByFlatNumber(pin);
            if(TextUtils.isEmpty(contactId)){
                fail();
            }
            Gui.get().run(()->{
                ContactDetailsActivity.startForTesting(TestApplication.getAccess().getContext(),contactId,pin);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        });

    }
}

