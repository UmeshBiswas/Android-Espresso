package com.revesoft.itelmobiledialer.dialer.about;

import com.revesoft.itelmobiledialer.account.AboutActivity;
import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;


@RunWith(AndroidJUnit4.class)
public class About {

    private UiDevice uiDevice;


    @Test
    public void AboutPage() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        AboutActivity.startForTesting(TestApplication.getAccess().getContext());

        onView((withId(R.id.textVersion)))
                .check(matches(withText(Supplier.getString(R.string.about_version))));

        ViewInteraction licences= onView((withId(R.id.textLicences)))
                .check(matches(isDisplayed()));
        licences.perform(click());

    }
}
