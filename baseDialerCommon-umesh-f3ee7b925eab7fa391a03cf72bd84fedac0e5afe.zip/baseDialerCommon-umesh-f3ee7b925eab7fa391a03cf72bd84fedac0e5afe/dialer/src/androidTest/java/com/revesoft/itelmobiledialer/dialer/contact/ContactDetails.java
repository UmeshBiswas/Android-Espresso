package com.revesoft.itelmobiledialer.dialer.contact;

import android.text.TextUtils;
import android.view.View;
import android.widget.Checkable;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isChecked;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isNotChecked;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.setChecked;
import static junit.framework.TestCase.fail;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;


@RunWith(AndroidJUnit4.class)
public class ContactDetails {

    private UiDevice uiDevice;

    //Notifications
    @Test
    public void Notifications() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_all));

        //Click on notifications Switch

        ViewInteraction notifiSwitch_click = onView(withId(R.id.sNotification));

        if (notifiSwitch_click.equals(isChecked())) {
            notifiSwitch_click.perform(click());

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            //Click the radio button
            ViewInteraction radioButton_click = onView(withId(R.id.radioOneWeek));
            radioButton_click.perform(click());

            //Press the Apply button
            ViewInteraction ApplyButton_click = onView(withId(R.id.btn_ok));
            ApplyButton_click.perform(click());

        } else {
            notifiSwitch_click.perform(click());
        }


    }

    //Custom Notifications for message
    @Test
    public void CustomNotificationsForMessage() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_all));

        //Click on notifications Switch

        ViewInteraction custom_notification = onView(allOf(withText(Supplier.getString(R.string.contact_custom_notifications))));
        custom_notification.perform(click());

        //use custom notification button check on/off
        onView(withId(R.id.custom_notification_check_box)).perform(setChecked(true));

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Select Phone Ringtones
        ViewInteraction phone_ringtone = onView(allOf(withText(Supplier.getString(R.string.contact_notification_tone))));
        phone_ringtone.perform(click());

        UiObject ringtone_choose = uiDevice.findObject(new UiSelector()
                .index(5)
                .className("android.widget.RelativeLayout"));
        assertEquals(true, ringtone_choose.exists());
        ringtone_choose.click();

        UiObject done_button = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.done_cap))
                .className("android.widget.Button"));
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        assertEquals(true, done_button.exists());
        done_button.click();

        ViewInteraction Virate_message_notifications=onView(allOf(withId(R.id.notification_vibrate)));
        Virate_message_notifications.perform(click());

        ViewInteraction VirateType=onView(allOf(withText(Supplier.getString(R.string.contact_details_Short))));
        VirateType.perform(click());

        ViewInteraction PopupNotification=onView(allOf(withText(Supplier.getString(R.string.contact_details_popup_notifications))));
        PopupNotification.perform(click());

        ViewInteraction PopupNotificationSelect=onView(allOf(withText(Supplier.getString(R.string.contact_details_no_popup))));
        PopupNotificationSelect.perform(click());

    }

    //Custom Notifications for message
    @Test
    public void CustomNotificationsForCall() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_all));

        //Click on notifications Switch

        ViewInteraction custom_notification = onView(allOf(withText(Supplier.getString(R.string.contact_custom_notifications))));
        custom_notification.perform(click());

        //use custom notification button check on/off
        onView(withId(R.id.custom_notification_check_box)).perform(setChecked(true));

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Select Phone Ringtones
        ViewInteraction phone_ringtone = onView(allOf(withText(Supplier.getString(R.string.contact_details_ringtone))));
        phone_ringtone.perform(click());

        ViewInteraction phone_ringtone_select = onView(allOf(withText(Supplier.getString(R.string.contact_details_ringtone_phone_ringtone))));
        phone_ringtone_select.perform(click());

        UiObject ringtone_choose = uiDevice.findObject(new UiSelector()
                .index(5)
                .className("android.widget.RelativeLayout"));
        assertEquals(true, ringtone_choose.exists());
        ringtone_choose.click();

        UiObject done_button = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.done_cap))
                .className("android.widget.Button"));
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        assertEquals(true, done_button.exists());
        done_button.click();

        ViewInteraction Virate_call_notification=onView(allOf(withId(R.id.ring_vibrate)));
        Virate_call_notification.perform(click());
        ViewInteraction VirateType=onView(allOf(withText(Supplier.getString(R.string.contact_details_Short))));
        VirateType.perform(click());

    }


    // lunch the app start
    private void lunchContactDetailsForPin(String pin) {
        Executor.ex(()->{
            String contactId = ContactRepo.get().getContactIdByFlatNumber(pin);
            if(TextUtils.isEmpty(contactId)){
                fail();
            }
            Gui.get().run(()->{
                ContactDetailsActivity.startForTesting(TestApplication.getAccess().getContext(),contactId,pin);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        });

    }


}

