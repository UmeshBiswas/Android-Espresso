package com.revesoft.itelmobiledialer.dialer;


import android.view.View;
import android.widget.Checkable;


import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.material.R;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Assert;


import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;

import androidx.test.espresso.ViewInteraction;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.core.AllOf.allOf;

public class CommonMethod {
    public static void  ScrollAndSearch(String searchText)
            throws UiObjectNotFoundException {

        boolean counter = false;
        UiScrollable uiScrollable = new UiScrollable(new UiSelector().scrollable(true));
        uiScrollable.setAsVerticalList();
        while(!counter) {
          //  uiScrollable.scrollForward();
            try {
                UiObject searchItem = uiScrollable.getChildByText(new UiSelector()
                                .className(android.widget.TextView.class.getName()),
                        searchText, true);
                searchItem.clickAndWaitForNewWindow();
                counter=true;
            } catch (Exception e){
                e.printStackTrace();
            }
        }

    }

    //Matcher Class for identify id start
    public static Matcher<View> withIndex(final Matcher<View> matcher, final int index) {
        return new TypeSafeMatcher<View>() {
            int currentIndex = 0;

            @Override
            public void describeTo(Description description) {
                description.appendText(Supplier.getString(R.string.with_index));
                description.appendValue(index);
                matcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                return matcher.matches(view) && currentIndex++ == index;
            }
        };
    }
    //Matcher Class for identify id end

    //checkbox matcher method start
    public static ViewAction setChecked(final boolean checked) {
        return new ViewAction() {
            @Override
            public BaseMatcher<View> getConstraints() {
                return new BaseMatcher<View>() {
                    @Override
                    public boolean matches(Object item) {
                        return isA(Checkable.class).matches(item);
                    }

                    @Override
                    public void describeMismatch(Object item, Description mismatchDescription) {}

                    @Override
                    public void describeTo(Description description) {}
                };
            }

            @Override
            public String getDescription() {
                return null;
            }

            @Override
            public void perform(UiController uiController, View view) {
                Checkable checkableView = (Checkable) view;
                checkableView.setChecked(checked);
            }
        };
    }
    //checkbox method end

    public static void sleepFor(long sec) {
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            Assert.fail();
            e.printStackTrace();
        }
    }

    public static void ScrollForward() {
        UiScrollable uiScrollable = new UiScrollable(new UiSelector().scrollable(true));
        try {
            uiScrollable.scrollForward();
        } catch (UiObjectNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void getSearchButton(String searchItem){
        ViewInteraction searchButton = onView(allOf(withId(R.id.search_button)))
                .check(matches(isDisplayed()));
        searchButton.perform(click());
        ViewInteraction searchContact = onView(allOf(withId(R.id.search_src_text)))
                .check(matches(isDisplayed()));
        searchContact.perform(replaceText(searchItem));
        sleepFor(1);
        onView (withIndex(withId(R.id.content), 0)).perform(click());
    }



}
