package com.revesoft.itelmobiledialer.dialer.profileinfo;

import android.view.View;
import android.widget.Checkable;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.GrantPermissionRule;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.isA;
import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class ProfileInfoUpdate {

    private static final String FULL_NAME="com.reve.base:id/etName";
    private static final String EMAIL="com.reve.base:id/etEmail";
    private static final String CONFIRM__BUT="com.reve.base:id/bConfirm";
    private static final String PICTURE_UPLOAD="com.reve.base:id/ivProfilePicture";
    private static final String CAMERA_PACKAGE="tools.photo.hd.camera:id/shutter_button";

    private UiDevice uiDevice;

    @Test
    public void ProfileInfo() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject Picture_Uploaad=uiDevice.findObject(new UiSelector()
                .resourceId(PICTURE_UPLOAD));
        assertEquals(true,Picture_Uploaad.exists());
        Picture_Uploaad.click();


        UiObject TakePhoto =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.take_new_photo))
                .className("android.widget.TextView"));
        if(TakePhoto.exists() && TakePhoto.isEnabled()) {
            TakePhoto.click();
        }

        //clicking camera for picture

        uiDevice.findObject(new UiSelector().resourceId(CAMERA_PACKAGE)).click();
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject photoSelectFinal =uiDevice.findObject(new UiSelector()
                .resourceId("tools.photo.hd.camera:id/btn_done")
                .className("android.widget.ImageView"));

        if(photoSelectFinal.exists() && photoSelectFinal.isEnabled()) {
            photoSelectFinal.click();
        }
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject photoSave =uiDevice.findObject(new UiSelector()
                .resourceId("com.reve.base:id/crop_image_menu_crop")
                .className("android.widget.TextView"));

        if(photoSave.exists() && photoSave.isEnabled()) {
            photoSave.click();
        }


        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiScrollable Full_Name = new UiScrollable(new UiSelector()
                .resourceId(FULL_NAME)
                .className("android.widget.EditText"));
        assertEquals(true,Full_Name.exists());
        Full_Name.setText(Supplier.getString(R.string.ProfileInfoUpdate_full_name));

        UiScrollable email = new UiScrollable(new UiSelector()
                .resourceId(EMAIL)
                .className("android.widget.EditText"));
        assertEquals(true,email.exists());
        email.setText(Supplier.getString(R.string.ProfileInfoUpdate_email));

        UiScrollable confirm_but = new UiScrollable(new UiSelector()
                .resourceId(CONFIRM__BUT)
                .className("android.widget.Button"));
        assertEquals(true,confirm_but.exists());
        confirm_but.click();
        try {
            Thread.sleep(50000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
