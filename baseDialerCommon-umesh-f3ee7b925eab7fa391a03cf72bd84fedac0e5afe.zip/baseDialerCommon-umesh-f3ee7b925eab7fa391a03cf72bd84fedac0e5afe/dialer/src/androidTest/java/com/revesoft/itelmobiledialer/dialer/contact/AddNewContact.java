package com.revesoft.itelmobiledialer.dialer.contact;


import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;


import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;


import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.sleepFor;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;


@RunWith(AndroidJUnit4.class)
public class AddNewContact {
    private UiDevice uiDevice;
    private static final String PICTURE_UPLOAD="com.google.android.contacts:id/photo_icon";
    private static final String CAMERA_PACKAGE="tools.photo.hd.camera:id/shutter_button";

    //Add New Contact
    //Contact->Select Fab for add contact->then check it exists or not?
    @Test
    public void AddNewContact() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        ViewInteraction create_contactsFab=onView(allOf(withId(R.id.fab))).check(matches(isDisplayed()));
        create_contactsFab.perform(click());

        UiObject create_new_contacts=uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_create_contact))
                .className("android.widget.TextView"));
        create_new_contacts.click();

        //Update photo

        UiObject Picture_Uploaad=uiDevice.findObject(new UiSelector()
                .resourceId(PICTURE_UPLOAD));
        assertEquals(true,Picture_Uploaad.exists());
        Picture_Uploaad.click();


        UiObject TakePhoto =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_take_photo))
                .className("android.widget.TextView"));
        if(TakePhoto.exists() && TakePhoto.isEnabled()) {
            TakePhoto.click();
        }
        //clicking camera for picture
        uiDevice.findObject(new UiSelector().resourceId(CAMERA_PACKAGE)).click();
        sleepFor(5);

        UiObject photoSelectFinal =uiDevice.findObject(new UiSelector()
                .resourceId("tools.photo.hd.camera:id/btn_done")
                .className("android.widget.ImageView"));

        if(photoSelectFinal.exists() && photoSelectFinal.isEnabled()) {
            photoSelectFinal.click();
        }
        sleepFor(5);
        UiObject done =uiDevice.findObject(new UiSelector()
                .resourceId("com.google.android.apps.photos:id/cpe_save_button")
                .className("android.widget.Button"));

        if(done.exists() && done.isEnabled()) {
            done.click();
        }

        //Enter the Name
        UiObject firstName = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_first_name))
                .className("android.widget.EditText"));
        assertEquals(true,firstName.exists());
        firstName.setText(Supplier.getString(R.string.contact_name_first));

        UiObject lastName = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_last_name))
                .className("android.widget.EditText"));
        assertEquals(true,lastName.exists());
        lastName.setText(Supplier.getString(R.string.contact_name_last));

        //Enter the Mobile Number
        UiObject MobileNumber = uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.contact_phone))
                .className("android.widget.EditText"));
        assertEquals(true,MobileNumber.exists());
        MobileNumber.setText(Supplier.getString(R.string.contact_phone_1));

        UiObject save =uiDevice.findObject(new UiSelector()
                .resourceId("com.google.android.contacts:id/menu_save")
                .className("android.widget.TextView"));

        if(save.exists() && save.isEnabled()) {
            save.click();
        }

        //Save Compleate Now the check the Contact it exists or Not

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click1=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click1.perform(click());

        //Select the All portion
        ViewInteraction allcontacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_details_all)),(withId(R.id.tvAll))));
        allcontacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button=onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView=onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.contact_name_full)),closeSoftKeyboard());
        sleepFor(5);

        onView (withIndex(withId(R.id.content), 0)).perform(click());

    }

}

