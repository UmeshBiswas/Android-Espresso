package com.revesoft.itelmobiledialer.dialer.chat;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.View;

import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.Client;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.Communicator;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.Response;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.ResponseListener;
import com.revesoft.itelmobiledialer.service.firebase.FireListener;
import com.revesoft.itelmobiledialer.service.firebase.FireListenerPool;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static org.hamcrest.core.AllOf.allOf;
import static org.hamcrest.core.StringEndsWith.endsWith;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


public class Chat {
    private static final long MAX_TIMEOUT = 30000;
    private static final String DIALER_PACKAGE_NAME = "com.reve.base";
    private static String TARGET_PIN = "8801847291974";
    private UiDevice mDevice;


    //ChatFromHomePage method start
    //Chat->press the fab button->select a number-> send sms
    @Test
    public void ChatFromHomePage() throws UiObjectNotFoundException, IOException {

        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        ViewInteraction fab_button = onView(allOf(withId(R.id.fab)));
        fab_button.perform(click());

        //Select A Dialer using customize scroll method


        UiScrollable settingsItem = new UiScrollable(new UiSelector().scrollable(true));
        settingsItem.setAsVerticalList();


        boolean settingsFound = false;
        while (!settingsFound) {
            settingsItem.scrollForward();
            try {
                UiObject settingsApp = settingsItem.getChildByText(new UiSelector().className(android.widget.TextView.class.getName())
                        , Supplier.getString(R.string.umesh_rn), true);
                settingsApp.clickAndWaitForNewWindow();
                settingsFound = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            Thread.sleep(7000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Type simple text and send it

        ViewInteraction type_simpleText = onView(allOf(withId(R.id.etMessage)));
        type_simpleText.perform(replaceText(Supplier.getString(R.string.chat_from_home_page)), closeSoftKeyboard());

        ViewInteraction sms_send_button = onView(allOf(withId(R.id.ivSend)));
        sms_send_button.perform(click());

    }
    //ChatFromHomePage method start end


    //ContactTabChat Method Start
    //A Dialer portion
    //Contact->Select a Number->send sms->
    @Test
    public void ContactTabChat() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_text))
                , (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Select A Dialer using customize scroll method


        UiScrollable settingsItem = new UiScrollable(new UiSelector().scrollable(true));
        settingsItem.setAsVerticalList();


        boolean settingsFound = false;
        while (!settingsFound) {
            settingsItem.scrollForward();
            try {
                UiObject settingsApp = settingsItem.getChildByText(new UiSelector().className(android.widget.TextView.class.getName())
                        , Supplier.getString(R.string.umesh_rn), true);
                settingsApp.clickAndWaitForNewWindow();
                settingsFound = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Select chat option
        onView(withIndex(withId(R.id.ivChat), 0)).perform(click());

        //Type simple text and send it

        ViewInteraction type_simpleText = onView(allOf(withId(R.id.etMessage)));
        type_simpleText.perform(replaceText(Supplier.getString(R.string.chat_send_text)), closeSoftKeyboard());

        ViewInteraction sms_send_button = onView(allOf(withId(R.id.ivSend)));
        sms_send_button.perform(click());


    }
    //ContactTabChat Method End


    //ContactTabChat by search Method Start
    //All portion
    //Contact->Select a Contact by search->Start chat by send sms->
    @Test
    public void ContactTabChatAll() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_text)), (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Select the All portion
        ViewInteraction allcontacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_details_all)), (withId(R.id.tvAll))));
        allcontacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button = onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView = onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.chat_search_text)), closeSoftKeyboard());

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withIndex(withId(R.id.content), 1)).perform(click());


        //Select A Dialer using customize scroll method


        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Select chat option
        onView(withIndex(withId(R.id.ivChat), 0)).perform(click());

        //Type simple text and send it

        ViewInteraction type_simpleText = onView(allOf(withId(R.id.etMessage)));
        type_simpleText.perform(replaceText(Supplier.getString(R.string.chat_send_text)), closeSoftKeyboard());

        ViewInteraction sms_send_button = onView(allOf(withId(R.id.ivSend)));
        sms_send_button.perform(click());


    }
    //ContactTabChat by search Method End

    private static final TaggedLogger logger = new TaggedLogger("serverComTest");
    private static String status = null;


    //Registration new device into server start
    @Test
    public void ServerRegistration() {
        CountDownLatch lock = new CountDownLatch(1);
        TestApplication.getAccess();
        logger.log("ServerRegistration testing started");
        Client client = Client.newBuilder()
                .withPin(UserDataManager.getUserName())
                .withFid(PreferenceDataManager.quickGet(Constants.GCM_REGISTRATION_ID, ""))
                .withAppDetails(Supplier.getString(R.string.app_name))
                .withDeviceName(Build.DEVICE)
                .build();
        Communicator.get().register(client, new ResponseListener() {
            @Override
            public void onResponse(Response response, Exception e) {
                logger.log("ServerRegistration got call back");
                if (e == null) {
                    logger.log("ServerRegistration no error");
                    status = response.getStatus();
                } else {
                    logger.error("ServerRegistration got error" + e.getLocalizedMessage());
                    status = null;
                }
                lock.countDown();
            }
        });
        try {
            lock.await(MAX_TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        assertEquals("success", status);
        logger.log("ServerRegistration testing main thread passed");

    }
    //Registration new device into server end


    // lunch the app start
    private void lunchChatWindowForPin(String pin) {
        ChatWindowActivity.simpleTestStart(TestApplication.getAccess().getContext(), pin);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    // lunch the app end


    @Test
    public void MessageSendingToTargetPinAndCheckIfReached() {
        String testMessage = "i am good";
        TestApplication.getAccess().lunch();
        lunchChatWindowForPin(TARGET_PIN);
        sendMessage(testMessage);
        useTASToEnsureMessageGotThere(testMessage);
    }

    private void sendMessage(String messageToSend) {
        ViewInteraction etMessage = onView(allOf(withId(R.id.etMessage)));
        etMessage.perform(replaceText(messageToSend), closeSoftKeyboard());

        ViewInteraction ivSend = onView(allOf(withId(R.id.ivSend)));
        ivSend.perform(click());
    }

    private void useTASToEnsureMessageGotThere(String messageToCheck) {
        CountDownLatch lock = new CountDownLatch(2);
        AtomicReference<String> status = new AtomicReference<>(null);
        logger.log("sending message to receiver over TAS");
        HashMap<String, String> data = new HashMap<>();
        data.put("command", "checkForMessage");
        data.put("fromPin", UserDataManager.getUserName());
        data.put("messageContent", messageToCheck);
        Communicator.get().talk(TARGET_PIN, data, (response, e) -> {
            lock.countDown();
            assertEquals("success", response.getStatus());
            if (e == null) {
                assertTrue(FireListenerPool.listen(fireData -> {
                    logger.log("data received from 2nd party");
                    if (fireData.containsKey("commandResponse")) {
                        String commandResponse = fireData.get("commandResponse");
                        assert commandResponse != null;
                        if (commandResponse.equals("checkForMessageResponse")) {
                            status.set(fireData.get("status"));
                            lock.countDown();
                        }
                    } else {
                        fail();
                    }
                }));
            } else {
                fail();
            }
        });
        try {
            lock.await(MAX_TIMEOUT * 4, TimeUnit.MILLISECONDS);
            assertEquals("success", status.get());
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }

    //ContactTabChat by Scrolling Method Start
    //All portion
    //Contact->Select a Contact by search->Start chat by send sms->
    @Test
    public void ContactTabChatAllByScrolling() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_text))
                , (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Select the All portion
        ViewInteraction allcontacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_details_all)), (withId(R.id.tvAll))));
        allcontacts_click.perform(click());


        //Select the Rates from menu

        UiScrollable settingsItem = new UiScrollable(new UiSelector().scrollable(true));
        settingsItem.setAsVerticalList();


        int settingsFound = 0;
        while (settingsFound < 1) {
            settingsItem.scrollForward(200);

            UiObject settingsApp = settingsItem.getChildByText(new UiSelector().className(android.widget.TextView.class.getName()),
                    Supplier.getString(R.string.umesh_rn), true);
            settingsApp.clickAndWaitForNewWindow();
            settingsFound++;

        }


    }
    //ContactTabChat by Scrolling Method End




    //Matcher Class for identify id end
    CountDownLatch tasLock = new CountDownLatch(5000);

    @Test
    public void ListenAndObey() {
        logger.log("ListenAndObey ");
        TestApplication.getAccess().lunch();

        boolean canListen = FireListenerPool.listen(new FireListener() {
            @Override
            public void onDataReceived(Map<String, String> data) {
                tasLock.countDown();
                logger.log("count left " + tasLock.getCount());
                logger.log("onDataReceived ");
                logger.log(data);
                if (data.containsKey("command")) {
                    String command = data.get("command");
                    if (command != null) {
                        switch (command) {
                            case "checkForMessage":
                                String fromPin = data.get("fromPin");
                                String messageContent = data.get("messageContent");
                                checkMessageAndSendResponse(fromPin, messageContent);
                                break;
                            case "receiveCall":
                                break;
                        }
                    }
                }
            }
        });
        if (canListen) {
            logger.log("started listening to TAS");
        } else {
            logger.error("cannot listen to TAS");
        }
        try {
            logger.log("waiting for 1 day :)");
            tasLock.await(1, TimeUnit.DAYS);
            logger.log("tasLock wait ended somehow");
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }


    private boolean checkMessageAndSendResponse(String forPin, String messageContent) {
        logger.log("checkMessageAndSendResponse for pin " + forPin + ", messageContent = " + messageContent);
        lunchChatWindowForPin(forPin);
        sleepFor(1);
        String status = TestApplication
                .getAccess()
                .getUiDevice()
                .findObject(new UiSelector()
                        .text(messageContent))
                .exists() ? "success" : "fail";
        logger.log("checkMessageAndSendResponse status = " + status);
        HashMap<String, String> data = new HashMap<>();
        data.put("commandResponse", "checkForMessageResponse");
        data.put("status", status);
        logger.log("sending reply to " + forPin);
        logger.log(data);
        Communicator.get().talk(forPin, data, new ResponseListener() {
            @Override
            public void onResponse(Response response, Exception e) {

                if (e == null) {
                    logger.log("checkMessageAndSendResponse command send to TAS");
                } else {
                    logger.error("checkMessageAndSendResponse failed to" +
                            " send command to TAS for " + e.getLocalizedMessage());
                }
                tasLock.countDown();
            }
        });
        logger.log("returning from checkMessageAndSendResponse");
        return true;
    }

    private void sleepFor(long sec) {
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }
}
