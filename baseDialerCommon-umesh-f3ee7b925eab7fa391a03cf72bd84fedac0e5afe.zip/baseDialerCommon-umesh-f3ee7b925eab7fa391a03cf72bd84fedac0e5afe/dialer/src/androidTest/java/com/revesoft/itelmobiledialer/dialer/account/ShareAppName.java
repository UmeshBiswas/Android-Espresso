package com.revesoft.itelmobiledialer.dialer.account;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.dialer.testServerSdk.Communicator;
import com.revesoft.itelmobiledialer.rates.RateListActivity;
import com.revesoft.itelmobiledialer.service.firebase.FireListenerPool;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.HashMap;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollAndSearch;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class ShareAppName {
    private static final String DIALER_PACKAGE_NAME = "com.reve.base";
    private static final String WUMD="com.reve.base:id/sMobileData";
    private static final String WCOWifi="com.reve.base:id/sWifiData";
    private static final String TAG = "CommunicationTest";
    private UiDevice uiDevice;
    

    //Share appName with friends region
    //AccountShare Method Start
    @Test
    public void AccountShareAppNameWithFriends() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        AccountActivity.startForTesting(TestApplication.getAccess().getContext());

        //menu bar Share appName with friends

        ViewInteraction shareAppName=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_share_app_name_friends)))));
        shareAppName.perform(click());


        //call ScrollAndSearch method
        ScrollAndSearch(Supplier.getString(R.string.account_share_app_name));

    }
    //AccountShare Method End

}
