package com.revesoft.itelmobiledialer.dialer.chat;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.junit.Test;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;


public class DeleteAndMute {

    private UiDevice uiDevice;

    //Delete a chat from chat list history by Search
    //Chat->Select a chat name by search->press long time ->Delete
    @Test
    public void DeleteFromChatlistBySearch() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

            ViewInteraction searchButton = onView(allOf(withId(R.id.search_button)))
                    .check(matches(isDisplayed()));
            searchButton.perform(click());
            ViewInteraction searchText = onView(allOf(withId(R.id.search_src_text)))
                    .check(matches(isDisplayed()));
            searchText.perform(replaceText(Supplier.getString(R.string.chat_search_text)), closeSoftKeyboard());

            sleepFor(3);

            UiObject deleteItem = uiDevice.findObject(new UiSelector()
                    .className("android.view.ViewGroup")
                    .resourceId("com.reve.base:id/mainContent")
                    .index(0));
            assertEquals(true, deleteItem.exists());
            deleteItem.longClick();

            sleepFor(4);

            ViewInteraction delete = onView(allOf(withText(Supplier.getString(R.string.delete)), withId(R.id.tv)));
            delete.perform(click());


        }

    //Delete a chat from chat list history 
    //Chat->Select a chat name by index->press long time ->Delete
    @Test
    public void DeleteFromChat() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        
        sleepFor(3);

        UiObject deleteItem = uiDevice.findObject(new UiSelector()
                .className("android.view.ViewGroup")
                .resourceId("com.reve.base:id/mainContent")
                .index(1));
        assertEquals(true, deleteItem.exists());
        deleteItem.longClick();

        sleepFor(4);
        ViewInteraction delete = onView(allOf(withText(Supplier.getString(R.string.delete)), withId(R.id.tv)));
        delete.perform(click());

    }


    //Mute a chat from chat list history
    //Chat->Select a chat name by index->press long time-> Mute
    @Test
    public void MuteFromChat() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.chat_text)), (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());


        //Press the search button
//        ViewInteraction search_button=onView(allOf(withId(R.id.search_button)));
//        search_button.perform(click());
//        ViewInteraction search_editView=onView(allOf(withId(R.id.search_src_text)));
//        search_editView.perform(replaceText("umes"),closeSoftKeyboard());

        sleepFor(3);

        //select the mute item

        UiObject mute_item = uiDevice.findObject(new UiSelector()
                .className("android.view.ViewGroup")
                .resourceId("com.reve.base:id/mainContent")
                .index(1));
        assertEquals(true, mute_item.exists());
        mute_item.longClick();

        sleepFor(4);

        //final click the mute item
        ViewInteraction delete = onView(allOf(withText(Supplier.getString(R.string.chat_mute)), withId(R.id.tv)));
        delete.perform(click());

        //select the mute duration
        ViewInteraction mute_time = onView(allOf(withText(Supplier.getString(R.string.chat_1_week))
                , withId(R.id.radioOneWeek)));
        mute_time.perform(click());

        //select the checkBox
        ViewInteraction check_notification = onView(allOf(withText(Supplier.getString(R.string.chat_show_notifications))
                , withId(R.id.checkBox_showNotifications)));
        check_notification.perform(click());

        //click the apply button
        ViewInteraction button_apply = onView(allOf(withText(Supplier.getString(R.string.chat_apply)), withId(R.id.btn_ok)));
        button_apply.perform(click());

    }

    //Unmute a chat from chat list history start
    //Chat->Select a chat name by index->press long time-> Unmute
    @Test
    public void UnMuteFromChat() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        
        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.chat_text))
                , (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());
        sleepFor(3);

        UiObject mute_item = uiDevice.findObject(new UiSelector()
                .className("android.view.ViewGroup")
                .resourceId("com.reve.base:id/mainContent")
                .index(1));
        assertEquals(true, mute_item.exists());
        mute_item.longClick();

        sleepFor(4);
        ViewInteraction unmute = onView(allOf(withText(Supplier.getString(R.string.chat_unmute)), withId(R.id.tv)));
        unmute.perform(click());
    }


    //Others method

    private void sleepFor(long sec) {
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }

}
