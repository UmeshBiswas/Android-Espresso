package com.revesoft.itelmobiledialer.dialer.testServerSdk;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;

public class Communicator {
    private static Communicator communicator;

    public static Communicator get() {
        if (communicator == null) {
            communicator = new Communicator();
        }
        return communicator;
    }

    public void register(Client client, ResponseListener listener) {
        ClientDao.getAccess().save(client)
                .enqueue(new Callback<Response>() {
                    @Override
                    public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                        Response serverResponse = response.body();
                        if (serverResponse != null) {
                            listener.onResponse(serverResponse, null);
                        } else {
                            listener.onResponse(null, new Exception("Null response from server"));
                        }
                    }

                    @Override
                    public void onFailure(Call<Response> call, Throwable t) {
                        listener.onResponse(null, new Exception(t.getLocalizedMessage()));
                    }
                });
    }

    public void talk(String targetPin, HashMap<String, String> data, ResponseListener listener) {
        data.put("pin", targetPin);
        ClientDao.getAccess().talk(data)
                .enqueue(new Callback<Response>() {
                    @Override
                    public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                        Response serverResponse = response.body();
                        if (serverResponse != null) {
                            listener.onResponse(serverResponse, null);
                        } else {
                            listener.onResponse(null, new Exception("Null response from server"));
                        }
                    }

                    @Override
                    public void onFailure(Call<Response> call, Throwable t) {
                        listener.onResponse(null, new Exception(t.getLocalizedMessage()));
                    }
                });
    }
}
