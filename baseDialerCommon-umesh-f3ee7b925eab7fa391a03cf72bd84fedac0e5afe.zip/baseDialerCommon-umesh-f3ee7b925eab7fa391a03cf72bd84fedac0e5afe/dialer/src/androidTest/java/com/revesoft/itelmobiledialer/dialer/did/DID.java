package com.revesoft.itelmobiledialer.dialer.did;

import com.revesoft.itelmobiledialer.dialer.TestApplication;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObjectNotFoundException;


@RunWith(AndroidJUnit4.class)
public class DID {

    private UiDevice uiDevice;


    @Test
    public void Did() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();



    }
}
