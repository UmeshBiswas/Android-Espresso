package com.revesoft.itelmobiledialer.dialer.rates;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.rates.RateListActivity;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class Rates {

    private UiDevice uiDevice;


    //Rates Details Method Start
    @Test
    public void RatesDetails() throws UiObjectNotFoundException, IOException, InterruptedException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        RateListActivity.startForTesting(TestApplication.getAccess().getContext());


        //Select the Recharge from menu
        ViewInteraction search_country=onView(allOf(withId(R.id.search_button)));
        search_country.perform(click());

        //type the country name
        ViewInteraction type_country=onView(allOf(withId(R.id.search_src_text)));
        type_country.perform(replaceText(Supplier.getString(R.string.rates_search_country_name)));

        onView (withIndex(withId(R.id.countryInfoHolder), 0)).perform(click());

        try {
            Thread.sleep(2000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Rates Details Method End


    //Rates Details Method Start
    //Search a country->then press the cross button
    @Test
    public void RatesDetailsCrossChecked() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        RateListActivity.startForTesting(TestApplication.getAccess().getContext());

        //Select the Recharge from menu
        ViewInteraction search_country=onView(allOf(withId(R.id.search_button)));
        search_country.perform(click());

        //type the country name
        ViewInteraction type_country=onView(allOf(withId(R.id.search_src_text)));
        type_country.perform(replaceText(Supplier.getString(R.string.rates_search_country_name)),closeSoftKeyboard());

        //Cross button click
        ViewInteraction cross_button=onView(allOf(withId(R.id.search_close_btn)));
        cross_button.perform(click());

        try {
            Thread.sleep(2000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Rates Details Method End

}
