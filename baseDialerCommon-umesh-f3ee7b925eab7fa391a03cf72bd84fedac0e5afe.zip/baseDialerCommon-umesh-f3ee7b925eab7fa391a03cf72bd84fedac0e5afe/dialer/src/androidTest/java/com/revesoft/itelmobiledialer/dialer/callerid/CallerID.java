package com.revesoft.itelmobiledialer.dialer.callerid;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.did.CallerIDSelectionActivity;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObjectNotFoundException;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;


@RunWith(AndroidJUnit4.class)
public class CallerID {

    private UiDevice uiDevice;


    @Test
    public void CallerIDDetails() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        CallerIDSelectionActivity.startForTesting(TestApplication.getAccess().getContext());

    }

    //Bye new DID
    @Test
    public void ByeDID() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        CallerIDSelectionActivity.startForTesting(TestApplication.getAccess().getContext());


        ViewInteraction buyDID=onView(allOf(withText(Supplier.getString(R.string.caller_bye_did))));
        buyDID.perform(click());
        Thread.sleep(3000);

        ViewInteraction fabButton=onView(allOf(withId(R.id.fab)));
        fabButton.perform(click());
        Thread.sleep(3000);


    }
}
