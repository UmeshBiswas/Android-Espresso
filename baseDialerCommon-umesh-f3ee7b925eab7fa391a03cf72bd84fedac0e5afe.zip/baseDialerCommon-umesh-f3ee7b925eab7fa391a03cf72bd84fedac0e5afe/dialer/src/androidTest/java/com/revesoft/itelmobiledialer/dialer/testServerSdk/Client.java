package com.revesoft.itelmobiledialer.dialer.testServerSdk;

import com.google.gson.annotations.SerializedName;

public class Client {

    @SerializedName("fid")
    private String fid;

    @SerializedName("pin")
    private String pin;

    @SerializedName("__v")
    private int V;

    @SerializedName("appDetails")
    private String appDetails;

    @SerializedName("_id")
    private String id;

    @SerializedName("deviceName")
    private String deviceName;

    @SerializedName("updated")
    private String updated;

    private Client(Builder builder) {
        setFid(builder.fid);
        setPin(builder.pin);
        setAppDetails(builder.appDetails);
        setId(builder.id);
        setDeviceName(builder.deviceName);
        setUpdated(builder.updated);
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    public String getFid() {
        return fid;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPin() {
        return pin;
    }

    public void setV(int V) {
        this.V = V;
    }

    public int getV() {
        return V;
    }

    public void setAppDetails(String appDetails) {
        this.appDetails = appDetails;
    }

    public String getAppDetails() {
        return appDetails;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public String getUpdated() {
        return updated;
    }

    @Override
    public String toString() {
        return
                "Client{" +
                        "fid = '" + fid + '\'' +
                        ",pin = '" + pin + '\'' +
                        ",__v = '" + V + '\'' +
                        ",appDetails = '" + appDetails + '\'' +
                        ",_id = '" + id + '\'' +
                        ",deviceName = '" + deviceName + '\'' +
                        ",updated = '" + updated + '\'' +
                        "}";
    }


    public static final class Builder {
        private String fid;
        private String pin;
        private String appDetails;
        private String id;
        private String deviceName;
        private String updated;

        private Builder() {
        }

        public Builder withFid(String val) {
            fid = val;
            return this;
        }

        public Builder withPin(String val) {
            pin = val;
            return this;
        }

        public Builder withAppDetails(String val) {
            appDetails = val;
            return this;
        }

        public Builder withId(String val) {
            id = val;
            return this;
        }

        public Builder withDeviceName(String val) {
            deviceName = val;
            return this;
        }

        public Builder withUpdated(String val) {
            updated = val;
            return this;
        }

        public Client build() {
            return new Client(this);
        }
    }
}