package com.revesoft.itelmobiledialer.dialer.testServerSdk;

import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ClientDao {
    static ClientDao getAccess() {
        return Api.getAccess().create(ClientDao.class);
    }

    @GET("client")
    @Headers({
            "Accept: application/json"
    })
    Call<List<Client>> getAll();


    @Headers({
            "Content-Type: application/json",
            "Accept: application/json"
    })
    @POST("client")
    Call<Response> save(@Body Client client);

    @Headers({
            "Content-Type: application/json",
            "Accept: application/json"
    })
    @POST("client/talk")
    Call<Response> talk(@Body HashMap<String, String> data);


}
