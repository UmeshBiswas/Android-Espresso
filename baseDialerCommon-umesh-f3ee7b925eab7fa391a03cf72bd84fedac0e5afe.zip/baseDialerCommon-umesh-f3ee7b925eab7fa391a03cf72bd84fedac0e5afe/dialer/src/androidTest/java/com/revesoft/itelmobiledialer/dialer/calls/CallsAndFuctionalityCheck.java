package com.revesoft.itelmobiledialer.dialer.calls;

import android.content.Context;
import android.content.Intent;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

@RunWith(AndroidJUnit4.class)
public class CallsAndFuctionalityCheck {
    private static final String DIALER_PACKAGE_NAME = "com.reve.base";

    private UiDevice uiDevice;


    //Call->FabButton->Number press->App call
    @Test
    public void MakeCallUsingDialPad() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        ViewInteraction callsMenu=onView(allOf(withText(Supplier.getString(R.string.calls_text))
                ,(withId(R.id.tvTabLabel)))).check(matches(isDisplayed()));
        callsMenu.perform(click());

        ViewInteraction fabChosse=onView(allOf(withId(R.id.fab))).check(matches(isDisplayed()));
        fabChosse.perform(click());


        //Press a number from the dialer
        ViewInteraction number1_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_0)),(withId(R.id.textNumber))));
        number1_press.perform(click());

        ViewInteraction number2_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_1)),(withId(R.id.textNumber))));
        number2_press.perform(click());

        ViewInteraction number3_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_2)),(withId(R.id.textNumber))));
        number3_press.perform(click());

        ViewInteraction number4_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_3)),(withId(R.id.textNumber))));
        number4_press.perform(click());

        ViewInteraction number5_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_4)),(withId(R.id.textNumber))));
        number5_press.perform(click());

        ViewInteraction number6_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_5)),(withId(R.id.textNumber))));
        number6_press.perform(click());

        ViewInteraction number7_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_6)),(withId(R.id.textNumber))));
        number7_press.perform(click());

        ViewInteraction number8_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_7)),(withId(R.id.textNumber))));
        number8_press.perform(click());

        ViewInteraction number9_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_8)),(withId(R.id.textNumber))));
        number9_press.perform(click());

        ViewInteraction number10_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_9)),(withId(R.id.textNumber))));
        number10_press.perform(click());


        //press the call button
        ViewInteraction ivCall=onView(allOf(withId(R.id.ivCall))).check(matches(isDisplayed()));
        ivCall.perform(click());

        sleepFor(1);

        ViewInteraction appCallChoose=onView(allOf(withText(Supplier.getString(R.string.calls_app_call))))
                .check(matches(isDisplayed()));
        appCallChoose.perform(click());

        sleepFor(2);

    }


    //Call->FabButton->Contact icon press->Select Number and Call via App Call
    @Test
    public void MakeAppCallUsingSearchContact() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction callsMenu=onView(allOf(withText(Supplier.getString(R.string.calls_text))
                ,(withId(R.id.tvTabLabel)))).check(matches(isDisplayed()));
        callsMenu.perform(click());

        ViewInteraction fabChosse=onView(allOf(withId(R.id.fab))).check(matches(isDisplayed()));
        fabChosse.perform(click());

        ViewInteraction hideDialPadpress=onView(allOf(withId(R.id.ivHideDialPad))).check(matches(isDisplayed()));
        hideDialPadpress.perform(click());

        //Type something in the keypad
        ViewInteraction contactNameType=onView(allOf(withId(R.id.search_src_text)));
        contactNameType.perform(replaceText(Supplier.getString(R.string.umesh_rn)),closeSoftKeyboard());
        sleepFor(2);


        UiObject recyleView = uiDevice.findObject(new UiSelector()
                        .className("androidx.recyclerview.widget.RecyclerView")
                        .resourceId("com.reve.base:id/rv"));

        UiObject selectAttribute=recyleView.getChild(new UiSelector()
                .index(1)
                );
        selectAttribute.click();

        sleepFor(5);
        //Select the App Call

        ViewInteraction appCallChoose=onView(allOf(withText(Supplier.getString(R.string.calls_app_call))))
                .check(matches(isDisplayed()));
        appCallChoose.perform(click());

        sleepFor(10);

        //Speaker On
        ViewInteraction speaker=onView(allOf(withId(R.id.speaker_button))).check(matches(isDisplayed()));
        speaker.perform(click());

        sleepFor(10);

        //Recording On
        ViewInteraction recordingOn=onView(allOf(withId(R.id.record_button))).check(matches(isDisplayed()));
        recordingOn.perform(click());
        sleepFor(5);

        //Mute On
        ViewInteraction mute=onView(allOf(withId(R.id.mute_button))).check(matches(isDisplayed()));
        mute.perform(click());

        sleepFor(5);

        //Hold On
        ViewInteraction hold=onView(allOf(withId(R.id.ic_call_window_hold_button))).check(matches(isDisplayed()));
        hold.perform(click());

        sleepFor(5);

        //End Call
        ViewInteraction endCall=onView(allOf(withId(R.id.endcall_button))).check(matches(isDisplayed()));
        endCall.perform(click());

        sleepFor(5);

    }


    //Call->FabButton->Contact icon press->Select Number and Call via Vedio Call
    @Test
    public void MakeVideoCallUsingSearchContact() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction callsMenu=onView(allOf(withText(Supplier.getString(R.string.calls_text))
                ,(withId(R.id.tvTabLabel)))).check(matches(isDisplayed()));
        callsMenu.perform(click());

        //Select the fab
        ViewInteraction fabChosse=onView(allOf(withId(R.id.fab))).check(matches(isDisplayed()));
        fabChosse.perform(click());

        ViewInteraction hideDialPadpress=onView(allOf(withId(R.id.ivHideDialPad))).check(matches(isDisplayed()));
        hideDialPadpress.perform(click());

        //Type something in the editText
        ViewInteraction contactNameType=onView(allOf(withId(R.id.search_src_text))).check(matches(isDisplayed()));
        contactNameType.perform(replaceText(Supplier.getString(R.string.umesh_rn)),closeSoftKeyboard());
        sleepFor(2);

        UiObject recyleView = uiDevice.findObject(new UiSelector()
                .className("androidx.recyclerview.widget.RecyclerView")
                .resourceId("com.reve.base:id/rv"));

        UiObject selectAttribute=recyleView.getChild(new UiSelector()
                .index(1)
        );
        selectAttribute.click();


        sleepFor(9);
        //Select the video Call

        ViewInteraction videoCallChoose=onView(allOf(withText(Supplier.getString(R.string.calls_video_call))))
                .check(matches(isDisplayed()));
        videoCallChoose.perform(click());

        sleepFor(5);

        //Switch to Audio from vedio
        ViewInteraction swithToAudio=onView(allOf(withId(R.id.switch_to_audio_from_video)))
                .check(matches(isDisplayed()));
        swithToAudio.perform(click());
        sleepFor(5);

        //Speaker off
        ViewInteraction speakerOff=onView(allOf(withId(R.id.video_call_sepaker_button)))
                .check(matches(isDisplayed()));
        speakerOff.perform(click());
        sleepFor(5);

        //Vedio Call Mute Buttion
        ViewInteraction mute=onView(allOf(withId(R.id.video_call_mute_button)))
                .check(matches(isDisplayed()));
        mute.perform(click());
        sleepFor(5);

        //Vedio Camera Switch Container
        ViewInteraction cameraSwitch=onView(allOf(withId(R.id.video_camera_switch_container)))
                .check(matches(isDisplayed()));
        cameraSwitch.perform(click());
        sleepFor(5);

        ViewInteraction videoEnd=onView(allOf(withId(R.id.call_window_video_end_call)))
                .check(matches(isDisplayed()));
        videoEnd.perform(click());
        sleepFor(5);

    }

    //Call->FabButton->Contact icon press->Select Number and Call via International Call
    @Test
    public void MakeInternationalCallUsingSearchContact() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction callsMenu=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))))
                .check(matches(isDisplayed()));
        callsMenu.perform(click());

        //Select the fab
        ViewInteraction fabChosse=onView(allOf(withId(R.id.fab))).check(matches(isDisplayed()));
        fabChosse.perform(click());

        ViewInteraction hideDialPadpress=onView(allOf(withId(R.id.ivHideDialPad)))
                .check(matches(isDisplayed()));
        hideDialPadpress.perform(click());

        //Type something in the keypad
        ViewInteraction contactNameType=onView(allOf(withId(R.id.search_src_text)))
                .check(matches(isDisplayed()));
        contactNameType.perform(replaceText(Supplier.getString(R.string.umesh_rn)),closeSoftKeyboard());
        sleepFor(2);

        UiObject recyleView = uiDevice.findObject(new UiSelector()
                .className("androidx.recyclerview.widget.RecyclerView")
                .resourceId("com.reve.base:id/rv"));

        UiObject selectAttribute=recyleView.getChild(new UiSelector()
                .index(1)
        );
        selectAttribute.click();

        sleepFor(9);
        //Select international Call

        ViewInteraction internationalCallChoose=onView(allOf(withText(Supplier.getString(R.string.calls_international_call))))
                .check(matches(isDisplayed()));
        internationalCallChoose.perform(click());

        sleepFor(10);
    }

    //Call->FabButton->Contact icon press->Select Number and Call via App Call
    @Test
    public void DeleteCallItem() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction callMenu=onView(allOf(withText(Supplier.getString(R.string.calls_text))
                ,(withId(R.id.tvTabLabel)))).check(matches(isDisplayed()));
        callMenu.perform(click());

        UiObject deleteItemParent=uiDevice.findObject(new UiSelector()
                .className("androidx.recyclerview.widget.RecyclerView")
                .index(0));

        assertEquals(true,deleteItemParent.exists());

        UiObject deleteItem =deleteItemParent.getChild(new UiSelector()
                .className("android.widget.LinearLayout")
                .index(3));
        assertEquals(true,deleteItem.exists());

        deleteItem.longClick();

//        Rect test=test2.getBounds();
//        uiDevice.swipe(test.centerX(),test.centerX(),test.centerX(),test.centerY(),100);

        sleepFor(5);

        ViewInteraction delete=onView(allOf(withText(Supplier.getString(R.string.delete)),withId(R.id.tv))).check(matches(isDisplayed()));
        delete.perform(click());

    }
    //DeleteCallItem Method End


    private void sleepFor(long sec) {
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }

}
