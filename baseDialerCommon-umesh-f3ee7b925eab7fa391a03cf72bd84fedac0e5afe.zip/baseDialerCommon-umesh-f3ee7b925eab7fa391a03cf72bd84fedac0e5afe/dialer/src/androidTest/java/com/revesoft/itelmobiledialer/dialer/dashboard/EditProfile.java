package com.revesoft.itelmobiledialer.dialer.dashboard;


import com.revesoft.itelmobiledialer.account.EditProfileActivity;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;


import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObjectNotFoundException;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.sleepFor;


@RunWith(AndroidJUnit4.class)
public class EditProfile {

    private UiDevice uiDevice;

    //Edit Profile
    @Test
    public void EditProfileInfo() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        EditProfileActivity.startForTesting(TestApplication.getAccess().getContext());

        sleepFor(1);

        ViewInteraction profileName= onView((withId(R.id.tvProfileName))).check(matches(isDisplayed()));
        profileName.perform(replaceText(Supplier.getString(R.string.dashboard_name)));

        ViewInteraction status= onView((withId(R.id.etStatus)))
                .check(matches(isDisplayed()));
        status.perform(replaceText(Supplier.getString(R.string.dashboard_status)));

        onView((withId(R.id.phoneNumber)))
                .check(matches(withText(Supplier.getString(R.string.dashboard_sim_no))));

        ViewInteraction button= onView((withId(R.id.button)))
                .check(matches(isDisplayed()));
        button.perform(click());
        sleepFor(3);

    }

    //Edit Profile check
    @Test
    public void EditProfileInfoCheck() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        EditProfileActivity.startForTesting(TestApplication.getAccess().getContext());

        sleepFor(1);

        onView((withId(R.id.tvProfileName)))
                .check(matches(withText(Supplier.getString(R.string.dashboard_name))));
        onView((withId(R.id.etStatus)))
                .check(matches(withText(Supplier.getString(R.string.dashboard_status))));
        onView((withId(R.id.phoneNumber)))
                .check(matches(withText(Supplier.getString(R.string.dashboard_sim_no))));

        onView((withId(R.id.button))).check(matches(isDisplayed()));

    }
}
