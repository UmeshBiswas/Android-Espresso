package com.revesoft.itelmobiledialer.dialer.signup;

import com.revesoft.itelmobiledialer.dialer.TestApplication;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class AppPermision {
    private static volatile AppPermision appPermision;

    public static AppPermision getAccess() {
        if (appPermision == null) {
            synchronized (TestApplication.class) {
                if (appPermision == null) {
                    appPermision = new AppPermision();
                }
            }
        }
        return appPermision;
    }

    private UiDevice uiDevice;

    //AppPermision method
    @Test
    public void AppPermisionForSignUp() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Permission region start
        UiObject Grant_BUtton =uiDevice.findObject(new UiSelector()
                .text("GRANT")
                .className("android.widget.Button"));

        if(Grant_BUtton.exists() && Grant_BUtton.isEnabled()) {
            Grant_BUtton.click();
        }

        for(int i=0;i<6;i++) {
            UiObject Allow_BUtton = uiDevice.findObject(new UiSelector()
                    .text("ALLOW")
                    .className("android.widget.Button"));

            if (Allow_BUtton.exists() && Allow_BUtton.isEnabled()) {
                Allow_BUtton.click();
            }
        }
        //Permission region end

    }

}
