package com.revesoft.itelmobiledialer.dialer.dashboard;

import com.revesoft.itelmobiledialer.account.EditProfileActivity;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollAndSearch;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollForward;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.sleepFor;

@RunWith(AndroidJUnit4.class)
public class CheckAllElements {

    private UiDevice uiDevice;


  //Check All Elements in Dashboard
    @Test
    public void CheckAllElementsInDashboard() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        getMenu();//Method call

        onView(withId(R.id.ivProfilePicture)).check(matches(isDisplayed()));
        onView((withId(R.id.tvNameBack)))
                .check(matches(withText(Supplier.getString(R.string.dashboard_name))));
        onView((withId(R.id.tvPresenceNote)))
                .check(matches(withText(Supplier.getString(R.string.dashboard_status))));

        onView((withId(R.id.tvBalanceBack))).check(matches(isDisplayed()));

        onView((withText(Supplier.getString(R.string.dashboard_account)))).check(matches(isDisplayed()));
        onView((withText(Supplier.getString(R.string.dashboard_caller_id)))).check(matches(isDisplayed()));
        onView((withText(Supplier.getString(R.string.dashboard_did)))).check(matches(isDisplayed()));
        onView((withText(Supplier.getString(R.string.dashboard_recharge)))).check(matches(isDisplayed()));
        onView((withText(Supplier.getString(R.string.dashboard_topup)))).check(matches(isDisplayed()));
        onView((withText(Supplier.getString(R.string.dashboard_packages)))).check(matches(isDisplayed()));
        onView((withText(Supplier.getString(R.string.dashboard_rates)))).check(matches(isDisplayed()));
        ScrollForward();//Method call in CommonMethod
        onView((withText(Supplier.getString(R.string.dashboard_support)))).check(matches(isDisplayed()));
        onView((withText(Supplier.getString(R.string.dashboard_about)))).check(matches(isDisplayed()));
    }

    public void getMenu(){
        UiObject menuItem=uiDevice.findObject(new UiSelector()
                .className("android.widget.ImageButton")
                .index(0));
        try {
            menuItem.click();
        } catch (UiObjectNotFoundException e) {
            e.printStackTrace();
        }
    }
}
