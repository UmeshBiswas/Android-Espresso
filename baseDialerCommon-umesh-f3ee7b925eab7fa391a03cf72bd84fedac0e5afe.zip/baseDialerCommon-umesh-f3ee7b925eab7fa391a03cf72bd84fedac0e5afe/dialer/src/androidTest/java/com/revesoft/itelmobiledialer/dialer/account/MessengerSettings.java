package com.revesoft.itelmobiledialer.dialer.account;


import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.account.NotificationSettingsActivity;
import com.revesoft.itelmobiledialer.account.SettingsActivity;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.MyViewAction;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.core.AllOf.allOf;

@RunWith(AndroidJUnit4.class)
public class MessengerSettings {

    private UiDevice uiDevice;


    //Account Privacy Method Start
    @Test
    public void AccountsPrivacy() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        AccountActivity.startForTesting(TestApplication.getAccess().getContext());


        ViewInteraction messengerSettings=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_messenger_settings)))));
        messengerSettings.perform(click());

        ViewInteraction accountPrivacy=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_account_privacy)))));
        accountPrivacy.perform(click());


        //profile photo
        ViewInteraction profilePhoto=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_profile_photo)))));
        profilePhoto.perform(click());

        ViewInteraction everyOneProfilePhoto=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_everyone)))));
        everyOneProfilePhoto.perform(click());

        ViewInteraction myContactProfilePhoto=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_my_contacts)))));

        ViewInteraction noBodyProfilePhoto=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_nobody)))));

        //Status

        ViewInteraction status=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_status)))));
        status.perform(click());

        ViewInteraction everyOneStatus=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_everyone)))));
        everyOneStatus.perform(click());

        ViewInteraction myContactStatus=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_my_contacts)))));

        ViewInteraction noBodyStatus=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_nobody)))));

        //Blocked Contacts
        ViewInteraction blockedContacts=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_block_contacts)))));
        blockedContacts.perform(click());

        onView(withId(R.id.rv))
                .check(matches(hasDescendant(withText(Supplier.getString(R.string.abdul_kader)))));
    }


    //Notifications Method Start
    @Test
    public void Notifications() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        SettingsActivity.startForTesting(TestApplication.getAccess().getContext());

        ViewInteraction notifications=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_notifications)))));
        notifications.perform(click());

        //Message Notifications Start

        ViewInteraction notificationsTone=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_notifications_tone)))));
        notificationsTone.perform(click());

        UiScrollable SelectTone = new UiScrollable(new UiSelector()
                .className("android.widget.TextView")
                .text(Supplier.getString(R.string.ringtone_name)));
        SelectTone.click();

        //Done or Cancle Button click
        UiObject Donebutton =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.done_cap))
                .className("android.widget.Button"));

        // Simulate a user-click on the everyOne button, if found.
        if(Donebutton.exists() && Donebutton.isEnabled()) {
            Donebutton.click();
        }


        //Notifications Vibrate start

        UiScrollable NotificationsVibrate = new UiScrollable(new UiSelector()
                .className("android.widget.TextView")
                .text(Supplier.getString(R.string.vibrate)));
        NotificationsVibrate.click();

        //Done or Cancle Button click
        UiObject Vibrationbutton =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.default_text))
                .className("android.widget.CheckedTextView"));

        // Simulate Vibration type from the vibration layout
        if(Vibrationbutton.exists() && Vibrationbutton.isEnabled()) {
            Vibrationbutton.click();
        }

        //Notifications Vibrate end


        //Notifications PopUp start

        UiScrollable NotificationsPopUp = new UiScrollable(new UiSelector()
                .className("android.widget.TextView")
                .text(Supplier.getString(R.string.account_popup_notification)));
        NotificationsPopUp.click();

        //PopUp Notifications
        UiObject PopUpNotifications =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.account_no_popup))
                .className("android.widget.CheckedTextView"));

        // Simulate Vibration type from the vibration layout
        if(PopUpNotifications.exists() && PopUpNotifications.isEnabled()) {
            PopUpNotifications.click();
        }

        //Message Notifications End


        //Call Notifications Start

        //Notifications Ringtone start

        UiScrollable NotificationsRingtone = new UiScrollable(new UiSelector()
                .className("android.widget.TextView")
                .text(Supplier.getString(R.string.ringtone_text)));
        NotificationsRingtone.click();

        //PopUp Select
        UiObject PopUpSelect =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.phone_ringtone))
                .className("android.widget.TextView"));

        // Simulate Vibration type from the vibration layout
        if(PopUpSelect.exists() && PopUpSelect.isEnabled()) {
            PopUpSelect.click();
        }


        //Select Sound Picker
        UiScrollable SoundPicker = new UiScrollable(new UiSelector()
                .className("android.widget.TextView")
                .text(Supplier.getString(R.string.ringtone_atria)));
        SoundPicker.click();

        //Done or Cancle Button click
        UiObject DoneSoundPicker =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.done_cap))
                .className("android.widget.Button"));

        // Simulate a user-click on the everyOne button, if found.
        if(DoneSoundPicker.exists() && DoneSoundPicker.isEnabled()) {
            DoneSoundPicker.click();
        }


        //Notifications Ringtone end

        // Notification Vibrate start
        UiScrollable NotificationsCallVibrate = new UiScrollable(new UiSelector()
                .className("android.widget.TextView")
                .text(Supplier.getString(R.string.vibrate_text)));
        NotificationsCallVibrate.click();

        //PopUp Select
        UiObject PopUpVibrate =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.short_text))
                .className("android.widget.CheckedTextView"));

        // Simulate Vibration type from the vibration layout
        if(PopUpVibrate.exists() && PopUpVibrate.isEnabled()) {
            PopUpVibrate.click();
        }

        //Notification Vibrate End

        //Call Notifications End


        //Notifications End

    }
    //Messenger settings Notifications Method End

    //DataUsages Method Start
    @Test
    public void DataUsages() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        SettingsActivity.startForTesting(TestApplication.getAccess().getContext());

        ViewInteraction dataUsage=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_data_usages)))));
        dataUsage.perform(click());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction wumd=onView((withId(R.id.sMobileData)));
        wumd.perform(click());


        ViewInteraction wcoWiFi=onView(allOf(withId(R.id.sWifiData)));
        wcoWiFi.perform(click());

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    //DataUsages Method End
}
