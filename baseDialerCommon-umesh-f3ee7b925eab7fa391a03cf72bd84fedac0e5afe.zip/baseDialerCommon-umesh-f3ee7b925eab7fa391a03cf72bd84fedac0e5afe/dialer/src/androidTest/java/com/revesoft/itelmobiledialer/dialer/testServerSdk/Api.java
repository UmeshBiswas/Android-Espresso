package com.revesoft.itelmobiledialer.dialer.testServerSdk;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Api {
    private static Retrofit api = null;
    private static final String BaseUrl = "https://test-automation-server.herokuapp.com/api/v1/";

    public static Retrofit getAccess() {
        if (api == null) {
            api = new Retrofit.Builder()
                    .baseUrl(BaseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

        }
        return api;
    }

    public void registerWithServer(Client client) {

    }

}
