package com.revesoft.itelmobiledialer.dialer.account;

import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.dialer.callForward.CallForwardingSettingsActivity;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObjectNotFoundException;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.fail;

@RunWith(AndroidJUnit4.class)
public class CallForwarding {
    private UiDevice uiDevice;


    //Call Forwarding without Number
    @Test
    public void CallForwardingWithoutNumber() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        AccountActivity.startForTesting(TestApplication.getAccess().getContext());

        ViewInteraction callForwarding=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_call_forwarding_text)))));
        callForwarding.perform(click());
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction setForwaringNumber= onView((withId(R.id.btn_set_number)))
                .check(matches(isDisplayed()));
        setForwaringNumber.perform(click());

        ViewInteraction save= onView((withId(R.id.btn_save)))
                .check(matches(isDisplayed()));
        save.perform(click());

        onView((withText(Supplier.getString(R.string.account_call_forward_insert_forwarding_number))))
                .check(matches(isDisplayed()));

        ViewInteraction ok=onView((withText(Supplier.getString(R.string.ok_text))))
                .check(matches(isDisplayed()));
        ok.perform(click());


        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }


    //Call Forwarding Number Set
    @Test
    public void CallForwardingSetNumber() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        AccountActivity.startForTesting(TestApplication.getAccess().getContext());

        ViewInteraction callForwarding=onView(allOf(instanceOf(android.widget.TextView.class)
                ,(withText(Supplier.getString(R.string.account_call_forwarding_text)))));
        callForwarding.perform(click());

        sleepFor(3);

        ViewInteraction setForwaringNumber= onView((withId(R.id.btn_set_number)))
                .check(matches(isDisplayed()));
        setForwaringNumber.perform(click());

        ViewInteraction insertNumber= onView((withId(R.id.et_cf_number)))
                .check(matches(isDisplayed()));
        insertNumber.perform(replaceText(Supplier.getString(R.string.account_call_forward_number)));

        ViewInteraction save= onView((withId(R.id.btn_save)))
                .check(matches(isDisplayed()));
        save.perform(click());

        sleepFor(2);

    }


    //Call Forwarding Change forwarding Number
    @Test
    public void CallForwardingChangeNumber() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        CallForwardingSettingsActivity.startForTesting(TestApplication.getAccess().getContext());

        sleepFor(3);
        ViewInteraction changeForwardNumber= onView((withId(R.id.btn_change_number)))
                .check(matches(isDisplayed()));
        changeForwardNumber.perform(click());

        ViewInteraction insertNumber= onView((withId(R.id.et_cf_number)))
                .check(matches(isDisplayed()));
        insertNumber.perform(replaceText(Supplier.getString(R.string.account_call_forward_number)));

        ViewInteraction save= onView((withId(R.id.btn_save)))
                .check(matches(isDisplayed()));
        save.perform(click());

        sleepFor(3);


    }

    //Call Forwarding disable
    @Test
    public void CallForwardingDisable() throws UiObjectNotFoundException, IOException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        CallForwardingSettingsActivity.startForTesting(TestApplication.getAccess().getContext());

        sleepFor(3);
        ViewInteraction disableCallForward= onView((withId(R.id.btn_disable_call_forwarding)))
                .check(matches(isDisplayed()));
        disableCallForward.perform(click());

        sleepFor(3);

    }


   //Sleep (Timer)
    private void sleepFor(long sec) {
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }



}
