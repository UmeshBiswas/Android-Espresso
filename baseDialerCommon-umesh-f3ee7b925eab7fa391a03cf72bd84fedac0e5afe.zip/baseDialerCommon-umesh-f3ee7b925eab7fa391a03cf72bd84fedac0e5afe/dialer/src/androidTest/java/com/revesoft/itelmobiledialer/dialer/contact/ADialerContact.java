package com.revesoft.itelmobiledialer.dialer.contact;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static junit.framework.TestCase.fail;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;


@RunWith(AndroidJUnit4.class)
public class ADialerContact {

    private UiDevice uiDevice;


    //check Audio call,video call, chat option icon for A dialer installer.existence for the icon
    @Test
    public void AudioVideoChatOptionInADialerContact() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_a_dialer));

        onView(withIndex(withId(R.id.ivAudioCall), 0)).check(matches(isDisplayed()));
        onView(withIndex(withId(R.id.ivVideoCall), 0)).check(matches(isDisplayed()));
        onView(withIndex(withId(R.id.ivChat), 0)).check(matches(isDisplayed()));

    }


    //make audio,video,message from a dialer
    @Test
    public void AudioCallFromADialer() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_a_dialer));

        ViewInteraction audioCall=onView(withIndex(withId(R.id.ivAudioCall), 0));
        audioCall.perform(click());
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void VideoCallFromADialer() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_a_dialer));

        ViewInteraction videoCall=onView(withIndex(withId(R.id.ivVideoCall), 0));
        videoCall.perform(click());
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void MessagingFromADialer() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_a_dialer));

        ViewInteraction messaging=onView(withIndex(withId(R.id.ivChat), 0));
        messaging.perform(click());
        ViewInteraction etMessage = onView(allOf(withId(R.id.etMessage)));
        etMessage.perform(replaceText(Supplier.getString(R.string.a_dialer_send_message)), closeSoftKeyboard());

        ViewInteraction ivSend = onView(allOf(withId(R.id.ivSend)));
        ivSend.perform(click());

    }



    //check callOut option for who didn't install dialer
    @Test
    public void SearchByTypingNamePhoneNumber() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_text)), (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button = onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView = onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.chat_search_text)), closeSoftKeyboard());
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withIndex(withId(R.id.content), 0)).check(matches(isDisplayed()));


    }

    //Search any name then go any other page & then go back to contact page
    @Test
    public void SearchAnyNameThenGoBack() throws UiObjectNotFoundException,IOException{

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click = onView(allOf(withText(Supplier.getString(R.string.contact_text)), (withId(R.id.tvTabLabel))));
        contacts_click.perform(click());


        //Press the search button
        ViewInteraction search_button = onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView = onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.chat_search_text)), closeSoftKeyboard());

        //go any other page
        //Select the Call menu from the tab view
        ViewInteraction calls_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));
        calls_click.perform(click());

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click1 = onView(allOf(withText(Supplier.getString(R.string.contact_text)), (withId(R.id.tvTabLabel))));
        contacts_click1.perform(click());

        onView(withIndex(withId(R.id.content), 0)).check(matches(isDisplayed()));


    }

    //Dial Pad Via AppCall Contact Method Start
    //Call->FabButton->Contact icon press->Select Number and Call via App Call
    @Test
    public void DialPadKeypadAppCall() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        lunchContactDetailsForPin(Supplier.getString(R.string.contact_target_pin_for_a_dialer));


        UiObject recyleView = uiDevice.findObject(new UiSelector()
                .className("androidx.recyclerview.widget.RecyclerView")
                .resourceId("com.reve.base:id/rv"));

        UiObject selectAttribute=recyleView.getChild(new UiSelector()
                .index(1)
        );
        selectAttribute.click();


        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Select the App Call

        UiObject press_appCall=uiDevice.findObject(new UiSelector()
                .index(0)
                .text(Supplier.getString(R.string.calls_app_call))
                .resourceId("android:id/text1"));
        assertEquals(true,press_appCall.exists());
        press_appCall.click();

        try{
            Thread.sleep(10000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Speaker On
        ViewInteraction speaker_press=onView(allOf(withId(R.id.speaker_button)));
        speaker_press.perform(click());

        try{
            Thread.sleep(10000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Recording On
        ViewInteraction recordingOn_press=onView(allOf(withId(R.id.record_button)));
        recordingOn_press.perform(click());
        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Mute On
        ViewInteraction mute_press=onView(allOf(withId(R.id.mute_button)));
        mute_press.perform(click());

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Hold On
        ViewInteraction hold_press=onView(allOf(withId(R.id.ic_call_window_hold_button)));
        hold_press.perform(click());

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //End Call
        ViewInteraction endCall=onView(allOf(withId(R.id.endcall_button)));
        endCall.perform(click());

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Dial Pad Via AppCall Contact Method End


    // lunch the app start
    private void lunchContactDetailsForPin(String pin) {
        Executor.ex(()->{
            String contactId = ContactRepo.get().getContactIdByFlatNumber(pin);
            if(TextUtils.isEmpty(contactId)){
                fail();
            }
            Gui.get().run(()->{
                ContactDetailsActivity.startForTesting(TestApplication.getAccess().getContext(),contactId,pin);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        });

    }
}

