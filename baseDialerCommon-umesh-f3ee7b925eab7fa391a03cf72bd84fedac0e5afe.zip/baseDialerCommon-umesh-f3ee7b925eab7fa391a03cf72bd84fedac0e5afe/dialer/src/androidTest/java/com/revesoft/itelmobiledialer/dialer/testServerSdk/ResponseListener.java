package com.revesoft.itelmobiledialer.dialer.testServerSdk;

public interface ResponseListener {
    void onResponse(Response response, Exception e);
}
