package com.revesoft.itelmobiledialer.dialer.contact;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollForward;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.sleepFor;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static junit.framework.TestCase.fail;
import static org.hamcrest.core.AllOf.allOf;


@RunWith(AndroidJUnit4.class)
public class Blocked {

    private UiDevice uiDevice;


    //Add a Contact Into BlockList
    @Test
    public void AddContactIntoBlockList() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //Select the Contacts menu from the tab view
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.contact_text)),(withId(R.id.tvTabLabel))));
        contacts_click.perform(click());

        //Press the search button
        ViewInteraction search_button=onView(allOf(withId(R.id.search_button)));
        search_button.perform(click());
        ViewInteraction search_editView=onView(allOf(withId(R.id.search_src_text)));
        search_editView.perform(replaceText(Supplier.getString(R.string.blocklist_search_text)),closeSoftKeyboard());

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView (withIndex(withId(R.id.content), 0)).perform(click());


        sleepFor(5);





        //   onView(ViewMatchers.withId(R.id.tvBlock)).perform(ViewActions.scrollTo());



//        ViewInteraction block_click=onView(allOf(withId(R.id.tvBlock)));
//        block_click.perform(click());
        try{
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Add a Contact Into BlockList End







    // lunch the app start
    private void lunchContactDetailsForPin(String pin) {
        Executor.ex(()->{
            String contactId = ContactRepo.get().getContactIdByFlatNumber(pin);
            if(TextUtils.isEmpty(contactId)){
                fail();
            }
            Gui.get().run(()->{
                ContactDetailsActivity.startForTesting(TestApplication.getAccess().getContext(),contactId,pin);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        });

    }

}

