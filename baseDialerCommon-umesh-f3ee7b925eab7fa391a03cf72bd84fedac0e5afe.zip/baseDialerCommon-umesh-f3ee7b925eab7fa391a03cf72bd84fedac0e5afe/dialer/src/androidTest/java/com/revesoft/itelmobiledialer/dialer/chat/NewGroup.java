package com.revesoft.itelmobiledialer.dialer.chat;

import com.revesoft.itelmobiledialer.arch.Supplier;

import com.revesoft.itelmobiledialer.dialer.TestApplication;

import com.revesoft.material.R;

import org.junit.Test;

import java.io.IOException;

import androidx.test.espresso.ViewInteraction;
import androidx.test.platform.app.InstrumentationRegistry;

import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.ScrollAndSearch;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.getSearchButton;
import static com.revesoft.itelmobiledialer.dialer.CommonMethod.withIndex;
import static freemarker.template.utility.NullArgumentException.check;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;


public class NewGroup {

    private UiDevice uiDevice;

    //New Group->click fab without select number/contact
    @Test
    public void CreateNewGroupWithoutContact() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        getByIndexAndClass(1,"android.widget.ImageView");//method call

        ViewInteraction newGroup = onView(allOf(withText(Supplier.getString(R.string.chat_new_group))
                , (withId(R.id.title)))).check(matches(isDisplayed()));
        newGroup.perform(click());


        ViewInteraction fabButton = onView((withId(R.id.fab))).check(matches(isDisplayed()));
        fabButton.perform(click());

    }

    //New Group->Select contact->click fab without name
    @Test
    public void CreateNewGroupWithoutName() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        getByIndexAndClass(1,"android.widget.ImageView");//method call

        ViewInteraction newGroup = onView(allOf(withText(Supplier.getString(R.string.chat_new_group))
                , (withId(R.id.title)))).check(matches(isDisplayed()));
        newGroup.perform(click());

        //Choose member from contact list

        //ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_1));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_2));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_3));

        ViewInteraction fabButton = onView((withId(R.id.fab))).check(matches(isDisplayed()));
        fabButton.perform(click());

        //image upload will be here

        getByIndexAndClass(1,"android.widget.ImageButton");

        sleepFor(3);

    }

    //Create New Group and send sms
    @Test
    public void CreateNewGroup() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        getByIndexAndClass(1,"android.widget.ImageView");//method call

        ViewInteraction newGroup = onView(allOf(withText(Supplier.getString(R.string.chat_new_group))
                , (withId(R.id.title)))).check(matches(isDisplayed()));
        newGroup.perform(click());

        //Choose member from contact list

        //ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_1));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_2));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_3));

        ViewInteraction fabButton = onView((withId(R.id.fab))).check(matches(isDisplayed()));
        fabButton.perform(click());

        //image upload will be here

        ViewInteraction groupName=onView(allOf(withId(R.id.etGroupName)
                ,(instanceOf(android.widget.EditText.class))
                ,(withHint(Supplier.getString(R.string.chat_hints_group_name)))))
                .check(matches(isDisplayed()));
        groupName.perform(replaceText(Supplier.getString(R.string.chat_group_name)),closeSoftKeyboard());

        getByIndexAndClass(1,"android.widget.ImageButton");

        sleepFor(3);

        ViewInteraction typeSms=onView(allOf(withId(R.id.etMessage)
                ,(instanceOf(android.widget.EditText.class))))
                .check(matches(isDisplayed()));
        typeSms.perform(replaceText(Supplier.getString(R.string.chat_send_sms)),closeSoftKeyboard());

        ViewInteraction sendSms=onView(allOf((withId(R.id.ivSend))))
                .check(matches(isDisplayed()));
       // sendSms.perform(click());

    }

    //Create New Group->Add more member while naming the group
    @Test
    public void CreateNewGroupAddMoreMember() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        getByIndexAndClass(1,"android.widget.ImageView");//method call

        ViewInteraction newGroup = onView(allOf(withText(Supplier.getString(R.string.chat_new_group))
                , (withId(R.id.title)))).check(matches(isDisplayed()));
        newGroup.perform(click());

        //Choose member from contact list

        //ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_1));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_2));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_3));

        ViewInteraction fabButton = onView((withId(R.id.fab))).check(matches(isDisplayed()));
        fabButton.perform(click());

        //add more member
        ViewInteraction addMoreMember=onView(allOf(withId(R.id.ivAddNumber)
                ,(instanceOf(android.widget.ImageView.class))))
                .check(matches(isDisplayed()));
        addMoreMember.perform(click());
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_1));

        ViewInteraction fabButtonAddMore = onView((withId(R.id.fab))).check(matches(isDisplayed()));
        fabButtonAddMore.perform(click());

        //image upload will be here

        ViewInteraction groupName=onView(allOf(withId(R.id.etGroupName)
                ,(instanceOf(android.widget.EditText.class))
                ,(withHint(Supplier.getString(R.string.chat_hints_group_name)))))
                .check(matches(isDisplayed()));
        groupName.perform(replaceText(Supplier.getString(R.string.chat_group_name)),closeSoftKeyboard());


        getByIndexAndClass(1,"android.widget.ImageButton");

        sleepFor(3);

        ViewInteraction typeSms=onView(allOf(withId(R.id.etMessage)
                ,(instanceOf(android.widget.EditText.class))))
                .check(matches(isDisplayed()));
        typeSms.perform(replaceText(Supplier.getString(R.string.chat_send_sms)),closeSoftKeyboard());

        ViewInteraction sendSms=onView(allOf((withId(R.id.ivSend))))
                .check(matches(isDisplayed()));
      //  sendSms.perform(click());

    }

    //Create New Group->Remove member while naming the group
    @Test
    public void CreateNewGroupRemoveMember() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        getByIndexAndClass(1,"android.widget.ImageView");//method call

        ViewInteraction newGroup = onView(allOf(withText(Supplier.getString(R.string.chat_new_group))
                , (withId(R.id.title)))).check(matches(isDisplayed()));
        newGroup.perform(click());

        //Choose member from contact list

        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_1));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_2));
        ScrollAndSearch(Supplier.getString(R.string.chat_phone_number_3));

        ViewInteraction fabButton = onView((withId(R.id.fab))).check(matches(isDisplayed()));
        fabButton.perform(click());
        sleepFor(4);

        //remove member
        removeIndex(1); //method call
        sleepFor(5);

        //image upload will be here

        ViewInteraction groupName=onView(allOf(withId(R.id.etGroupName)
                ,(instanceOf(android.widget.EditText.class))
                ,(withHint(Supplier.getString(R.string.chat_hints_group_name)))))
                .check(matches(isDisplayed()));
        groupName.perform(replaceText(Supplier.getString(R.string.chat_group_name)),closeSoftKeyboard());


        getByIndexAndClass(1,"android.widget.ImageButton");

        sleepFor(3);

        ViewInteraction typeSms=onView(allOf(withId(R.id.etMessage)
                ,(instanceOf(android.widget.EditText.class))))
                .check(matches(isDisplayed()));
        typeSms.perform(replaceText(Supplier.getString(R.string.chat_send_sms)),closeSoftKeyboard());

        ViewInteraction sendSms=onView(allOf((withId(R.id.ivSend))))
                .check(matches(isDisplayed()));
        //  sendSms.perform(click());

    }

    //Create New Group and send sms using Search
    @Test
    public void CreateNewGroupUsingSearch() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        getByIndexAndClass(1,"android.widget.ImageView");//method call

        ViewInteraction newGroup = onView(allOf(withText(Supplier.getString(R.string.chat_new_group))
                , (withId(R.id.title)))).check(matches(isDisplayed()));
        newGroup.perform(click());

        //method call
        getSearchButton(Supplier.getString(R.string.chat_phone_number_2));
        getSearchButton(Supplier.getString(R.string.chat_phone_number_3));

        ViewInteraction fabButton = onView((withId(R.id.fab))).check(matches(isDisplayed()));
        fabButton.perform(click());
        sleepFor(5);

        //image upload will be here

        ViewInteraction groupName=onView(allOf(withId(R.id.etGroupName)
                ,(instanceOf(android.widget.EditText.class))
                ,(withHint(Supplier.getString(R.string.chat_hints_group_name)))))
                .check(matches(isDisplayed()));
        groupName.perform(replaceText(Supplier.getString(R.string.chat_group_name)),closeSoftKeyboard());

        getByIndexAndClass(1,"android.widget.ImageButton");

        sleepFor(3);

        ViewInteraction typeSms=onView(allOf(withId(R.id.etMessage)
                ,(instanceOf(android.widget.EditText.class))))
                .check(matches(isDisplayed()));
        typeSms.perform(replaceText(Supplier.getString(R.string.chat_send_sms)),closeSoftKeyboard());

        ViewInteraction sendSms=onView(allOf((withId(R.id.ivSend))))
                .check(matches(isDisplayed()));
//        sendSms.perform(click());

    }


    //Others method

    private void sleepFor(long sec) {
        try {
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            fail();
            e.printStackTrace();
        }
    }

    public void getByIndexAndClass(int indexNo,String className){
        UiObject menubar = uiDevice.findObject(new UiSelector()
                .index(indexNo)
                .className(className));
        assertEquals(true, menubar.exists());
        try {
            menubar.click();
        } catch (UiObjectNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void removeIndex(int indexNo){
        UiObject listView=uiDevice.findObject(new UiSelector()
                .className("android.widget.ListView")
                .index(0));
        assertEquals(true,listView.exists());
        UiObject  relativeLayout = null;
        try {
              relativeLayout = listView.getChild(new UiSelector().className("android.widget.RelativeLayout")
                    .index(indexNo));
        } catch (UiObjectNotFoundException e) {
            e.printStackTrace();
        }
        assertEquals(true,relativeLayout.exists());
        try {
            relativeLayout.getChild(new UiSelector ().index(2)).click();
        } catch (UiObjectNotFoundException e) {
            e.printStackTrace();
        }
    }

}
