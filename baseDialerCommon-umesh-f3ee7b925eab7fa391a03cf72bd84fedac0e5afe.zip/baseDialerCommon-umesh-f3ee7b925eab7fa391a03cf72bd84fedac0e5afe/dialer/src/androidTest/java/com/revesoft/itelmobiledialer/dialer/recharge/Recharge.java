package com.revesoft.itelmobiledialer.dialer.recharge;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.revesoft.itelmobiledialer.arch.Supplier;

import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.recharge.RechargeContainerActivity;
import com.revesoft.itelmobiledialer.recharge.RechargeOptionsActivity;
import com.revesoft.material.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class Recharge {

    private UiDevice uiDevice;


    //Recharge Via Credit Card Method Start
    @Test
    public void RechargeViaCreditCard() throws UiObjectNotFoundException, IOException, InterruptedException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();
        RechargeOptionsActivity.startForTesting(TestApplication.getAccess().getContext());

        //Recharge via Credit Card
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.recharge_recharge_via_credit_card))));
        contacts_click.check(matches(isDisplayed())).perform(click());

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //input the amount
        ViewInteraction enterAmount=onView(allOf(withId(R.id.enterAmountText)))
                .check(matches( withHint(Supplier.getString(R.string.recharge_enter_amount_hint))));
        enterAmount.check(matches(isDisplayed())).perform(replaceText(Supplier.getString(R.string.recharge_amount)));

        //click the next button
        ViewInteraction nextButton=onView(allOf(withId(R.id.addRechargeButton)))
                .check(matches(withText(Supplier.getString(R.string.next_button))));
        nextButton.perform(click());

        try {
            Thread.sleep(8000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Select the app via payPal
        ViewInteraction payWith=onView(allOf(withText(Supplier.getString(R.string.recharge_pay_with))));
        payWith.perform(click());

        //input the email & password
        ViewInteraction emailId= onView(allOf(instanceOf(android.widget.EditText.class),
                withHint(Supplier.getString(R.string.recharge_email_hint)))).check(matches(isDisplayed()));
        emailId.perform(replaceText(Supplier.getString(R.string.recharge_email)));

        ViewInteraction password= onView(allOf(instanceOf(android.widget.EditText.class),
                withHint(Supplier.getString(R.string.recharge_password_hint))));
        password.perform(replaceText(Supplier.getString(R.string.recharge_password)));

        try{
            Thread.sleep(3000);
        }catch (InterruptedException e)
        {
            e.printStackTrace();
        }

    }
    //Recharge Via Credit Card Method End

    //Recharge Via Code Method Start
    @Test
    public void RechargeViaCode() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        RechargeOptionsActivity.startForTesting(TestApplication.getAccess().getContext());
        //Recharge via Credit Card
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.recharge_recharge_via_code))));
        contacts_click.perform(click());

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //input the amount
        ViewInteraction enterAmount=onView(allOf(withId(R.id.enterAmountText)))
                .check(matches( withHint(Supplier.getString(R.string.recharge_enter_recharge_code))));
        enterAmount.perform(replaceText("10"),closeSoftKeyboard());

        //click the next button
        ViewInteraction nextButton=onView(allOf(withId(R.id.addRechargeButton)))
                .check(matches(withText(Supplier.getString(R.string.next_button))));
        nextButton.perform(click());

        try {
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Recharge Via Code Method End

    //Recharge Report method Start
    @Test
    public void RechargeReport() throws UiObjectNotFoundException, IOException, InterruptedException {

        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        RechargeOptionsActivity.startForTesting(TestApplication.getAccess().getContext());

        Thread.sleep(2000);
        //Recharge via Credit Card
        ViewInteraction contacts_click=onView(allOf(withText(Supplier.getString(R.string.recharge_report))))
                .check(matches(isDisplayed()));
        contacts_click.perform(click());

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    //Recharge Report Method End

}
