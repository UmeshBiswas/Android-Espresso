package com.revesoft.itelmobiledialer.dialer;

import android.content.Context;
import android.content.Intent;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.Until;

public class TestApplication {
    private static volatile TestApplication testApplication;

    public static TestApplication getAccess() {
        if (testApplication == null) {
            synchronized (TestApplication.class) {
                if (testApplication == null) {
                    testApplication = new TestApplication();
                }
            }
        }
        return testApplication;
    }

    private UiDevice uiDevice;
    private Context context;
    public UiDevice getUiDevice() {
        return uiDevice;
    }

    public Context getContext() {
        return context;
    }

    public void lunch(){
        String packageName = context.getPackageName();
        final Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            context.startActivity(intent);
            uiDevice.wait(Until.hasObject(By.pkg(packageName).depth(0)), 10000);
        }
    }
    private TestApplication() {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        context = ApplicationProvider.getApplicationContext();
    }
}
