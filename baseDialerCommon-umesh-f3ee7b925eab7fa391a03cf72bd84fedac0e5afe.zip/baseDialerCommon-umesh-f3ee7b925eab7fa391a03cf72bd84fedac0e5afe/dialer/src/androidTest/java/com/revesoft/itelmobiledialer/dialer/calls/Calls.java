package com.revesoft.itelmobiledialer.dialer.calls;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.view.View;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withParentIndex;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class Calls {
    private static final String DIALER_PACKAGE_NAME = "com.reve.base";

    private UiDevice mDevice;


  //Dial Pad Call Method Start
    //Call->FabButton->Number press->AppCall/VedioCall/International Call
    @Test
    public void DialPad() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction calls_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));
        calls_click.perform(click());

        //Select the fab
        ViewInteraction fab_click=onView(allOf(withId(R.id.fab)));
        fab_click.perform(click());


        //Press a number from the dialer start
        ViewInteraction number1_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_0)),(withId(R.id.textNumber))));
        number1_press.perform(click());

        ViewInteraction number2_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_1)),(withId(R.id.textNumber))));
        number2_press.perform(click());

        ViewInteraction number3_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_2)),(withId(R.id.textNumber))));
        number3_press.perform(click());

        ViewInteraction number4_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_3)),(withId(R.id.textNumber))));
        number4_press.perform(click());

        ViewInteraction number5_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_4)),(withId(R.id.textNumber))));
        number5_press.perform(click());

        ViewInteraction number6_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_5)),(withId(R.id.textNumber))));
        number6_press.perform(click());

        ViewInteraction number7_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_6)),(withId(R.id.textNumber))));
        number7_press.perform(click());

        ViewInteraction number8_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_7)),(withId(R.id.textNumber))));
        number8_press.perform(click());

        ViewInteraction number9_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_8)),(withId(R.id.textNumber))));
        number9_press.perform(click());

        ViewInteraction number10_press=onView(allOf(withText(Supplier.getString(R.string.calls_degit_9)),(withId(R.id.textNumber))));
        number10_press.perform(click());


        //Press a number from the dialer end


        //press the dialer button
        ViewInteraction ivCall=onView(allOf(withId(R.id.ivCall)));
        ivCall.perform(click());

        try{
            Thread.sleep(2000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Select the App Call

        UiObject press_appCall=mDevice.findObject(new UiSelector()
                .index(0)
                .text(Supplier.getString(R.string.calls_app_call))
                .resourceId("android:id/text1"));
        assertEquals(true,press_appCall.exists());
        press_appCall.click();

        try{
            Thread.sleep(9000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }


    }

    //Dial Pad Via AppCall Contact Method Start
    //Call->FabButton->Contact icon press->Select Number and Call via App Call
    @Test
    public void DialPadKeypadAppCall() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction calls_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));
        calls_click.perform(click());

        //Select the fab
        ViewInteraction fab_click=onView(allOf(withId(R.id.fab)));
        fab_click.perform(click());

        //Select the fab
        ViewInteraction keypad_press=onView(allOf(withId(R.id.ivHideDialPad)));
        keypad_press.perform(click());

        //Type something in the keypad
        ViewInteraction keypad_text=onView(allOf(withId(R.id.search_src_text)));
        keypad_text.perform(replaceText(Supplier.getString(R.string.umesh_rn)),closeSoftKeyboard());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject recyleView = mDevice.findObject(new UiSelector()
                        .className("androidx.recyclerview.widget.RecyclerView")
                        .resourceId("com.reve.base:id/rv"));

        UiObject selectAttribute=recyleView.getChild(new UiSelector()
                .index(1)
                );
        selectAttribute.click();


        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Select the App Call

        UiObject press_appCall=mDevice.findObject(new UiSelector()
                .index(0)
                .text(Supplier.getString(R.string.calls_app_call))
                .resourceId("android:id/text1"));
        assertEquals(true,press_appCall.exists());
        press_appCall.click();

        try{
            Thread.sleep(10000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Speaker On
        ViewInteraction speaker_press=onView(allOf(withId(R.id.speaker_button)));
        speaker_press.perform(click());

        try{
            Thread.sleep(10000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Recording On
        ViewInteraction recordingOn_press=onView(allOf(withId(R.id.record_button)));
        recordingOn_press.perform(click());
        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Mute On
        ViewInteraction mute_press=onView(allOf(withId(R.id.mute_button)));
        mute_press.perform(click());

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Hold On
        ViewInteraction hold_press=onView(allOf(withId(R.id.ic_call_window_hold_button)));
        hold_press.perform(click());

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //End Call
        ViewInteraction endCall=onView(allOf(withId(R.id.endcall_button)));
        endCall.perform(click());

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Dial Pad Via AppCall Contact Method End


    //Dial Pad Via VedioCall Method Start
    //Call->FabButton->Contact icon press->Select Number and Call via Vedio Call
    @Test
    public void DialPadKeypadVedioCall() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction calls_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));
        calls_click.perform(click());

        //Select the fab
        ViewInteraction fab_click=onView(allOf(withId(R.id.fab)));
        fab_click.perform(click());

        //Select the fab
        ViewInteraction keypad_press=onView(allOf(withId(R.id.ivHideDialPad)));
        keypad_press.perform(click());

        //Type something in the keypad
        ViewInteraction keypad_text=onView(allOf(withId(R.id.search_src_text)));
        keypad_text.perform(replaceText(Supplier.getString(R.string.umesh_rn)),closeSoftKeyboard());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject recyleView = mDevice.findObject(new UiSelector()
                .className("androidx.recyclerview.widget.RecyclerView")
                .resourceId("com.reve.base:id/rv"));

        UiObject selectAttribute=recyleView.getChild(new UiSelector()
                .index(1)
        );
        selectAttribute.click();


        try {
            Thread.sleep(9000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Select the App Call

        UiObject press_videoCall=mDevice.findObject(new UiSelector()
                .index(1)
                .text(Supplier.getString(R.string.calls_video_call))
                .resourceId("android:id/text1"));
        assertEquals(true,press_videoCall.exists());
        press_videoCall.click();

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //Switch to Audio from vedio
        ViewInteraction swith_to_audio=onView(allOf(withId(R.id.switch_to_audio_from_video)));
        swith_to_audio.perform(click());
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Speaker off
        ViewInteraction speaker_off=onView(allOf(withId(R.id.video_call_sepaker_button)));
        speaker_off.perform(click());
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Vedio Call Mute Buttion
        ViewInteraction mute_button=onView(allOf(withId(R.id.video_call_mute_button)));
        mute_button.perform(click());
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Vedio Camera Switch Container
        ViewInteraction camera_switch=onView(allOf(withId(R.id.video_camera_switch_container)));
        camera_switch.perform(click());
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Vedio Camera Switch Container
        ViewInteraction vedio_end=onView(allOf(withId(R.id.call_window_video_end_call)));
        vedio_end.perform(click());
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    //Dial Pad Via VedioCall Method End

    //Dial Pad Via InternationalCall Method Start
    //Call->FabButton->Contact icon press->Select Number and Call via International Call
    @Test
    public void DialPadKeypadInternationalCall() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction calls_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));
        calls_click.perform(click());

        //Select the fab
        ViewInteraction fab_click=onView(allOf(withId(R.id.fab)));
        fab_click.perform(click());

        //Select the fab
        ViewInteraction keypad_press=onView(allOf(withId(R.id.ivHideDialPad)));
        keypad_press.perform(click());

        //Type something in the keypad
        ViewInteraction keypad_text=onView(allOf(withId(R.id.search_src_text)));
        keypad_text.perform(replaceText(Supplier.getString(R.string.umesh_rn)),closeSoftKeyboard());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject recyleView = mDevice.findObject(new UiSelector()
                .className("androidx.recyclerview.widget.RecyclerView")
                .resourceId("com.reve.base:id/rv"));

        UiObject selectAttribute=recyleView.getChild(new UiSelector()
                .index(1)
        );
        selectAttribute.click();


        try {
            Thread.sleep(9000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Select the App Call

        UiObject press_internationalCall=mDevice.findObject(new UiSelector()
                .index(2)
                .text(Supplier.getString(R.string.calls_international_call))
                .resourceId("android:id/text1"));
        assertEquals(true,press_internationalCall.exists());
        press_internationalCall.click();

        try{
            Thread.sleep(10000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
    //Dial Pad Via InternationalCall Method End


    //DeleteCallItem Method Start
    //Call->FabButton->Contact icon press->Select Number and Call via App Call
    @Test
    public void DeleteCallItem() throws UiObjectNotFoundException, IOException {
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(DIALER_PACKAGE_NAME);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);


        mDevice.wait(Until.hasObject(By.pkg(DIALER_PACKAGE_NAME).depth(0)),
                10000);

        //Select the Contacts menu from the tab view
        ViewInteraction calls_click=onView(allOf(withText(Supplier.getString(R.string.calls_text)),(withId(R.id.tvTabLabel))));
        calls_click.perform(click());

        UiObject delete_item=mDevice.findObject(new UiSelector()
                .className("androidx.recyclerview.widget.RecyclerView")
                .index(0));

        assertEquals(true,delete_item.exists());

        UiObject test2 =delete_item.getChild(new UiSelector()
                .className("android.widget.LinearLayout")
                .index(3));

        assertEquals(true,test2.exists());

        test2.longClick();

//        Rect test=test2.getBounds();
//        uiDevice.swipe(test.centerX(),test.centerX(),test.centerX(),test.centerY(),100);

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction delete=onView(allOf(withText(Supplier.getString(R.string.delete)),withId(R.id.tv)));
        delete.perform(click());





    }
    //DeleteCallItem Method End

}
