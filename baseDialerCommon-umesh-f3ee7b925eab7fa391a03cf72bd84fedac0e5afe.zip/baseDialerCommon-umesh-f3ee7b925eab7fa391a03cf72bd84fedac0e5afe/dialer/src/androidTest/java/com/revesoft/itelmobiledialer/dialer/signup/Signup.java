package com.revesoft.itelmobiledialer.dialer.signup;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Checkable;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.dialer.TestApplication;
import com.revesoft.itelmobiledialer.theme.Theme;
import com.revesoft.material.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.GrantPermissionRule;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.isA;
import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class Signup {
    private static final String COUNTRY_SELECTION_LAYOUT="com.reve.base:id/rlClickConsumer";
    private static final String COUNTRY_SEARCH_EDIT_TEXT="com.reve.base:id/editText_search";
    private static final String SIGNUP_COUNTRY_CODE="com.reve.base:id/signup_country_code";
    private static final String PHONE__NUMBER="com.reve.base:id/signup_phone_number";
    private static final String CONFIRM__BUTTON="com.reve.base:id/confirmButton";
    private static final String FULL_NAME="com.reve.base:id/etName";
    private static final String EMAIL="com.reve.base:id/etEmail";
    private static final String CONFIRM__BUT="com.reve.base:id/bConfirm";
    private static final String PICTURE_UPLOAD="com.reve.base:id/ivProfilePicture";
    private static final String CAMERA_PACKAGE="tools.photo.hd.camera:id/shutter_button";

    private UiDevice uiDevice;

    @Rule
    public GrantPermissionRule mGrantPermissionRule =
            GrantPermissionRule.grant(
                    "android.permission.RECEIVE_SMS",
                    "android.permission.SEND_SMS",
                    "android.permission.READ_CONTACTS",
                    "android.permission.GET_ACCOUNTS",
                    "android.permission.READ_SMS",
                    "android.permission.CALL_PHONE",
                    "android.permission.RECORD_AUDIO",
                    "android.permission.WRITE_EXTERNAL_STORAGE",
                    "android.permission.WRITE_CONTACTS",
                    "android.permission.CAMERA",
                    "android.permission.READ_EXTERNAL_STORAGE",
                    "android.permission.READ_PHONE_STATE");

    //SignUp without SIM card
    @Test
    public void SignUpWithoutSimCard() throws UiObjectNotFoundException,IOException{
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //choose your country region end


        // match the edittext box which exist "Russian Federation" or not
        UiObject country_search=uiDevice.findObject(new UiSelector()
                .resourceId("com.reve.base:id/textView_selectedCountry")
                .text(Supplier.getString(R.string.sign_up_country_name_without_sim)));
        assertEquals(true,country_search.exists());

        UiObject country_code=uiDevice.findObject(new UiSelector()
                .resourceId("com.reve.base:id/signup_country_code")
                .text(Supplier.getString(R.string.sign_up_country_code_without_sim)));
        assertEquals(true,country_code.exists());

    }

    //SignUp with Invalid character
    @Test
    public void SignUpWithInvalidChar() throws UiObjectNotFoundException,IOException{
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //choose your country region start
        UiObject country_selection_layout=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SELECTION_LAYOUT));

        UiObject country_code=uiDevice.findObject(new UiSelector()
                .resourceId(SIGNUP_COUNTRY_CODE));

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        assertEquals(true,country_selection_layout.exists());

        country_selection_layout.click();
        //choose your country region end




        // Select a country region start
        UiObject country_search=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SEARCH_EDIT_TEXT));
        assertEquals(true,country_search.exists());

        country_search.setText(Supplier.getString(R.string.sign_up_country_search));

        UiObject country_denmark=uiDevice.findObject(new UiSelector().text(Supplier.getString(R.string.sign_up_country_name)).className("android.widget.TextView"));

        assertEquals(true,country_denmark.exists());

        country_denmark.click();
        // Select a country region end




        //country code and phone number region start
        assertEquals(Supplier.getString(R.string.sign_up_country_code),country_code.getText());

        UiObject phone_number=uiDevice.findObject(new UiSelector()
                .resourceId(PHONE__NUMBER));
        assertEquals(true,phone_number.exists());
        phone_number.setText(Supplier.getString(R.string.sign_up_invalid_char));
        //country code and phone number region end


        //checkbox value check start

        onView(withId(R.id.checkBox)).perform(setChecked(true));

        //checkbox value check end




        //Confirm button click start
        UiObject confirm_button=uiDevice.findObject(new UiSelector()
                .resourceId(CONFIRM__BUTTON));
        assertEquals(true,confirm_button.exists());
        confirm_button.click();
        //Confirm button click end

    }

    //SignUp with Invalid Number
    @Test
    public void SignUpWithInvalidNumber() throws UiObjectNotFoundException,IOException{
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //choose your country region start
        UiObject country_selection_layout=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SELECTION_LAYOUT));

        UiObject country_code=uiDevice.findObject(new UiSelector()
                .resourceId(SIGNUP_COUNTRY_CODE));

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        assertEquals(true,country_selection_layout.exists());

        country_selection_layout.click();

        //choose your country region end




        // Select a country region start
        UiObject country_search=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SEARCH_EDIT_TEXT));
        assertEquals(true,country_search.exists());

        country_search.setText(Supplier.getString(R.string.sign_up_country_search));

        UiObject country_denmark=uiDevice.findObject(new UiSelector().text(Supplier.getString(R.string.sign_up_country_name)).className("android.widget.TextView"));

        assertEquals(true,country_denmark.exists());

        country_denmark.click();
        // Select a country region end




        //country code and phone number region start
        assertEquals(Supplier.getString(R.string.sign_up_country_code),country_code.getText());

        UiObject phone_number=uiDevice.findObject(new UiSelector()
                .resourceId(PHONE__NUMBER));
        assertEquals(true,phone_number.exists());
        phone_number.setText(Supplier.getString(R.string.sign_up_invalid_phone_number));
        //country code and phone number region end


        //checkbox value check start

        onView(withId(R.id.checkBox)).perform(setChecked(true));

        //checkbox value check end




        //Confirm button click start
        UiObject confirm_button=uiDevice.findObject(new UiSelector()
                .resourceId(CONFIRM__BUTTON));
        assertEquals(true,confirm_button.exists());
        confirm_button.click();
        //Confirm button click end

        //Notification
        UiObject edit=uiDevice.findObject(new UiSelector()
                .resourceId("android:id/button2")
                .text("EDIT")
                .className("android.widget.Button"));
        assertEquals(true,edit.exists());
        edit.click();

        UiObject phone_number_edit=uiDevice.findObject(new UiSelector()
                .resourceId(PHONE__NUMBER));
        assertEquals(true,phone_number.exists());
        phone_number_edit.setText(Supplier.getString(R.string.sign_up_phone_number));

        //Confirm button click start
        UiObject finally_confirm_button=uiDevice.findObject(new UiSelector()
                .resourceId(CONFIRM__BUTTON));
        assertEquals(true,confirm_button.exists());
        finally_confirm_button.click();
        //Confirm button click end

    }

    //SignUp Continue with Invalid data Number
    @Test
    public void SignUpContinueWithInvalidNumber() throws UiObjectNotFoundException,IOException{
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //choose your country region start
        UiObject country_selection_layout=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SELECTION_LAYOUT));

        UiObject country_code=uiDevice.findObject(new UiSelector()
                .resourceId(SIGNUP_COUNTRY_CODE));

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        assertEquals(true,country_selection_layout.exists());

        country_selection_layout.click();

        //choose your country region end




        // Select a country region start
        UiObject country_search=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SEARCH_EDIT_TEXT));
        assertEquals(true,country_search.exists());

        country_search.setText(Supplier.getString(R.string.sign_up_country_search));

        UiObject country_denmark=uiDevice.findObject(new UiSelector().text(Supplier.getString(R.string.sign_up_country_name)).className("android.widget.TextView"));

        assertEquals(true,country_denmark.exists());

        country_denmark.click();
        // Select a country region end




        //country code and phone number region start
        assertEquals(Supplier.getString(R.string.sign_up_country_code),country_code.getText());

        UiObject phone_number=uiDevice.findObject(new UiSelector()
                .resourceId(PHONE__NUMBER));
        assertEquals(true,phone_number.exists());
        phone_number.setText(Supplier.getString(R.string.sign_up_invalid_phone_number));
        //country code and phone number region end


        //checkbox value check start

        onView(withId(R.id.checkBox)).perform(setChecked(true));

        //checkbox value check end




        //Confirm button click start
        UiObject confirm_button=uiDevice.findObject(new UiSelector()
                .resourceId(CONFIRM__BUTTON));
        assertEquals(true,confirm_button.exists());
        confirm_button.click();
        //Confirm button click end

        //Notification
        UiObject edit=uiDevice.findObject(new UiSelector()
                .resourceId("android:id/button1")
                .text("CONTINUE")
                .className("android.widget.Button"));
        assertEquals(true,edit.exists());
        edit.click();

    }

    //SignUp with valid data input
    @Test
    public void SignUpWithValidInfo() throws UiObjectNotFoundException,IOException{
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //choose your country region start
        UiObject country_selection_layout=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SELECTION_LAYOUT));

        UiObject country_code=uiDevice.findObject(new UiSelector()
                .resourceId(SIGNUP_COUNTRY_CODE));

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        assertEquals(true,country_selection_layout.exists());

        country_selection_layout.click();
        //choose your country region end


        // Select a country region start
        UiObject country_search=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SEARCH_EDIT_TEXT));
        assertEquals(true,country_search.exists());

        country_search.setText(Supplier.getString(R.string.sign_up_country_search));

        UiObject country_denmark=uiDevice.findObject(new UiSelector().text(Supplier.getString(R.string.sign_up_country_name)).className("android.widget.TextView"));

        assertEquals(true,country_denmark.exists());

        country_denmark.click();
        // Select a country region end




        //country code and phone number region start
        assertEquals(Supplier.getString(R.string.sign_up_country_code),country_code.getText());

        UiObject phone_number=uiDevice.findObject(new UiSelector()
                .resourceId(PHONE__NUMBER));
        assertEquals(true,phone_number.exists());
        phone_number.setText(Supplier.getString(R.string.sign_up_phone_number));
        //country code and phone number region end


        //checkbox value check start

        onView(withId(R.id.checkBox)).perform(setChecked(true));

        //checkbox value check end


        //Confirm button click start
        UiObject confirm_button=uiDevice.findObject(new UiSelector()
                .resourceId(CONFIRM__BUTTON));
        assertEquals(true,confirm_button.exists());
        confirm_button.click();
        //Confirm button click end


        //Ok & Cancel Button start
        UiObject Ok_Button =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.ok))
                .className("android.widget.Button"));

        UiObject Cancle_Button =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.cancel))
                .className("android.widget.Button"));

        // Simulate a user-click on the OK button, if found.
        if(Ok_Button.exists() && Ok_Button.isEnabled()) {
            Ok_Button.click();
        }
        //Ok & Cancel Button end

        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    //SignUp with Valid data but another phone number //Check the resend SMS
    @Test
    public void SignUpWithValidInfoResendSms() throws UiObjectNotFoundException,IOException{
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //choose your country region start
        UiObject country_selection_layout=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SELECTION_LAYOUT));

        UiObject country_code=uiDevice.findObject(new UiSelector()
                .resourceId(SIGNUP_COUNTRY_CODE));

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        assertEquals(true,country_selection_layout.exists());

        country_selection_layout.click();
        //choose your country region end




        // Select a country region start
        UiObject country_search=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SEARCH_EDIT_TEXT));
        assertEquals(true,country_search.exists());

        country_search.setText(Supplier.getString(R.string.sign_up_country_search));

        UiObject country_denmark=uiDevice.findObject(new UiSelector().text(Supplier.getString(R.string.sign_up_country_name)).className("android.widget.TextView"));

        assertEquals(true,country_denmark.exists());

        country_denmark.click();
        // Select a country region end




        //country code and phone number region start
        assertEquals(Supplier.getString(R.string.sign_up_country_code),country_code.getText());

        UiObject phone_number=uiDevice.findObject(new UiSelector()
                .resourceId(PHONE__NUMBER));
        assertEquals(true,phone_number.exists());
        phone_number.setText(Supplier.getString(R.string.sign_up_phone_number));
        //country code and phone number region end


        //checkbox value check start

        onView(withId(R.id.checkBox)).perform(setChecked(true));

        //checkbox value check end


        //Confirm button click
        UiObject confirm_button=uiDevice.findObject(new UiSelector()
                .resourceId(CONFIRM__BUTTON));
        assertEquals(true,confirm_button.exists());
        confirm_button.click();


        //Ok & Cancel Button
        UiObject Ok_Button =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.ok))
                .className("android.widget.Button"));

        UiObject Cancle_Button =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.cancel))
                .className("android.widget.Button"));

        // Simulate a user-click on the OK button, if found.
        if(Ok_Button.exists() && Ok_Button.isEnabled()) {
            Ok_Button.click();
        }

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject resendSms=uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.sign_up_resend_sms)));
        assertEquals(true,resendSms.exists());
        resendSms.click();

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }



   //Signup and profile info update together
    @Test
    public void SignUpWithEntire() throws UiObjectNotFoundException, IOException {
        uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        uiDevice.pressHome();
        TestApplication.getAccess().lunch();

        //choose your country region start
        UiObject country_selection_layout=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SELECTION_LAYOUT));

        UiObject country_code=uiDevice.findObject(new UiSelector()
                .resourceId(SIGNUP_COUNTRY_CODE));

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        assertEquals(true,country_selection_layout.exists());

        country_selection_layout.click();
        //choose your country region end




       // Select a country region start
        UiObject country_search=uiDevice.findObject(new UiSelector()
                .resourceId(COUNTRY_SEARCH_EDIT_TEXT));
        assertEquals(true,country_search.exists());

        country_search.setText(Supplier.getString(R.string.sign_up_country_search));

        UiObject country_denmark=uiDevice.findObject(new UiSelector().text(Supplier.getString(R.string.sign_up_country_name)).className("android.widget.TextView"));

        assertEquals(true,country_denmark.exists());

        country_denmark.click();
       // Select a country region end




        //country code and phone number region start
        assertEquals(Supplier.getString(R.string.sign_up_country_code),country_code.getText());

        UiObject phone_number=uiDevice.findObject(new UiSelector()
                .resourceId(PHONE__NUMBER));
        assertEquals(true,phone_number.exists());
        phone_number.setText(Supplier.getString(R.string.sign_up_phone_number));
       //country code and phone number region end


        //checkbox value check start

        onView(withId(R.id.checkBox)).perform(setChecked(true));

        //checkbox value check end




       //Confirm button click start
        UiObject confirm_button=uiDevice.findObject(new UiSelector()
                .resourceId(CONFIRM__BUTTON));
        assertEquals(true,confirm_button.exists());
        confirm_button.click();
        //Confirm button click end




        //Ok & Cancel Button start
        UiObject Ok_Button =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.ok))
                .className("android.widget.Button"));

        UiObject Cancle_Button =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.cancel))
                .className("android.widget.Button"));

        // Simulate a user-click on the OK button, if found.
        if(Ok_Button.exists() && Ok_Button.isEnabled()) {
            Ok_Button.click();
        }
        //Ok & Cancel Button end

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Pop up notification for something went wrong start
//        UiObject mText = uiDevice.findObject(new UiSelector()
//                .resourceId("android:id/button3")
//                .text("OK"));
//        mText.click();

        try {
            ViewInteraction buttonOk=  onView(withText(Supplier.getString(R.string.ok))).check(matches(isDisplayed()));
            buttonOk.perform(click());

        } catch (NoMatchingViewException e) {
            //view not displayed logic
        }
        //Pop up notification for something went wrong end


        //Profile info start
        try {
            Thread.sleep(200000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        UiObject Picture_Uploaad=uiDevice.findObject(new UiSelector()
                .resourceId(PICTURE_UPLOAD));
        assertEquals(true,Picture_Uploaad.exists());
        Picture_Uploaad.click();


        UiObject TakePhoto =uiDevice.findObject(new UiSelector()
                .text(Supplier.getString(R.string.take_new_photo))
                .className("android.widget.TextView"));
        if(TakePhoto.exists() && TakePhoto.isEnabled()) {
            TakePhoto.click();
        }

        //clicking camera for picture

        uiDevice.findObject(new UiSelector().resourceId(CAMERA_PACKAGE)).click();
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject photoSelectFinal =uiDevice.findObject(new UiSelector()
                .resourceId("tools.photo.hd.camera:id/btn_done")
                .className("android.widget.ImageView"));

        if(photoSelectFinal.exists() && photoSelectFinal.isEnabled()) {
            photoSelectFinal.click();
        }
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiObject photoSave =uiDevice.findObject(new UiSelector()
                .resourceId("com.reve.base:id/crop_image_menu_crop")
                .className("android.widget.TextView"));

        if(photoSave.exists() && photoSave.isEnabled()) {
            photoSave.click();
        }
        
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiScrollable Full_Name = new UiScrollable(new UiSelector()
                .resourceId(FULL_NAME)
                .className("android.widget.EditText"));
        assertEquals(true,Full_Name.exists());
        Full_Name.setText(Supplier.getString(R.string.ProfileInfoUpdate_full_name));

        UiScrollable email = new UiScrollable(new UiSelector()
                .resourceId(EMAIL)
                .className("android.widget.EditText"));
        assertEquals(true,email.exists());
        email.setText(Supplier.getString(R.string.ProfileInfoUpdate_email));

        UiScrollable confirm_but = new UiScrollable(new UiSelector()
                .resourceId(CONFIRM__BUT)
                .className("android.widget.Button"));
        assertEquals(true,confirm_but.exists());
        confirm_but.click();
        try {
            Thread.sleep(50000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Profile info end
    }
    //SignUp method end



    //checkbox matcher method start
    public static ViewAction setChecked(final boolean checked) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return new Matcher<View>() {
                    @Override
                    public boolean matches(Object item) {
                        return isA(Checkable.class).matches(item);
                    }

                    @Override
                    public void describeMismatch(Object item, Description mismatchDescription) {}

                    @Override
                    public void _dont_implement_Matcher___instead_extend_BaseMatcher_() {}

                    @Override
                    public void describeTo(Description description) {}
                };
            }

            @Override
            public String getDescription() {
                return null;
            }

            @Override
            public void perform(UiController uiController, View view) {
                Checkable checkableView = (Checkable) view;
                checkableView.setChecked(checked);
            }
        };
    }
    //checkbox method end

}
