package com.revesoft.itelmobiledialer.chat.tenor.tools.loaders;

import android.graphics.drawable.Drawable;

import android.widget.ImageView;

import com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces.IDrawableLoaderTaskListener;
import com.revesoft.itelmobiledialer.chat.tenor.tools.util.WeakRefObject;

import java.lang.ref.WeakReference;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public abstract class WeakRefContentLoaderTaskListener<CTX, T extends ImageView>
        extends WeakRefObject<CTX>
        implements IDrawableLoaderTaskListener<T, Drawable> {

    public WeakRefContentLoaderTaskListener(@NonNull CTX ctx) {
        super(ctx);
    }

    public WeakRefContentLoaderTaskListener(@NonNull WeakReference<CTX> weakRef) {
        super(weakRef);
    }

    @Override
    public void success(@NonNull T target, @NonNull Drawable taskResult) {
        if (hasRef()) {
            //noinspection ConstantConditions
            success(getRef(), target, taskResult);
        }
    }

    @Override
    public void failure(@NonNull T target, @NonNull Drawable errorResult) {
        if (hasRef()) {
            //noinspection ConstantConditions
            failure(getRef(), target, errorResult);
        }
    }

    public abstract void success(@NonNull CTX ctx, @NonNull T target, @Nullable Drawable taskResult);

    public abstract void failure(@NonNull CTX ctx, @NonNull T target, @Nullable Drawable errorResult);
}
