package com.revesoft.itelmobiledialer.ims;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;


public class ImageGalleryFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {


    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private ImageGalleryAdapter mAdapter;
    private OnFragmentInteractionListener mListener;
    private TextView mNoImageFoundTextView;
    private static final String TAG = "Mkhan";

    private RelativeLayout contentView;
    private RelativeLayout askPermissionView;

    private static final String IMAGE_WIDTH = "image_width";
    private static final String IMAGE_HEIGHT = "image_height";

    private int imageViewWidth;
    private int imageViewHeight;

    private static Fragment fragment;

    public static Fragment getInstance(int imageWidth, int imageHeight) {
        if (fragment == null) {
            fragment = new ImageGalleryFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putInt(IMAGE_WIDTH, imageWidth);
        bundle.putInt(IMAGE_HEIGHT, imageHeight);
        fragment.setArguments(bundle);
        return fragment;
    }

    public ImageGalleryFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            imageViewWidth = getArguments().getInt(IMAGE_WIDTH);
            imageViewHeight = getArguments().getInt(IMAGE_HEIGHT);
            if (imageViewWidth == 0 || imageViewHeight == 0) {
                imageViewWidth = 400;
                imageViewHeight = 400;
            }
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.fragment_gallery, container, false);

        mRecyclerView = layout.findViewById(R.id.gallery_recycler_view);
        mLayoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new ImageGalleryAdapter(imageViewHeight/2, imageViewHeight/2);

        contentView = layout.findViewById(R.id.main_content);
        askPermissionView = layout.findViewById(R.id.ask_permission_view);
        Button askPermissionButton = layout.findViewById(R.id.accept_button);

        askPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforGallery(getActivity()).length > 0) {
                    Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
                    requestPermissions(PermissionUtil.getPermissionsforGallery(getActivity()), OnFragmentInteractionListener.TYPE_LOCATION);
                }
            }
        });

        mRecyclerView.setAdapter(mAdapter);

        mNoImageFoundTextView = layout.findViewById(R.id.textViewNoImage);

        return layout;
    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private void onImageSend(String imageFilePath) {
        mListener.onFragmentInteraction(OnFragmentInteractionListener.TYPE_GALLERY_IMAGE, imageFilePath);
    }

    private void onMultipleImageSend(Cursor cursor, boolean [] selectedList) {
        ArrayList <String> paths = new ArrayList<>();
        for (int i = 0; i < selectedList.length && cursor != null && !cursor.isClosed(); i++){
            if(selectedList[i] && cursor.moveToPosition(i)){
                paths.add(cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA)));
            }
        }
        mListener.onFragmentInteraction(OnFragmentInteractionListener.TYPE_GALLERY_IMAGE, paths);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri queryUri = MediaStore.Files.getContentUri("external");

        String[] projection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.PARENT,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.TITLE,
                MediaStore.Files.FileColumns.SIZE
        };

        String selection = "("+MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                +") AND ("
                + MediaStore.Files.FileColumns.SIZE + " > 0 )";


        return new CursorLoader(
                getActivity(),
                queryUri,
                projection,
                selection,
                null,
                MediaStore.Files.FileColumns.DATE_ADDED + " DESC"
        );
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        Log.d(TAG, "Cursor size for gallery " + data.getCount());
        if (data.getCount() > 0) {
            Log.d(TAG, "Set recycle view as visible");
            mRecyclerView.setVisibility(View.VISIBLE);
            mNoImageFoundTextView.setVisibility(View.GONE);
        }
        if(data.getCount() > 0)
        {
            data.moveToFirst();
            while(data.moveToNext())
            {
               Log.d("GalleryFragment",data.getString(data.getColumnIndex(MediaStore.Files.FileColumns.PARENT)) +" " +
                       data.getString(data.getColumnIndex(MediaStore.Files.FileColumns.DATA)) +" " +
                       data.getInt(data.getColumnIndex(MediaStore.Files.FileColumns._ID)) +" "
               );
            }
        }

        mAdapter.swapCursor(data);

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
    }


    public class ImageGalleryAdapter extends RecyclerView.Adapter<ImageGalleryAdapter.ViewHolder> {
        private Cursor mCursor;
        private int imageWidth;
        private int imageHeight;

        boolean [] selected = new boolean[1];

        public ImageGalleryAdapter(int imageWidth, int imageHeight) {

            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // initialize a new view
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_gallery_item, parent, false);

            ViewHolder vh = new ViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {

            mCursor.moveToPosition(position);
            try {
//                Log.d(TAG, "Image data " + mCursor.getString(mCursor.getColumnIndex(MediaStore.Images.Media.DATA)));
                holder.mImageFilepath=mCursor.getString(mCursor.getColumnIndex(MediaStore.Files.FileColumns.DATA));
                int mediaType=mCursor.getInt(mCursor.getColumnIndex(MediaStore.Files.FileColumns.MEDIA_TYPE));

                if(mediaType==MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) {
                    holder.mVideoIconOverlay.setVisibility(View.VISIBLE);
                }else {
                    holder.mVideoIconOverlay.setVisibility(View.GONE);
                }
                Glide.with(getContext())
                        .load(holder.mImageFilepath)
                        .centerCrop()
                        .crossFade()
                        .error(R.drawable.invalid_image_file)
                        .into(holder.mImageView);

                if (selected[position]) {
                    Log.d(TAG, "Selected item position in onBindViewHolder " + position);
                    holder.mImageSend.setVisibility(View.VISIBLE);
                    holder.mSelectedBackground.setVisibility(View.VISIBLE);
                }else {
                    holder.mImageSend.setVisibility(View.GONE);
                    holder.mSelectedBackground.setVisibility(View.GONE);
                }


            } catch (Exception e) {

                Log.e(TAG, "Exception with glide " + e.getMessage());
            }


        }

        @Override
        public int getItemCount() {

            if (mCursor != null) {
                return mCursor.getCount();
            }
            return 0;
        }

        public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            // each data item is just a string in this case

            public ImageView mImageView;
            public ImageView mImageSend;
            public View mSelectedBackground;
            public String mImageFilepath;
            public ImageView mVideoIconOverlay;

            public ViewHolder(View v) {
                super(v);

                mImageView = v.findViewById(R.id.imageViewItem);
                mImageSend = v.findViewById(R.id.imageButtonImageSend);
                mSelectedBackground=v.findViewById(R.id.imageItemBackground);
                mVideoIconOverlay = v.findViewById(R.id.video_icon_overlay);
                ViewGroup.LayoutParams layoutParams=mSelectedBackground.getLayoutParams();
                layoutParams.height=imageHeight;
                layoutParams.width=imageWidth;
                mSelectedBackground.setLayoutParams(layoutParams);

                mImageSend.setOnClickListener(this);
                LinearLayout.LayoutParams ImageLayoutParams=new LinearLayout.LayoutParams(imageWidth,imageHeight);
                mImageView.setLayoutParams(ImageLayoutParams);
                mImageView.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {

                switch (view.getId()) {
                    case R.id.imageViewItem:
                        selected[getAdapterPosition()] ^= true;
                        Log.d(TAG, "Selected item position " + getAdapterPosition());
                        notifyDataSetChanged();
                        onMultipleImageSend(mCursor, selected);
                        break;
//                    case R.id.imageButtonImageSend:
//                        Log.d(TAG,"Image send button clicked");
//                        onImageSend(this.mImageFilepath);
//                        break;
                    default:
                        break;
                }
            }
        }

        public void swapCursor(Cursor cursor) {
            mCursor = cursor;
            if(cursor != null)
                selected = new boolean[cursor.getCount()];
            notifyDataSetChanged();
        }

        public void clearSelection(){
            if(selected != null){
                for(int i = 0; i < selected.length; i++){
                    selected[0] = false;
                }
            }
            notifyDataSetChanged();
        }
    }

    public void clearSelection(){
        if(mAdapter != null)
            mAdapter.clearSelection();
    }

//    @Override
//    public void setUserVisibleHint(boolean isVisibleToUser) {
//        super.setUserVisibleHint(isVisibleToUser);
//
//        // Make sure that we are currently visible
//        if (this.isVisible()) {
//            // If we are becoming invisible, then...
//            if (!isVisibleToUser) {
//                Log.d("ImageGalleryFragment", "Not visible anymore. clearing selection");
//                mAdapter.clearSelection();
//                onMultipleImageSend(null, new boolean[0]);
//            }
//        }
//    }

    public void onFragmentReload() {
        mAdapter.clearSelection();
        onMultipleImageSend(null, new boolean[0]);
        getLoaderManager().restartLoader(0, null, this);
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        // Make sure that we are currently visible
        if (this.isVisible()) {
            // If we are becoming invisible, then...
            if (!isVisibleToUser) {
                Log.d("ImageGalleryFragment", "Not visible anymore. clearing selection");
                mAdapter.clearSelection();
                onMultipleImageSend(null, new boolean[0]);
                getLoaderManager().restartLoader(0, null, this);
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforGallery(getActivity()).length > 0) {
            contentView.setVisibility(View.GONE);
            askPermissionView.setVisibility(View.VISIBLE);
        } else {
            contentView.setVisibility(View.VISIBLE);
            askPermissionView.setVisibility(View.GONE);
            getLoaderManager().initLoader(0, null, this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == OnFragmentInteractionListener.TYPE_LOCATION) {
            Log.i("StartupPermissions", "Received response for required permissions makeRequest.");
            if (PermissionUtil.verifyPermissions(grantResults)) {
                Log.i("StartupPermissions", "ALL required permissions have been granted, starting DialerService.");
                contentView.setVisibility(View.VISIBLE);
                askPermissionView.setVisibility(View.GONE);
                getLoaderManager().initLoader(0, null, this);
            } else {
                Log.i("StartupPermissions", "Permissions were NOT granted. Showing exit dialog");
                contentView.setVisibility(View.GONE);
                askPermissionView.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 23)
                    showExitOrGrantPermissionAlert();
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void showExitOrGrantPermissionAlert() {
        try {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage("You did not grant required permissions. You can grant them from application settings.");
            bld.setNegativeButton("Cancel", null);
            bld.setPositiveButton("App settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getActivity().getPackageName(), null));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    dialog.dismiss();
                }
            });
            bld.setCancelable(false);
            bld.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
