package com.revesoft.itelmobiledialer.fileAndMediaUtil;

import android.media.MediaMetadataRetriever;

import java.io.File;
import java.util.Locale;

/**
 * @author Ifta on 6/11/2017.
 */

public class MediaUtils {
    public static String getFileSizeInMB(String filePath) {
        File file = new File(filePath);
        long sizeInBytes = file.length();
        double sizeInMB = sizeInBytes / (1000000f);
        return String.format(new Locale("en","US"),"%.2f",sizeInMB)+" MB";
    }
    public static String getDuration(String filePath) {
        MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
        try {
            metaRetriever.setDataSource(filePath);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return "00:00";
        }

        String out;

        String duration = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        long dur = Long.parseLong(duration);
        int sec = (int) (dur % 60000) / 1000;
        int min = (int) dur / 60000;
        String seconds = (sec < 10) ? ("0" + sec) : ("" + sec);
        out = min + ":" + seconds;
        metaRetriever.release();
        return out;
    }
    public static int getDurationInMill(String filePath) {
        MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
        try {
            metaRetriever.setDataSource(filePath);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return 0;
        }
        String duration = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        int result = 0;
        try {
             result = Integer.parseInt(duration);
        }catch (Exception e){
            e.printStackTrace();
        }
        metaRetriever.release();
        return result;
    }
}
