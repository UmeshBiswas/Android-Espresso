package com.revesoft.itelmobiledialer.contact;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.revesoft.itelmobiledialer.contact.list.ContactListFragment;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

/**
 * @author Ifta on 8/30/2017.
 */

public class FavoriteContactsActivity extends BaseActivity {
    Toolbar toolbar;
    Fragment favoriteContactFragment;

    public static void start(Context context) {
        Intent intent = new Intent(context, FavoriteContactsActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocked_contact_activity_layout);
        handleToolbar();
        favoriteContactFragment = ContactListFragment.newInstance(false, ContactType.FAVORITE);
        getSupportFragmentManager().beginTransaction().add(R.id.blockedContactHolder, favoriteContactFragment).commit();
    }

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(getString(R.string.favorite));
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return false;
    }
}
