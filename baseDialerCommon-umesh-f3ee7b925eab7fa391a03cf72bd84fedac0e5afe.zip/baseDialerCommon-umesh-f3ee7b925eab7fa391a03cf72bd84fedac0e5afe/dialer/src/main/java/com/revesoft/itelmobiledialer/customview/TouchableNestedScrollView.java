package com.revesoft.itelmobiledialer.customview;

import android.content.Context;

import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.widget.NestedScrollView;

/**
 * @author Ifta on 2/6/2018.
 */

public class TouchableNestedScrollView extends NestedScrollView {
    //public boolean onInterceptState = false;

    public TouchableNestedScrollView(Context context) {
        super(context);
    }

    public TouchableNestedScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public TouchableNestedScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean performClick() {
        return false;
    }

    @Override
    public boolean performLongClick() {
        return false;
    }

    @Override
    public void onNestedScroll(View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
        super.onNestedScroll(target, dxConsumed, dyUnconsumed, dyConsumed, dyUnconsumed);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
       /*if(this.onInterceptState==false) {
           return true;
       }
       else if(this.onInterceptState==true){
           return false;
       }*/
       return true;
    }

}
