/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:25 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:25 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "subscribed_packages")
public class SubscribedPackage {
    @NonNull
    @PrimaryKey(autoGenerate = true)
    public int _id;

    @ColumnInfo(name = "package_id")
    public String packageId;

    @ColumnInfo(name = "package_name")
    public String packageName;

    @ColumnInfo(name = "package_value")
    public String packageValue;

    @ColumnInfo(name = "package_activation_time")
    public String packageActivationTime;

    @ColumnInfo(name = "package_deactivation_time")
    public String packageDeactivationTime;

    @ColumnInfo(name = "group_id")
    public String groupId;

    @ColumnInfo(name = "thumbnail")
    public String thumbnail;

    @ColumnInfo(name = "valid_till")
    public String validTill;

    @ColumnInfo(name = "subtitle")
    public String subtitle;

    @ColumnInfo(name = "unused_balance")
    public String unusedBalance;

    @ColumnInfo(name = "available_minutes")
    public String availableMinutes;

    @ColumnInfo(name = "package_type")
    public String packageType;

    @ColumnInfo(name = "unused_minutes")
    public String unusedMinutes;

    public SubscribedPackage() {
    }

    private SubscribedPackage(Builder builder) {
        _id = builder._id;
        packageId = builder.packageId;
        packageName = builder.packageName;
        packageValue = builder.packageValue;
        packageActivationTime = builder.packageActivationTime;
        packageDeactivationTime = builder.packageDeactivationTime;
        groupId = builder.groupId;
        thumbnail = builder.thumbnail;
        validTill = builder.validTill;
        subtitle = builder.subtitle;
        unusedBalance = builder.unusedBalance;
        availableMinutes = builder.availableMinutes;
        packageType = builder.packageType;
        unusedMinutes = builder.unusedMinutes;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private int _id;
        private String packageId;
        private String packageName;
        private String packageValue;
        private String packageActivationTime;
        private String packageDeactivationTime;
        private String groupId;
        private String thumbnail;
        private String validTill;
        private String subtitle;
        private String unusedBalance;
        private String availableMinutes;
        private String packageType;
        private String unusedMinutes;

        private Builder() {
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withPackageId(String val) {
            packageId = val;
            return this;
        }

        public Builder withPackageName(String val) {
            packageName = val;
            return this;
        }

        public Builder withPackageValue(String val) {
            packageValue = val;
            return this;
        }

        public Builder withPackageActivationTime(String val) {
            packageActivationTime = val;
            return this;
        }

        public Builder withPackageDeactivationTime(String val) {
            packageDeactivationTime = val;
            return this;
        }

        public Builder withGroupId(String val) {
            groupId = val;
            return this;
        }

        public Builder withThumbnail(String val) {
            thumbnail = val;
            return this;
        }

        public Builder withValidTill(String val) {
            validTill = val;
            return this;
        }

        public Builder withSubtitle(String val) {
            subtitle = val;
            return this;
        }

        public Builder withUnusedBalance(String val) {
            unusedBalance = val;
            return this;
        }

        public Builder withAvailableMinutes(String val) {
            availableMinutes = val;
            return this;
        }

        public Builder withPackageType(String val) {
            packageType = val;
            return this;
        }

        public Builder withUnusedMinutes(String val) {
            unusedMinutes = val;
            return this;
        }

        public SubscribedPackage build() {
            return new SubscribedPackage(this);
        }
    }
}
