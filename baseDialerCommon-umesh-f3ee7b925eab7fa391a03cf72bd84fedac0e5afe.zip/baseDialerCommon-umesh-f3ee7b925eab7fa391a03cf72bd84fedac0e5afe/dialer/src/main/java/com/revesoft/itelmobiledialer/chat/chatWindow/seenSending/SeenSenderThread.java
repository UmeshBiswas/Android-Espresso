package com.revesoft.itelmobiledialer.chat.chatWindow.seenSending;

import android.content.Intent;
import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.braodcast.QuickBroadCaster;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TaggedLogger;

import java.util.HashSet;

/**
 * @author Ifta on 10/19/2017.
 */

public class SeenSenderThread extends Thread {
    private static final TaggedLogger logger = new TaggedLogger("SeenSenderThread");
    private volatile HashSet<String> processedCallIds = new HashSet<>();
    private boolean running;
    private final SetBlockingQueue<String> unseenCallIDs = new SetBlockingQueue<>(3000);
    private final String target;
    private final boolean isGroupChat;

    public SeenSenderThread(String target, boolean isGroupChat) {
        unseenCallIDs.clear();
        this.target = target;
        this.isGroupChat = isGroupChat;
        running = true;
        start();
    }

//    public void feed(HashSet<String> callIdsForUnseenMessages){
//        unseenCallIDs.addAll(callIdsForUnseenMessages);
//    }
    public void feed(String callId){
        if(!TextUtils.isEmpty(callId)) {
            Executor.ex(() -> {
                if (MessageRepo.get().getMessageByCallId(callId).messageType == MessageEntry.MessageType.RECEIVED) {
                    unseenCallIDs.add(callId);
                }
            });

        }
    }

    @Override
    public void run() {
        while (running) {
            try {
                String callID = unseenCallIDs.take();
//                if(!processedCallIds.contains(callID)) {
                    processedCallIds.add(callID);
                    logger.log("sending " + callID);
                    Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
                    intent.putExtra("seen", target);
                    intent.putExtra("callID", callID);
                    intent.putExtra("isGroup", isGroupChat);
                    QuickBroadCaster.broadcast(intent);
//                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void finish() {
        running = false;
        interrupt();
    }
}
