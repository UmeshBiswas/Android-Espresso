package com.revesoft.itelmobiledialer.appDatabase.entities;


import org.jetbrains.annotations.NotNull;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "persistent")
public class Persistent {


    @NotNull
    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "id")
    public String key;

    @ColumnInfo(name = "value")
    public String value;


    public Persistent(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
