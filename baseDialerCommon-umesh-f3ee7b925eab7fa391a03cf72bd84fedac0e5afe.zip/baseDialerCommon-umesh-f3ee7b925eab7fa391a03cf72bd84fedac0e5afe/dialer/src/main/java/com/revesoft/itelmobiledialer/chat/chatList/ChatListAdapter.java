package com.revesoft.itelmobiledialer.chat.chatList;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatConstants;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsHelper;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListAdapter;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListItem;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.eventlistener.DialerListener;
import com.revesoft.itelmobiledialer.eventlistener.EventData;
import com.revesoft.itelmobiledialer.eventlistener.MuteOrUnMuteEventData;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ChatListSingleItemBinding;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.databinding.DataBindingUtil;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import static com.revesoft.itelmobiledialer.arch.Supplier.getResources;
import static com.revesoft.itelmobiledialer.arch.Supplier.getString;
import static com.revesoft.itelmobiledialer.eventlistener.DialerEvent.MuteOrUnMuteChangeEvent;

public class ChatListAdapter extends PagedListAdapter<ChatListItem, ChatListAdapter.ViewHolder> implements DialerListener {
    private Context context;
    String TAG="ChatListAdapter : ";

    ChatListAdapter(Context context) {
        super(callback);
        this.context = context;
        register();
    }




    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ChatListSingleItemBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.chat_list_single_item, parent, false);
        return new ViewHolder(binding);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatListItem item = getItem(position);
        if (item != null) {
            holder.binding.setChatListItem(item);
            if (PreferenceDataManager.quickGet(item.getNumberOrGroupId() + AccountPreference.Keys.RING_MUTE_STATUS, (long) -1) != -1) {
                holder.binding.tvTime.setCompoundDrawablesWithIntrinsicBounds(0,0,R.drawable.ic_notifications_off,0);
            }
            else  holder.binding.tvTime .setCompoundDrawables(null,null,null,null);
            ImageUtil.setImage(holder.binding.ivProfileImage, item.getImageUrl(), item.getName());
            ItemClickListener itemClickListener=new ItemClickListener(item);
            holder.binding.mainContent.setOnClickListener(itemClickListener);
            holder.binding.ivProfileImage.setOnClickListener(itemClickListener);
            holder.binding.getRoot().setOnLongClickListener(v -> {
                handleLongPressOptions(item,position);
                return true;
            });
        } else {
            holder.binding.invalidateAll();
        }
    }

    private void handleLongPressOptions(ChatListItem item,int pos) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        ArrayList<ImageListItem> itemsList = new ArrayList<>(3);
        itemsList.add(new ImageListItem(getString(R.string.add_chat_short_cut), R.drawable.ic_add_shortcut));
        itemsList.add(new ImageListItem(getString(R.string.delete), R.drawable.ic_call_log_delete));
        if (PreferenceDataManager.quickGet(item.getNumberOrGroupId() + AccountPreference.Keys.RING_MUTE_STATUS, (long) -1) != -1) {
            itemsList.add(new ImageListItem(getString(R.string.unmute), R.drawable.ic_notifications_active));
        }
        else itemsList.add(new ImageListItem(getString(R.string.mute), R.drawable.ic_notifications_off));
        ImageListAdapter imageListAdapter = new ImageListAdapter(context, itemsList, false);
        builder.setAdapter(imageListAdapter, (dialog, which) -> {
            switch (which) {
                case 0:
                    handleAddShortCutOption(item);
                    break;
                case 1:
                    deleteChatLog(item);
                    break;
                case 2:

                    ContactDetailsHelper.getAccess().muteOrUnMuteChat((Activity) context, item.getNumberOrGroupId(), ChatListAdapter.this, pos);
            }
            dialog.dismiss();
        });
        builder.create().show();

    }






    private void deleteChatLog(ChatListItem item) {
        if (item.isGroup())
            Executor.ex(() -> MessageRepo.get().deleteMessageByGroupId(item.getNumberOrGroupId()));
        else Executor.ex(() -> MessageRepo.get().deleteMessageByNumber(item.getNumberOrGroupId()));
    }


    private void handleAddShortCutOption(ChatListItem item){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(getString(R.string.areYouSure));
        builder.setMessage(getString(R.string.sureInstallShortCut));
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                makeShortcutIconForGroupChat(item);
                dialog.dismiss();
            }
        });
        builder.setNegativeButton(getString(R.string.neverMind), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }





    private void makeShortcutIconForGroupChat(ChatListItem item) {
            try {
                String chatId = item.getCallerId();
                Intent shortcutIntent = getShortCutIntent(context, item.isGroup()?"":item.getNumberOrGroupId(),
                        item.isGroup()?item.getNumberOrGroupId():"",false,false,false,null);
                Intent addIntent = new Intent();
                addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
                String shortCutName=item.getName();
                if (TextUtils.isEmpty(shortCutName)) {
                    shortCutName = getString(R.string.groupMessage);
                }
                if (shortCutName.length() > 20) {
                    shortCutName = shortCutName.substring(0, 16) + "...";
                }
                addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, shortCutName);
                addIntent.putExtra("duplicate", false);
                Bitmap shortCutIcon = null;
                String imageUri = item.getImageUrl();
                if (imageUri != null) {
                    shortCutIcon = BitmapFactory.decodeFile(imageUri);
                }
                if (shortCutIcon == null) {
                    if(item.isGroup()) {
                        shortCutIcon = BitmapFactory.decodeResource(getResources(), R.drawable.group_details_group_image);
                    }
                    else{
                        shortCutIcon = ImageUtil.getBitmapFromVectorDrawable(context,R.drawable.person);
                    }
                }
                shortCutIcon = ImageUtil.getShortCutImage(getResources(), shortCutIcon);
                addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON, shortCutIcon);
                I.log("ShortCut : " + shortCutName + " " + chatId + " " + imageUri);
                addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
                context.getApplicationContext().sendBroadcast(addIntent);
                Toast.makeText(context,"Shortcut created",Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                e.printStackTrace();
                I.log(e.getLocalizedMessage());
            }

    }



    public static Intent getShortCutIntent(Context context, String number, String groupId, boolean isSMSChat,
                             boolean isBroadCast, boolean isEncrypted, String ocid) {
        Intent starter = new Intent(context, ChatWindowActivity.class);
        starter.putExtra(ChatConstants.KEY_NUMBER, number);
        starter.putExtra(ChatConstants.KEY_GROUP_ID, groupId);
        starter.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
        starter.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadCast);
        starter.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
        starter.putExtra(ChatConstants.KEY_OCID_ID, ocid);
        return starter;
    }

    @Override
    public void register() {
        DialerEventHock.getInstance().addListener(this);
    }

    @Override
    public void performOnEvent(DialerEvent event, EventData eventData) {
        if(event==MuteOrUnMuteChangeEvent){
            MuteOrUnMuteEventData muteOrUnMuteEventData= (MuteOrUnMuteEventData) eventData;
            for(int i=0;i<getItemCount();i++){
                if(getItem(i).getNumberOrGroupId().equals(muteOrUnMuteEventData.getKeyNumber())) {
                    notifyItemChanged(i);
                    break;
                }
            }
        }

    }


    class ViewHolder extends RecyclerView.ViewHolder {
        ChatListSingleItemBinding binding;

        public ViewHolder(@NonNull ChatListSingleItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private static final DiffUtil.ItemCallback<ChatListItem> callback = new DiffUtil.ItemCallback<ChatListItem>() {
        @Override
        public boolean areItemsTheSame(@NonNull ChatListItem oldItem, @NonNull ChatListItem newItem) {
            return oldItem.getCallerId().equals(newItem.getCallerId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull ChatListItem oldItem, @NonNull ChatListItem newItem) {
            return oldItem.getLastMessage().equals(newItem.getLastMessage())
                    && oldItem.getLastMessageStatus() == newItem.getLastMessageStatus()
                    && oldItem.getNumberOrGroupId().equals(newItem.getNumberOrGroupId())
                    && oldItem.getUnseenMessageCount().equals(newItem.getUnseenMessageCount());
        }
    };





    class ItemClickListener implements View.OnClickListener{
        ChatListItem item;

        public ItemClickListener(ChatListItem item) {
            this.item = item;
        }

        @Override
        public void onClick(View v) {
            if(v.getId()==R.id.ivProfileImage){
                Switcher.switchToContactDetails(context,item.getNumberOrGroupId());

            }
            else if(v.getId()==R.id.mainContent){
                ChatWindowActivity.start(context, item.isGroup()?"":item.getNumberOrGroupId(),
                        item.isGroup()?item.getNumberOrGroupId():"",false,false,false,null);
            }

        }
    }


}
