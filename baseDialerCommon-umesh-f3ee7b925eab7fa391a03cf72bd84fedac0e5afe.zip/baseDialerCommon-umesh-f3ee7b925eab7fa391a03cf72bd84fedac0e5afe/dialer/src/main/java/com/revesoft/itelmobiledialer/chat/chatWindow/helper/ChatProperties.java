package com.revesoft.itelmobiledialer.chat.chatWindow.helper;

import android.content.Context;

import com.revesoft.itelmobiledialer.util.TaggedLogger;

/**
 * @author Ifta on 1/4/2018.
 */

public class ChatProperties {
    public static boolean isGroupChat;
    public static boolean isEncryptedChat;
    public static boolean isSMSChat;
    public static int groupType;
    private static boolean isPrepared = false;

    private static Context chatWindowContext;
    static TaggedLogger logger;

    public static void setUpChatProperties(boolean isGroupChat, boolean isEncryptedChat, boolean isSMSChat, int groupType) {
        ChatProperties.isGroupChat = isGroupChat;
        ChatProperties.isEncryptedChat = isEncryptedChat;
        ChatProperties.isSMSChat = isSMSChat;
        ChatProperties.groupType = groupType;
        isPrepared = true;
        logger = new TaggedLogger("ChatProperties");
    }

    public static void start() {
        isPrepared = true;
    }

    public static void destroy() {
        setChatWindowContext(null);
        isPrepared = false;
    }

    public static boolean isActive(String from, String groupId, int e2e) {
        boolean windowChat;
        if (e2e == 1 && !isEncryptedChat) {
            windowChat = false;
        } else if (e2e == 0 && isEncryptedChat) {
            windowChat = false;
        } else {
            windowChat = true;
        }

        return isPrepared && (isGroupChat ? Target.target.equals(groupId) : Target.target.equals(from)) && windowChat; //(isEncryptedChat?e2e==1:e2e==0);
    }

    public static Context getChatWindowContext() {
        return chatWindowContext;
    }

    public static void setChatWindowContext(Context context) {
        chatWindowContext = context;
    }
}
