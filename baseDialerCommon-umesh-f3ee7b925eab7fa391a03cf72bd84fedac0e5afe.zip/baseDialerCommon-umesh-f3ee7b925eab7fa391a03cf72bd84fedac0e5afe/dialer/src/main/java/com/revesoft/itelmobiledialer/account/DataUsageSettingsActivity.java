package com.revesoft.itelmobiledialer.account;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import android.widget.CompoundButton;

import com.revesoft.itelmobiledialer.account.extras.DataUsageRestrictedFileLoadType;
import com.revesoft.itelmobiledialer.braodcast.QuickBroadCaster;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

/**
 * @author Ifta
 *         on 5/22/2017.
 */

public class DataUsageSettingsActivity extends BaseActivity {
    Context context;
    Toolbar toolbar;
    SwitchCompat sMobileData, sWifiData;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_usages_settings_layout);
        context = this;
        sMobileData = (SwitchCompat) findViewById(R.id.sMobileData);
        sWifiData = (SwitchCompat) findViewById(R.id.sWifiData);
        sMobileData.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AccountPreference.put(AccountPreference.Keys.MEDIA_ON_MOBILE_DATA, isChecked);
            Intent intent = new Intent(Constants.DATA_USAGE_SETTINGS_CHANGED_INTENT_FILTER);
            intent.putExtra("loading_type", DataUsageRestrictedFileLoadType.LOAD_ALL);
            QuickBroadCaster.broadcast(intent);
        });
        sWifiData.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AccountPreference.put(AccountPreference.Keys.MEDIA_ON_WIFI_DATA, isChecked);
            Intent intent = new Intent(Constants.DATA_USAGE_SETTINGS_CHANGED_INTENT_FILTER);
            intent.putExtra("loading_type", DataUsageRestrictedFileLoadType.LOAD_ALL);
            QuickBroadCaster.broadcast(intent);
        });
        handleToolbar();
        updateViewData();
    }

    private void updateViewData() {
        boolean isDownloadOnMobileDataSetOn = AccountPreference.getBoolean(AccountPreference.Keys.MEDIA_ON_MOBILE_DATA);
        boolean isDownloadOnWifiSetOn = AccountPreference.getBoolean(AccountPreference.Keys.MEDIA_ON_WIFI_DATA);
        sMobileData.setChecked(isDownloadOnMobileDataSetOn);
        sWifiData.setChecked(isDownloadOnWifiSetOn);
    }

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(getString(R.string.dataUsage));
        }
    }
}
