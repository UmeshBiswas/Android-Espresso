package com.revesoft.itelmobiledialer.dialogues;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;

import com.revesoft.material.R;

/**
 * @author Ifta
 *         on 3/12/2017.
 */

public class DialogActivity extends Activity {
    public static final String KEY_DIALOG_TYPE = "KEY_DIALOG_TYPE";
    public static final String KEY_DIALOG_MESSAGE = "KEY_DIALOG_MESSAGE";

    public enum DialogType {
        FORBIDDEN, TIME_OUT, BUSY,
        NO_INTERNET, CALL_LIMIT_EXCEED,
        ERROR_REASON, INVALID_NUMBER,
        INSUFFICIENT_BALANCE, SERVICE_UNAVAILABLE,
        DESTINATION_NOT_ALLOWED, RATE_APP, REGISTRATION_NOT_ALLOWED,
        REGISTRATION_FAILED
    }

    DialogType dialogType;
    Dialog dialog;
    String dialogMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transparent_layout);
        dialogType = (DialogType) getIntent().getSerializableExtra(KEY_DIALOG_TYPE);
        dialogMessage = getIntent().getStringExtra(KEY_DIALOG_MESSAGE);
        showDialog(dialogType);
    }

    private void showDialog(DialogType dialogType) {
        switch (dialogType) {
            case BUSY:
                showBusyDialog();
                break;
            case TIME_OUT:
                showTimeOutDialog();
                break;
            case FORBIDDEN:
                showForbiddenDialog();
                break;
            case NO_INTERNET:
                showNoInternetDialog();
                break;
            case CALL_LIMIT_EXCEED:
                showCallLimitExceedDialog();
                break;
            case ERROR_REASON:
                showGenericDialogWithErrorMessage();
                break;
            case INVALID_NUMBER:
                showInvalidNumberDialog();
                break;
            case INSUFFICIENT_BALANCE:
                showInsufficientBalanceDialog();
                break;
            case SERVICE_UNAVAILABLE:
                showServiceUnavailableDialog();
                break;
            case DESTINATION_NOT_ALLOWED:
                showDestinationNotAllowedDialog();
                break;
            case REGISTRATION_NOT_ALLOWED:
                showRegistrationNotAllowedDialog();
                break;
            case REGISTRATION_FAILED:
                showRegistrationFailedDialog();
                break;
            case RATE_APP:
                showRateAppDialog();
                break;
            default:
                finish();
        }
    }

    private void showForbiddenDialog() {
        showDialog(getString(R.string.error),getString(R.string.server_unable_to_process_call));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.error));
//        builder.setMessage(getString(R.string.server_unable_to_process_call));
//        builder.setCancelableOnOutSideTouch(false);
//        builder.setCancelable(false);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showTimeOutDialog() {
        showDialog(getString(R.string.timeOut),getString(R.string.request_timed_out_by_server));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.timeOut));
//        builder.setMessage(getString(R.string.request_timed_out_by_server));
//        builder.setCancelableOnOutSideTouch(false);
//        builder.setCancelable(false);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showBusyDialog() {
        showDialog(getString(R.string.busy),getString(R.string.busyMessage));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.busy));
//        builder.setMessage(getString(R.string.busyMessage));
//        builder.setCancelableOnOutSideTouch(false);
//        builder.setCancelable(false);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showNoInternetDialog() {
        showDialog(getString(R.string.no_internet_title),getString(R.string.no_internet_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.no_internet_title));
//        builder.setMessage(getString(R.string.no_internet_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showCallLimitExceedDialog() {
        showDialog(getString(R.string.call_limit_exceeded_title),getString(R.string.call_limit_exceeded_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.call_limit_exceeded_title));
//        builder.setMessage(getString(R.string.call_limit_exceeded_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showInvalidNumberDialog() {
        showDialog(getString(R.string.invalid_number_title),getString(R.string.invalid_number_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.invalid_number_title));
//        builder.setMessage(getString(R.string.invalid_number_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showServiceUnavailableDialog() {
        showDialog(getString(R.string.service_unavailable_title),getString(R.string.service_unavailable_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.service_unavailable_title));
//        builder.setMessage(getString(R.string.service_unavailable_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showDestinationNotAllowedDialog() {
        showDialog(getString(R.string.destination_not_allowed_title),getString(R.string.destination_not_allowed_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.destination_not_allowed_title));
//        builder.setMessage(getString(R.string.destination_not_allowed_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showRegistrationNotAllowedDialog() {
        showDialog(getString(R.string.registration_not_allowed_title),getString(R.string.registration_not_allowed_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.registration_not_allowed_title));
//        builder.setMessage(getString(R.string.registration_not_allowed_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showRegistrationFailedDialog() {
        showDialog(getString(R.string.failed),getString(R.string.signup_attempt_failed_plz_try_later));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setIsHeadingShown(false);
//        builder.setMessage(getString(R.string.signup_attempt_failed_plz_try_later));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showRateAppDialog() {
        showDialog(getString(R.string.rate_app_title),getString(R.string.rate_app_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.rate_app_title));
//        builder.setMessage(getString(R.string.rate_app_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.GREEN);
//        builder.setLeftButtonText(getString(R.string.rate_now));
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                try {
//                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
//                } catch (ActivityNotFoundException e) {
//                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
//                }
//                finish();
//            }
//        });
//        builder.setRightButtonText(getString(R.string.later));
//        builder.setRightButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showInsufficientBalanceDialog() {
        showDialog(getString(R.string.insuffient_balance_title),getString(R.string.insuffient_balance_message));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.insuffient_balance_title));
//        builder.setMessage(getString(R.string.insuffient_balance_message));
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
////        builder.setLeftButtonText("Buy Pack");
////        builder.setLeftButtonClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                Intent intent = new Intent(DialogActivity.this, MyProfileActivity.class);
////                intent.putExtra(MyProfileActivity.GO_TO_TAB, MyProfileActivity.TAB_PURCHASE_PACKAGE);
////                startActivity(intent);
////                finish();
////            }
////        });
//        builder.setRightButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showGenericDialogWithErrorMessage() {
        showDialog(getString(R.string.error),getString(R.string.server_unable_to_process_call));
//        DialogProvider.Builder builder = DialogProvider.getBuilder(DialogActivity.this);
//        builder.setTitle(getString(R.string.error));
//        if(TextUtils.isEmpty(dialogMessage)) {
//            builder.setMessage(getString(R.string.server_unable_to_process_call));
//        } else {
//            builder.setMessage(dialogMessage.replaceAll("\"",""));
//        }
//        builder.setCancelableOnOutSideTouch(true);
//        builder.setCancelable(true);
//        builder.setDialogType(DialogProvider.DialogType.ERROR);
//        builder.setLeftButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        dialog = builder.build();
//        if(dialog != null)
//            dialog.show();
    }

    private void showDialog(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(DialogActivity.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                dialog.dismiss();
                finish();
            }
        });
        builder.create().show();
    }
}
