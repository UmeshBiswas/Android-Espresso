package com.revesoft.itelmobiledialer.ims;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.revesoft.itelmobiledialer.data.UserDataManager;

/**
 * @author ifta on 4/12/17.
 */

public class DraftMessageManager {
    private static final String DRAFT_MESSAGE_PREFERENCE_KEY = "DRAFT_MESSAGE_PREFERENCE_KEY";
    private static SharedPreferences draftMessages = null;

    public static void prepare(Context context) {
        String userName = UserDataManager.getUserName();
        if(TextUtils.isEmpty(userName) || userName.trim().length() < 1){
            return;
        }
        draftMessages = context.getSharedPreferences(DRAFT_MESSAGE_PREFERENCE_KEY+userName, Context.MODE_PRIVATE);
    }

    static boolean saveDraftMessage(String phoneNumber, String message) {
        if (draftMessages == null) {
            return false;
        }
        draftMessages.edit().putString(phoneNumber, message).apply();
        return true;
    }

    static boolean removeDraftMessage(String phoneNumber) {
        if (draftMessages == null) {
            return false;
        }
        draftMessages.edit().remove(phoneNumber).apply();
        return true;
    }

    static String getDraftMessage(String phoneNumber) {
        if (draftMessages == null) {
            return null;
        }
        return draftMessages.getString(phoneNumber, null);
    }
}
