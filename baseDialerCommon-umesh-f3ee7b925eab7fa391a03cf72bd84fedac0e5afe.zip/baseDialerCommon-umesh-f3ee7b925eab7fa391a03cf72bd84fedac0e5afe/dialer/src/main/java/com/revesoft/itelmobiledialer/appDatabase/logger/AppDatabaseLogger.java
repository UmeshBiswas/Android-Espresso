/*
 *  Created by Ifta on 8/8/18 11:02 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/5/18 3:35 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.logger;

import com.revesoft.itelmobiledialer.signalling.sipUtil.TaggedLogger;

import java.util.List;

public class AppDatabaseLogger {
    private static final TaggedLogger logger = new TaggedLogger("SlothLogger");
    public static void log(String data){
        logger.log(data);
    }
    public static void log(int data){
        logger.log(data);
    }
    public static void log(List<String> data){
        logger.log(data);
    }

    public static void error(Exception e) {
        logger.error(e);
    }
}
