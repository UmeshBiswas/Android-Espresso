package com.revesoft.itelmobiledialer.chat.chatWindow.memory;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.util.TaggedLogger;

/**
 * @author Ifta on 12/14/2017.
 */

public class MessageCache {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");
    private static final int CACHE_SIZE = 2048;
    public static final Message[] cache = new Message[CACHE_SIZE];

    private static boolean put(int positionAsKey, Message message) {
        if (positionAsKey >= CACHE_SIZE) {
            return false;
        }
        cache[positionAsKey] = message;
        return true;
    }


    public static Message findMessage(int position, Cursor cursor) {
        if (position < CACHE_SIZE) {
            Message message = cache[position];
            if (message == null && cursor != null && cursor.moveToPosition(position)) {
//                logger.log("findMessage:");
//                logger.log(cursor);
                message = new Message(cursor);
                put(position, message);
//                logger.log("message at position = " + position + " was not found in cache");
            } else {
//                logger.log("message at position = " + position + " has been found in cache");
            }
            return message;
        } else if (cursor != null && cursor.moveToPosition(position)) {
//            logger.log("cache size overflown at position = " + position);
            return new Message(cursor);
        }
        return null;
    }

    public static void invalidate() {
//        logger.log("invalidating message cache");
        for (int i = 0; i < CACHE_SIZE; i++) {
            cache[i] = null;
        }
    }
}
