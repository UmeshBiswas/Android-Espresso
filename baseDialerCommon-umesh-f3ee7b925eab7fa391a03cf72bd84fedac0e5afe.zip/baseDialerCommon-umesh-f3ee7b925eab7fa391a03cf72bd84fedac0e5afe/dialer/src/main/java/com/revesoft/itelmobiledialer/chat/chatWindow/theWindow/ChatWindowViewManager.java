package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow;

import android.content.Context;
import android.content.res.Resources;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.chat.chatWindow.group.Group;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.NameResolver;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.databaseentry.SubscriberEntry.PresenceState;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

/**
 * @author Ifta on 12/9/2017.
 */

public class ChatWindowViewManager {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");
    private Context context;
    private String target;
    private boolean isGroupChat;
    private Group group;

    public ChatWindowViewManager(Context context, String target, boolean isGroupChat) {
        this.context = context;
        this.target = target;
        this.isGroupChat = isGroupChat;
        if (isGroupChat) {
            this.group = new Group(ChatWindowActivity.getGroup());
        }
    }


    public void setPresenceStatus(int presenceState, ImageView ivState) {
        if (presenceState == PresenceState.AVAILABLE) {
            ivState.setImageResource(R.drawable.online);
        } else if (presenceState == PresenceState.OFFLINE) {
            ivState.setImageResource(R.drawable.busy);
        } else if (presenceState == PresenceState.BUSY) {
            ivState.setImageResource(R.drawable.inactive_status);
        } else if (presenceState == PresenceState.AWAY) {
            ivState.setImageResource(R.drawable.away);
        }
    }

    public void setProfileImage(ImageView ivProfileImage) {
        if (isGroupChat) {
            setGroupImage(ivProfileImage);
        } else {
            setPersonImage(ivProfileImage);
        }
    }

    public void setBroadcastImage(ImageView ivProfileImage) {
        ivProfileImage.setImageDrawable(Supplier.getResource().getDrawable(R.drawable.bubble_tone_offer));
    }

    private void setGroupImage(ImageView ivProfileImage) {
        String path = CommonData.groupIdToGroupImageUrl.get(group.id);
        ImageUtil.setImageButTextImageOnException(path, ivProfileImage, group.name);
//        ImageUtil.setImageButDefaultOnException(group.groupImagePath, ivProfileImage, R.drawable.ic_default_group_image);
    }

    private void setPersonImage(ImageView ivProfileImage) {
        String profilePicturePath = ProfilePictureDataProvider.getProfilePicturePath(target);
        ImageUtil.setImageButTextImageOnException(profilePicturePath, ivProfileImage, NameResolver.getContactNameFromNumberOrEmail(target));
    }

    void updateGroupState(String groupId) {
        this.group = new Group(ChatWindowActivity.getGroup());
    }

    public void setName(TextView tvName) {
        if (isGroupChat) {
            tvName.setText(group.name);
        } else {
            String name = CommonData.contactNumberToContactName.get(target);
            if (TextUtils.isEmpty(name)) {
                name = Util.getProperEmail(target);
            }
            tvName.setText(name);
        }
    }

    public void setNumber(TextView tvNumber) {
        if (isGroupChat) {
            Resources res = Supplier.getResource();
            String participantsFound = res.getQuantityString(R.plurals.numberOfParticipants, (group.memberCountButMe + 1), group.memberCountButMe);
            tvNumber.setText(participantsFound);
            tvNumber.setVisibility(View.VISIBLE);
        } else {
            tvNumber.setVisibility(View.GONE);
        }
    }

    void changeBackGround(ImageView ivBackground) {
        if (ChatProperties.isEncryptedChat) {
            ivBackground.setImageResource(0);
        } else {
            String identifierSeparator = Constants.CHAT_BACKGROUND;
            int id = PreferenceDataManager
                    .quickGet((target + identifierSeparator),
                            PreferenceDataManager
                                    .quickGet(Constants.IMS.DEFAULT_BACKGROUND_KEY+Constants.CHAT_BACKGROUND, R.drawable.bg0)
                    );
            ivBackground.setImageResource(id);
        }
    }


    private CountDownTimer typingTimer;

    void showTyping(TextView tv, String message) {
        final TextView typing = tv;
        if (typingTimer != null) {
            typingTimer.cancel();
        }
        typing.setText(message);
        typing.setVisibility(View.VISIBLE);
        typingTimer = new CountDownTimer(1500, 500) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                typing.post(new Runnable() {
                    @Override
                    public void run() {
                        typing.setVisibility(View.GONE);
                    }
                });
            }
        };
        typingTimer.start();
    }

}
