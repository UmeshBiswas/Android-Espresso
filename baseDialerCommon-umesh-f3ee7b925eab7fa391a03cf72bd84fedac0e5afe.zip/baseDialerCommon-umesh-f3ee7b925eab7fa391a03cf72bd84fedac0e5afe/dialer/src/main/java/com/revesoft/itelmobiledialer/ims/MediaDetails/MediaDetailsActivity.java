package com.revesoft.itelmobiledialer.ims.MediaDetails;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;


public class MediaDetailsActivity extends BaseActivity implements TabLayout.OnTabSelectedListener,
        MediaFragment.FragmentItemCallback, View.OnClickListener {
    public static void start(Activity activity, String phoneNumberOrGroupNumber, String name, boolean isGroup) {
        Intent intent = new Intent(activity, MediaDetailsActivity.class);
        intent.putExtra(Constants.Contact.CONTACT_NUMBER, phoneNumberOrGroupNumber);
        intent.putExtra(Constants.Contact.CONTACT_NAME, name);
        intent.putExtra("is_group", isGroup);
        activity.startActivity(intent);
    }

    private TabLayout tabLayout;
    private ViewPager viewPager;
    boolean searchEnabled = false;
    String currentpageTitle;
    Cursor mediaMessageCursor;
    MediaFragment mediaActivityFragment;
    DocumentFragment documentFragment;
    LinksFragment linksFragment;
    private static String[] pageTitle;
    private String phoneNumberOrGroupNumber;
    private String name;
    boolean isGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_detail_activity);
        pageTitle = new String[3];
        pageTitle[0] = getString(R.string.MEDIA);
        pageTitle[1] = getString(R.string.DOCUMENTS);
        pageTitle[2] = getString(R.string.LINKS);
        phoneNumberOrGroupNumber = getIntent().getExtras().getString(Constants.Contact.CONTACT_NUMBER);
        name = getIntent().getExtras().getString(Constants.Contact.CONTACT_NAME);
        isGroup = getIntent().getExtras().getBoolean("is_group", false);
        initViews();
        setViewData();
    }

    private void handleToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(name);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initViews() {
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
    }


    private void setViewData() {

        FragmentAdapter fragmentAdapter = new FragmentAdapter(getSupportFragmentManager());
        mediaActivityFragment = new MediaFragment();
        mediaActivityFragment.setFragmentName(getString(R.string.Media));
        mediaActivityFragment.setFragmentParams(isGroup, phoneNumberOrGroupNumber);
        fragmentAdapter.addFragment(mediaActivityFragment);
        documentFragment = new DocumentFragment();
        documentFragment.setFragmentName(getString(R.string.Document));
        documentFragment.setFragmentParams(isGroup, phoneNumberOrGroupNumber);
        fragmentAdapter.addFragment(documentFragment);
        linksFragment = new LinksFragment();
        linksFragment.setFragmentName(getString(R.string.links_uppercase));
        linksFragment.setFragmentParams(isGroup, phoneNumberOrGroupNumber);
        fragmentAdapter.addFragment(linksFragment);

        viewPager.setAdapter(fragmentAdapter);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(this);
        setHeader();
        handleToolbar();


    }

    private void setHeader() {
        if (tabLayout.getSelectedTabPosition() == 0) {
            searchEnabled = false;
        }
    }


    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
        setHeader();

    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {
        currentpageTitle = tab.getText().toString();
    }

    @Override
    public void onPagerItemClick(String message) {
        Toast.makeText(this, message + "!", Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onClick(View v) {

    }


    public static class FragmentAdapter extends FragmentStatePagerAdapter {

        List<Fragment> fragments = new ArrayList<Fragment>();


        public FragmentAdapter(FragmentManager fm) {
            super(fm);
        }

        public void addFragment(Fragment fragment) {

            fragments.add(fragment);
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return pageTitle[position];
        }

    }

}
