/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:47 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:47 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "topuplog")
public class TopUpLog {
    @NonNull
    @PrimaryKey(autoGenerate = true)
    public int _id;

    @ColumnInfo(name = "topupid")
    public int topUpId = 0;

    @NonNull
    public String number = AppDatabaseDefault.number;
    @NonNull
    public String amount = "0";

    public int status = 0;
    @NonNull
    public Date date = AppDatabaseDefault.date;


    public TopUpLog(int topUpId, @NonNull String number, @NonNull String amount, int status, @NonNull Date date) {
        this.topUpId = topUpId;
        this.number = number;
        this.amount = amount;
        this.status = status;
        this.date = date;
    }

    private TopUpLog(Builder builder) {
        _id = builder._id;
        topUpId = builder.topUpId;
        number = builder.number;
        amount = builder.amount;
        status = builder.status;
        date = builder.date;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private int _id;
        private int topUpId;
        private String number;
        private String amount;
        private int status;
        private Date date;

        private Builder() {
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withTopUpId(int val) {
            topUpId = val;
            return this;
        }

        public Builder withNumber(String val) {
            number = val;
            return this;
        }

        public Builder withAmount(String val) {
            amount = val;
            return this;
        }

        public Builder withStatus(int val) {
            status = val;
            return this;
        }

        public Builder withDate(Date val) {
            date = val;
            return this;
        }

        public TopUpLog build() {
            return new TopUpLog(this);
        }
    }
}
