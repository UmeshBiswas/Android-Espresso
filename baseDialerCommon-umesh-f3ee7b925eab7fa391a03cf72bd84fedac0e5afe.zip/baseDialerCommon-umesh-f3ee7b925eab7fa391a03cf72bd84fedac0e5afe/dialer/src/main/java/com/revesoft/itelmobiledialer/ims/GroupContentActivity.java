package com.revesoft.itelmobiledialer.ims;

import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.appDatabase.repo.CallLogRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.customview.SquareImageView;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.model.Group;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TimeFormat;
import com.revesoft.material.R;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import androidx.appcompat.widget.Toolbar;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Bulbul
 */

public class GroupContentActivity extends BaseActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    Toolbar toolbar;

    RecyclerView mRecyclerView;
    RecyclerViewAdapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;

    Group group;
    GroupDetailsActivity.GroupContentType content_type;

    private static final int MEDIA_QUERY_LOADER = 0;
    private static final int VOICE_QUERY_LOADER = 1;
    private static final int LINK_QUERY_LOADER = 2;

    TreeMap<Integer, Integer> dateRangeMap = new TreeMap<>();
    HashMap<Integer, Boolean> headerMap = new HashMap<>();
    int[] sizeArray = {10,1,33,7};  //Need to get from table. This is a dummy

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_content);
        group = (Group) getIntent().getSerializableExtra(Constants.IMS.GROUP_CONTENT);
        content_type = (GroupDetailsActivity.GroupContentType) getIntent().getSerializableExtra(Constants.IMS.GROUP_CONTENT_TYPE);

        Toast.makeText(this, content_type + "", Toast.LENGTH_LONG).show();

        handleToolbar();

        populateDateRangeMap(dateRangeMap,sizeArray);   //use dummy here.

        mRecyclerView = findViewById(R.id.recycler_view_media);
        mLayoutManager = new GridLayoutManager(this, 4);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new RecyclerViewAdapter();
        mRecyclerView.setAdapter(mAdapter);
        ((GridLayoutManager) mLayoutManager).setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (mAdapter.getItemViewType(position)) {
                    case RecyclerViewAdapter.TYPE_NORMAL:
                        return 1;
                    case RecyclerViewAdapter.TYPE_DATE:
                        return 4;
                    default:
                        return -1;
                }
            }
        });


        if (content_type == GroupDetailsActivity.GroupContentType.MEDIA) {
            getSupportLoaderManager().initLoader(MEDIA_QUERY_LOADER, null, this);
        } else if (content_type == GroupDetailsActivity.GroupContentType.VOICE) {
            getSupportLoaderManager().initLoader(VOICE_QUERY_LOADER, null, this);
        } else if (content_type == GroupDetailsActivity.GroupContentType.LINK) {
            getSupportLoaderManager().initLoader(LINK_QUERY_LOADER, null, this);
        }
    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home_up);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroy() {
        if (content_type == GroupDetailsActivity.GroupContentType.MEDIA) {
            getLoaderManager().destroyLoader(MEDIA_QUERY_LOADER);
        } else if (content_type == GroupDetailsActivity.GroupContentType.VOICE) {
            getLoaderManager().destroyLoader(VOICE_QUERY_LOADER);
        } else if (content_type == GroupDetailsActivity.GroupContentType.LINK) {
            getLoaderManager().destroyLoader(LINK_QUERY_LOADER);
        }
        super.onDestroy();
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        switch (id) {
            case MEDIA_QUERY_LOADER: {
                return new SQLiteCursorLoader(this) {
                    @Override
                    public Cursor loadInBackground() {
                        Cursor cursor = null;
                        try {
                            cursor = CallLogRepo.get().getCallLogsWithNameAndPic("", 0);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        return cursor;
                    }
                };
            }
            case VOICE_QUERY_LOADER: {

            }
            case LINK_QUERY_LOADER: {

            }
            default:
                return null;
        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.notifyDataSetChanged();
    }

    class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
        private Cursor mCursor;
        public static final int TYPE_NORMAL = 1;
        public static final int TYPE_DATE = 2;

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, int position) {
            int cursorPosition = 0;
            if(position!=0) {
                int dateCount;
                try {
                    dateCount = getMappedValue(dateRangeMap, position);
                } catch (Exception e) {
                    e.printStackTrace();
                    dateCount = 0;
                }
                cursorPosition = position - dateCount + 1;
            }
            mCursor.moveToPosition(cursorPosition);
            if (isSectionHeader(position)) {
                long time = mCursor.getLong(mCursor.getColumnIndex(DatabaseConstants.KEY_TIME));
                viewHolder.tvSectionDate.setVisibility(View.VISIBLE);
                viewHolder.tvSectionDate.setText(TimeFormat.getDateHeader(time));
                viewHolder.squareImageView.setVisibility(View.GONE);
            } else {
                final String filePath = mCursor.getString(mCursor.getColumnIndex(DatabaseConstants.KEY_FILE_PATH));
                if (filePath != null) {
                    try {
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


                viewHolder.tvSectionDate.setVisibility(View.GONE);
                viewHolder.squareImageView.setVisibility(View.VISIBLE);
                viewHolder.squareImageView.setImageResource(R.drawable.person_large);
            }
        }

        @Override
        public RecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.group_content_item, parent, false);

            ViewHolder viewHolder = new ViewHolder(view);

            return viewHolder;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            SquareImageView squareImageView;
            LinearLayout groupContentLayout;
            TextView tvSectionDate;

            public ViewHolder(View v) {

                super(v);

                squareImageView = v.findViewById(R.id.sqImageView);
                groupContentLayout = v.findViewById(R.id.groupContentLayout);
                tvSectionDate = v.findViewById(R.id.tvSectionDate);

            }
        }

        @Override
        public int getItemCount() {
            if (mCursor == null) {
                return 0;
            }
            return mCursor.getCount()+sizeArray.length;
        }

        @Override
        public int getItemViewType(int position) {
            if (isSectionHeader(position)) {
                return TYPE_DATE;
            } else {
                return TYPE_NORMAL;
            }
        }

        public void swapCursor(Cursor cursor) {
            mCursor = cursor;
            mAdapter.notifyDataSetChanged();
        }

        private boolean isSectionHeader(int position) {
            return headerMap.containsKey(position);
        }
    }

    private <K, V> V getMappedValue(TreeMap<K, V> map, K key) {
        Map.Entry<K, V> e = map.floorEntry(key);
        if (e != null && e.getValue() == null) {
            e = map.lowerEntry(key);
        }
        return e == null ? null : e.getValue();
    }

    private void populateDateRangeMap(TreeMap<Integer, Integer> map, int[] sizeArray) {
        int currentPosition = 0;
        int index = 1;
        for (int aSizeArray : sizeArray) {
            map.put(currentPosition, index);
            map.put(currentPosition + aSizeArray, null);
            headerMap.put(currentPosition, true);
            currentPosition += aSizeArray + 1;
            index++;
        }
    }
}
