package com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import com.revesoft.itelmobiledialer.chat.chatWindow.memory.StaticStickerDataProvider;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class StaticStickerFragment extends Fragment {
    private static Fragment fragment = null;
    StaticStickerAdapter adapter;

    public static Fragment getInstance() {
        if (fragment == null) {
            fragment = new StaticStickerFragment();
        }
        return fragment;
    }

    RecyclerView rvStickers;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.static_stickers_layout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvStickers = view.findViewById(R.id.rvStickers);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 4, RecyclerView.VERTICAL, false);
        rvStickers.setLayoutManager(gridLayoutManager);

        List<StaticSticker> staticStickers = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>(StaticStickerDataProvider.getStickersNames());
        for (String stickerName : names) {
            staticStickers.add(new StaticSticker(stickerName, StaticStickerDataProvider.getResourceIdByName(stickerName)));
        }
        adapter = new StaticStickerAdapter(staticStickers);
        rvStickers.setAdapter(adapter);
    }


    class StaticStickerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private List<StaticSticker> items;

        StaticStickerAdapter(List<StaticSticker> items) {
            this.items = items;
            notifyDataSetChanged();
        }

        @Override
        public staticStickerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.static_sticker, parent, false);
            return new staticStickerViewHolder(v);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            StaticSticker item = items.get(position);
            if (holder instanceof staticStickerViewHolder) {
                ((staticStickerViewHolder) holder).bindView(item);
            }
        }

        @Override
        public int getItemCount() {
            if (items == null) {
                return 0;
            }
            return items.size();
        }

        private class staticStickerViewHolder extends RecyclerView.ViewHolder {
            ImageView ivSticker;

            staticStickerViewHolder(View itemView) {
                super(itemView);
                ivSticker = itemView.findViewById(R.id.ivSticker);
            }

            public void bindView(StaticSticker item) {
//                ivSticker.setImageResource(item.resourceId);
                Glide.with(AppContext.getAccess().getContext())
                        .load(item.resourceId)
                        .error(R.drawable.b5)
                        .dontAnimate()
                        .thumbnail(0.2f)
                        .into(ivSticker);
                itemView.setOnClickListener(v -> {
                    Sender.getAccess().sendStaticSticker(item.name);
                });
            }
        }


    }

    public class StaticSticker {
        String name;
        int resourceId;

        StaticSticker(String name, int resourceId) {
            this.name = name;
            this.resourceId = resourceId;
        }

        @Override
        public String toString() {
            return "StaticSticker{" +
                    "name='" + name + '\'' +
                    ", resourceId=" + resourceId +
                    '}';
        }
    }
}
