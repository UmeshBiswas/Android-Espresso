package com.revesoft.itelmobiledialer.chat.tenor;


import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.MemoryCategory;

import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

/**
 * @author Ifta on 10/29/2017.
 */

public class TenorFragment extends Fragment {
    private static final TaggedLogger logger = new TaggedLogger("TenorGif");
    public static final String TAG = "TenorFragment";
    private static TenorFragment fragment = null;

    private TenorClickListener tenorClickListener;

    public static TenorFragment getInstance() {
        if (fragment == null) {
            fragment = new TenorFragment();
        }
        return fragment;
    }

    RecyclerView rvGifList;
    EditText etSearch;
    ImageView ivSearch;
    TenorAdapter tenorAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Glide.get(getActivity()).setMemoryCategory(MemoryCategory.HIGH);
    }

    public void attachTenorClickListener(TenorClickListener tenorClickListener) {
        this.tenorClickListener = tenorClickListener;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tenor_fragment_layout, container, false);
        rvGifList =  rootView.findViewById(R.id.rvGifList);
        final RecyclerView.LayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.HORIZONTAL);
        rvGifList.setLayoutManager(layoutManager);
        tenorAdapter = new TenorAdapter(getActivity());
        rvGifList.setAdapter(tenorAdapter);
        loadAndShowTenor(null);
        tenorAdapter.attachTenorClickListener(tenorClickListener);
        return rootView;
    }



    private void disableSearch() {
        etSearch.setEnabled(false);
        ivSearch.setEnabled(false);
        ivSearch.setClickable(false);
    }

    private void enableSearch() {
        etSearch.setEnabled(true);
        ivSearch.setEnabled(true);
        ivSearch.setClickable(true);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        TenorDataLoader.getAccess().clear();
        Glide.get(getActivity()).setMemoryCategory(MemoryCategory.NORMAL);
    }

    private void loadAndShowTenor(String searchText) {
        TenorDataLoader.getAccess().getNextSet(getActivity(), searchText, new TenorLoadListener() {
            @Override
            public void onTenorLoad(ArrayList<TenorGif> tenorGifs) {
                enableSearch();
                tenorAdapter.refresh(tenorGifs);
            }

            @Override
            public void onTenorLoadError(String errorInfo) {
                I.toast(getString(R.string.something_went_wrong));
                enableSearch();
            }


        });
    }

    public boolean isInSearchMode() {
        return etSearch.hasFocus();
    }
}
