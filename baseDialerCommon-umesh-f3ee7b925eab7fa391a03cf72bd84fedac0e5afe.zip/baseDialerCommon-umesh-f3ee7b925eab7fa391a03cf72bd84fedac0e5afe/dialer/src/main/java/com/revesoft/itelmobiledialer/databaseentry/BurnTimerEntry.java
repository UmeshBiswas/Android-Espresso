package com.revesoft.itelmobiledialer.databaseentry;

public class BurnTimerEntry {
	public String callerId;
	public String number;
	public int entryType;
	public long extactBurnTime;
	public int burnTime;
	public int burnTimeIndex;
	public int messageType;

	public static interface BurnTimerEntryType {
		public static short SINGLE_CHAT = 0, GROUP_CHAT = 1;
	}
}