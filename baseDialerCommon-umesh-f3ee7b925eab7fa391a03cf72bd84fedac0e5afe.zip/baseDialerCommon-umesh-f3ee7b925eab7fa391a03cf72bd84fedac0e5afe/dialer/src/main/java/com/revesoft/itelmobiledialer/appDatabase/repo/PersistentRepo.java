package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Persistent;

public class PersistentRepo {
    private static final PersistentRepo ourInstance = new PersistentRepo();

    public static PersistentRepo get() {
        return ourInstance;
    }

    private PersistentRepo() {
    }

    public void createOrUpdatePersistentSettingsEntry(String key, String value){
        Persistent persistent=new Persistent(key,value);
        AppDatabase.get().persistentDao().insert(persistent);
    }
}

