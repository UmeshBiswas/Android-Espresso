package com.revesoft.itelmobiledialer.contact.picker;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class PickedContacts {
    private static Set<ContactListItem> items = new HashSet<>();

    public static boolean add(ContactListItem item) {
        boolean success = items.add(item);
        if (success && listener != null) {
            listener.onAdd(item);
        }
        return success;
    }

    public static boolean remove(ContactListItem item) {
        boolean success = items.remove(item);
        if (success && listener != null) {
            listener.onRemove(item);
        }
        return success;
    }

    public static boolean contains(ContactListItem item) {
        return items.contains(item);
    }

    public static void addAll(ArrayList<String> selectedContactList) {
        List<ContactListItem> selectedItems = new ArrayList<>();
        Executor.ex(() -> {
            List<Contact> contacts = AppDatabase.get().contactDao().getContactByFlatNumber(selectedContactList);
            for (Contact contact : contacts) {
                selectedItems.add(ContactListItem.from(contact, false));
            }
            items.addAll(selectedItems);
            if (listener != null) {
                Gui.get().run(()-> listener.onAddAll());
            }
        });

    }

    public static void clear() {
        items.clear();
    }

    public static Set<ContactListItem> getAll() {
        return items;
    }

    public static String getCount() {
        return String.valueOf(items.size());
    }

    public static int size() {
        return items.size();
    }

    public List<String> getNumbers() {
        List<String> selectedNumbers = new ArrayList<>();
        for (ContactListItem item : items) {
            selectedNumbers.add(item.getProcessedNumber());
        }
        return selectedNumbers;
    }

    private static PickerListener listener;

    static void attachListener(PickerListener pickerListener) {
        PickedContacts.listener = pickerListener;
    }
}
