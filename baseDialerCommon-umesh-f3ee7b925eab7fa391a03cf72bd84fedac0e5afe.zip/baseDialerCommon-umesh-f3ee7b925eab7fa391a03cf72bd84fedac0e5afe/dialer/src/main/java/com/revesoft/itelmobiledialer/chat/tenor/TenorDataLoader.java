package com.revesoft.itelmobiledialer.chat.tenor;

import android.content.Context;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.itelmobiledialer.util.Util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;

import androidx.annotation.Nullable;

/**
 * @author Ifta on 10/30/2017.
 */

public class TenorDataLoader {
    private static TenorDataLoader tenorDataLoader = null;

    public static TenorDataLoader getAccess() {
        if (tenorDataLoader == null) {
            tenorDataLoader = new TenorDataLoader();
        }
        return tenorDataLoader;
    }

    private static String API_KEY;

    void setApiKey(String apiKey) {
        API_KEY = apiKey;
    }

    private static final TaggedLogger logger = new TaggedLogger("TenorGif");
    private static final int LIMIT = 20;
    private static String next = null;

    public void clear() {
        next = null;
    }

    public void getNextSet(Context context, @Nullable String searchText, final TenorLoadListener tenorLoadListener) {
        final ArrayList<TenorGif> tenorGifs = new ArrayList<>(LIMIT);
        RequestQueue queue = Volley.newRequestQueue(context);
        String url;
        if (searchText == null) {
            url = "https://api.tenor.com/v1/trending?key=" + API_KEY + "&safesearch=strict";
        } else {
            try {
                url = "https://api.tenor.com/v1/search?q=" + URLEncoder.encode(searchText, "UTF-8") + "&key=" + API_KEY + "&safesearch=strict";
            } catch (Exception e) {
                url = "https://api.tenor.com/v1/search?q=" + searchText.split(" ")[0] + "&key=" + API_KEY + "&safesearch=strict";
                e.printStackTrace();
            }
        }
        url += "&limit=" + LIMIT;
//        if (next != null) {
//            url += "&pos=" + next;
//        }
        logger.log("url = " + url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Util.printLongLog("TenorGif",response);
                            JSONObject data = new JSONObject(response);
                            JSONArray results = data.getJSONArray("results");
                            for (int i = 0; i < results.length(); i++) {
                                tenorGifs.add(new TenorGif(results.getJSONObject(i)));
//                                logger.log(tenorGifs.quickGet(i).toString());
                            }
                            next = data.getString("next");
                            tenorLoadListener.onTenorLoad(tenorGifs);
                        } catch (Exception e) {
                            logger.error(e);
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tenorLoadListener.onTenorLoadError(error.getLocalizedMessage());
            }
        });
        queue.add(stringRequest);
    }
}
