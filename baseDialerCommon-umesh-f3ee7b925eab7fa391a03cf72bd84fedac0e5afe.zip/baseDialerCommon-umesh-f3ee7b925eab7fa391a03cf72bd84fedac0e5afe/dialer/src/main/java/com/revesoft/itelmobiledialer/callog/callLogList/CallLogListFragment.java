package com.revesoft.itelmobiledialer.callog.callLogList;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.arch.LazyFragment;
import com.revesoft.itelmobiledialer.data.MissedCallCounter;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModelOwner;
import com.revesoft.material.R;
import com.revesoft.material.databinding.FragmentCallLogListBinding;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;


/**
 * Recent calls fragment.
 */
public class CallLogListFragment extends LazyFragment implements FilterableViewModelOwner {
    private static final String TAG = "RecentCallsFragment";
    private CallLogListViewModel model;

    public static String getTAG() {
        return TAG;
    }

    public static Fragment newInstance() {
        return new CallLogListFragment();
    }

    public CallLogListFragment() {

    }

    private CallLogListAdapter adapter;
    private FragmentCallLogListBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_call_log_list, container, false);
        adapter = new CallLogListAdapter(getContext());
        binding.list.setAdapter(adapter);
        return binding.getRoot();
    }

    @Override
    public void loadData() {
        MissedCallCounter.clearCount();
        model = ViewModelProviders.of(this).get(CallLogListViewModel.class);
        watchViewModel();
    }

    @Override
    public void search(String searchString) {
        model.filter(this, searchString);
        watchViewModel();
    }

    @Override
    public void watchViewModel() {
        model.getPagedData().observe(this, callLogItems -> {
            adapter.submitList(callLogItems);
            binding.progressBar.setVisibility(View.GONE);
        });
    }


}
