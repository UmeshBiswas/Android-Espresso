package com.revesoft.itelmobiledialer.dialogues;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import com.revesoft.material.R;
import com.revesoft.itelmobiledialer.util.IntentUtil;


public class UserOfflinePaidCallActivity extends Activity {


    private String number;
    private String rate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Log.d("Abhi","started");
        setContentView(R.layout.activity_user_offline_paid_call);
        number = getIntent().getExtras().getString("callingNumber");
        rate = getIntent().getExtras().getString("rate");
        if (!TextUtils.isEmpty(rate))
            ((TextView) findViewById(R.id.tv_subtext)).setText(
                    getString(R.string.make_an_outside_call) + " " +  getString(R.string.callrate) + " " + rate);
        findViewById(R.id.yesButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentUtil.sendStartPaidCallIntent(UserOfflinePaidCallActivity.this, number);
                finish();
            }
        });
        findViewById(R.id.noButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();

    }
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent == null)
            return;

        number = getIntent().getExtras().getString("callingNumber");
        rate = getIntent().getExtras().getString("rate");
        if (!TextUtils.isEmpty(rate))
            ((TextView) findViewById(R.id.tv_subtext)).setText(
                    getString(R.string.make_an_outside_call) + " " +  getString(R.string.callrate)  + " "+ rate);
    }

}


