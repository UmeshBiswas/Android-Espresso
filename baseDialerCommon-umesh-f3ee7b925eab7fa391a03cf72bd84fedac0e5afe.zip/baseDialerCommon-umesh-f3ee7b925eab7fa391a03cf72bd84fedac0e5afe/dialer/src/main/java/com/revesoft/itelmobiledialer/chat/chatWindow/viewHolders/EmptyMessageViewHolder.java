package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;


import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

/**
 *@author Ifta on 12/21/2017.
 */

public class EmptyMessageViewHolder extends RecyclerView.ViewHolder {
    public EmptyMessageViewHolder(View view) {
        super(view);
    }

    public void bindView() {

    }
}
