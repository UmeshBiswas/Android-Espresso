package com.revesoft.itelmobiledialer.chat.chatWindow.helper;

/**
 * @author Ifta on 12/19/2017.
 */

public enum CallType {
    AUDIO,VIDEO
}
