package com.revesoft.itelmobiledialer.confide;

import android.database.Cursor;

import android.text.TextUtils;

import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.xdatabase.XTableKeys;

import androidx.collection.ArrayMap;

/**
 * @author Ifta on 2/8/2018.
 */

public class ConfideMessage {
    String callerId;
    String number;
    int messageType;
    int deliveryStatus;
    long receivedTime;
    String content;
    int notification;
    String filepath;
    boolean isDecrypted;
    MimeType mimeType;

    public ConfideMessage(Cursor cursor) {
        this.callerId = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_CALLER_ID));
        this.number = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_NUMBER));
        this.messageType = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_MESSAGE_TYPE));
        this.deliveryStatus = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_MESSAGE_DELIVERY_STATUS));
        this.receivedTime = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_RECEIVE_TIME_CONFIDE));
        this.content = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_MESSAGE_CONTENT));
        if(MimeTypeUtil.getMimeType(content) != MimeType.Text){
            this.content = ChatContentParser.parseCaption(content);
        }
        this.notification = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_NOTIFICATION));
        this.filepath = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_FILE_PATH));
        this.isDecrypted = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_IS_DECRYPTED)) == 1;
        this.mimeType = TextUtils.isEmpty(filepath) ? MimeType.Text : MimeTypeUtil.getMimeTypeFromFilePath(filepath);
    }

    public static class ColumnIndexCache {
        private static ArrayMap<String, Integer> cache = new ArrayMap<>();

        public static int getColumnIndex(Cursor cursor, String columnName) {
            if (!cache.containsKey(columnName))
                cache.put(columnName, cursor.getColumnIndex(columnName));
            return cache.get(columnName);
        }

        public static void clear() {
            cache.clear();
        }
    }
}
