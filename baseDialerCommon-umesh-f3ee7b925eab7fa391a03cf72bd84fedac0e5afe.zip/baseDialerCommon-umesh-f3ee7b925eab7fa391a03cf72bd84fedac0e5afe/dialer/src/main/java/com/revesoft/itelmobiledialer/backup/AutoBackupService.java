package com.revesoft.itelmobiledialer.backup;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.DriveServiceHelper;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.GoogleDriveChatBackupApi;

import java.util.Collections;


/**
 * Created by ashikee on 8/9/17.
 */
@SuppressWarnings("all")
public class AutoBackupService extends Service {
    public static String TAG = "AutoBackupService";


    private DriveServiceHelper mDriveServiceHelper;


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        try {
            handleSignIn();
        } catch (Exception e) {

        }


    }

    @Override
    public void onStart(Intent intent, int startId) {
        try {
            GoogleDriveChatBackupApi googleDriveChatBackupApi = new GoogleDriveChatBackupApi(mDriveServiceHelper);
            googleDriveChatBackupApi.backUpChatNow();
        } catch (Exception e) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        System.out.println(TAG+" onStartCommand");
//        try{
//            handleSignIn();
//            GoogleDriveChatBackupApi backupChat=new GoogleDriveChatBackupApi(mDriveServiceHelper);
//            backupChat.backUpChatNow();
//        }catch (Exception e){
//            System.out.println(TAG+" onStartCommand err "+e.getMessage());
//        }


        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {

    }


    private void handleSignIn() {

        GoogleAccountCredential credential = GoogleAccountCredential.usingOAuth2(getApplicationContext(),
                Collections.singleton(DriveScopes.DRIVE_FILE));
        credential.setSelectedAccount(GoogleSignIn.getLastSignedInAccount(getApplicationContext()).getAccount());
        Drive googleDriveService =
                new Drive.Builder(
                        AndroidHttp.newCompatibleTransport(),
                        new GsonFactory(),
                        credential)
                        .setApplicationName("Drive API Migration")
                        .build();
        mDriveServiceHelper = new DriveServiceHelper(googleDriveService);
    }
}





