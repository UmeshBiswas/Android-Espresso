package com.revesoft.itelmobiledialer.contact.list;

import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;
import androidx.paging.LivePagedListBuilder;
import androidx.paging.PagedList;

public class ContactListViewModel extends FilterableViewModel<ContactListItem> {
    private ContactType contactType;

    ContactListViewModel(ContactType contactType) {
        this.contactType = contactType;
        pagedData = prepareFilteredData();
    }


    @Override
    protected LiveData<PagedList<ContactListItem>> prepareFilteredData() {
        Set<Character> alreadyObservedHeader = new HashSet<>();
        if (contactType == null) {
            contactType = ContactType.APP;
        }
        DataSource.Factory<Integer, Contact> dataSourceFactory;
        switch (contactType) {
            case ALL:
                dataSourceFactory = ContactRepo.get().getAllLivePagedFiltered(searchFilter);
                break;
            case APP:
                dataSourceFactory = ContactRepo.get().getAppLivePagedFiltered(searchFilter);
                break;
            case BLOCKED:
                dataSourceFactory = ContactRepo.get().getBlockedLivePagedFiltered(searchFilter);
                break;

            case NOT_BLOCKED:
                dataSourceFactory = ContactRepo.get().getNotBlockedLivePagedFiltered(searchFilter);
                break;
            case FAVORITE:
                dataSourceFactory = ContactRepo.get().getFavoriteLivePagedFiltered(searchFilter);
                break;
            default:
                dataSourceFactory = ContactRepo.get().getAllLivePagedFiltered(searchFilter);
                break;
        }
        DataSource.Factory<Integer, ContactListItem> factory = dataSourceFactory.mapByPage(input -> {
            List<ContactListItem> list = new ArrayList<>();
            for (int i = 0; i < input.size(); i++) {
                Contact contact = input.get(i);
                String name = TextUtils.isEmpty(contact.name) ? contact.number : contact.name;
                boolean isHeader = alreadyObservedHeader.add(name.toUpperCase().charAt(0));
                list.add(ContactListItem.from(contact, isHeader));
            }
            return list;
        });
        return new LivePagedListBuilder<>(factory, 20).build();
    }

    @Override
    public void filter(LifecycleOwner lifecycleOwner, String searchFilter) {
        super.filter(lifecycleOwner, searchFilter);
    }
}
