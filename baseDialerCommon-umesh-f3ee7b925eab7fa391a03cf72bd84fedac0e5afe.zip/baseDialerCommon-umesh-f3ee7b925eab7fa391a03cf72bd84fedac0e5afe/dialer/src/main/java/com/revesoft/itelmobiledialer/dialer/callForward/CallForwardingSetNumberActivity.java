package com.revesoft.itelmobiledialer.dialer.callForward;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


public class CallForwardingSetNumberActivity extends BaseActivity {

    /**
     * Called when the activity is first created.
     */
    private Button btnsave;
    private TextInputEditText etCallForwardNumber;
    ProgressDialog pD;
    Handler handler;
    volatile boolean gotResponse = false;
    Toolbar toolbar;

    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            gotResponse = true;
            hideProgressDialog();
            String action = intent.getAction();
            if (Constants.CALL_FORWARDING_ADD_OR_CHANGE_ACTION.equals(action)) {
                String number = intent.getStringExtra(Constants.CALL_FORWARDING_NUMBER);
                Intent resultIntent = new Intent();
                if (number == null) {
                    Toast.makeText(getApplicationContext(), R.string.call_forwarding_set_failed, Toast.LENGTH_SHORT).show();
                    resultIntent.putExtra("forwarded_number", "");
                    CallForwardingSetNumberActivity.this.setResult(RESULT_OK, resultIntent);
                } else {
                    Toast.makeText(getApplicationContext(), R.string.call_forwarding_set_successfully, Toast.LENGTH_SHORT).show();
                    PreferenceDataManager.quickPut(AccountPreference.Keys.CALL_FORWARDING, number);
                    PreferenceDataManager.quickPut(AccountPreference.Keys.IS_ENABLED_CALL_FORWARDING, true);
                    resultIntent.putExtra("forwarded_number", number);
                    CallForwardingSetNumberActivity.this.setResult(RESULT_OK, resultIntent);

                }

                finish();
            }
        }
    };


    private void showProgressDialog() {
        pD = ProgressDialog.show(this, "",
                getString(R.string.please_wait), true);
    }

    private void hideProgressDialog() {
        try {
            if (pD != null && pD.isShowing()) {
                pD.dismiss();
                pD = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_forwarding_set_number);

        handler = new Handler();
        handleToolbar();
        etCallForwardNumber = findViewById(R.id.et_cf_number);
        etCallForwardNumber.setLongClickable(true);
        etCallForwardNumber.setCustomSelectionActionModeCallback(new ActionMode.Callback() {

            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            public void onDestroyActionMode(ActionMode mode) {
            }

            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                return false;
            }
        });

        btnsave = findViewById(R.id.btn_save);

        btnsave.setOnClickListener(v -> {
            if (etCallForwardNumber.getText() == null) return;
            String number = etCallForwardNumber.getText().toString();
            if (number.length() > 0) {
                showProgressDialog();
                sendCallForwardingAddOrChangeRequest(number);
                startCountDown();
            } else {
                AlertDialog.Builder bld = new AlertDialog.Builder(CallForwardingSetNumberActivity.this);
                bld.setMessage(getString(R.string.call_forwarding_insert_a_number));
                bld.setPositiveButton(R.string.ok_button, (dialogInterface, i) -> dialogInterface.dismiss());
                bld.create().show();
            }
        });


        IntentFilter mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(Constants.CALL_FORWARDING_ADD_OR_CHANGE_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(mBroadcastReceiver, mIntentFilter);

    }

    private void startCountDown() {
        gotResponse = false;
        handler.postDelayed(() -> {
            if (!gotResponse) {
                hideProgressDialog();
                Toast.makeText(getApplicationContext(), R.string.network_dialog_title, Toast.LENGTH_SHORT).show();
            }
        }, 10000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mBroadcastReceiver);
    }

    private void sendIntentMessageToDialer(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }


    private void sendCallForwardingAddOrChangeRequest(String number) {
        sendIntentMessageToDialer("call_forwarding_add_or_change_request", number);
    }

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home_up);
            getSupportActionBar().setTitle(R.string.call_forwarding);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return false;
    }


}
