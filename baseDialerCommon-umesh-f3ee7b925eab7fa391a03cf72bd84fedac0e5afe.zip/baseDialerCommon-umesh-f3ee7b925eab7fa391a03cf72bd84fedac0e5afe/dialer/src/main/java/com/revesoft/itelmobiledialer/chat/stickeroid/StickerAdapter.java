package com.revesoft.itelmobiledialer.chat.stickeroid;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 10/29/2017.
 */

public class StickerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    TaggedLogger logger = new TaggedLogger("Stickroid");
    private ArrayList<Sticker> stickers = new ArrayList<>();
    private Context context;

    public StickerAdapter(Context context) {
        this.context = context;
    }


    private StickerClickListener stickerClickListener = null;

    public void attachStickerClickListener(StickerClickListener stickerClickListener) {
        this.stickerClickListener = stickerClickListener;
    }

    void addMore(ArrayList<Sticker> stickers) {
        this.stickers.addAll(stickers);
        logger.log("size after adding = " + stickers.size());
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.stickeroid_single_item, parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder) holder).bindView(position);
    }


    @Override
    public int getItemCount() {
        return stickers.size();
    }

    public void refresh(ArrayList<Sticker> stickers) {
        this.stickers.clear();
        this.stickers.addAll(stickers);
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPreview, dummy;
        ShimmerFrameLayout shimmerFrameLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            ivPreview = itemView.findViewById(R.id.ivPreview);
            dummy = itemView.findViewById(R.id.dummyIvPreview);
            shimmerFrameLayout = itemView.findViewById(R.id.sticker_shimmer_view_container);
        }

        public void bindView(final int position) {
            Sticker sticker = stickers.get(position);


            if(sticker.isPlaceHolder){
                dummy.setVisibility(View.VISIBLE);
                ivPreview.setVisibility(View.GONE);

            }else {
                itemView.setOnClickListener(v -> {
                    if (stickerClickListener != null) {
                        stickerClickListener.onStickerClick(sticker);
                    }
                });

                Glide.with(context)
                        .load(sticker.thumbUrl)
                        .asBitmap()
                        .crossFade()
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .listener(new RequestListener<String, Bitmap>() {
                            @Override
                            public boolean onException(Exception e, String model, Target<Bitmap> target, boolean isFirstResource) {
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Bitmap resource, String model, Target<Bitmap> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                ivPreview.setVisibility(View.VISIBLE);
                                dummy.setVisibility(View.GONE);
                                return false;
                            }
                        })
                        .into(ivPreview);
            }

        }

    }
}
