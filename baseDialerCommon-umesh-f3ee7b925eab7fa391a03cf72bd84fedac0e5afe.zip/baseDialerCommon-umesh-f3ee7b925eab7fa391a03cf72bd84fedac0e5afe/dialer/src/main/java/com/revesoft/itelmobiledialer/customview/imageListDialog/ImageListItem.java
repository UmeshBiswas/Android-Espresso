package com.revesoft.itelmobiledialer.customview.imageListDialog;

/**
 * @author Ifta
 *         on 8/28/2017.
 */

public class ImageListItem  {
    String itemName;
    int imageDrawableId;

    public ImageListItem(String itemName, int imageDrawableId) {
        this.itemName = itemName;
        this.imageDrawableId = imageDrawableId;
    }
}
