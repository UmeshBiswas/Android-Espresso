package com.revesoft.itelmobiledialer.chat.chatWindow.messageBurn;


import android.view.animation.Animation;
import android.view.animation.Transformation;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Nazmul  on 10/19/2017.
 * moved to different package by Ifta
 */

public class BurnTimerAnimation extends Animation {
    private final RecyclerView recyclerView;
    private int deltaY = 0;
    private int currDeltaY = 0;

    public BurnTimerAnimation(RecyclerView recyclerView, int deltaY) {
        this.recyclerView = recyclerView;
        this.deltaY = deltaY;
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        int prevDeltaY = currDeltaY;
        currDeltaY = (int) (deltaY * interpolatedTime);
        recyclerView.scrollBy(0, currDeltaY - prevDeltaY);
    }

    @Override
    public boolean willChangeBounds() {
        return true;
    }

}
