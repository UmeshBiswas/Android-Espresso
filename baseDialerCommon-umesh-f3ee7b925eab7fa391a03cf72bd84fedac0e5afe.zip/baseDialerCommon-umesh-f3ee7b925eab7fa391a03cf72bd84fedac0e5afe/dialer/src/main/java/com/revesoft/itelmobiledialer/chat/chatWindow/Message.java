package com.revesoft.itelmobiledialer.chat.chatWindow;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.itelmobiledialer.xdatabase.XTableKeys;

import androidx.collection.ArrayMap;

/**
 * @author Ifta on 10/23/2017.
 */
public class Message {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");
    public String callerId;
    public long _id;
    public String sender;
    public short messageType;
    public int deliveryStatus;
    public long time;
    public String content;
    public long receivedTime;
    public long trueTimeStamp;
    public int editCount;
    public long futureTime = 0;
    public long seenTime;
    public String filePathLocal;
    public String filePathOriginal;
    public boolean isHeader;
    public long imBurnTime;
    public String smsMessageId;
    public short sendOriginalTimestampFlag;
    public String numberSentSMSFromGroupChat;
    public short previousType = -1;
    public long previousTime = -1;
    public String previousSender = null;
    public boolean isEmoOnly = false;
    public boolean isLastOnConitiousStack;
    public MimeType mimeType;
    public int broadcastId;
    public boolean isConfide = false;
    public String longMessage = null;

    //added by ashrafi

    public String ocid;
    public String qcid;
    public String quoteData;
    public String quoteFilePath;
    public String quoteFromUser;
    public MimeType quoteMimeType;

    public Message(Cursor cursor) {
        this.content = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_MESSAGE_CONTENT));
        this.callerId = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_CALLER_ID));
        this.filePathLocal = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_FILE_PATH));
//        this.filePathOriginal = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_ORIGINAL_FILE_PATH));
//        this.imBurnTime = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_BURN_TIME));
        this._id = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_ID));
        this.sender = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_NUMBER));
        this.time = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_TIME));
        this.futureTime = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_FUTURE_SEND_TIME));
        this.smsMessageId = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_SMS_MESSAGE_ID));
        this.seenTime = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_SEEN_TIME));
//        this.trueTimeStamp = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_TRUE_TIMESTAMP));
        this.messageType = cursor.getShort(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_MESSAGE_TYPE));
        this.deliveryStatus = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_MESSAGE_DELIVERY_STATUS));
        this.editCount = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_EDIT_COUNT));
//        this.sendOriginalTimestampFlag = cursor.getShort(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_SEND_ORIGINAL_TIMESTAMP_FLAG));
        this.receivedTime = cursor.getLong(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_RECV_TIME));
        this.numberSentSMSFromGroupChat = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_NUMBER));
        this.isEmoOnly = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_IS_EMO_ONLY)) == 1;
        this.mimeType = MimeTypeUtil.getMimeTypeByName(cursor.getString(ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_MIME_TYPE)));
//        this.isConfide = cursor.getInt(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_IS_CONFIDE)) == 1;
        this.longMessage = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_LONG_MESSAGE));

        //message quote
        this.ocid = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_OCID));
        this.qcid = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_QCID));
        this.quoteData = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_QUOTE_DATA));
        this.quoteFilePath = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_QUOTE_FILE_PATH));
        this.quoteFromUser = cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_QUOTE_FROM_USER));
//        this.quoteMimeType = MimeTypeUtil.getMimeTypeByName(cursor.getString(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_QUOTE_MIME_TYPE)));

        //broadcast
//        this.broadcastId = cursor.getInt(ChatHistoryItem.ColumnIndexCache.getColumnIndex(cursor, XTableKeys.KEY_BROADCAST_ID));

        //helper data
        if (cursor.getPosition() == 0) {
            isHeader = true;
        } else {
            cursor.moveToPrevious();
            this.previousType = cursor.getShort(cursor.getColumnIndex(DatabaseConstants.KEY_MESSAGE_TYPE));
            this.previousTime = cursor.getLong(cursor.getColumnIndex(DatabaseConstants.KEY_TIME));
            this.previousSender = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_NUMBER));
            cursor.moveToNext();
            isHeader = !ChatDateTimeFormatter.getComparableDate(this.time).equals(ChatDateTimeFormatter.getComparableDate(previousTime));
        }

        if (messageType == MessageEntry.MessageType.RECEIVED) {
            if (cursor.moveToNext()) {
                short nextType = cursor.getShort(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_MESSAGE_TYPE));
                String nextSender = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_NUMBER));
                long nextTime = cursor.getLong(cursor.getColumnIndex(DatabaseConstants.KEY_TIME));
                isLastOnConitiousStack = nextType != messageType || !nextSender.equals(sender)
                        || !ChatDateTimeFormatter.getComparableDate(nextTime).equals(ChatDateTimeFormatter.getComparableDate(this.time));
                cursor.moveToPrevious();
            } else {
                isLastOnConitiousStack = true;
            }
        } else {
            if (cursor.moveToNext()) {
                short nextType = cursor.getShort(ColumnIndexCache.getColumnIndex(cursor, DatabaseConstants.KEY_MESSAGE_TYPE));
                long nextTime = cursor.getLong(cursor.getColumnIndex(DatabaseConstants.KEY_TIME));
                isLastOnConitiousStack = nextType != messageType || !ChatDateTimeFormatter.getComparableDate(nextTime).equals(ChatDateTimeFormatter.getComparableDate(this.time));
                cursor.moveToPrevious();
            } else {
                isLastOnConitiousStack = true;
            }
        }

    }

    public Message() {
    }

    public static Message from(com.revesoft.itelmobiledialer.appDatabase.entities.Message message) {
        Message m = new Message();
        m.callerId = message.callerId;
        m._id = message._id;
        m.sender = message.number;
        m.messageType = (short) message.messageType;
        m.deliveryStatus = message.deliveryStatus;
        m.time = message.date.getTime();
        m.content = message.content;
        m.receivedTime = message.received.getTime();
        m.trueTimeStamp = 0;
        m.editCount = message.editCount;
        m.futureTime = message.futureSendTime;
        m.seenTime = message.seenTime;
        m.filePathLocal = message.filePath;
        m.filePathOriginal = ChatContentParser.parseFilePath(message.content);
        m.isHeader = false;
        m.mimeType = message.mimeType;
        m.imBurnTime = message.burnScheduledTimeStamp;
        m.qcid = message.qcid == null ? "" : message.qcid;
        m.ocid = message.ocid;
        m.quoteData = message.quotePreviewContent;
        m.quoteFromUser = message.quoteFromUser;
        return m;
    }

    @Override
    public String toString() {
        return "Message{" +
                "callerId='" + callerId + '\'' +
                ", sender='" + sender + '\'' +
                ", messageType=" + messageType +
                ", deliveryStatus=" + deliveryStatus +
                ", time=" + time +
                ", content='" + content + '\'' +
                ", receivedTime=" + receivedTime +
                ", trueTimeStamp=" + trueTimeStamp +
                ", editCount=" + editCount +
                ", futureTime=" + futureTime +
                ", seenTime=" + seenTime +
                ", filePathLocal='" + filePathLocal + '\'' +
                ", filePathOriginal='" + filePathOriginal + '\'' +
                ", isHeader=" + isHeader +
                ", imBurnTime=" + imBurnTime +
                ", smsMessageId='" + smsMessageId + '\'' +
                ", sendOriginalTimestampFlag=" + sendOriginalTimestampFlag +
                ", numberSentSMSFromGroupChat='" + numberSentSMSFromGroupChat + '\'' +
                ", previousType=" + previousType +
                ", previousTime=" + previousTime +
                ", previousSender='" + previousSender + '\'' +
                ", isEmoOnly=" + isEmoOnly +
                ", isLastOnConitiousStack=" + isLastOnConitiousStack +
                ", mimeType=" + mimeType +
                ", broadcastId=" + broadcastId +
                ", ocid='" + ocid + '\'' +
                ", qcid='" + qcid + '\'' +
                ", quoteData='" + quoteData + '\'' +
                ", quoteFilePath='" + quoteFilePath + '\'' +
                ", quoteFromUser='" + quoteFromUser + '\'' +
                ", quoteMimeType=" + quoteMimeType +
                '}';
    }

    public static class ColumnIndexCache {
        private static ArrayMap<String, Integer> cache = new ArrayMap<>();

        public static int getColumnIndex(Cursor cursor, String columnName) {
//            if (!cache.containsKey(columnName))
//                cache.put(columnName, cursor.getColumnIndex(columnName));
//            return cache.quickGet(columnName);
            return cursor.getColumnIndex(columnName);
        }

        public static void clear() {
            cache.clear();
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Message message = (Message) o;

        return callerId.equals(message.callerId);
    }

    @Override
    public int hashCode() {
        return callerId.hashCode();
    }
}
