package com.revesoft.itelmobiledialer.contact.picker;

import com.revesoft.itelmobiledialer.contact.list.ContactListItem;

interface PickerListener {
    void onAdd(ContactListItem contact);

    void onRemove(ContactListItem contact);

    void onAddAll();
}
