package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "location_request_table")
public class LocationRequest {
    public int _id;
    @NonNull
    @PrimaryKey
    public String number = AppDatabaseDefault.number;

    @ColumnInfo(name = "location_request_expire_time")
    public Date locationRequestExpireTime = AppDatabaseDefault.date;

    public LocationRequest() {
    }

    private LocationRequest(Builder builder) {
        _id = builder._id;
        number = builder.number;
        locationRequestExpireTime = builder.locationRequestExpireTime;
    }


    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private int _id;
        private String number;
        private Date locationRequestExpireTime;

        private Builder() {
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withNumber(String val) {
            number = val;
            return this;
        }

        public Builder withLocationRequestExpireTime(Date val) {
            locationRequestExpireTime = val;
            return this;
        }

        public LocationRequest build() {
            return new LocationRequest(this);
        }
    }
}
