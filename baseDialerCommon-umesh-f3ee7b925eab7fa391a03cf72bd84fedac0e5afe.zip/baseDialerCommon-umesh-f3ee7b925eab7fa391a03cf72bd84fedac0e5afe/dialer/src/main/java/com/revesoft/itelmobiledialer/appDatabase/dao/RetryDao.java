package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.RetryEntry;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * Created By suvo on January 31, 2019
 * Project baseDialerCommon
 */

@Dao
public interface RetryDao extends BaseDao<RetryEntry> {


    @Query("SELECT * FROM RETRY")
    List<RetryEntry> getAll();


    @Query("SELECT COUNT(*) FROM RETRY WHERE callerid=:callerId")
    boolean checkRetryExistsByCallerId(String callerId);

    @Query("SELECT retry_count FROM RETRY WHERE callerid=:callerId")
    int getRetryCountByCallerId(String callerId);


    @Query("DELETE FROM RETRY WHERE callerid=:callerId")
    int deleteRetryByCallerId(String callerId);


}
