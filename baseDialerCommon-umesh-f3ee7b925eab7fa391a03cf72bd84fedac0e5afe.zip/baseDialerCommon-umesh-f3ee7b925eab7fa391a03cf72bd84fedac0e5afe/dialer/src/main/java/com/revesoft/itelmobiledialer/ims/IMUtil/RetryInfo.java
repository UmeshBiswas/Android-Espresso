package com.revesoft.itelmobiledialer.ims.IMUtil;

/**
 * Created by Acer on 4/17/2017.
 */

public class RetryInfo {

    private String message;
    private int type;
    private long futureTime;

    public long getFutureTime() {
        return futureTime;
    }

    public void setFutureTime(long futureTime) {
        this.futureTime = futureTime;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public RetryInfo(String message, int type, long futureTime) {
        this.message = message;
        this.type = type;
        this.futureTime=futureTime;
    }
}
