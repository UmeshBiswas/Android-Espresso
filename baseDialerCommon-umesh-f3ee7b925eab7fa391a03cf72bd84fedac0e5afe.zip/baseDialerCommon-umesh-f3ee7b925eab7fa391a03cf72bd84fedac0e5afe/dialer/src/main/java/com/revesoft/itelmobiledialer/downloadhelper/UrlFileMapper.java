package com.revesoft.itelmobiledialer.downloadhelper;

import java.io.File;

public class UrlFileMapper {
    private String url;
    private File file;
    public UrlFileMapper(String url, File file)
    {
        this.url = url;
        this.file= file;
    }

    public String getUrl() {
        return url;
    }

    public File getFile() {
        return file;
    }

}
