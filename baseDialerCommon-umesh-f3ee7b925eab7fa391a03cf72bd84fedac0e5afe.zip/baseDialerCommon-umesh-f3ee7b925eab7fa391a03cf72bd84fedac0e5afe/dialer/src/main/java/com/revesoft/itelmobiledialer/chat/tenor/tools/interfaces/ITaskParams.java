package com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces;



import java.io.Serializable;

import androidx.annotation.NonNull;

public interface ITaskParams extends Serializable {

    /**
     * @return the unique id of the task
     */
    @NonNull
    String getId();
}
