package com.revesoft.itelmobiledialer.callog.callLogList;

import java.util.Date;

import androidx.room.ColumnInfo;

public class QueryItemCallLogList {
    public String callId;
    public String processedNumber;
    public String number;
    public String name;
    @ColumnInfo(name = "type")
    public int callLogType;

    public Date date;

    @ColumnInfo(name = "is_video_call")
    public boolean isVideoCall;

    public long duration;

    @ColumnInfo(name = "call_type")
    public int callType;

    @ColumnInfo(name = "call_rate")
    public  float callRate;

}
