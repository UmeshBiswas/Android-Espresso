package com.revesoft.itelmobiledialer.account;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.revesoft.itelmobiledialer.backup.ChatBackupSettingsActivity;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

/**
 * @author Ifta
 *         on 5/21/2017.
 */

public class SettingsActivity extends BaseActivity {
    Context context;
    Toolbar toolbar;

    public static void startForTesting(Context context) {
        Intent intent = new Intent(context, SettingsActivity.class);
        context.startActivity(intent);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity_layout);
        this.context = this;
        handleToolbar();
    }


    private void handleToolbar() {
        toolbar =  findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.settings));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(getString(R.string.settings));
        }
    }
    public void handleAccountPrivacy(View view) {
        startActivity(AccountPrivacyActivity.class);
    }

    public void handleChats(View view) {
        startActivity(ChatSettingsActivity.class);
    }

    public void handleNotifications(View view) {
        startActivity(NotificationSettingsActivity.class);
    }

    public void handleDataUsage(View view) {
        startActivity(DataUsageSettingsActivity.class);
    }

    private void startActivity(Class<?> targetClass) {
        Intent intent = new Intent(SettingsActivity.this, targetClass);
        startActivity(intent);
    }

    public void handleDataBackUp(View view) {
        startActivity(ChatBackupSettingsActivity.class);
    }
}
