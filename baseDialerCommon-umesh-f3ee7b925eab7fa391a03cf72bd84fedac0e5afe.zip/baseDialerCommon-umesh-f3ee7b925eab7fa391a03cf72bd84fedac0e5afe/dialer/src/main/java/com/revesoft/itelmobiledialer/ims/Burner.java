

package com.revesoft.itelmobiledialer.ims;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;

import java.util.HashMap;
import java.util.List;

import static com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants.MESSAGE_HISTORY_URI;
import static com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants.MESSAGE_URI;


/**
 * Created by Ashikee AbH! on 8/14/2018.
 */
public class Burner {

    enum BurnType {single, session}

    HashMap<String, Long> userOrGroupToBurnTime = new HashMap<>();
    BurnType burnType = BurnType.session;
    Context context;
    static Burner burner;
    Handler burnHandler;
    String TAG = "Burner";
    HandlerThread handlerThreadBurner;

    public static Burner getBurner(Context context) {
        if (burner == null) burner = new Burner();
        burner.context = context;
        if (burner.burnHandler == null)
            burner.initHandler();
        return burner;
    }

    Burner() {
        handlerThreadBurner = new HandlerThread("HandlerThreadBurner");
        handlerThreadBurner.start();
    }

    private void initHandler() {
        burnHandler = new Handler(handlerThreadBurner.getLooper());
    }

    void setBurnerOn(String userOrGroupID, long time) {
        userOrGroupToBurnTime.put(userOrGroupID, time);
    }

    public void unsetBurner(String userOrGroupID) {
        userOrGroupToBurnTime.remove(userOrGroupID);
    }

    public boolean isBurnerSet(String userOrGroup) {
        return userOrGroupToBurnTime.containsKey(userOrGroup);
    }

    public long getBurnTimeInMillies(String userOrGroup) {
        return userOrGroupToBurnTime.get(userOrGroup);
    }

    public void startOrRestartBurner() {
        burnHandler.removeCallbacks(BurnerRunnable);
        recursiveCallHandler((long) 10);

    }

    public void recursiveCallHandler(Long waitTimeInMillis) {
        burnHandler.postDelayed(BurnerRunnable, waitTimeInMillis);
    }


    Runnable BurnerRunnable = () -> {
        Executor.ex(() -> {
            long currentTime = System.currentTimeMillis();
            Message[] message = MessageRepo.get().getScheduledBurnMessage(currentTime + 500);
            if (message.length > 0) {
                if (currentTime >= message[0].burnScheduledTimeStamp ||
                        ((message[0].burnScheduledTimeStamp - currentTime) < 1000)) {
                    AppDatabase.get().messageDao().delete(message[0]);
                    context.getContentResolver().notifyChange(MESSAGE_URI, null);
                    context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);

                    message = MessageRepo.get().getNextBurnMessage();
                    if (message.length > 0) {
                        long interval = message[0].burnScheduledTimeStamp - System.currentTimeMillis();
                        if (interval > 200)
                            recursiveCallHandler(interval);
                        else recursiveCallHandler((long) 100);
                    }
                } else
                    recursiveCallHandler(message[0].burnScheduledTimeStamp - currentTime);
            } else {
                message = MessageRepo.get().getNextBurnMessage();
                if (message.length > 0) {
                    long interval = message[0].burnScheduledTimeStamp - System.currentTimeMillis();
                    recursiveCallHandler(interval);
                }

            }

        });
    };

    public static void updateBurnScheduledTimeStampOnDelivered(String callid, Context context) {
        Executor.ex(() -> {
            Message[] message = MessageRepo.get().getSentMessageByCallerID(callid);
            if (message.length > 0 && message[0].burnTimerInSecond > 0 && message[0].burnScheduledTimeStamp <= 0) {
                message[0].burnScheduledTimeStamp = System.currentTimeMillis() + message[0].burnTimerInSecond;
                long rowid = AppDatabase.get().messageDao().update(message[0]);
                if (rowid > 0) {
                    Burner.getBurner(context).startOrRestartBurner();

                }
            }
        });
    }

    public static void updateReceivedMessageBurnTimeInMillis(List<String> callIDs, Context context) {
        Executor.ex(() -> {
            List<Message> message = MessageRepo.get().getReceivedBurnedMessagesWhereBurnTImeInMilliesNotSet(callIDs);
            if (message.size() > 0) {
                for (int i = 0; i < message.size(); i++)
                    message.get(i).burnScheduledTimeStamp = System.currentTimeMillis() + message.get(i).burnTimerInSecond;
                AppDatabase.get().messageDao().insertAll(message);
                Burner.getBurner(context).startOrRestartBurner();

            }
        });

    }

    public void quitBurner() {
        handlerThreadBurner.quit();
    }

}
