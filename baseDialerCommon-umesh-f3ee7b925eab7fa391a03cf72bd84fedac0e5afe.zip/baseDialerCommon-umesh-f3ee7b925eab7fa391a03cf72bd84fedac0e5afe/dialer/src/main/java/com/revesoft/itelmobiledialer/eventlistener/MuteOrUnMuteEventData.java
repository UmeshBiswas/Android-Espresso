package com.revesoft.itelmobiledialer.eventlistener;

public class MuteOrUnMuteEventData extends EventData{
    private String keyNumber;
    private boolean mute_status;

    public MuteOrUnMuteEventData(String keyNumber, boolean mute_status) {
        this.keyNumber = keyNumber;
        this.mute_status = mute_status;
    }

    public String getKeyNumber() {
        return keyNumber;
    }

    public boolean isMute_status() {
        return mute_status;
    }
}
