package com.revesoft.itelmobiledialer.chat.stickeroid;

import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TaggedLogger;

import java.net.URLEncoder;

/**
 * @author Ifta on 11/5/2017.
 */

public class Stickeroid {
    static TaggedLogger logger = new TaggedLogger("Stickeroid");
    private static final String ROOT_URL = "https://stickeroid.com";
    private static String url;
    private static Builder builder = null;
    private static String defaultSearchKey = "hi";

    public static Builder getBuilder() {
        if (builder == null) {
            builder = new Builder();
        }
        return builder;
    }

    public static String getRoot() {
        return ROOT_URL;
    }

    public static String getDefaultSearchKey() {
        return PreferenceDataManager.quickGet(Constants.IMS.KEY_LAST_STICKER_SEARCH, defaultSearchKey);
    }

    public static class Builder {
        private String apiKey;
        private int count = 5;
        private int width = 128;
        private String searchKey = "hi";

        private Builder() {
        }

        public Builder setApiKey(String apiKey) {
            this.apiKey = apiKey;
            return this;
        }

        public Builder setCount(int count) {
            this.count = count;
            return this;
        }

        public Builder setWidth(int width) {
            this.width = width;
            return this;
        }

        public Builder setDefaultSearchKey(String searchKey) {
            this.searchKey = searchKey;
            return this;
        }

        public void build() {
            url = ROOT_URL + "/bot?k=" + apiKey + "&c=" + count;
            defaultSearchKey = searchKey;
        }
    }

    public static String getBotUrl(String searchKey) {
        String[] parts = searchKey.split(" ");
        if (parts.length == 1) {
            return url + "&s=" + searchKey;
        } else if(parts.length > 1) {
            try {
                return url + "&s=" + URLEncoder.encode(searchKey, "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
                return url + "&s=" + parts[0];
            }
        }
        return url +"&s=hello";
    }
}
