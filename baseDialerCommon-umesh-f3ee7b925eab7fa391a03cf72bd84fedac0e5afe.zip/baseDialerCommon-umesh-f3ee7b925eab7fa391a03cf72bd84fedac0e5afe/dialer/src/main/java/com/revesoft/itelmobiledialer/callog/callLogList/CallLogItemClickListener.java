package com.revesoft.itelmobiledialer.callog.callLogList;

public interface CallLogItemClickListener {
    void onCallLogClick(CallLogItem callLog);
    void onCallLogLongClick(CallLogItem callLog);
    void makeAudioCall(String number);
    void makeVideoCall(String number);
    void makeOutCall(String number);
    void unblock(String number);
    void onCallLogProfileImageClick(String number);
}
