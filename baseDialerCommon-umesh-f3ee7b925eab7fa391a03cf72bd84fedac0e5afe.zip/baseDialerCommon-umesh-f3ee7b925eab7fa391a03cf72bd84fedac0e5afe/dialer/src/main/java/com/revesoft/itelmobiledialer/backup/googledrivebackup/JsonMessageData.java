package com.revesoft.itelmobiledialer.backup.googledrivebackup;

import com.revesoft.itelmobiledialer.appDatabase.entities.BurnMessageInfo;
import com.revesoft.itelmobiledialer.appDatabase.entities.Group;
import com.revesoft.itelmobiledialer.appDatabase.entities.GroupMessageEligible;
import com.revesoft.itelmobiledialer.appDatabase.entities.HiddenMessage;
import com.revesoft.itelmobiledialer.appDatabase.entities.LocationRequest;
import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.appDatabase.entities.MessageStatus;
import com.revesoft.itelmobiledialer.appDatabase.repo.BurnMessageInfoRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupMessageEligibleRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.HiddenMessageRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.LocationRequestRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageStatusRepo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created By suvo on February 07, 2019
 * Project baseDialerCommon
 **/

@SuppressWarnings("all")
public class JsonMessageData {


    public List<BurnMessageInfo> burnMessageInfoList = new ArrayList<>();
    public List<Group> groupList = new ArrayList<>();
    public List<GroupMessageEligible> groupMessageEligibleList = new ArrayList<>();
    public List<HiddenMessage> hiddenMessageList = new ArrayList<>();
    public List<LocationRequest> locationRequestList = new ArrayList<>();
    //    public List<MessageHistoryTime> messageHistoryTimeList=new ArrayList<>();
    public List<Message> messageList = new ArrayList<>();
    public List<MessageStatus> messageStatusList = new ArrayList<>();


    public JsonMessageData() {

    }


    public void initializeFromDatabase() {
        burnMessageInfoList = BurnMessageInfoRepo.get().getAll();
        groupList = GroupRepo.get().getAll();
        groupMessageEligibleList = GroupMessageEligibleRepo.get().getAll();
        hiddenMessageList = HiddenMessageRepo.get().getAll();
        locationRequestList = LocationRequestRepo.get().getAll();
//        messageHistoryTimeList= MessageHistoryTimeRepo.get().get
        messageList = MessageRepo.get().getAll();
        messageStatusList = MessageStatusRepo.get().getAll();
    }
}
