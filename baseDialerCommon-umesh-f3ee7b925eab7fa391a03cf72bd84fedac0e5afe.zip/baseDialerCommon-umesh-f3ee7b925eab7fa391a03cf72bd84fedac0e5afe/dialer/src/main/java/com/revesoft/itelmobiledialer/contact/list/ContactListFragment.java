package com.revesoft.itelmobiledialer.contact.list;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.arch.LazyFragment;
import com.revesoft.itelmobiledialer.contact.FavoriteContactsActivity;
import com.revesoft.itelmobiledialer.block.BlockedContactActivity;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModelOwner;
import com.revesoft.itelmobiledialer.processor.contactblock.ContactBlockHelper;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Log;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ContactListFragmentLayoutBinding;

import java.util.Queue;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Ifta Noor Mahmood
 * Created by Ifta Noor Mahmood on 1/24/2017.
 */

public class ContactListFragment extends LazyFragment implements FilterableViewModelOwner {
    private static final boolean gotFoolishRequest = false;//make it true for fools
    public static final String TAG = "ContactPickerListFragment";
    private static final String KEY_HAS_OPTION_MENU = "KEY_HAS_OPTION_MENU";
    private static final String KEY_CONTACT_TYPE = "KEY_CONTACT_TYPE";
    private ContactListFragmentLayoutBinding binding;

    public ContactListFragment() {
    }

    public static ContactListFragment newInstance(boolean hasOptionMenu, ContactType contactType) {
        Bundle bundle = new Bundle();
        bundle.putBoolean(KEY_HAS_OPTION_MENU, hasOptionMenu);
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        ContactListFragment fragment = new ContactListFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    public static Fragment newInstance(ContactType contactType) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        Fragment fragment = new ContactListFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            boolean hasOptionMenu = bundle.getBoolean(KEY_HAS_OPTION_MENU);
            contactTypeToLoad = (ContactType) bundle.getSerializable(KEY_CONTACT_TYPE);
            setHasOptionsMenu(hasOptionMenu);
        }
    }


    private ContactListAdapter adapter;
    private ContactListViewModel viewModel;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        binding = DataBindingUtil.inflate(inflater, R.layout.contact_list_fragment_layout, container, false);
        initEmptyListLayout();
        adapter = new ContactListAdapter(getActivity(),contactTypeToLoad);
        binding.rv.setAdapter(adapter);
        if (gotFoolishRequest) {
            IntentFilter filter = new IntentFilter(Constants.DASHBOARD_INTENT_FILTER);
            if (getActivity() != null && isAdded()) {
                LocalBroadcastManager.getInstance(getActivity()).registerReceiver(broadcastReceiver, filter);
            }
        }
        return binding.getRoot();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (gotFoolishRequest) {
            LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(broadcastReceiver);
        }
    }


    private void initEmptyListLayout() {
        binding.emptyListLayout.tvEmptyListDescription.setText(getString(R.string.noContactFound));
        binding.emptyListLayout.ivEmptyListIcon.setImageResource(R.drawable.ic_big_no_contact);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private ContactType contactTypeToLoad = ContactType.ALL;


    private void showEmptyViewMessage() {
        if (searchText.length() != 0) {
            return;
        }
        binding.emptyListLayout.getRoot().setVisibility(View.VISIBLE);
        binding.indexFragmentHolderPhoneBook.setVisibility(View.GONE);
    }

    private void hideEmptyViewMessage() {
        binding.emptyListLayout.getRoot().setVisibility(View.GONE);
        binding.indexFragmentHolderPhoneBook.setVisibility(View.VISIBLE);
    }

    @Override
    public void search(String searchString) {
        this.searchText = searchString;
        viewModel.filter(this, searchString);
        watchViewModel();
    }

    private String searchText = "";

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_contacts, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuFavoritesContacts:
                Intent intent = new Intent(getActivity(), FavoriteContactsActivity.class);
                startActivity(intent);
                return true;
            case R.id.menuBlockedContacts:
                startBlockedContactActivity();
                return true;
            case R.id.menuAccount:
                Intent accountIntent = new Intent(getActivity(), AccountActivity.class);
                startActivity(accountIntent);
                return true;
        }
        return false;
    }

    private void startBlockedContactActivity() {
        Intent intent = new Intent(getActivity(), BlockedContactActivity.class);
        startActivity(intent);
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (this.isVisible()) {
            if (!isVisibleToUser) {
                if (!searchText.equals("")) {
                    search("");
                }
            }
        }
    }

    @Override
    public void loadData() {
        viewModel = ViewModelProviders.of(this, new ContactViewModelFactory(contactTypeToLoad)).get(ContactListViewModel.class);
        watchViewModel();
    }

    public static String getTAG() {
        return TAG;
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(Constants.Broadcast.TYPE_SUBSCRIBER_INFO_LOADED_SIGNAL)) {
                    adapter.notifyDataSetChanged();
                } else if (bag.containsKey(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE)) {
                    adapter.notifyDataSetChanged();
                }
            }
        }
    };

    @Override
    public void watchViewModel() {
        viewModel.getPagedData().observe(this, contactListItems -> {
            binding.progressBar.setVisibility(View.GONE);
            adapter.submitList(contactListItems);

            if(requestType.equals("blocking"))
            {
                blockNextContactFromQueue();
            }
            if(requestType.equals("unblocking"))
            {
                requestType = "none";
                dismissProgressDialog();
            }
            if (contactListItems.size() == 0) {
                showEmptyViewMessage();
            } else {
                hideEmptyViewMessage();

            }

        });
    }

    private Queue<String> blockContactsQueue;
    private ProgressDialog blockUnblockProgressDialog;
    private String requestType="none";    // none, blocking, unblocking
    private String currentBlockUnblockContact;
    public void setBlockContactsQueue(Queue<String> blockContactsQueue)
    {
        this.blockContactsQueue = blockContactsQueue;
    }


    public void blockNextContactFromQueue()
    {
        if(blockContactsQueue!=null && !blockContactsQueue.isEmpty())
        {
            if(requestType.equals("none")) {
                requestType = "blocking";
                showProgressDialog(requestType);
            }
            currentBlockUnblockContact = blockContactsQueue.poll();
            ContactBlockHelper.getAccess().block(currentBlockUnblockContact);
        }
        else
        {
            currentBlockUnblockContact = null;
            requestType = "none";
            dismissProgressDialog();
        }
    }

    public void unblockContact(String contact)
    {
        requestType = "unblocking";
        currentBlockUnblockContact = contact;
        showProgressDialog(requestType);
        ContactBlockHelper.getAccess().unblock(contact);

    }

    private void showProgressDialog(String requestType)
    {
        if(requestType.equals("blocking"))
        {
            blockUnblockProgressDialog = new ProgressDialog(getContext());
            blockUnblockProgressDialog.setTitle(getResources().getString(R.string.please_wait));
            blockUnblockProgressDialog.setMessage(getResources().getString(R.string.blocking_contacts));
            blockUnblockProgressDialog.show();
        }
        else if(requestType.equals("unblocking"))
        {
            blockUnblockProgressDialog = new ProgressDialog(getContext());
            blockUnblockProgressDialog.setTitle(getResources().getString(R.string.please_wait));
            blockUnblockProgressDialog.setMessage(getResources().getString(R.string.unblocking_contacts));
            blockUnblockProgressDialog.show();
        }
        else
        {
            Log.i("blocking_contact","Status "+requestType);
        }
    }

    private void dismissProgressDialog(){ blockUnblockProgressDialog.dismiss();}


}
