package com.revesoft.itelmobiledialer.eventlistener;

/**
 * Created By suvo on February 11, 2019
 * Project baseDialerCommon
 **/

public class BackupOperationStatusData extends EventData {
    private boolean operationStatus;
    private boolean isGoogleDriveReachable;
    private boolean isGoogleDrivePermitted;


    private BackupOperationStatusData(Builder builder) {
        operationStatus = builder.operationStatus;
        isGoogleDriveReachable = builder.isGoogleDriveReachable;
        isGoogleDrivePermitted = builder.isGoogleDrivePermitted;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public boolean isOperationStatus() {
        return operationStatus;
    }

    public boolean isGoogleDriveReachable() {
        return isGoogleDriveReachable;
    }

    public boolean isGoogleDrivePermitted() {
        return isGoogleDrivePermitted;
    }

    /**
     * {@code BackupOperationStatusData} builder static inner class.
     */
    public static final class Builder {
        private boolean operationStatus = false;
        private boolean isGoogleDriveReachable = false;
        private boolean isGoogleDrivePermitted = false;

        private Builder() {
        }


        public Builder operationStatus(boolean val) {
            operationStatus = val;
            return this;
        }


        public Builder isGoogleDriveReachable(boolean val) {
            isGoogleDriveReachable = val;
            return this;
        }


        public Builder isGoogleDrivePermitted(boolean val) {
            isGoogleDrivePermitted = val;
            return this;
        }


        public BackupOperationStatusData build() {
            return new BackupOperationStatusData(this);
        }
    }
}
