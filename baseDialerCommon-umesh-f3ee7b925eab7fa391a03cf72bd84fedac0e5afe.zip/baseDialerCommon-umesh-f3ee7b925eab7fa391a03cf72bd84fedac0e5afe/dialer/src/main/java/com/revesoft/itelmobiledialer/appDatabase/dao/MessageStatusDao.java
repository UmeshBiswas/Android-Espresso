package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.MessageStatus;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;


/**
 * @author Ifta
 */
@Dao
public interface MessageStatusDao extends BaseDao<MessageStatus>{


    @Query("SELECT * FROM MESSAGE_STATUS_TABLE")
    List<MessageStatus> getAll();


        @Query("SELECT * FROM message_status_table where callerid = :cid LIMIT 1")
        MessageStatus[] getStatusMessageByCallID(String cid);

//    @Query("SELECT * FROM  messages Where burn_timer_in_sec > 0 AND ((messagetype = 0 AND deliverystatus == 200) OR (messagetype = 1 AND deliverystatus = 3210)) ")
//    public  Message[] getmessageToBurn();
//
//    @Query("SELECT * FROM messages where callerid = :cid  AND messagetype = 0 LIMIT 1")
//    public  Message[] getSentMessageByCallerID(String cid);
//
//    @Query("SELECT * FROM messages where callerid = :cid AND messagetype = 1 LIMIT 1")
//    public Message[] getReceivedMessageByCallerID(String cid);
//
//    @Query("SELECT * FROM messages where  (burn__scheduled_timestamp > 0 AND burn__scheduled_timestamp <= :currentSystemTime) ORDER BY burn__scheduled_timestamp  LIMIT 1 ")
//    public  Message[] getScheduledBurnMessage(long currentSystemTime);
//
//
//    @Query("SELECT * FROM messages where  burn__scheduled_timestamp > 0 ORDER BY burn__scheduled_timestamp  LIMIT 1 ")
//    public  Message[] getNextBurnMessage();
//
//    @Query("SELECT * FROM messages where burn_timer_in_sec > 0 AND burn__scheduled_timestamp = -1 AND callerid  IN (:callIDs)")
//    List<Message> getReceivedBurnedMessagesWhereBurnTImeInMilliesNotSet(List<String> callIDs);
//
//
//    @Query("SELECT burn_timer_in_sec FROM messages where callerid = :cid")
//    public  long getBurnTimer(String cid);

    @Query("SELECT * FROM MESSAGE_STATUS_TABLE WHERE callerid=:callerId")
    Cursor getMessageStatusByCallerId(String callerId);


    @Query("SELECT st.callerid AS callerid,et.eligibleCount AS eligibleCount, SUM(CASE WHEN st.seen_time<>0 THEN 1 ELSE 0 END) AS seenCount, " +
            "SUM(CASE WHEN st.delivery_time<>0 THEN 1 ELSE 0 END) AS deliveryCount FROM MESSAGE_STATUS_TABLE st LEFT JOIN " +
            "GROUP_MESSAGE_ELIGIBLE_TABLE et  ON st.callerid=et.callerid " +
            " WHERE et.groupid=:groupId group by st.callerid")
    Cursor seenDeliveryCountWithGroupMemberCount(String groupId);


    @Query("SELECT q1.callerid, q2.eligibleCount, q2.seenCount, q2.deliveryCount FROM " +
            "(SELECT gmt.callerid AS callerid, Max(gmt.date) AS date FROM MESSAGES gmt GROUP BY gmt.groupid) AS q1 " +
            " INNER JOIN " +
            "(SELECT st.callerid AS callerid,et.eligibleCount AS eligibleCount, SUM(CASE WHEN st.seen_time<>0 THEN 1 ELSE 0 END) AS seenCount, " +
            "SUM(CASE WHEN st.delivery_time<>0 THEN 1 ELSE 0 END) AS deliveryCount FROM " +
            "MESSAGE_STATUS_TABLE st LEFT JOIN GROUP_MESSAGE_ELIGIBLE_TABLE et  ON st.callerid=et.callerid " +
            "GROUP BY st.callerid) AS q2 " +
            "ON q1.callerid = q2.callerid")
    Cursor lastMessageSeenDeliveryCountWithGroupMemberCount();
}
