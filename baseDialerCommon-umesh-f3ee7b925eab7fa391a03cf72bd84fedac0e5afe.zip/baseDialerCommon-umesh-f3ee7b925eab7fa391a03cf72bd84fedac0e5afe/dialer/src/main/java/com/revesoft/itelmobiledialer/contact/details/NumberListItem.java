package com.revesoft.itelmobiledialer.contact.details;

public class NumberListItem {
    String number;
    int showAudioCall;
    int showVideoCall;
    int showOutCall;
    int showChat;
    int showEmail;

    public String getNumber() {
        return number;
    }

    public int isShowAudioCall() {
        return showAudioCall;
    }

    public int isShowVideoCall() {
        return showVideoCall;
    }

    public int isShowOutCall() {
        return showOutCall;
    }

    public int isShowChat() {
        return showChat;
    }

    public int isShowEmail() {
        return showEmail;
    }
}
