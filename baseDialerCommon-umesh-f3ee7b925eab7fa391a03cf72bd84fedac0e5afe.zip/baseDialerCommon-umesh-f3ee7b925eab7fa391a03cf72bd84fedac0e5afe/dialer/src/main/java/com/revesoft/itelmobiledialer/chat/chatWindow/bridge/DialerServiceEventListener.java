package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;

import java.util.HashMap;

/**
 * @author Ifta  on 2/13/2018.
 */

public interface DialerServiceEventListener {
    void onDialerServiceEvent(DialerServiceEvent event, String data);
    void onDialerServiceEvent(DialerServiceEvent event, HashMap<String, String> data);
}
