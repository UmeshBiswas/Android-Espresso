package com.revesoft.itelmobiledialer.customview;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by acer on 8/22/2016.
 */

public class SmoothScrollLinearLayoutManager extends LinearLayoutManager {
    LinearSmoothScroller smoothScroller;
    int rowHeight;
    public int currentScrollY = 0;

    public SmoothScrollLinearLayoutManager(Context context) {
        super(context);
    }

    public void init(Context context) {
        rowHeight = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, context.getResources().getDisplayMetrics());
        smoothScroller = new LinearSmoothScroller(context) {
            @Override
            public PointF computeScrollVectorForPosition(int targetPosition) {
                Log.v("nazmul-hossain",  "yDelta targetPosition: " + targetPosition);
                int yDelta = calculateCurrentDistanceToPosition(targetPosition);
                return new PointF(0, yDelta);
            }

            // This is the important method. This code will return the amount of time it takes to scroll 1 pixel.
            // This code will request X milliseconds for every Y DP units.
            @Override
            protected float calculateSpeedPerPixel(DisplayMetrics displayMetrics) {
                return 40 / TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, displayMetrics);
            }
        };
    }

    private int calculateCurrentDistanceToPosition(int targetPosition) {
        int targetScrollY = targetPosition * rowHeight;
        int deltaScrollY = targetScrollY - currentScrollY;
        Log.v("nazmul-hossain",  "deltaScrollY: " + deltaScrollY);
        return deltaScrollY;
    }

    @Override
    public void smoothScrollToPosition(RecyclerView recyclerView, RecyclerView.State state, int position) {
        Log.v("nazmul-hossain", "smoothScrollToPosition: " + position);
//        // A good idea would be to initialize this instance in some initialization method, and just set the target position in this method.
        smoothScroller.setTargetPosition(position);
        startSmoothScroll(smoothScroller);
    }

    @Override
    public void scrollToPositionWithOffset(int position, int offset) {
        super.scrollToPositionWithOffset(position, offset);
    }


    //        @Override
//    public int scrollVerticallyBy(int dy, RecyclerView.Recycler recyclerView, RecyclerView.State state) {
//
//        int prevDelta = dy;
//        if (getScrollState() == SCROLL_STATE_DRAGGING)
//            delta = (int)(delta > 0 ? Math.max(delta * MANUAL_SCROLL_SLOW_RATIO, 1) : Math.min(delta * MANUAL_SCROLL_SLOW_RATIO, -1));
//
//        // MANUAL_SCROLL_SLOW_RATIO is between 0 (no manual scrolling) to 1 (normal speed) or more (faster speed).
//        // write your scrolling logic code here whereby you move each view by the given delta
//
//        if (getScrollState() == SCROLL_STATE_DRAGGING)
//            delta = prevDelta;
//
//        return delta;
//    }
}
