package com.revesoft.itelmobiledialer.customview.editcodeview;

public interface EditCodeListener {
    void onCodeReady(String code);
}

