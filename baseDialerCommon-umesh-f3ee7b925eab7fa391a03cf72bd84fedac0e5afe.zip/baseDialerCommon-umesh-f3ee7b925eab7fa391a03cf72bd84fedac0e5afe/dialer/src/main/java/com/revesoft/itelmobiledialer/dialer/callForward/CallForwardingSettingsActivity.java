package com.revesoft.itelmobiledialer.dialer.callForward;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


public class CallForwardingSettingsActivity extends BaseActivity {

    /**
     * Called when the activity is first created.
     */
    private Button btnChangeNumber, btnSetNumber, btnDisablCallForwarding;
    private TextView tvCallForwardNumber;
    private boolean isNumberExists = false;
    ProgressDialog pD;
    Handler handler;
    volatile boolean gotResponse = false;
    Toolbar toolbar;

    public static void startForTesting(Context context) {
        Intent intent = new Intent(context, CallForwardingSettingsActivity.class);
        context.startActivity(intent);
    }


    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            gotResponse = true;
            hideProgressDialog();
            String action = intent.getAction();
            if (Constants.CALL_FORWARDING_QUERY_ACTION.equals(action)) {
                String number = intent.getStringExtra(Constants.CALL_FORWARDING_NUMBER);
                if (number == null) {
                    btnChangeNumber.setVisibility(View.GONE);
                    btnDisablCallForwarding.setVisibility(View.GONE);
                    btnSetNumber.setVisibility(View.VISIBLE);
                    isNumberExists = false;
                    tvCallForwardNumber.setVisibility(View.VISIBLE);
                    tvCallForwardNumber.setText(getString(R.string.call_forwarding_no_number));
                    PreferenceDataManager.quickPut(AccountPreference.Keys.IS_ENABLED_CALL_FORWARDING, false);

                } else {
                    btnChangeNumber.setVisibility(View.VISIBLE);
                    btnDisablCallForwarding.setVisibility(View.VISIBLE);
                    btnSetNumber.setVisibility(View.GONE);
                    isNumberExists = true;
                    tvCallForwardNumber.setVisibility(View.VISIBLE);
                    tvCallForwardNumber.setText(String.format("%s: %s", getString(R.string.call_forwarding_your_number), number));
                    PreferenceDataManager.quickPut(AccountPreference.Keys.CALL_FORWARDING, number);
                    PreferenceDataManager.quickPut(AccountPreference.Keys.IS_ENABLED_CALL_FORWARDING, true);


                }
            } else if (Constants.CALL_FORWARDING_DISABLE_ACTION.equals(action)) {
                String status = intent.getStringExtra(Constants.CALL_FORWARDING_DISABLE_STATUS);
                if (status == null) {
                    Toast.makeText(getApplicationContext(), R.string.call_forwarding_disable_failed, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), R.string.call_forwarding_disabled_successfully, Toast.LENGTH_SHORT).show();
                    btnChangeNumber.setVisibility(View.GONE);
                    btnDisablCallForwarding.setVisibility(View.GONE);
                    btnSetNumber.setVisibility(View.VISIBLE);
                    isNumberExists = false;
                    tvCallForwardNumber.setVisibility(View.VISIBLE);
                    tvCallForwardNumber.setText(getString(R.string.call_forwarding_no_number));
                    PreferenceDataManager.quickPut(AccountPreference.Keys.IS_ENABLED_CALL_FORWARDING, false);

                }
            }
        }
    };

    private void showProgressDialog() {
        pD = ProgressDialog.show(this, "",
                getString(R.string.please_wait), true);
    }

    private void hideProgressDialog() {
        try {
            if (pD != null && pD.isShowing()) {
                pD.dismiss();
                pD = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_forwarding);
        handler = new Handler();
        btnSetNumber = (Button) findViewById(R.id.btn_set_number);
        btnChangeNumber = (Button) findViewById(R.id.btn_change_number);
        btnDisablCallForwarding = (Button) findViewById(R.id.btn_disable_call_forwarding);
        tvCallForwardNumber = (TextView) findViewById(R.id.tv_call_forward_number);
        handleToolbar();

        btnSetNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CallForwardingSettingsActivity.this, CallForwardingSetNumberActivity.class);
                intent.putExtra("isNumberexists", false);
                startActivityForResult(intent, 0);
            }
        });
        btnChangeNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CallForwardingSettingsActivity.this, CallForwardingSetNumberActivity.class);
                intent.putExtra("isNumberexists", true);
                startActivityForResult(intent, 0);

            }
        });
        btnDisablCallForwarding.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgressDialog();
                sendCallForwardingDisableRequest();
                startCountDown();
            }
        });

        IntentFilter mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(Constants.CALL_FORWARDING_QUERY_ACTION);
        mIntentFilter.addAction(Constants.CALL_FORWARDING_DISABLE_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(mBroadcastReceiver, mIntentFilter);

        sendRequest();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    private void sendRequest() {
        btnSetNumber.setVisibility(View.GONE);
        btnChangeNumber.setVisibility(View.GONE);
        btnDisablCallForwarding.setVisibility(View.GONE);
        tvCallForwardNumber.setVisibility(View.GONE);

        showProgressDialog();
        sendCallForwardingQueryRequest();
        startCountDown();
    }

    private void startCountDown() {
        gotResponse = false;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!gotResponse) {
                    hideProgressDialog();
                    Toast.makeText(getApplicationContext(), R.string.network_dialog_title, Toast.LENGTH_SHORT).show();
                }
            }
        }, 10000);
    }

    private void sendIntentMessageToDialer(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendCallForwardingQueryRequest() {
        sendIntentMessageToDialer("call_forwarding_query_request", "");
    }

    private void sendCallForwardingDisableRequest() {
        sendIntentMessageToDialer("call_forwarding_disable_request", "");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mBroadcastReceiver);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode == RESULT_OK) {
            String forwardedNumber = data.getStringExtra("forwarded_number");
            if (!"".equals(forwardedNumber)) {
                btnChangeNumber.setVisibility(View.VISIBLE);
                btnDisablCallForwarding.setVisibility(View.VISIBLE);
                btnSetNumber.setVisibility(View.GONE);
                isNumberExists = true;
                tvCallForwardNumber.setVisibility(View.VISIBLE);
                tvCallForwardNumber.setText(String.format("%s: %s", getString(R.string.call_forwarding_your_number), forwardedNumber));
            }
        }
    }
    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle(R.string.call_forwarding);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return false;
    }




}
