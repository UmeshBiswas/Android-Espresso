package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.media.AudioManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.iftalab.runtimepermission.DangerousPermission;
import com.iftalab.runtimepermission.PermissionDialogActivity;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.SeenSender;
import com.revesoft.itelmobiledialer.chat.chatWindow.media.AudioMessage;
import com.revesoft.itelmobiledialer.chat.chatWindow.media.ChatMediaPlayer;
import com.revesoft.itelmobiledialer.chat.chatWindow.media.ChatMediaUtil;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import androidx.appcompat.widget.AppCompatSeekBar;

import static android.content.Context.AUDIO_SERVICE;

/**
 * @author Ifta on 12/14/2017.
 */

public class AudioMessageViewHolder extends RetryAndProgressMessageViewHolder implements AudioManager.OnAudioFocusChangeListener {
    private final ImageView ivPlayPause;
    private final AppCompatSeekBar seekBar;
    private final TextView tvDuration;
    private final TextView tvPlayDuration;

    public AudioMessageViewHolder(View view) {
        super(view);
        ivPlayPause = view.findViewById(R.id.ivPlayPause);
        seekBar = view.findViewById(R.id.seekBar);
        tvDuration = view.findViewById(R.id.tvDuration);
        tvPlayDuration = view.findViewById(R.id.tvPlayDuration);
    }

    public void bindView(Message message) {
        super.bindView(message);
        ivPlayPause.setVisibility(View.VISIBLE);
        seekBar.setVisibility(View.VISIBLE);
        tvDuration.setVisibility(View.VISIBLE);
        tvPlayDuration.setVisibility(View.VISIBLE);
        handleDuration(message);
        handlePlayDuration(message);
        handleFilePlaying(message);
        seekBar.setProgress(0);
    }

    private void handlePlayDuration(Message message) {
        tvPlayDuration.setText(Supplier.getString(R.string.playTimeZero));
    }

    private void handleFilePlaying(final Message message) {
        ivPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                    checkAudioFocus();
                    if (ChatUtil.isDownloadingNow(message)) {
                        return;
                    }
                    SeenSender.getAccess().sendSeen(message);
//                    if (PreferenceDataManager.quickGet(Constants.VISUALIZATION_OF_VOICE_MESSAGES, true)) {
//                        AudioVisualizationPlayerActivity.startAudioVisualization(AppContext.getAccess().getContext(), message.filePathLocal, true);
//                    } else {
                        AudioMessage audioMessage = new AudioMessage(message.callerId, message.filePathLocal, seekBar, tvPlayDuration, ivPlayPause);
                        ChatMediaPlayer.getInstance().handleAudioClick(audioMessage);

//                    }
                } else {
                    PermissionDialogActivity.takePermission(ivPlayPause.getContext(),PermissionDialogActivity.PermissionType.Storage);
                }
            }
        });
    }

    private void checkAudioFocus() {
        AudioManager mAudioManager = (AudioManager) AppContext.getAccess().getContext().getSystemService(AUDIO_SERVICE);
        if (mAudioManager.isMusicActive()) {
            int result = mAudioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN);
        }
    }


    private void handleDuration(Message message) {
        if (message.filePathLocal != null) {
            tvDuration.setText(ChatMediaUtil.getAudioFileDuration(message.filePathLocal));
        } else {
            tvDuration.setText("--:--");
        }
    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        Log.d("AudioManager", "get audio focus and pause others");
    }
}
