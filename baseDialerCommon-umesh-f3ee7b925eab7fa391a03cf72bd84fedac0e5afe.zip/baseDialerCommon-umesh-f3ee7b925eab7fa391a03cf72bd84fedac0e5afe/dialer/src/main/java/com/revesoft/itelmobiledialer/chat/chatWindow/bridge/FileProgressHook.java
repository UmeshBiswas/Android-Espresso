package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;

import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Gui;

import java.util.HashMap;

/**
 * Created by Acer on 3/21/2017.
 */

public class FileProgressHook {


    public static HashMap<String, String> mapCallerIDPercentage = new HashMap<>();
    public static HashMap<String, TextView> mapCallerIdTextView = new HashMap<>();
    public static HashMap<String, ProgressBar> mapCallerIdProgressBar = new HashMap<>();


    public static void watchProgressWith(TextView tvPercentage, String callerId) {
        mapCallerIdTextView.put(callerId, tvPercentage);
        Gui.get().run(() -> {
            if (mapCallerIDPercentage.containsKey(callerId)) {
                tvPercentage.setText(mapCallerIDPercentage.get(callerId));
            } else {
                tvPercentage.setText("0%");
            }
        });

    }

    public static void publishProgress(String callerId, String progress) {
        mapCallerIDPercentage.put(callerId, progress);
        Gui.get().run(()->{
            TextView tv = mapCallerIdTextView.get(callerId);
            if (tv != null) {
                tv.setText(progress);
                tv.invalidate();
            }
        });
    }

    public static void deleteEntry(String callerId) {
        mapCallerIDPercentage.remove(callerId);
        mapCallerIdTextView.remove(callerId);
    }

    public static void addTextViewEntry(TextView tvPercentage, String callerId) {

        mapCallerIdTextView.remove(callerId);
        mapCallerIdTextView.put(callerId, tvPercentage);
        if (mapCallerIDPercentage.containsKey(callerId)) {
            tvPercentage.setText(mapCallerIDPercentage.get(callerId));
            Log.e("setting", "callerID" + callerId + " perc: " + mapCallerIDPercentage.get(callerId) + "  " + tvPercentage.hashCode());
        } else
            tvPercentage.setText("0%");
    }

    public static void addNewProgressEntry(String callerId, String percentage) {
        mapCallerIDPercentage.put(callerId, percentage);
        TextView tv = mapCallerIdTextView.get(callerId);
        if (tv != null)
            tv.setText(percentage);
        ProgressBar progressBar = mapCallerIdProgressBar.get(callerId);
        if (progressBar != null)
            progressBar.setProgress(Integer.parseInt(percentage.replaceAll("%", "").trim()));
    }

    public static void addNewProgressBarEntry(String callerId, ProgressBar progressBar) {
        mapCallerIdProgressBar.remove(callerId);
        mapCallerIdProgressBar.put(callerId, progressBar);
        if (mapCallerIdProgressBar.containsKey(callerId)) {
            progressBar.setProgress(Integer.parseInt(mapCallerIDPercentage.get(callerId).replaceAll("%", "").trim()));
            Log.e("setting", "callerID" + callerId + " perc: " + mapCallerIDPercentage.get(callerId) + "  " + mapCallerIdProgressBar.hashCode());
        } else {
            progressBar.setMax(100);
            progressBar.setProgress(0);
        }
    }

    public static void clearAll() {
        mapCallerIDPercentage.clear();
        mapCallerIdTextView.clear();
        mapCallerIdProgressBar.clear();
    }
}
