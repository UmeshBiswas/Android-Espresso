package com.revesoft.itelmobiledialer.chat.cameraAndImage;

class CaptionMedia {
    String filePath;
    String caption;

    CaptionMedia(String filePath, String caption) {
        this.filePath = filePath;
        this.caption = caption;
    }
}
