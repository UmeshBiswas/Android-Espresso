package com.revesoft.itelmobiledialer.ims.MediaDetails;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.ims.AudioPlayerActivity;
import com.revesoft.itelmobiledialer.ims.ImageDialog;
import com.revesoft.itelmobiledialer.ims.ImageResizeUtil;
import com.revesoft.itelmobiledialer.ims.VideoPlayerActivity;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.GenericFileProvider;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

/**
 * Created by Acer on 6/8/2017.
 */

public class MediaFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>{
    public static final String PAGE_TITLE = "PAGE_TITLE";
    String fragmentName = null;
    public TextView textView;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private ImageGalleryAdapter mAdapter;
    private ImageView imageView;
    public FrameLayout frameLayout;
    private static final String TAG = "MediaActivityFragment";
    private ArrayList<Message> messageArrayList = new ArrayList<>();


    public MediaFragment(){

    }



    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.activity_media_detail_media_fragment, null);
        Log.i("sayma_med", "media detail");
        RelativeLayout relativeLayout = view.findViewById(R.id.cont_pager_item_root);
        textView = view.findViewById(R.id.textView);
        textView.setText(fragmentName);
        getLoaderManager().initLoader(3000, null, this);
        mRecyclerView = view.findViewById(R.id.recycler_view);
        int displayWidth = ImageResizeUtil.getDisplayWidth(getActivity());
        int displayHeight = ImageResizeUtil.getDisplayHeight(getActivity());
        mAdapter = new ImageGalleryAdapter(displayWidth / 3, displayWidth / 3);
        mLayoutManager = new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(mLayoutManager);
        return view;
    }

    public void updateMessageList() {
        messageArrayList.clear();
        for(int i =0;  getActivity() != null  && i<messageList.size();i++) {
            MimeType mimeType = messageList.get(i).mimeType;
            Log.e("media-doc", mimeType.toString());
            if (mimeType == MimeType.Audio || mimeType == MimeType.Video || mimeType == MimeType.Image) {
                File file = new File(messageList.get(i).filePath);
                if (file.exists())
                    messageArrayList.add(messageList.get(i));
                Log.d("media", Integer.toString(messageArrayList.size()));
            }

        }
        Log.e("media", Integer.toString(messageArrayList.size()));
        mAdapter.notifyDataSetChanged();

    }


    public static MediaFragment getInstance(String pageTitle, int icon){
        MediaFragment item = new MediaFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PAGE_TITLE,pageTitle);
        //bundle.putInt("PAGE_ICON",icon);
        //bundle.putString("CURRENCY","Dollar");
        item.setArguments(bundle);
        return item;
    }

    public void setFragmentName(String fragmentName){
        this.fragmentName = fragmentName;
        Log.e("fragment name",fragmentName);
    }

    private boolean isGroup;
    private String phoneNumberOrGroupNumber;

    public void setFragmentParams(boolean isGroup, String phoneNumberOrGroupNumber){
        this.isGroup = isGroup;
        this.phoneNumberOrGroupNumber = phoneNumberOrGroupNumber;
        Log.e("fragment param", this.phoneNumberOrGroupNumber);
    }

    public String getFragmentName(){
        return fragmentName;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new SQLiteCursorLoader(getActivity()) {
            @Override
            public Cursor loadInBackground() {
                Log.i("MediaDetailsActivity", "in MESSAGE_QUERY_LOADER");
                Cursor cursor = null;
                try {
                    if (isGroup) {
                        cursor = MessageRepo.get().getImsWithMediaByGroupId(phoneNumberOrGroupNumber);
                    } else {
                        cursor = MessageRepo.get().getImsWithMediaByNumber(phoneNumberOrGroupNumber);
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    this.registerContentObserver(cursor, DatabaseConstants.MESSAGE_URI);
                }

                return cursor;
            }
        };
    }

    private Cursor mediaMessageCursor;
    private ArrayList<Message> messageList = new ArrayList<>();

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null) {
            mediaMessageCursor = data;
        }
        Log.i("--------", "in MESSAGE_QUERY_LOADER_FINISHED_2");
        messageList.clear();
        if (mediaMessageCursor != null) {
            if (mediaMessageCursor.moveToFirst()) {
                do {
                    messageList.add(new Message(mediaMessageCursor));
                }
                while (mediaMessageCursor.moveToNext());

            }
        }
        Log.e("media++", Integer.toString(messageList.size()));
        updateMessageList();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        messageList.clear();
        updateMessageList();
    }


    public interface FragmentItemCallback{
        void onPagerItemClick(String message);
    }

    public class ImageGalleryAdapter extends RecyclerView.Adapter<ImageGalleryAdapter.ViewHolder> {
        private Cursor mCursor;
        private int imageWidth;
        private int imageHeight;

        boolean[] selected = new boolean[1];

        public ImageGalleryAdapter(int imageWidth, int imageHeight) {
            Log.i("sayma_med", "media detail adapter");
            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // initialize a new view
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_gallery_item, parent, false);

            ImageGalleryAdapter.ViewHolder vh = new ImageGalleryAdapter.ViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(ImageGalleryAdapter.ViewHolder holder, int position) {


            holder.mImageSend.setVisibility(View.GONE);
            if(messageArrayList.get(position).mimeType == MimeType.Audio)
            {
                holder.mImageView.setImageResource(R.drawable.audio_down);
                holder.mVideoIconOverlay.setVisibility(View.GONE);

            }
            else
            {
                Glide.with(getActivity())
                        .load(messageArrayList.get(position).filePath)
                        .centerCrop()
                        .crossFade()
                        .error(R.drawable.invalid_image_file)
                        .into(holder.mImageView);
                if (messageArrayList.get(position).mimeType == MimeType.Video) {
                    holder.mVideoIconOverlay.setVisibility(View.VISIBLE);
                } else {
                    holder.mVideoIconOverlay.setVisibility(View.GONE);
                }
            }

        }

        @Override
        public int getItemCount() {

            return messageArrayList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            // each data item is just a string in this case

            public ImageView mImageView;
            public ImageView mImageSend;
            public View mSelectedBackground;
            public String mImageFilepath;
            public ImageView mVideoIconOverlay;
            public TextView textViewInfo;

            public ViewHolder(View v) {
                super(v);

                mImageView = v.findViewById(R.id.imageViewItem);
                mImageSend = v.findViewById(R.id.imageButtonImageSend);
                mSelectedBackground = v.findViewById(R.id.imageItemBackground);
                mVideoIconOverlay = v.findViewById(R.id.video_icon_overlay);
                textViewInfo = v.findViewById(R.id.tv_info);
                ViewGroup.LayoutParams layoutParams = mSelectedBackground.getLayoutParams();
                layoutParams.height = imageHeight;
                layoutParams.width = imageWidth;
                mSelectedBackground.setLayoutParams(layoutParams);

                mImageSend.setOnClickListener(this);
                LinearLayout.LayoutParams ImageLayoutParams = new LinearLayout.LayoutParams(imageWidth, imageHeight);
                mImageView.setLayoutParams(ImageLayoutParams);
                mImageView.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {

                switch (view.getId()) {
                    case R.id.imageViewItem:
                        Log.d(TAG, "Selected item position " + getAdapterPosition());
                        Log.d("MediaGalleryActivity", "Item clicked");
                        openFileContent( new File(messageArrayList.get(getAdapterPosition()).filePath));
                        break;
                    default:
                        break;
                }
            }
        }

        public void swapCursor(Cursor cursor) {
            mCursor = cursor;
            if (cursor != null)
                selected = new boolean[cursor.getCount()];
            notifyDataSetChanged();
        }

    }

    private void openFileContent(File file) {
        if (file == null)
            return;
        String fileMimeType = determineFileMimeType(file);
        Log.d("Mkhan", "File Name " + file.getName() + " Type " + fileMimeType);

        if (!file.exists())
            return;
        if (fileMimeType != null) {

            //
            if (fileMimeType.contains("image")) {
                try {
                    Intent intent = new Intent(getActivity(), ImageDialog.class);
                    intent.putExtra("FILE_PATH", file.getAbsolutePath());
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("Asif", "Exception in opening image file");
                }
            } else if (fileMimeType.contains("video")) {
                try {
                    Intent intent = new Intent(getActivity(), VideoPlayerActivity.class);
                    intent.putExtra("FILE_PATH", file.getAbsolutePath());
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("Asif", "Exception in opening video file");
                }
            } else if (fileMimeType.contains("audio")) {
                try {
                    Intent intent = new Intent(getActivity(), AudioPlayerActivity.class);
                    intent.putExtra("AUDIO_FILE_PATH", file.getAbsolutePath());
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("Asif", "Exception in opening audio file");
                }
            } else {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                String authority = AppContext.getAccess().getContext().getPackageName() + ".my.package.name.provider";
                Uri fileUri = GenericFileProvider.getUriForFile(AppContext.getAccess().getContext(), authority, file);
                Log.d("fileUri", "openDocument: fileUri " + fileUri);
                intent.setDataAndType(fileUri, fileMimeType);
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(intent, Supplier.getString(R.string.option));
                chooser.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                AppContext.getAccess().getContext().startActivity(chooser);
            }

        } else {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage("Can not determine file anInt").setNeutralButton("OK", null);
            Log.d(TAG, "Showing alert dialog: " + "can not determine file anInt");
            bld.create().show();
        }
    }

    private String determineFileMimeType(File file) {
        String mimeType = null;
        try {
            String fileUrl = file.toURI().toURL().toString();
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(fileUrl).toLowerCase();
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
        } catch (MalformedURLException e) {
            Log.e("Mkhan", "Exception in determineFileMimeType");
            e.printStackTrace();
            if (mimeType == null || mimeType.length() == 0) {
                mimeType = "application/octet-stream";
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            Log.e("Mkhan", "Exception in determineFileMimeType");
            if (mimeType == null || mimeType.length() == 0) {
                mimeType = "application/octet-stream";
            }
        }

        return mimeType;

    }


}
