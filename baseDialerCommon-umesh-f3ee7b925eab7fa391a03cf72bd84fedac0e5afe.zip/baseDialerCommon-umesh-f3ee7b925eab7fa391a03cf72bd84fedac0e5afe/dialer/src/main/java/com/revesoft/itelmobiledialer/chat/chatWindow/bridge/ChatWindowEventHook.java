package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;



import com.revesoft.itelmobiledialer.chat.chatWindow.Message;

import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Ifta on 2/26/2018.
 */

public class ChatWindowEventHook {
    private static ChatWindowEventListener chatWindowEventListener;
    public static void attachEventListener(ChatWindowEventListener chatWindowEventListener){
        ChatWindowEventHook.chatWindowEventListener = chatWindowEventListener;
    }

    public static void dispatchEvent(final ChatWindowEvent event){
        if(chatWindowEventListener !=null){
            if(chatWindowEventListener instanceof AppCompatActivity) {
                ((AppCompatActivity) chatWindowEventListener).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        chatWindowEventListener.onChatWindowEvent(event);
                    }
                });
            }
        }
    }

    public static void free() {
        chatWindowEventListener = null;
    }

    public static void dispatchEvent(final ChatWindowEvent event, final int data) {
        if(chatWindowEventListener !=null){
            if(chatWindowEventListener instanceof AppCompatActivity) {
                ((AppCompatActivity) chatWindowEventListener).runOnUiThread(() -> {
                    if(chatWindowEventListener!=null) {
                        chatWindowEventListener.onChatWindowEvent(event, data);
                    }
                });
            }
        }
    }
    public static void dispatchEvent(final ChatWindowEvent event, final Message message) {
        if(chatWindowEventListener !=null){
            if(chatWindowEventListener instanceof AppCompatActivity) {
                ((AppCompatActivity) chatWindowEventListener).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(chatWindowEventListener!=null) {
                            chatWindowEventListener.onChatWindowEvent(event, message);
                        }
                    }
                });
            }
        }
    }
}
