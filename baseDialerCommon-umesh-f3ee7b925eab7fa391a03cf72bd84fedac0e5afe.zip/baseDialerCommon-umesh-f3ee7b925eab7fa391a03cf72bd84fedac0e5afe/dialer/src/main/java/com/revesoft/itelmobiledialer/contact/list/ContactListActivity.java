package com.revesoft.itelmobiledialer.contact.list;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.revesoft.itelmobiledialer.block.BlockedContactActivity;
import com.revesoft.itelmobiledialer.interfaces.Controllable;
import com.revesoft.itelmobiledialer.interfaces.Searchable;
import com.revesoft.itelmobiledialer.util.NativeContactUtil;
import com.revesoft.itelmobiledialer.util.ViewSetup;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

public class ContactListActivity extends AppCompatActivity implements Controllable {
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);
        ViewSetup.setUpToolbar(this, getString(R.string.contacts), true);
        setupViewPager();
        setUpTabLayout();


    }

    private void setUpTabLayout() {
        List<String> tabNames = new ArrayList<>();
        tabNames.add(getString(R.string.all_contacts));
        tabNames.add(getString(R.string.appName_contacts));
        ViewSetup.setUpTabLayout(this, tabNames, viewPager);
    }

    List<Fragment> fragments = new ArrayList<>();

    private void setupViewPager() {
        fragments.add(ContactListFragment.newInstance(false, ContactType.ALL));
        fragments.add(ContactListFragment.newInstance(false, ContactType.APP));
        viewPager = ViewSetup.setUpViewPager(this, fragments);
    }

    @Override
    public void onControlRequest(ControlRequestType controlRequestType) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else if (item.getItemId() == R.id.actionBlocked) {
            startActivity(new Intent(ContactListActivity.this, BlockedContactActivity.class));
        }
//        else if(item.getItemId() == R.id.actionFavorite){
//            startActivity(new Intent(ContactListActivity.this, FavoriteContactsActivity.class));
//        }
        return super.onOptionsItemSelected(item);
    }

    SearchView searchView;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.contact_list, menu);
        final MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null && searchManager != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setIconifiedByDefault(true);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    Fragment currentFragment = getCurrentFragment();
                    Searchable searchable = null;
                    if (currentFragment instanceof Searchable) {
                        searchable = (Searchable) currentFragment;
                    }
                    if (searchable != null) {
                        if (TextUtils.isEmpty(newText)) {
                            searchable.search("");
                        } else {
                            searchable.search(newText);
                        }
                    }
                    return true;
                }
            });
        }
        return super.onCreateOptionsMenu(menu);
    }

    private Fragment getCurrentFragment() {
        return fragments.get(viewPager.getCurrentItem());
    }

    public void openAddNewContact(View view) {
        NativeContactUtil.startCreateContactAction(ContactListActivity.this);
    }
}
