package com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.Config.Features;
import com.revesoft.itelmobiledialer.chat.chatWindow.futureMessage.FutureMessageTimeDialogs;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Controllable;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.FutureMessageDateTimeListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageQuoteInfo;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.customview.AudioRecordVisualizerView;
import com.revesoft.itelmobiledialer.ims.OnFragmentInteractionListener;
import com.revesoft.itelmobiledialer.confide.OnRecordCompleteListener;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

@SuppressWarnings("all")
//import com.revesoft.itelmobiledialer.util.ExtAudioRecorder;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SoundRecorderFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SoundRecorderFragment extends Fragment {
    private static final String LOG_TAG = "SoundRecorderFragment";
    private static final String RECORD_DIR = "/BubbleToneMedia";
    Handler handler = null;

    AudioRecordVisualizerView visualizerView = null; //the ripple effect? :|
    CountDownTimer timer = null; //for counting down the time?
    private boolean isStoppedRecording = true;
    private FrameLayout recorderButton;
    private MediaRecorder mRecorder = null;
    private File mAudioFile = null;
    ImageButton mImageButtonCancel; //the playing part
    ImageView mImageButtonPlayPause;
    //how to quickGet the audio file path? :|
    RelativeLayout mRelativeLayoutAudioRecord, mRelativeLayoutAudioPlay; //important part :|
    public String audioPath = ""; //the file path? ^_^
    Boolean isPlaying = false; //flag?
    AudioPlayer audioPlayer; //for playing the audio?
    CountDownTimer audioPlayerTimer = null, audioPlayerTimerForVIew = null;
    AudioMessage audioMessage;
    SeekBar mSeekBar;
    TextView mTextViewTimer, mTextViewTimerPlayView;
    ImageView imageViewSoundRecord;
    public static final int AUDIO_PLAY_ACTIVITY_REQUEST_CODE = 1073;


    public ImageView ivSendNow, ivSendInFuture; //made public, beforehand it wasn't


    public SoundRecorderFragment() {
        // Required empty public constructor
    }


    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment SoundRecorderFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SoundRecorderFragment newInstance() {
        SoundRecorderFragment fragment = new SoundRecorderFragment();

        return fragment;
    }

    private static SoundRecorderFragment fragment;

    public static SoundRecorderFragment getInstance() {
        if (fragment == null) {
            fragment = new SoundRecorderFragment();
        }

        return fragment;
    }

    Controllable parentActivity; //Controllable, an interface
    OnRecordCompleteListener parent_activity; // for smoke chat

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handler = new Handler();
        isStoppedRecording = true;
        if (getActivity() instanceof Controllable) {
            parentActivity = (Controllable) getActivity();
        }
        if (getActivity() instanceof OnRecordCompleteListener) {
            parent_activity = (OnRecordCompleteListener) getActivity();
        }

    }

    int playButtonResourceId = R.drawable.ic_audio_play;
    int pauseButtonResourceId = R.drawable.ic_audio_pause;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.sound_recorder_fragment_layout, container, false);


        recorderButton = (FrameLayout) v.findViewById(R.id.recordSound);
        mTextViewTimer = (TextView) v.findViewById(R.id.tv_timer);
        mTextViewTimerPlayView = (TextView) v.findViewById(R.id.tv_timer_two_he);

        visualizerView = (AudioRecordVisualizerView) v.findViewById(R.id.visualizerView);
        imageViewSoundRecord = (ImageView) v.findViewById(R.id.iv_sound_record);
        //below part for recording task

        recorderButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Log.i(LOG_TAG, "recorderButton.setOnTouchListener: event.getAction():" + event.getAction());

                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    imageViewSoundRecord.setImageResource(R.drawable.sound_fragment__record_ongoing);
                    startRecording(); //recording started
                }

                if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL || /*event.getAction() == MotionEvent.ACTION_MOVE ||*/
                        event.getAction() == MotionEvent.ACTION_OUTSIDE || event.getAction() == MotionEvent.ACTION_BUTTON_RELEASE) {
                    imageViewSoundRecord.setImageResource(R.drawable.sound_fragment_start_record);
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            stopRecording();
                            visualizerView.setFactor(0);
                        }
                    }, 500);
                }

                return true;
            }
        });


        mSeekBar = (SeekBar) v.findViewById(R.id.seekBar_me);
        mSeekBar.setEnabled(false);
        mRelativeLayoutAudioRecord = (RelativeLayout) v.findViewById(R.id.rl_audio_record);
        mRelativeLayoutAudioPlay = (RelativeLayout) v.findViewById(R.id.rl_audio_play_she);
        mRelativeLayoutAudioRecord.setVisibility(View.VISIBLE);
        mRelativeLayoutAudioPlay.setVisibility(View.GONE);
        mImageButtonPlayPause = (ImageView) v.findViewById(R.id.imageViewPlayPause_he);


        //for playing and pausing the recorded audio
        mImageButtonPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isPlaying) {
                    if (new File(audioPath).length() <= 0) {
                        I.toast("Can not send empty file.", true);
                        Log.w(LOG_TAG, "Can not send empty file.");
                        if (mAudioFile != null && mAudioFile.exists())
                            mAudioFile.delete();
                        return;
                    }
                    if (audioPath != null) {
                        File file = new File(audioPath);
                        if (file.exists()) {
                            try {
                                String path = file.getAbsolutePath();
                                Log.i("asif", "filePath: " + path);
                                if (audioMessage == null)
                                    audioMessage = new AudioMessage(path);
                                if (audioMessage != null) {
                                    if (audioMessage.isCurrentlyPlaying()) {
                                        mImageButtonPlayPause.setImageResource(playButtonResourceId);
                                        audioPlayer.pauseAudio(audioMessage);
                                    } else {
                                        if (audioPlayer == null) {
                                            audioPlayer = new AudioPlayer();
                                        }
                                        mImageButtonPlayPause.setImageResource(pauseButtonResourceId);
                                        audioPlayer.playOrResumeAudio(audioMessage);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                Log.e("Asif", "Exception in opening audio file");
                            }
                        } else {
                            I.toast(Supplier.getString(R.string.file_does_not_exist));
                        }
                    }
                }
            }
        });
        mImageButtonCancel = (ImageButton) v.findViewById(R.id.imageButtonCancelAudioMe);
        mImageButtonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelRecord();
            }
        });
        ivSendNow = (ImageView) v.findViewById(R.id.ivSendAudioNow);
        ivSendInFuture = (ImageView) v.findViewById(R.id.ivSendAudioInFuture);
        if (!Features.hasFutureMessage()) {
            ivSendInFuture.setVisibility(View.GONE);
        }
        ivSendNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (audioPath != null) {
                    Sender.getAccess().sendFile(audioPath);
                    if (parentActivity != null) {
                        parentActivity.onControlRequest(Controllable.RequestType.HideBottomFragments);
                    }
                }
            }
        });
        if (MessageQuoteInfo.isInQuoteMode) {
            ivSendInFuture.setVisibility(View.GONE);
        } else {
            if (Features.hasFutureMessage()) {
                ivSendInFuture.setVisibility(View.VISIBLE);
            }

        }
        ivSendInFuture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (audioPath != null) {
                    FutureMessageTimeDialogs.showDateTimePicker(new FutureMessageDateTimeListener() {
                        @Override
                        public void onDateTimePicked(Date formattedDateTime, boolean sendCurrentTimeStamp) {
                            Sender.getAccess().sendFutureFile(audioPath, formattedDateTime.getTime(), sendCurrentTimeStamp);
                            if (parentActivity != null) {
                                parentActivity.onControlRequest(Controllable.RequestType.HideBottomFragments);
                            }
                        }
                    });

                }
            }
        });
        return v;
    }

    private void alert(String message, String title) {
        if (getActivity() != null) {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage(message).setTitle(title).setNeutralButton(android.R.string.ok, null);
            Log.d(LOG_TAG, "Showing alert dialog: " + message);
            bld.create().show();
        }
    }

    private void startRecording() {
        Log.d(LOG_TAG, "start recording. isStoppedRecording: " + isStoppedRecording);
        if (!isStoppedRecording)
            return;

        try {
            mRecorder = new MediaRecorder();
            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            try {
                mAudioFile = createAudioFile();
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(LOG_TAG, "Could not create audio file.. returning.. " + e.getMessage());
                return;
            }
            mRecorder.setOutputFile(mAudioFile.getAbsolutePath());
//            if (Build.VERSION.SDK_INT > 9) {
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
//            } else {
//                mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
//            }
//            mRecorder.setAudioSamplingRate(8000);

            try {
                mRecorder.prepare();
            } catch (Exception e) {
                Log.e(LOG_TAG, "prepare() failed: " + e.getMessage());
                return;
            }

            try {
                mRecorder.start();
            } catch (IllegalStateException e) {
                Log.e(LOG_TAG, "Audio recorder start() failed :" + e.getMessage());
                alert("Can't access microphone", "Error");
                return;
            }

            isStoppedRecording = false;

            timer = new CountDownTimer(600000, 500) {
                int count = 0;
                String time = "00:00";

                public void onTick(final long millisUntilFinished) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                count++;
                                long timePassed = 600000 - millisUntilFinished;
                                String hms = String.format(Locale.ENGLISH, "%02d:%02d",
                                        TimeUnit.MILLISECONDS.toMinutes(timePassed) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(timePassed)),
                                        TimeUnit.MILLISECONDS.toSeconds(timePassed) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(timePassed)));

                                int maxAmplitude = mRecorder.getMaxAmplitude();
                                visualizerView.setFactor(maxAmplitude / 250);
                                mTextViewTimer.setText(hms);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }

                public void onFinish() {
                    count = 0;
                    time = "00:00";
                    stopRecording();
                    visualizerView.setFactor(0);
                }
            }.start();
            Log.d(LOG_TAG, "Recording Started");
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(LOG_TAG, "startRecording failed: " + e.getMessage());
        }

    }

    private void stopRecording() {
        Log.d(LOG_TAG, "Stop recording. isStoppedRecording: " + isStoppedRecording);
        if (isStoppedRecording)
            return;
        try {
            if (timer != null)
                timer.cancel();
            isStoppedRecording = true;

            mRecorder.stop();
            mRecorder.release();
            mRecorder = null;

            onRecordComplete(mAudioFile.getAbsolutePath());
            Log.d(LOG_TAG, "Recording Stopped");
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(LOG_TAG, "stopRecording failed: " + e.getMessage());
        }
    }

    private File createAudioFile() throws IOException {
        // Create an Audio file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(new Date());
        String audioFileName = "RECORDING_" + timeStamp + ".m4a";
        File recordDir = new File(Environment.getExternalStorageDirectory() + RECORD_DIR);
        if (!recordDir.exists()) {
            recordDir.mkdir();
        }

        Log.i(LOG_TAG, "file created: " + audioFileName);
        return new File(recordDir, audioFileName);
    }


    public void onRecordComplete(String path) {
        if (new File(path).length() <= 0) {
            I.toast("Can not send empty file.", true);
            Log.w(LOG_TAG, "Can not send empty file.");
            if (mAudioFile != null && mAudioFile.exists()) {
                mAudioFile.delete();
            }
            return;
        }
        long duration = new AudioMessage(path).duration;
        if (duration > 1000) {
            Log.d(LOG_TAG, "Audio Recording OnrecordComplete Called");
            audioPath = path;

            mRelativeLayoutAudioRecord.setVisibility(View.GONE);
            mRelativeLayoutAudioPlay.setVisibility(View.VISIBLE);
            String hms = String.format(Locale.ENGLISH, "%02d:%02d",
                    TimeUnit.MILLISECONDS.toMinutes(duration) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(duration)),
                    TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)));
            mTextViewTimerPlayView.setText(hms);
            mTextViewTimer.setText("00:00");

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        audioPath =
                null;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.d(LOG_TAG, "RequestCode: " + resultCode + " " + resultCode + " ");
        if (requestCode == AUDIO_PLAY_ACTIVITY_REQUEST_CODE) {
            if (data != null && data.getBooleanExtra("isFuture", false)) {
                long time = data.getLongExtra("time", 0);
                String path = data.getStringExtra("resultFilePath");
                ArrayList<String> paths = new ArrayList<>();
                paths.add(path);

            } else if (resultCode == -1) {
                String filePath = data.getStringExtra("resultFilePath");
            }
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "Audio recorder dialog on Puase");

        if (mRecorder != null) {

            I.toast("Recording caneled");
            try {
                mRecorder.stop();
            } catch (RuntimeException e) {
                // TODO: handle exception
                if (mAudioFile != null && mAudioFile.exists()) {
                    mAudioFile.delete();
                }
                e.printStackTrace();

            }
            mRecorder.release();
            mRecorder = null;
        }
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
    }


    class AudioMessage {
        long duration;
        long currentPosition = 0;
        String filePath;
        boolean isCurrentlyPlaying = false;
        //   ImageView playPauseIcon;
        //   TextView playPauseTextView;
        //   TextView durationTextView;

        /**
         * Constructor.
         *
         * @param filepath : absolute path of the audio file.
         */
        public AudioMessage(String filepath) {
            filePath = filepath;
            duration = getDurationInMilliSeconds(filePath);
        }

        /**
         * Extracts the duration from the given filepath.
         *
         * @param filePath : absulate path of the audio file.
         * @return : duration of the audio file in milliseconds long
         */
        private long getDurationInMilliSeconds(String filePath) {
            try {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD) {
                    MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                    try {
                        metaRetriever.setDataSource(filePath);
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        return 0;
                    }
                    String duration = metaRetriever
                            .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    Log.d("Asif", "Duration before parsing - " + duration);
                    metaRetriever.release();
                    return Long.parseLong(duration);
                } else {
                    return 0;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return 0;
            }
        }

        /**
         * Changes the necessary UI when the streaming of this audio message is
         * played
         */
        public void changeViewsPlayed() {
            isCurrentlyPlaying = true;
            mImageButtonPlayPause.setImageDrawable(getResources().getDrawable(pauseButtonResourceId));
//        playPauseTextView.setText(getResources().getString(
//                R.string.pause_audio_im));
        }

        /**
         * Changes the necessary UI when the streaming of this audio message is
         * paused
         */
        public void changeViewsWhenPaused() {
            isCurrentlyPlaying = false;
            mImageButtonPlayPause.setImageDrawable(getResources().getDrawable(
                    playButtonResourceId));
//        playPauseTextView.setText(getResources().getString(
//                R.string.play_audio_im));
        }

        /**
         * Parses the millisecond duration to a readable minute:seconds string
         * structure
         *
         * @param milliseconds : duration in long
         * @return : readable duration in String
         */
        public String parseDuration(long milliseconds) {
            if (milliseconds <= 0)
                return "0:00";
            String out = "";
            int sec = (int) (milliseconds % 60000) / 1000;
            int min = (int) milliseconds / 60000;
            String seconds = (sec < 10) ? ("0" + sec) : (sec + "");
            out = min + ":" + seconds;
            Log.d("Asif", "Duration after parsing - " + out);
            return out;
        }

        // getter setters
        // duration
        public long getDuration() {
            return duration;
        }

        public void setDuration(long duration) {
            this.duration = duration;
        }

        // filepath
        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        // current position
        public int getCurrentPosition() throws ArithmeticException {
            return new BigDecimal(currentPosition).intValueExact();
        }

        /**
         * Sets the Current position in the streaming
         *
         * @param currentPosition
         */
        public void setCurrentPosition(long currentPosition) {
            this.currentPosition = currentPosition;
            setDurationText(currentPosition);
        }

        /**
         * Checks if this audio message is currently playing or not
         *
         * @return true if currently playing, otherwise false
         */
        public boolean isCurrentlyPlaying() {
            return isCurrentlyPlaying;
        }

        /**
         * Sets if this audio message is currently streaming or not
         *
         * @param isCurrentlyPlaying
         */
        public void setIsCurrentlyPlaying(boolean isCurrentlyPlaying) {
            this.isCurrentlyPlaying = isCurrentlyPlaying;
        }

        // playPause Icon
        public ImageView getPlayPauseIcon() {
            //   return playPauseIcon;
            return null;
        }

        public void setPlayPauseIconImageView(ImageView playPauseIcon) {
//        this.playPauseIcon = playPauseIcon;
//
//        this.playPauseIcon.setImageDrawable(getResources().getDrawable(
//                R.drawable.ic_message_audio_play));
        }

        public void setPlayPauseIcon(Context context, int id) {
            //     this.playPauseIcon.setImageDrawable(getResources().getDrawable(id));
        }

        // play pause text view
        public TextView getPlayPauseTextView() {
            //   return playPauseTextView;
            return null;
        }

        public void setPlayPauseTextView(TextView playPauseTextView) {
//        this.playPauseTextView = playPauseTextView;
//        this.playPauseTextView.setText(R.string.play_audio_im);
        }

        public void setPlayPauseTextViewText(String text) {
            //   this.playPauseTextView.setText(text);
        }

        // duration textview
        public void setDurationTextView(TextView textView) {
//        this.durationTextView = textView;
//        this.durationTextView.setText("   (" + getDuration(filePath) + ")   ");
        }

        private String getDuration(String filePath) {
            // load data file
            try {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD) {
                    MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                    try {
                        metaRetriever.setDataSource(filePath);
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        return "00:00";
                    }
                    String out = "";
                    // convert duration to minute:seconds
                    String duration = metaRetriever
                            .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    Log.d("Asif", "Duration before parsing - " + duration);
                    long dur = Long.parseLong(duration);
                    int sec = (int) (dur % 60000) / 1000;
                    int min = (int) dur / 60000;
                    // String seconds = String.valueOf((dur % 60000) / 1000);
                    //
                    // String minutes = String.valueOf(dur / 60000);
                    String seconds = (sec < 10) ? ("0" + sec) : (sec + "");
                    out = min + ":" + seconds;
                    /*
                     * if (seconds.length() == 1) { txtTime.setText("0" + minutes + ":0"
                     * + seconds); }else { txtTime.setText("0" + minutes + ":" +
                     * seconds); }
                     */
                    Log.d("Asif", "Duration after parsing - " + out);
                    // close object
                    metaRetriever.release();
                    return out;
                } else {
                    return "00:00";
                }
            } catch (Exception e) {
                return "00:00";
            }
        }

        /**
         * Sets the duration in the durationTextView
         *
         * @param duration
         */
        public void setDurationText(long duration) {
            //    durationTextView.setText("   (" + parseDuration(duration) + ")   ");
        }
    }

    class AudioPlayer extends MediaPlayer {
        /**
         * last audio message the player was playing
         * <p>
         * when a new play request comes while the player is already playing,
         * player will call the pause function of the previous request, start
         * processing the request, remove the previous request from the
         * variable, and store the new message in the var
         * </p>
         */
        AudioMessage currentlyPlaying = null;

        public AudioPlayer() {
            super();
            setScreenOnWhilePlaying(true);
            setAudioStreamType(AudioManager.STREAM_MUSIC);
        }

        /**
         * The player puts its current streaming to pause and plays/resumes the
         * audioMessage
         *
         * @param audioMessage : AudioMessage to play/resume
         */
        public void playOrResumeAudio(final AudioMessage audioMessage) {
            try {
                if (isPlaying()) {
                    pauseAudio(currentlyPlaying);
                }
                currentlyPlaying = audioMessage;
                setDataSource(audioMessage.getFilePath());
                setOnCompletionListener(new OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        reset();
                        audioMessage.setCurrentPosition(0);
                        audioMessage.changeViewsWhenPaused();
                        audioMessage
                                .setDurationText(audioMessage.getDuration());
                        mSeekBar.setProgress(0);
                        String hms = String.format("%02d:%02d",
                                TimeUnit.MILLISECONDS.toMinutes(audioMessage.getDuration()) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(audioMessage.getDuration())),
                                TimeUnit.MILLISECONDS.toSeconds(audioMessage.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(audioMessage.getDuration())));
                        mTextViewTimerPlayView.setText(hms);
                    }
                });
                audioPlayer.prepare();
                // resume from previous pause
                final int currentPosition = audioMessage.getCurrentPosition();
                mSeekBar.setMax((int) audioMessage.getDuration());
                mSeekBar.setProgress(audioMessage.getCurrentPosition());
                audioPlayer.seekTo(currentPosition);
                audioPlayer.start();
                // cancel previous timers
                if (audioPlayerTimer != null) {
                    audioPlayerTimerForVIew.cancel();
                    audioPlayerTimer.cancel();
                }
                // start new timer
                audioPlayerTimerForVIew = new CountDownTimer(
                        audioMessage.getDuration() - currentPosition, 1000) {
                    long current = currentPosition;

                    @Override
                    public void onTick(long l) {
                        current += 1000;
                        long millis = current;
                        String hms = String.format("%02d:%02d",
                                TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                                TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                        mTextViewTimerPlayView.setText(hms);
                    }

                    @Override
                    public void onFinish() {
                    }
                }.start();
                audioPlayerTimer = new CountDownTimer(
                        audioMessage.getDuration() - currentPosition, 100) {
                    long current = currentPosition;

                    @Override
                    public void onTick(long l) {
                        current += 100;
                        audioMessage.setCurrentPosition(getCurrentPosition());
                        mSeekBar.setProgress(getCurrentPosition());
                    }

                    @Override
                    public void onFinish() {
                    }
                }.start();
                audioMessage.changeViewsPlayed();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ArithmeticException ae) {
                ae.printStackTrace();
            }
        }

        /**
         * Pauses the audioMessage
         *
         * @param audioMessage : which AudioMessage to pause
         */
        public void pauseAudio(AudioMessage audioMessage) {
            audioMessage.setCurrentPosition(getCurrentPosition());
            pause();
            reset();
            audioMessage.setIsCurrentlyPlaying(false);
            audioMessage.changeViewsWhenPaused();
            audioPlayerTimer.cancel();
            audioPlayerTimerForVIew.cancel();

        }
    }

    void cancelRecord() {
        mRelativeLayoutAudioPlay.setVisibility(View.GONE);
        mRelativeLayoutAudioRecord.setVisibility(View.VISIBLE);
        if (audioPlayerTimer != null)
            audioPlayerTimer.cancel();
        if (audioPlayerTimerForVIew != null)
            audioPlayerTimer.cancel();
        if (audioPlayer != null) {
            if (audioPlayer.isPlaying())
                audioPlayer.stop();
            audioPlayer.release();
            audioPlayer = null;
        }
        audioMessage = null;
        mSeekBar.setProgress(0);
        mImageButtonPlayPause.setImageResource(playButtonResourceId);
    }

}
