package com.revesoft.itelmobiledialer.block;

import android.app.Activity;
import android.app.ProgressDialog;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.BlockRepo;
import com.revesoft.itelmobiledialer.eventlistener.BlockStatusChangeData;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.processor.contactblock.ContactBlockHelper;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

public class ContactBlocker {
    private static final ContactBlocker ourInstance = new ContactBlocker();

    private ContactBlocker() {
    }

    public static ContactBlocker getInstance() {
        return ourInstance;
    }

    public void toggleContactBlockStatus(Activity activity, String translatedKeyNumber) {
        if (!Util.hasConnection(activity)) {
            I.toast(activity.getString(R.string.network_dialog_content));
            return;
        }
        final ProgressDialog progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage(activity.getResources().getString(R.string.please_wait));
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        AtomicBoolean isBlockedNow = new AtomicBoolean(false);
        Executor.ex(() -> {
            final boolean isCurrentlyBlocked = BlockRepo.get().isBlockedContact(translatedKeyNumber);
            new Timer().scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    Executor.ex(() -> {
                        isBlockedNow.set(BlockRepo.get().isBlockedContact(translatedKeyNumber));
                        if (isBlockedNow.get() != isCurrentlyBlocked) {
                            Gui.get().run(progressDialog::dismiss);

                            this.cancel();
                        }
                    });
                    if (System.currentTimeMillis() - scheduledExecutionTime() >= 11000) {
                        Gui.get().run(progressDialog::dismiss);
                        this.cancel();
                    }
                }
            }, 1000, 10000);
            if (isCurrentlyBlocked) {
                ContactBlockHelper.getAccess().unblock(translatedKeyNumber);
            } else {
                ContactBlockHelper.getAccess().block(translatedKeyNumber);
            }
        });
        progressDialog.setOnDismissListener(dialog -> {
            BlockStatusChangeData data = new BlockStatusChangeData(translatedKeyNumber, isBlockedNow.get());
            DialerEventHock.getInstance().dispatchEvent(DialerEvent.BlockStatusChangeEvent, data);
        });

    }
}
