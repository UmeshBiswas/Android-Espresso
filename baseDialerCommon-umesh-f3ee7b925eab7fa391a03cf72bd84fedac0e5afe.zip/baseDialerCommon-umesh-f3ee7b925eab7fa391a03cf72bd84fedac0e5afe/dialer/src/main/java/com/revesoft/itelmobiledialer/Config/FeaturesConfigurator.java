package com.revesoft.itelmobiledialer.Config;

public class FeaturesConfigurator {
    public static void prepare() {
        Features.newBuilder()
                .withCallerId(true)
                .withDid(true)
                .withPackages(true)
                .withRates(true)
                .withRecharge(true)
                .withSupport(true)
                .withTopUp(true)
                .withBurnMessage(false)
                .withFutureMessage(true)
                .withE2E(false)
                .build();
    }
}
