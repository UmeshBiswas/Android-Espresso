package com.revesoft.itelmobiledialer.chat.chatWindow.group;

import android.database.Cursor;
import android.text.TextUtils;

import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.util.Constants;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;

/**
 * @author Ifta
 */

public class Group implements Serializable {
    public String name, id, membersNumber, creatorsNumber;
    public String groupImagePath = "";
    public String[] numberOfGroupMembersIncludingMyNumberAndCreatorsNumber;
    public String[] curentMembers;
    public String[] allOtherMembersNumberButMe;
    public int memberCountButMe;
    public boolean isOpenGroup;
    public int groupType;
    public int isEncrypted = 0;
    public boolean isCreator = false;

    public Group(Cursor groupCursor) {
        String name = groupCursor.getString(groupCursor.getColumnIndex(DatabaseConstants.KEY_GROUP_NAME));
        String membersNumber = groupCursor.getString(groupCursor.getColumnIndex(DatabaseConstants.KEY_NUMBER));
        String creatorsNumber = groupCursor.getString(groupCursor.getColumnIndex(DatabaseConstants.KEY_CREATOR));
        this.groupType = groupCursor.getInt(groupCursor.getColumnIndex(DatabaseConstants.KEY_GROUP_TYPE));

        this.isEncrypted = groupCursor.getInt(groupCursor.getColumnIndex(DatabaseConstants.KEY_IS_ENCRYPTED_GROUP));
        if (name.contains(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR)) {
            String nameImage[] = name.split(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR_SPLITTER);
            this.name = nameImage[0];
            if (nameImage.length == 2 && !TextUtils.isEmpty(nameImage[1])) {
                this.groupImagePath = nameImage[1];
            } else {
                this.groupImagePath = null;
            }
        } else {
            this.name = name;
            this.groupImagePath = null;
        }
        this.id = groupCursor.getString(groupCursor.getColumnIndex("groupid"));

        this.membersNumber = membersNumber;
        this.creatorsNumber = creatorsNumber;
        this.isOpenGroup = groupCursor.getInt(groupCursor.getColumnIndex("group_type")) == 1;

        numberOfGroupMembersIncludingMyNumberAndCreatorsNumber = membersNumber.split(";");
        curentMembers = membersNumber.split(";");

        HashSet<String> uniqueNumber = new HashSet<String>(Arrays.asList(numberOfGroupMembersIncludingMyNumberAndCreatorsNumber));
        if (groupType != Constants.GROUP_TYPE_SMS) {
            uniqueNumber.add(creatorsNumber);
            uniqueNumber.add(UserDataManager.getUserName());
            numberOfGroupMembersIncludingMyNumberAndCreatorsNumber = null;
            numberOfGroupMembersIncludingMyNumberAndCreatorsNumber = uniqueNumber.toArray(new String[uniqueNumber.size()]);
            uniqueNumber.remove(UserDataManager.getUserName());
        }
        /*if(groupType == Constants.GROUP_TYPE_SMS){
            uniqueNumber.remove(UserDataManager.getUserName()); //SMS not to be sent to own-self
        }*/
        allOtherMembersNumberButMe = uniqueNumber.toArray(new String[uniqueNumber.size()]);
        memberCountButMe = uniqueNumber.size();
        isCreator = UserDataManager.getUserName().equals(this.creatorsNumber);
    }

    public Group() {
    }

    public Group(com.revesoft.itelmobiledialer.appDatabase.entities.Group group) {
        String name = group.groupName;
        String membersNumber = group.number;
        String creatorsNumber = group.creatorNumber;
        this.groupType = group.groupType;
        this.isEncrypted = group.isEncryptedGroup ? 1 : 0;
        if (name.contains(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR)) {
            String nameImage[] = name.split(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR_SPLITTER);
            this.name = nameImage[0];
            if (nameImage.length == 2 && !TextUtils.isEmpty(nameImage[1])) {
                this.groupImagePath = nameImage[1];
            } else {
                this.groupImagePath = null;
            }
        } else {
            this.name = name;
            this.groupImagePath = null;
        }
        this.id = group.groupId;
        this.membersNumber = membersNumber;
        this.creatorsNumber = creatorsNumber;
        this.isOpenGroup = group.groupType == 1;

        numberOfGroupMembersIncludingMyNumberAndCreatorsNumber = membersNumber.split(";");
        curentMembers = membersNumber.split(";");

        HashSet<String> uniqueNumber = new HashSet<String>(Arrays.asList(numberOfGroupMembersIncludingMyNumberAndCreatorsNumber));
        if (groupType != Constants.GROUP_TYPE_SMS) {
            uniqueNumber.add(creatorsNumber);
            uniqueNumber.add(UserDataManager.getUserName());
            numberOfGroupMembersIncludingMyNumberAndCreatorsNumber = null;
            numberOfGroupMembersIncludingMyNumberAndCreatorsNumber = uniqueNumber.toArray(new String[uniqueNumber.size()]);
            uniqueNumber.remove(UserDataManager.getUserName());
        }
        /*if(groupType == Constants.GROUP_TYPE_SMS){
            uniqueNumber.remove(UserDataManager.getUserName()); //SMS not to be sent to own-self
        }*/
        allOtherMembersNumberButMe = uniqueNumber.toArray(new String[uniqueNumber.size()]);
        memberCountButMe = uniqueNumber.size();
        isCreator = UserDataManager.getUserName().equals(this.creatorsNumber);
    }

    @Override
    public String toString() {
        return "Group Info:\nname : " + name
                + "\nid : " + id
                + "\nmembers : " + membersNumber
                + "\ncreator : " + creatorsNumber
                + "\nEveryBody : " + Arrays.toString(numberOfGroupMembersIncludingMyNumberAndCreatorsNumber)
                + "\nImage : " + groupImagePath;
    }

    public boolean isMember(String phoneNumber) {
        boolean isMember = false;
        for (String number : curentMembers) {
            if (number.equals(phoneNumber)) {
                isMember = true;
                break;
            }
        }
        return isMember;
    }
}
