package com.revesoft.itelmobiledialer.did;

/**
 * Created by Rahat on 9/25/2017.
 */

public interface OnDoNotDisturbListener {
    void onEnable(boolean showToast);

    void onDisable(boolean showToast);

    void onFailed(boolean showToast);


    void setSwitchStatus(String status);
}
