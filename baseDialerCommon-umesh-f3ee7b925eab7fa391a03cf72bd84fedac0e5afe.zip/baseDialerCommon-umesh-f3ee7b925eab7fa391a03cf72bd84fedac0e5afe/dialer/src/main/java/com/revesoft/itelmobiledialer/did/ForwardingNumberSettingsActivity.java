package com.revesoft.itelmobiledialer.did;

import android.os.Bundle;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;

import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

public class ForwardingNumberSettingsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_did);
        handleToolbar();
        ForwardingNumberSettingFragment forwardingNumberSettingFragment = new ForwardingNumberSettingFragment();
        forwardingNumberSettingFragment.setArguments(this.getIntent().getExtras());
        getFragmentManager().beginTransaction().add(R.id.container, forwardingNumberSettingFragment, "forwarding_number_Settings_activity").commit();

    }

    private void handleToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.call_forwarding_set_number));
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.call_forwarding_set_number));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
