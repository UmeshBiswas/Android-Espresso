package com.revesoft.itelmobiledialer.chat.share;


import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.revesoft.itelmobiledialer.chat.chatWindow.ChatConstants;
import com.revesoft.itelmobiledialer.dialer.InviteSubscriberContactPickerActivity;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;


/**
 * Created by Ahsan Tarique on 12/27/2017.
 */



public class ShareActivity extends BaseActivity {
    public static int FLAG_INTENT_SINGLE_TEXT=1;
    public static int FLAG_INTENT_SINGLE_FILE=2;
    public static int FLAG_INTENT_MULTIPLE_FILES=3;

    @Override
    protected  void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        Log.d("tarique", "type: "+ type +
                " action: " + action + " " +
                "extras: " + intent.getExtras().toString());

        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if (type.startsWith("text/")) {
                handleSendText(intent);
            } else {
                handleSendSingleFile(intent);
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type != null) {
            handleSendMultipleFiles(intent);
        }

        Intent serviceIntent = new Intent(this, DialerService.class);
        startService(serviceIntent);

        finish();
    }

    @Override
    protected void onPause(){
        super.onPause();
        finish();
    }

    void handleSendText(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        String textInvitation = intent.hasExtra(Constants.EXTRA_INVITE_BY_BUBBLETONE)?
                intent.getStringExtra(Constants.EXTRA_INVITE_BY_BUBBLETONE) : "";

        if(textInvitation.equals("yes")){
//            Log.e(" received intent","text intent");
////            Intent i = new Intent(ShareActivity.this, InviteSMSContactPickerActivity.class);
//            startActivity(i);

        } else if (sharedText != null) {
            // Update UI to reflect text being shared
            Log.e(" received intent","text intent");
            Intent i=new Intent(ShareActivity.this, InviteSubscriberContactPickerActivity.class);
            i.putExtra(ChatConstants.INTENT_TYPE,FLAG_INTENT_SINGLE_TEXT);
            i.putExtra(ChatConstants.INTENT_VALUES,sharedText);
            startActivity(i);
        }

    }

    void handleSendSingleFile(Intent intent) {
        Uri contentUri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
        try {
            if (contentUri.toString().startsWith("content://")) {
                contentUri = saveWebFile(contentUri);  // save and make contentUri same as saved file's Uri
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            I.toast(Supplier.getString(R.string.ft_sending_failed));
        }
        Intent i=new Intent(ShareActivity.this, InviteSubscriberContactPickerActivity.class);
        i.putExtra(ChatConstants.INTENT_TYPE,FLAG_INTENT_SINGLE_FILE);
        i.putExtra(ChatConstants.INTENT_VALUES, contentUri);
//        i.setData(contentUri);
        startActivity(i);
    }

    void handleSendMultipleFiles(Intent intent) {
        ArrayList<Uri> multipleImageUri = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
        if (multipleImageUri != null) {
            for(int i = 0; i < multipleImageUri.size(); i++){
                try {
                    Uri uri = multipleImageUri.get(i);
                    if (uri.toString().startsWith("content://")) {
                        multipleImageUri.set(i, saveWebFile(uri));
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                    I.toast(Supplier.getString(R.string.ft_sending_failed));
                }
            }
            Log.e(" got intent","multiple image Intent");
            // Update UI to reflect multiple images being shared
            Intent i=new Intent(ShareActivity.this, InviteSubscriberContactPickerActivity.class);
            i.putExtra(ChatConstants.INTENT_TYPE,FLAG_INTENT_MULTIPLE_FILES);
            i.putParcelableArrayListExtra(ChatConstants.INTENT_VALUES,multipleImageUri);
            startActivity(i);
        }
    }



    public Uri saveWebFile(Uri contentURI){
        String filePath="";
        try {
            ContentResolver contentResolver = getContentResolver();
            MimeTypeMap mime = MimeTypeMap.getSingleton();
            String extension = mime.getExtensionFromMimeType(contentResolver.getType(contentURI));
            if (extension == null) {
                if (contentResolver.getType(contentURI).split("/").length == 2)
                    extension = contentResolver.getType(contentURI).split("/")[1];

                //Following filtering is for some whatsapp version which sends codec type also eg: Type :audio/ogg; codecs=opus
                if (extension.contains(";"))
                    extension = extension.split(";")[0];
            }
            InputStream is = getContentResolver().openInputStream(contentURI);

            String savedChildDirectory = getResources().getString(R.string.app_name)+
                    File.pathSeparator + System.currentTimeMillis() +
                    "." + extension;

            File tempDest = new File(Environment.getExternalStorageDirectory(), savedChildDirectory);
            OutputStream outputStream = new FileOutputStream(tempDest);
            int read = 0;
            byte[] bytes = new byte[1024];
            while ((read = is.read(bytes)) != -1) {
                outputStream.write(bytes, 0, read);
            }
            filePath = tempDest.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.d("tarique", "saveWebFile() filePath" + filePath);

        return Uri.parse("file://" + filePath);
    }
}
