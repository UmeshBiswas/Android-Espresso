package com.revesoft.itelmobiledialer.contact.list;

public enum ContactType {
    ALL, APP, FAVORITE, BLOCKED,NOT_BLOCKED,APP_FOR_FORWARD
}
