package com.revesoft.itelmobiledialer.did;

import androidx.appcompat.app.ActionBar;

import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;

import com.revesoft.material.R;
import com.revesoft.itelmobiledialer.util.BaseActivity;

public class DIDNumbersActivity extends BaseActivity {

    DIDNumbersFragment DIDNumbersFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_did);
        getFragmentManager().beginTransaction().add(R.id.container, new DIDNumbersFragment(), "global_number_fragment").commit();
        handleToolbar();
    }

    private void handleToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.new_number));
        setSupportActionBar(toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.new_number));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
