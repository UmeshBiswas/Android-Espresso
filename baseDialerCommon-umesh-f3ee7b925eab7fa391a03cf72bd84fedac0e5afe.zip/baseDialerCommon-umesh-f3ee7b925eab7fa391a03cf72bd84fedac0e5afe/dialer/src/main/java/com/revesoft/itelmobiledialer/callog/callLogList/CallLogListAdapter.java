package com.revesoft.itelmobiledialer.callog.callLogList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.BlockRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.CallLogRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.block.ContactBlocker;
import com.revesoft.itelmobiledialer.callog.callLogDetails.UserWiseFullCallLogActivity;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListAdapter;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListItem;
import com.revesoft.itelmobiledialer.databaseentry.CallLogEntry;
import com.revesoft.itelmobiledialer.eventlistener.BlockStatusChangeData;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.eventlistener.DialerListener;
import com.revesoft.itelmobiledialer.eventlistener.EventData;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.CallMaker;
import com.revesoft.itelmobiledialer.util.NativeContactUtil;
import com.revesoft.material.R;
import com.revesoft.material.databinding.CallLogListSingleItemBinding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.databinding.DataBindingUtil;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import static com.revesoft.itelmobiledialer.arch.Supplier.getString;

public class CallLogListAdapter extends PagedListAdapter<CallLogItem, CallLogListAdapter.ViewHolder> implements DialerListener {
    private Context context;

    private HashMap<String, Boolean> numberIsBlockMap = new HashMap<>();
    private HashMap<CallLogItem, ViewHolder> callLogItemViewHolderHashMap = new HashMap<>();
    @SuppressLint("UseSparseArrays")
    private HashMap<String, PriorityQueue<CallLogItem>> headerTimeQueueMap = new HashMap<>();
    private String TAG = "CALL_LOG_ADAPTER";

    CallLogListAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
        register();

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.call_log_list_single_item,
                parent, false
        ));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        CallLogItem item = getItem(position);

        if (item != null) {

            if (!numberIsBlockMap.keySet().contains(item.getNumber())) {
                numberIsBlockMap.put(item.getNumber(), item.getUnblockVisibility() == View.VISIBLE);
            } else {
                boolean isPaidCall = item.getCallType() == CallLogEntry.CallType.PAID;
                if (!numberIsBlockMap.get(item.getNumber())) {
                    item.setUnblockVisibility(View.GONE);
                    item.setFreeCallVisibility(isPaidCall ? View.GONE : View.VISIBLE);
                    item.setPaidCallVisibility(isPaidCall ? View.VISIBLE : View.GONE);
                } else {
                    item.setUnblockVisibility(View.VISIBLE);
                    item.setFreeCallVisibility(View.GONE);
                    item.setPaidCallVisibility(View.GONE);

                }
            }

            holder.binding.setCallLog(item);
            ImageUtil.setImage(holder.binding.ivProfileImage, item.getImageUrl(), item.getName());


            holder.binding.setCallLogItemClickListener(new CallLogItemClickListener() {

                @Override
                public void onCallLogLongClick(CallLogItem callLog) {

                }

                @Override
                public void onCallLogClick(CallLogItem callLog) {
                    UserWiseFullCallLogActivity.start(context, item.getNumber());
                }

                @Override
                public void makeAudioCall(String number) {
                    CallMaker.makeFreeCall(number);
                }

                @Override
                public void makeVideoCall(String number) {
                    CallMaker.makeVideoCall(number);
                }

                @Override
                public void makeOutCall(String number) {
                    CallMaker.makePaidCall(number);
                }

                @Override
                public void unblock(String number) {
                    ContactBlocker.getInstance().toggleContactBlockStatus((Activity) context, item.getNumber());
                }

                @Override
                public void onCallLogProfileImageClick(String number) {
                    Switcher.switchToContactDetails(context, number);
                }
            });

            holder.binding.getRoot().setOnLongClickListener(v -> {
                handleLongPressOptions(item, position);
                return true;
            });
        } else {
            holder.binding.invalidateAll();
        }
    }

    private void handleLongPressOptions(CallLogItem callLogItem, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        ArrayList<ImageListItem> itemsList = new ArrayList<>(3);
        Executor.ex(() -> {
            boolean isBlocked = BlockRepo.get().isBlockedContact(callLogItem.getNumber());
            if (!ContactRepo.get().isContact(callLogItem.getNumber())) {
                Gui.get().run(() -> {
                    itemsList.add(new ImageListItem(getString(R.string.addToContact), R.drawable.ic_call_log_add_to_contacts));
                    if (!isBlocked)
                        itemsList.add(new ImageListItem(getString(R.string.block), R.drawable.ic_call_log_block));
                    else
                        itemsList.add(new ImageListItem(getString(R.string.unblock), R.drawable.ic_call_log_block));
                    itemsList.add(new ImageListItem(getString(R.string.delete), R.drawable.ic_call_log_delete));
                    ImageListAdapter imageListAdapter = new ImageListAdapter(context, itemsList, false);
                    builder.setAdapter(imageListAdapter, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case 0:
                                    NativeContactUtil.saveContact(context, callLogItem.getNumber());
                                    break;
                                case 1:
                                    ContactBlocker.getInstance().toggleContactBlockStatus((Activity) context, callLogItem.getNumber());
                                    break;
                                case 2:
                                    deleteCallLog(callLogItem);
                                    break;
                            }
                            dialog.dismiss();
                        }
                    });
                });


            } else {
                Gui.get().run(() -> {
                    if (!isBlocked)
                        itemsList.add(new ImageListItem(getString(R.string.block), R.drawable.ic_call_log_block));
                    else
                        itemsList.add(new ImageListItem(getString(R.string.unblock), R.drawable.ic_call_log_block));
                    itemsList.add(new ImageListItem(getString(R.string.delete), R.drawable.ic_call_log_delete));
                    ImageListAdapter imageListAdapter = new ImageListAdapter(context, itemsList, false);
                    builder.setAdapter(imageListAdapter, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case 0:
                                    ContactBlocker.getInstance().toggleContactBlockStatus((Activity) context, callLogItem.getNumber());
                                    break;
                                case 1:
                                    deleteCallLog(callLogItem);
                                    break;
                            }
                            dialog.dismiss();
                        }
                    });
                });


            }
            Gui.get().run(() -> builder.create().show());
        });


    }

    private void deleteCallLog(CallLogItem callLogItem) {

        Executor.ex(() -> {
            CallLogRepo.get().DeleteByCallID(callLogItem.getCallId());
        });
    }

    @Override
    public void register() {
        DialerEventHock.getInstance().addListener(this);
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        public CallLogListSingleItemBinding binding;

        public ViewHolder(@NonNull CallLogListSingleItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private static DiffUtil.ItemCallback<CallLogItem> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<CallLogItem>() {
                @Override
                public boolean areItemsTheSame(@NonNull CallLogItem oldItem, @NonNull CallLogItem newItem) {
                    return oldItem.getCallId() != null && oldItem.getCallId().equals(newItem.getCallId());
                }

                @Override
                public boolean areContentsTheSame(@NonNull CallLogItem oldItem, @NonNull CallLogItem newItem) {
                    return areItemsTheSame(oldItem, newItem) && oldItem.getHeaderDateVisibility() == newItem.getHeaderDateVisibility()
                            && oldItem.getUnblockVisibility() == newItem.getUnblockVisibility();
                }
            };

    @Override
    public void performOnEvent(DialerEvent event, EventData eventData) {
        if (event == DialerEvent.BlockStatusChangeEvent) {
            BlockStatusChangeData blockStatusChangeData = (BlockStatusChangeData) eventData;
            numberIsBlockMap.put(blockStatusChangeData.getKeyNumber(), blockStatusChangeData.isBlockStatus());

            for (int i = 0; i < getItemCount(); i++) {

                if (getItem(i) != null && getItem(i).getNumber() != null &&
                        getItem(i).getNumber().equals(blockStatusChangeData.getKeyNumber())) {
                    notifyItemChanged(i);
                }

            }
        }

    }

}
