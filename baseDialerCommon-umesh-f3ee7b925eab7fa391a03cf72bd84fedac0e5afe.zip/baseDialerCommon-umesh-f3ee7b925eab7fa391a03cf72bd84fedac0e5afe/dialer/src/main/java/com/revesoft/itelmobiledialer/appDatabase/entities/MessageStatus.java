package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;

/**
 * @author Ifta
 */

@Entity(tableName = "message_status_table", primaryKeys = {"callerid","number"})
public class MessageStatus {
    public int _id;
    @NonNull
    @ColumnInfo(name = "callerid")
    public String callerId = AppDatabaseDefault.callerId;
    @NonNull
    public String number = AppDatabaseDefault.number;

    @ColumnInfo(name = "delivery_time")
    public long deliveryTime = 0;
    @ColumnInfo(name = "seen_time")
    public long seenTime = 0;
    public MessageStatus() {
    }
    private MessageStatus(Builder builder) {
        _id = builder._id;
        callerId = builder.callerId;
        number = builder.number;
        deliveryTime = builder.deliveryTime;
        seenTime = builder.seenTime;
    }
    public static MessageStatus.Builder newBuilder() {
        return new Builder();
    }
    public static final class Builder {
        private int _id;
        private String callerId;
        private String number;
        private long deliveryTime;
        private long seenTime;

        public Builder() {
        }

        public Builder _id(int val) {
            _id = val;
            return this;
        }

        public Builder callerId(String val) {
            callerId = val;
            return this;
        }

        public Builder number(String val) {
            number = val;
            return this;
        }

        public Builder deliveryTime(long val) {
            deliveryTime = val;
            return this;
        }

        public Builder seenTime(long val) {
            seenTime = val;
            return this;
        }

        public MessageStatus build() {
            return new MessageStatus(this);
        }
    }
}
