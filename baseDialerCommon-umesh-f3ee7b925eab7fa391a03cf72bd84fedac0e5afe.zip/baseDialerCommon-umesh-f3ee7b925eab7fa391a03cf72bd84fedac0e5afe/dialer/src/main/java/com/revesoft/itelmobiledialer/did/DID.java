package com.revesoft.itelmobiledialer.did;

import java.io.Serializable;

/**
 * Created by Rahat on 9/18/2017.
 */
public class DID implements Serializable {
    private String didID;
    private String didOwner;
    private String didNumber;
    private String expireDate;
    private String rate;
    private String forwardedNumber;

    public DID(String didID, String didOwner, String didNumber, String forwardedNumber, String expireDate) {
        this.didID = didID;
        this.didOwner = didOwner;
        this.didNumber = didNumber;
        this.expireDate = expireDate;
        this.forwardedNumber = forwardedNumber;
    }

    public DID(String didID, String didOwner, String didNumber, String rate) {
        this.didID = didID;
        this.didOwner = didOwner;
        this.didNumber = didNumber;
        this.rate = rate;
    }

    public DID(String didID, String didOwner, String rate) {
        this.didID = didID;
        this.didOwner = didOwner;
        this.rate = rate;
    }

    public String getExpireDate() {
        return expireDate;
    }

    public String getDidID() {
        return didID;
    }

    public String getDidOwner() {
        return didOwner;
    }

    public String getDidNumber() {
        return didNumber;
    }

    public String getRate() {
        return rate;
    }

    public void setForwardedNumber(String forwardedNumber) {

        this.forwardedNumber = forwardedNumber;
    }

    public void setDidNumber(String didNumber) {
        this.didNumber = didNumber;
    }

    public String getForwardedNumber() {
        return forwardedNumber;
    }

    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if ((obj == null) || (obj.getClass() != this.getClass()))
            return false;
        // object must be Test at this point
        DID did = (DID) obj;
        return didID.equals(did.getDidID());

    }

    public int hashCode() {
        int hash = 7;
        //hash = 31 * hash + didID;
        hash = 31 * hash + (null == didNumber ? 0 : didNumber.hashCode());
        return hash;
    }
}
