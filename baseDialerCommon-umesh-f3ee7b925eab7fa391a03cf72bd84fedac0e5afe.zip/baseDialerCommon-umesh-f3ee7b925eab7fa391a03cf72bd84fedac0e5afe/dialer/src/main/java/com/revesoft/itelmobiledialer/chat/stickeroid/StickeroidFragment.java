package com.revesoft.itelmobiledialer.chat.stickeroid;


import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.MemoryCategory;

import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

/**
 * @author Ifta on 10/29/2017.
 */

public class StickeroidFragment extends Fragment {
    private static final TaggedLogger logger = new TaggedLogger("Stickroid");
    public static final String TAG = "StickeroidFragment";
    private static StickeroidFragment fragment = null;

    private StickerClickListener stickerClickListener;

    public static StickeroidFragment getInstance() {
        if (fragment == null) {
            fragment = new StickeroidFragment();
        }
        return fragment;
    }

    RecyclerView rvGifList;
    EditText etSearch;
    ImageView ivSearch;
    StickerAdapter stickerAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Glide.get(getActivity()).setMemoryCategory(MemoryCategory.HIGH);
    }

    public void attachStickerClickListener(StickerClickListener stickerClickListener) {
        this.stickerClickListener = stickerClickListener;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.stickeroid_fragment_layout, container, false);
        rvGifList = (RecyclerView) rootView.findViewById(R.id.rvStickerList);
        final RecyclerView.LayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.HORIZONTAL);
        rvGifList.setLayoutManager(layoutManager);
        stickerAdapter = new StickerAdapter(getActivity());
        rvGifList.setAdapter(stickerAdapter);
        loadAndShowSticker(Stickeroid.getDefaultSearchKey());
        stickerAdapter.attachStickerClickListener(stickerClickListener);
        return rootView;
    }



    @Override
    public void onDestroy() {
        super.onDestroy();
        Glide.get(getActivity()).setMemoryCategory(MemoryCategory.NORMAL);
    }

    private void loadAndShowSticker(String searchText) {
        StickeroidDataLoader.getAccess(getActivity()).getStickers(searchText, new StickerLoadListener() {
            @Override
            public void onStickerLoad(ArrayList<Sticker> stickers) {

                stickerAdapter.refresh(stickers);
            }

            @Override
            public void onStickerLoadError(String errorInfo) {
            }
        });
    }

    public boolean isInSearchMode() {
        return etSearch.hasFocus();
    }
}
