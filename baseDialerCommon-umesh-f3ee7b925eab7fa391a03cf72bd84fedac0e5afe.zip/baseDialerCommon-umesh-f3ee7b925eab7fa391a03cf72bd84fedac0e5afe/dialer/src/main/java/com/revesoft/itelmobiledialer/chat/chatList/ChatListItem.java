package com.revesoft.itelmobiledialer.chat.chatList;

import android.text.TextUtils;
import android.view.View;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.signalling.data.MessageDeliveryStatus;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TimeFormat;
import com.revesoft.material.R;

import java.io.File;

import static com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants.MULTIPART_INDICATOR;

public class ChatListItem {
    private boolean isGroup;
    private String numberOrGroupId;
    private String callerId;
    private String name;
    private String lastMessage;
    private int lastMessageStatus;
    private String unseenMessageCount;
    private String date;
    private String imageUrl;
    private int counterVisibility;
    private MimeType mimeType;
    public static ChatListItem from(QueryItemChatList message) {
        ChatListItem item = new ChatListItem();
        item.isGroup = !TextUtils.isEmpty(message.groupid);
        item.numberOrGroupId = item.isGroup ? message.groupid : message.number;
        item.callerId = message.callerid;
        item.name = findName(message);
        item.lastMessage = getLastMessage(message);
        if(message.messagetype == MessageEntry.MessageType.SEND) {
            if (message.deliverystatus == MessageDeliveryStatus.Seen.getValue()) {
                item.lastMessageStatus = R.drawable.ic_chat_seen;
            } else if (message.deliverystatus == MessageDeliveryStatus.Successful.getValue()) {
                item.lastMessageStatus = R.drawable.ic_chat_delevered;
            } else if (message.deliverystatus == MessageDeliveryStatus.Pending.getValue()) {
                item.lastMessageStatus = R.drawable.ic_chat_send;
            } else if (message.deliverystatus == MessageDeliveryStatus.NoReply.getValue()) {
                item.lastMessageStatus = R.drawable.ic_chat_clock;
            } else if (message.deliverystatus == MessageDeliveryStatus.Failed.getValue()) {
                item.lastMessageStatus = R.drawable.ic_chat_failed;
            } else {
                item.lastMessageStatus = 0;
            }
        }else {
            item.lastMessageStatus = 0;
        }
        item.unseenMessageCount = String.valueOf(message.unread_count);
        item.date = TimeFormat.getChatHistoryDate(message.received);
        item.imageUrl = findImage(message);
        item.counterVisibility = message.unread_count == 0 ? View.GONE : View.VISIBLE;

        return item;
    }

    private static String getLastMessage(QueryItemChatList message) {
        if (message.mime_type.equals(MimeType.Text.name())) {
            return message.messagecontent;
        } else if (!TextUtils.isEmpty(message.long_message)) {
            if (message.messagecontent.contains(MULTIPART_INDICATOR))
                return Supplier.getString(R.string.new_message);
            else
                return message.messagecontent;
        } else if (TextUtils.isEmpty(message.filepath) && message.mime_type.equals(MimeType.Document.name())) {
            return message.messagecontent;
        } else if (message.mime_type.equals(MimeType.Call.name())) {
            String content = message.messagecontent.replace(Constants.Call.CALL_MESSAGE_PREFIX, "").replace(Constants.Call.CALL_MESSAGE_SUFFIX, "");
            if (content.contains("audio")) {
                return Supplier.getString(R.string.missedAudioCall);
            } else {
                return Supplier.getString(R.string.missedVideoCall);
            }
        }
        String processedMime = MimeTypeUtil.getHumanReadableMimeType(MimeTypeUtil.getMimeTypeByName(message.mime_type));
        String processedMessageType = getLastMessageExtensionByType(message.messagetype);
        String finalMime = processedMime;
        if (processedMime.equalsIgnoreCase("Image")) {
            finalMime = Supplier.getString(R.string.image) + " " + processedMessageType;
        } else if (processedMime.equals("Location")) {
            finalMime = Supplier.getString(R.string.location) + " " + processedMessageType;
        } else if (processedMime.equals("Contact")) {
            finalMime = Supplier.getString(R.string.contact) + " " + processedMessageType;
        } else if (processedMime.equals("Document")) {
            finalMime = Supplier.getString(R.string.document) + " " + processedMessageType;
        } else if (processedMime.equals("Audio")) {
            finalMime = Supplier.getString(R.string.audio) + " " + processedMessageType;
        } else if (processedMime.equals("Video")) {
            finalMime = Supplier.getString(R.string.video) + " " + processedMessageType;
        }
        return finalMime;
    }


    private static String getLastMessageExtensionByType(int messageType) {
        if (messageType == MessageEntry.MessageType.SEND) {
            return Supplier.getString(R.string.send);
        } else {
            return Supplier.getString(R.string.received);
        }
    }


    private static String findImage(QueryItemChatList message) {
        if (TextUtils.isEmpty(message.groupid)) {
            return ProfilePictureDataProvider.getProfilePicturePath(message.number);
        } else {
            if (message.name != null && message.name.contains(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR)) {
                String nameImage[] = message.name.split(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR_SPLITTER);
                if (nameImage.length == 2 && !TextUtils.isEmpty(nameImage[1])) {
                    String groupImageName = nameImage[1];
                    if (groupImageName != null && !"null".equals(groupImageName)
                            && !"".equals(groupImageName) && !TextUtils.isEmpty(groupImageName)) {
                        File file = new File(ProfilePicUploadDownloadHelper.getReceivedMediaDirectory(), groupImageName);
                        if (ProfilePicUploadDownloadHelper.checkIfImageAvailable(file)) {
                            return file.getAbsolutePath();
                        }
                        return null;
                    }
                }
                return null;
            }
        }
        return null;
    }

    private static String findName(QueryItemChatList message) {
        if (!TextUtils.isEmpty(message.name)) {
            if (message.name.contains(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR)) {
                String nameImage[] = message.name.split(Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR_SPLITTER);
                return nameImage[0];
            }
            return message.name;
        } else {
            return message.number;
        }
    }

    public String getNumberOrGroupId() {
        return numberOrGroupId;
    }

    public String getCallerId() {
        return callerId;
    }

    public String getName() {
        return name;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public int getLastMessageStatus() {
        return lastMessageStatus;
    }

    public String getUnseenMessageCount() {
        return unseenMessageCount;
    }

    public String getDate() {
        return date;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public int getCounterVisibility() {
        return counterVisibility;
    }

    public boolean isGroup() {
        return isGroup;
    }
}
