package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 12/12/2017.
 */

public class E2EViewHolder extends RecyclerView.ViewHolder {
    public E2EViewHolder(View view) {
        super(view);
    }

    public void bindView() {

    }
}
