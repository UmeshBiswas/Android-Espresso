package com.revesoft.itelmobiledialer.appDatabase.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
// db.execSQL("CREATE TABLE IF NOT EXISTS block(_id integer default 1, number text primary key not null)");
@Entity(tableName = "block")
public class Block {

    public int _id = 1;

    @NonNull
    @PrimaryKey(autoGenerate = false)
    public String number = "";



}
