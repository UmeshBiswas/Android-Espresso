package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.content.Intent;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDateTimeFormatter;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.BurnerListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageBubbleBackgroundResourceProvider;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageHighlighter;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageSelection;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageBurn.Burner;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.quote.MessageQuoteBindingData;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.confide.ConfidePreviewActivity;
import com.revesoft.itelmobiledialer.confide.Smoker;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.customview.RoundedImageView;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.NameResolver;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.jetPackHelpers.dataBinding.DataBindingAdapters;
import com.revesoft.itelmobiledialer.service.burnmessage.BurnMessageHelper;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 12/13/2017.
 */

public class TextMessageViewHolder extends RecyclerView.ViewHolder {
    private static TaggedLogger logger = new TaggedLogger("ChatWindow");
    private TextView tvDate;
    private TextView tvName;
    private TextView tvMessage;
    private TextView tvTime;
    private ImageView ivStatus;
    private RoundedImageView ivContactImage;
    private View selectionOverLay;
    public View row;
    public View content;
    private View ivEditedIndicator;
    private View ivBurnIndicator;
    private View messageBubble;
    //burn message related variables
    public boolean isBurning;
    public View fireAnimationHolder;
    public View fireSourceController;
    public View fireSource;

    private TextView tvNameOfQuotee;
    private TextView tvQuoteMessage;
    private ImageView ivQuoteFilePreview;
    private View closeQuote;
    private View quoteVideoIndicator;
    private View messageQuoteView;

    public TextMessageViewHolder(View view) {
        super(view);
        tvDate = view.findViewById(R.id.tvDate);
        tvName = view.findViewById(R.id.tvName);
        tvMessage = view.findViewById(R.id.tvMessage);
        tvTime = view.findViewById(R.id.tvTime);
        ivStatus = view.findViewById(R.id.ivStatus);
        ivContactImage = view.findViewById(R.id.ivContactImage);
        selectionOverLay = view.findViewById(R.id.overlay);
        row = view.findViewById(R.id.row);
        content = view.findViewById(R.id.content);
        ivEditedIndicator = view.findViewById(R.id.ivEditedIndicator);
        ivBurnIndicator = view.findViewById(R.id.ivBurnIndicator);
        //burn message
        fireAnimationHolder = view.findViewById(R.id.fireAnimationHolder);
        fireSource = view.findViewById(R.id.fireSource);
        fireSourceController = view.findViewById(R.id.fireSourceController);
        isBurning = false;
        messageBubble = view.findViewById(R.id.messageBubble);

        tvNameOfQuotee = view.findViewById(R.id.tvNameOfQuotee);
        tvQuoteMessage = view.findViewById(R.id.tvQuotedTextMessage);
        ivQuoteFilePreview = view.findViewById(R.id.ivQuoteFilePreview);
        closeQuote = view.findViewById(R.id.ivCloseQuote);
        quoteVideoIndicator = view.findViewById(R.id.ivQuotePreviewVideoIndicator);
        messageQuoteView = view.findViewById(R.id.messageQuoteView);
    }

    public void bindView(Message message) {
        logger.log("text message bindView");
        if (message == null) return;
        handleHeader(message);
        handleName(message);
        handleMessage(message);
        handleStatus(message);
        handleDateTime(message);
        handleContactImage(message);
        handleOverLay(message);
        handleEditedIndication(message);
        handleBurnIndicator(message);
        handleMessageBurning(message);
        handleMessageQuoteView(message);
        handleClicks(message);
        handleMessageBubble(message);
        handleSmoking(message);
    }


    private void handleMessageBubble(Message message) {
        if (message.mimeType == MimeType.GIF || message.mimeType == MimeType.Sticker || message.mimeType == MimeType.CallRejectSticker || message.mimeType == MimeType.StaticSticker) {
            messageBubble.setBackgroundResource(0);
            return;
        }
        if (message.messageType == MessageEntry.MessageType.SEND || message.messageType == MessageEntry.MessageType.SENT_SMS || message.messageType == MessageEntry.MessageType.SMS) {
            if (message.isLastOnConitiousStack) {
                messageBubble.setBackgroundResource(MessageBubbleBackgroundResourceProvider.getCorneredDrawable());
            } else {
                messageBubble.setBackgroundResource(MessageBubbleBackgroundResourceProvider.getCornerLessDrawable());
            }
        } else if (message.messageType == MessageEntry.MessageType.RECEIVED || message.messageType == MessageEntry.MessageType.RECEIVED_SMS) {
            if (message.isLastOnConitiousStack) {
                messageBubble.setBackgroundResource(R.drawable.cb_cornered_white);
            } else {
                messageBubble.setBackgroundResource(R.drawable.cb_cornerless_white);
            }
        }
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) messageBubble.getLayoutParams();
        if (TextUtils.isEmpty(message.qcid)) {
            layoutParams.width = RelativeLayout.LayoutParams.WRAP_CONTENT;
        } else {
            layoutParams.width = RelativeLayout.LayoutParams.MATCH_PARENT;
        }
        messageBubble.setLayoutParams(layoutParams);
    }

    private void handleDateTime(Message message) {
        if (message.futureTime > 0) {
            tvTime.setText(ChatDateTimeFormatter.getFutureMessageDateTime(message.futureTime));
        } else {
            tvTime.setText(ChatDateTimeFormatter.getMessageTime(message.time));
        }
    }

    private static final TaggedLogger loggerBurner = new TaggedLogger("Burner");

    private void handleSmoking(Message message) {
        if (Smoker.needSmoking(message.callerId)) {
            Smoker.smoke(message.callerId, messageBubble);
            messageBubble.animate().alpha(0).setDuration(1000).start();
            ivStatus.animate().alpha(0).setDuration(500).start();
        } else {
            messageBubble.setAlpha(1.0f);
            ivStatus.setAlpha(1.0f);
        }
    }

    private void handleMessageBurning(final Message message) {
        if (message.imBurnTime > 0 && BurnMessageHelper.animatedBurnMessageEntryMap.containsKey(message.callerId)) {
            Log.e("BurnThread", "message to be burned");
            Burner.burnMessage(this, new BurnerListener() {
                @Override
                public void onBurnFinished() {
//                    if (ChatProperties.isGroupChat) {
//                        DatabaseConstants.getInstance().deleteGroupMessage(Target.target, message.callerId);
//                    } else {
//                        DatabaseConstants.getInstance().deleteMessage(Target.target, message.callerId);
//                    }

                    Executor.ex(() -> MessageRepo.get().deleteMessageByCallID(message.callerId));
                    BurnMessageHelper.animatedBurnMessageEntryMap.remove(message.callerId);
                    isBurning = false;
                }
            });
        } else {
            fireAnimationHolder.setVisibility(View.GONE);
        }
    }


    private void handleMessageQuoteView(final Message message) {
        if (TextUtils.isEmpty(message.qcid)) {
            messageQuoteView.setVisibility(View.GONE);
            return;
        } else {
            messageQuoteView.setVisibility(View.VISIBLE);
        }
        MessageQuoteBindingData quoteBindingData = new MessageQuoteBindingData();
        if (ChatUtil.isFileContent(message.quoteData)) {
            quoteBindingData.filePath = message.quoteFilePath;
            String description = com.revesoft.itelmobiledialer.ims.ChatUtil.getCaption(message.quoteData);
            if (TextUtils.isEmpty(description)) {
                description = MimeTypeUtil.getHumanReadableMimeType(MimeTypeUtil.getMimeType(message.quoteData));
            }
            quoteBindingData.message = description;
            quoteBindingData.previewVisibility = View.VISIBLE;
            if (message.mimeType == MimeType.Video) {
                quoteBindingData.videoIconVisibility = View.VISIBLE;
            } else {
                quoteBindingData.videoIconVisibility = View.GONE;
            }
        } else {
            quoteBindingData.filePath = null;
            quoteBindingData.message = ChatUtil.getQuoteMessageData(message.quoteData);
            quoteBindingData.previewVisibility = View.GONE;
        }
        quoteBindingData.name = NameResolver.getContactNameFromNumberOrEmail(message.quoteFromUser);
        tvQuoteMessage.setText(quoteBindingData.message);
        tvNameOfQuotee.setText(quoteBindingData.name);
        ivQuoteFilePreview.setVisibility(quoteBindingData.previewVisibility);
        quoteVideoIndicator.setVisibility(quoteBindingData.videoIconVisibility);
        closeQuote.setVisibility(View.GONE);
        if (quoteBindingData.previewVisibility == View.VISIBLE) {
            DataBindingAdapters.setImageUri(ivQuoteFilePreview, quoteBindingData.filePath);
        }
    }
//
//    private void handleMediaQuotedMessage(Message message) {
//        tvQuotedTextMessage.setVisibility(View.GONE);
//        ivQuoteFilePreview.setVisibility(View.VISIBLE);
//        tvNameOfQuotee.setText(NameResolver.getContactNameFromNumberOrEmail(message.quoteFromUser));
//        String description = ChatContentParser.parseCaption(message.quoteData);
//        if (TextUtils.isEmpty(description)) {
//            description = MimeTypeUtil.getHumanReadableMimeType(message.quoteMimeType);
//        }
//        ivQuotePreviewVideoIndicator.setVisibility(View.GONE);
//        switch (message.quoteMimeType) {
//            case Image:
//            case Video:
//                if (message.quoteMimeType == MimeType.Video) {
//                    ivQuotePreviewVideoIndicator.setVisibility(View.VISIBLE);
//                } else {
//                    ivQuotePreviewVideoIndicator.setVisibility(View.GONE);
//                }
//                setQuoteThumbnailForVideoAndImage(message.quoteFilePath);
//                break;
//            case GIF:
//            case Sticker:
//            case CallRejectSticker:
//            case StaticSticker:
//                setStickerGifPreview(message);
//                break;
//            case Location:
//                setQuoteThumbnailForMap();
//                break;
//            default:
//                ivQuoteFilePreview.setVisibility(View.GONE);
//                break;
//        }
//    }
//
//    private void setQuoteThumbnailForVideoAndImage(String filePath) {
//        ivQuoteFilePreview.setVisibility(View.VISIBLE);
//        tvQuotedTextMessage.setVisibility(View.GONE);
//        int dimension = Supplier.getResource().getDimensionPixelSize(R.dimen.messageQuoteThumbSize);
//        Glide.with(AppContext.getAccess().getContext())
//                .load(filePath)
//                .centerCrop()
//                .override(dimension, dimension)
//                .crossFade()
//                .error(R.drawable.ic_broken_file)
//                .into(ivQuoteFilePreview);
//    }
//
//    private void setStickerGifPreview(Message message) {
//        messageQuoteViewBinding.getRoot().setVisibility(View.VISIBLE);
//        if (message.quoteMimeType == MimeType.Sticker) {
//            ChatAdapterHelper.Sticker.handleStickerPreview(message.quoteData, ivQuoteFilePreview);
//        } else if (message.quoteMimeType == MimeType.StaticSticker) {
//            ChatAdapterHelper.Sticker.handleStaticStickerPreview(message.quoteData, ivQuoteFilePreview);
//        } else if (message.quoteMimeType == MimeType.CallRejectSticker) {
//            ChatAdapterHelper.Sticker.handleCallRejectStickerPreview(message.quoteData, ivQuoteFilePreview);
//        }
//    }
//
//    private void setQuoteThumbnailForMap() {
//        int dimension = Supplier.getResource().getDimensionPixelSize(R.dimen.messageQuoteThumbSize);
//        Glide.with(AppContext.getAccess().getContext())
//                .load(R.drawable.quote_map)
//                .crossFade()
//                .centerCrop()
//                .override(dimension, dimension)
//                .error(R.drawable.quote_map)
//                .into(ivQuoteFilePreview);
//    }
//
//    private void handleTextQuotedMessage(Message message) {
////        logger.log(message.toString());
//        tvQuotedTextMessage.setVisibility(View.VISIBLE);
//        ivQuotePreviewVideoIndicator.setVisibility(View.GONE);
//        ivQuoteFilePreview.setVisibility(View.GONE);
//        tvQuotedTextMessage.setText(message.quoteData);
//        tvNameOfQuotee.setText(NameResolver.getContactNameFromNumberOrEmail(message.quoteFromUser));
//    }

    private void handleBurnIndicator(Message message) {
        if (message.messageType == MessageEntry.MessageType.SEND) {
            if (message.imBurnTime > 0) {
                ivBurnIndicator.setVisibility(View.VISIBLE);
            } else {
                ivBurnIndicator.setVisibility(View.GONE);
            }
        } else {
            ivBurnIndicator.setVisibility(View.GONE);
        }
    }

    private void handleEditedIndication(Message message) {
        if (message.editCount > 0) {
            ivEditedIndicator.setVisibility(View.VISIBLE);
        } else {
            ivEditedIndicator.setVisibility(View.GONE);
        }
    }

    private void handleOverLay(Message message) {
        if (MessageHighlighter.isHighlighted(message.ocid)) {
            selectionOverLay.setVisibility(View.VISIBLE);
        } else if (MessageSelection.isInSelectionMode) {
            if (MessageSelection.isSelected(message)) {
                selectionOverLay.setVisibility(View.VISIBLE);
            } else {
                selectionOverLay.setVisibility(View.INVISIBLE);
            }
        } else {
            selectionOverLay.setVisibility(View.INVISIBLE);
        }

    }

    private void handleClicks(final Message message) {
        tvMessage.setOnLongClickListener(v -> {
            logger.log("onLongClick " + message.content);
            MessageSelection.addOrRemove(message);
            return true;
        });
        row.setOnLongClickListener(v -> {
            logger.log("onLongClick " + message.content);
            MessageSelection.addOrRemove(message);
            return true;
        });
        messageQuoteView.setOnLongClickListener(v -> {
            logger.log("onLongClick " + message.content);
            MessageSelection.addOrRemove(message);
            return true;
        });
        messageQuoteView.setOnClickListener(v -> MessageHighlighter.highLight(message.qcid));
        ivQuoteFilePreview.setOnLongClickListener(v -> {
            logger.log("onLongClick " + message.content);
            MessageSelection.addOrRemove(message);
            return true;
        });
        tvMessage.setOnClickListener(v -> {
            if (MessageSelection.isInSelectionMode) {
                MessageSelection.addOrRemove(message);
            }
        });
        row.setOnClickListener(v -> {
            if (message.isConfide && !MessageSelection.isInSelectionMode) {
                if (message.messageType == MessageEntry.MessageType.SEND) {
                    Intent intent = new Intent(AppContext.getAccess().getContext(), ConfidePreviewActivity.class);
                    if (ChatUtil.isFileContent(message.content)) {
                        intent.putExtra(ConfidePreviewActivity.KEY_TEXT, ChatContentParser.parseCaption(message.content));
                    } else {
                        intent.putExtra(ConfidePreviewActivity.KEY_TEXT, message.content);
                    }
                    if (TextUtils.isEmpty(message.longMessage))
                        intent.putExtra(ConfidePreviewActivity.KEY_FILE_PATH, message.filePathLocal);
                    intent.putExtra(ConfidePreviewActivity.KEY_IS_PREVIEW, true);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    AppContext.getAccess().getContext().startActivity(intent);
                } else {
                    if (!ChatUtil.isDownloadingNow(message)) {
                        Switcher.switchToReadConfideChat(message.callerId);
                    } else {
                        I.toast(Supplier.getString(R.string.please_wait_attachment_is_downloading));
                    }
                }
            } else if (MessageSelection.isInSelectionMode) {
                MessageSelection.addOrRemove(message);
            }
        });
        ivContactImage.setOnClickListener(view -> Executor.ex(() -> {
            String contactId = ContactRepo.get().getContactIdByNumber(message.sender);
            Gui.get().run(() -> ContactDetailsActivity.start(view.getContext(), contactId, message.sender));

        }));
    }

    private void handleContactImage(Message message) {
        if (!ChatProperties.isGroupChat) {
            ivContactImage.setVisibility(View.GONE);
            return;
        }
        if (message.messageType == MessageEntry.MessageType.RECEIVED || message.messageType == MessageEntry.MessageType.RECEIVED_SMS) {
            if (message.isLastOnConitiousStack) {
                ivContactImage.setVisibility(View.VISIBLE);
                String profilePictureUri = ProfilePictureDataProvider.getProfilePicturePath(message.sender);
                ImageUtil.setImageButTextImageOnException(profilePictureUri, ivContactImage, tvName.getText().toString());

                if (message.broadcastId > 0) {
                    ivContactImage.setImageDrawable(Supplier.getResource().getDrawable(R.drawable.bubble_tone_offer));
                }
            } else {
                ivContactImage.setVisibility(View.INVISIBLE);
            }
        } else {
            ivContactImage.setVisibility(View.GONE);
        }
    }


    private void handleStatus(Message message) {
        ivStatus.setVisibility(View.VISIBLE);
        if (message.deliveryStatus == MessageEntry.DeliveryStatus.SUCCESSFUL) {
            ivStatus.setImageResource(R.drawable.ic_chat_delevered);
        } else if (message.deliveryStatus == MessageEntry.DeliveryStatus.SEEN) {
            ivStatus.setImageResource(R.drawable.ic_chat_seen);
        } else if (message.deliveryStatus == MessageEntry.DeliveryStatus.PENDING) {
            ivStatus.setImageResource(R.drawable.ic_chat_send);
        } else if (message.deliveryStatus == MessageEntry.DeliveryStatus.NO_REPLY) {
            ivStatus.setImageResource(R.drawable.ic_chat_clock);
        } else if (message.deliveryStatus == MessageEntry.DeliveryStatus.FAILED) {
            ivStatus.setImageResource(R.drawable.ic_chat_failed);
        } else {
            ivStatus.setVisibility(View.GONE);
        }
    }

    private void handleMessage(Message message) {
        if (message.mimeType == MimeType.Deleted) {
            tvMessage.setVisibility(View.VISIBLE);
            int deleteIconResourceId = 0;
            if (message.messageType == MessageEntry.MessageType.RECEIVED) {
                tvMessage.setText(Supplier.getString(R.string.thisMessageWasDeleted));
                deleteIconResourceId = R.drawable.ic_received_message_deleted_indicator;
            } else {
                tvMessage.setText(Supplier.getString(R.string.youDeletedThisMessage));
                deleteIconResourceId = R.drawable.ic_send_message_deleted_indicator;
            }
            tvMessage.setCompoundDrawablesWithIntrinsicBounds(deleteIconResourceId, 0, 0, 0);
            tvMessage.setAlpha(0.5f);
            tvMessage.setTextSize(TypedValue.COMPLEX_UNIT_MM, 3.0f);
            return;
        } else if (message.isConfide) {
            tvMessage.setVisibility(View.GONE);
        }
        tvMessage.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        tvMessage.setAlpha(1.0f);
        String properContent = getProperMessageContent(message);
        if (TextUtils.isEmpty(properContent)) {
            tvMessage.setVisibility(View.GONE);
        } else {
            tvMessage.setVisibility(View.VISIBLE);
            tvMessage.setText(properContent);
            tvMessage.setMovementMethod(LinkMovementMethod.getInstance());
        }
        if (message.isEmoOnly) {
            tvMessage.setTextSize(TypedValue.COMPLEX_UNIT_MM, 6f);
        } else {
            tvMessage.setTextSize(TypedValue.COMPLEX_UNIT_MM, 3.0f);
        }


    }

    private String getProperMessageContent(Message message) {
        if (TextUtils.isEmpty(message.content) || message.mimeType == MimeType.Contact || message.isConfide) {
            return null;
        }

        if (message.content.startsWith(Constants.GROUP_SMS_PREFIX)) {
            String text = message.content.substring(message.content.indexOf(Constants.GROUP_SMS_SEPARATOR)).replace(Constants.GROUP_SMS_SEPARATOR, "").replace(Constants.GROUP_SMS_SUFFIX, "");
            String number = message.content.substring(0, message.content.indexOf(Constants.GROUP_SMS_SEPARATOR)).replace(Constants.GROUP_SMS_PREFIX, "").replace(Constants.GROUP_SMS_SEPARATOR, "");
            if (ChatProperties.isGroupChat && !TextUtils.isEmpty(Target.target)) {
                return text + "\n" + Supplier.getString(R.string.sms_to_group) + ": " + NameResolver.getGroupNameById(Target.target);
            }
            return text + "\n" + Supplier.getString(R.string.sms_to_number) + ": " + number;
        }
        if (message.mimeType == MimeType.Text || message.mimeType == MimeType.System || message.mimeType == MimeType.Link) {
            return message.content;
        }
        if (message.mimeType == MimeType.Image || message.mimeType == MimeType.Video) {
            return ChatContentParser.parseCaption(message.content);
        }
        if (message.mimeType == MimeType.Location) {
            return ChatContentParser.parseAddress(message.content);
        }

        return null;
    }

    private void handleName(Message message) {
        String name;
        if (message.messageType == MessageEntry.MessageType.RECEIVED || message.messageType == MessageEntry.MessageType.RECEIVED_SMS) {

            if (message.isLastOnConitiousStack) {
                name = CommonData.contactNumberToContactName.get(message.sender);
                if (TextUtils.isEmpty(name)) {
                    name = Util.getProperEmail(message.sender);
                }
                tvName.setVisibility(View.VISIBLE);
                tvName.setText(name);
            } else {
                tvName.setVisibility(View.GONE);
            }
        } else {
            tvName.setVisibility(View.GONE);
        }

    }

    private void handleHeader(Message message) {
        if (message.futureTime > 0) {
            tvDate.setVisibility(View.GONE);
        } else {
            if (message.isHeader) {
                tvDate.setVisibility(View.VISIBLE);
                tvDate.setText(ChatDateTimeFormatter.getHeaderDate(message.time));
            } else {
                tvDate.setVisibility(View.GONE);
            }
        }
    }
}