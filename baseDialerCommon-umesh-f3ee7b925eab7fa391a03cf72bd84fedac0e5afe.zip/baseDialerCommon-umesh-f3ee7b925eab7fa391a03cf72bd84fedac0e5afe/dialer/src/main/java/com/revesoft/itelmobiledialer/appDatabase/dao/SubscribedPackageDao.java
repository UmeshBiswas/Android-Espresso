/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:30 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:30 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.SubscribedPackage;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface SubscribedPackageDao extends BaseDao<SubscribedPackage> {
    @Query("SELECT * FROM subscribed_packages")
    List<SubscribedPackage> getAll();

    @Query("DELETE FROM SUBSCRIBED_PACKAGES")
    void deleteAll();

    @Query("SELECT * FROM SUBSCRIBED_PACKAGES WHERE package_id=:id")
    SubscribedPackage getSubscribedPackageInfoByID(String id);
}
