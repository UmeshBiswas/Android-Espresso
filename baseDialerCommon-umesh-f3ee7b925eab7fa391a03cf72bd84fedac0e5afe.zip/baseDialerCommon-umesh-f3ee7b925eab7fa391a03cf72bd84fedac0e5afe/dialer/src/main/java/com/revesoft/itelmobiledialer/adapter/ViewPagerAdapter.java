package com.revesoft.itelmobiledialer.adapter;

import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

/**
 * @author Ifta
 */

public class ViewPagerAdapter  extends FragmentPagerAdapter {
    private List<Fragment> fragments = new ArrayList<Fragment>();
    private Fragment currentFragment;

    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    public void addFragment(Fragment fragment) {
        fragments.add(fragment);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    public boolean replaceFragment(Fragment newFragment, String previousFragmentTag) {
        for (int i = 0; i < fragments.size(); i++) {
            String tag = fragments.get(i).getTag();
            if (tag.equals(previousFragmentTag)) {
                fragments.set(i, newFragment);
                return true;
            }
        }
        return false;
    }

    public Fragment getCurrentFragment() {
        return currentFragment;
    }

    @Override
    public void setPrimaryItem(ViewGroup container, int position, Object object) {
        if (getCurrentFragment() != object) {
            currentFragment = ((Fragment) object);
        }
        super.setPrimaryItem(container, position, object);
    }
}
