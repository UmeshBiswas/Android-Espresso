package com.revesoft.itelmobiledialer.contact.list;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class ContactViewModelFactory implements ViewModelProvider.Factory {
    private ContactType contactType;

    public ContactViewModelFactory(ContactType type) {
        this.contactType = type;
    }


    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new ContactListViewModel(contactType);
    }
}
