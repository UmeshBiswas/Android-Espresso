/*
 *  Created by Ifta on 8/9/18 1:13 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/9/18 1:10 PM
 *
 */

package com.revesoft.itelmobiledialer.dialer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.itelmobiledialer.permissions.StartupPermissionsActivity;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.service.DialerServiceBinder;
import com.revesoft.itelmobiledialer.signalling.sipUtil.ApplicationState;
import com.revesoft.itelmobiledialer.signup.ProfileInfoUpdateActivity;
import com.revesoft.itelmobiledialer.signup.SignUpActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ActivitySplashBinding;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static com.revesoft.itelmobiledialer.util.Constants.OP_CODE;


public class SplashScreenActivity extends AppCompatActivity {


    private static final int MIN_SPLASH_DISPLAY_LENGTH = 50;
    public static final String STOP_SPLASH = "splash_stop";
    public static final String GET_OPERATOR_CODE = "get_operator";
    private static final int REQUEST_PERMISSIONS_FOR_STARTING_SERVICE = 11;
    private SharedPreferences pref;
    private DialerServiceBinder mServiceBinder = null;
    private Handler handler;
    private View mainWindow;
    String opname;
    private boolean isRunning = false;
    ActivitySplashBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
//        UserDataManager.setUserName("8801844191311");
//        UserDataManager.setUserPassword("191311");
//        UserDataManager.setUserName("12345678");
//        UserDataManager.setUserPassword("1234");
//        UserDataManager.setUserName("8801844160137");
//        UserDataManager.setUserPassword("160137");
//


        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash);
        if (checkForCredential() && UserDataManager.hasUpdatedProfile()) {
            binding.windowToDashBoard.setVisibility(View.VISIBLE);
            binding.windowToNonDashBoard.setVisibility(View.GONE);
        } else {

            binding.windowToDashBoard.setVisibility(View.GONE);
            binding.windowToNonDashBoard.setVisibility(View.VISIBLE);
        }

        handler = new Handler(getMainLooper());
        handlePreference();
        isRunning = true;
        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getStartupPermissions(this).length > 0) {
            mainWindow = findViewById(R.id.windowToDashBoard);
            handler.postDelayed(() -> {
                Intent intent = new Intent(SplashScreenActivity.this, StartupPermissionsActivity.class);
                startActivityForResult(intent, REQUEST_PERMISSIONS_FOR_STARTING_SERVICE);
            }, MIN_SPLASH_DISPLAY_LENGTH);
        } else {
//            handler.postDelayed(() -> {
//                if (isRunning) {
            startService(new Intent(SplashScreenActivity.this, DialerService.class));
            mServiceBinder = new DialerServiceBinder(SplashScreenActivity.this).doBindService();
            startApplication();
//                }
//            }, MIN_SPLASH_DISPLAY_LENGTH);
        }
    }

    private void handlePreference() {

        pref = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
        DialerService.FIRST_RUN = pref.getBoolean("first_launch", true);
//        pref.edit().putInt(ALWAYS_ASK, R.id.always_ask_no).apply();
        pref.edit().putBoolean(Constants.IM_POPUP, Constants.IM_POPUP_B_DEF).apply();
        pref.edit().putBoolean(Constants.DIALER_OPEN, true).apply();
        pref.getBoolean(Constants.INTEGRATE_WITH_DIALER, Constants.INTEGRATE_WITH_DIALER_B_DEF);
        if (pref.getString(Constants.PRESENCE_STATUS, "-1").equals("-1"))
            pref.edit().putString(Constants.PRESENCE_STATUS, "available").apply();

        if (pref.getString(OP_CODE, "").length() == 0)
            pref.edit().putString(OP_CODE, getString(R.string.opcode)).apply();
//     pref.edit().putString(OP_CODE, "12892").putString(Constants.USERNAME, "8801767692072").putString(Constants.PASSWORD, "2072").putString(Constants.PHONE, "8801767692072").apply();
//        UserDataManager.setUserName("8801632316301");
//        UserDataManager.setUserPassword("316301");
    }

    @Override
    protected void onResume() {
        super.onResume();
        restartSipProvider();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 21)
            getWindow().setExitTransition(null);
        isRunning = false;
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        if (mServiceBinder != null) {
            mServiceBinder.doUnbindService();
        }
        super.onDestroy();
    }

    private void startApplication() {
        handler.postDelayed(() -> {
            Log.d("LogOut", "startApplication");
            if (checkForCredential()) {
                if (UserDataManager.hasUpdatedProfile()) {
                    Intent intent = new Intent(SplashScreenActivity.this, DashboardActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                    finish();
                } else {
                    Intent intent = new Intent(SplashScreenActivity.this, ProfileInfoUpdateActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivityForResult(intent, 0);
                    overridePendingTransition(0, 0);
                    finish();
                }
            } else {
                Intent mainIntent = new Intent(SplashScreenActivity.this, SignUpActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainIntent);
                overridePendingTransition(0, 0);
                finish();
            }
        }, 500);
    }

    private boolean checkForCredential() {
        boolean credentialFound = false;

        String user = UserDataManager.getUserName();
        String password = UserDataManager.getUserPassword();
        if (user.length() != 0 && password.length() != 0) {
            credentialFound = true;
        }

        return credentialFound;
    }

    public void signup(View view) {
        Log.d("LogOut", "signup");
        if (pref.getString(Constants.OP_CODE, "").length() == 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(SplashScreenActivity.this);
            builder.setMessage(getString(R.string.invalidApplication));
            builder.setCancelable(false);
            builder.setPositiveButton(R.string.exit, (dialog, which) -> {
                dialog.dismiss();
                finish();
            });
            builder.create().show();
        } else if (!checkForCredential()) {
            Intent mainIntent = new Intent(SplashScreenActivity.this, SignUpActivity.class);
            startActivity(mainIntent);
        } else {
            Toast.makeText(this, "You have already signed up.", Toast.LENGTH_SHORT).show();
            Intent mainIntent = new Intent(SplashScreenActivity.this, DashboardActivity.class);
            mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(mainIntent);
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        ApplicationState.activityPaused();
    }

    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                if (bundle.containsKey(STOP_SPLASH)) {
                    finish();
                } else if (bundle.containsKey(DashboardActivity.OPERATOR_NAME)) {
                    opname = intent.getExtras().getString(DashboardActivity.OPERATOR_NAME);
                    startApplication();
                }
//                else if (bundle.containsKey(GET_OPERATOR_CODE)) {
//                    getOperatorCodeFromUser();
//                } else if (bundle.containsKey(NETWORK_UNAVAILABLE)) {
//                    showNetworkAlert();
//                }
                else if (bundle.containsKey(Constants.EXIT)) {
                    exit();
                }
            }
        }

    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_PERMISSIONS_FOR_STARTING_SERVICE && resultCode == RESULT_OK) {
            handler.postDelayed(() -> {
                if (isRunning) {
                    startService(new Intent(SplashScreenActivity.this, DialerService.class));
                    mServiceBinder = new DialerServiceBinder(SplashScreenActivity.this).doBindService();
                    startApplication();
                }
            }, MIN_SPLASH_DISPLAY_LENGTH);
        } else if (requestCode == REQUEST_PERMISSIONS_FOR_STARTING_SERVICE && resultCode == RESULT_CANCELED) {
            if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getStartupPermissions(this).length > 0) {
                Snackbar.make(mainWindow, R.string.didnt_permit_closing_app, Snackbar.LENGTH_LONG)
                        .setAction(R.string.ok, v -> finish())
                        .show();
                handler.postDelayed(() -> finish(), MIN_SPLASH_DISPLAY_LENGTH);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private synchronized void restartSipProvider() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.RESTART_SIP_PROVIDER, "");
        LocalBroadcastManager.getInstance(this).sendBroadcast(i);
    }

    private void exit() {
        if (mServiceBinder != null && mServiceBinder.getBoundedService() != null)
            mServiceBinder.getBoundedService().stopSelf();
        finish();
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
