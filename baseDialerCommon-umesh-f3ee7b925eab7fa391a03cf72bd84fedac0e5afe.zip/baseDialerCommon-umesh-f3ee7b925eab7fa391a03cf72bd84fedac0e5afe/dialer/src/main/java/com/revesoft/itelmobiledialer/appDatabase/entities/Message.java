/*
 *  Created by Ifta on 8/8/18 11:06 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/6/18 8:54 AM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.UriNotifyEventListener;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.ims.emoticons.EmojiHelper;



import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */

@Entity(tableName = "messages")
public class Message extends EntityBase {
    public int _id = 100;
    @ColumnInfo(name = "groupid")
    public String groupId = null;
    @ColumnInfo(name = "filepath")
    public String filePath = null;
    @ColumnInfo(name = "messagetype")
    public int messageType = 2;
    @ColumnInfo(name = "deliverystatus")
    public int deliveryStatus = 2;
    @ColumnInfo(name = "notification")
    public int notification;
    @ColumnInfo(name = "received")
    public Date received = new Date(0);
    @ColumnInfo(name = "editcount")
    public int editCount = 0;
    @ColumnInfo(name = "futuresendtime")
    public long futureSendTime = 0;
    @ColumnInfo(name = "send_original_timestamp")
    public int sendOriginalTimeStamp;
    @ColumnInfo(name = "seentime")
    public int seenTime = 0;
    @ColumnInfo(name = "query_id")
    public String queryId = null;
    @ColumnInfo(name = "mime_type")
    public MimeType mimeType = AppDatabaseDefault.mimeType;
    @ColumnInfo(name = "is_decrypted")
    public boolean isDecrypted = true;
    @ColumnInfo(name = "is_encrypted")
    public boolean isEncrypted = false;
    public String ocid = null;
    public String qcid = null;
    @ColumnInfo(name = "quote_preview_content")
    public String quotePreviewContent = null;
    @ColumnInfo(name = "quote_from_user")
    public String quoteFromUser = null;
    @ColumnInfo(name = "quote_file_path")
    public String quoteFilePath = null;
    @ColumnInfo(name = "is_emo_only")
    public boolean isEmoOnly = false;
    @ColumnInfo(name = "long_message")
    public String longMessage = null;
    @ColumnInfo(name = "is_im_ready_for_view")
    public boolean isReadyToView = false;
    @ColumnInfo(name = "burn_timer_in_sec")
    public int burnTimerInSecond = -1;
    @ColumnInfo(name = "burn__scheduled_timestamp")
    public long burnScheduledTimeStamp = -1;
    @PrimaryKey(autoGenerate = false)
    @NonNull
    @ColumnInfo(name = "callerid", index = true)
    public String callerId = AppDatabaseDefault.callerId;
    @NonNull
    public String number = AppDatabaseDefault.number;
    @NonNull
    @ColumnInfo(name = "date")
    public Date date = AppDatabaseDefault.date;
    @NonNull
    @ColumnInfo(name = "messagecontent")
    public String content = AppDatabaseDefault.messageContent;
    @NonNull
    @ColumnInfo(name = "display_time")
    public Date displayTime = new Date(0);
    @ColumnInfo(name = "test")
    public int test;

    @ColumnInfo(name = "is_confined")
    public boolean isConfined = false;

    public Message() {
    }

    private Message(Builder builder) {
        _id = builder._id;
        callerId = builder.callerId;
        groupId = builder.groupId;
        number = builder.number;
        filePath = builder.filePath;
        messageType = builder.messageType;
        deliveryStatus = builder.deliveryStatus;
        date = builder.date;
        content = builder.content;
        notification = builder.notification;
        received = builder.received;
        editCount = builder.editCount;
        futureSendTime = builder.futureSendTime;
        sendOriginalTimeStamp = builder.sendOriginalTimeStamp;
        seenTime = builder.seenTime;
        queryId = builder.queryId;
        mimeType = builder.mimeType;
        isDecrypted = builder.isDecrypted;
        isEncrypted = builder.isEncrypted;
        ocid = builder.ocid;
        qcid = builder.qcid;

        quotePreviewContent = builder.quotePreviewContent;
        quoteFromUser = builder.quoteFromUser;
        quoteFilePath = builder.quoteFilePath;
        isEmoOnly = builder.isEmoOnly;
        displayTime = builder.displayTime;
        longMessage = builder.longMessage;
        isReadyToView = builder.isReadyToView;
        burnTimerInSecond = builder.burnTimerInSecond;
        burnScheduledTimeStamp = builder.burnScheduledTimeStamp;
        isConfined = builder.isConfined;
    }


    public static Message createFromMessageEntry(MessageEntry messageEntry) {
        MimeType mimeType;
        if ("system".equals(messageEntry.number)) {
            mimeType = MimeType.System;
        } else {
            mimeType = MimeTypeUtil.getMimeType(messageEntry.content);
        }
        long receivedTime = 0;
        if (messageEntry.editCount == 0) {
            receivedTime = System.currentTimeMillis();
        }
        else {
            receivedTime = MessageRepo.get().getMessageReceiveTime(messageEntry.callerId).getTime();
            if (receivedTime == 0) {
                receivedTime = System.currentTimeMillis();
            }
        }
        return Message.newBuilder()
                .number(messageEntry.number)
                .groupId(TextUtils.isEmpty(messageEntry.groupId) ? null : messageEntry.groupId)
                .date(new Date(messageEntry.time))
                .displayTime(new Date((messageEntry.time - UserDataManager.getTimeAdjustment())))
                .notification(messageEntry.status)
                .content(messageEntry.content)
                .messageType(messageEntry.type)
                .callerId(messageEntry.callerId)
                .deliveryStatus(messageEntry.delivery_status)
                .isEmoOnly(EmojiHelper.containsEmojiOnly(messageEntry.content))
                .ocid(messageEntry.ocid)
                .qcid(messageEntry.qcid)
                .quotePreviewContent(messageEntry.quoteData)
                .quoteFromUser(messageEntry.quoteFromUser)
                .quoteFilePath(messageEntry.quoteMessageFilePath)
                .longMessage(messageEntry.longMessage)
                .isReadyToView(messageEntry.getIsReadyForView() == 1)
                .received(new Date(receivedTime))
                .mimeType(mimeType)
                .editCount(messageEntry.editCount)
                .filePath(messageEntry.filePath)
                .isConfined(messageEntry.isConfide)
                .isEncrypted(messageEntry.isEncrypted == 1)
                .isDecrypted(messageEntry.isDecrypted == 1)
                .burnTimerInSecond((int) messageEntry.burnTimerMillis * 1000)
                .futureSendTime(messageEntry.futureSendTime)
                .sendOriginalTimeStamp(messageEntry.sendOriginalTimestampFlag)
                .build();
    }

    public MessageEntry convertMessageEntry() {
        MessageEntry messageEntry = new MessageEntry();
        messageEntry.groupId = groupId;
        messageEntry.isGroup = groupId.length() != 0;
        messageEntry.burnTimeInsec = burnTimerInSecond;
        messageEntry.callerId = callerId;
//        messageEntry.confideFileName;
        messageEntry.content = content;
        messageEntry.delivery_status = (short) deliveryStatus;
        messageEntry.editCount = editCount;
        messageEntry.filePath = filePath;
        messageEntry.futureSendTime = futureSendTime;
        messageEntry.id = _id;
        messageEntry.isConfide = isConfined;
        messageEntry.isDecrypted = isDecrypted ? 1 : 0;
        messageEntry.isEncrypted = isEncrypted ? 1 : 0;
        messageEntry.longMessage = longMessage;
//        messageEntry.messageId;
//        messageEntry.broadcastID
        messageEntry.burnTimerMillis = burnTimerInSecond * 1000;
        messageEntry.mimeType = mimeType.name();
        messageEntry.number = number;
        messageEntry.ocid = ocid;
        messageEntry.qcid = qcid;
        messageEntry.query_id = queryId;
        messageEntry.quoteData = quotePreviewContent;
        messageEntry.quoteFromUser = quoteFromUser;
        messageEntry.quoteMessageFilePath = quoteFilePath;
//        messageEntry.sendOriginalTimestampFlag;
//        messageEntry.serverFilePath;
        messageEntry.status = (short) notification;
        messageEntry.time = date.getTime();
        messageEntry.type = (short) messageType;
        messageEntry.setIsReadyForView(isReadyToView ? 1 : 0);
        return messageEntry;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    @Override
    public void save(UriNotifyEventListener listener) {

    }

    @Override
    public void delete(UriNotifyEventListener listener) {

    }

    @Override
    public void update(UriNotifyEventListener listener) {
        Executor.ex(() -> {
            int updatedRowCount = AppDatabase.get().messageDao().update(this);
            if (updatedRowCount > 0) {
                listener.notifyUri();
            }
        });
    }


    public static final class Builder {
        private int _id = 100;
        private String callerId = AppDatabaseDefault.callerId;
        private String groupId = AppDatabaseDefault.groupId;
        private String number = AppDatabaseDefault.number;
        private String filePath = null;
        private int messageType = 2;
        private int deliveryStatus = 2;
        private Date date = AppDatabaseDefault.date;
        private String content = AppDatabaseDefault.messageContent;
        private int notification;
        private Date received = new Date(0);
        private int editCount = 0;
        private long futureSendTime = 0;
        private int sendOriginalTimeStamp;
        private int seenTime = 0;
        private String queryId = null;
        private MimeType mimeType = AppDatabaseDefault.mimeType;
        private boolean isDecrypted = false;
        private boolean isEncrypted = true;
        private String ocid = null;
        private String qcid = null;
        private String quotePreviewContent = null;
        private String quoteFromUser = null;
        private String quoteFilePath = null;
        private boolean isEmoOnly = false;
        private Date displayTime = new Date(0);
        private String longMessage = null;
        private boolean isReadyToView = false;
        private int burnTimerInSecond = -1;
        private long burnScheduledTimeStamp = -1;
        boolean isConfined = false;

        private Builder() {
        }

        public Builder id(int id) {
            this._id = id;
            return this;
        }

        public Builder callerId(String callerId) {
            this.callerId = callerId;
            return this;
        }

        public Builder groupId(String groupId) {
            this.groupId = groupId;
            return this;
        }

        public Builder number(String number) {
            this.number = number;
            return this;
        }

        public Builder filePath(String filePath) {
            this.filePath = filePath;
            return this;
        }

        public Builder messageType(int messageType) {
            this.messageType = messageType;
            return this;
        }

        public Builder deliveryStatus(int deliveryStatus) {
            this.deliveryStatus = deliveryStatus;
            return this;
        }

        public Builder date(Date date) {
            this.date = date;
            return this;
        }

        public Builder content(String content) {
            this.content = content;
            return this;
        }

        public Builder notification(int notification) {
            this.notification = notification;
            return this;
        }

        public Builder received(Date received) {
            this.received = received;
            return this;
        }

        public Builder editCount(int editCount) {
            this.editCount = editCount;
            return this;
        }

        public Builder futureSendTime(long futureSendTime) {
            this.futureSendTime = futureSendTime;
            return this;
        }

        public Builder sendOriginalTimeStamp(short sendOriginalTimeStamp) {
            this.sendOriginalTimeStamp = sendOriginalTimeStamp;
            return this;
        }

        public Builder seenTime(int seenTime) {
            this.seenTime = seenTime;
            return this;
        }

        public Builder queryId(String queryId) {
            this.queryId = queryId;
            return this;
        }

        public Builder mimeType(MimeType mimeType) {
            this.mimeType = mimeType;
            return this;
        }

        public Builder isDecrypted(boolean isDecrypted) {
            this.isDecrypted = isDecrypted;
            return this;
        }

        public Builder isEncrypted(boolean isEncrypted) {
            this.isEncrypted = isEncrypted;
            return this;
        }

        public Builder ocid(String ocid) {
            this.ocid = ocid;
            return this;
        }

        public Builder qcid(String qcid) {
            this.qcid = qcid;
            return this;
        }

        public Builder quotePreviewContent(String quotePreviewContent) {
            this.quotePreviewContent = quotePreviewContent;
            return this;
        }

        public Builder quoteFromUser(String quoteFromUser) {
            this.quoteFromUser = quoteFromUser;
            return this;
        }

        public Builder quoteFilePath(String quoteFilePath) {
            this.quoteFilePath = quoteFilePath;
            return this;
        }

        public Builder isEmoOnly(boolean isEmoOnly) {
            this.isEmoOnly = isEmoOnly;
            return this;
        }

        public Builder displayTime(Date displayTime) {
            this.displayTime = displayTime;
            return this;
        }

        public Builder longMessage(String longMessage) {
            this.longMessage = longMessage;
            return this;
        }

        public Builder isReadyToView(boolean isReadyToView) {
            this.isReadyToView = isReadyToView;
            return this;
        }

        public Builder burnTimerInSecond(int val) {
            burnTimerInSecond = val;
            return this;
        }

        public Builder burnScheduledTimeStamp(long val) {
            burnScheduledTimeStamp = val;
            return this;
        }

        public Builder isConfined(boolean val) {
            this.isConfined = val;
            return this;
        }

        public Message build() {
            return new Message(this);
        }

        public Builder _id(int val) {
            _id = val;
            return this;
        }

    }
}