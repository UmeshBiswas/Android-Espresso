package com.revesoft.itelmobiledialer.Config;

import com.revesoft.itelmobiledialer.service.DialerService;

public class Config {
    public static final DialerService.DialerVariant DIALER_VARIANT = DialerService.DialerVariant.SALAM;
}
