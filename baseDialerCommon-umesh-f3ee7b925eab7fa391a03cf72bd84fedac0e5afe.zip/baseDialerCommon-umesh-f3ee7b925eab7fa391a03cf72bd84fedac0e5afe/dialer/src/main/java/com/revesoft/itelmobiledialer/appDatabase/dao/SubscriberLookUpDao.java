/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:46 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:46 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.SubscriberLookUp;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface SubscriberLookUpDao extends BaseDao<SubscriberLookUp>{


    @Query("SELECT COUNT(*) FROM SUBSCRIBER_LOOKUP_TABLE WHERE lookup_key=:lookup")
    boolean checkIfSubscriberLookExists(String lookup);


    @Query("DELETE FROM SUBSCRIBER_LOOKUP_TABLE")
    void deleteAllSubscribers();



    @Query("DELETE FROM SUBSCRIBER_LOOKUP_TABLE WHERE number=:number")
    void deleteSubscriberLookup(String number);


    @Query("SELECT * FROM SUBSCRIBER_LOOKUP_TABLE")
    Cursor getSubscriberLookUpCursor();

}
