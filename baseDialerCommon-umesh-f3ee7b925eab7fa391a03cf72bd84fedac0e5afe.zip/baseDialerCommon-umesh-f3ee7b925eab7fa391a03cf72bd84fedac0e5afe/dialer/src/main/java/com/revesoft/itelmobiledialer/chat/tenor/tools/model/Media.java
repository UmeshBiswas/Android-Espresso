package com.revesoft.itelmobiledialer.chat.tenor.tools.model;


import android.text.TextUtils;

import androidx.annotation.NonNull;


public class Media extends Image {
    private static final long serialVersionUID = -8616498739266612929L;
    private String preview;
    private double duration;

    /**
     * @return url of a static image pipRenderer
     */
    @NonNull
    public String getPreviewUrl() {
        return getOrEmpty(preview);
    }

    /**
     * @return duration of each loop, in seconds
     */
    public double getDuration() {
        return duration;
    }
    private String getOrEmpty(String url){
        return TextUtils.isEmpty(url)?"":url;
    }
}
