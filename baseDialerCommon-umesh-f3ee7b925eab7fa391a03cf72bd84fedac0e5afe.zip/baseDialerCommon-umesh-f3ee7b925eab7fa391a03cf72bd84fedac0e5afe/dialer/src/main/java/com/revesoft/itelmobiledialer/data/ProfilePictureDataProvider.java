package com.revesoft.itelmobiledialer.data;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.util.AppContext;

import org.jetbrains.annotations.Nullable;

import java.io.File;

/**
 * @author Ifta
 *         on 3/15/2017.
 */

public class ProfilePictureDataProvider {
    public static String getProfilePicturePath(Context context, String phoneNumber) {
        File profileFile = null;
        if(ProfilePicUploadDownloadHelper.checkIfProfilePictureIsAvailable(context,phoneNumber)){
            profileFile = ProfilePicUploadDownloadHelper.getProfilePictureFile(context, phoneNumber);
        }
        if (profileFile == null) {
            return null;
        }
        return profileFile.getAbsolutePath();
    }

    public static Bitmap getProfilePictureAsBitmap(Context context, String phoneNumber) {
        String filePath = getProfilePicturePath(context, phoneNumber);
        if (filePath == null) {
            return null;
        }
        return BitmapFactory.decodeFile(filePath);
    }

    public static String getProfilePictureAsFilePath(Context context, String phoneNumber) {
        String filePath = getProfilePicturePath(context, phoneNumber);
        return filePath;
    }

    public static String getOwnProfilePicturePath(Context context) {
        return getProfilePicturePath(context,null);
    }
    @Nullable
    public static String getProfilePicturePath(String phoneNumber) {
        if(phoneNumber!=null && UserDataManager.getUserName().equals(phoneNumber)){
            phoneNumber = null;
        }
        File profileFile = null;
        if (ProfilePicUploadDownloadHelper.checkIfProfilePictureIsAvailable(AppContext.getAccess().getContext(), phoneNumber)) {
            profileFile = ProfilePicUploadDownloadHelper.getProfilePictureFile(AppContext.getAccess().getContext(), phoneNumber);
        }
        if (profileFile == null) {
            if (phoneNumber !=null && CommonData.contactNumberToContactImageUri.containsKey(phoneNumber)) {
                return CommonData.contactNumberToContactImageUri.get(phoneNumber);
            }
            return null;
        }
        return profileFile.getAbsolutePath();
    }

    public static Bitmap getProfilePictureAsBitmap(String phoneNumber) {
        String filePath = getProfilePicturePath(phoneNumber);
        if (filePath == null) {
            return null;
        }
        return BitmapFactory.decodeFile(filePath);
    }

    public static String getOwnProfilePicturePath() {
        return getProfilePicturePath(null);
    }
}
