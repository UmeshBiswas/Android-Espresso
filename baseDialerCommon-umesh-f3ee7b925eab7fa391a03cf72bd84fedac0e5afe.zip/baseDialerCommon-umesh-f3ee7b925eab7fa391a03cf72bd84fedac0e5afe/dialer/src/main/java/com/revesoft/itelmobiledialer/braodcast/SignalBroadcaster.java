package com.revesoft.itelmobiledialer.braodcast;

import android.content.Context;
import android.content.Intent;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.revesoft.itelmobiledialer.util.Constants;

/**
 * @author Ifta on 5/29/2017.
 */

public class SignalBroadcaster {
    public enum SignalType {
        CONTACT_LOADED_IN_COMMON_DATA,
        CONTACT_LOADED,
        CALL_LOG_LOADED,
        GROUP_PROFILE_PICTURE_DOWNLOAD_FINISHED,
        SMS_LOADED
    }

    private static LocalBroadcastManager localBroadcastManager = null;

    public static void register(Context context) {
        localBroadcastManager = LocalBroadcastManager.getInstance(context);
    }

    public static void sendSignal(SignalType signalType) {
        Intent intent = new Intent(Constants.SIGNAL_INTENT_FILTER);
        intent.putExtra(signalType.toString(), true);
        localBroadcastManager.sendBroadcast(intent);
    }
}
