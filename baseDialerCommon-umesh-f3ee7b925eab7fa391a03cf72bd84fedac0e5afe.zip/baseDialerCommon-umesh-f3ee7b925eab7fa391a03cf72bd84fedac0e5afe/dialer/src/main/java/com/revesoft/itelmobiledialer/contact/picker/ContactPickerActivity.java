package com.revesoft.itelmobiledialer.contact.picker;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.chip.Chip;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.util.ViewSetup;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ActivityContactPickerActivityBinding;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.databinding.DataBindingUtil;

public class ContactPickerActivity extends AppCompatActivity {
    private static ContactPickedListener listener;
    ActivityContactPickerActivityBinding binding;
    private ContactPickerListFragment pickerListFragment;
    private Toolbar toolbar;

    @SuppressWarnings("unused")
    public static void startPicker(Context context, ContactType contactType, List<String> preSelectedContacts, ContactPickedListener listener) {
        Intent intent = new Intent(context, ContactPickerActivity.class);
        intent.putStringArrayListExtra("selectedContactList", new ArrayList<>(preSelectedContacts));
        intent.putExtra("contactType", contactType);
        ContactPickerActivity.listener = listener;
        context.startActivity(intent);
    }

    public static void startPicker(Context context, ContactType contactType, ContactPickedListener listener) {
        Intent intent = new Intent(context, ContactPickerActivity.class);
        intent.putExtra("contactType", contactType);
        ContactPickerActivity.listener = listener;
        context.startActivity(intent);
    }


    public static void startPicker(Context context, ContactType contactType, ContactSelectiontype contactSelectiontype, ContactPickedListener listener) {
        Intent intent = new Intent(context, ContactPickerActivity.class);
        intent.putExtra("contactType", contactType);
        intent.putExtra("contactSelectionType", contactSelectiontype);
        ContactPickerActivity.listener = listener;
        context.startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        readData();
        binding = DataBindingUtil.setContentView(this, R.layout.activity_contact_picker_activity);
        toolbar = ViewSetup.setUpToolbar(this, getString(R.string.selectContacts), true);
        if (contactSelectiontype == ContactSelectiontype.MULTIPLE_SELECT) {
            PickedContacts.attachListener(pickerListener);
            binding.fab.setVisibility(View.VISIBLE);
        } else {
            binding.fab.setVisibility(View.GONE);

        }

        pickerListFragment = ContactPickerListFragment.newInstance(false, contactType, contactSelectiontype);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.contactListFrame, pickerListFragment).commit();
        PickedContacts.addAll(selectedContactList);
    }

    PickerListener pickerListener = new PickerListener() {
        @Override
        public void onAdd(ContactListItem contact) {
            addChip(contact);
            pickerListFragment.onChangeContact(contact);
            toolbar.setSubtitle(String.format(Locale.ENGLISH, getString(R.string.selectedContactCount), PickedContacts.getCount(), pickerListFragment.getCount()));
            clearSearchIfExists();
        }

        @Override
        public void onRemove(ContactListItem contact) {
            removeChip(contact);
            pickerListFragment.onChangeContact(contact);
            if (PickedContacts.size() == 0) {
                toolbar.setSubtitle("");
            } else {
                toolbar.setSubtitle(String.format(Locale.ENGLISH, getString(R.string.selectedContactCount), PickedContacts.getCount(), pickerListFragment.getCount()));
            }
            clearSearchIfExists();
        }

        @Override
        public void onAddAll() {

        }
    };

    private void addChip(ContactListItem contact) {
        Chip chip = (Chip) getLayoutInflater().inflate(R.layout.contact_chip_layout, binding.chipGroup, false);
        chip.setText(contact.getName());
        chip.setOnCloseIconClickListener(v -> PickedContacts.remove(contact));
        chip.setClickable(false);
        chip.setTag(contact);
        binding.chipGroup.addView(chip);
        binding.chipGroup.postDelayed(() -> binding.chipHolder.fullScroll(HorizontalScrollView.FOCUS_DOWN), 250);

    }

    private void removeChip(ContactListItem contact) {
        int toBeRemoved = -1;
        int chipHeight =0;
        for (int i = 0; i < binding.chipGroup.getChildCount(); i++) {
            Chip chip = (Chip) binding.chipGroup.getChildAt(i);
            if (chip.getTag() != null && chip.getTag().equals(contact)) {
                toBeRemoved = i;
                chipHeight = chip.getHeight();
                break;
            }
        }
        if (toBeRemoved != -1) {
            binding.chipGroup.removeViewAt(toBeRemoved);
        }

    }




    private ContactType contactType;
    private ContactSelectiontype contactSelectiontype;
    private ArrayList<String> selectedContactList = new ArrayList<>();

    private void readData() {
        if (getIntent().hasExtra("contactType")) {
            contactType = (ContactType) getIntent().getSerializableExtra("contactType");
        }
        if (getIntent().hasExtra("contactSelectionType")) {
            contactSelectiontype = (ContactSelectiontype) getIntent().getSerializableExtra("contactSelectionType");
        }

        if (contactType == null) {
            contactType = ContactType.APP;
        }

        if (contactSelectiontype == null) {
            contactSelectiontype = ContactSelectiontype.MULTIPLE_SELECT;
        }

        if (getIntent().hasExtra("selectedContactList")) {
            selectedContactList = getIntent().getStringArrayListExtra("selectedContactList");
        }
    }



    @Override
    protected void onPause() {
        super.onPause();
        PickedContacts.clear();
    }

    public void done(View view) {
        List<String> numbersPicked = new ArrayList<>();
        for (ContactListItem item : PickedContacts.getAll()) {
            numbersPicked.add(item.getProcessedNumber());
        }
        if (listener != null && numbersPicked.size()>0) {
            listener.onContactPicked(numbersPicked, new ArrayList<>(PickedContacts.getAll()));
        }
        else
        {
            Toast.makeText(ContactPickerActivity.this,R.string.no_conctact_selected,Toast.LENGTH_LONG).show();
            return;
        }
        finish();
    }


    private SearchView searchView;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.contact_picker_menu, menu);
        final MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
            setSearchCursorColorToAccent(searchView);
        }
        if (searchView != null) {

            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setIconifiedByDefault(true);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    if (pickerListFragment != null) {
                        if (TextUtils.isEmpty(newText)) {
                            pickerListFragment.search("");
                        } else {
                            pickerListFragment.search(newText);
                        }
                    }
                    return true;
                }
            });
        }
        return super.onCreateOptionsMenu(menu);
    }


    private void setSearchCursorColorToAccent(SearchView searchView) {
        AutoCompleteTextView searchTextView = (AutoCompleteTextView) searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        try {
            Field mCursorDrawableRes = TextView.class.getDeclaredField("mCursorDrawableRes");
            mCursorDrawableRes.setAccessible(true);
            mCursorDrawableRes.set(searchTextView, R.drawable.cursor);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return true;
    }

    public void clearSearchIfExists() {
        if(searchView !=null && !searchView.isIconified())
        {
            searchView.setQuery("",true);
            searchView.setIconified(true);
            toolbar.setSubtitle(String.format(Locale.ENGLISH, getString(R.string.selectedContactCount), PickedContacts.getCount(), pickerListFragment.getCount()));
        }
    }

}
