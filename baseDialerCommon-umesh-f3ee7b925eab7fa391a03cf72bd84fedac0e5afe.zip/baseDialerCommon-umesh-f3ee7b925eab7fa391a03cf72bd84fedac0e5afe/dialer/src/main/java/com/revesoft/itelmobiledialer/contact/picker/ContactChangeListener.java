package com.revesoft.itelmobiledialer.contact.picker;



import com.revesoft.itelmobiledialer.contact.list.ContactListItem;

interface ContactChangeListener {
    void onChangeContact(ContactListItem item);
}
