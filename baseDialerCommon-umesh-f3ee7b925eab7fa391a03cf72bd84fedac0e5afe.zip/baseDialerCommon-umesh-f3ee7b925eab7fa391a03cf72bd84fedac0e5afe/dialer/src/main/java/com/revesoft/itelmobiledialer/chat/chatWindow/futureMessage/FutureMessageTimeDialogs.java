package com.revesoft.itelmobiledialer.chat.chatWindow.futureMessage;
import android.app.Dialog;
import android.util.Log;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.FutureMessageDateTimeListener;
import com.revesoft.material.R;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Ifta on 1/3/2018.
 */

public class FutureMessageTimeDialogs {

    private static final String TAG = "FutureMessageTimeDialog";

    public static void showDateTimePicker(final FutureMessageDateTimeListener futureMessageDateTimeListener) {
        final Dialog dialog = ChatWindowActivity.getDialog();
        //showDateTimePicker(dialog,futureMessageDateTimeListener);
    }

    public static void showDateTimePicker(AppCompatActivity activity, final FutureMessageDateTimeListener futureMessageDateTimeListener) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setTitle(R.string.send_in_future);
        dialog.setContentView(R.layout.date_picker_dialog);
        TextView dateField = dialog.findViewById(R.id.date);
        TextView timeField = dialog.findViewById(R.id.time);
        CheckBox isSendingCurrentTimeStampCheckBox = dialog.findViewById(R.id.is_sending_timestamp_checkbox);

        TimePickerDialog.OnTimeSetListener onTimeSetListener = (view, hourOfDay, minute, second) -> {
            try {
                String time = hourOfDay + ":" + minute;
                SimpleDateFormat parsingFormat = new SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
                SimpleDateFormat outputFormat = new SimpleDateFormat("hh:mm a", java.util.Locale.getDefault());
                time = outputFormat.format(parsingFormat.parse(time));
                timeField.setText(time);
            }catch (Exception e)
            {
                Log.e(TAG,"error",e);
            }
        };

        DatePickerDialog.OnDateSetListener onDateSetListener = (view, year, monthOfYear, dayOfMonth) -> {
            try {
                monthOfYear += 1;
                String date = year + "-" + monthOfYear + "-" + dayOfMonth;
                SimpleDateFormat parsingFormat = new SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
                SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault());
                date = outputFormat.format(parsingFormat.parse(date));
                dateField.setText(date);

                if(timeField.getText().toString().equals(activity.getResources().getString(R.string.not_set_yet))) {
                    showTimePickerDialog(activity, onTimeSetListener);
                }
            }catch (Exception e)
            {
                Log.e(TAG,"error",e);
            }

        };


        dialog.findViewById(R.id.change_date).setOnClickListener(v -> {
            showDatePickerDialog(activity, onDateSetListener);
        });


        dialog.findViewById(R.id.change_time).setOnClickListener(v -> {
            showTimePickerDialog(activity, onTimeSetListener);
        });

        showDatePickerDialog(activity,onDateSetListener);

        dialog.findViewById(R.id.confirm).setOnClickListener(v -> {
            try{
                String pickedDateTime = dateField.getText().toString() + " " + timeField.getText().toString();
                Log.i("timeeeee",pickedDateTime);
                SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm a", java.util.Locale.getDefault());
                futureMessageDateTimeListener.onDateTimePicked(dateTimeFormat.parse(pickedDateTime), isSendingCurrentTimeStampCheckBox.isChecked());
            }catch(Exception e) {
                Log.e(TAG,"error",e);
            }
            finally {
                dialog.dismiss();
            }
        });

        dialog.findViewById(R.id.cancel).setOnClickListener(v -> {
            dialog.dismiss();
        });

        dialog.show();
    }


    private static void showDatePickerDialog(AppCompatActivity activity, DatePickerDialog.OnDateSetListener dateSetListener)
    {
        Calendar now = Calendar.getInstance();
        DatePickerDialog pickerDialog = DatePickerDialog.newInstance(
                dateSetListener,
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
        );

        pickerDialog.setMinDate(now);
        pickerDialog.show(activity.getSupportFragmentManager(), "Datepickerdialog");
    }


    private static void showTimePickerDialog(AppCompatActivity activity, TimePickerDialog.OnTimeSetListener timeSetListener)
    {
        TimePickerDialog pickerDialog = TimePickerDialog.newInstance(timeSetListener,false);
        pickerDialog.show(activity.getSupportFragmentManager(), "Datepickerdialog");
    }



    public static Date getTime(DatePicker datePicker, TimePicker timePicker) {
        StringBuilder sendTime = new StringBuilder();
        sendTime.append(datePicker.getYear()).append("-");
        int month = datePicker.getMonth();
        month++;
        if (month < 10) {
            sendTime.append("0").append(month).append("-");
        } else {
            sendTime.append(month).append("-");
        }

        int day = datePicker.getDayOfMonth();
        if (day < 10) {
            sendTime.append("0").append(day).append("T");
        } else {
            sendTime.append(day).append("T");
        }

        int hour = timePicker.getCurrentHour();
        if (hour < 10) {
            sendTime.append("0").append(hour).append(":");
        } else {
            sendTime.append(hour).append(":");
        }

        int minute = timePicker.getCurrentMinute();
        if (minute < 10) {
            sendTime.append("0").append(minute).append("00.050").append("Z");
        } else {
            sendTime.append(minute).append(":00.050").append("Z");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
        try {
            return sdf.parse(sendTime.toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}
