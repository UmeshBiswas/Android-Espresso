package com.revesoft.itelmobiledialer.customview.editcodeview;

/**
 * Created by Alexandr Grizhinku on 15/07/2017.
 * alexg.mobiledev@gmail.com
 */

public interface EditCodeWatcher {
    void onCodeChanged(String code);
}
