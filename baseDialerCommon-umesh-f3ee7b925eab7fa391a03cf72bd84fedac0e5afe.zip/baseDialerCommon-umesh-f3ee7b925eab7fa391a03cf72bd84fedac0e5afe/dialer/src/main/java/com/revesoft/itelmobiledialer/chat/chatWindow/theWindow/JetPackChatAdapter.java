package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDateTimeFormatter;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.AudioMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.CallViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.ConfideMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.ContactMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.DataUsageRestrictedMessagesViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.E2EViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.EmptyMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.ImageAndVideoMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.LocationMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.MediaMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.SystemMessageViewHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.TextMessageViewHolder;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import androidx.annotation.NonNull;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

public class JetPackChatAdapter extends PagedListAdapter<Message, RecyclerView.ViewHolder> {

    private TaggedLogger logger = new TaggedLogger("ChatWindow");
    private int endToEndEncryption;
    private static final int TEXT_MESSAGE_VIEW_SENT = 1;
    private static final int TEXT_MESSAGE_VIEW_RECEIVED = 51;
    private static final int CONTACT_MESSAGE_VIEW_SENT = 2;
    private static final int CONTACT_MESSAGE_VIEW_RECEIVED = 52;
    private static final int MEDIA_MESSAGE_VIEW_SENT = 3;
    private static final int MEDIA_MESSAGE_VIEW_RECEIVED = 53;
    private static final int AUDIO_MESSAGE_VIEW_SENT = 4;
    private static final int AUDIO_MESSAGE_VIEW_RECEIVED = 54;
    private static final int IMAGE_VIDEO_VIEW_RECEIVED = 5;
    private static final int IMAGE_VIDEO_VIEW_SENT = 55;
    private static final int STICKER_GIF_VIEW_RECEIVED = 6;
    private static final int STICKER_GIF_VIEW_SENT = 56;
    private static final int CONFIDE_MESSAGE_VIEW_SENT = 7;
    private static final int CONFIDE_MESSAGE_VIEW_RECEIVED = 57;
    private static final int LOCATION_MESSAGE_VIEW_SENT = 8;
    private static final int LOCATION_MESSAGE_VIEW_RECEIVED = 58;
    private static final int DATA_USAGE_RESTRICTED_VIEW = 9;
    private static final int SYSTEM_MESSAGE_VIEW = 100;
    private static final int EMPTY_MESSAGE_VIEW = 101;
    private static final int E2E_VIEW = 102;
    private static final int CALL_VIEW = 103;

    private MessageType messageType;


    public JetPackChatAdapter(boolean isEncrypted, MessageType messageType) {
        super(DIFF_CALLBACK);
        this.endToEndEncryption = isEncrypted ? 1 : 0;
        this.messageType = messageType;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        try {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            switch (viewType) {
                case TEXT_MESSAGE_VIEW_RECEIVED:
                    return new TextMessageViewHolder(layoutInflater.inflate(R.layout.text_bubble_received, parent, false));
                case TEXT_MESSAGE_VIEW_SENT:
                    return new TextMessageViewHolder(layoutInflater.inflate(R.layout.text_bubble_sent, parent, false));
                case LOCATION_MESSAGE_VIEW_RECEIVED:
                    return new LocationMessageViewHolder(layoutInflater.inflate(R.layout.location_bubble_received, parent, false));
                case LOCATION_MESSAGE_VIEW_SENT:
                    return new LocationMessageViewHolder(layoutInflater.inflate(R.layout.location_bubble_sent, parent, false));
                case MEDIA_MESSAGE_VIEW_RECEIVED:
                    return new MediaMessageViewHolder(layoutInflater.inflate(R.layout.media_bubble_received, parent, false));
                case MEDIA_MESSAGE_VIEW_SENT:
                    return new MediaMessageViewHolder(layoutInflater.inflate(R.layout.media_bubble_sent, parent, false));
                case STICKER_GIF_VIEW_RECEIVED:
                    return new MediaMessageViewHolder(layoutInflater.inflate(R.layout.sticker_gif_bubble_received, parent, false));
                case STICKER_GIF_VIEW_SENT:
                    return new MediaMessageViewHolder(layoutInflater.inflate(R.layout.sticker_gif_bubble_sent, parent, false));
                case IMAGE_VIDEO_VIEW_RECEIVED:
                    return new ImageAndVideoMessageViewHolder(layoutInflater.inflate(R.layout.image_video_bubble_received, parent, false));
                case IMAGE_VIDEO_VIEW_SENT:
                    return new ImageAndVideoMessageViewHolder(layoutInflater.inflate(R.layout.image_video_bubble_sent, parent, false));
                case AUDIO_MESSAGE_VIEW_RECEIVED:
                    return new AudioMessageViewHolder(layoutInflater.inflate(R.layout.audio_bubble_received, parent, false));
                case AUDIO_MESSAGE_VIEW_SENT:
                    return new AudioMessageViewHolder(layoutInflater.inflate(R.layout.audio_bubble_sent, parent, false));
                case CONTACT_MESSAGE_VIEW_RECEIVED:
                    return new ContactMessageViewHolder(layoutInflater.inflate(R.layout.contact_bubble_received, parent, false));
                case CONTACT_MESSAGE_VIEW_SENT:
                    return new ContactMessageViewHolder(layoutInflater.inflate(R.layout.contact_bubble_sent, parent, false));
                case CONFIDE_MESSAGE_VIEW_RECEIVED:
                    return new ConfideMessageViewHolder(layoutInflater.inflate(R.layout.confide_bubble_received, parent, false));
                case CONFIDE_MESSAGE_VIEW_SENT:
                    return new ConfideMessageViewHolder(layoutInflater.inflate(R.layout.confide_bubble_sent, parent, false));
                case CALL_VIEW:
                    return new CallViewHolder(layoutInflater.inflate(R.layout.missed_call_bubble, parent, false));
                case SYSTEM_MESSAGE_VIEW:
                    return new SystemMessageViewHolder(layoutInflater.inflate(R.layout.system_message_bubble, parent, false));
                case E2E_VIEW:
                    return new E2EViewHolder(layoutInflater.inflate(R.layout.end_to_end_bubble, parent, false));
                case EMPTY_MESSAGE_VIEW:
                    return new EmptyMessageViewHolder(layoutInflater.inflate(R.layout.empty_message_bubble, parent, false));
                case DATA_USAGE_RESTRICTED_VIEW:
                    return new DataUsageRestrictedMessagesViewHolder(layoutInflater.inflate(R.layout.data_restricted_download_anyway_bubble, parent, false));
            }
        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();

        }
        return null;
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof E2EViewHolder) {
            ((E2EViewHolder) holder).bindView();
            return;
        } else if (holder instanceof EmptyMessageViewHolder) {
            ((EmptyMessageViewHolder) holder).bindView();
            return;
        }
        position = position - endToEndEncryption;
        Message message = getItem(position);
        if (message != null) {
            message.isHeader = false;
            if (position == 0) {
                message.isHeader = true;
            } else {
                Message previousMessage = getItem(position - 1);
                if (previousMessage != null) {
                    message.isHeader = !ChatDateTimeFormatter.getComparableDate(message.time).equals(ChatDateTimeFormatter.getComparableDate(previousMessage.time));
                }
            }
            message.isLastOnConitiousStack = false;
            if (position < getItemCount() - 1) {
                Message nextMessage = getItem(position + 1);
                if (nextMessage != null) {
                    message.isLastOnConitiousStack = nextMessage.messageType != message.messageType
                            || !nextMessage.sender.equals(message.sender)
                            || !ChatDateTimeFormatter.getComparableDate(nextMessage.time).equals(ChatDateTimeFormatter.getComparableDate(message.time));
                }
            } else {
                message.isLastOnConitiousStack = true;
            }
        }
        if(holder instanceof DataUsageRestrictedMessagesViewHolder){
            ((DataUsageRestrictedMessagesViewHolder) holder).bindView(message);
        }
        if (holder instanceof ImageAndVideoMessageViewHolder) {
            ((ImageAndVideoMessageViewHolder) holder).bindView(message);
        } else if (holder instanceof MediaMessageViewHolder) {
            ((MediaMessageViewHolder) holder).bindView(message);
        } else if (holder instanceof AudioMessageViewHolder) {
            ((AudioMessageViewHolder) holder).bindView(message);
        } else if (holder instanceof ContactMessageViewHolder) {
            ((ContactMessageViewHolder) holder).bindView(message, position);
        } else if (holder instanceof CallViewHolder) {
            ((CallViewHolder) holder).bindView(message);
        } else if (holder instanceof SystemMessageViewHolder) {
            ((SystemMessageViewHolder) holder).bindView(message);
        }
        if (holder instanceof LocationMessageViewHolder) {
            ((LocationMessageViewHolder) holder).bindView(message);
        } else if (holder instanceof TextMessageViewHolder) {
            ((TextMessageViewHolder) holder).bindView(message);
        }
    }

    @Override
    public int getItemViewType(int position) {
        Message message = getItem(position);

        if (message != null) {

            if(message.deliveryStatus == MessageEntry.DeliveryStatus.READY_TO_DOWNLOAD)
            {
                return DATA_USAGE_RESTRICTED_VIEW;
            }

            if (message.isConfide) {
                if (message.messageType == MessageEntry.MessageType.RECEIVED) {
                    return CONFIDE_MESSAGE_VIEW_RECEIVED;
                } else {
                    return CONFIDE_MESSAGE_VIEW_SENT;
                }
            }
            if (message.messageType == MessageEntry.MessageType.RECEIVED || message.messageType == MessageEntry.MessageType.RECEIVED_SMS) {
                switch (message.mimeType) {
                    case Text:
                    case Link:
                    case Dummy:
                        return TEXT_MESSAGE_VIEW_RECEIVED;
                    case Image:
                    case Video:
                        return IMAGE_VIDEO_VIEW_RECEIVED;
                    case GIF:
                    case Sticker:
                    case CallRejectSticker:
                    case StaticSticker:
                        return STICKER_GIF_VIEW_RECEIVED;
                    case Location:
                        return LOCATION_MESSAGE_VIEW_RECEIVED;
                    case Document:
                    case LocationRequest:
                        return MEDIA_MESSAGE_VIEW_RECEIVED;
                    case Audio:
                        return AUDIO_MESSAGE_VIEW_RECEIVED;
                    case Contact:
                        return CONTACT_MESSAGE_VIEW_RECEIVED;
                    case Call:
                        return CALL_VIEW;
                    case System:
                        return SYSTEM_MESSAGE_VIEW;
                    case Deleted:
                        return TEXT_MESSAGE_VIEW_RECEIVED;
                    default:
                        return EMPTY_MESSAGE_VIEW;
                }

            } else {
                switch (message.mimeType) {
                    case Text:
                    case Link:
                    case Dummy:
                        return TEXT_MESSAGE_VIEW_SENT;
                    case Image:
                    case Video:
                        return IMAGE_VIDEO_VIEW_SENT;
                    case GIF:
                    case Sticker:
                    case CallRejectSticker:
                    case StaticSticker:
                        return STICKER_GIF_VIEW_SENT;
                    case Location:
                        return LOCATION_MESSAGE_VIEW_SENT;
                    case Document:
                    case LocationRequest:
                        return MEDIA_MESSAGE_VIEW_SENT;
                    case Audio:
                        return AUDIO_MESSAGE_VIEW_SENT;
                    case Contact:
                        return CONTACT_MESSAGE_VIEW_SENT;
                    case Call:
                        return CALL_VIEW;
                    case System:
                        return SYSTEM_MESSAGE_VIEW;
                    case Deleted:
                        return TEXT_MESSAGE_VIEW_SENT;
                    default:
                        return EMPTY_MESSAGE_VIEW;
                }
            }
        }
        return EMPTY_MESSAGE_VIEW;
    }

    public enum MessageType {
        REGULAR, FUTURE, INFO
    }

    private static DiffUtil.ItemCallback<Message> DIFF_CALLBACK = new DiffUtil.ItemCallback<Message>() {
        @Override
        public boolean areItemsTheSame(@NonNull Message oldItem, @NonNull Message newItem) {
            return oldItem.callerId.equals(newItem.callerId);
        }

        @Override
        public boolean areContentsTheSame(@NonNull Message oldItem, @NonNull Message newItem) {
            return oldItem.deliveryStatus == newItem.deliveryStatus
                    && oldItem.content.equals(newItem.content)
                    && oldItem.isLastOnConitiousStack == newItem.isLastOnConitiousStack
                    && oldItem.qcid.equals(newItem.qcid);
        }
    };


}
