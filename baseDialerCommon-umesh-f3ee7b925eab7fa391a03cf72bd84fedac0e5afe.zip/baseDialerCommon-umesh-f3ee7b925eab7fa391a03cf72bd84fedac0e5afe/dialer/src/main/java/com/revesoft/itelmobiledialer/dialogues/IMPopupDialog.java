package com.revesoft.itelmobiledialer.dialogues;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.ims.GroupMessageAssistant;
import com.revesoft.itelmobiledialer.notification.custom_notification.MessageNotification;
import com.revesoft.itelmobiledialer.service.dialerService.BagName;
import com.revesoft.itelmobiledialer.service.dialerService.MessageBag;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.CustomNotification;
import com.revesoft.material.R;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class IMPopupDialog extends Activity {
    public static final String IMPOPUP_ACTION = "im_popup_action";
    public static final String IMPOPUP_MESSAGE_EXIT = "im_popup_message_exit";
    public static final String MESSAGE = "message";
    public static final String TIME = "time";
    public static final String NUMBER = "number";
    public static final String GROUP_ID = "groupid";

    private String number = null;
    private String groupID = null;
    private EditText mNewMessage;
    private ImageButton mButtonSend;
    private TextView title;
    private TextView groupTitle;
    private TextView timeView;
    private TextView mPortraitTxt;
    private ImageView mPortrait;
    private TextView mMessage;
    private String time = null;

    private boolean isGroupMessage = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_impopup_dialog);
        mPortraitTxt = findViewById(R.id.portraitTxt);
        mPortrait = findViewById(R.id.portrait);
        title = findViewById(R.id.title);
        groupTitle = findViewById(R.id.group_title);
        timeView = findViewById(R.id.time);

        number = getIntent().getStringExtra(NUMBER);
        if (number == null || number.equals("")) {
            finish();
            return;
        }

        findViewById(R.id.btm_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        if(number.matches(".*[a-zA-Z]+.*"))
            findViewById(R.id.message_sending_layout).setVisibility(View.GONE);

        time = getIntent().getStringExtra(TIME);
        if (time == null) {
            timeView.setVisibility(View.GONE);
        } else timeView.setText(time);

        groupID = getIntent().getStringExtra(GROUP_ID);
        isGroupMessage = groupID != null;

        mMessage = findViewById(R.id.message);
        String title_text;
        if (isGroupMessage) {
            com.revesoft.itelmobiledialer.model.Group group = GroupMessageAssistant.getGroupById(this,groupID);
            title_text = group.name;
            groupTitle.setVisibility(View.VISIBLE);
            groupTitle.setText(title_text);
        } else {
            groupTitle.setVisibility(View.GONE);
        }

        title_text = ContactEngine.getContactNamefromNumber(this, number);
        if (title_text != null)
            title.setText(title_text);
        else
            title.setText(number);


        String name = ContactEngine.getContactNamefromNumber(this, number);
        Bitmap mContactPortrait = ContactEngine.loadContactPhoto(this, number);
        if (name != null) {
            if (mContactPortrait != null) {
                mPortrait.setImageBitmap(mContactPortrait);
                mPortraitTxt.setVisibility(View.GONE);
                mPortrait.setVisibility(View.VISIBLE);
            } else {
                mPortraitTxt.setText(String.valueOf(name.charAt(0)).toUpperCase());
                mPortraitTxt.setVisibility(View.VISIBLE);
                mPortrait.setVisibility(View.GONE);
            }
        } else {
            mPortraitTxt.setText("");
            mPortraitTxt.setVisibility(View.VISIBLE);
            mPortrait.setVisibility(View.GONE);
        }



        String message = getIntent().getStringExtra(MESSAGE);
        if (message != null) {
            if(message.startsWith(Constants.STICKER_PREFIX) && message.endsWith(Constants.LS_SUFIX))
                message = "You have received a sticker";
            else if(message.startsWith(Constants.LOCATION_PREFIX) && message.endsWith(Constants.LS_SUFIX))
                message = "You have received a location";
            mMessage.setText(message);
            Linkify.addLinks(mMessage, Linkify.ALL);
            mMessage.setMovementMethod(ScrollingMovementMethod.getInstance());
        } else {
            finish();
            return;
        }

        mMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isGroupMessage){
                    sendIntentMessageToDialer("startgroupims", groupID);
                } else {
                    sendIntentMessageToDialer("startims", number);
                }
                finish();
            }
        });

        findViewById(R.id.rl_view_container).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isGroupMessage){
                    sendIntentMessageToDialer("startgroupims", groupID);
                } else {
                    sendIntentMessageToDialer("startims", number);
                }
                finish();

            }
        });
        mButtonSend = findViewById(R.id.buttonSend);
        mNewMessage = findViewById(R.id.newMessage);

        mButtonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean status = sendMessage();
                MessageNotification.cancelAll();
                if (status)
                    finish();
            }
        });

        mNewMessage.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    boolean status = sendMessage();
                    handled = true;
                    MessageNotification.cancelAll();
                    if (status)
                        finish();
                }
                return handled;
            }
        });

        LocalBroadcastManager.getInstance(this).registerReceiver(
                mMessageReceiver, new IntentFilter(IMPOPUP_ACTION));
    }

    @Override
    public void onResume() {
        super.onResume();
            finish();
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent == null)
            return;

        number = intent.getStringExtra(NUMBER);
        if (number == null || number.equals("")) {
            finish();
            return;
        }

        time = intent.getStringExtra(TIME);
        if (time == null) {
            timeView.setVisibility(View.GONE);
        } else timeView.setText(time);

        groupID = intent.getStringExtra(GROUP_ID);
        isGroupMessage = groupID != null;

        String title_text;
        if (isGroupMessage) {
            com.revesoft.itelmobiledialer.model.Group group = GroupMessageAssistant.getGroupById(this,groupID);
            title_text = group.name;
            groupTitle.setVisibility(View.VISIBLE);
            groupTitle.setText(title_text);
        } else {
            groupTitle.setVisibility(View.GONE);
        }
        title_text = ContactEngine.getContactNamefromNumber(this, number);
        if (title_text != null)
            title.setText(title_text);
        else
            title.setText(number);


        String name = ContactEngine.getContactNamefromNumber(this, number);
        Bitmap mContactPortrait = ContactEngine.loadContactPhoto(this, number);
        if (name != null) {
            if (mContactPortrait != null) {
                mPortrait.setImageBitmap(mContactPortrait);
                mPortraitTxt.setVisibility(View.GONE);
                mPortrait.setVisibility(View.VISIBLE);
            } else {
                mPortraitTxt.setText(String.valueOf(name.charAt(0)).toUpperCase());
                mPortraitTxt.setVisibility(View.VISIBLE);
                mPortrait.setVisibility(View.GONE);
            }
        } else {
            mPortraitTxt.setText("");
            mPortraitTxt.setVisibility(View.VISIBLE);
            mPortrait.setVisibility(View.GONE);
        }

        String message = intent.getStringExtra(MESSAGE);
        if (message != null) {
            if(message.startsWith(Constants.STICKER_PREFIX) && message.endsWith(Constants.LS_SUFIX))
                message = "You have received a sticker. To see it tap here.";
            else if(message.startsWith(Constants.LOCATION_PREFIX) && message.endsWith(Constants.LS_SUFIX))
                message = "You have received a location. To see it tap here.";
            mMessage.setText(message);
            Linkify.addLinks(mMessage, Linkify.ALL);
            mMessage.setMovementMethod(ScrollingMovementMethod.getInstance());
        } else {
            finish();
        }

        mMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isGroupMessage){
                    sendIntentMessageToDialer("startgroupims", groupID);
                } else {
                    sendIntentMessageToDialer("startims", number);
                }
                finish();
            }
        });
    }

    private boolean sendMessage() {
        Executor.ex(() -> {
            MessageRepo.get().updateMessageNotificationAsReadByNumber(number);
        });
//        if (!Util.hasConnection(IMPopupDialog.this)) {
//            alert(getString(R.string.error_no_data_connection));
//            return false;
//        } else if (!SIPProvider.registrationFlag) {
//            alert(getString(R.string.error_connection_to_server_failed));
//            return false;
//        } else {
            if (!mNewMessage.getText().toString().trim().equals("")) {
                if (isGroupMessage) {
                    sendIntentMessageToDialerForGroupMessage(groupID, /*UnicodeSmiledText.getSmiledText*/(mNewMessage.getText().toString()));
                    sendIntentMessageToDialerForIMS(number, /*UnicodeSmiledText.getSmiledText*/(mNewMessage.getText().toString()));
                    Executor.ex(() -> {
                        MessageRepo.get().updateMessageNotificationAsReadByGroupID(groupID);
                    });
                } else {
                    sendIntentMessageToDialerForIMS(number, /*UnicodeSmiledText.getSmiledText*/(mNewMessage.getText().toString()));
                    Executor.ex(() -> {
                        MessageRepo.get().updateMessageNotificationAsReadByNumber(number);
                    });
                }
                Log.d("IMPopupDialog", "Type: IMS " + "Number: " + number + " Message: " + mNewMessage.getText().toString());
                mNewMessage.setText("");
                return true;
            }
            return false;
//        }
    }

    private void sendIntentMessageToDialerForIMS(String number, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(BagName.SingleIM.Message, MessageBag.newBuilder().number(number).messageData(message).build());
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendIntentMessageToDialerForGroupMessage(String groupid, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(BagName.Group.Message, new String[]{groupid, message});
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendIntentMessageToDialer(String type, String number) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, number);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void alert(String message) {
        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        bld.setMessage(message);
        bld.setNeutralButton(android.R.string.ok, null);
        Log.d("RateFragment", "Showing alert dialog: " + message);
        bld.create().show();
    }

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle extras = intent.getExtras();
            if (extras != null) {
                if (extras.containsKey(IMPOPUP_MESSAGE_EXIT)) {
                    finish();
                }
            }
        }
    };

}