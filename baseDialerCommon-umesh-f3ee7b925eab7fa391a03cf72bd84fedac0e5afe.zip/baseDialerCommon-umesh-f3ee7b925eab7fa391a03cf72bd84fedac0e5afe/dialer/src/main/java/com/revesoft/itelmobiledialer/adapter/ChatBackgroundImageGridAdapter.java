package com.revesoft.itelmobiledialer.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.Display;

import androidx.annotation.NonNull;

/**
 * @author Ifta
 *         on 12/18/2016.
 */

public class ChatBackgroundImageGridAdapter extends ArrayAdapter<Integer> {
    private Context context;

    public ChatBackgroundImageGridAdapter(Context context, int resource, Integer[] objects) {
        super(context, resource, objects);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(context);
            imageView.setLayoutParams(new GridView.LayoutParams(85, 85));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }
        ImageUtil.setImage((Activity) context, getItem(position), imageView);
        int windowWidth = Display.getWidth((Activity) context);
        int imageWidth = windowWidth / 2;
        int imageHeight = (int) (imageWidth * 1.78);
        imageView.setLayoutParams(new GridView.LayoutParams(imageWidth, imageHeight));
        return imageView;
    }
}
