package com.revesoft.itelmobiledialer.confide;

import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import com.revesoft.itelmobiledialer.braodcast.QuickBroadCaster;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.io.File;

import static com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants.SEND_FILE_PREFIX_SENDER;
import static com.revesoft.itelmobiledialer.util.Constants.SEND_FILE_SUFFIX_SENDER;

/**
 * @author Ashrafi on 1/23/2018.
 */

public class ConfideSender {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");
    private String target;
    private static ConfideSender confideSender;
    private boolean isEncryptedChat = true; //always encrypted
    private boolean isGroupChat = false; //always false for confide chat
    private String messageSecurityMode = "1"; //always secured
    private String isConfide = "isConfide";
    private String isCaptionConfide = "isCaptionConfide";

    private String groupType = "1"; //not necessary probably

    public static ConfideSender getAccess() {
        if (confideSender == null) {
            confideSender = new ConfideSender();
        }
        return confideSender;
    }




    public void sendTextMessage(String textMessage) {
        final String OUT_GOING_TEXT_SINGLE = "outgoingmessage"; //broadcast to be received in Dialer Service
        sendMessageSendingBroadcastToDialerService(OUT_GOING_TEXT_SINGLE, textMessage);
    }

    private void sendMessageSendingBroadcastToDialerService(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        logger.log("sendMessageSendingBroadcastToDialerService messageSecurityMode ="+messageSecurityMode);
        intent.putExtra(type, new String[]{target, message, groupType, messageSecurityMode,isConfide});
        QuickBroadCaster.broadcast(intent);
    }

    public void sendFile(String filePath) {
        File file = new File(filePath);
        Log.e("HTTP", " file size: " + file.length());
        if (file.length() > Constants.FILE_SIZE_THRESHOLD) {
            I.toast(Supplier.getString(R.string.too_big_file));
        } else {
            Log.e(" normal group file path", " " + filePath);
            MessageEntry m = new MessageEntry();
            m.content = SEND_FILE_PREFIX_SENDER + filePath + SEND_FILE_SUFFIX_SENDER;
            //m.content = SEND_FILE_PREFIX + filePath + SEND_FILE_SUFFIX;

            m.number = target;
            m.time = System.currentTimeMillis();
            m.type = MessageEntry.MessageType.SEND;
            m.status = MessageEntry.MessageStatus.READ;
            m.delivery_status = MessageEntry.DeliveryStatus.PENDING;
            //m.callerId = System.currentTimeMillis() + UserDataManager.getUserName(); //generated
            m.callerId = System.currentTimeMillis() + m.number;
            //Log.e("user name ",UserDataManager.getUserName());
            m.groupId = target;
            m.isEncrypted = isEncryptedChat ? 1 : 0;

            m.burnTimeInsec = PreferenceDataManager.quickGet(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);
            PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);

            sendIntentMessageFileUploadToDialer(filePath, m.callerId);
            //DatabaseConstants.getInstance(AppContext.get().getContext()).createMessageLog(m); //no normal msg log to be created :|
        }
    }

    public void sendFile(String filePath, String caption) {
        /*if (TextUtils.isEmpty(caption)) {
            sendFile(filePath);
            return;
        }*/
        File file = new File(filePath);
        Log.e("HTTP", " file size: " + file.length());
        if (file.length() > Constants.FILE_SIZE_THRESHOLD) {
            I.toast(Supplier.getString(R.string.too_big_file));
        } else {
            Log.e(" normal group file path", " " + filePath);
            MessageEntry m = new MessageEntry();
            m.content = SEND_FILE_PREFIX_SENDER + filePath + IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR + caption + SEND_FILE_SUFFIX_SENDER;
            if (TextUtils.isEmpty(caption)) {
                //m.content = SEND_FILE_PREFIX_SENDER + filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + "\u0020" + SEND_FILE_SUFFIX_SENDER;
                caption = "\u0020";
            }
            m.content = SEND_FILE_PREFIX_SENDER + filePath + IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR + caption + SEND_FILE_SUFFIX_SENDER;
            //m.content = SEND_FILE_PREFIX + filePath + SEND_FILE_SUFFIX;

            m.number = target;
            m.time = System.currentTimeMillis();
            m.type = MessageEntry.MessageType.SEND;
            m.status = MessageEntry.MessageStatus.READ;
            m.delivery_status = MessageEntry.DeliveryStatus.PENDING;
            m.callerId = System.currentTimeMillis() + UserDataManager.getUserName();
            m.groupId = target;
            m.isEncrypted = isEncryptedChat ? 1 : 0;
            m.burnTimeInsec = PreferenceDataManager.quickGet(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);
            PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);


            if (isGroupChat) { //this block won't work for Confide
                sendIntentMessageFileUploadToDialer(filePath, caption, m.callerId);
                //DatabaseConstants.getInstance(AppContext.get().getContext()).createGroupMessageLog(m);
            } else {
                sendIntentMessageFileUploadToDialer(filePath, caption, m.callerId);
                //DatabaseConstants.getInstance(AppContext.get().getContext()).createMessageLog(m);
            }
        }
    }


    private void sendIntentMessageFileUploadToDialer(String filePath, String callerId) {
        Log.d("Abhi", "File Transfer" + "sendIntentMessageFileUploadToDialer");
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(Constants.COMMAND_FILE_UPLOARD, new String[]{target, "", filePath, callerId, messageSecurityMode,isConfide});
        QuickBroadCaster.broadcast(intent);
    }

    private void sendIntentMessageFileUploadToDialer(String filePath, String caption, String callerId) {
        Log.d("Abhi", "File Transfer" + "sendIntentMessageFileUploadToDialer");
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) { //this block won't work for Confide
            intent.putExtra(Constants.COMMAND_FILE_UPLOARD, new String[]{"", target,
                    filePath + IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR + caption,
                    callerId, messageSecurityMode + "", isCaptionConfide});
        } else {
            intent.putExtra(Constants.COMMAND_FILE_UPLOARD, new String[]{target, "",
                    filePath + IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR + caption,
                    callerId, messageSecurityMode + "", isCaptionConfide});
        }
        QuickBroadCaster.broadcast(intent);
    }


    static void configureFor(String number) {
        ConfideSender.getAccess().target = number;
    }
}
