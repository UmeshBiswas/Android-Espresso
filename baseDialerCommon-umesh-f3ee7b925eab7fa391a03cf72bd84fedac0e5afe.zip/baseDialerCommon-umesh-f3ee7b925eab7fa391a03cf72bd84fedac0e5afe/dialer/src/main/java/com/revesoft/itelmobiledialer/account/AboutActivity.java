package com.revesoft.itelmobiledialer.account;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.util.WebViewActivity;
import com.revesoft.itelmobiledialer.Config.Config;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import java.util.Locale;

/**
 * @author SaymaSultana on 5/18/2017.
 */

public class AboutActivity extends BaseActivity implements View.OnClickListener{
    Toolbar toolbar;
    TextView textLicense, versionNumber;

    public static void startForTesting(Context context) {
        Intent intent = new Intent(context, AboutActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_page);
        initViews();
        try {
            handleViews();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

    }

    private void initViews() {
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        textLicense = (TextView)findViewById(R.id.textLicences);
        versionNumber = (TextView)findViewById(R.id.textVersion);

    }
    private void handleViews() throws PackageManager.NameNotFoundException {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.title_about));
        }

        PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        String version = pInfo.versionName;
        versionNumber.setText(getString(R.string.version) + " " + version);

        SpannableString span = new SpannableString(getString(R.string.terms_of_use));
        ClickableSpan clickSpan = new ClickableSpan() {
            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(true);
            }

            @Override
            public void onClick(View textView) {
                startActivity(new Intent(AboutActivity.this, WebViewActivity.class));
            }
        };
        String CurrentLang = Locale.getDefault().getLanguage();
        span.setSpan(clickSpan, 0, span.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        textLicense.setText(span);
        textLicense.setOnClickListener(this);

    }

//    private void checkForUpdate(String packageName) {
//        try {
//            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.updateLink) + packageName)));
//        } catch (ActivityNotFoundException e) {
//            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.secondaryUpdateLink) + packageName)));
//        }
//    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.textLicences:
                if(Config.DIALER_VARIANT == DialerService.DialerVariant.SALAM){
                    startActivity(new Intent(AboutActivity.this, WebViewActivity.class));
                }
                else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.licenseLink))));
                break;
            default:
                break;
        }
    }
}
