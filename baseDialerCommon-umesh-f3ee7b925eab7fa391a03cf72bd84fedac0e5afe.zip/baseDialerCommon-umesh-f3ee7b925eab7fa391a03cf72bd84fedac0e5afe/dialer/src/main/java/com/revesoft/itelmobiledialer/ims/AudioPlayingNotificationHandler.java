package com.revesoft.itelmobiledialer.ims;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import android.util.Log;
import android.widget.RemoteViews;

import com.revesoft.material.R;
import com.revesoft.itelmobiledialer.receiver.NotificationDismissBroadcastReceiver;


/**
 * Created by ashikee on 12/26/17.
 */

public class AudioPlayingNotificationHandler {
    AudioPlayingNotificationHandler(Context context, int id)
    {
        this.context = context;
        notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

    }
    public static  NotificationManager mNotifyManager;
    public static NotificationCompat.Builder mBuilder;
    public static final int notificationID = 70007;
    public static Context context;
    public static NotificationManager notificationManager;
    public static RemoteViews notificationView;
    public static NotificationCompat.Builder builder;
    public  static long lastUpdateTimeInMilles = 0;
    public static  long minDiffBetweenTwoConsequtiveUpdate = 300;

    void initNotificationBuilder(int id)
    {
        createProgressNotification();
    }
    void removeProgressNotification()
    {
        Log.w("Notification","AudioProgress: " + "Removed Notification");
        notificationManager.cancel(101355);

    }
    void updateNotificationStatus(int maxLength, int increment, boolean isIndeterminate)
    {
        if(lastUpdateTimeInMilles == 0)
            lastUpdateTimeInMilles = System.currentTimeMillis();
        else{
            Long currentTimeInMillies = System.currentTimeMillis();
            long diff =  currentTimeInMillies -lastUpdateTimeInMilles;
            if(diff < minDiffBetweenTwoConsequtiveUpdate)
                return;
            lastUpdateTimeInMilles = currentTimeInMillies;
        }
        notificationView.setProgressBar(R.id.pb_progress, maxLength, increment, false);
        notificationManager.notify(101355, builder.build());


    }

    private void createProgressNotification() {
        Intent closeButton = new Intent("GETTING_STOP");
        closeButton.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent pendingSwitchIntent = PendingIntent.getBroadcast(context, 0, closeButton, 0);
        notificationView = new RemoteViews(context.getPackageName(), R.layout.widget_update_notification);

        builder = new NotificationCompat.Builder(context).setSmallIcon(R.drawable.notification_icon).setTicker("Ticker Text").setContent(notificationView);
        builder.setContentTitle(context.getString(R.string.app_name));
        builder.setDeleteIntent(createOnDismissedIntent(context,103255));
        notificationView.setProgressBar(R.id.pb_progress, 100, 0, false);
        notificationView.setOnClickPendingIntent(R.id.btn_close, pendingSwitchIntent);
        notificationView.setTextViewText(R.id.tv_header,context.getString(R.string.app_name));
        notificationManager.notify(101355, builder.build());

    }
    private PendingIntent createOnDismissedIntent(Context context, int notificationId) {
        Intent intent = new Intent(context, NotificationDismissBroadcastReceiver.class);
        intent.putExtra("com.my.app.notificationId", notificationId);

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(context.getApplicationContext(),
                        notificationId, intent, 0);
        return pendingIntent;
    }

}
