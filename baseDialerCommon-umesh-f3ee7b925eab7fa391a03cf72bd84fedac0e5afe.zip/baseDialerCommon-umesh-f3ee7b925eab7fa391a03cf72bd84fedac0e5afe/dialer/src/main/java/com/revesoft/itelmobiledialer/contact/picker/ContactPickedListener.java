package com.revesoft.itelmobiledialer.contact.picker;

import com.revesoft.itelmobiledialer.contact.list.ContactListItem;

import java.util.List;

public interface ContactPickedListener {
    void onContactPicked(List<String> contacts, List<ContactListItem> contactListItems);
}
