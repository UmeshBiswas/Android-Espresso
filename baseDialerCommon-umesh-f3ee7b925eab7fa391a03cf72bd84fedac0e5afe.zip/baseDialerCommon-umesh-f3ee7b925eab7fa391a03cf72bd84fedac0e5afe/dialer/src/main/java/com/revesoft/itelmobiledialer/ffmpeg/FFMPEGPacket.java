package com.revesoft.itelmobiledialer.ffmpeg;

public class FFMPEGPacket {
	public byte[] data;
	public int size;
	
//	public FFMPEGPacket(int size, byte[] data){
//		this.data = data;
//		this.size = size;
//	}
	
	public void init(int size, byte[] data){
		this.data = data;
		this.size = size;
	}
}
