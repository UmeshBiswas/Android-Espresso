package com.revesoft.itelmobiledialer.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import static android.content.Context.MODE_PRIVATE;
import static com.revesoft.itelmobiledialer.util.BaseApplication.PASSWORD_ENCRYPTION_KEY;
import static com.revesoft.itelmobiledialer.util.Constants.GOOGLE_ACCOUNT_EMAIL_ADDRESS;
import static com.revesoft.itelmobiledialer.util.Constants.GOOGLE_DRIVE_BACKUP_ERROR;
import static com.revesoft.itelmobiledialer.util.Constants.GOOGLE_DRIVE_BACKUP_ERROR_DEF;
import static com.revesoft.itelmobiledialer.util.Constants.KEY_TIME_ADJUSTMENT;
import static com.revesoft.itelmobiledialer.util.Constants.LAST_BACKUP_DATE;
import static com.revesoft.itelmobiledialer.util.Constants.LAST_BACKUP_SIZE;
import static com.revesoft.itelmobiledialer.util.Constants.MAIN_HISTORY_LOADINF_FOR_FIRST_TIME;
import static com.revesoft.itelmobiledialer.util.Constants.PASSWORD;
import static com.revesoft.itelmobiledialer.util.Constants.PASSWORD_DEF;
import static com.revesoft.itelmobiledialer.util.Constants.PHONE;
import static com.revesoft.itelmobiledialer.util.Constants.PHONE_DEF;
import static com.revesoft.itelmobiledialer.util.Constants.READY_TO_SEND_SUBSCRIBE;
import static com.revesoft.itelmobiledialer.util.Constants.USERNAME;
import static com.revesoft.itelmobiledialer.util.Constants.USERNAME_DEF;
import static com.revesoft.itelmobiledialer.util.Constants.USER_HAS_DELETED_PHOTO;

/**
 * @author Ifta
 */

public class  UserDataManager {
    private static SharedPreferences preference = null;
    private static boolean isRegistered = false;
    private static boolean isUserNameSet = false;
    private static boolean isPasswordSet = false;
    public static void register(Context context) {
        preference = context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
        isRegistered = true;
    }
    public static boolean isReadyForUse(){
        boolean res = isRegistered;
        res = res && !UserDataManager.getUserName().equals(Constants.USERNAME_DEF);
        res = res && PreferenceDataManager.isReadyToCreateDB();
        res = res && !UserDataManager.getUserPassword().equals(PASSWORD_DEF);

        return res;
//        return isRegistered && !UserDataManager.getUserName().equals(Constants.USERNAME_DEF) && !UserDataManager.getUserPassword().equals(PASSWORD_DEF) && PreferenceDataManager.isReadyToCreateDB();
    }
    private static String quickGet(String key, String defaultValue) {
        return preference.getString(key, defaultValue);
    }

    private static void quickPut(String key, String value) {
        preference.edit().putString(key, value).apply();
    }

    private static long quickGet(String key, long defaultValue) {
        return preference.getLong(key, defaultValue);
    }

    private static void quickPut(String key, long value) {
        preference.edit().putLong(key, value).apply();
    }

    private static int quickGet(String key, int defaultValue) {
        return preference.getInt(key, defaultValue);
    }

    private static void quickPut(String key, int value) {
        preference.edit().putInt(key, value).apply();
    }

    private static void quickPut(String key, boolean value) {
        preference.edit().putBoolean(key, value).apply();
    }

    private static boolean quickGet(String key, boolean defaultValue) {
        return preference.getBoolean(key, defaultValue);
    }


    public static String getUserName() {
        return quickGet(USERNAME, USERNAME_DEF);
    }

    public static void setUserName(String username) {
        quickPut(USERNAME, username);
        isUserNameSet = true;
    }


    public static long getLastBackupTime() {
        return quickGet(LAST_BACKUP_DATE, (long) 0);
    }

    public static void setLastBackupTime(long time) {
        quickPut(LAST_BACKUP_DATE, time);
    }

    public static long getLastBackupSize() {
        return quickGet(LAST_BACKUP_SIZE, (long) 0);
    }

    public static void setLastBackupSize(long size) {
        quickPut(LAST_BACKUP_SIZE, size);

    }

    public static String getChatBackupLastError() {
        return quickGet(GOOGLE_DRIVE_BACKUP_ERROR, GOOGLE_DRIVE_BACKUP_ERROR_DEF);
    }

    public static void setChatBackupLastError(String error) {
        quickPut(GOOGLE_DRIVE_BACKUP_ERROR, error);
    }


    public static long getLastContactSyncTime(){
        return quickGet(Constants.LAST_CONTACT_SYNC_TIME,(long) 0);
    }

    public static void setLastContactSyncTime(long time){
        quickPut(Constants.LAST_CONTACT_SYNC_TIME,time);
    }

    public static String getFullName() {
        return quickGet(Constants.MY_PROFILE_FULL_NAME, USERNAME_DEF);
    }

    public static void setFullName(String fullName) {
        quickPut(Constants.MY_PROFILE_FULL_NAME, fullName);
    }

    public static  void setSalmNumberActivated(boolean set){
        quickPut(Constants.IS_SALAM_NUMBER_ACTIVATED, set);
    }
    public static boolean getSalamNumberActivated(){
        return quickGet(Constants.IS_SALAM_NUMBER_ACTIVATED, false);
    }

    public static void setSalamNumber(String number){
        quickPut(Constants.SALAM_NUMBER, number);
    }

    public static String getSalamNumber(){
        return quickGet(Constants.SALAM_NUMBER,"");
    }

    public static void setErrorDescription(String number){
        quickPut(Constants.ERROR_DESCRIPTION, number);
    }

    public static String getErrorDescription(){
        return quickGet(Constants.ERROR_DESCRIPTION,"");
    }

    public static void setRequestCodeForSalamNumber(String code){
        quickPut(Constants.REQUEST_CODE_FOR_SALAM_NUMBER, code);
    }

    public static String getRequestCodeForSalamNumber(){
        return quickGet(Constants.REQUEST_CODE_FOR_SALAM_NUMBER, "");
    }

    public static void setIsMainHistoryLoadingForFirstTime(boolean readyToSendSubscribe) {
        quickPut(MAIN_HISTORY_LOADINF_FOR_FIRST_TIME, readyToSendSubscribe);
    }



//    public static void setCurrentStatus(String currentStatus) {
//        quickPut(Constants.CURRENT_STATUS, currentStatus);
//    }

//    public static String getCurrentStatus() {
//        return quickGet(Constants.CURRENT_STATUS, "available");
//    }

    public static int getUserCountryCode() {
        String countryCode = quickGet(Constants.USER_COUNTRY_CODE, Constants.USER_COUNTRY_CODE_DEF);
        if (countryCode.isEmpty()) {
            countryCode = Util.getUserCountryCode(getUserName());
            quickPut(Constants.USER_COUNTRY_CODE, countryCode);
        }
        int userCountryCode = -1;
        try {
            userCountryCode = Integer.parseInt(countryCode.trim());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userCountryCode;
    }

//    public static  boolean isSingtelUser() {
//        return  PreferenceDataManager.quickGet(KEY_IS_SINGTEL_USER, KEY_IS_SINGTEL_USER_DEF);
//    }

    public static String getUserPhoneNo() {
        return quickGet(PHONE, PHONE_DEF);
    }

    public static String getGoogleEmailAddress() {
        return quickGet(GOOGLE_ACCOUNT_EMAIL_ADDRESS, "");
    }

    public static void setGoogleEmailAddress(String emailAddress) {
        quickPut(GOOGLE_ACCOUNT_EMAIL_ADDRESS, emailAddress);

    }

    public static String getUserPassword() {
        byte[] bytes = quickGet(PASSWORD, PASSWORD_DEF).getBytes();

//        if (DialerService.DEBUG)
//            Log.v("UserDataManager", "getUserPassword : ENCRYPTED_PASSWORD: " + new String(bytes));

        if (!TextUtils.isEmpty(getUserName()) && !TextUtils.isEmpty(PASSWORD_ENCRYPTION_KEY)) {
            byte[] mobileNumber = getUserName().getBytes();
            byte[] keyAutoSignUp = PASSWORD_ENCRYPTION_KEY.getBytes();

            for (int i = 0; i < bytes.length; i++) {
                bytes[i] = (byte) (bytes[i] & 0x00FF);
                bytes[i] = (byte) (bytes[i] ^ keyAutoSignUp[i % mobileNumber.length]);
            }

            for (int i = 0; i < bytes.length; i++) {
                bytes[i] = (byte) (bytes[i] & 0x00FF);
                bytes[i] = (byte) (bytes[i] ^ mobileNumber[i % keyAutoSignUp.length]);
            }
        }

//        if (DialerService.DEBUG)
//            Log.v("UserDataManager", "getUserPassword : PASSWORD: " + new String(bytes));

        return new String(bytes);
    }

    public static void setUserPassword(String password) {
        byte[] bytes = password.getBytes();

        if (DialerService.DEBUG)
            Log.v("UserDataManager", "setUserPassword : PASSWORD: " + new String(bytes));

        if (!TextUtils.isEmpty(getUserName()) && !TextUtils.isEmpty(PASSWORD_ENCRYPTION_KEY)) {
            byte[] mobileNumber = getUserName().getBytes();
            byte[] keyAutoSignUp = PASSWORD_ENCRYPTION_KEY.getBytes();

            for (int i = 0; i < bytes.length; i++) {
                bytes[i] = (byte) (bytes[i] & 0x00FF);
                bytes[i] = (byte) (bytes[i] ^ keyAutoSignUp[i % mobileNumber.length]);
            }

            for (int i = 0; i < bytes.length; i++) {
                bytes[i] = (byte) (bytes[i] & 0x00FF);
                bytes[i] = (byte) (bytes[i] ^ mobileNumber[i % keyAutoSignUp.length]);
            }
        }

        if (DialerService.DEBUG)
            Log.v("UserDataManager", "setUserPassword : ENCRYPTED_PASSWORD: " + new String(bytes));
        quickPut(PASSWORD, new String(bytes));
        isPasswordSet = true;
    }

    public static String getProfilePicturePath() {
        return ProfilePictureDataProvider.getOwnProfilePicturePath(AppContext.getAccess().getContext());
    }

    public static String getPresenceNote() {
        return quickGet(Constants.PRESENCE_NOTE, Supplier.getString(R.string.defaultStatus));
    }

    public static void setPresenceNote(String presenceNote) {
        quickPut(Constants.PRESENCE_NOTE, presenceNote);
    }

    public static String getPresenceStatus() {
        return quickGet(Constants.PRESENCE_STATUS, "available");
    }

    public static void setPresenceStatus(String status) {
        quickPut(Constants.PRESENCE_STATUS, status);
    }

    public static boolean isActivated() {
        return  !UserDataManager.getDID().equals("");

    }

    private static String balance = "";

    public static void setBalance(String balance) {
        UserDataManager.balance = balance;
    }

    public static String getBalance() {
        return  balance;
    }

    public static void clearAll() {
        preference.edit().clear().apply();
    }

    public static void acceptTermsAndCondition() {
        quickPut(Constants.SignUp.KEY_ACCEPT_TERMS_AND_CONDITION, true);
    }

    public static boolean hasAcceptedTermsAndCondition() {
        return quickGet(Constants.SignUp.KEY_ACCEPT_TERMS_AND_CONDITION, false);
    }
    private static final String SALAM_NUMBER_KEY = "SALAM_NUMBER_KEY";
    public static void setDID(String response) {
        quickPut(SALAM_NUMBER_KEY,response);
    }
    public static String getDID(){
        return quickGet(SALAM_NUMBER_KEY,"");
    }

    public static boolean hasUpdatedProfile() {
        return quickGet(Constants.KEY_PROFILE_INFO_UPDATED, false);
    }

    public static void setCompletedProfileInfoUpdate() {
        quickPut(Constants.KEY_PROFILE_INFO_UPDATED,true);
    }

    public static void setEmail(String email) {
        quickPut(Constants.MY_PROFILE_EMAIL,email);
    }
    public static String getEmail(){
        return quickGet(Constants.MY_PROFILE_EMAIL, Supplier.getString(R.string.emailNotFound));
    }


    public static void destroyCompletedProfileInfoUpdate() {
        quickPut(Constants.KEY_PROFILE_INFO_UPDATED,false);
    }

    public static void setTimeAdjustment(long adjustment){
        quickPut(KEY_TIME_ADJUSTMENT, adjustment);
    }

    public static long getTimeAdjustment(){
        return quickGet(KEY_TIME_ADJUSTMENT, 0L);
    }

    public static int getDeletePhotoStatus(){
        return quickGet(USER_HAS_DELETED_PHOTO, 0);
    }

    public static void setDeletePhotoStatus(int value){
        quickPut(USER_HAS_DELETED_PHOTO, value);
    }

    public static void setIsReadyToSendSubscribe( boolean readyToSendSubscribe){
        quickPut(READY_TO_SEND_SUBSCRIBE, readyToSendSubscribe);
    }

    public static boolean getIsReadyToSendSubscribe(){
        return quickGet(READY_TO_SEND_SUBSCRIBE, false);
    }

}
