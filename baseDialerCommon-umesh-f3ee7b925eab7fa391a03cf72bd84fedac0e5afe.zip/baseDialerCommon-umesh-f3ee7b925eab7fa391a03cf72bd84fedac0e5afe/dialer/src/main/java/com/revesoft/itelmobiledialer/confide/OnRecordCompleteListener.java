package com.revesoft.itelmobiledialer.confide;

/**
 * @author Ashrafi on 1/25/2018.
 */

public interface OnRecordCompleteListener {

    enum RequestType{
        ON_RECORD_COMPLETE
    }

    void onRecordCompleteRequest(RequestType requestType);

    void setFilePath(String filePath);
}
