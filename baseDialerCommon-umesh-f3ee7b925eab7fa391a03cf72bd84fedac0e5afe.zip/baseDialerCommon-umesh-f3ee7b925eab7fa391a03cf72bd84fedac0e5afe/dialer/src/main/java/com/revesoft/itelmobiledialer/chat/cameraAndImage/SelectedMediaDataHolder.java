package com.revesoft.itelmobiledialer.chat.cameraAndImage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SelectedMediaDataHolder {
    private static Set<String> filePaths = new HashSet<>();

    public static boolean add(String filePath) {
        return filePaths.add(filePath);
    }

    public static boolean addAll(List<String> filePaths) {
        return SelectedMediaDataHolder.filePaths.addAll(filePaths);
    }


    public static boolean contains(String filePath) {
        return filePaths.contains(filePath);
    }

    public static List<String> getAll() {
        return new ArrayList<>(filePaths);
    }

    public static boolean remove(String filePath) {
        return filePaths.remove(filePath);
    }

    public static void clear() {
        filePaths.clear();
    }
}
