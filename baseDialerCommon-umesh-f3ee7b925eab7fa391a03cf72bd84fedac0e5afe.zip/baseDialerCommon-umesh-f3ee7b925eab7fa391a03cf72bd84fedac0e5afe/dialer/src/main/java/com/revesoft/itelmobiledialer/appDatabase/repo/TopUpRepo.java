package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.TopUpLog;
import com.revesoft.itelmobiledialer.databaseentry.TopUpLogEntry;

import java.util.Date;

public class TopUpRepo {
    private static final TopUpRepo ourInstance = new TopUpRepo();

    private TopUpRepo() {
    }

    public static TopUpRepo get() {
        return ourInstance;
    }

    public void createTopUpLog(TopUpLogEntry mtuEntry) {
        AppDatabase.get().topUpLogDao().insert(TopUpLog.newBuilder()
                .withTopUpId(mtuEntry.topupid)
                .withNumber(mtuEntry.number)
                .withAmount(mtuEntry.amount)
                .withStatus(mtuEntry.status)
                .withDate(new Date(mtuEntry.time))
                .build()
        );
    }


    public Cursor getTopUpLogs() {
        return AppDatabase.get().topUpLogDao().getTopUpLogs();
    }

    public String[] getPendingTopUpID() {
        int[] res = AppDatabase.get().topUpLogDao().getPendingTopUpID();
        String[] str = new String[res.length];
        for (int i = 0; i < res.length; i++) {
            str[i] = String.valueOf(res[i]);
        }
        return str;
    }

    public void updateTopUpLog(int topupid, int status) {
        AppDatabase.get().topUpLogDao().updateTopUpLog(topupid, status);
    }
}
