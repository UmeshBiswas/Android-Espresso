package com.revesoft.itelmobiledialer.account;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.entities.CustomNotificationParam;
import com.revesoft.itelmobiledialer.appDatabase.repo.CustomNotificationParamRepo;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.notification.AppNotificationManagement;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Ringer;
import com.revesoft.material.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

/**
 * @author Ifta
 * on 5/22/2017.
 */

public class NotificationSettingsActivity extends BaseActivity {
    private Context context;
    private Toolbar toolbar;
    private TextView tvNotificationTone;
    private TextView tvVibrateTypeForChat;
    private TextView tvPopupNotificationType;
    private TextView tvRingTone;
    private TextView tvVibrateTypeForCall;
    public static final String TARGET_KEY = "target_key";
    private MediaPlayer audioplayer = new MediaPlayer();
    public static final String TARGET_NAME_KEY = "target_name_key";
    SwitchCompat customNotificationSwitchCompact;
    CustomNotificationParam param, sysParam;
    String target = "";
    String targetName = "";
    boolean isDefaultSettings = true;
    boolean isCustomNotificationEnable = false;
    private final HashMap<Integer, String> ringtoneMap = new HashMap<Integer, String>() {
        {
            put(0, "ringtone_one");
            put(1, "ringtone_two");
            put(2, "ringtone_three");
            put(3, "ringtone_four");
            put(4, "ringtone_five");
            put(5, "ringtone_six");
            put(6, "ringtone_seven");
            put(7, "ringtone_eight");
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_settings_activity_layout);


        context = this;
        loadIntentData();
        handleToolbar();
        init();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (audioplayer == null) {
            audioplayer = new MediaPlayer();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (audioplayer == null) {
            audioplayer = new MediaPlayer();
        }
    }


    private void init() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.please_wait));

        Executor.ex(() -> {
            Gui.get().run(progressDialog::show);
            loadData();
            Gui.get().run(() -> {
                initViews();
                updateViewData();
                handleEnableCheckBox();
                progressDialog.dismiss();
            });

        });

    }


    private void loadIntentData() {
        Intent intent = getIntent();
        if (intent.hasExtra(TARGET_KEY)) {
            target = intent.getStringExtra(TARGET_KEY);
        }
        if (intent.hasExtra(TARGET_NAME_KEY)) {
            targetName = intent.getStringExtra(TARGET_NAME_KEY);
        }

        isDefaultSettings = !(target != null && !target.trim().equals(""));
        if (isDefaultSettings) targetName = "Message Notification";
    }


    private void loadData() {

        if (isDefaultSettings)
            param = CustomNotificationParamRepo.get().getDefaultNotificationParam();
        else param = CustomNotificationParamRepo.get().getCustomNotificationParam(target);
        isCustomNotificationEnable = param.target.equals(target) && param.isCustomNotificationEnable;


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            sysParam = AppNotificationManagement.getInstance().getSystemNotificationParam(param.notificationChannelID);
        } else {
            sysParam = param;
        }

        if (sysParam != null && (!sysParam.messageRingTone.equals(param.messageRingTone) ||
                (sysParam.messageVibrationMode == 0 && param.messageVibrationMode != 0) ||
                (sysParam.messageVibrationMode != 0 && param.messageVibrationMode == 0))) {


            param.messageRingTone = sysParam.messageRingTone;
            param.messageVibrationMode = sysParam.messageVibrationMode;
            updateDatabase();
        }
    }

    private void updateViewData() {
        updateNotificationToneViewData();
        updateRingToneViewData();
        tvVibrateTypeForChat.setText(getString(R.string.wip));
        tvVibrateTypeForCall.setText(getString(R.string.wip));
        tvPopupNotificationType.setText(param.popUpNotification ?
                getString(R.string.always_show_popup) : getString(R.string.no_popup));
        tvVibrateTypeForChat.setText(getVibrationStatus(param.messageVibrationMode));
        tvVibrateTypeForCall.setText(getVibrationStatus(param.messageVibrationMode));

    }

    private void updateNotificationToneViewData() {
        String notificationToneUri = param.messageRingTone;
        Ringtone ringtone = RingtoneManager.getRingtone(context, Uri.parse(notificationToneUri));
        tvNotificationTone.setText(ringtone.getTitle(context));
    }

    private void updateRingToneViewData() {
        String ringtoneUri = param.callRingTone;
        Ringtone ringtone = RingtoneManager.getRingtone(context, Uri.parse(ringtoneUri));
        String toneLabel = ringtone.getTitle(context);
        if (ringtoneUri.contains("android.resource://com.nurtelecom.salam/raw")) {
            String processedLabel = ringtoneUri.substring(ringtoneUri.lastIndexOf('/') + 1);
            for (HashMap.Entry<Integer, String> entry : ringtoneMap.entrySet()) {
                if (entry.getValue().equals(processedLabel))
                    tvRingTone.setText("Ringtone " + Integer.toString(entry.getKey() + 1));
            }


        } else tvRingTone.setText(toneLabel);
    }

    private void initViews() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.please_wait));
        tvNotificationTone = findViewById(R.id.tvNotificationTone);
        customNotificationSwitchCompact = findViewById(R.id.custom_notification_check_box);
        tvVibrateTypeForChat = findViewById(R.id.tvVibrateTypeForChat);
        tvPopupNotificationType = findViewById(R.id.tvPopupNotificationType);
        tvRingTone = findViewById(R.id.tvRingTone);
        tvVibrateTypeForCall = findViewById(R.id.tvVibrateTypeForCall);
        if (isDefaultSettings) {
            findViewById(R.id.custom_notification_target_view).setVisibility(View.GONE);
        } else {
            findViewById(R.id.custom_notification_target_view).setVisibility(View.VISIBLE);
        }
        if (isCustomNotificationEnable) {
            customNotificationSwitchCompact.setChecked(true);
        } else if (!isDefaultSettings) {
            customNotificationSwitchCompact.setChecked(false);
            disableView();

        }
        if (sysParam == null)
            AppNotificationManagement.getInstance().changeNotificationParameter(param, targetName);


        progressDialog.dismiss();


    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.blockedContacts));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            if (isDefaultSettings) actionBar.setTitle(getString(R.string.notifications));
            else {
                actionBar.setTitle(targetName);
                actionBar.setSubtitle(getString(R.string.notifications));
            }
        }
    }


    private void handleEnableCheckBox() {
        customNotificationSwitchCompact.setOnClickListener(v -> {
            if (customNotificationSwitchCompact.isChecked()) {
                AppNotificationManagement.getInstance().enableCustomNotification(target, targetName, param);
                enableView();

            } else {
                AppNotificationManagement.getInstance().disableCustomNotification(param);
                disableView();
            }
        });
    }

    private static final int NOTIFICATION_PICKER_REQUEST_CODE = 18;

    public void handleNotificationTone(View view) {
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Notification Tone");
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(AccountPreference.get(AccountPreference.Keys.NOTIFICATION_TONE_URI, AppNotificationManagement.getDefaultNotificationToneUri())));
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, (Uri) null);
        startActivityForResult(intent, NOTIFICATION_PICKER_REQUEST_CODE);
    }

    public void handleVibrateType(View view) {
        AlertDialog.Builder adb = new AlertDialog.Builder(NotificationSettingsActivity.this);
        CharSequence items[] = new CharSequence[]{getString(R.string.off_camel),
                getString(R.string.default_camel),
                getString(R.string.short_camel),
                getString(R.string.long_camel)};


        adb.setSingleChoiceItems(items,
                PreferenceDataManager.quickGet(AccountPreference.Keys.VIBRATION_IN_IM, 1), (d, n) -> {
                    if (n == 0) {
                        param.messageVibrationMode = Constants.Vibration.VIBRATION_OFF;
                        AppNotificationManagement.getInstance().changeNotificationParameter(param, targetName);
                        updateViewData();
                    }
                    if (n == 1) {
                        param.messageVibrationMode = Constants.Vibration.VIBRATION_DEFAULT;
                        AppNotificationManagement.getInstance().changeNotificationParameter(param, targetName);
                        updateViewData();
                    }
                    if (n == 2) {
                        param.messageVibrationMode = Constants.Vibration.VIBRATION_SHORT;
                        AppNotificationManagement.getInstance().changeNotificationParameter(param, targetName);
                        updateViewData();
                    }
                    if (n == 3) {
                        param.messageVibrationMode = Constants.Vibration.VIBRATION_LONG;
                        AppNotificationManagement.getInstance().changeNotificationParameter(param, targetName);
                        updateViewData();
                    }
                    d.dismiss();
                });
        adb.setNegativeButton(R.string.cancel, null);
        adb.setTitle(R.string.vibration);
        adb.show();
    }

    String getVibrationStatus(int vibrationSelected) {

        if (vibrationSelected == Constants.Vibration.VIBRATION_OFF)
            return getString(R.string.off_camel);
        if (vibrationSelected == Constants.Vibration.VIBRATION_DEFAULT)
            return getString(R.string.default_camel);
        if (vibrationSelected == Constants.Vibration.VIBRATION_SHORT)
            return getString(R.string.short_camel);
        if (vibrationSelected == Constants.Vibration.VIBRATION_LONG)
            return getString(R.string.long_camel);
        return "";
    }



    public void handlePopupNotification(View view) {
        AlertDialog.Builder adb = new AlertDialog.Builder(NotificationSettingsActivity.this);
        CharSequence items[] = new CharSequence[]{getString(R.string.always_show_popup), getString(R.string.no_popup)};

        adb.setSingleChoiceItems(items,
                PreferenceDataManager.quickGet(AccountPreference.Keys.POPUP_NOTIFICATION, true) ? 0 : 1, (d, n) -> {
                    param.popUpNotification = n == 0;
                    updateDatabase();
                    updateViewData();
                    d.dismiss();


                });
        adb.setNegativeButton(R.string.cancel, null);
        adb.setTitle(R.string.popup_notification);
        adb.show();
    }


    private static final int RINGTONE_PICKER_REQUEST_CODE = 12;

    public void handleRingtone(View view) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(NotificationSettingsActivity.this);
        final CharSequence[] items = {getString(R.string.phone_ringtone), getString(R.string.salam_ringtone)};
        dialog.setItems(items, (dialog1, which) -> {
            if (which == 0) {
                Intent ringtoneSelectionIntent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
                ringtoneSelectionIntent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(AccountPreference.get(AccountPreference.Keys.RINGTONE_URI, Ringer.getDefaultRingToneUri())));
                ringtoneSelectionIntent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
                ringtoneSelectionIntent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
                startActivityForResult(ringtoneSelectionIntent, RINGTONE_PICKER_REQUEST_CODE);
            } else {
                final AlertDialog.Builder selectTone = new AlertDialog.Builder(NotificationSettingsActivity.this);
                final CharSequence ringtones[] = new CharSequence[ringtoneMap.size()];
                for (int i = 0; i < ringtoneMap.size(); i++) {
                    ringtones[i] = "Ringtone " + Integer.toString(i + 1);

                }
                selectTone.setTitle(getString(R.string.select_salam_Ringtone));
                final ArrayList<Integer> whichList = new ArrayList<Integer>();
                selectTone.setSingleChoiceItems(ringtones, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog1, int which) {
                        try {
                            if (audioplayer != null) {
                                audioplayer.stop();
                                audioplayer.reset();

                            }
                            audioplayer.setDataSource(NotificationSettingsActivity.this,
                                    Uri.parse("android.resource://" + getPackageName() + "/raw/"
                                            + ringtoneMap.get(which)));
                            whichList.add(which);
                            audioplayer.prepare();
                            audioplayer.start();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                });
                selectTone.setPositiveButton(getString(R.string.ok), (dialog11, which1) -> {
                    if (audioplayer != null) {
                        audioplayer.stop();
                        audioplayer.reset();
                    }
                    if (whichList.size() > 0) {


                        param.callRingTone = "android.resource://" + getPackageName() + "/raw/"
                                + ringtoneMap.get(whichList.get(whichList.size() - 1));
                        updateDatabase();
//
                    }
                    updateViewData();

                });

                selectTone.setOnDismissListener(dialog112 -> {
                    if (audioplayer != null) {
                        audioplayer.stop();
                        audioplayer.reset();
                    }
                });

                selectTone.setOnCancelListener(dialog113 -> {
                    if (audioplayer != null) {
                        audioplayer.stop();
                        audioplayer.reset();
                    }
                });

                selectTone.show();
            }
        });
        dialog.show();


    }

    public void handleVibrateTypeForCall(View view) {

        AlertDialog.Builder adb = new AlertDialog.Builder(NotificationSettingsActivity.this);
        CharSequence items[] = new CharSequence[]{getString(R.string.off_camel),
                getString(R.string.default_camel), getString(R.string.short_camel),
                getString(R.string.long_camel)
        };


        adb.setSingleChoiceItems(items,
                PreferenceDataManager.quickGet(AccountPreference.Keys.VIBRATION_IN_CALL, 1), (d, n) -> {
                    if (n == 0) {
                        param.callVibrationMode = Constants.Vibration.VIBRATION_OFF;
                    }
                    if (n == 1) {
                        param.callVibrationMode = Constants.Vibration.VIBRATION_DEFAULT;
                    }
                    if (n == 2) {
                        param.callVibrationMode = Constants.Vibration.VIBRATION_SHORT;
                    }
                    if (n == 3) {
                        param.callVibrationMode = Constants.Vibration.VIBRATION_LONG;
                    }
                    updateDatabase();
                    updateViewData();
                    d.dismiss();

                });
        adb.setNegativeButton(R.string.cancel, null);
        adb.setTitle(R.string.vibration);
        adb.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RINGTONE_PICKER_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (uri != null) {
                    param.callRingTone = uri.toString();
                    updateDatabase();
                    updateViewData();
                }
            }
        } else if (requestCode == NOTIFICATION_PICKER_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (uri != null) {
                    param.messageRingTone = uri.toString();
                    AppNotificationManagement.getInstance().changeNotificationParameter(param, targetName);
                    updateViewData();
                }
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (audioplayer != null) {
            audioplayer.release();
            audioplayer = null;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (audioplayer != null) {
            audioplayer.release();
            audioplayer = null;
        }
    }


    private void updateDatabase() {
        Executor.ex(() -> CustomNotificationParamRepo.get().update(param));
    }


    private void enableView() {
        findViewById(R.id.custom_notification_change_setting_view).setAlpha(1);


        findViewById(R.id.custom_notification_change_setting_view).setEnabled(true);
        findViewById(R.id.custom_notification_change_setting_view).setClickable(true);
        findViewById(R.id.custom_notification_change_setting_view).setFocusable(true);


        findViewById(R.id.notification_tone).setEnabled(true);
        findViewById(R.id.notification_tone).setClickable(true);
        findViewById(R.id.notification_tone).setFocusable(true);


        findViewById(R.id.notification_vibrate).setEnabled(true);
        findViewById(R.id.notification_vibrate).setClickable(true);
        findViewById(R.id.notification_vibrate).setFocusable(true);


        findViewById(R.id.popup_notification).setEnabled(true);
        findViewById(R.id.popup_notification).setClickable(true);
        findViewById(R.id.popup_notification).setFocusable(true);


        findViewById(R.id.ring_tone).setEnabled(true);
        findViewById(R.id.ring_tone).setClickable(true);
        findViewById(R.id.ring_tone).setFocusable(true);


        findViewById(R.id.ring_vibrate).setEnabled(true);
        findViewById(R.id.ring_vibrate).setClickable(true);
        findViewById(R.id.ring_vibrate).setFocusable(true);

    }

    private void disableView() {
        findViewById(R.id.custom_notification_change_setting_view).setAlpha(.4f);


        findViewById(R.id.custom_notification_change_setting_view).setEnabled(false);
        findViewById(R.id.custom_notification_change_setting_view).setClickable(false);
        findViewById(R.id.custom_notification_change_setting_view).setFocusable(false);


        findViewById(R.id.notification_tone).setEnabled(false);
        findViewById(R.id.notification_tone).setClickable(false);
        findViewById(R.id.notification_tone).setFocusable(false);


        findViewById(R.id.notification_vibrate).setEnabled(false);
        findViewById(R.id.notification_vibrate).setClickable(false);
        findViewById(R.id.notification_vibrate).setFocusable(false);


        findViewById(R.id.popup_notification).setEnabled(false);
        findViewById(R.id.popup_notification).setClickable(false);
        findViewById(R.id.popup_notification).setFocusable(false);


        findViewById(R.id.ring_tone).setEnabled(false);
        findViewById(R.id.ring_tone).setClickable(false);
        findViewById(R.id.ring_tone).setFocusable(false);


        findViewById(R.id.ring_vibrate).setEnabled(false);
        findViewById(R.id.ring_vibrate).setClickable(false);
        findViewById(R.id.ring_vibrate).setFocusable(false);
    }
}

