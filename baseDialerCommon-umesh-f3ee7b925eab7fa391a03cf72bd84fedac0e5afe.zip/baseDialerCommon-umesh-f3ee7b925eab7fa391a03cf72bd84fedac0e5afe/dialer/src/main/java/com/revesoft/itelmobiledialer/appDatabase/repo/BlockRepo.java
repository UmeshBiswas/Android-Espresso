package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Block;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class BlockRepo {

    private static BlockRepo blockRepo = null;


    private BlockRepo() {
    }

    public static BlockRepo get() {
        if (blockRepo == null) blockRepo = new BlockRepo();
        return blockRepo;
    }


    public boolean isBlockedContact(String translatedKeyNumber) {
        return AppDatabase.get().blockDao().isBlockedContact(translatedKeyNumber);
    }

    public List<String> getAllBlockedNumbers() {
        return AppDatabase.get().blockDao().getAllBlockedNumbers();
    }

    public void deleteBlockContact(String number) {
        Block block = new Block();
        block.number = number;
        AppDatabase.get().blockDao().delete(block);
    }

    public void addBlockContact(String blockContact) {
        Block block = new Block();
        block.number = blockContact;
        AppDatabase.get().blockDao().insert(block);
    }

    public List<Block> getAllBlockContact() {
        return AppDatabase.get().blockDao().getAllBlockContact();
    }

    public int getBlockContactCount() {
        return AppDatabase.get().blockDao().getBlockContactCount();
    }

    public void createBlockContactEntries(ArrayList<String> blockContacts) {
        for (String blockContact : blockContacts) addBlockContact(blockContact);
    }

    public void deleteBlockContactsNotINMap(HashSet<String> blockedContacts) {
        AppDatabase.get().blockDao().deleteBlockContactsNotINMap(blockedContacts);

    }


    public Cursor getAllBlockContactBySearch(String search) {
        return AppDatabase.get().blockDao().getAllBlockContactBySearch("%" + search + "%");
    }


    public Cursor getAllBlockContactCursor() {
        return AppDatabase.get().blockDao().getAllBlockContactCursor();
    }
}
