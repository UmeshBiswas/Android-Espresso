package com.revesoft.itelmobiledialer.ims.IMUtil;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.RetryRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.SMSRepo;
import com.revesoft.itelmobiledialer.sms.SMSLogStatus;
import com.revesoft.itelmobiledialer.sms.SmsLogEntry;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

import java.nio.charset.StandardCharsets;

import androidx.appcompat.app.AlertDialog;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static com.revesoft.itelmobiledialer.util.Constants.compose;

/**
 * Created by Acer on 4/18/2017.
 */

public class VoipSmsRequestUtil {


    public boolean sendIntentMessageSMSToDialer(Context context, String message, String numberOrGroupId, boolean isGroup, String callerId) {


        Log.e(" smsretry"," "+message);
        Log.e(" smsretry", " " + numberOrGroupId);
        Log.e(" smsretry"," "+isGroup);


        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("sendsmsretry","");
        String s = message;

        byte[] utf8Bytes = s.getBytes(StandardCharsets.UTF_8);
        int length = utf8Bytes.length;
        if (length <= 1000) {
            Executor.ex(() -> {
                if (s.length() == 0)
                    return;
                intent.putExtra(compose, s);

                if (!isGroup) {
                    String[] numbers;
                    numbers = new String[1];
                    numbers[0] = numberOrGroupId;
                    intent.putExtra("to1", numbers);

//
                } else {
                    intent.putExtra("to1", GroupRepo.get().getGroupNumbers(numberOrGroupId));

                }

                Log.e("smsretry", " sending broarcast");
                if (isGroup)
                    intent.putExtra("groupid", numberOrGroupId);
                else
                    intent.putExtra("groupid", "");

                intent.putExtra("callerid", callerId);
                LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
            });

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setMessage(context.getString(R.string.text_length_is_too_big));
            builder.setPositiveButton(R.string.ok,(d,__)-> d.dismiss());
            builder.create().show();
        }

        return true;
    }

    public boolean sendIntentFutureMessageSMSToDialer(Context context, String message, String numberOrGroupId, boolean isGroup, long time, String callerId) {
        Log.e("smsretryfuture", " " + message);
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("sendfuturesmsretry","");
        String s = message;
        byte[] utf8Bytes = s.getBytes(StandardCharsets.UTF_8);
        int length = utf8Bytes.length;
        if (length <= 1000) {
            Executor.ex(() -> {
                if (s.length() == 0)
                    return;
                intent.putExtra(compose, s);
                // message.setText("");
                if (!isGroup) {
                    String[] numbers;
                    numbers = new String[1];
                    numbers[0] = numberOrGroupId;
                    intent.putExtra("to1", numbers);

                } else {
                    intent.putExtra("to1", GroupRepo.get().getGroupNumbers(numberOrGroupId));


                }

                if (isGroup)
                    intent.putExtra("groupid", numberOrGroupId);
                else
                    intent.putExtra("groupid", "");
                intent.putExtra("future_time_diff", time);
                intent.putExtra("callerid", callerId);
                LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
            });

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setMessage(context.getString(R.string.text_length_is_too_big));
            builder.setPositiveButton(R.string.ok,(d,__)-> d.dismiss());
            builder.create().show();
        }

        return true;
    }

    public void setRetryForFutureSMS(Context context, String messageId, boolean isGroup) {
        Executor.ex(() -> {
            SmsLogEntry smsLogEntry = SMSRepo.get().getSMSByRequestId(messageId);
            if (smsLogEntry != null) {
                String request_id = smsLogEntry.request_id;
                String number = smsLogEntry.number;


                if (RetryRepo.get().checkRetryExists(request_id)) {
                    int retry_count = RetryRepo.get().getRetryCountByCallerId(request_id);
                    if (retry_count >= Constants.MAXIMUM_FILE_RETRY_VALUE) {
                        RetryRepo.get().deleteRetryByCallerId(request_id);
                        SMSRepo.get().updateSMSDeliveryStatusByRequestId(request_id, SMSLogStatus.FAILED);
                    } else {
                        RetryRepo.get().deleteRetryByCallerId(request_id);
                        RetryRepo.get().createRetryEntry(request_id, Constants.BURN_TIME_DELAY_IN_SECS, number, isGroup, retry_count + 1);

                    }

                } else {
                    RetryRepo.get().createRetryEntry(request_id, Constants.BURN_TIME_DELAY_IN_SECS, number, isGroup, 0);

                    SMSRepo.get().updateSMSDeliveryStatusByRequestId(request_id, SMSLogStatus.PENDING);

                }
            }
        });


    }



}
