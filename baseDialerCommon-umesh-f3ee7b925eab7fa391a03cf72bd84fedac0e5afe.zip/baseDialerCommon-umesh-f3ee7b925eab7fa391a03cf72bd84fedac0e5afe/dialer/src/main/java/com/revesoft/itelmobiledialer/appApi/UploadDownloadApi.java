package com.revesoft.itelmobiledialer.appApi;

import com.revesoft.api.fileApi.FileApiError;
import com.revesoft.api.fileApi.FileApi;
import com.revesoft.api.fileApi.fileApiInterfaces.FileUploadListener;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.signalling.fileInterfaces.FileDownloadListener;
import com.revesoft.itelmobiledialer.signalling.fileInterfaces.FileDownloadProgressListener;
import com.revesoft.itelmobiledialer.signalling.fileInterfaces.FileUploadProgressListener;
import com.revesoft.itelmobiledialer.signalling.message.IMInfo;
import com.revesoft.itelmobiledialer.testunit.Voldemort;
import com.revesoft.itelmobiledialer.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class UploadDownloadApi {
    private static final String route = ProfilePicUploadDownloadHelper.fileUploadDownloadRoute;
    private static final String UPLOAD_REQUEST_TYPE ="upload";
    private static final String DOWNLOAD_REQUEST_TYPE ="download";

    public static void uploadFile(String toUser, String toGroup, String filePath, String caption, String callerId, int e2e, IMInfo imInfo
            , com.revesoft.itelmobiledialer.signalling.fileInterfaces.FileUploadListener fileUploadListener, FileUploadProgressListener fileUploadProgressListener)
    {
        Map<String, String> formDatas = new HashMap<>();
        formDatas.put("requestType", UPLOAD_REQUEST_TYPE);
        formDatas.put("toUser",toUser);
        formDatas.put("toGroup",toGroup);

        Map<String, File> files = new HashMap<>();
        files.put("newFile", new File(filePath));
        FileApi.Upload.upload(route, formDatas, files, null, new FileUploadListener() {
            @Override
            public void onUploadFinished(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    int statusCode = jsonResponse.getInt("status");
                    if (statusCode == 0) {
                        String serverFileName = jsonResponse.getString("filename");
                        fileUploadListener.OnUploadFinished(toUser, toGroup, serverFileName, filePath, caption, callerId, true, e2e, imInfo);
                    } else {
                        fileUploadListener.OnUploadFinished(toUser, toGroup, "", filePath, caption, callerId, false, e2e, imInfo);
                    }
                } catch (JSONException e) {
                    fileUploadListener.OnUploadFinished(toUser, toGroup, "", filePath, caption, callerId, false, e2e, imInfo);
                }
            }

            @Override
            public void onUploadError(FileApiError e) {
                fileUploadListener.OnUploadFinished(toUser, toGroup, "", filePath, caption, callerId, false, e2e, imInfo);
            }

            @Override
            public void onUploadProgress(int progress) {
                fileUploadProgressListener.onUploadProgress(callerId, progress + "%");
            }
        });
    }


    public static void downloadFile(String fileName, File destFile, String callerID, boolean isToGroup, FileDownloadListener fileDownloadListener,
                                    FileDownloadProgressListener fileDownloadProgresListener, boolean isLongMessage,
                                    int retryCount)
    {
        HashMap<String, String> formDatas = new HashMap<>();
        formDatas.put("requestType",DOWNLOAD_REQUEST_TYPE);
        formDatas.put("filename",fileName);
        FileApi.Download.download(route, destFile, formDatas, null, new com.revesoft.api.fileApi.fileApiInterfaces.FileDownloadListener()
        {
            @Override
            public void onDownloadFinished(String filePath) {
                Log.i("tanvvvvv",filePath);
                if(isLongMessage)
                {
                    String longMessageCallerId = callerID+"::longMessage"+retryCount;
                    fileDownloadListener.OnDownloadFinished(longMessageCallerId,true,isToGroup);
                }
                else
                {
                    fileDownloadListener.OnDownloadFinished(callerID,true,isToGroup);
                }
            }

            @Override
            public void onDownloadError(FileApiError e) {
                Voldemort.avrakaDavra();
                Log.i("tanvvvvv","error",e);
                if(isLongMessage)
                {
                    String longMessageCallerId = callerID+"::longMessage"+retryCount;
                    fileDownloadListener.OnDownloadFinished(longMessageCallerId,false,isToGroup);
                }
                else
                {
                    fileDownloadListener.OnDownloadFinished(callerID,false,isToGroup);
                }
            }

            @Override
            public void onDownloadProgress(int progress) {
                fileDownloadProgresListener.onDownloadProgress(callerID,progress + "%");
            }
        });

    }

}
