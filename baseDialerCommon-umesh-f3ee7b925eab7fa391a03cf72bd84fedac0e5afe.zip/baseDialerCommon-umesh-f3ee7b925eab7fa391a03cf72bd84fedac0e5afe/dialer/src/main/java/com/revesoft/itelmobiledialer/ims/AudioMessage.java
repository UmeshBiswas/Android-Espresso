package com.revesoft.itelmobiledialer.ims;

/**
 * Created by Dhiman on 12/18/2017.
 */

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.revesoft.material.R;

import java.math.BigDecimal;

/**
 * Audio Message Model Object for IM.
 *
 * <p>
 * Various attributes of audio messages, getter setters, important view
 * changers and related behaviours.
 *
 * <p>
 * This class is supposed to be used with
 * {@link com.revesoft.itelmobiledialer.ims.MessageFragment.AudioPlayer}
 * player Class.
 */
class AudioMessage {
    long duration;
    long currentPosition = 0;
    String filePath;
    boolean isCurrentlyPlaying = false;
    ImageView playPauseIcon;
    TextView playPauseTextView;
    TextView durationTextView;
    Context context;

    /**
     * Constructor.
     *
     * @param filepath : absolute path of the audio file.
     */
    public AudioMessage(String filepath, Context context) {
        filePath = filepath;
        duration = getDurationInMilliSeconds(filePath);
        this.context = context;
    }

    /**
     * Extracts the duration from the given filepath.
     *
     * @param filePath : absulate path of the audio file.
     * @return : duration of the audio file in milliseconds long
     */
    private long getDurationInMilliSeconds(String filePath) {
        try {
            MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
            try {
                metaRetriever.setDataSource(filePath);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                return 0;
            }
            String duration = metaRetriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            Log.d("Asif", "Duration before parsing - " + duration);
            metaRetriever.release();
            return Long.parseLong(duration);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Changes the necessary UI when the streaming of this audio message is
     * played
     */
    public void changeViewsPlayed() {
        isCurrentlyPlaying = true;
        playPauseIcon.setImageResource(R.drawable.ic_message_audio_pause);
        playPauseTextView.setText(R.string.pause_audio_im);
    }

    /**
     * Changes the necessary UI when the streaming of this audio message is
     * paused
     */
    public void changeViewsWhenPaused() {
        isCurrentlyPlaying = false;
        playPauseIcon.setImageResource(R.drawable.ic_message_audio_play);
        playPauseTextView.setText(R.string.play_audio_im);
    }

    /**
     * Parses the millisecond duration to a readable minute:seconds string
     * structure
     *
     * @param milliseconds : duration in long
     * @return : readable duration in String
     */
    public String parseDuration(long milliseconds) {
        if (milliseconds <= 0)
            return "0:00";
        String out = "";
        int sec = (int) (milliseconds % 60000) / 1000;
        int min = (int) milliseconds / 60000;
        String seconds = (sec < 10) ? ("0" + sec) : (sec + "");
        out = min + ":" + seconds;
        Log.d("Asif", "Duration after parsing - " + out);
        return out;
    }

    // getter setters
    // duration
    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    // filepath
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    // current position
    public int getCurrentPosition() throws ArithmeticException {
        return new BigDecimal(currentPosition).intValueExact();
    }

    /**
     * Sets the Current position in the streaming
     *
     * @param currentPosition
     */
    public void setCurrentPosition(long currentPosition) {
        this.currentPosition = currentPosition;
        setDurationText(currentPosition);
    }

    /**
     * Checks if this audio message is currently playing or not
     *
     * @return true if currently playing, otherwise false
     */
    public boolean isCurrentlyPlaying() {
        return isCurrentlyPlaying;
    }

    /**
     * Sets if this audio message is currently streaming or not
     *
     * @param isCurrentlyPlaying
     */
    public void setIsCurrentlyPlaying(boolean isCurrentlyPlaying) {
        this.isCurrentlyPlaying = isCurrentlyPlaying;
    }

    // playPause Icon
    public ImageView getPlayPauseIcon() {
        return playPauseIcon;
    }

    public void setPlayPauseIconImageView(ImageView playPauseIcon) {
        this.playPauseIcon = playPauseIcon;

        this.playPauseIcon.setImageResource(R.drawable.ic_message_audio_play);
    }

    public void setPlayPauseIcon(Context context, int id) {
        this.playPauseIcon.setImageResource(id);
    }

    // play pause text view
    public TextView getPlayPauseTextView() {
        return playPauseTextView;
    }

    public void setPlayPauseTextView(TextView playPauseTextView) {
        this.playPauseTextView = playPauseTextView;
        this.playPauseTextView.setText(R.string.play_audio_im);
    }

    public void setPlayPauseTextViewText(String text) {
        this.playPauseTextView.setText(text);
    }

    // duration textview
    public void setDurationTextView(TextView textView) {
        this.durationTextView = textView;
        this.durationTextView.setText("   (" + getDuration(filePath)
                + ")   ");
    }

    private String getDuration(String filePath) {
        // load data file
        try {
            MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
            try {
                metaRetriever.setDataSource(filePath);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                return "00:00";
            }

            String out = "";

            // convert duration to minute:seconds
            String duration = metaRetriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            Log.d("Asif", "Duration before parsing - " + duration);
            long dur = Long.parseLong(duration);
            int sec = (int) (dur % 60000) / 1000;
            int min = (int) dur / 60000;
            // String seconds = String.valueOf((dur % 60000) / 1000);
            //
            // String minutes = String.valueOf(dur / 60000);
            String seconds = (sec < 10) ? ("0" + sec) : (sec + "");
            out = min + ":" + seconds;
            /*
             * if (seconds.length() == 1) { txtTime.setText("0" + minutes + ":0"
             * + seconds); }else { txtTime.setText("0" + minutes + ":" +
             * seconds); }
             */
            Log.d("Asif", "Duration after parsing - " + out);
            // close object
            metaRetriever.release();
            return out;
        } catch (Exception e) {
            return "00:00";
        }
    }

    /**
     * Sets the duration in the durationTextView
     *
     * @param duration
     */
    public void setDurationText(long duration) {
        durationTextView.setText("   (" + parseDuration(duration) + ")   ");
    }
}