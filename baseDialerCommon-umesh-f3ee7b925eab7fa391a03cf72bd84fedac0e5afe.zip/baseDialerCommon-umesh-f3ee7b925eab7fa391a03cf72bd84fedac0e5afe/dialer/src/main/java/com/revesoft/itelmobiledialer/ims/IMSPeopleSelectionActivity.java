package com.revesoft.itelmobiledialer.ims;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.SubscriberRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.databaseentry.SubscriberEntry;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.HashSet;

import androidx.cursoradapter.widget.CursorAdapter;
import androidx.loader.app.LoaderManager.LoaderCallbacks;
import androidx.loader.content.Loader;

public class IMSPeopleSelectionActivity extends BaseActivity implements
        LoaderCallbacks<Cursor> {

    private ListView friendList = null;
    //    private DatabaseConstants dbhelper;
    private IMSFriendsAdapter mAdapter;
    public static final String SELECTED_NUMBERS = "selectednumbers";
    public static final String EXISTING_GROUP_MEMBER_NUMBERS = "existingnumbers";
    public static final String GROUP_NAME = "groupname";
    public static final String SHOW_GROUP_NAME_KEY = "showgroupname";
    public static final String EXISTING_GROUP_NAME_KEY = "existinggroupname";
    public static final String SHOW_ONLY_GROUP_MEMBERS = "showonlygroupmembers";
    private boolean mShowGroupnameEditText;
    private boolean mShowOnlyGroupMembers;
    private EditText mGroupNameEditText;
    private FloatingActionButton mAddToGroup;
    private EditText mSelectedContactsEditText;
    private TextView mSelectedContactsTextView;
    private TextView mPeopleCount;
    private String[] mExistingGroupMemberNumbers;
    private String groupName = null;
    private String contactsSelected = null;

    private static HashSet<String> sImageReloadSet = new HashSet<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent data = getIntent();
        mExistingGroupMemberNumbers = data
                .getStringArrayExtra(EXISTING_GROUP_MEMBER_NUMBERS);
        mShowGroupnameEditText = data.getBooleanExtra(SHOW_GROUP_NAME_KEY,
                false);
        mShowOnlyGroupMembers = data.getBooleanExtra(SHOW_ONLY_GROUP_MEMBERS,
                false);
        groupName = data.getStringExtra(GROUP_NAME);
        contactsSelected = "";

        setContentView(R.layout.ims_friends_selection_layout);
        friendList = findViewById(R.id.friend_list);
        friendList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
//        dbhelper = DatabaseConstants.getInstance(this);
        mAdapter = new IMSFriendsAdapter(null);

        friendList.setAdapter(mAdapter);

        getSupportLoaderManager().initLoader(0, null, this);

        mGroupNameEditText = findViewById(R.id.edittext_groupname);
        mSelectedContactsTextView = findViewById(R.id.textview_contacts_added);
        mSelectedContactsEditText = findViewById(R.id.edittext_contacts_added);
        mAddToGroup = findViewById(R.id.add_to_group);
        mSelectedContactsEditText.addTextChangedListener(new SearchTextWatcher());
        mPeopleCount = findViewById(R.id.people_count);
        if (mShowGroupnameEditText) {
            mGroupNameEditText.setSelection(mGroupNameEditText.getText()
                    .toString().length());
        } else {
            findViewById(R.id.actionbar_layout).setVisibility(
                    View.GONE);
        }

        // No subscriber search while removing or adding members in a group
        if (mShowOnlyGroupMembers || mExistingGroupMemberNumbers != null)
            findViewById(R.id.contacts_selected_layout).setVisibility(View.GONE);

        mAddToGroup.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mSelectedContactsEditText.getVisibility() == View.GONE) {
                    mSelectedContactsEditText.setVisibility(View.VISIBLE);
                    mSelectedContactsTextView.setVisibility(View.GONE);
                    mSelectedContactsEditText.setText("");
                    mSelectedContactsEditText.setFocusable(true);
                    mSelectedContactsEditText.requestFocus();
                    mAddToGroup.setImageBitmap(drawableToBitmap(getResources().getDrawable(R.drawable.cancel)));
                } else {
                    mSelectedContactsEditText.setVisibility(View.GONE);
                    mSelectedContactsTextView.setVisibility(View.VISIBLE);
                    mSelectedContactsEditText.setText("");
                    mAddToGroup.setImageBitmap(drawableToBitmap(getResources().getDrawable(R.drawable.ic_input_add)));
                }
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (groupName != null) {
            setTitle(groupName);
            findViewById(R.id.actionbar_layout).setVisibility(View.GONE);
        } else setTitle(R.string.create_new_group);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_people_selection, menu);
        if (mShowOnlyGroupMembers) {
            menu.findItem(R.id.action_remove).setVisible(true);
            menu.findItem(R.id.action_create).setVisible(false);
            menu.findItem(R.id.action_add).setVisible(false);

        } else if (mExistingGroupMemberNumbers != null && groupName != null) {
            menu.findItem(R.id.action_remove).setVisible(false);
            menu.findItem(R.id.action_create).setVisible(false);
            menu.findItem(R.id.action_add).setVisible(true);

        } else if (mExistingGroupMemberNumbers != null && groupName == null) {
            menu.findItem(R.id.action_remove).setVisible(false);
            menu.findItem(R.id.action_create).setVisible(true);
            menu.findItem(R.id.action_add).setVisible(false);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent intent = new Intent();
        switch (id) {
            case R.id.action_create:
                // Two ways of creating a group
                // 1. Directly from MessageActivity by floating action button
                // 2. From a private chat history i.e. inside a private chat there's an action bar add icon.
                // So these two situations must be handled in two different ways in IMSPeopleSelectionActivity
                // For the first option we'll send intent with group name = null and no existing members
                // And for the second option we'll send one existing member whom i'm currently chatting with. In this case we'll send group name = null too!
                if (groupName == null && mExistingGroupMemberNumbers == null) {
                    if (mAdapter.getCount() > 1) {
                        intent.putStringArrayListExtra(SELECTED_NUMBERS,
                                mAdapter.getCheckedItems());
                        if (mGroupNameEditText.getText().toString().length() > 0)
                            intent.putExtra(GROUP_NAME, mGroupNameEditText.getText().toString());
                        else
                            intent.putExtra(GROUP_NAME, mSelectedContactsTextView.getText().toString());

                        setResult(RESULT_OK, intent);
                        finish();
                    } else
                        Toast.makeText(this, R.string.min_people_selection_toast, Toast.LENGTH_SHORT).show();
                } else if (groupName == null && mExistingGroupMemberNumbers != null) {
                    ArrayList<String> checkedItems = mAdapter.getCheckedItems();
                    if (checkedItems.size() > 0) {
                        checkedItems.add(mExistingGroupMemberNumbers[0]);
                        intent.putStringArrayListExtra(SELECTED_NUMBERS,
                                checkedItems);
                        if (mGroupNameEditText.getText().toString().length() > 0)
                            intent.putExtra(GROUP_NAME, mGroupNameEditText.getText().toString());
                        else
                            intent.putExtra(GROUP_NAME, mSelectedContactsTextView.getText().toString());

                        setResult(RESULT_OK, intent);
                        finish();
                    } else
                        Toast.makeText(this, R.string.please_select_a_number_to_start_conversation, Toast.LENGTH_SHORT).show();
                }
                return true;
            case R.id.action_add:
                intent.putStringArrayListExtra(SELECTED_NUMBERS,
                        mAdapter.getCheckedItems());
                intent.putExtra(GROUP_NAME, mGroupNameEditText.getText().toString());
                setResult(RESULT_OK, intent);
                finish();
                return true;
            case R.id.action_remove:
                intent.putStringArrayListExtra(SELECTED_NUMBERS,
                        mAdapter.getCheckedItems());
                intent.putExtra(GROUP_NAME, mGroupNameEditText.getText().toString());
                setResult(RESULT_OK, intent);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
        return new SQLiteCursorLoader(this) {
            @Override
            public Cursor loadInBackground() {
                Cursor cursor = null;
                if (mSelectedContactsEditText != null)
                    mCurFilter = mSelectedContactsEditText.getText().toString();
                try {
                    if (mShowOnlyGroupMembers) {
                        cursor = GroupRepo.get()
                                .getGroupMembers(mExistingGroupMemberNumbers);
                    } else if (mExistingGroupMemberNumbers != null) {
                        cursor = SubscriberRepo.get()
                                .getSubscribersExcludingSpecifiedNumbers(mExistingGroupMemberNumbers);
                    } else if (mCurFilter != null && !mCurFilter.equals("") && !mShowOnlyGroupMembers && mExistingGroupMemberNumbers == null) {
                        cursor = SubscriberRepo.get().searchSubscriberCursor(mCurFilter);
                    } else {
                        cursor = SubscriberRepo.get().getSubscriberCursor();
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    cursor.getCount();
                    this.registerContentObserver(cursor, DatabaseConstants.SUBSCRIBER_URI);
                }

                return cursor;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> arg0, Cursor cursor) {
        mAdapter.swapCursor(cursor);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> arg0) {
        mAdapter.swapCursor(null);
    }

    private class IMSFriendsAdapter extends CursorAdapter {
        private ArrayList<String> checkedItems = null;

        public IMSFriendsAdapter(Cursor c) {
            super(IMSPeopleSelectionActivity.this, c, false);
            checkedItems = new ArrayList<String>();
        }

        public ArrayList<String> getCheckedItems() {
            return checkedItems;
        }

        @Override
        public void bindView(View convertView, final Context context,
                             final Cursor cursor) {
            final ViewHolder holder = (ViewHolder) convertView.getTag();

            final String number = cursor.getString(cursor
                    .getColumnIndex(DatabaseConstants.KEY_NUMBER));
            final int state = cursor.getInt(cursor
                    .getColumnIndex(DatabaseConstants.KEY_PRESENCE_STATE));
            final String name = cursor.getString(cursor
                    .getColumnIndex(DatabaseConstants.KEY_NAME));
            final int randomColor = cursor.getPosition() % 10;

            // Set contact image
            Bitmap b = null;
            b = ProfilePicUploadDownloadHelper
                    .getContactThumbnailImage(context, number, 96, 96);

            if (b == null) {
                if (name != null && name.length() > 0)
                    holder.mPortraitTxt.setText(String.valueOf(name.charAt(0)).toUpperCase());
                else if (number != null && number.length() > 0)
                    holder.mPortraitTxt.setText(String.valueOf(number.charAt(0)).toUpperCase());
                else holder.mPortraitTxt.setText("");

                holder.mPortraitTxt.setVisibility(View.VISIBLE);
                holder.mPortrait.setVisibility(View.GONE);

                if (randomColor == 0)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle));
                else if (randomColor == 1)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_blue));
                else if (randomColor == 2)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_brightpink));
                else if (randomColor == 3)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_cyan));
                else if (randomColor == 4)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_megenta));
                else if (randomColor == 5)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_orange));
                else if (randomColor == 6)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_red));
                else if (randomColor == 7)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_springgreen));
                else if (randomColor == 8)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_violet));
                else if (randomColor == 9)
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_yellow));
                else
                    holder.mPortraitTxt.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_portrait_circle_azure));

            } else {
                holder.mPortrait.setImageBitmap(b);

                holder.mPortraitTxt.setVisibility(View.GONE);
                holder.mPortrait.setVisibility(View.VISIBLE);
            }

            if (state == SubscriberEntry.PresenceState.AVAILABLE) {
                holder.state
                        .setBackgroundResource(android.R.drawable.presence_online);
                holder.name
                        .setTextColor(getResources().getColor(R.color.green));
            } else if (state == SubscriberEntry.PresenceState.AWAY) {
                holder.state
                        .setBackgroundResource(android.R.drawable.presence_away);
                holder.name.setTextColor(getResources().getColor(R.color.gray));
            } else if (state == SubscriberEntry.PresenceState.BUSY) {
                holder.state
                        .setBackgroundResource(android.R.drawable.presence_busy);
                holder.name.setTextColor(getResources().getColor(R.color.red));
            } else {
                holder.state
                        .setBackgroundResource(android.R.color.transparent);
                holder.name.setTextColor(getResources().getColor(
                        R.color.black));
            }

            if (name == null || name.equals("")) {
                holder.name.setText(number);
            } else {
                holder.name.setText(name);
            }

            if (checkedItems.contains(number)) {
                holder.selected.setChecked(true);
            } else {
                holder.selected.setChecked(false);
            }

            holder.selected.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (checkedItems.contains(number)
                            && !holder.selected.isChecked()) {
                        checkedItems.remove(number);
                    } else if (!checkedItems.contains(number)
                            && holder.selected.isChecked()) {
                        checkedItems.add(number);
                    }

                    contactsSelected = "";
                    for (int i = 0; i < checkedItems.size(); i++) {

                        String contactName = ContactEngine.getContactNamefromNumber(context, checkedItems.get(i));
                        if (contactName == null) contactName = checkedItems.get(i);

                        if (contactsSelected.length() == 0)
                            contactsSelected += contactName;
                        else
                            contactsSelected += ", " + contactName;
                    }

                    mSelectedContactsTextView.setVisibility(View.VISIBLE);
                    mSelectedContactsEditText.setText("");
                    mSelectedContactsEditText.setVisibility(View.GONE);
                    mAddToGroup.setImageBitmap(drawableToBitmap(getResources().getDrawable(R.drawable.ic_input_add)));

                    if (contactsSelected.length() > 0)
                        mSelectedContactsTextView.setText(contactsSelected);
                    else mSelectedContactsTextView.setText("");

                    if (checkedItems.size() > 0) {
                        mPeopleCount.setText(checkedItems.size() + "");
                        mPeopleCount.setVisibility(View.VISIBLE);
                    } else mPeopleCount.setVisibility(View.GONE);
                }
            });

            convertView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (checkedItems.contains(number)) {
                        checkedItems.remove(number);
                        holder.selected.setChecked(false);
                    } else if (!checkedItems.contains(number)) {
                        checkedItems.add(number);
                        holder.selected.setChecked(true);
                    }

                    contactsSelected = "";
                    for (int i = 0; i < checkedItems.size(); i++) {

                        String contactName = ContactEngine.getContactNamefromNumber(context, checkedItems.get(i));
                        if (contactName == null) contactName = checkedItems.get(i);

                        if (contactsSelected.length() == 0)
                            contactsSelected += contactName;
                        else
                            contactsSelected += ", " + contactName;
                    }

                    mSelectedContactsTextView.setVisibility(View.VISIBLE);
                    mSelectedContactsEditText.setText("");
                    mSelectedContactsEditText.setVisibility(View.GONE);
                    mAddToGroup.setImageBitmap(drawableToBitmap(getResources().getDrawable(R.drawable.ic_input_add)));

                    if (contactsSelected.length() > 0)
                        mSelectedContactsTextView.setText(contactsSelected);
                    else mSelectedContactsTextView.setText("");

                    if (checkedItems.size() > 0) {
                        mPeopleCount.setText(checkedItems.size() + "");
                        mPeopleCount.setVisibility(View.VISIBLE);
                    } else mPeopleCount.setVisibility(View.GONE);
                }
            });
        }

        @Override
        public View newView(Context context, Cursor arg1, ViewGroup arg2) {
            View convertView = LayoutInflater.from(context).inflate(
                    R.layout.ims_contact_selection_row, null);
            ViewHolder holder = new ViewHolder();
            holder.name = convertView.findViewById(R.id.name);
            holder.state = convertView.findViewById(R.id.state);
            holder.selected = convertView
                    .findViewById(R.id.checkBoxSelection);
            holder.mPortraitTxt = convertView.findViewById(R.id.portraitTxt);
            holder.mPortrait = convertView.findViewById(R.id.portrait);
            convertView.setTag(holder);
            return convertView;
        }
    }

    static class ViewHolder {
        TextView name;
        ImageView state;
        CheckBox selected;
        TextView mPortraitTxt;
        ImageView mPortrait;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public static void addToImageReloadSet(String value) {
        sImageReloadSet.add(value);
    }

    String mCurFilter;

    public boolean onQueryTextChange(String newText) {
        String newFilter = !TextUtils.isEmpty(newText) ? newText : null;
        if (mCurFilter == null && newFilter == null) {
            return true;
        }
        if (mCurFilter != null && mCurFilter.equals(newFilter)) {
            return true;
        }
        mCurFilter = newFilter;
        getSupportLoaderManager().restartLoader(0, null, IMSPeopleSelectionActivity.this);
        return true;
    }

    private class SearchTextWatcher implements TextWatcher {
        @Override
        public void onTextChanged(CharSequence s, int start, int before,
                                  int count) {
            onQueryTextChange(mSelectedContactsEditText.getText().toString());
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }
}
