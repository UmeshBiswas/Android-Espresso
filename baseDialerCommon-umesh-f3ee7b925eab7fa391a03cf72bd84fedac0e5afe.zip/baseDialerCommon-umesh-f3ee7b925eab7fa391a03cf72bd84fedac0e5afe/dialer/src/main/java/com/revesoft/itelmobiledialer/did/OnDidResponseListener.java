package com.revesoft.itelmobiledialer.did;

import java.util.ArrayList;

/**
 * Created by Rahat on 9/18/2017.
 */
public interface OnDidResponseListener {
    void onCountryListResponse(String[] countryNames, int[] countryFlags);

    void onStatesListResponse(String[] stateNames, String[] stateCode);

    void onCityListResponse(String[] cityNames, String[] cityCode);


    void onDIDListResponse(ArrayList<DID> dids);

    void onUsersDidListResponse(ArrayList<DID> dids);

    void onBuyUsersDID(DID did);

    void onUnsubscribeDid(DID selectedDID);

    void onForwardedNumberSet(String forwardedNumber);
}