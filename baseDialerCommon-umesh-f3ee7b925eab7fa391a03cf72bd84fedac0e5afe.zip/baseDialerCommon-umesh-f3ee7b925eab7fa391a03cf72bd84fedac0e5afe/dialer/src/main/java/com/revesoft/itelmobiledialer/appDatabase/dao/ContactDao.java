package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;
import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface ContactDao extends BaseDao<Contact> {
    @Query("SELECT * FROM contacts group by processed_number")
    List<Contact> getAll();

    @Query("SELECT * FROM contacts " +
            "where name like :filter OR number like :filter OR processed_number like :filter " +
            "group by processed_number ORDER BY name COLLATE NOCASE ASC")
    DataSource.Factory<Integer, Contact> getAllLivePagedFiltered(String filter);

    @Query("SELECT * FROM contacts where processed_number in (SELECT number from subscriber) " +
            "and (name like :filter OR number like :filter OR processed_number like :filter) " +
            "group by processed_number ORDER BY name COLLATE NOCASE ASC")
    DataSource.Factory<Integer, Contact> getAppLivePagedFiltered(String filter);

    @Query(" SELECT * FROM contacts  where is_favourite=1  " +
            "and (name like :filter OR number like :filter OR processed_number like :filter) " +
            "group by contact_id ORDER BY name COLLATE NOCASE ASC")
    DataSource.Factory<Integer, Contact> getFavoriteLivePagedFiltered(String filter);

    @Query("SELECT * FROM contacts where processed_number in (SELECT number from block)" +
            "and (name like :filter OR number like :filter OR processed_number like :filter)  " +
            "group by processed_number ORDER BY name COLLATE NOCASE ASC")
    DataSource.Factory<Integer, Contact> getBlockedLivePagedFiltered(String filter);


    @Query("SELECT * FROM contacts where processed_number not in (SELECT number from block)  " +
            "and processed_number in (SELECT number from subscriber) " +
            "and (name like :filter OR number like :filter OR processed_number like :filter)  " +
            "group by processed_number ORDER BY name COLLATE NOCASE ASC")
    DataSource.Factory<Integer, Contact> getNotBlockedLivePagedFiltered(String filter);

    @Query("SELECT * FROM contacts where contact_id=:contactId")
    LiveData<List<Contact>> getByContactId(String contactId);

    @Query("SELECT * FROM contacts where contact_id=:contactId")
    List<Contact> getByContactBytId(String contactId);

    @Query("SELECT contact_id from contacts where processed_number=:processedNumber LIMIT 1")
    String getContactIdByFlatNumber(String processedNumber);

    @Query("SELECT distinct * from contacts where processed_number IN(:processedNumbers) group by processed_number ORDER BY name COLLATE NOCASE ASC")
    List<Contact> getContactByFlatNumber(List<String> processedNumbers);


    @Query("SELECT * from contacts where processed_number IN (:processedNumbers)")
    List<Contact> getContactsByFlatNumber(List<String> processedNumbers);





    @Query("SELECT name FROM CONTACTS WHERE number=:num LIMIT 1")
    String getNameByNumber(String num);

    @Query("SELECT contact_id FROM CONTACTS WHERE number=:num LIMIT 1")
    String getContactIdByNumber(String num);


    @Query("SELECT lookup_key FROM CONTACTS WHERE processed_number=:processedNumber LIMIT 1")
    String lookUpKeyByProcessedNumber(String processedNumber);


    @Query("SELECT * FROM CONTACTS WHERE lookup_key=:lookUpKey")
    List<Contact> getAllContactsByLookUpKey(String lookUpKey);



    @Query("SELECT * FROM CONTACTS GROUP BY processed_number ORDER BY" +
            " CONTACTS.name COLLATE LOCALIZED ASC")
    List<Contact> getAllContacts();


    @Query("SELECT * FROM CONTACTS GROUP BY processed_number ORDER BY" +
            " CONTACTS.name COLLATE LOCALIZED ASC")
    Cursor getAllContactsCursor();


    @Query("SELECT * FROM CONTACTS " +
            "WHERE processed_number <> :userName " +
                "AND ( name like :searchText OR processed_number like :searchText OR number like :searchText )"+
            "GROUP BY processed_number "+
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    List<Contact> searchContact(String userName,String searchText);



    @Query("SELECT * FROM CONTACTS " +
            "WHERE processed_number <> :userName " +
            "AND ( name like :searchText OR processed_number like :searchText OR number like :searchText )"+
            "GROUP BY processed_number "+
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    Cursor searchContactCursor(String userName,String searchText);


    @Query("SELECT * FROM CONTACTS " +
            "WHERE name like  :searchText  OR processed_number like :searchText " +
            "GROUP BY contact_id " +
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    Cursor searchAllGroupedContact(String searchText);




    @Query("SELECT * FROM CONTACTS " +
            "WHERE is_favourite=1 AND (name like  :searchText  OR processed_number like :searchText) " +
            "GROUP BY contact_id " +
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    List<Contact> searchAllFavoriteContact(String searchText);


    @Query("SELECT COUNT(*) FROM CONTACTS WHERE processed_number=:translatedNumber")
    boolean isContact(String translatedNumber);




    @Query("SELECT COUNT(*) FROM CONTACTS WHERE contact_id=:contact_id")
    boolean isContactExistsByContactId(String contact_id);


    @Query("SELECT COUNT(*) FROM CONTACTS WHERE processed_number=:processedNumber")
    boolean isContactExistsByProcessedNumber(String processedNumber);




    @Query("UPDATE CONTACTS SET name=:name,number=:number,lookup_key=:lookUpKey," +
            "contact_id=:contact_id,photo_uri=:photo_uri,processed_number=:processed_number," +
            "is_favourite=:is_fav WHERE contact_id=:contact_id")
    void replaceModifiedContact(String name,String number,String lookUpKey,String contact_id,
                                String photo_uri,String processed_number,int is_fav);


    @Query("SELECT * FROM CONTACTS " +
            "WHERE is_favourite=1 AND (name like  :searchText  OR processed_number like :searchText) " +
            "GROUP BY contact_id " +
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    Cursor favoriteCursor(String searchText);


    @Query("SELECT * FROM CONTACTS WHERE processed_number IN (:numberOfContactsToRead) GROUP BY processed_number")
    Cursor byProcessedNumbers(String[] numberOfContactsToRead);






    @Query("SELECT " +
            "CONTACTS.name AS name," +
            "CONTACTS.processed_number AS processed_number," +
            "CONTACTS.lookup_key AS lookup_key," +
            "CONTACTS.photo_uri AS photo_uri " +
            "FROM SUBSCRIBER LEFT JOIN CONTACTS ON SUBSCRIBER.number = CONTACTS.processed_number " +
            "WHERE (CONTACTS.name LIKE :searchText OR CONTACTS.number LIKE :searchText) " +
            "AND CONTACTS.name IS NOT NULL AND CONTACTS.lookup_key IS NOT NULL " +
            "GROUP BY SUBSCRIBER.number " +
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    Cursor getAppContactsCursor(String searchText);



    @Query("SELECT " +
            "CONTACTS.name AS name," +
            "CONTACTS.processed_number AS processed_number," +
            "CONTACTS.lookup_key AS lookup_key," +
            "CONTACTS.photo_uri AS photo_uri " +
            "FROM SUBSCRIBER LEFT JOIN CONTACTS ON SUBSCRIBER.number = CONTACTS.processed_number " +
            "WHERE (CONTACTS.name LIKE :searchText OR CONTACTS.number LIKE :searchText) " +
            "AND CONTACTS.name IS NOT NULL AND CONTACTS.lookup_key IS NOT NULL " +
            "AND processed_number NOT IN (:excludeContactNumbers)" +
            "GROUP BY SUBSCRIBER.number " +
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    Cursor getAppContactsCursorExcludingSome(String searchText, String[] excludeContactNumbers);



    @Query("SELECT " +
            "CONTACTS.name AS name," +
            "CONTACTS.processed_number AS processed_number," +
            "CONTACTS.lookup_key AS lookup_key," +
            "CONTACTS.photo_uri AS photo_uri " +
            "FROM CONTACTS " +
            "WHERE (CONTACTS.name LIKE :searchText OR CONTACTS.number LIKE :searchText) " +
            "AND CONTACTS.name IS NOT NULL AND CONTACTS.lookup_key IS NOT NULL " +
            "AND processed_number NOT IN (SELECT number FROM SUBSCRIBER) " +
            "GROUP BY CONTACTS.processed_number " +
            "ORDER BY CONTACTS.name COLLATE LOCALIZED ASC")
    Cursor _getNonAppContactsCursor(String searchText);





    @Query("DELETE FROM CONTACTS WHERE lookup_key=:lookUpKey")
    void deleteContactByLookUpKey(String lookUpKey);


    @Query("DELETE FROM CONTACTS WHERE lookup_key=:processedNumber")
    void deleteContactByProcessedNumber(String processedNumber);


    @Query("UPDATE CONTACTS SET is_favourite=0 WHERE lookup_key=:lookUpKey")
    void removeFromFavoriteListByLookUpKey(String lookUpKey);



    @Query("UPDATE CONTACTS SET is_favourite=1 WHERE lookup_key=:lookUpKey")
    void addToFavoriteByLookUpKey(String lookUpKey);


    @Query("DELETE FROM CONTACTS WHERE contact_id IN (:notFoundContactId)")
    void deleteContactByContactIdsNotFound(List<String> notFoundContactId);


    @Query("SELECT contact_id FROM CONTACTS")
    List<String> getAllAppContactId();



    @Query("SELECT * FROM CONTACTS WHERE is_favourite=1 AND (name LIKE :searchText OR processed_number LIKE :searchText)" +
            "ORDER BY name COLLATE LOCALIZED ASC")
    Cursor searchFavoriteContacts(String searchText);


    @Query("select * from contacts where processed_number in(:numbers) group by processed_number order by name collate LOCALIZED asc")
    List<Contact> getContactsByNumber(String[] numbers);
}
