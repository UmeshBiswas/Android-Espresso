package com.revesoft.itelmobiledialer.dialogues;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.revesoft.material.R;

/**
 * Created by ashikee on 11/6/16.
 */
public class CustomProgressDialog extends Dialog {

    TextView  mTextViewHeading,mTextViewMessage;
    boolean  isMessageVisible;
    boolean isCancelable;
    String  message,heading;
    ProgressBar progressBar;
    Context customProgressDialog;

    public CustomProgressDialog(Context c,String heading,String message, boolean isMessageVisible, boolean isCancelable)
    {
        super(c);
        customProgressDialog = c;
        this.heading =heading;
        this.message = message;
        this.isMessageVisible = isMessageVisible;
        this.isCancelable = isCancelable;

    }

    public void setMessage(String message)
    {
        this.message = message;
    }
    @Override
    public void setCancelable(boolean cancelable) {
        isCancelable = cancelable;
    }
    public void setMessageVisible(boolean messageVisible) {
        isMessageVisible = messageVisible;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        this.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        setContentView(R.layout.customdialog_progress);
        this.setCancelable(isCancelable);
        progressBar = findViewById(R.id.progressbar);
        mTextViewHeading = (TextView) findViewById(R.id.textviewHeading);
        if(heading != null && heading.length() != 0)
            mTextViewHeading.setText(heading);
        else
            findViewById(R.id.relativeLayoutHeadingContainer).setVisibility(View.GONE);
        mTextViewMessage  = (TextView) findViewById(R.id.message);
        mTextViewMessage.setText(message);

    }
}
