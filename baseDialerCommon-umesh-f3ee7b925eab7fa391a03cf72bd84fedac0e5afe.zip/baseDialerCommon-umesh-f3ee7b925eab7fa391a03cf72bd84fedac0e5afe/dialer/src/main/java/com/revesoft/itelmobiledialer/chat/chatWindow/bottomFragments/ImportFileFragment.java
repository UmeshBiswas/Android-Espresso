package com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments;


import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.dropbox.chooser.android.DbxChooser;
import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.android.AndroidAuthSession;
import com.dropbox.client2.android.AuthActivity;
import com.dropbox.client2.exception.DropboxException;
import com.dropbox.client2.session.AccessTokenPair;
import com.dropbox.client2.session.AppKeyPair;
import com.revesoft.itelmobiledialer.chat.chatWindow.futureMessage.FutureMessageTimeDialogs;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Controllable;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.chat.chatWindow.supportiveActivities.LocalFileImportActivity;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListAdapter;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListItem;
import com.revesoft.itelmobiledialer.ims.imhelper.TimePickerDoneClickListner;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;

import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Objects;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;


@TargetApi(Build.VERSION_CODES.KITKAT)
public class ImportFileFragment extends Fragment implements TimePickerDoneClickListner {

    private static final String TAG = "ImportFileFragmentTAG";

    public static String getTAG() {
        return TAG;
    }


    private static final int DROPBOX_PICKER = 10221;
    private static final int GOOGLE_PHOTOS_PICKER = 10222;
    private static final int GOOGLE_DRIVE_PICKER = 10223;
    private static final int LOCAL_FILE_PICKER = 10224;
    private static final int GALLERY_IMAGE_PICKER = 10225;
    private static final String APP_KEY = "0lwxxjh0miepwgu";
    private ProgressDialog driveFilePrecessingProgressDialog;
    //DropBox Credentials
    private String dropBoxAppKey;
    private String ACCOUNT_PREFS_NAME = "prefs";
    private String ACCESS_KEY_NAME = "ACCESS_KEY";
    private String ACCESS_SECRET_NAME = "ACCESS_SECRET";
    private int DBX_CHOOSER_REQUEST = 1123;

    private DbxChooser mChooser;
    private DropboxAPI<AndroidAuthSession> mApi;
    private boolean isDropboxDownloadEnabled = true;
    private String dropBoxAppSecret;
    private ImportFileFragment importfilefragment;
    private String selectedFilePath = "";


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {


            String path = "";
            if (msg != null && msg.getData() != null) {
                path = msg.getData().getString("file_path");
            }
            Log.e("fileimport", " called path: " + path);
            if (driveFilePrecessingProgressDialog != null)
                driveFilePrecessingProgressDialog.dismiss();
            showFileSendingOptionsDialog(path);
            super.handleMessage(msg);
        }
    };


    public ImportFileFragment() {

    }

    public static ImportFileFragment newInstance() {
        ImportFileFragment fragment = new ImportFileFragment();
        return fragment;
    }

    private Controllable parentActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dropBoxAppKey = Objects.requireNonNull(getActivity()).getString(R.string.dropbox_app_key);
        dropBoxAppSecret = getActivity().getString(R.string.dropbox_app_secret);

        if (getActivity() instanceof Controllable) {
            parentActivity = (Controllable) getActivity();
        }
    }


    @Override
    public void onDoneClick(long time) {
        ArrayList<String> path = new ArrayList<>();
        if (selectedFilePath != null && selectedFilePath.length() > 0) {
            Sender.getAccess().sendFile(selectedFilePath);
            if(parentActivity != null){
                parentActivity.onControlRequest(Controllable.RequestType.HideBottomFragments);
            }
        }

        selectedFilePath = "";

    }


    @Override
    public void onResume() {
        super.onResume();
        if (mApi != null && isDropboxDownloadEnabled) {
            AndroidAuthSession session = mApi.getSession();
            if (session.authenticationSuccessful()) {
                try {
                    session.finishAuthentication();
                    storeAuth(session);
                    //StartChoosingFile
                    isDropboxDownloadEnabled = false;
                    mChooser.forResultType(DbxChooser.ResultType.FILE_CONTENT).launch(this, DBX_CHOOSER_REQUEST);
                } catch (IllegalStateException e) {
                    Log.e("Pias", "Error authenticating", e);
                }
            }

        }

    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_import_file, container, false);
        mChooser = new DbxChooser(APP_KEY);


        importfilefragment = this;


        LinearLayout mDropBoxButton = view.findViewById(R.id.button_dropbox);
        mDropBoxButton.setOnClickListener(v -> chooseFromDropBoxFileSend());

        LinearLayout mGoogleDriveButton = view.findViewById(R.id.button_google_drive);
        mGoogleDriveButton.setOnClickListener(v -> chooseFromGoogleDriveN());

        LinearLayout mLocalDriveButton = view.findViewById(R.id.button_local_drive);
        mLocalDriveButton.setOnClickListener(v -> chooseFromLocalDrive());

        LinearLayout mGooglePhotosButton = view.findViewById(R.id.button_google_photos);
        mGooglePhotosButton.setOnClickListener(v -> chooseFromGooglePhotos());


        View mGalleryImageButton = view.findViewById(R.id.button_gallery);
        mGalleryImageButton.setOnClickListener(v -> chooseFromGallery());

        return view;
    }




    private void chooseFromLocalDrive() {
        Uri uri = Uri.parse(Environment.getExternalStorageDirectory().getPath());

        Intent intent = new Intent(getActivity(), LocalFileImportActivity.class);
        intent.putExtra(LocalFileImportActivity.START_PATH, uri + "/");
        intent.putExtra(LocalFileImportActivity.CAN_SELECT_DIR, true);

        startActivityForResult(intent, LOCAL_FILE_PICKER);
    }


    private void chooseFromGoogleDriveN() {
        if (isPackageInstalled("com.google.android.apps.docs", Objects.requireNonNull(getActivity()))) {
            Intent intent = new Intent();
            intent.setType("file/*");
            intent.setPackage("com.google.android.apps.docs");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select file"), GOOGLE_DRIVE_PICKER);
        } else {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + "com.google.android.apps.docs")));
            } catch (ActivityNotFoundException anfe) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + "com.google.android.apps.docs")));
            }
        }
    }


    private void chooseFromDropBoxFileSend() {

        AndroidAuthSession session = buildSession();
        mApi = new DropboxAPI<>(session);
        if (!isAppKeySetProperly())
            I.toast("Dropbox is not set properly");
        else {
            if (buildSession().isLinked()) {
                Log.d("pias", "dhuktase" + isDropboxDownloadEnabled);
                if (mApi != null) {
                    Log.d("pias", "dhuktase2");
                    mChooser.forResultType(DbxChooser.ResultType.FILE_CONTENT).launch(importfilefragment, DBX_CHOOSER_REQUEST);
                }
            } else {
                isDropboxDownloadEnabled = true;
                mApi.getSession().startOAuth2Authentication(getActivity());
            }


        }
    }

    private void chooseFromGooglePhotos() {
        if (isPackageInstalled("com.google.android.apps.photos", Objects.requireNonNull(getActivity()))) {
            Intent intent = new Intent();
            intent.setPackage("com.google.android.apps.photos");
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select your photo"), GOOGLE_PHOTOS_PICKER);
        } else {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + "com.google.android.apps.photos")));
            } catch (ActivityNotFoundException anfe) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + "com.google.android.apps.photos")));
            }
        }

    }


    private void chooseFromGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), GALLERY_IMAGE_PICKER);
    }


    private boolean isPackageInstalled(String packageName, Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }





    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("ImportFile", "requestCode: " + requestCode + " resultCode: " + resultCode);
        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == DBX_CHOOSER_REQUEST) {

                DbxChooser.Result result = new DbxChooser.Result(data);
                String path = result.getLink().toString().replaceFirst("file://", "");
                File file = new File(path);
                Uri fileuri = result.getLink();
                try {
                    InputStream in = Objects.requireNonNull(getActivity()).getContentResolver().openInputStream(fileuri);
                    File newFile = createFileFromInputStream(in, file.getName());
                    if (newFile != null)
                        path = newFile.getAbsolutePath();


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                showFileSendingOptionsDialog(path);
            } else if (requestCode == DROPBOX_PICKER) {

                Uri uriFileLink = processDropBoxData(resultCode, data);
                showFileSendingOptionsDialog(uriFileLink.toString());


            } else if (requestCode == GOOGLE_DRIVE_PICKER) {
                sendGoogleDriveFile(data);


            } else if (requestCode == GOOGLE_PHOTOS_PICKER) {
                String path = getImageFilePath(data);
                if (path == null || path.equals("")) {
                    path = getImageUrlWithAuthority(getActivity(), data.getData());
                    path = getImageFilePath(path);
                }
                if (path != null) showFileSendingOptionsDialog(path);
            } else if (requestCode == GALLERY_IMAGE_PICKER) {
                String path = getImageFilePath(data);
                if (path == null || path.equals("")) {
                    path = getImageUrlWithAuthority(getActivity(), data.getData());
                    path = getImageFilePath(path);
                }
                if (path != null) showFileSendingOptionsDialog(path);
            } else if (requestCode == LOCAL_FILE_PICKER) {
                    showFileSendingOptionsDialog(getLocalDriveFilePath(data));
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private File createFileFromInputStream(InputStream inputStream, String fileName) {

        try {
            File f = ProfilePicUploadDownloadHelper
                    .getDownloadedImageFile(getActivity(), fileName);
            f.setWritable(true, false);

            OutputStream outputStream = new FileOutputStream(f);
            byte buffer[] = new byte[1024];
            int length = 0;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            return f;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }


    public String getImageUrlWithAuthority(Context context, Uri uri) {
        InputStream is = null;
        if (uri.getAuthority() != null) {
            try {
                is = context.getContentResolver().openInputStream(uri);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                return writeToTempImageAndGetPathUri(context, bmp).toString();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (is != null)
                        is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public Uri writeToTempImageAndGetPathUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }


    private String getLocalDriveFilePath(Intent intent) {
        if (intent == null || !intent.hasExtra("RESULT_PATH")) {
            return "";
        }
        return intent.getStringExtra("RESULT_PATH");
    }


    private Uri processDropBoxData(int resultCode, Intent intent) {
        if (intent == null || !intent.hasExtra("EXTRA_CHOOSER_RESULTS")) {
            return null;
        }
        if (resultCode == Activity.RESULT_OK) {
            DbxChooser.Result result = new DbxChooser.Result(intent);
            return result.getLink();
        } else {
            Log.d("onActivityResult", "failed");
        }
        return null;
    }


    private boolean hasStorageEnoughSpace(long fileSize) {
        int threshold = 1024 * 1024 * 30;
        return Environment.getRootDirectory().getFreeSpace() - fileSize > threshold;
    }

    private void showFileSendingOptionsDialog(final String filePath) {


        File file = new File(filePath);
        if (file.length() > 50 * 1024 * 1024) {
            I.toast(getString(R.string.sending_file_size_warning));
            return;
        }


        AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()));
        ArrayList<ImageListItem> itemsList = new ArrayList<>(3);
        itemsList.add(new ImageListItem(getActivity().getString(R.string.send_in_future), R.drawable.ic_scheduled_message));
        itemsList.add(new ImageListItem(getActivity().getString(R.string.Send), R.drawable.ic_send));

        ImageListAdapter imageListAdapter = new ImageListAdapter(getActivity(), itemsList, false);

        builder.setAdapter(imageListAdapter, (dialog, which) -> {
            switch (which) {
                case 0:
                    FutureMessageTimeDialogs.showDateTimePicker((formattedDateTime, sendCurrentTimeStamp) ->
                            Sender.getAccess().sendFutureFile(filePath, formattedDateTime.getTime(), sendCurrentTimeStamp));
                    break;
                case 1:
                    Sender.getAccess().sendFile(filePath);
                    break;
                case 2:
                    dialog.dismiss();

            }
            dialog.dismiss();
        });

        builder.create().show();


    }

    private String getImageFilePath(Intent data) {
        if (data == null) {
            return "";
        }
        String filePath = "";
        Uri mUri = data.getData();
        if (mUri != null && "content".equals(mUri.getScheme())) {
            Cursor cursor = getActivity().getContentResolver().query(mUri, new String[]{MediaStore.Images.ImageColumns.DATA}, null, null, null);
            cursor.moveToFirst();
            filePath = cursor.getString(cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA));
            cursor.close();
        } else {
            filePath = mUri.getPath();
        }
        return filePath;
    }


    private void sendGoogleDriveFile(Intent data) {

        driveFilePrecessingProgressDialog = new ProgressDialog(getActivity());
        driveFilePrecessingProgressDialog.setMessage(getString(R.string.processing_file));
        driveFilePrecessingProgressDialog.show();

        Uri _uri = data.getData();
        Log.d("", "URI = " + _uri);
        if (_uri != null && "content".equals(_uri.getScheme())) {
            Cursor cursor = Objects.requireNonNull(getActivity()).getContentResolver().query(_uri, null, null, null, null);

            if (cursor != null) {
                cursor.moveToFirst();
                String displayName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                long fileSize = cursor.getLong(cursor.getColumnIndex(OpenableColumns.SIZE));


                if (fileSize > 150 * 1024 * 1024) {
                    driveFilePrecessingProgressDialog.dismiss();
                    I.toast(R.string.sending_file_size_warning);
                    return;
                }


                if (!hasStorageEnoughSpace(fileSize)) {
                    driveFilePrecessingProgressDialog.dismiss();
                    I.toast(getString(R.string.sending_file_not_enough_space));
                    return;
                }
                createTempDriveFileAndSend(data, displayName);
                cursor.close();
            } else {
                driveFilePrecessingProgressDialog.dismiss();
                I.toast(R.string.sending_file_failed);
            }

        } else {
            driveFilePrecessingProgressDialog.dismiss();
            I.toast(R.string.sending_file_failed);
        }

    }


    private void createTempDriveFileAndSend(Intent intent, String fileName) {


        Thread thread = new Thread(() -> {
            File file = Objects.requireNonNull(getActivity()).getCacheDir();
            File tempFile = new File(file.getAbsolutePath() + "/" + fileName);
            try {
                InputStream inputStream = getActivity().getContentResolver().openInputStream(Objects.requireNonNull(intent.getData()));
                FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
                byte[] buffer = new byte[1024];
                while (inputStream != null && inputStream.read(buffer) != -1) {
                    fileOutputStream.write(buffer);
                }
                fileOutputStream.flush();
                fileOutputStream.close();
                if (inputStream != null) inputStream.close();


            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


            Message message = new Message();
            Bundle bundle = new Bundle();
            bundle.putString("file_path", tempFile.getAbsolutePath());
            message.setData(bundle);
            handler.sendMessage(message);
        });
        thread.start();



    }

    private String getImageFilePath(String uriString) {
        if (uriString == null || uriString.equals("")) {
            return "";
        }

        Uri mUri = Uri.parse(uriString);
        String filePath = "";
        if ("content".equals(mUri.getScheme())) {
            Cursor cursor = getActivity().getContentResolver().query(mUri, new String[]{MediaStore.Images.ImageColumns.DATA}, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                filePath = cursor.getString(cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA));
                cursor.close();
            }
        } else {
            filePath = mUri.getPath();
        }
        return filePath;
    }











    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }


    private AndroidAuthSession buildSession() {
        AppKeyPair appKeyPair = new AppKeyPair(dropBoxAppKey, dropBoxAppSecret);
        AndroidAuthSession session = new AndroidAuthSession(appKeyPair);
        loadAuth(session);
        return session;
    }

    private void loadAuth(AndroidAuthSession session) {
        SharedPreferences prefs = getActivity().getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
        String key = prefs.getString(ACCESS_KEY_NAME, null);
        String secret = prefs.getString(ACCESS_SECRET_NAME, null);
        if (key == null || secret == null || key.length() == 0 || secret.length() == 0) return;

        if (key.equals("oauth2:")) {
            session.setOAuth2AccessToken(secret);
        } else {
            session.setAccessTokenPair(new AccessTokenPair(key, secret));
        }
    }

    private boolean isAppKeySetProperly() {

        if (dropBoxAppKey.startsWith("CHANGE") || dropBoxAppSecret.startsWith("CHANGE")) {
            Log.e("Pias", "Dropbox api key problem");
            return false;
        }

        Intent testIntent = new Intent(Intent.ACTION_VIEW);
        String scheme = "db-" + dropBoxAppKey;
        String uri = scheme + "://" + AuthActivity.AUTH_VERSION + "/test";
        testIntent.setData(Uri.parse(uri));
        PackageManager pm = getActivity().getPackageManager();
        if (0 == pm.queryIntentActivities(testIntent, 0).size()) {
            Log.e("Pias", "Manifest is not set up correctly");
            return false;
        }

        return true;
    }

    private void storeAuth(AndroidAuthSession session) {
        String oauth2AccessToken = session.getOAuth2AccessToken();
        if (oauth2AccessToken != null) {
            SharedPreferences prefs = getActivity().getSharedPreferences(ACCOUNT_PREFS_NAME, 0);
            SharedPreferences.Editor edit = prefs.edit();
            edit.putString(ACCESS_KEY_NAME, "oauth2:");
            edit.putString(ACCESS_SECRET_NAME, oauth2AccessToken);
            edit.commit();
            return;
        }
    }

    private String downloadDropBoxFile(DbxChooser.Result fileSelected) {// , String
        File dir = new File(getPath());
        File localFile;
        String filePath = "";
        if (!dir.exists())
            dir.mkdirs();
        localFile = new File(dir + "/" + fileSelected.getName());
        if (!localFile.exists()) {
            // localFile.createNewFile();
            // copyFileInLoacDevice(fileSelected, localFile);
//                filePath = localFile.getAbsolutePath();
        } else {
            showFileExitsDialog(fileSelected, localFile);
        }

        return filePath;
    }

    private String getPath() {
        String path;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            path = Environment.getExternalStorageDirectory().getAbsolutePath();
        } else if ((new File("/mnt/emmc")).exists()) {
            path = "/mnt/emmc";
        } else {
            path = Environment.getExternalStorageDirectory().getAbsolutePath();
        }
        return path + "/" + getString(R.string.app_name);
    }

    private void copyFileInLoacDevice(final DbxChooser.Result fileSelected, final File localFile) {
        final ProgressDialog pd = new ProgressDialog(getActivity());
        pd.setButton(DialogInterface.BUTTON_NEGATIVE, getString(R.string.cancel), (dialogInterface, i) -> pd.dismiss());
        pd.setMessage(getString(R.string.please_wait));
        pd.show();

        new Thread(() -> {
            try {
                FileOutputStream outputStream = new FileOutputStream(localFile);
                Log.e("pias", fileSelected.getName());
                DropboxAPI.DropboxFileInfo info = mApi.getFile(fileSelected.getName(), null, outputStream, null);
                if (pd.isShowing()) {
                    pd.dismiss();
                    Log.e("Pias", "File saved to " + localFile);
                    Message message = new Message();
                    Bundle bundle = new Bundle();
                    bundle.putString("file_path", localFile.getAbsolutePath());
                    message.setData(bundle);
                    handler.sendMessage(message);

                }

            } catch (DropboxException | IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void showFileExitsDialog(final DbxChooser.Result fileSelected, final File localFile) {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()));
        alertBuilder.setMessage("File already exists. Want to overwrite?");
        alertBuilder.setPositiveButton("Ok", (dialog, which) -> copyFileInLoacDevice(fileSelected, localFile));
        alertBuilder.setNegativeButton("Cancel", null);
        alertBuilder.create().show();
    }
}
