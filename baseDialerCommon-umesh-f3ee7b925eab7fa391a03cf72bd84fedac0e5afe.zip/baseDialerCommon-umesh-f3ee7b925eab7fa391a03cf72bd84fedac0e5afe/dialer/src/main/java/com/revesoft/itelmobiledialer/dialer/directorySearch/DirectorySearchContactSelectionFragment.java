package com.revesoft.itelmobiledialer.dialer.directorySearch;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.processor.contactsearch.ContactEntry;
import com.revesoft.itelmobiledialer.processor.contactsearch.SearchContactUtil;
import com.revesoft.itelmobiledialer.processor.directorySearch.DirectorySearchConstants;
import com.revesoft.itelmobiledialer.processor.directorySearch.DirectorySearchHook;
import com.revesoft.itelmobiledialer.processor.directorySearch.DirectorySearchModuleManager;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.NativeContactUtil;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta
 */

public class DirectorySearchContactSelectionFragment extends Fragment {
    public static final String TAG = "ContactsForInviteFriendsFragmentTag";
    public static final String KEY_CONTACT_TYPE = "KEY_CONTACT_TYPE";
    private static final String KEY_EXCLUTION_CONTACTS = "KEY_EXCEPTION_CONTACTS";
    private static final String KEY_IS_FOR_BLOCKING_LIST = "KEY_IS_FOR_BLOCKING_LIST";
    private static final int ADD_CONTACT_REQUEST_CODE = 1122;
    public String mCurFilter;

    public static String getTAG() {
        return TAG;
    }

    private static final int LOADER_ID = 9950589;
    RecyclerView rv;
    RecyclerView.LayoutManager layoutManager;

    public ContactAdapter adapter;
    Activity parentActivity;

    public enum ContactType {
        APP, NON_APP, ALL
    }


    ContactType contactType;
    boolean isForBlockingList = false;
    private static ArrayList<ContactEntry> searchResult = new ArrayList();
    ProgressDialog progressingDialog;
    public boolean isTextSizeAlertShown = false;


    public DirectorySearchContactSelectionFragment() {
    }

    private static Fragment fragment;

    public static Fragment newInstance(ContactType contactType) {
        if (fragment == null) {
            fragment = new DirectorySearchContactSelectionFragment();
            ((DirectorySearchContactSelectionFragment) fragment).isTextSizeAlertShown = false;

        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static Fragment newInstance(String s) {

        Log.d("Abhi", "Starting DirectorySearchNewFragment with searchText: " + s);
        if (fragment == null) {
            fragment = new DirectorySearchContactSelectionFragment();
            searchText = s;

        } else {
            searchText = s;
        }
        return fragment;
    }

    public static Fragment newInstance(ContactType contactType, String[] exceptionContactNumbers) {
        if (fragment == null) {
            fragment = new DirectorySearchContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        bundle.putStringArray(KEY_EXCLUTION_CONTACTS, exceptionContactNumbers);
        fragment.setArguments(bundle);
        return fragment;
    }

    String[] excludedContacts;
    int highLightColor;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Abhi", "OnCreate DirectorySearchNewFragment");

        if (getArguments() != null) {
            contactType = (ContactType) getArguments().getSerializable(KEY_CONTACT_TYPE);
            excludedContacts = getArguments().getStringArray(KEY_EXCLUTION_CONTACTS);
            isForBlockingList = getArguments().getBoolean(KEY_IS_FOR_BLOCKING_LIST);
            if (isForBlockingList) {
                excludedContacts = new String[CommonData.blockedNumber.size()];
                int index = 0;
                for (String blockedNumber : CommonData.blockedNumber) {
                    excludedContacts[index++] = blockedNumber;
                }

            }
        }

        setHasOptionsMenu(true);
        highLightColor = ContextCompat.getColor(getActivity(), R.color.appBlue);

        DirectorySearchModuleManager.getConfigurator()
                .withDirectorySearchDataHook(
                        new DirectorySearchHook() {
                            @Override
                            public void addResult(ArrayList<ContactEntry> contactEntries) {
                                DirectorySearchContactSelectionFragment.searchResult.addAll(contactEntries);
                                if (adapter != null) {
                                    adapter.notifyDataSetChanged();
                                }
                            }

                            @Override
                            public ArrayList<ContactEntry> getResult() {
                                return DirectorySearchContactSelectionFragment.searchResult;
                            }
                        }
                ).withIsEnabled(true)
                .configure();
    }

    @Override
    public void onPause() {
        super.onPause();
        searchText = "";
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mReceiver);

    }

    @Override
    public void onDestroy() {
        searchText = "";
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d("Abhi", "DirectorySearch OncreateView");
        View v = inflater.inflate(R.layout.contact_selection_layout, container, false);
        parentActivity = getActivity();
        rv = v.findViewById(R.id.rv);
        layoutManager = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(layoutManager);
        adapter = new ContactAdapter(getActivity());
        rv.setAdapter(adapter);

        v.setFocusableInTouchMode(true);
        v.requestFocus();
        v.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    getActivity().getSupportFragmentManager().popBackStackImmediate();
                    return true;
                }
                return false;
            }
        });
        v.setFocusableInTouchMode(true);
        v.requestFocus();
        v.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    getActivity().onBackPressed();
                    return true;
                }
                return false;
            }
        });

        progressingDialog = new ProgressDialog(getActivity());
        progressingDialog.setMessage(getString(R.string.please_wait));
//        searchResult.clear();
//        adapter.notifyDataSetChanged();
        return v;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @SuppressWarnings("unused")
    private void changeSearchIcon() {
        ImageView ivSearchIcon = searchView.findViewById(R.id.search_button);
        if (ivSearchIcon != null) {
            ivSearchIcon.setImageResource(R.drawable.ic_menu_search);
        }
    }

    public class ContactAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int ITEM_VIEW = 5000;
        private static final int EMPTY_VIEW = 6000;
        Cursor dataCursor = null;
        Context context;

        private ContactAdapter(Context context) {
            this.context = context;
        }

        protected void swapCursor(Cursor cursor) {
            dataCursor = cursor;
            notifyDataSetChanged();
            rv.smoothScrollToPosition(0);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v;
            if (viewType == EMPTY_VIEW) {
                v = LayoutInflater.from(parent.getContext()).inflate(R.layout.empty_list_layout, parent, false);
                return new ContactAdapter.EmptyViewHolder(v);
            } else if (viewType == ITEM_VIEW) {
                v = LayoutInflater.from(context).inflate(R.layout.directory_search_entry, parent, false);
                return new ContactAdapter.ContactViewHolder(v);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof ContactAdapter.EmptyViewHolder) {
                ContactAdapter.EmptyViewHolder vh = (ContactAdapter.EmptyViewHolder) holder;
                vh.tvEmptyTextDescription.setText(getText(R.string.noContactFound));
                vh.ivEmptyListIcon.setImageResource(R.drawable.empty_list_app_icon);
            } else if (holder instanceof ContactAdapter.ContactViewHolder) {
                ContactAdapter.ContactViewHolder vh = (ContactAdapter.ContactViewHolder) holder;
                vh.bindView();
            }
        }

        @Override
        public int getItemCount() {
            try {
                if (searchResult == null) {
                    return 1;
                }

                if (searchResult.size() == 0) {
                    return 1;
                }

                return searchResult.size();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }

        @Override
        public int getItemViewType(int position) {

            if (searchResult == null) {
                return EMPTY_VIEW;
            } else if (searchResult.size() == 0) {
                return EMPTY_VIEW;
            }
            return ITEM_VIEW;


        }

        class EmptyViewHolder extends RecyclerView.ViewHolder {
            TextView tvEmptyTextDescription;
            ImageView ivEmptyListIcon;

            public EmptyViewHolder(View itemView) {
                super(itemView);
                tvEmptyTextDescription = itemView.findViewById(R.id.tvEmptyListDescription);
                ivEmptyListIcon = itemView.findViewById(R.id.ivEmptyListIcon);
            }
        }

        class ContactViewHolder extends RecyclerView.ViewHolder {
            LinearLayout llRow;
            ImageView ivContactImage;
            TextView tvName;
            TextView tvNumber;
            ImageView ivAddNewContact;

            private ContactViewHolder(View itemView) {
                super(itemView);
                llRow = itemView.findViewById(R.id.ll_row);
                ivContactImage = itemView.findViewById(R.id.ivPhoneContactImage);
                tvName = itemView.findViewById(R.id.tvNameSalamDirectorySearch);
                tvNumber = itemView.findViewById(R.id.tvSearchText);
                ivAddNewContact = itemView.findViewById(R.id.ivAddToNewContact);
            }

            public void bindView() {
                if (searchResult == null) {
                    return;
                }
                try {
                    final ContactEntry contact = searchResult.get(getAdapterPosition());

                    final String name = contact.name;
                    final String subscribed_number = contact.phoneNumber;
                    final String contact_number = contact.phoneNumber;

                    Log.d("Abhi", name + " " + contact_number);
                    if (name == null || name.length() == 0) {
                        tvNumber.setText(R.string.unknown);
                        tvName.setText(contact_number);
                    } else {
                        tvNumber.setText(contact_number);
                        tvName.setText(name);
                    }


                    String profileImageLoadingPath = ProfilePictureDataProvider.getProfilePicturePath(getActivity(), subscribed_number);
                    ImageUtil.setImageButTextImageOnException(getActivity(), profileImageLoadingPath, ivContactImage, this.tvName.getText().toString());

                    if (CommonData.contactNumberToContactLookUpKey.containsKey(contact_number)) {
                        ivAddNewContact.setVisibility(View.GONE);
                    } else {
                        ivAddNewContact.setVisibility(View.VISIBLE);
                    }

                    ivAddNewContact.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            NativeContactUtil.saveContactFromDirectory(getActivity(), contact_number, name);
                        }
                    });

                    llRow.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (CommonData.contactNumberToContactLookUpKey.containsKey(contact.phoneNumber)) {
                                String lookupKey = CommonData.contactNumberToContactLookUpKey.get(contact.phoneNumber);
                                Intent intent = new Intent(getActivity(), ContactDetailsActivity.class);
                                intent.putExtra(Constants.Contact.KEY_LOOKUP_KEY, lookupKey);
                                intent.putExtra(Constants.Contact.KEY_NUMBER, contact.phoneNumber);
                                startActivity(intent);
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("ContactsFragment", "Error: " + e.getMessage());
                }

            }

        }
    }

    public SearchView searchView;
    public static String searchText = "";

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        Log.d("Abhi", "Creating option menu");
        inflater.inflate(R.menu.menu_invite_friends, menu);
        final MenuItem searchItem = menu.findItem(R.id.app_bar_search_contacts);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
//        I.log("search item null : "+ (searchItem ==null));
//        I.log("search view null : "+ (searchView ==null));
        if (searchView != null) {
//            changeSearchIcon();
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
            searchView.setIconifiedByDefault(false);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    onQueryTextChangeNew(newText);
//                    if (TextUtils.isEmpty(newText)) {
//                        searchText = "";
//                    } else {
//                        searchText = newText;
//                    }
//                    adapter.notifyDataSetChanged();
//                    getActivity().getSupportLoaderManager().restartLoader(LOADER_ID, null, DirectorySearchContactSelectionFragment.this);
                    return true;
                }
            });
        }
        searchView.setQuery(searchText, true);
//        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onResume() {
        LocalBroadcastManager.getInstance(getActivity())
                .registerReceiver(mReceiver, new IntentFilter(DirectorySearchConstants.DIRECTORY_SEARCH_INTENT_FILTER));
        if (adapter != null) {
            Log.d("Abhi", "Adapter reloading");

            adapter.notifyDataSetChanged();
        } else {
            Log.d("Abhi", "Adapter null");
        }
        super.onResume();
    }


    private void sendDirectorySearchRequest(String query) {

//        new Handler(Looper.getMainLooper()).post(new Runnable() {
//            @Override
//            public void run() {
//                if(!progressingDialog.isShowing())
//                progressingDialog.show();
//            }
//        });
        if (query.length() < 3) {
            Log.d("Abhi", "search request cancelled length: " + query.length());
            return;
        }

        Log.d("Abhi", "sending search: " + query);
        Intent intent = new Intent(Constants.GET_CONTACT_SEARCH_LIST_ACTION);
        intent.putExtra(Constants.CONTACT_SEARCH_QUERY_NAME, query);
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
        DirectorySearchContactSelectionFragment.searchResult.clear();
    }

    BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle extras = intent.getExtras();
            Log.d("Abhi", "got search: response");
//            new Handler(Looper.getMainLooper()).post(new Runnable() {
//                @Override
//                public void run() {
//                    if(progressingDialog.isShowing())
//                        progressingDialog.dismiss();
//                }
//            });

            if (extras != null) {
                if (extras.containsKey(DirectorySearchConstants.UPDATE_SEARCH_RESULT)
                        && !TextUtils.isEmpty(mCurFilter)) {
                    SearchContactUtil searchUtil = extras.getParcelable(DirectorySearchConstants.UPDATE_SEARCH_RESULT);
                    if (searchUtil != null && searchUtil.mSearchContactEntries.size() > 0) {
                        searchResult.clear();
                        searchResult.addAll(searchUtil.mSearchContactEntries);
                    }
                }
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
            }
        }
    };
    Timer timer = null;

    public boolean onQueryTextChangeNew(String newText) {
        String newFilter = !TextUtils.isEmpty(newText) ? newText : null;
        if (newFilter == null) {
            searchResult.clear();
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
            return true;
        }
        if (mCurFilter != null && mCurFilter.equals(newFilter)) {
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
            return true;
        }
        mCurFilter = newFilter;
        searchText = newText;

        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                sendDirectorySearchRequest(mCurFilter);
            }
        }, 1500);
        return true;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_CONTACT_REQUEST_CODE && adapter != null) {
            Log.d("Abhi", "Directory SearchContactSelectionFragment");
            adapter.notifyDataSetChanged();
        }
    }
}
