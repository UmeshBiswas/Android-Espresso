package com.revesoft.itelmobiledialer.chat.stickeroid;

import android.content.Context;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.revesoft.itelmobiledialer.util.TaggedLogger;

import org.json.JSONArray;

import java.util.ArrayList;

import androidx.annotation.NonNull;

/**
 * @author Ifta on 11/5/2017.
 */

public class StickeroidDataLoader {
    private static final TaggedLogger logger = new TaggedLogger("Stickroid");
    private static StickeroidDataLoader stickeroidDataLoader = null;
    private RequestQueue queue;

    public static StickeroidDataLoader getAccess(Context context) {
        if (stickeroidDataLoader == null) {
            stickeroidDataLoader = new StickeroidDataLoader(context);
        }
        return stickeroidDataLoader;
    }

    private StickeroidDataLoader(Context context) {
        queue = Volley.newRequestQueue(context);
    }

    public void getStickers(@NonNull String searchKey, final StickerLoadListener stickerLoadListener) {
        final ArrayList<Sticker> stickers = new ArrayList<>();
        String url = Stickeroid.getBotUrl(searchKey);
        logger.log(url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray results = new JSONArray(response);
                            for (int i = 0; i < results.length(); i++) {
                                Sticker sticker = new Sticker(results.getJSONObject(i));
                                if (sticker.isAcceptable) {
                                    stickers.add(sticker);
//                                    logger.log(sticker.toString());
                                }
                            }
                            stickerLoadListener.onStickerLoad(stickers);
                        } catch (Exception e) {
                            logger.error("Exception");
                            logger.error(e);
                            e.printStackTrace();
                            stickerLoadListener.onStickerLoadError(e.getLocalizedMessage());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if(error == null) {
                    try {
                        String responseBody = new String(error.networkResponse.data, "utf-8");
                        JSONArray results = new JSONArray(responseBody);
                        for (int i = 0; i < results.length(); i++) {
                            Sticker sticker = new Sticker(results.getJSONObject(i));
                            if (sticker.isAcceptable) {
                                stickers.add(sticker);
                            }
                            stickerLoadListener.onStickerLoad(stickers);
                        }
                        logger.error(responseBody);
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(e.getLocalizedMessage());
                    }
                }else {
                    logger.error("onErrorResponse");
                    logger.error(error.getLocalizedMessage());
                    stickerLoadListener.onStickerLoadError(error.getLocalizedMessage());
                }
            }
        });
        queue.add(stringRequest);
    }
}
