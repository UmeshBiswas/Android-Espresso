package com.revesoft.itelmobiledialer.chat.preview;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatConstants;
import com.revesoft.itelmobiledialer.chat.tenor.tools.loaders.GifLoader;
import com.revesoft.itelmobiledialer.chat.tenor.tools.params.GlideTaskParams;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import androidx.annotation.Nullable;

/**
 * @author Ifta on 12/21/2017.
 */

public class GifAndStickerPreviewActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gif_preview_acivity_layout);
        ImageView ivPreview = (ImageView) findViewById(R.id.ivPreview);
        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        if (getIntent().hasExtra(ChatConstants.KEY_GIF_URL)) {
            String gifUrl = getIntent().getStringExtra(ChatConstants.KEY_GIF_URL);
            if (TextUtils.isEmpty(gifUrl)) {
                finish();
            } else {
                GlideTaskParams<ImageView> params = new GlideTaskParams<>(ivPreview, gifUrl);
                GifLoader.loadGif(AppContext.getAccess().getContext(), params);
            }
        } else if (getIntent().hasExtra(ChatConstants.KEY_STICKER_URL)) {
            String stickerUrl = getIntent().getStringExtra(ChatConstants.KEY_STICKER_URL);
            if (TextUtils.isEmpty(stickerUrl)) {
                finish();
            } else {
                Glide.with(AppContext.getAccess().getContext()).load(stickerUrl)
                        .asBitmap()
                        .placeholder(R.drawable.loader_animation)
                        .crossFade()
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .into(ivPreview);
            }
        }
    }
}
