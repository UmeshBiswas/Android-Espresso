package com.revesoft.itelmobiledialer.dialer;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.PictureInPictureParams;
import android.app.RemoteAction;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Rational;
import android.view.Display;
import android.view.GestureDetector;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.revesoft.itelmobiledialer.apprtc.AppRTCAudioManager;
import com.revesoft.itelmobiledialer.apprtc.ProxyVideoSink;
import com.revesoft.itelmobiledialer.apprtc.SignalingParameters;
import com.revesoft.itelmobiledialer.apprtc.videocall.ICECandidateUtilVideoCall;
import com.revesoft.itelmobiledialer.apprtc.videocall.PeerConnectionClientVideoCall;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickerActivity;
import com.revesoft.itelmobiledialer.contact.picker.ContactSelectiontype;
import com.revesoft.itelmobiledialer.customview.NumberView;
import com.revesoft.itelmobiledialer.customview.TouchListenerAudio;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.media.MediaDataRecv;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.notification.custom_notification.IncomingCallNotification;
import com.revesoft.itelmobiledialer.notification.custom_notification.RunningCallNotification;
import com.revesoft.itelmobiledialer.phonebook.ContactSelectionActivity;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.signalling.call.CallManager;
import com.revesoft.itelmobiledialer.signalling.call.CallParameters;
import com.revesoft.itelmobiledialer.signalling.data.CallState;
import com.revesoft.itelmobiledialer.signalling.sipUtil.ApplicationState;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.CallUtil;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.Country;
import com.revesoft.itelmobiledialer.util.CountryInfoProvider;
import com.revesoft.itelmobiledialer.util.DTMFTones;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.video.VideoParameters;
import com.revesoft.material.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.EglBase;
import org.webrtc.FileVideoCapturer;
import org.webrtc.IceCandidate;
import org.webrtc.Logging;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RendererCommon;
import org.webrtc.ScreenCapturerAndroid;
import org.webrtc.SessionDescription;
import org.webrtc.StatsReport;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoFileRenderer;
import org.webrtc.VideoSink;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import androidx.core.view.GestureDetectorCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static android.hardware.Sensor.TYPE_PROXIMITY;
import static android.hardware.SensorManager.SENSOR_DELAY_NORMAL;
import static android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP;
import static android.os.PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK;
import static android.os.PowerManager.SCREEN_DIM_WAKE_LOCK;
import static com.revesoft.itelmobiledialer.signalling.call.CallConstants.CallTypes.CALLTYPE_VIDEO;
import static com.revesoft.itelmobiledialer.util.Constants.BROADCAST_MESSAGE_CALLID;
import static com.revesoft.itelmobiledialer.util.Constants.BROADCAST_MESSAGE_CONFERENCE_STARTED;
import static com.revesoft.itelmobiledialer.util.Constants.BROADCAST_MESSAGE_DISPLAY_DURATION_CALLID;

@SuppressLint("NewApi")
public class CallFrameGUIActivityAppRTC extends BaseActivity implements SensorEventListener, PeerConnectionClientVideoCall.PeerConnectionEvents {
    public static boolean isOnPause;


    private final String INTENT_KEY_FOR_END_CALL_FROM_PIP = "intent_from_end_call_from_pip";
    private final String PIP_END_CALL_BROADCAST_FILTER = "pip_endcall_broadcast_filter";

    private Handler handler;
    private ImageView muteButton;
    private ImageView speakerButton;
    private ImageView recordButton;
    private ImageView callTransferButton;
    private boolean muteFlag = false;
    private boolean speakerFlag = false;
    private boolean recordFlag = false;
    private boolean holdFlag = false;
    private boolean callTransferFlag = false;
    private boolean fullScreen = true;
    private SharedPreferences preferences;
    private TextView enteredNumber;
    private TextView calledCountryISO;
    private TextView packageTView;
    private LinearLayout endCallButtonSpace;
    private View acceptDeclineButtonSpace;
    private LinearLayout secondLineButtons;
    private RelativeLayout allButtonHolder, major_buttons;
    FloatingActionButton cameraSwitchButtonContainer;
    LinearLayout videoCallControlButtons;
    private LinearLayout callerNameHolder;
    private ImageView ivChat;
    private TextView tvMicOnOff;
    private TextView tvRecord;
    private TextView tvCallInfoText;
    WakeLock screenLock, proximityLock;
    private SensorManager sensorManager;
    private Sensor proximitySensor;
    private ImageView picture;
    private TextView linkQuality;
    private AudioManager audioManager = null;
    DTMFTones tones;
    private String number = "";
    private final boolean DEBUG = false;
    BluetoothAdapter bluetoothAdapter = null;
    private boolean bluetoothSettingsFlag = false;
    private BluetoothProfile.ServiceListener mProfileListener;
    private BluetoothHeadset mBluetoothHeadset;
    private int connectedHeadsetCount = 0;
    private BluetoothDevice headsetDevice = null;
    AudioManager localAudioManager;
    Timer timer;
    float scale;
    public static volatile boolean SPEAKER_FLAG;
    public static boolean isActivityActive = false;
    private boolean returnFromCrash = false;
    private boolean isIncomingCall = false;
    static final int BLUETOOTH_NOT_CONNECTED = 0;
    static final int A2DP_CONNECTED = 1;
    static final int SCO_CONNECTED = 2;
    int blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
    private int CALL_TRANSFER_REQUEST = 123;
    private static final String TAG = "CallRTCClient";
    private static final String TAG_NEW = "CallRTCClient";
    String identity;
    String callID;
    ImageView audioVideoSwitchButton;
    LinearLayout audioVideoSwitchButtonContainer;
    HeadSetReceiver headsetReceiver;
    public static String remoteSDP = "";
    public static String localFinalSDP = "";
    public static boolean caller = true;
    public static boolean callAccepted = false;
    /* Peer connection statistics callback period in ms. */
    private static final int STAT_CALLBACK_PERIOD = 1000;
    private boolean wasSpeakerOnBeforeHeadsetPluggedIn = false;

    private boolean locationFlag = false;

    private boolean dialogShown = false;
    private static final int CAPTURE_PERMISSION_REQUEST_CODE = 1;


    boolean callDisconnected = false;
    TouchListenerAudio touchListenerAudio;
    public String previewSizeInString = "SMALL"; // SMALL or MEDIUM or FULL
    private boolean isVideoEnabled;

    private LinearLayout callInfoContainer;
    public boolean isOtherSendingVideo = false;


    private final HashMap<String, CallInfoHolder> callInfoMap = new HashMap<>();
    Bitmap profilePicture;
    BroadcastReceiver pipBradCastReceiver;

    private void processCandidateList() {
        if (remoteCandidateList.size() > 0) {
            for (String candidate : remoteCandidateList) {
                Log.w(TAG, "Failed EXTRA_CANDIDATE: " + candidate);
                if (candidate.startsWith("sdp=")) {
                    processMessage(candidate);
                } else if (candidate.startsWith("removed=")) {

                } else if (candidate.contains("remove-candidates")) {
                    setRemoteICECandidateForRemoving(candidate);
                } else {
                    setRemoteICECandidate(candidate);
                }
            }
            remoteCandidateList.clear();
        }
    }

    private void initSurfaces() {
        bottomViewGroupContainer = findViewById(R.id.bottomViewGroup);
        topViewGroupContainer = findViewById(R.id.topViewGroupCard);
        pipRenderer = findViewById(R.id.pip_video_view);
        fullscreenRenderer = findViewById(R.id.fullscreen_video_view);
        try {
            pipRenderer.setZOrderMediaOverlay(true);
        } catch (Exception e) {
            e.printStackTrace();
        }





        /*----------------------------Animation slide down and up------------------------------*/
        final RelativeLayout rl = findViewById(R.id.rl_parent);
        touchListenerAudio = new TouchListenerAudio(this, this, pipRenderer, rl);
        pipRenderer.setOnTouchListener(touchListenerAudio);
        gestureDetector = new GestureDetectorCompat(this,
                new MySingleTapGestureListener());
        pipRenderer.setVisibility(View.VISIBLE);
        fullscreenRenderer.setVisibility(View.VISIBLE);
    }

    private void initializeVideo() {
        caller = getIntent().getBooleanExtra(EXTRA_CALLERID, true);
        identity = getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_IDENTITY);
        Log.e(TAG_NEW, "onCreate: " + caller);

        localFinalSDP = "";
        Init();

        iceConnected = false;
        signalingParameters = null;

//		// Show/hide call control fragment on view click.
//		View.OnClickListener listener = new View.OnClickListener() {
//			@Override
//			public void onClick(View view) {
//				toggleCallControlFragmentVisibility();
//			}
//		};

        // Swap feeds on pip view click.
        pipRenderer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (callAccepted) {
                    setSwappedFeeds(!isSwappedFeeds);
                }
            }
        });

//		fullscreenRenderer.setOnClickListener(listener);
        remoteSinks.add(remoteProxyRenderer);

        // Create video renderer.
        rootEglBase = EglBase.create();
        pipRenderer.init(rootEglBase.getEglBaseContext(), null);
        pipRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);

        fullscreenRenderer.init(rootEglBase.getEglBaseContext(), null);
        fullscreenRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL);

        pipRenderer.setZOrderMediaOverlay(true);
        pipRenderer.setEnableHardwareScaler(true /* enabled */);
        fullscreenRenderer.setEnableHardwareScaler(true);
        // Start with local feed in fullscreen and swap it to the pip when the call is connected.
        setSwappedFeeds(true /* isSwappedFeeds */);

        // Check for mandatory permissions.
        for (String permission : MANDATORY_PERMISSIONS) {
            if (checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permission " + permission + " is not granted");
                setResult(RESULT_CANCELED);
                finish();
                return;
            }
        }

        boolean loopback = infoIntent.getBooleanExtra(EXTRA_LOOPBACK, false);
        boolean tracing = infoIntent.getBooleanExtra(EXTRA_TRACING, false);

        int videoWidth = infoIntent.getIntExtra(EXTRA_VIDEO_WIDTH, 0);
        int videoHeight = infoIntent.getIntExtra(EXTRA_VIDEO_HEIGHT, 0);

        screenCaptureEnabled = infoIntent.getBooleanExtra(EXTRA_SCREENCAPTURE, false);

        // If capturing format is not specified for screencapture, use screen resolution.
        if (screenCaptureEnabled && videoWidth == 0 && videoHeight == 0) {
            DisplayMetrics displayMetrics = getDisplayMetrics();
            videoWidth = displayMetrics.widthPixels;
            videoHeight = displayMetrics.heightPixels;
        }
        PeerConnectionClientVideoCall.DataChannelParameters dataChannelParameters = null;
        if (infoIntent.getBooleanExtra(EXTRA_DATA_CHANNEL_ENABLED, false)) {
            dataChannelParameters = new PeerConnectionClientVideoCall.DataChannelParameters(infoIntent.getBooleanExtra(EXTRA_ORDERED, true),
                    infoIntent.getIntExtra(EXTRA_MAX_RETRANSMITS_MS, -1),
                    infoIntent.getIntExtra(EXTRA_MAX_RETRANSMITS, -1), infoIntent.getStringExtra(EXTRA_PROTOCOL),
                    infoIntent.getBooleanExtra(EXTRA_NEGOTIATED, false), infoIntent.getIntExtra(EXTRA_ID, -1));
        }

        //peer connection parameter settings....
        peerConnectionParameters =
                new PeerConnectionClientVideoCall.PeerConnectionParameters(infoIntent.getBooleanExtra(EXTRA_VIDEO_CALL, true), loopback,
                        tracing, videoWidth, videoHeight, infoIntent.getIntExtra(EXTRA_VIDEO_FPS, 0),
                        infoIntent.getIntExtra(EXTRA_VIDEO_BITRATE, 0), infoIntent.getStringExtra(EXTRA_VIDEOCODEC),
                        infoIntent.getBooleanExtra(EXTRA_HWCODEC_ENABLED, true),
                        infoIntent.getBooleanExtra(EXTRA_FLEXFEC_ENABLED, false),
                        infoIntent.getIntExtra(EXTRA_AUDIO_BITRATE, 0), infoIntent.getStringExtra(EXTRA_AUDIOCODEC),
                        infoIntent.getBooleanExtra(EXTRA_NOAUDIOPROCESSING_ENABLED, false),
                        infoIntent.getBooleanExtra(EXTRA_AECDUMP_ENABLED, false),
//                        infoIntent.getBooleanExtra(EXTRA_SAVE_INPUT_AUDIO_TO_FILE_ENABLED, false),
                        false,
                        infoIntent.getBooleanExtra(EXTRA_OPENSLES_ENABLED, false),
                        infoIntent.getBooleanExtra(EXTRA_DISABLE_BUILT_IN_AEC, false),
                        infoIntent.getBooleanExtra(EXTRA_DISABLE_BUILT_IN_AGC, false),
                        infoIntent.getBooleanExtra(EXTRA_DISABLE_BUILT_IN_NS, false),
                        infoIntent.getBooleanExtra(EXTRA_DISABLE_WEBRTC_AGC_AND_HPF, false),
//                        infoIntent.getBooleanExtra(EXTRA_ENABLE_RTCEVENTLOG, false),
                        false,
//                        infoIntent.getBooleanExtra(EXTRA_USE_LEGACY_AUDIO_DEVICE, false), dataChannelParameters);
                        false, dataChannelParameters);

        Log.d(TAG, "VIDEO_FILE: '" + infoIntent.getStringExtra(EXTRA_VIDEO_FILE_AS_CAMERA) + "'");

        peerConnectionClientVideoCall = new PeerConnectionClientVideoCall(getApplicationContext(), rootEglBase, peerConnectionParameters, this);
        PeerConnectionFactory.Options options = new PeerConnectionFactory.Options();
        if (loopback) {
            options.networkIgnoreMask = 0;
        }
        peerConnectionClientVideoCall.createPeerConnectionFactory(options);

        if (screenCaptureEnabled) {
            startScreenCapture();
        }

        if (caller) gatherICEInfo(null);
        else processMessage(remoteSDP);

        if (ifWiredHeadsetOn())
            speakerAction(false);
        else
            speakerAction(true);
    }

    private void checkIfFromDialog() {
        boolean bb = getIntent().getBooleanExtra("fromDialogue", false);
        if (bb)
            accept();
    }

    private boolean isMeSendingVideo = false;
    private LinearLayout holdButton;

    private void registerReceivers() {
        LocalBroadcastManager.getInstance(this).registerReceiver(
                mMessageReceiver,
                new IntentFilter(Constants.INTENT_FROM_DIALER));
        registerBluetoothConnectionStateReceiver();
        IntentFilter filter = new IntentFilter(Intent.ACTION_HEADSET_PLUG);
        registerReceiver(headsetReceiver, filter);
        readyToReceiveBroadcast = true;
    }

    private void initObjects() {
//        MissedCallNotification.cancelAll();

        tones = new DTMFTones();
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        proximitySensor = sensorManager.getDefaultSensor(TYPE_PROXIMITY);
        headsetReceiver = new HeadSetReceiver();
    }

    private void checkIfReturnFromCrash(Bundle bundle) {
        if (bundle != null) {
            if (bundle.containsKey(IncomingCallNotification.INTENT_TYPE_INCOMING_CALL) ||
                    bundle.containsKey(RunningCallNotification.INTENT_TYPE_RUNNING_CALL)) {
                returnFromCrash = true;
                finish();
                return;
            }
        }
    }

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Read extra data included in the Intent
            String[] message = intent.getStringArrayExtra(BROADCAST_MESSAGE_CONFERENCE_STARTED);
            if (message != null) {
                if (message.length > 0) {
                    String callID = intent.getStringExtra(BROADCAST_MESSAGE_CALLID);
                    prepareCallInfoHolderForConference(callID, message);
                }
                return;
            }

            message = intent.getStringArrayExtra(BROADCAST_MESSAGE_DISPLAY_DURATION_CALLID);
            if (message != null) {
                String callID = message[0];
//				if (CallManager.getCallType(callID) == CALLTYPE_AUDIO && (callFrameContainer.getVisibility() == View.INVISIBLE || callFrameContainer.getVisibility() == View.GONE)) {
//				    animLogger.log("2839");
//					callFrameContainer.setVisibility(View.VISIBLE);
//				}
                CallInfoHolder holder = callInfoMap.get(callID);
                if (holder != null) {
                    if (!message[1].equals(holder.tvCallStatus.getText().toString())) {
                        holder.tvCallStatus.setText(message[1]);
                    }
                }
                allButtonHolder.setVisibility(View.VISIBLE);
                if (!shouldHideViews()) {
                    bottomViewGroupContainer.setVisibility(View.VISIBLE);
                    topViewGroupContainer.setVisibility(View.VISIBLE);
                }
                return;
            }

            message = intent.getStringArrayExtra(Constants.BROADCAST_MESSAGE_DISPLAY_STATUS_CALLID);
            if (message != null) {
                String callID = message[0];
                CallInfoHolder holder = callInfoMap.get(callID);
                if (holder != null) {
                    if (!message[1].equals(holder.tvCallStatus.getText().toString())) {
                        holder.tvCallStatus.setText(message[1]);
                    }
                } else {
                    prepareCallInfoHolder(callID);
                    holder = callInfoMap.get(callID);
                    if (holder != null && !message[1].equals(holder.tvCallStatus.getText().toString())) {
                        holder.tvCallStatus.setText(message[1]);
                    }
                }
                if (!endCallInitiated) {

//                    callTimer.setText(message);
                } else if (message[1].equalsIgnoreCase(getString(R.string.call_end))) {
//                    endActivity();
                    endCall(message[1]);
                }

                if (message[1].equalsIgnoreCase(getString(R.string.connected))) {
                    callConnected();
                    outgoingGUISetup();
                    showRunningCallNotification(number);
                    MediaDataRecv.resetDataReceivedSoFar();
                    audioVideoSwitchButton.setEnabled(true);
                    audioVideoSwitchButtonContainer.setEnabled(true);

                    if (isIncomingCall) {
                        callTransferFlag = true;
                        callTransferButton.setAlpha((float) 1.0);
                        callTransferButton.setEnabled(true);
                        Log.d(TAG, "CallFrameGUIActivityAppRTC isIncomingCall");
                    }
                    isCallProgressingOrConnected = true;
                    isConnectedCall = true;
                    if (!localAudioManager.isBluetoothA2dpOn()) {
                        Log.d("BluetoothTest", "Checking if isBluetoothScoRequestedToSetOn: "
                                + DialerService.isBluetoothScoRequestedToSetOn);
                        if (isIncomingCall &&
                                Util.isBluetoothHeadsetConnected() &&
                                !DialerService.isBluetoothScoRequestedToSetOn) {
                            if (!localAudioManager.isBluetoothScoOn()) {
                                localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                                localAudioManager.setBluetoothScoOn(true);
                                localAudioManager.startBluetoothSco();
                                DialerService.isBluetoothScoRequestedToSetOn = true;
                                blueToothConnectionMode = SCO_CONNECTED;
                                Log.e("BluetoothTest", "CallFrameGUI Activity starting BlueToothSco " +
                                        "after incoming call connected");
                            }


                        }
                    } else {

                        if (localAudioManager.getMode() != AudioManager.STREAM_VOICE_CALL) {
                            Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC: Call Connected: " +
                                    "BluetoothA2DP connected: AudioMode Set: STREAM_VOICE_CALL "
                            );
                            localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                        }
                        blueToothConnectionMode = A2DP_CONNECTED;
                    }
//                    tvCallStatus.setText(message);
//                    callTimer.setText("");
//                    callTimer.setVisibility(View.GONE);
                    allButtonHolder.setVisibility(View.GONE);
                    callConnected = true;
                    callStartTime = System.currentTimeMillis();
                }

                if (message[1].equalsIgnoreCase(getString(R.string.call_progressing))) {
                    isCallProgressingOrConnected = true;
//                    tvCallStatus.setText(message);
//                    callTimer.setText("");
//                    callTimer.setVisibility(View.GONE);
                    if (!wasCallInfoEverGreaterThanOne)
                        allButtonHolder.setVisibility(View.GONE);
//                    findViewById(R.id.callOptionsInactive).setVisibility(View.GONE);
//                    findViewById(R.id.callOptionsActive).setVisibility(View.VISIBLE);
                }
                return;
            }

            String[] messageArr = intent.getStringArrayExtra(Constants.BROADCAST_MESSAGE_SEND_CANDIDATE_CALLID);
            if (messageArr != null) {
                for (String candidate : localCandidateList) {
                    CallUtil.sendCandidateInfoBroadcast(CallFrameGUIActivityAppRTC.this, number, callID, candidate);
                    Log.i(TAG, "Sending ice candidate from progress: " + candidate);
                }
                localCandidateList.clear();
            }

            String msg = intent.getStringExtra(Constants.BROADCAST_MESSAGE_UPDATE_NUMBER);
            if (msg != null) {
                try {
                    number = msg;
                    String name = ContactEngine.getContactNamefromNumber(CallFrameGUIActivityAppRTC.this, number);
                    if (name == null) {
                        name = number;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return;
            }

            msg = intent.getStringExtra(Constants.BROADCAST_MESSAGE_VIDEO_STATUS_NUMBER);
            if (msg != null) {
                try {
                    int videoStatus = intent.getIntExtra(Constants.BROADCAST_MESSAGE_VIDEO_STATUS, 0);
                    String callID = intent.getStringExtra(Constants.BROADCAST_MESSAGE_CALLID);
//					if (SIPProvider.isVideoCall(callID)) {
                    isOtherSendingVideo = videoStatus == 1;
                    if (!isOtherSendingVideo) {
                        I.toast("Video is paused at other end");
                    }
//                    switchVideoPlayerStatus(videoStatus == 1);
                    handleAudioVideoSwitching();
//					}
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return;
            }

            msg = intent.getStringExtra(Constants.BROADCAST_MESSAGE_FINISH);
            if (msg != null) {
                endActivity();
                return;
            }

            msg = intent.getStringExtra(Constants.BROADCAST_MESSAGE_CALL_FINISH_REMOVE_VIEW);
            if (msg != null) {
                removeCallInfoHolder(msg);
                return;
            }

            msg = intent.getStringExtra(Constants.BROADCAST_MESSAGE_STOP_DIALOGUE);
            if (msg != null) {
                endActivity();
                return;
            }

            Bundle extras = intent.getExtras();
            if (extras != null) {
                if (extras.containsKey(EXTRA_SDP)) {
                    String s = intent.getStringExtra(EXTRA_SDP);
                    Log.e(TAG, "EXTRA_SDP: " + s);
                    processMessage(s);
                    return;
                }
                if (extras.containsKey(EXTRA_CANDIDATE)) {
                    String candidate = intent.getStringExtra(EXTRA_CANDIDATE);
                    Log.i(TAG, "EXTRA_CANDIDATE: " + candidate);
                    if (candidate.startsWith("sdp=")) {
                        processMessage(candidate);
                    } else if (candidate.startsWith("removed=")) {

                    } else if (candidate.contains("remove-candidates")) {
                        setRemoteICECandidateForRemoving(candidate);
                    } else {
                        setRemoteICECandidate(candidate);
                    }
                    return;
                }
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("AppRTC", "CallFrameGUIActivityAppRTC onCreate");
        Bundle bundle = getIntent().getExtras();
        checkIfReturnFromCrash(bundle);
        setContentView(R.layout.activity_call_frame_guiapp_rtc);


//        findViewById(R.id.video_call_control_buttons).setVisibility(View.INVISIBLE);
//

        SPEAKER_FLAG = false;
        wasSpeakerOnBeforeHeadsetPluggedIn = SPEAKER_FLAG;
        isActivityActive = true;
        preferences = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
        String type = this.getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_FROM_DIALER);
        callID = this.getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_CALLID);
        number = this.getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_NUMBER);
        initViews();
        initObjects();
        registerReceivers();
        setWakeLock();
        checkIfFromDialog();
        acquireLocksInCall();
        endCallInitiated = false;
        handleBluetooth();
        initSurfaces();
        initializeVideo();

        if (videoCall) {
//            isMeSendingVideo=true;
            findViewById(R.id.contact_image_holder).setVisibility(View.GONE);
            picture.setVisibility(View.GONE);
            pipRenderer.setVisibility(View.VISIBLE);
            fullscreenRenderer.setVisibility(View.VISIBLE);
            initAnimations();
            startStopSpeaker();
            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
            allButtonHolder.setVisibility(View.GONE);
            major_buttons.setVisibility(View.GONE);
            videoCallControlButtons.setVisibility(View.VISIBLE);
            audioVideoSwitchButtonContainer.setEnabled(true);
            isVideoEnabled = true;
            if (ifWiredHeadsetOn()) {
                speakerFlag = false;
                speakerAction(speakerFlag);
                speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
                wasSpeakerOnBeforeHeadsetPluggedIn = false;
            } else {
                speakerFlag = true;
                speakerAction(speakerFlag);
                speakerButton.setImageResource(R.drawable.ic_call_window_speaker_active);
                wasSpeakerOnBeforeHeadsetPluggedIn = true;
            }
        } else {
            pipRenderer.setVisibility(View.GONE);
            fullscreenRenderer.setVisibility(View.GONE);
            picture.setVisibility(View.VISIBLE);
            holdVideoAction(true);
            audioVideoSwitchButtonContainer.setEnabled(false);
            startStopSpeaker();
            isVideoEnabled = false;
            cameraSwitchButtonContainer.setVisibility(View.GONE);
            videoCallControlButtons.setVisibility(View.GONE);
        }
        pipRenderer.setZOrderMediaOverlay(true);
        fullscreenRenderer.setZOrderMediaOverlay(false);
        processCandidateList();
        if (!isIncomingCall && videoCall)
            showHideButtonOptions();
        if (isIncomingCall) {
            major_buttons.setVisibility(View.VISIBLE);
            videoCallControlButtons.setVisibility(View.GONE);
        }

        if (videoCall && isIncomingCall) {
            isMeSendingVideo = false;
            isOtherSendingVideo = true;
        } else if (videoCall) {
            isMeSendingVideo = true;
            isOtherSendingVideo = false;
        } else {
            isMeSendingVideo = false;
            isOtherSendingVideo = false;
        }

    }

    @SuppressLint("InvalidWakeLockTag")
    private void setWakeLock() {
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        try {
            if (Build.VERSION.SDK_INT >= 21 && powerManager.isWakeLockLevelSupported(PROXIMITY_SCREEN_OFF_WAKE_LOCK))
                screenLock = powerManager.newWakeLock(PROXIMITY_SCREEN_OFF_WAKE_LOCK, "CallFrameGUIACtivityAppRTC");
            else
                screenLock = powerManager.newWakeLock(SCREEN_DIM_WAKE_LOCK | ACQUIRE_CAUSES_WAKEUP, "CallFrameGUIACtivityAppRTC");
        } catch (Exception e) {
            if (DEBUG)
                Log.e("AppRTC", "ScreenLock: ", e);
        }
    }

    public void handleSpeaker(View view) {
        //Do nothing if headset connected
        if (localAudioManager.isWiredHeadsetOn())
            return;
//        if(localAudioManager.isBluetoothA2dpOn() || localAudioManager.isBluetoothScoOn())
//            return;
        if (speakerFlag) {
            speakerFlag = false;
            Toast.makeText(this, R.string.speaker_off, Toast.LENGTH_SHORT).show();
            speakerAction(speakerFlag);
            wasSpeakerOnBeforeHeadsetPluggedIn = false;
        } else {
            speakerFlag = true;
            Toast.makeText(this, R.string.speaker_on, Toast.LENGTH_SHORT).show();
            speakerAction(speakerFlag);
            wasSpeakerOnBeforeHeadsetPluggedIn = true;
        }
    }

    public void handleCallTransfer(View view) {
        I.log("handleCallTransfer, callTransferFlag is " + callTransferFlag);
        if (callTransferFlag) {
            callTransferButton.setAlpha((float) 1.0);
            Log.d(TAG, "CallFrameGUIActivityAppRTC callTransferFlag");
            ContactPickerActivity.startPicker(CallFrameGUIActivityAppRTC.this, ContactType.ALL, ContactSelectiontype.SINGLE_SELECT, (contacts, contactListItems) -> {
                if (contacts.size() == 1) {
                    callTransferButton.setAlpha((float) 1.0);
                    IntentUtil.sendCallTransferRequest(CallFrameGUIActivityAppRTC.this, contacts.get(0), callID);
                } else {
                    callTransferFlag = false;
                    callTransferButton.setAlpha((float) 0.4);

                }
            });
//            Intent intent = new Intent(CallFrameGUIActivityAppRTC.this, ContactPickerInCallProgressingActivity.class);
//            intent.putExtra("multiple_selection", false);
//            intent.putExtra("call_transfer", true);
//            intent.putExtra("callID", callID);
//
//            startActivityForResult(intent, CALL_TRANSFER_REQUEST);
        }
    }

    public void handleCallMerge(View view) {
        sendCallMergeIntentMessageToDialer();
    }

    public void handleCallSwitch(View view) {
        sendCallSwitchIntentMessageToDialer();
    }

    public void handleAddConferenceMember(View view) {
        ContactPickerActivity.startPicker(CallFrameGUIActivityAppRTC.this,
                ContactType.ALL,
                ContactSelectiontype.SINGLE_SELECT,
                (contacts, contactListItems) -> {
                    if (contacts.size() == 1) {
                        sendAddCallIntentMessageToDialer(contacts.get(0));
                    } else {
                        I.toast(getString(R.string.no_contacts_selected));
                    }
                });
    }

    public void handleDTMF(View view) {
        showKeyPad(view);
    }


    public void handleCallRecord(View view) {
        if (recordFlag) {
            recordFlag = false;
            callRecordAction(recordFlag);
            tvRecord.setText(getString(R.string.record));
        } else {
            recordFlag = true;
            callRecordAction(recordFlag);
            tvRecord.setText(getString(R.string.recording));
        }
    }

    public void wip(View view) {
        switch (view.getId()) {
            case R.id.video_switch_button_container:
//                audioVideoSwitchButton.performClick();
                break;
            default:
                Util.workInProgress();
                break;
        }
    }

    LinearLayout keyPad;
    NumberView nvDigits;
    private static final long KEYPAD_ANIMATION_TIME = 200;
    boolean isShowingAnimation = false;

    public void showKeyPad(View view) {
        isShowingAnimation = true;
        keyPad.setVisibility(View.VISIBLE);
        keyPad.animate().scaleY(1).scaleX(1).setDuration(KEYPAD_ANIMATION_TIME);
    }

    private void hideKeyPad() {
        isShowingAnimation = false;
        keyPad.animate().scaleY(0).scaleX(0).setDuration(KEYPAD_ANIMATION_TIME).setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (!isShowingAnimation) {
                    keyPad.setVisibility(View.GONE);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }


    ImageView ivCalleePictureInDTMF;

    private void handleKeyPad() {
        ivCalleePictureInDTMF = findViewById(R.id.ivCalleePictureInDTMF);
        keyPad = findViewById(R.id.keyPad);
        nvDigits = findViewById(R.id.nvDigits);
        nvDigits.getBackground().mutate().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        nvDigits.requestFocus();
        nvDigits.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        setupKeys();
        keyPad.setScaleY(0);
        keyPad.setScaleX(0);
        LinearLayout llCloseKeyPad = findViewById(R.id.llCloseKeyPad);
        llCloseKeyPad.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyPad();
            }
        });
        keyPad.setVisibility(View.GONE);
        ivCalleePictureInDTMF.post(new Runnable() {
            @Override
            public void run() {
                String profilePicturePath = ProfilePictureDataProvider.getProfilePicturePath(CallFrameGUIActivityAppRTC.this, number);
                if (profilePicturePath == null) {
                    profilePicturePath = CommonData.contactNumberToContactImageUri.get(number);
                }
                ImageUtil.setImageButDefaultOnException(CallFrameGUIActivityAppRTC.this, profilePicturePath, ivCalleePictureInDTMF, R.drawable.person_bg);
            }
        });
    }

    private void setupKeys() {
        TableLayout tableLayout = findViewById(R.id.tableLayout);
        int index = 1;
        for (int i = 0; i < tableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            for (int j = 0; j < row.getChildCount(); j++) {
                View btnView = row.getChildAt(j);
                setDialButtonView(index, btnView);
                index++;
            }
        }
    }

    public void setDialButtonView(final int index, View btnView) {
        Log.d("setDialButtonView", "index: " + index);
        btnView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String digit = "";
                int tone = 0;
                if (index <= 9) {
                    digit = Integer.toString(index);
                    tone = index;
                } else if (index == 10) {
                    digit = "*";
                    tone = 10;
                } else if (index == 11) {
                    digit = "0";
                    tone = 0;
                } else if (index == 12) {
                    digit = "#";
                    tone = 11;
                }
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, digit);
                sendDTMF(callID, digit);
                nvDigits.insertDigit(digit);
                tones.playTone(tone);
            }
        });
        TextView textNumber = btnView.findViewById(R.id.textNumber);
        TextView textLetter = btnView.findViewById(R.id.textLetter);
        switch (index) {
            case 1:
                textNumber.setText("1");
                textLetter.setText(getString(R.string.sixSpace));
                break;
            case 2:
                textNumber.setText("2");
                textLetter.setText("ABC");
                break;
            case 3:
                textNumber.setText("3");
                textLetter.setText("DEF\u0020");
                break;
            case 4:
                textNumber.setText("4");
                textLetter.setText("GHI\u0020");
                break;
            case 5:
                textNumber.setText("5");
                textLetter.setText("JKL");
                break;
            case 6:
                textNumber.setText("6");
                textLetter.setText("MNO\u0020");
                break;
            case 7:
                textNumber.setText("7");
                textLetter.setText("PQRS");
                break;
            case 8:
                textNumber.setText("8");
                textLetter.setText("TUV");
                break;
            case 9:
                textNumber.setText("9");
                textLetter.setText("WXYZ");
                break;
            case 10:
                textNumber.setText("*");
                textLetter.setText(getString(R.string.sixSpace));
                break;
            case 11:
                textNumber.setText("0");
                textLetter.setText("\u0020+");
                textLetter.setTextColor(Color.WHITE);
                break;
            case 12:
                textNumber.setText("#");
                textLetter.setText(getString(R.string.sixSpace));
                break;
        }
    }

    private void muteAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.mute_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_MUTE);
        } else {
            Toast.makeText(this, R.string.mute_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_MUTE);
        }
    }

    // private void bluetoothAction(boolean isChecked) {
    // if (isChecked) {
    // Toast.makeText(this, "bluetooth on", 3000).show();
    // sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
    // Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
    // } else {
    // Toast.makeText(this, "bluetooth off", 3000).show();
    // sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
    // Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);
    // }
    // }

    private void callHoldAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.call_paused, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_CALL_PAUSE);
        } else {
            Toast.makeText(this, R.string.call_resumed, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_CALL_PAUSE);
        }
    }

    private void speakerAction(boolean isChecked) {
        if (isChecked) {
//            Toast.makeText(this, R.string.speaker_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_SPEAKER);
            SPEAKER_FLAG = true;
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker_active);
//            findViewById(R.id.video_call_sepaker_button).setBackgroundResource(R.drawable.ic_call_window_speaker_active);
            FloatingActionButton fab = findViewById(R.id.video_call_sepaker_button);
            fab.setImageResource(R.drawable.ic_call_window_speaker_active);
            Log.d("Speaker", "speaker on request sent");
        } else {
//            Toast.makeText(this, R.string.speaker_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_SPEAKER);
            SPEAKER_FLAG = false;
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
//            findViewById(R.id.video_call_sepaker_button).setBackgroundResource(R.drawable.ic_call_window_speaker);
            FloatingActionButton fab = findViewById(R.id.video_call_sepaker_button);
            fab.setImageResource(R.drawable.ic_call_window_speaker);
            Log.d("Speaker", "speaker off request sent");

        }
    }

    private void callRecordAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.call_record_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.CALL_RECORDING_IMMEDIATE_START_ACTION, "");
            SPEAKER_FLAG = true;

        } else {
            Toast.makeText(this, R.string.call_record_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.CALL_RECORDING_IMMEDIATE_STOP_ACTION, "");
            SPEAKER_FLAG = false;


        }
    }

    private void soundAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.sound_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_SOUND);
        } else {
            Toast.makeText(this, R.string.sound_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_SOUND);
        }
    }

    public void onClick(View v) {
        Log.w("DTMF", "KEY PRESSED: id: " + v.getId());
        switch (v.getId()) {
            case R.id.cp_zero:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "0");
                sendDTMF(callID, "0");
                enteredNumber.setText(enteredNumber.getText().toString() + "0");
                tones.playTone(0);
                break;
            case R.id.cp_one:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "1");
                sendDTMF(callID, "1");
                enteredNumber.setText(enteredNumber.getText().toString() + "1");
                tones.playTone(1);
                break;
            case R.id.cp_two:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "2");
                sendDTMF(callID, "2");
                enteredNumber.setText(enteredNumber.getText().toString() + "2");
                tones.playTone(2);
                break;
            case R.id.cp_three:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "3");
                sendDTMF(callID, "3");
                enteredNumber.setText(enteredNumber.getText().toString() + "3");
                tones.playTone(3);
                break;
            case R.id.cp_four:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "4");
                sendDTMF(callID, "4");
                enteredNumber.setText(enteredNumber.getText().toString() + "4");
                tones.playTone(4);
                break;
            case R.id.cp_five:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "5");
                sendDTMF(callID, "5");
                enteredNumber.setText(enteredNumber.getText().toString() + "5");
                tones.playTone(5);
                break;
            case R.id.cp_six:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "6");
                sendDTMF(callID, "6");
                enteredNumber.setText(enteredNumber.getText().toString() + "6");
                tones.playTone(6);
                break;
            case R.id.cp_seven:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "7");
                sendDTMF(callID, "7");
                enteredNumber.setText(enteredNumber.getText().toString() + "7");
                tones.playTone(7);
                break;
            case R.id.cp_eight:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "8");
                sendDTMF(callID, "8");
                enteredNumber.setText(enteredNumber.getText().toString() + "8");
                tones.playTone(8);
                break;
            case R.id.cp_nine:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "9");
                sendDTMF(callID, "9");
                enteredNumber.setText(enteredNumber.getText().toString() + "9");
                tones.playTone(9);
                break;
            case R.id.cp_star:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "*");
                sendDTMF(callID, "*");
                enteredNumber.setText(enteredNumber.getText().toString() + "*");
                tones.playTone(10);
                break;
            case R.id.cp_hash:
//                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "#");
                sendDTMF(callID, "#");
                enteredNumber.setText(enteredNumber.getText().toString() + "#");
                tones.playTone(11);
                break;

            case R.id.endcall_button:
                reject();
                // Toast.makeText(CallFrameGUIACtivityAppRTC.this, "End call",
                // Toast.LENGTH_SHORT).show();
                break;
            case R.id.accept_button:
                accept();
                // Toast.makeText(CallFrameGUIACtivityAppRTC.this, "Accept",
                // Toast.LENGTH_SHORT).show();
                break;
            case R.id.decline_button:
                reject();
                // Toast.makeText(CallFrameGUIACtivityAppRTC.this, "Decline",
                // Toast.LENGTH_SHORT).show();
                break;
            case R.id.call_window_video_end_call:
                reject();
                break;
        }
    }

    @Override
    protected void onResume() {

        IntentFilter filter = new IntentFilter(Intent.ACTION_HEADSET_PLUG);
        registerReceiver(headsetReceiver, filter);
        super.onResume();
        if (peerConnectionClientVideoCall != null && !screenCaptureEnabled)
            peerConnectionClientVideoCall.startVideoSource();
        Log.i("AppRTC", "CallFrameGUIACtivityAppRTC onResume");
        isActivityActive = true;
        isOnPause = false;
        ApplicationState.activityResumed();

        /*********** bluetooth headset part **********/
        if (bluetoothSettingsFlag == true
                && Build.VERSION.SDK_INT >= 11) {
            mProfileListener = new BluetoothProfile.ServiceListener() {
                public void onServiceConnected(int profile,
                                               BluetoothProfile proxy) {
                    if (profile == BluetoothProfile.HEADSET) {
                        mBluetoothHeadset = (BluetoothHeadset) proxy;
                        Log.d("Mkhan", "Enters");

                        List<BluetoothDevice> connectedHeadsets = mBluetoothHeadset
                                .getConnectedDevices();
                        bluetoothAdapter.closeProfileProxy(
                                BluetoothProfile.HEADSET, mBluetoothHeadset);
                        Log.d("Mkhan", "Connected headset count : "
                                + connectedHeadsets.size());

                        connectedHeadsetCount = connectedHeadsets.size();

                        if (connectedHeadsetCount == 1) {
                            Toast.makeText(CallFrameGUIActivityAppRTC.this,
                                    R.string.bluetooth_on,
                                    Toast.LENGTH_LONG).show();
                            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                                    Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
                        } else {
                            Toast.makeText(CallFrameGUIActivityAppRTC.this,
                                    R.string.no_device_connected,
                                    Toast.LENGTH_LONG).show();
                            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                                    Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);
                        }

                    }
                }

                public void onServiceDisconnected(int profile) {
                    if (profile == BluetoothProfile.HEADSET) {
                        mBluetoothHeadset = null;
                    }
                }
            };

            /**
             * for some reason this line must be after creation of service
             * listener
             */
            bluetoothAdapter.getProfileProxy(this, mProfileListener,
                    BluetoothProfile.HEADSET);

        }
        bluetoothSettingsFlag = false;

        /************** end **********/
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i(TAG, "CallFrameGUIACtivityAppRTCAppRTC onNewIntent");
        Bundle b = intent.getExtras();
        if (b != null) {
            if (b.containsKey(IncomingCallNotification.INTENT_TYPE_INCOMING_CALL)) {
                String type = b.getString(IncomingCallNotification.INTENT_TYPE_INCOMING_CALL);
                if (type != null && type.equals(IncomingCallNotification.ACCEPT_VALUE)) {
                    accept();
                } else {
                    reject();
                }
            } else if (b.containsKey(RunningCallNotification.INTENT_TYPE_RUNNING_CALL)) {
                String type = b.getString(RunningCallNotification.INTENT_TYPE_RUNNING_CALL);
                if (type != null && type.equals(IncomingCallNotification.ACCEPT_VALUE)) {
                    onResume();
                } else {
                    reject();
                }
            }

        }
        audioVideoSwitchButtonContainer.setEnabled(true);
        audioVideoSwitchButton.setEnabled(true);
    }

    @Override
    protected void onDestroy() {
        Log.i("AppRTC", "CallFrameGUIACtivityAppRTC onDestroy");
        localFinalSDP = "";
        remoteSDP = "";
        callAccepted = false;
        isOnPause = false;
        disconnect();
        Thread.setDefaultUncaughtExceptionHandler(null);
        rootEglBase.release();
        cancelIncomingCallNotification();
        cancelRunningCallNotification();
        isOnPause = false;
        if (returnFromCrash) {
            super.onDestroy();
            return;
        }
        callInfoMap.clear();
        // Unregister since the activity is about to be closed.

        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
//        LocalBroadcastManager.newInstance(this).unregisterReceiver(openFFMPEGBroadcastReceiver);
//        LocalBroadcastManager.newInstance(this).unregisterReceiver(resizeVideoPlayer);
        unregisterReceiver(headsetReceiver);


        // Destroy bluetooth, speaker and mute.
//        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                Constants.BROADCAST_MESSAGE_STOP_SPEAKER);

        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                Constants.BROADCAST_MESSAGE_STOP_MUTE);

//        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);
        readyToReceiveBroadcast = false;

        releaseLocksInCall();

        try {
            if (dialogShown && statsDialog != null)
                statsDialog.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // KeyguardManager km = (KeyguardManager)
        // getSystemService(Context.KEYGUARD_SERVICE);
        // KeyguardLock keyguard = km.newKeyguardLock("MyApp");
        // keyguard.reenableKeyguard();
        unregisterReceiver(mReceiver);
        if (localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "CallFrameGUIActivityAPPRTC On" +
                    " Destroy: Audio Mode set to: MODE_NORMAL");
            localAudioManager.setMode(AudioManager.MODE_NORMAL);
        }

        handleBluetoothOnDestroy();
        isConnectedCall = false;
        super.onDestroy();
    }

    public void startMessaging(View view) {
        boolean isSubscriber = CommonData.subscriberPhoneNumberToLookUpKey.containsKey(number);
        ChatWindowActivity.start(view.getContext(),number,null,!isSubscriber,false,false,null);
    }

    private void handleBluetoothOnDestroy() {
        if (blueToothConnectionMode == A2DP_CONNECTED) {
            Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC" +
                    ":Ondestroy(): " +
                    ": LAST STATUS: A2DP: AUDIO set mode: MODE_NORMAL");
            localAudioManager.setMode(AudioManager.MODE_NORMAL);
            blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;

        } else if (blueToothConnectionMode == SCO_CONNECTED) {
            if (localAudioManager.isBluetoothScoOn()) {
                localAudioManager.setBluetoothScoOn(false);
                localAudioManager.stopBluetoothSco();
                DialerService.isBluetoothScoRequestedToSetOn = false;
                localAudioManager.setMode(AudioManager.MODE_NORMAL);
                blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                Log.e("BluetoothTest", "CallFrameGUIACtivityAppRTC Stopping BlueToothSCO" +
                        ":Ondestroy(): " +
                        ": LAST STATUS: SCO : AUDIO set mode: MODE_NORMAL");
            } else {
                localAudioManager.setMode(AudioManager.MODE_NORMAL);
                blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
            }


        } else {
            blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
            Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC" +
                    ":Ondestroy(): " +
                    ": LAST STATUS: None");

        }
    }

    private boolean callConnected = false;
    private long callStartTime = 0;
    private long callEndTime = 0;
    int volumeUpClickCount = 0;
    boolean isVolumeDisabled = false;
    int initialVolumeLevel;

    boolean videoCall;
    boolean paidCall;
    private boolean isCallProgressingOrConnected = false;
    private boolean isConnectedCall = false;

    private void initViews() {
        handler = new Handler();
        secondLineButtons = findViewById(R.id.secondLineButtons);
        handleKeyPad();
        endCallButtonSpace = findViewById(R.id.endcall_button_space);
        acceptDeclineButtonSpace = findViewById(R.id.accept_decline_button_space);
        callInfoContainer = findViewById(R.id.call_info_container);
//        callStatus = (TextView) findViewById(R.id.statustview);
//        callTimer = (TextView) findViewById(R.id.timertview);
        allButtonHolder = findViewById(R.id.all_button_holder);


//        callTimer.setVisibility(View.GONE);
        allButtonHolder.setVisibility(View.GONE);
//        tvCallStatus = (TextView) findViewById(R.id.tvCallStatus);
        calledCountryISO = findViewById(R.id.tvCountryName);
//        calledNumber = (TextView) findViewById(R.id.numtview);
        picture = findViewById(R.id.contact_image);
//        keypadButton = (ImageView) findViewById(R.id.keypad_button);
        tvCallInfoText = findViewById(R.id.call_info_text);
        holdButton = findViewById(R.id.call_window_hold);
        holdButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textView = findViewById(R.id.ic_call_window_hold_status);
                ImageView imageView = findViewById(R.id.ic_call_window_hold_button);
                if (holdFlag) {
                    holdFlag = false;
                    callHoldAction(holdFlag);
                    textView.setText("Hold");
                    imageView.setImageResource(R.drawable.ic_call_window_pause);

//                    holdButton.setBackgroundColor(getResources().getColor(android.R.color.transparent));
                } else {
                    holdFlag = true;
                    callHoldAction(holdFlag);
                    textView.setText(getString(R.string.unhold));
                    imageView.setImageResource(R.drawable.ic_call_window_play);
//                    holdButton.setBackgroundResource(R.drawable.btn_rec_pressed);
                }
            }
        });
        muteButton = findViewById(R.id.mute_button);
//        bluetoothButton = (ImageView) findViewById(R.id.bluetooth_button);
//        bluetoothButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                bluetoothAction(true);
//            }
//        });
        speakerButton = findViewById(R.id.speaker_button);
        recordButton = findViewById(R.id.record_button);
        callTransferButton = findViewById(R.id.btn_call_transfer);
//        soundButton = (ImageView) findViewById(R.id.sound_button);
//        soundButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                soundAction(true);
//            }
//        });

//        muteButtonBack = (LinearLayout) findViewById(R.id.mute_button_back);
//        bluetoothButtonBack = (LinearLayout) findViewById(R.id.bluetooth_button_back);
//        speakerButtonBack = (LinearLayout) findViewById(R.id.speaker_button_back);
//        soundButtonBack = (LinearLayout) findViewById(R.id.sound_button_back);

//        startMessageButton = (ImageView) findViewById(R.id.btn_start_message);
//        startMessageButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(CallFrameGUIACtivityAppRTC.this, MessageActivity.class);
//                i.putExtra(MessageActivity.EXTRA_PHONE_NUMBER, tvNumber);
//                startActivity(i);
//            }
//        });
        audioVideoSwitchButton = findViewById(R.id.video_switch_button);
        audioVideoSwitchButton.setEnabled(false);
        audioVideoSwitchButtonContainer = findViewById(R.id.video_switch_button_container);
        audioVideoSwitchButtonContainer.setEnabled(false);
        audioVideoSwitchButton.setOnClickListener(view -> {
            if (wasCallInfoEverGreaterThanOne || !callConnected) return;
            if (!isVideoEnabled) {
                isVideoEnabled = true;
                isMeSendingVideo = true;
                sendIntentMessageToDialerForVideoStatus(number, 1, callID);
                holdVideoAction(false);
            } else {
                isVideoEnabled = false;
                isOtherSendingVideo = false;
                sendIntentMessageToDialerForVideoStatus(number, 0, callID);
                holdVideoAction(true);
            }
//            switchVideoPreviewStatus(isVideoEnabled);
            handleAudioVideoSwitching();
        });

        FloatingActionButton video_to_audio = findViewById(R.id.switch_to_audio_from_video);
        video_to_audio.setOnClickListener(view -> {
            if (wasCallInfoEverGreaterThanOne || !callConnected) return;
            if (!isVideoEnabled) {
                isVideoEnabled = true;
                isMeSendingVideo = true;
                sendIntentMessageToDialerForVideoStatus(number, 1, callID);
                holdVideoAction(false);
            } else {
                isVideoEnabled = false;
                isMeSendingVideo = false;
                sendIntentMessageToDialerForVideoStatus(number, 0, callID);
                holdVideoAction(true);
            }
//            switchVideoPreviewStatus(isVideoEnabled);
            handleAudioVideoSwitching();
        });


        cameraSwitchButtonContainer = findViewById(R.id.video_camera_switch_container);
        videoCallControlButtons = findViewById(R.id.video_call_control_buttons);
        cameraSwitchButtonContainer.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onCameraSwitch();
            }
        });
        //---------------------------------//

        major_buttons = findViewById(R.id.major_buttons);
        callerNameHolder = findViewById(R.id.caller_name_holder);
        ivChat = findViewById(R.id.chat_icon);
        callerNameHolder.setAlpha((float) 0.8);
        allButtonHolder.setAlpha((float) 0.8);
        localAudioManager = (AudioManager) CallFrameGUIActivityAppRTC.this.getSystemService(AUDIO_SERVICE);
        tvMicOnOff = findViewById(R.id.tvMicOnOff);
        tvRecord = findViewById(R.id.tvRecord);
//        acceptDeclineButtonSpace.setVisibility(View.GONE);
        endCallButtonSpace.setVisibility(View.VISIBLE);


        videoCall = this.getIntent().getBooleanExtra(Constants.IS_VIDEO_CALL, false);
        paidCall = this.getIntent().getBooleanExtra(Constants.BROADCAST_MESSAGE_PAID_CALL, false);
        Log.d(TAG, "IsVideoCall: " + videoCall);
        if (videoCall) {
            tvCallInfoText.setText(R.string.salamVideoCall);
        } else {
            tvCallInfoText.setText(R.string.voice_call_salam);
        }

        String type = this.getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_FROM_DIALER);

        prepareCallInfoHolder(callID, number);
        CallInfoHolder holder = callInfoMap.get(callID);

        if (type == null) ;
        else if (type.compareTo(Constants.TYPE_INCOMING) == 0) {
            isIncomingCall = true;
            if (CallManager.getCallType(callID) == CALLTYPE_VIDEO) {
                if (holder != null) {
                    if (holder.tvCallStatus != null) {
                        holder.tvCallStatus.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                holder.tvCallStatus.setText(getString(R.string.incoming_video_call));
                            }
                        }, 50);
                    }
                }
            } else {
                if (holder != null) {
                    if (holder.tvCallStatus != null) {
                        holder.tvCallStatus.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                holder.tvCallStatus.setText(getString(R.string.incoming_call));
                            }
                        }, 50);
                    }
                }

            }
            incomingGUISetup();
            Log.d(TAG, "isIncomingCall: " + isIncomingCall);
        } else if (type.compareTo(Constants.TYPE_OUTGOING) == 0) {
            if (holder != null && holder.tvCallStatus != null) {
                holder.tvCallStatus.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        holder.tvCallStatus.setText(getString(R.string.calling));
                    }
                }, 500);

            }
            outgoingGUISetup();
            callingConnectingGUISetup();
            Log.d(TAG, "isIncomingCall: " + isIncomingCall);
        } else if (type.compareTo(Constants.TYPE_CONNECTED) == 0) {
            isIncomingCall = getIntent().getBooleanExtra(Constants.IS_INCOMING_CALL, false);
            connectedGUISetup();
            Log.d(TAG, "isIncomingCall: " + isIncomingCall + "Connected: true");
        }
//        number = this.getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_NUMBER);
//        if (number == null) {
//            finish();
//            return;
//        }
//        calledNumber.setText(number);
//        if (number != null) {
//            String name = ContactEngine.getContactNamefromNumber(this, number.replaceAll("\\D", ""));
//            if (name == null)
//                name = number;
//            calledNumber.setText(name);
//        }
        profilePicture = ProfilePictureDataProvider.getProfilePictureAsBitmap(this, number);
//        Log.d("suvotest","Profile Picture:"+profilePicture);
        if (profilePicture == null) {
            profilePicture = ContactEngine.loadContactPhotoHighResolution(this, number);
//            Log.d("suvotest","Profile Picture1:"+profilePicture);
        }
        if (profilePicture == null) {
            profilePicture = ImageUtil.getBitmapFromVectorDrawable(CallFrameGUIActivityAppRTC.this, R.drawable.person);
        }
//
//        } else {
//            picture.setImageBitmap(profilePicture);
//            Log.d("suvo-test","Profile Picture:"+profilePicture);
//        }

//        Log.d("suvotest","Profile Picture3:"+profilePicture);
//        System.out.println("profilePicture="+profilePicture);
        picture.setImageBitmap(profilePicture);

        String countryCode = Util.getUserCountryCode(number);
        Country country = CountryInfoProvider.countryDialingCodeToCountry.get(countryCode);

        if (country != null) {
            calledCountryISO.setVisibility(View.VISIBLE);
            calledCountryISO.setText(country.isoCode.toUpperCase());
        } else {
            calledCountryISO.setVisibility(View.GONE);
        }
        calledCountryISO.setVisibility(View.GONE);
        if (profilePicture != null)
            picture.setImageBitmap(profilePicture);


    }

    boolean endCallInitiated = false;

    private void endCall(String message) {
        if (endCallInitiated)
            return;
        endCallInitiated = true;
        if (callConnected) {
            if (!dialogShown) {
                callEndTime = System.currentTimeMillis();
            }
        }

//        tvCallStatus.setText(R.string.disconnecting);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!dialogShown) {
//                showCallDisconnectionDialog(message, callConnected);
                        endActivity();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 500);
    }

    private void endActivity() {

        Log.i("AppRTC", "CallFrameGUIACtivityAppRTC endActivity");
//        qualityBar.setVisibility(View.INVISIBLE);
        handler.post(new FinishRunnable());
    }

    public void handleMute(View view) {
        if (muteFlag) {
            muteFlag = false;
            muteAction(muteFlag);
            muteButton.setImageResource(R.drawable.ic_call_window_mute_on);
//            findViewById(R.id.video_call_mute_button).setBackgroundResource(R.drawable.ic_call_window_mute_on);

            FloatingActionButton fab = findViewById(R.id.video_call_mute_button);
            fab.setImageResource(R.drawable.ic_call_window_mute_on);
            tvMicOnOff.setText(getString(R.string.mikeOn));
            muteButton.invalidate();
        } else {
            muteFlag = true;
            muteAction(muteFlag);
            muteButton.setImageResource(R.drawable.ic_call_window_mute_off);
//            findViewById(R.id.video_call_mute_button).setBackgroundResource(R.drawable.ic_call_window_mute_off);
            FloatingActionButton fab = findViewById(R.id.video_call_mute_button);
            fab.setImageResource(R.drawable.ic_call_window_mute_off);
            tvMicOnOff.setText(getString(R.string.mikeOff));
            muteButton.invalidate();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        isActivityActive = false;
        isOnPause = true;
        Log.i("AppRTC", "CallFrameGUIACtivityAppRTC onPause");
//        if (peerConnectionClientVideoCall != null && !screenCaptureEnabled)
//            peerConnectionClientVideoCall.stopVideoSource();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        char numberTyped = KeyCharacterMap.load(event.getDeviceId()).getNumber(keyCode);
        if ((numberTyped >= '0' && numberTyped <= '9') || numberTyped == '#'
                || numberTyped == '*') {

        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
                keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE) {
            if (isConnectedCall)
                reject();
            else {
                if (isIncomingCall)
                    accept();
                else
                    reject();
            }


        } else if (keyCode == KeyEvent.KEYCODE_DEL) {

        } else if (keyCode == KeyEvent.KEYCODE_CALL) {
            accept();
        } else if (keyCode == KeyEvent.KEYCODE_ENDCALL) {
            reject();
        } else if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (fullscreenRenderer.getVisibility() == View.VISIBLE && callConnected) {
                PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder();
                Rational aspectRatio = new Rational(2, 3);
                builder.setAspectRatio(aspectRatio);


                enterPictureInPictureMode(builder.build());


                enterPictureInPictureMode(builder.build());
            }
        } else
            return false;
        return true;
    }

    protected void onUserLeaveHint() {
        if (fullscreenRenderer.getVisibility() == View.VISIBLE && callConnected) {
            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder();
            Rational aspectRatio = new Rational(2, 3);
            builder.setAspectRatio(aspectRatio);


            enterPictureInPictureMode(builder.build());


            enterPictureInPictureMode(builder.build());
        }
    }

    void addEndCallActionInPipMode() {
        PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder();


        Intent intent = new Intent(PIP_END_CALL_BROADCAST_FILTER);


        PendingIntent callEndIntentFromPIP = PendingIntent.getBroadcast(
                CallFrameGUIActivityAppRTC.this,
                0,
                intent,
                0
        );

        Icon icon = Icon.createWithResource(CallFrameGUIActivityAppRTC.this, R.drawable.pip_call_end);


        RemoteAction remoteAction = new RemoteAction(
                icon,
                "", "", callEndIntentFromPIP
        );
        List<RemoteAction> remoteActions = new ArrayList<>();
        remoteActions.add(remoteAction);


        builder.setActions(remoteActions);
        setPictureInPictureParams(builder.build());

    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {




        if (isInPictureInPictureMode) {
            slideDownTimer.cancel();


            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(PIP_END_CALL_BROADCAST_FILTER);


            pipBradCastReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    if (intent != null) {
                        if (PIP_END_CALL_BROADCAST_FILTER.equals(intent.getAction())) {
                            reject();
                        }
                    }
                }
            };
            registerReceiver(pipBradCastReceiver, intentFilter);

            findViewById(R.id.switch_to_audio_from_video).setVisibility(View.GONE);
            findViewById(R.id.video_call_mute_button).setVisibility(View.GONE);
            findViewById(R.id.video_call_sepaker_button).setVisibility(View.GONE);
            findViewById(R.id.video_camera_switch_container).setVisibility(View.GONE);
            findViewById(R.id.call_window_video_end_call).setVisibility(View.GONE);
            buttonsHideAnimation.setAnimationListener(null);
            durationContanerLinearLayoutHideAnimation.setAnimationListener(null);
            callInfoContainer.setVisibility(View.GONE);
            float scale = getResources().getDisplayMetrics().density;
            RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) pipRenderer.getLayoutParams();
            params.height = (int) (newConfig.screenHeightDp * .25 * scale);
            params.width = (int) (newConfig.screenWidthDp * .25 * scale);
            params.topMargin = (int) (4 * scale);
            params.leftMargin = (int) (4 * scale);
            params.setMarginStart((int) (4 * scale));
            pipRenderer.setLayoutParams(params);
            pipRenderer.invalidate();
            addEndCallActionInPipMode();


        } else {
            if (pipBradCastReceiver != null) unregisterReceiver(pipBradCastReceiver);
            pipBradCastReceiver = null;
            initAnimations();
            findViewById(R.id.switch_to_audio_from_video).setVisibility(View.VISIBLE);
            findViewById(R.id.video_call_mute_button).setVisibility(View.VISIBLE);
            findViewById(R.id.video_call_sepaker_button).setVisibility(View.VISIBLE);
            findViewById(R.id.video_camera_switch_container).setVisibility(View.VISIBLE);
            findViewById(R.id.call_window_video_end_call).setVisibility(View.VISIBLE);
            callInfoContainer.setVisibility(View.VISIBLE);
            float scale = getResources().getDisplayMetrics().density;
            RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) pipRenderer.getLayoutParams();
            params.height = (int) (newConfig.screenHeightDp * .25 * scale);
            params.width = (int) (newConfig.screenWidthDp * .25 * scale);
            params.topMargin = (int) (16 * scale);
            params.leftMargin = (int) (16 * scale);
            params.setMarginStart((int) (16 * scale));
            pipRenderer.setLayoutParams(params);
            pipRenderer.invalidate();


        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ContactSelectionActivity.CONTACT_SELECTION_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data.hasExtra(ContactSelectionActivity.KEY_RESULT)) {
                List<Contact> contacts = (List<Contact>) data.getSerializableExtra(ContactSelectionActivity.KEY_RESULT);
                if (contacts != null && contacts.size() > 0) {
                    String numbers = "";
                    for (Contact contact : contacts) {
                        numbers += contact.processedNumber + " ";
                        sendAddCallIntentMessageToDialer(contact.processedNumber);
                    }
                } else {
                    I.toast("no contacts selected");
                }
            } else {
                I.toast("Cancelled or no data");
            }
        } else if (requestCode == CALL_TRANSFER_REQUEST) {
            if (resultCode != Activity.RESULT_OK)
                callTransferButton.setAlpha((float) 1.0);
            else {
                callTransferFlag = false;
                callTransferButton.setAlpha((float) 0.4);

            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void accept() {
        endCallInitiated = false;
        if (videoCall) {
            videoCallControlButtons.setVisibility(View.VISIBLE);
            allButtonHolder.setVisibility(View.GONE);
            major_buttons.setVisibility(View.GONE);
            findViewById(R.id.firstLineButtons).setVisibility(View.GONE);

        }
        cancelIncomingCallNotification();
        showRunningCallNotification(number);
        sendMessage(Constants.BROADCAST_MESSAGE_ACCEPT, callID);
    }

    private void reject() {
        cancelIncomingCallNotification();
        cancelRunningCallNotification();
        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL, Constants.BROADCAST_MESSAGE_REJECT);
//        endActivity();
        endCall(getString(R.string.you_have_disconnected_the_call));
    }

    private void incomingGUISetup() {

        setVolumeControlStream(AudioManager.STREAM_RING);
        findViewById(R.id.endcall_button_space).setVisibility(View.INVISIBLE);
        findViewById(R.id.accept_button).setVisibility(View.VISIBLE);
        findViewById(R.id.decline_button).setVisibility(View.VISIBLE);
        findViewById(R.id.ll_call_transfer).setVisibility(View.INVISIBLE);
        findViewById(R.id.ll_add_conference_member).setVisibility(View.INVISIBLE);


        ivChat.setVisibility(View.GONE);
        if (videoCall) {
            isMeSendingVideo = true;
            isOtherSendingVideo = true;
        }
    }

    private void callingConnectingGUISetup() {
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);

        findViewById(R.id.accept_button).setVisibility(View.INVISIBLE);
        findViewById(R.id.decline_button).setVisibility(View.INVISIBLE);
        findViewById(R.id.ll_call_transfer).setVisibility(View.VISIBLE);
        findViewById(R.id.ll_add_conference_member).setVisibility(View.VISIBLE);


        findViewById(R.id.endcall_button_space).setVisibility(View.VISIBLE);
        audioVideoSwitchButton.setEnabled(false);
        buttonVisiblityCallingConnectingGUI();
    }

    private void buttonVisiblityCallingConnectingGUI() {
        allButtonHolder.setVisibility(View.VISIBLE);
        recordButton.setEnabled(false);
        callTransferButton.setEnabled(false);
        muteButton.setEnabled(false);
    }

    private void outgoingGUISetup() {
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);

        findViewById(R.id.accept_button).setVisibility(View.INVISIBLE);
        findViewById(R.id.decline_button).setVisibility(View.INVISIBLE);
        findViewById(R.id.ll_call_transfer).setVisibility(View.VISIBLE);
        findViewById(R.id.ll_add_conference_member).setVisibility(View.VISIBLE);


        findViewById(R.id.endcall_button_space).setVisibility(View.VISIBLE);
        // findViewById(R.id.activitybutton).setVisibility(View.INVISIBLE);
        ivChat.setVisibility(View.GONE);
//        audioVideoSwitchButton.setAlpha((float)0.4);
        audioVideoSwitchButton.setEnabled(false);

        if (videoCall) {
            allButtonHolder.setVisibility(View.GONE);
            findViewById(R.id.firstLineButtons).setVisibility(View.GONE);
            secondLineButtons.setVisibility(View.GONE);
            major_buttons.setVisibility(View.GONE);

            isMeSendingVideo = true;
            isOtherSendingVideo = true;
        }
    }

    private void connectedGUISetup() {
        outgoingGUISetup();
        ivChat.setVisibility(View.GONE);
//        audioVideoSwitchButton.setAlpha((float)1.0);


        if (isIncomingCall) {
            callTransferFlag = true;
            callTransferButton.setAlpha((float) 1.0);
        }
        isCallProgressingOrConnected = true;
        isConnectedCall = true;

        if (!localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "Checking if isBluetoothScoRequestedToSetOn: "
                    + DialerService.isBluetoothScoRequestedToSetOn);
            if (isIncomingCall &&
                    Util.isBluetoothHeadsetConnected() &&
                    !DialerService.isBluetoothScoRequestedToSetOn) {
                if (!localAudioManager.isBluetoothScoOn()) {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    localAudioManager.setBluetoothScoOn(true);
                    localAudioManager.startBluetoothSco();
                    DialerService.isBluetoothScoRequestedToSetOn = true;
                    blueToothConnectionMode = SCO_CONNECTED;
                    Log.e("BluetoothTest", "CallFrameGUI Activity starting BlueToothSco " +
                            "after incoming call connected");
                }
            }
        } else {
            if (localAudioManager.getMode() != AudioManager.STREAM_VOICE_CALL) {
                Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC: Call Connected: " +
                        "BluetoothA2DP connected: AudioMode Set: STREAM_VOICE_CALL "
                );
                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
            }
            blueToothConnectionMode = A2DP_CONNECTED;
        }
//        tvCallStatus.setText(getString(R.string.connected));
        audioVideoSwitchButtonContainer.setEnabled(true);
        audioVideoSwitchButton.setEnabled(true);
        if (videoCall) allButtonHolder.setVisibility(View.GONE);
        else allButtonHolder.setVisibility(View.VISIBLE);
        callConnected = true;
    }

    private class FinishRunnable implements Runnable {
        public void run() {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            finish();
        }
    }

    public void acquireLocksInCall() {
        sensorManager.registerListener(this, proximitySensor, SENSOR_DELAY_NORMAL, handler);
        if (screenLock != null && !screenLock.isHeld())
            screenLock.acquire();

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        PowerManager powerManager = (PowerManager) this.getSystemService(POWER_SERVICE);
        long l = SystemClock.uptimeMillis();
    }


    public void releaseLocksInCall() {
        sensorManager.unregisterListener(this);
        if (screenLock != null && screenLock.isHeld())
            screenLock.release(0);
    }

    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) {
    }

    public void onSensorChanged(SensorEvent event) {
        final Window window = getWindow();
        WindowManager.LayoutParams lAttrs = getWindow().getAttributes();


        View view = ((ViewGroup) window.getDecorView().findViewById(android.R.id.content)).getChildAt(0);


        if (isMeSendingVideo || isOtherSendingVideo) {
            lAttrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            view.setVisibility(View.VISIBLE);
        } else if (event.values[0] > 0.0) {
            lAttrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            view.setVisibility(View.VISIBLE);
        } else {
            lAttrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            view.setVisibility(View.GONE);
        }
        window.setAttributes(lAttrs);
    }

    private void bluetoothAction(boolean isChecked) {

        if (isChecked) {

            if (Build.VERSION.SDK_INT >= 11) {
                mProfileListener = new BluetoothProfile.ServiceListener() {
                    public void onServiceConnected(int profile,
                                                   BluetoothProfile proxy) {
                        if (profile == BluetoothProfile.HEADSET) {
                            mBluetoothHeadset = (BluetoothHeadset) proxy;
                            Log.d("AppRTC", "Enters in is checked");

                            List<BluetoothDevice> connectedHeadsets = mBluetoothHeadset
                                    .getConnectedDevices();
                            bluetoothAdapter
                                    .closeProfileProxy(
                                            BluetoothProfile.HEADSET,
                                            mBluetoothHeadset);
                            Log.d("AppRTC", "Connected headset count : "
                                    + connectedHeadsets.size());

                            connectedHeadsetCount = connectedHeadsets.size();

                            Log.d("AppRTC", "Connected headset count var: "
                                    + connectedHeadsetCount);

                            if (connectedHeadsetCount == 1) {

                                Toast.makeText(CallFrameGUIActivityAppRTC.this,
                                        R.string.bluetooth_on,
                                        Toast.LENGTH_SHORT).show();

                                sendMessage(
                                        Constants.BROADCAST_MESSAGE_FROM_CALL,
                                        Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
                            } else {
                                bluetoothSettingsFlag = true;
                                Intent intentBluetooth = new Intent();
                                intentBluetooth = new Intent();
                                intentBluetooth
                                        .setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                                startActivity(intentBluetooth);
                            }
                        }
                    }

                    public void onServiceDisconnected(int profile) {
                        if (profile == BluetoothProfile.HEADSET) {
                            mBluetoothHeadset = null;
                        }
                    }
                };

                /**
                 * for some reason this line must be after creation of service
                 * listener
                 */
                bluetoothAdapter.getProfileProxy(this, mProfileListener,
                        BluetoothProfile.HEADSET);
            } else {

                Toast.makeText(this, R.string.bluetooth_on, Toast.LENGTH_SHORT).show();
                sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL, Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
            }

        } else {
            Toast.makeText(this, R.string.bluetooth_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL, Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);

        }

    }

    private void sendIntentMessageToDialer(String type, String number) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, number);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private Dialog statsDialog = null;

//    private void showCallDisconnectionDialog(final String message, final boolean showDuration) {
//        //do_not_have_enough_balance_to_make_call
//
//        if (message.equals(getString(R.string.do_not_have_enough_balance_to_make_call))) {
//            Intent intent = new Intent(this, CallFinishedDialogLowBalance.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            intent.putExtra(CallFinishedDialogLowBalance.NUMBER, number);
//            intent.putExtra(CallFinishedDialogLowBalance.MESSAGE, message);
//            startActivity(intent);
//        } else if (message.length() == 0 && preferences.getBoolean(Constants.RATE_CALL_ENABLED, Constants.RATE_CALL_ENABLED_DEF) && showDuration) {
//            Intent intent = new Intent(this, RateCallActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            intent.putExtra(RateCallActivity.NUMBER, number);
//            startActivity(intent);
//        } else if (message.startsWith(getString(R.string.call_was_not_answered)) && DatabaseConstants.getInstance(this).checkForSubscriberByNumber(number)) {
//            Intent intent = new Intent(this, UserOfflineDialog.class);
//            intent.putExtra(UserOfflineDialog.NUMBER, number);
//            String[] parts = message.split(":");
//            if (parts.length >= 2) {
//                intent.putExtra(UserOfflineDialog.RATE, parts[1]);
//            }
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//        } else {
//            Intent intent = new Intent(this, CallFinishedDialog.class);
//            intent.putExtra(CallFinishedDialog.NUMBER, number);
//            intent.putExtra(CallFinishedDialog.MESSAGE, message);
//            if (showDuration) {
//                int sec = (int) ((callEndTime - callStartTime) / 1000);
//                int min = 0;
//                if (sec > 60) {
//                    min = sec / 60;
//                }
//                sec = sec % 60;
//                intent.putExtra(CallFinishedDialog.SHOW_DURATION, " " + (min > 0 ? (min + " min ") : "") + sec + " sec");
//            }
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//        }
//        endActivity();
//
//    }

    private void showRunningCallNotification(String number) {
        RunningCallNotification.newBuilder().withNumber(number)
                .withContext(this)
                .withIsOutGoingCall(!isIncomingCall)
                .build()
                .showNotification();
    }

    private void cancelRunningCallNotification() {
        RunningCallNotification.cancelNotification();
    }

    private void cancelIncomingCallNotification() {
        IncomingCallNotification.cancelNotification();
    }

    private void handleBluetooth() {

        if (localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC: checking Bluetooth A2DP: ON");
            if (isIncomingCall) {
                blueToothConnectionMode = A2DP_CONNECTED;

            } else {
                Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC: changing Audio Mode to " +
                        "STREAM_VOICE_CALL in Outgoing Call");
                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                blueToothConnectionMode = A2DP_CONNECTED;
            }

        } else {
            Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC: checking Bluetooth A2DP: OFF");
            if (!isIncomingCall) {
                if (isBluetoothHeadsetConnected() && !DialerService.isBluetoothScoRequestedToSetOn) {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    localAudioManager.setBluetoothScoOn(true);
                    localAudioManager.startBluetoothSco();
                    DialerService.isBluetoothScoRequestedToSetOn = true;
                    blueToothConnectionMode = SCO_CONNECTED;
                    Log.e("BluetoothTest", "CallFrameGUIACtivityAppRTC Outgoing Call Starting BluetoothSCO: changing Audio Mode to " +
                            "MODE_IN_COMMUNICATION");
                } else {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC Outgoing Call changing Audio Mode to " +
                            "MODE_IN_COMMUNICATION");

                }
            }

        }

    }

    public boolean isBluetoothHeadsetConnected() {
        if (localAudioManager.isBluetoothA2dpOn())
            return true;
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            return mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()
                    && mBluetoothAdapter.getProfileConnectionState(BluetoothHeadset.HEADSET) == BluetoothHeadset.STATE_CONNECTED;
        } else
            return false;
    }

    private void registerBluetoothConnectionStateReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(mReceiver, filter);
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                //Device found

                postBluetoothOrHeadSetConnected();
                if (localAudioManager.isBluetoothA2dpOn()) {
                    if (!isIncomingCall) {
                        Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC OutGoingCall " +
                                ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                        localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                        blueToothConnectionMode = A2DP_CONNECTED;
                    } else {
                        if (SIPProvider.voiceRunning) {
                            Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC Incoming Call voiceRunning " +
                                    ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                    ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                            if (!isCallProgressingOrConnected)
                                localAudioManager.setMode(AudioManager.MODE_NORMAL);
                            else
                                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                            blueToothConnectionMode = A2DP_CONNECTED;

                        }
                    }

                } else {
                    if (isIncomingCall) {
                        if (SIPProvider.voiceRunning) {
                            if (!localAudioManager.isBluetoothScoOn() &&
                                    !DialerService.isBluetoothScoRequestedToSetOn) {
                                localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                                localAudioManager.setBluetoothScoOn(true);
                                localAudioManager.startBluetoothSco();
                                blueToothConnectionMode = SCO_CONNECTED;
                                DialerService.isBluetoothScoRequestedToSetOn = true;
                                Log.e("BluetoothTest", "CallFrameGUIACtivityAppRTC Incoming Call voiceRunning " +
                                        ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                        ": A2DP STATUS: OFF : AUDIO set mode: MODE_IN_COMMUNICATION");
                            }

                        }
                    } else {
                        if (!localAudioManager.isBluetoothScoOn() &&
                                !DialerService.isBluetoothScoRequestedToSetOn) {
                            localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                            localAudioManager.setBluetoothScoOn(true);
                            localAudioManager.startBluetoothSco();
                            blueToothConnectionMode = SCO_CONNECTED;
                            DialerService.isBluetoothScoRequestedToSetOn = true;
                            Log.e("BluetoothTest", "CallFrameGUIACtivityAppRTC OutGoing Call " +
                                    ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                    ": A2DP STATUS: OFF: AUDIO set mode: MODE_IN_COMMUNICATION");
                        }
                    }

                }


            } else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                //              Device is now connected
                postBluetoothOrHeadSetConnected();

                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        localAudioManager = (AudioManager) CallFrameGUIActivityAppRTC.this.getSystemService(AUDIO_SERVICE);
                        Log.d("BluetoothTest", "IsVoiceRunning: " + SIPProvider.voiceRunning +
                                " IsConnected: " + isCallProgressingOrConnected + " isA2DP:  "
                                + localAudioManager.isBluetoothA2dpOn());
                        if (localAudioManager.isBluetoothA2dpOn()) {
                            if (!isIncomingCall) {
                                Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC OutGoingCall " +
                                        ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                        ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                blueToothConnectionMode = A2DP_CONNECTED;
                            } else {
                                if (SIPProvider.voiceRunning) {
                                    Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC Incoming Call voiceRunning " +
                                            ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                            ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                    if (isCallProgressingOrConnected)
                                        localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                    else
                                        localAudioManager.setMode(AudioManager.MODE_NORMAL);
                                    blueToothConnectionMode = A2DP_CONNECTED;

                                }
                            }

                        } else {

                            if (!isIncomingCall) {
                                Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC OutGoingCall " +
                                        ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                        ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                blueToothConnectionMode = SCO_CONNECTED;
                            } else {
                                if (SIPProvider.voiceRunning) {
                                    Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC Incoming Call voiceRunning " +
                                            ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                            ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                    localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                    blueToothConnectionMode = SCO_CONNECTED;

                                }
                            }
//                            if (isIncomingCall) {
//                                if (SIPProvider.voiceRunning) {
//                                    if (!localAudioManager.isBluetoothScoOn() &&
//                                            !DialerService.isBluetoothScoRequestedToSetOn) {
//                                        localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
//                                        localAudioManager.setBluetoothScoOn(true);
//                                        localAudioManager.startBluetoothSco();
//                                        DialerService.isBluetoothScoRequestedToSetOn = true;
//                                        blueToothConnectionMode = SCO_CONNECTED;
//                                        Log.e("BluetoothTest", "CallFrameGUIACtivityAppRTC Incoming Call voiceRunning " +
//                                                ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
//                                                ": A2DP STATUS: OFF : AUDIO set mode: MODE_IN_COMMUNICATION");
//                                    }
//
//                                }
//                            } else {
//                                if (!localAudioManager.isBluetoothScoOn() && !DialerService.isBluetoothScoRequestedToSetOn) {
//                                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
//                                    localAudioManager.setBluetoothScoOn(true);
//                                    localAudioManager.startBluetoothSco();
//                                    DialerService.isBluetoothScoRequestedToSetOn = true;
//                                    blueToothConnectionMode = SCO_CONNECTED;
//                                    Log.e("BluetoothTest", "CallFrameGUIACtivityAppRTC OutGoing Call " +
//                                            ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
//                                            ": A2DP STATUS: OFF: AUDIO set mode: MODE_IN_COMMUNICATION");
//                                }
//                            }

                        }
                    }
                }, 200);


            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                //Done searching
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED.equals(action)) {
                //Device is about to disconnect

            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                postBluetoothOrHeadSetDisconnected();

                Log.d("BluetoothTest", "ACTION_ACL_DISCONNECTED: connectionMode: " + blueToothConnectionMode);
                if (blueToothConnectionMode == A2DP_CONNECTED) {
                    Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC" +
                            ": Broadcast: BluetoothDevice.ACTION_ACL_DISCONNECTED" +
                            ": LAST STATUS: A2DP: AUDIO set mode: MODE_NORMAL");
                    localAudioManager.setMode(AudioManager.MODE_NORMAL);
                    blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;

                } else if (blueToothConnectionMode == SCO_CONNECTED) {
                    if (localAudioManager.isBluetoothScoOn()) {
                        localAudioManager.setBluetoothScoOn(false);
                        localAudioManager.stopBluetoothSco();
                        DialerService.isBluetoothScoRequestedToSetOn = false;
                        localAudioManager.setMode(AudioManager.MODE_NORMAL);
                        blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                        Log.e("BluetoothTest", "CallFrameGUIACtivityAppRTC Stopping BlueToothSCO" +
                                ": Broadcast: BluetoothDevice.ACTION_ACL_DISCONNECTED" +
                                ": LAST STATUS: SCO : AUDIO set mode: MODE_NORMAL");
                    } else {
                        localAudioManager.setMode(AudioManager.MODE_NORMAL);
                        blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                    }


                } else {

                    localAudioManager.setMode(AudioManager.MODE_NORMAL);
                    blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                    Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC" +
                            ": Broadcast: BluetoothDevice.ACTION_ACL_DISCONNECTED" +
                            ": LAST STATUS: None : AUDIO set mode: MODE_NORMAL");

                }

            }
        }
    };

    public void resetBluetoothMode() {
        if (!localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "Checking if isBluetoothScoRequestedToSetOn: "
                    + DialerService.isBluetoothScoRequestedToSetOn);
            if (isIncomingCall &&
                    Util.isBluetoothHeadsetConnected() &&
                    !DialerService.isBluetoothScoRequestedToSetOn) {
                if (!localAudioManager.isBluetoothScoOn()) {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    localAudioManager.setBluetoothScoOn(true);
                    localAudioManager.startBluetoothSco();
                    DialerService.isBluetoothScoRequestedToSetOn = true;
                    blueToothConnectionMode = SCO_CONNECTED;
                    Log.e("BluetoothTest", "CallFrameGUI Activity starting BlueToothSco " +
                            "after incoming call connected");
                }


            }
        } else {

            if (localAudioManager.getMode() != AudioManager.STREAM_VOICE_CALL) {
                Log.d("BluetoothTest", "CallFrameGUIACtivityAppRTC: Call Connected: " +
                        "BluetoothA2DP connected: AudioMode Set: STREAM_VOICE_CALL "
                );
                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
            }
            blueToothConnectionMode = A2DP_CONNECTED;
        }
    }


    private boolean videoCallInit = false;

    public static int CURRENT_DISPLAY_ROTATION = 0;
    //    LinearLayout callFrameContainer = null;
    LinearLayout bottomViewGroupContainer = null;
    RelativeLayout topViewGroupContainer = null;

    Animation.AnimationListener hideAnimationListener, showAnimationListener;
    long lastTappedTimeInMilisecond;
    Timer slideDownTimer;
    TimerTask slideDownTimerTask;
    GestureDetectorCompat gestureDetector;
    Animation buttonsHideAnimation, buttonsShowAnimation,
            durationContanerLinearLayoutHideAnimation,
            durationContanerLinearLayoutShowAnimation;


//    public boolean isCameraPresent(int camID) {
//        Camera.CameraInfo ci = new Camera.CameraInfo();
//        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
//            Camera.getCameraInfo(i, ci);
//            if (ci.facing == camID)
//                return true;
//        }
//        return false; // No front-facing camera found
//    }

//    public int getRotation(int cameraId, int orientation) {
//        android.hardware.Camera.CameraInfo turnInfo = new android.hardware.Camera.CameraInfo();
//        android.hardware.Camera.getCameraInfo(cameraId, turnInfo);
//        orientation = (orientation + 45) / 90 * 90;
//        int rotation = 0;
//        if (turnInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
//            rotation = (turnInfo.orientation - orientation + 360) % 360;
//        } else { // back-facing camera
//            rotation = (turnInfo.orientation + orientation) % 360;
//        }
//        return rotation;
//    }

//    private void setCameraDisplayOrientation(int cameraId,
//                                             android.hardware.Camera camera) {
//        android.hardware.Camera.CameraInfo turnInfo = new android.hardware.Camera.CameraInfo();
//        android.hardware.Camera.getCameraInfo(cameraId, turnInfo);
//        int rotation = getWindowManager().getDefaultDisplay().getRotation();
//        int degrees = 0;
//        switch (rotation) {
//            case Surface.ROTATION_0:
//                degrees = 0;
//                break;
//            case Surface.ROTATION_90:
//                degrees = 90;
//                break;
//            case Surface.ROTATION_180:
//                degrees = 180;
//                break;
//            case Surface.ROTATION_270:
//                degrees = 270;
//                break;
//        }
//
//        int result;
//        if (turnInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
//            result = (turnInfo.orientation + degrees) % 360;
//            result = (360 - result) % 360; // compensate the mirror
//        } else { // back-facing
//            result = (turnInfo.orientation - degrees + 360) % 360;
//        }
//        camera.setDisplayOrientation(result);
//    }

    /**
     * Video end
     */

    private void sendIntentMessageToDialerForVideoStatus(String number, int videoStatus, String callID) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("callswitchupdate", number);
        intent.putExtra("videostatus", videoStatus);
        intent.putExtra("callID", callID);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendAudioVideoSwitchIntentMessageToDialer(String number, String callID) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("audiovideoswitch", number);
        intent.putExtra("callID", callID);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendCallSwitchIntentMessageToDialer() {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("callswitch", "");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendCallMergeIntentMessageToDialer() {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("callmerge", "");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendAddCallIntentMessageToDialer(String number) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("addcall", number);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendDTMF(String callID, String dtmf) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(Constants.BROADCAST_MESSAGE_SEND_DTMF, dtmf);
        intent.putExtra(BROADCAST_MESSAGE_CALLID, callID);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendMessage(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }


    public void handleAudioVideoSwitching() {
        callInfoContainer.setVisibility(View.VISIBLE);
        if (isVideoEnabled) {
            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_camrea_off);
            FloatingActionButton fab = findViewById(R.id.switch_to_audio_from_video);
            fab.setImageResource(R.drawable.ic_call_window_video_camrea_off);
        } else {
            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_call);
            FloatingActionButton fab = findViewById(R.id.switch_to_audio_from_video);
            fab.setImageResource(R.drawable.ic_call_window_video_call);
        }
        if (!isMeSendingVideo && !isOtherSendingVideo) {
//            picture.setImageBitmap(profilePicture);
            picture.setVisibility(View.VISIBLE);
            slideDownTimer.cancel();
            slideDownTimerTask.cancel();
            buttonsHideAnimation.cancel();
            durationContanerLinearLayoutHideAnimation.cancel();
            durationContanerLinearLayoutShowAnimation.startNow();
            findViewById(R.id.contact_image_holder).setVisibility(View.VISIBLE);
            pipRenderer.setVisibility(View.GONE);
            fullscreenRenderer.setVisibility(View.GONE);
            allButtonHolder.setVisibility(View.VISIBLE);
            videoCallControlButtons.setVisibility(View.GONE);
            bottomViewGroupContainer.setVisibility(View.VISIBLE);
            topViewGroupContainer.setVisibility(View.VISIBLE);
            wasSpeakerOnBeforeHeadsetPluggedIn = false;
            speakerFlag = false;
            showHideButtonOptions();
            findViewById(R.id.firstLineButtons).setVisibility(View.VISIBLE);
            secondLineButtons.setVisibility(View.VISIBLE);
            major_buttons.setVisibility(View.VISIBLE);
            allButtonHolder.setVisibility(View.VISIBLE);
            startStopSpeaker();
        } else {


            findViewById(R.id.contact_image_holder).setVisibility(View.GONE);
            pipRenderer.setVisibility(View.VISIBLE);
            fullscreenRenderer.setVisibility(View.VISIBLE);
            videoCallControlButtons.setVisibility(View.VISIBLE);

            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
            initAnimations();
//            updateSpeakerStatusIfVideoCall();
            pipRenderer.setZOrderMediaOverlay(true);
            if (callConnected) {
                major_buttons.setVisibility(View.GONE);

            }

            showHideButtonOptions();
            findViewById(R.id.firstLineButtons).setVisibility(View.GONE);
            allButtonHolder.setVisibility(View.GONE);
            startStopSpeaker();

        }
    }

//    public void switchVideoPlayerStatus(boolean isChecked) {
//        callInfoContainer.setVisibility(View.VISIBLE);
//        System.out.println("AV SWITCH Player "+" isChecked"+isChecked+" isVideoEnabled:"+isVideoEnabled);
//        Log.w("AppRTC", "switchVideoPlayerStatus(): " + isChecked);
//
//        if (isVideoEnabled) {
//            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_camrea_off);
//            FloatingActionButton fab=findViewById(R.id.switch_to_audio_from_video);
//            fab.setImageResource(R.drawable.ic_call_window_video_camrea_off);
//        } else {
//            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_call);
//            FloatingActionButton fab=findViewById(R.id.switch_to_audio_from_video);
//            fab.setImageResource(R.drawable.ic_call_window_video_call);
//        }
//        if (isChecked) {
//
//            findViewById(R.id.contact_image_holder).setVisibility(View.GONE);
//            pipRenderer.setVisibility(View.VISIBLE);
//            fullscreenRenderer.setVisibility(View.VISIBLE);
//            videoCallControlButtons.setVisibility(View.VISIBLE);
//
//            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
//            initAnimations();
////            updateSpeakerStatusIfVideoCall();
//            pipRenderer.setZOrderMediaOverlay(true);
//            if(callConnected){
//                major_buttons.setVisibility(View.GONE);
//
//            }
//
//            showHideButtonOptions();
//            findViewById(R.id.firstLineButtons).setVisibility(View.GONE);
//            allButtonHolder.setVisibility(View.GONE);
//            startStopSpeaker();
//        } else {
//            findViewById(R.id.contact_image_holder).setVisibility(View.VISIBLE);
//            pipRenderer.setVisibility(View.GONE);
//            fullscreenRenderer.setVisibility(View.GONE);
//            allButtonHolder.setVisibility(View.VISIBLE);
//            videoCallControlButtons.setVisibility(View.GONE);
////            cameraSwitchButton.setVisibility(View.GONE);
////            cameraSwitchButtonContainer.setVisibility(View.GONE);
//            bottomViewGroupContainer.setVisibility(View.VISIBLE);
//            topViewGroupContainer.setVisibility(View.VISIBLE);
////            speakerAction(false);
//            wasSpeakerOnBeforeHeadsetPluggedIn = false;
//            speakerFlag = false;
//            showHideButtonOptions();
//            findViewById(R.id.firstLineButtons).setVisibility(View.VISIBLE);
//            secondLineButtons.setVisibility(View.VISIBLE);
//            major_buttons.setVisibility(View.VISIBLE);
//            allButtonHolder.setVisibility(View.VISIBLE);
//            startStopSpeaker();
//        }
//    }
//
//    public void switchVideoPreviewStatus(boolean isChecked) {
//        callInfoContainer.setVisibility(View.VISIBLE);
//        Log.w("AppRTC", "switchVideoPreviewStatus(): " + isChecked);
//        System.out.println("AV SWITCH Preview"+" isChecked"+isChecked+" isVideoEnabled:"+isVideoEnabled);
//        if (isChecked) {
//            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_camrea_off);
//            FloatingActionButton fab=findViewById(R.id.switch_to_audio_from_video);
//            fab.setImageResource(R.drawable.ic_call_window_video_camrea_off);
//        } else {
//            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_call);
//            FloatingActionButton fab=findViewById(R.id.switch_to_audio_from_video);
//            fab.setImageResource(R.drawable.ic_call_window_video_call);
//        }
//        System.out.println("suvo-test switchVideoPreviewStatus:"+isChecked);
//        if (isVideoEnabled) {
//
//            findViewById(R.id.contact_image_holder).setVisibility(View.GONE);
//            pipRenderer.setVisibility(View.VISIBLE);
//            fullscreenRenderer.setVisibility(View.VISIBLE);
//            videoCallControlButtons.setVisibility(View.VISIBLE);
//
//            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
//            initAnimations();
////            updateSpeakerStatusIfVideoCall();
//            pipRenderer.setZOrderMediaOverlay(true);
//            if(!isIncomingCall){
//                major_buttons.setVisibility(View.GONE);
//            }
//
//
//            showHideButtonOptions();
//            findViewById(R.id.firstLineButtons).setVisibility(View.GONE);
//            allButtonHolder.setVisibility(View.GONE);
//            startStopSpeaker();
//        } else {
//            findViewById(R.id.contact_image_holder).setVisibility(View.VISIBLE);
//            pipRenderer.setVisibility(View.GONE);
//            fullscreenRenderer.setVisibility(View.GONE);
//            allButtonHolder.setVisibility(View.VISIBLE);
//            videoCallControlButtons.setVisibility(View.GONE);
////            cameraSwitchButton.setVisibility(View.GONE);
//            cameraSwitchButtonContainer.setVisibility(View.GONE);
//            bottomViewGroupContainer.setVisibility(View.VISIBLE);
//            topViewGroupContainer.setVisibility(View.VISIBLE);
////            speakerAction(false);
//            wasSpeakerOnBeforeHeadsetPluggedIn = false;
//            speakerFlag = false;
//            showHideButtonOptions();
//            findViewById(R.id.firstLineButtons).setVisibility(View.VISIBLE);
//            secondLineButtons.setVisibility(View.VISIBLE);
//            major_buttons.setVisibility(View.VISIBLE);
//            allButtonHolder.setVisibility(View.VISIBLE);
//            startStopSpeaker();
//        }
//    }
//
//    public void setVideoCallEnvironment() {
//
//        getDimention();
//
//        VideoParameters.CURRENT_ORIENTATION = getResources().getConfiguration().orientation;
//
//        scale = this.getResources().getDisplayMetrics().density;
//    }

    public static double measuredWidth = 1;
    public static double measuredHeight = 1;

    public void getDimention() {
        WindowManager w = getWindowManager();
        VideoParameters.CURRENT_DISPLAY_ROTATION = w.getDefaultDisplay().getRotation();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            Point size = new Point();
            w.getDefaultDisplay().getSize(size);
            measuredWidth = size.x;
            measuredHeight = size.y;
        } else {
            Display d = w.getDefaultDisplay();
            measuredWidth = d.getWidth();
            measuredHeight = d.getHeight();
        }
    }

//    public void togglepipRendererSize() {
//        if (pipRendererSizeInString.equals("SMALL"))
//            makepipRendererBigger();
//        else if (pipRendererSizeInString.equals("MEDIUM"))
//            makepipRendererSmaller();
//    }

    public void startStopSpeaker() {
        if (fullscreenRenderer.getVisibility() != View.VISIBLE && pipRenderer.getVisibility() != View.VISIBLE) {
            speakerFlag = false;
            speakerAction(speakerFlag);
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
            wasSpeakerOnBeforeHeadsetPluggedIn = false;
        } else {
            updateSpeakerStatusIfVideoCall();
        }
    }

    private void updateSpeakerStatusIfVideoCall() {

        if (!localAudioManager.isWiredHeadsetOn() && !isBluetoothHeadsetConnected()) {
            speakerAction(true);
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker_active);

        } else {
            speakerAction(false);
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
            wasSpeakerOnBeforeHeadsetPluggedIn = true;
        }
        speakerFlag = true;
        if (isBluetoothHeadsetConnected())
            resetBluetoothMode();

    }


    private void initAnimations() {
        hideAnimationListener = new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
//                bottomViewGroupContainer.setVisibility(View.GONE);
//                topViewGroupContainer.setVisibility(View.GONE);
                if (fullscreenRenderer.getVisibility() == View.VISIBLE) {
                    videoCallControlButtons.setVisibility(View.GONE);
                    callInfoContainer.setVisibility(View.GONE);
                }


            }
        };

        showAnimationListener = new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (fullscreenRenderer.getVisibility() == View.VISIBLE)
                    reScheduleSlideDownTimer(slideDownTimer, slideDownTimerTask, 5000);
            }
        };

        buttonsHideAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.buttons_slide_down);
        buttonsShowAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.buttons_slide_up);

        buttonsHideAnimation.setAnimationListener(hideAnimationListener);
        buttonsShowAnimation.setAnimationListener(showAnimationListener);

        // Contact & duration animation
        durationContanerLinearLayoutHideAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.duration_slide_up);
        durationContanerLinearLayoutShowAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.duration_slide_down);

        durationContanerLinearLayoutHideAnimation.setAnimationListener(hideAnimationListener);
        durationContanerLinearLayoutShowAnimation.setAnimationListener(showAnimationListener);


        lastTappedTimeInMilisecond = 0;
        slideDownTimer = new Timer(true);
        slideDownTimerTask = new TimerTask() {
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        bottomViewGroupContainer.startAnimation(buttonsHideAnimation);
//                        topViewGroupContainer.startAnimation(durationContanerLinearLayoutHideAnimation);
//

                        videoCallControlButtons.startAnimation(buttonsHideAnimation);
                        callInfoContainer.startAnimation(durationContanerLinearLayoutHideAnimation);
                    }
                });
            }
        };
        if (callConnected && fullscreenRenderer.getVisibility() == View.VISIBLE)
            slideDownTimer.schedule(slideDownTimerTask, 5 * 1000);
    }


    public void reScheduleSlideDownTimer(Timer timer, TimerTask timertask,
                                         final long duration) {
        if (timer != null) {
            timer.cancel();
        }

        if (timertask != null) {
            timertask.cancel();
        }

        timer = new Timer(true);
        timertask = new TimerTask() {
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (isVideoEnabled && callConnected && fullscreenRenderer.getVisibility() == View.VISIBLE && System.currentTimeMillis()
                                    - lastTappedTimeInMilisecond >= duration) {
//                                bottomViewGroupContainer.startAnimation(buttonsHideAnimation);
//                                topViewGroupContainer.startAnimation(durationContanerLinearLayoutHideAnimation);

                                videoCallControlButtons.startAnimation(buttonsHideAnimation);
                                callInfoContainer.startAnimation(durationContanerLinearLayoutHideAnimation);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        };
        if (shouldHideViews()) {
            timer.schedule(timertask, duration);
        }
    }

    public boolean shouldHideViews() {
        if (fullscreenRenderer == null)
            return false;
        return (fullscreenRenderer.getVisibility() == View.VISIBLE);
    }

    public void animateShowViewSliding() {
        lastTappedTimeInMilisecond = System.currentTimeMillis();
        Log.w("SingleTap", "visilibility : " + bottomViewGroupContainer.getVisibility());

        if (buttonsShowAnimation == null) {
            initAnimations();
        }


        if (videoCallControlButtons.getVisibility() == View.INVISIBLE || videoCallControlButtons.getVisibility() == View.GONE) {
            videoCallControlButtons.setVisibility(View.VISIBLE);
            videoCallControlButtons.startAnimation(buttonsShowAnimation);
            if (!isInPictureInPictureMode()) callInfoContainer.setVisibility(View.VISIBLE);
            callInfoContainer.startAnimation(durationContanerLinearLayoutShowAnimation);
        } else if (videoCallControlButtons.getVisibility() == View.VISIBLE) {
            reScheduleSlideDownTimer(slideDownTimer, slideDownTimerTask, 5000);
        }
    }

    private class MySingleTapGestureListener extends
            GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onDown(MotionEvent event) {
            Log.w("VideoCallFrameActivity", "onDown");
//            rlDialPad.setVisibility(View.INVISIBLE);
//            if(isVideoEnabled) {
//                ViewGroup.LayoutParams lp = pipRenderer.getLayoutParams();
//                pipRenderer.setLayoutParams(lp);


//            System.out.println("callConnected:"+callConnected+" isVideoCall"+videoCall+" isVideoEnabled:"+isVideoEnabled);
            if (callConnected && fullscreenRenderer.getVisibility() == View.VISIBLE)
                animateShowViewSliding();


            return true;
        }

        @Override
        public boolean onDoubleTap(MotionEvent e) {
//            fullScreen = !fullScreen;
            fullScreen = true;
            Log.e("Pias", "FullScreen is now " + fullScreen);
            return true;
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
//        if (isVideoEnabled) {
        this.gestureDetector.onTouchEvent(ev);
//        }
        return super.dispatchTouchEvent(ev);
    }

    public void showHideButtonOptions() {
        if (fullscreenRenderer.getVisibility() != View.VISIBLE &&
                pipRenderer.getVisibility() != View.VISIBLE) {
            secondLineButtons.setVisibility(View.VISIBLE);
        } else {
            secondLineButtons.setVisibility(View.INVISIBLE);
        }
        if (isVideoEnabled) {
            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_camrea_off);
        } else {
            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video_call);
        }

    }

    private class HeadSetReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_HEADSET_PLUG)) {
                int state = intent.getIntExtra("state", -1);
                switch (state) {
                    case 0:
                        Log.d("Headset", "Headset unplugged");
                        postBluetoothOrHeadSetDisconnected();
                        break;
                    case 1:
                        Log.d("Headset", "Headset plugged");
                        postBluetoothOrHeadSetConnected();
                        break;
                }
            }
        }
    }


    void postBluetoothOrHeadSetConnected() {
        wasSpeakerOnBeforeHeadsetPluggedIn = speakerFlag;
        speakerFlag = false;
        speakerAction(speakerFlag);
        speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
        findViewById(R.id.speaker_button).setEnabled(false);
    }

    void postBluetoothOrHeadSetDisconnected() {
        speakerFlag = wasSpeakerOnBeforeHeadsetPluggedIn;
        speakerAction(speakerFlag);

        if (!speakerFlag)
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
        else
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker_active);
        findViewById(R.id.speaker_button).setEnabled(true);

    }

    private void Init() {

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        String keyprefResolution = getString(R.string.pref_resolution_key);
        String keyprefFps = getString(R.string.pref_fps_key);
        String keyprefVideoBitrateType = getString(R.string.pref_maxvideobitrate_key);
        String keyprefVideoBitrateValue = getString(R.string.pref_maxvideobitratevalue_key);
        String keyprefAudioBitrateType = getString(R.string.pref_startaudiobitrate_key);
        String keyprefAudioBitrateValue = getString(R.string.pref_startaudiobitratevalue_key);

        boolean loopback = false;

        // Video call enabled flag.
        boolean videoCallEnabled = sharedPrefGetBoolean(R.string.pref_videocall_key, R.string.pref_videocall_default);

        // Use screencapture option.
        boolean useScreencapture = sharedPrefGetBoolean(R.string.pref_screencapture_key, R.string.pref_screencapture_default);

        // Use Camera2 option.
        boolean useCamera2 = sharedPrefGetBoolean(R.string.pref_camera2_key, R.string.pref_camera2_default);

        // Get default codecs.
        String videoCodec = sharedPrefGetString(R.string.pref_videocodec_key, R.string.pref_videocodec_default);
        String audioCodec = sharedPrefGetString(R.string.pref_audiocodec_key, R.string.pref_audiocodec_default);

        // Check HW codec flag.
        boolean hwCodec = sharedPrefGetBoolean(R.string.pref_hwcodec_key, R.string.pref_hwcodec_default);

        // Check Capture to texture.
        boolean captureToTexture = sharedPrefGetBoolean(R.string.pref_capturetotexture_key, R.string.pref_capturetotexture_default);

        // Check FlexFEC.
        boolean flexfecEnabled = sharedPrefGetBoolean(R.string.pref_flexfec_key, R.string.pref_flexfec_default);

        // Check Disable Audio Processing flag.
        boolean noAudioProcessing = sharedPrefGetBoolean(R.string.pref_noaudioprocessing_key, R.string.pref_noaudioprocessing_default);

        // Check Disable Audio Processing flag.
        boolean aecDump = sharedPrefGetBoolean(R.string.pref_aecdump_key, R.string.pref_aecdump_default);

        // Check OpenSL ES enabled flag.
        boolean useOpenSLES = sharedPrefGetBoolean(R.string.pref_opensles_key, R.string.pref_opensles_default);

        // Check Disable built-in AEC flag.
        boolean disableBuiltInAEC = sharedPrefGetBoolean(R.string.pref_disable_built_in_aec_key, R.string.pref_disable_built_in_aec_default);

        // Check Disable built-in AGC flag.
        boolean disableBuiltInAGC = sharedPrefGetBoolean(R.string.pref_disable_built_in_agc_key, R.string.pref_disable_built_in_agc_default);

        // Check Disable built-in NS flag.
        boolean disableBuiltInNS = sharedPrefGetBoolean(R.string.pref_disable_built_in_ns_key, R.string.pref_disable_built_in_ns_default);

        // Check Enable level control.
        boolean enableLevelControl = sharedPrefGetBoolean(R.string.pref_enable_level_control_key, R.string.pref_enable_level_control_default);

        // Check Disable gain control
        boolean disableWebRtcAGCAndHPF = sharedPrefGetBoolean(R.string.pref_disable_webrtc_agc_and_hpf_key, R.string.pref_disable_webrtc_agc_default);

        // Get video resolution from settings.
        int videoWidth = 0;
        int videoHeight = 0;

        String resolution = sharedPref.getString(keyprefResolution, getString(R.string.pref_resolution_default));
        String[] dimensions = resolution.split("[ x]+");
        if (dimensions.length == 2) {
            try {
                videoWidth = Integer.parseInt(dimensions[0]);
                videoHeight = Integer.parseInt(dimensions[1]);
            } catch (NumberFormatException e) {
                videoWidth = 0;
                videoHeight = 0;
                Log.e(TAG, "Wrong video resolution setting: " + resolution);
            }
        }

        // Get camera fps from settings.
        int cameraFps = 0;

        String fps = sharedPref.getString(keyprefFps, getString(R.string.pref_fps_default));
        String[] fpsValues = fps.split("[ x]+");
        if (fpsValues.length == 2) {
            try {
                cameraFps = Integer.parseInt(fpsValues[0]);
            } catch (NumberFormatException e) {
                cameraFps = 0;
                Log.e(TAG, "Wrong camera fps setting: " + fps);
            }
        }

        // Check capture quality slider flag.
        boolean captureQualitySlider = sharedPrefGetBoolean(R.string.pref_capturequalityslider_key, R.string.pref_capturequalityslider_default);

        // Get video and audio start bitrate.
        int videoStartBitrate = 0;
        String bitrateTypeDefault = getString(R.string.pref_maxvideobitrate_default);
        String bitrateType = sharedPref.getString(keyprefVideoBitrateType, bitrateTypeDefault);
        if (!bitrateType.equals(bitrateTypeDefault)) {
            String bitrateValue = sharedPref.getString(
                    keyprefVideoBitrateValue, getString(R.string.pref_maxvideobitratevalue_default));
            videoStartBitrate = Integer.parseInt(bitrateValue);
            Log.e(TAG_NEW, "Init: " + videoStartBitrate);
        }
        Log.e(TAG_NEW, "Init: " + videoStartBitrate);

        int audioStartBitrate = 0;

        String bitrateTypeDefault2 = getString(R.string.pref_startaudiobitrate_default);
        String bitrateType2 = sharedPref.getString(keyprefAudioBitrateType, bitrateTypeDefault2);
        if (!bitrateType2.equals(bitrateTypeDefault2)) {
            String bitrateValue2 = sharedPref.getString(
                    keyprefAudioBitrateValue, getString(R.string.pref_startaudiobitratevalue_default));
            audioStartBitrate = Integer.parseInt(bitrateValue2);
        }

        boolean tracing = sharedPrefGetBoolean(R.string.pref_tracing_key, R.string.pref_tracing_default);

        // Get datachannel options
        boolean dataChannelEnabled = sharedPrefGetBoolean(R.string.pref_enable_datachannel_key, R.string.pref_enable_datachannel_default);
        boolean ordered = sharedPrefGetBoolean(R.string.pref_ordered_key, R.string.pref_ordered_default);
        boolean negotiated = sharedPrefGetBoolean(R.string.pref_negotiated_key, R.string.pref_negotiated_default);
        int maxRetrMs = sharedPrefGetInteger(R.string.pref_max_retransmit_time_ms_key, R.string.pref_max_retransmit_time_ms_default);
        int maxRetr = sharedPrefGetInteger(R.string.pref_max_retransmits_key, R.string.pref_max_retransmits_default);
        int id = sharedPrefGetInteger(R.string.pref_data_id_key, R.string.pref_data_id_default);
        String protocol = sharedPrefGetString(R.string.pref_data_protocol_key, R.string.pref_data_protocol_default);

        infoIntent = new Intent();
        infoIntent.putExtra(EXTRA_LOOPBACK, loopback);
        infoIntent.putExtra(EXTRA_VIDEO_CALL, videoCallEnabled);
        infoIntent.putExtra(EXTRA_SCREENCAPTURE, useScreencapture);
        infoIntent.putExtra(EXTRA_CAMERA2, useCamera2);
        infoIntent.putExtra(EXTRA_VIDEO_WIDTH, videoWidth);
        infoIntent.putExtra(EXTRA_VIDEO_HEIGHT, videoHeight);
        infoIntent.putExtra(EXTRA_VIDEO_FPS, cameraFps);
        infoIntent.putExtra(EXTRA_VIDEO_CAPTUREQUALITYSLIDER_ENABLED, captureQualitySlider);
        infoIntent.putExtra(EXTRA_VIDEO_BITRATE, videoStartBitrate);
        infoIntent.putExtra(EXTRA_VIDEOCODEC, videoCodec);
        infoIntent.putExtra(EXTRA_HWCODEC_ENABLED, hwCodec);
        infoIntent.putExtra(EXTRA_CAPTURETOTEXTURE_ENABLED, captureToTexture);
        infoIntent.putExtra(EXTRA_FLEXFEC_ENABLED, flexfecEnabled);
        infoIntent.putExtra(EXTRA_NOAUDIOPROCESSING_ENABLED, noAudioProcessing);
        infoIntent.putExtra(EXTRA_AECDUMP_ENABLED, aecDump);
        infoIntent.putExtra(EXTRA_OPENSLES_ENABLED, useOpenSLES);
        infoIntent.putExtra(EXTRA_DISABLE_BUILT_IN_AEC, disableBuiltInAEC);
        infoIntent.putExtra(EXTRA_DISABLE_BUILT_IN_AGC, disableBuiltInAGC);
        infoIntent.putExtra(EXTRA_DISABLE_BUILT_IN_NS, disableBuiltInNS);
        infoIntent.putExtra(EXTRA_ENABLE_LEVEL_CONTROL, enableLevelControl);
        infoIntent.putExtra(EXTRA_DISABLE_WEBRTC_AGC_AND_HPF, disableWebRtcAGCAndHPF);
        infoIntent.putExtra(EXTRA_AUDIO_BITRATE, audioStartBitrate);
        infoIntent.putExtra(EXTRA_AUDIOCODEC, audioCodec);
        infoIntent.putExtra(EXTRA_TRACING, tracing);

        infoIntent.putExtra(EXTRA_DATA_CHANNEL_ENABLED, dataChannelEnabled);

        if (dataChannelEnabled) {
            infoIntent.putExtra(EXTRA_ORDERED, ordered);
            infoIntent.putExtra(EXTRA_MAX_RETRANSMITS_MS, maxRetrMs);
            infoIntent.putExtra(EXTRA_MAX_RETRANSMITS, maxRetr);
            infoIntent.putExtra(EXTRA_PROTOCOL, protocol);
            infoIntent.putExtra(EXTRA_NEGOTIATED, negotiated);
            infoIntent.putExtra(EXTRA_ID, id);
        }

        infoIntent.putExtra(EXTRA_CALLERID, caller);
    }

    private String sharedPrefGetString(int attributeId, int defaultId) {
        String defaultValue = getString(defaultId);
        String attributeName = getString(attributeId);
        return sharedPref.getString(attributeName, defaultValue);
    }

    private boolean sharedPrefGetBoolean(int attributeId, int defaultId) {
        boolean defaultValue = Boolean.valueOf(getString(defaultId));
        String attributeName = getString(attributeId);
        return sharedPref.getBoolean(attributeName, defaultValue);
    }

    private int sharedPrefGetInteger(int attributeId, int defaultId) {
        String defaultString = getString(defaultId);
        int defaultValue = Integer.parseInt(defaultString);
        String attributeName = getString(attributeId);
        String value = sharedPref.getString(attributeName, defaultString);
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            Log.e(TAG, "Wrong setting for: " + attributeName + ":" + value);
            return defaultValue;
        }
    }

    @TargetApi(17)
    private DisplayMetrics getDisplayMetrics() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager =
                (WindowManager) getApplication().getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
        return displayMetrics;
    }

    @TargetApi(19)
    private static int getSystemUiVisibility() {
        int flags = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        return flags;
    }


    /**
     * It starts the video capture to save in a file
     */
    @TargetApi(21)
    private void startScreenCapture() {
        MediaProjectionManager mediaProjectionManager =
                (MediaProjectionManager) getApplication().getSystemService(
                        Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(
                mediaProjectionManager.createScreenCaptureIntent(), CAPTURE_PERMISSION_REQUEST_CODE);
    }

    private boolean useCamera2() {
        return Camera2Enumerator.isSupported(this) && infoIntent.getBooleanExtra(EXTRA_CAMERA2, true);
    }

    private boolean captureToTexture() {
        return infoIntent.getBooleanExtra(EXTRA_CAPTURETOTEXTURE_ENABLED, false);
    }

    private VideoCapturer createCameraCapturer(CameraEnumerator enumerator) {
        final String[] deviceNames = enumerator.getDeviceNames();

        // First, try to find front facing camera
        Logging.d(TAG, "Looking for front facing cameras.");
        for (String deviceName : deviceNames) {
            if (enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating front facing camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }

        // Front facing camera not found, try something else
        Logging.d(TAG, "Looking for other cameras.");
        for (String deviceName : deviceNames) {
            if (!enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating other camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }

        return null;
    }

    @TargetApi(21)
    private VideoCapturer createScreenCapturer() {
        if (mediaProjectionPermissionResultCode != Activity.RESULT_OK) {
            reportError("User didn't give permission to capture the screen.");
            return null;
        }
        return new ScreenCapturerAndroid(
                mediaProjectionPermissionResultData, new MediaProjection.Callback() {
            @Override
            public void onStop() {
                reportError("User revoked permission to capture the screen.");
            }
        });
    }

    public void onCameraSwitch() {
        if (peerConnectionClientVideoCall != null) {
            peerConnectionClientVideoCall.switchCamera();
        }
    }

    // Helper functions.
    private void toggleCallControlFragmentVisibility() {
        if (!iceConnected) {
            return;
        }

        callControlContainerVisible = !callControlContainerVisible;
        RelativeLayout fullPageContainer = findViewById(R.id.all_button_holder);
        if (callControlContainerVisible) {
            fullPageContainer.setVisibility(View.VISIBLE);
            fullPageContainer.bringToFront();
        } else {
            fullPageContainer.setVisibility(View.INVISIBLE);
        }
    }

    // Should be called from UI thread
    private void callConnected() {
        final long delta = System.currentTimeMillis() - callStartedTimeMs;
        Log.i(TAG, "Call connected: delay=" + delta + "ms");
        if (peerConnectionClientVideoCall == null || isError) {
            Log.w(TAG, "Call connected in closed or error state");
            return;
        }
        if (videoCall || isVideoEnabled) {
            holdVideoAction(false);
            pipRenderer.setVisibility(View.VISIBLE);
            slideDownTimer.schedule(slideDownTimerTask, 5 * 1000);
        }
        // Enable statistics callback.
        peerConnectionClientVideoCall.enableStatsEvents(true, STAT_CALLBACK_PERIOD);
        setSwappedFeeds(false /* isSwappedFeeds */);
        showHideButtonOptions();

    }

    // This method is called when the audio manager reports audio device change,
    // e.g. from wired headset to speakerphone.
    private void onAudioManagerDevicesChanged(
            final AppRTCAudioManager.AudioDevice device, final Set<AppRTCAudioManager.AudioDevice> availableDevices) {
        Log.d(TAG, "onAudioManagerDevicesChanged: " + availableDevices + ", "
                + "selected: " + device);
        // TODO(henrika): add callback handler.
    }

    // Disconnect from remote resources, dispose of local resources, and exit.
    private void disconnect() {
        remoteProxyRenderer.setTarget(null);
        localProxyRenderer.setTarget(null);
        if (peerConnectionClientVideoCall != null) {
            peerConnectionClientVideoCall.close();
            peerConnectionClientVideoCall = null;
        }
        if (pipRenderer != null) {
            pipRenderer.release();
            pipRenderer = null;
        }
        if (videoFileRenderer != null) {
            videoFileRenderer.release();
            videoFileRenderer = null;
        }
        if (fullscreenRenderer != null) {
            fullscreenRenderer.release();
            fullscreenRenderer = null;
        }
        /*if (audioManager != null) {
            audioManager.stop();
            audioManager = null;
        }*/
    }

    private void holdVideoAction(boolean hold) {
        Log.e(TAG, "holdVideoAction: " + hold);
        if (hold) {
            if (peerConnectionClientVideoCall != null && !screenCaptureEnabled) {
                peerConnectionClientVideoCall.stopVideoSource();
            }
        } else {
            if (peerConnectionClientVideoCall != null && !screenCaptureEnabled) {
                peerConnectionClientVideoCall.startVideoSource();
            }
        }
    }

    /**
     * The UI interchanges between pipRenderer window and on Call video window.
     * witching of the two window is done here.
     *
     * @param isSwappedFeeds : boolean value to determine which window will get full window access.
     */
    private void setSwappedFeeds(boolean isSwappedFeeds) {
        Logging.d(TAG, "setSwappedFeeds: " + isSwappedFeeds);
        this.isSwappedFeeds = isSwappedFeeds;
        localProxyRenderer.setTarget(isSwappedFeeds ? fullscreenRenderer : pipRenderer);
        remoteProxyRenderer.setTarget(isSwappedFeeds ? pipRenderer : fullscreenRenderer);
        fullscreenRenderer.setMirror(isSwappedFeeds);
        pipRenderer.setMirror(!isSwappedFeeds);
    }

    /**
     * On ice connectrion state goes to failed then we temporarily finished the activity
     * Here the Ice Restart procedure have to be implemented.
     *
     * @param description
     */
    private void reportError(final String description) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (!isError) {
                    isError = true;
                    Log.e(TAG_NEW, description);
//                    finish();
                }
            }
        });
    }

    private boolean ifWiredHeadsetOn() {
        AudioManager mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        return (mAudioManager.isWiredHeadsetOn());
    }

    /**
     * This method process the message.
     * It Extract necessary information from the intent message about the call.
     * depending on the caller/ calle information
     * remote SDP / gatherIceInfo / extraction of remote and local ice candidates
     * are done
     *
     * @param msg : the received SDP msg.
     */
    public void processMessage(String msg) {
        Log.i(TAG, "short remote sdp: " + msg);
        if (msg.startsWith("\"")) {
            msg = msg.substring(1);
        }
        if (msg.length() > 1 && msg.endsWith("\"")) {
            msg = msg.substring(0, msg.lastIndexOf("\""));
        }
        List<String> list = new ArrayList<String>(Arrays.asList(msg.split(";")));
        msg = list.get(0);
        if (msg.startsWith("sdp=")) {
            msg = msg.substring("sdp=".length());
        }
        if (msg.equals(localFinalSDP)) {
            return;
        }
        Log.i(TAG, "processed short sdp: " + msg);
        if (msg.length() <= 0) return;

        if (caller) {
            SessionDescription sdp = new SessionDescription(SessionDescription.Type.ANSWER, extendSDP(msg));
            if (!remoteSdpSet) {
                onRemoteDescription(sdp);
                remoteSdpSet = true;
            }
        } else {
            SessionDescription sdp = new SessionDescription(SessionDescription.Type.OFFER, extendSDP(msg));
            if (!remoteSdpSet) {
                gatherICEInfo(sdp);
                remoteSdpSet = true;
            }
        }
    }

    /**
     * The Generated SDP message is compressed and
     * default constant portion is discarded as unnecessary part.
     * Later on , on the receiver part this SDP is constructed as it is now.
     * Mo0re liuke encoding part of the SDP message.
     *
     * @param sdp : The Raw Generated SDP message by webRTC API.
     * @return String SDP as normalized compressed forms.
     */
    public String normalizeSDP(String sdp) {
        String newSDP = "";
        List<String> list = new ArrayList<String>(Arrays.asList(sdp.split("\r\n")));
        for (String s : list) {
            if (s.length() >= 10) {
                if (s.contains("rtpmap") && s.contains("VP8")) {
                    List<String> tempList = new ArrayList<String>(Arrays.asList(s.split(" ")));
                    newSDP = tempList.get(0).substring(9) + "," + newSDP;
                    break;
                } else if (s.substring(0, 5).equals("a=ice")) {
                    if (s.substring(0, 7).equals("a=ice-u")) {
                        newSDP = newSDP + s.substring(12) + ",";
                    } else if (s.substring(0, 7).equals("a=ice-p")) {
                        newSDP = newSDP + s.substring(10) + ",";
                    }
                } else if (s.substring(0, 8).equals("a=finger")) {
                    List<String> tempList = new ArrayList<String>(Arrays.asList(s.split(" ")));
                    newSDP = newSDP + tempList.get(1).replace(":", "") + ",";
                } else if (s.substring(0, 7).equals("a=setup")) {
                    newSDP = newSDP + s.substring(8) + ",";
                }
            }
        }
//        for (String s : localCandidateList) {
//            List<String> tempList = new ArrayList<String>(Arrays.asList(s.split(" ")));
//            String tempCandidate = "";
//            tempCandidate = tempCandidate + tempList.get(0).substring(10, tempList.get(0).length()) + " ";
//            tempCandidate = tempCandidate + tempList.get(1) + " " + tempList.get(2) + " " + tempList.get(3) + " " + tempList.get(4) + " " + tempList.get(5) + " " + tempList.get(7);
//            if (!tempList.get(7).equals("host")) {
//                tempCandidate = tempCandidate + " " + tempList.get(9) + " " + tempList.get(11);
//            }
//            newSDP = newSDP + tempCandidate + ",";
//        }
        newSDP = newSDP.substring(0, newSDP.length() - 1);
        return newSDP;
    }

    /**
     * Returns the extended SDP message received from the MESSAGE.
     * The Message is extended according to the prescribed format.
     * format: https://webrtchacks.com/sdp-anatomy/ (For general idea)
     *
     * @param sdp : The compressed SDP message.
     * @return String formatted extended SDP message.
     */
    String localMid = "0";

    public String extendSDP(String sdp) {
        List<String> list = new ArrayList<String>(Arrays.asList(sdp.split(",")));
        String newSDP = "v=0\r\no=- 1234567890123456789 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE " + localMid + "\r\nm=video 9 UDP/TLS/RTP/SAVPF " + list.get(0) + "\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\n";
        newSDP = newSDP + "a=ice-ufrag:" + list.get(1) + "\r\n";
        newSDP = newSDP + "a=ice-pwd:" + list.get(2) + "\r\n";
        newSDP = newSDP + "a=ice-options:trickle renomination\r\n";
        String fingerPrint = "";
        for (int i = 0; i < list.get(3).length(); i += 2) {
            fingerPrint = fingerPrint + list.get(3).substring(i, i + 2) + ":";
        }
        fingerPrint = fingerPrint.substring(0, fingerPrint.length() - 1);
        newSDP = newSDP + "a=fingerprint:sha-256 " + fingerPrint + "\r\n";
        newSDP = newSDP + "a=setup:" + list.get(4) + "\r\n";
        newSDP = newSDP + "a=mid:" + localMid + "\r\na=extmap:2 urn:ietf:params:rtp-hdrext:toffset\r\na=extmap:3 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:4 urn:3gpp:video-orientation\r\na=extmap:5 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:6 http://www.webrtc.org/experiments/rtp-hdrext/playout-delay\r\na=sendrecv\r\na=rtcp-mux\r\na=rtcp-rsize\r\n";
        String no = list.get(0);
        newSDP = newSDP + "a=rtpmap:" + no + " VP8/90000\r\na=rtcp-fb:" + no + " ccm fir\r\na=rtcp-fb:" + no + " nack\r\na=rtcp-fb:" + no + " nack pli\r\na=rtcp-fb:" + no + " goog-remb\r\na=rtcp-fb:" + no + " transport-cc\r\n";

        Log.e(TAG, "extendSDP: " + newSDP);
//        for (int i = 5; i < list.size(); i++) {
//            String s = list.get(i);
//            List<String> tempList = new ArrayList<String>(Arrays.asList(s.split(" ")));
//            String tempCandidate = "";
//            tempCandidate = tempCandidate + "candidate:" + tempList.get(0) + " " + tempList.get(1) + " " + tempList.get(2) + " " + tempList.get(3) + " " + tempList.get(4) + " " + tempList.get(5) + " typ " + tempList.get(6) + " ";
//            if (tempList.size() > 7) {
//                tempCandidate = tempCandidate + "raddr " + tempList.get(7) + " rport " + tempList.get(8) + " ";
//            }
//            tempCandidate = tempCandidate + "generation 0 ufrag " + list.get(1) + " network-id 3 network-cost 10";
//            if (!remoteCandidateList.contains(tempCandidate)) {
//                remoteCandidateList.add(tempCandidate);
//            }
//
//        }
        return newSDP;
    }

    /**
     * it sends a broiadcast message to dialer service7
     *
     * @param number   : number of the caller_id
     * @param identity : identity of the caller_id
     */
    public void sendInviteForVideoCall(String number, String identity) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("startvideocallnew", number);
        intent.putExtra(Constants.BROADCAST_MESSAGE_CALLID, callID);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    /**
     * it sends a broiadcast message to dialer service7
     *
     * @param number   : number of the caller_id
     * @param identity : identity of the caller_id
     */
    public void sendInviteForCall(String number, String identity) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("startcallnew", number);
        intent.putExtra(Constants.BROADCAST_MESSAGE_CALLID, callID);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    /**
     * it sends a broiadcast message to dialer service7
     *
     * @param number   : number of the caller_id
     * @param identity : identity of the caller_id
     */
    public void sendInviteForPaidCall(String number, String identity) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("startpaidcallnew", number);
        intent.putExtra(Constants.BROADCAST_MESSAGE_CALLID, callID);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    /**
     * it sends a broiadcast message to dialer service7
     *
     * @param callID : number of the caller_id
     */
    public void send183forCallid(String callID) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("send183forcallid", callID);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void showCallDisconnectionDialog(String message) {
//        if (message != null && message.length() > 0) {
//            dialogShown = true;
//            Intent intent = new Intent(this, CallFinishedDialog.class);
//            intent.putExtra(CallFinishedDialog.NUMBER, number);
//            intent.putExtra(CallFinishedDialog.MESSAGE, message);
//            if (callAccepted)
//                intent.putExtra(CallFinishedDialog.SHOW_DURATION, timerText.getText().toString());
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//            startActivity(intent);
//        }
        finish();
    }

    private void AcceptCall() {
        callAccepted = true;
        cancelIncomingCallNotification();
        showRunningCallNotification(number);
    }

    private void EndCall() {
        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL, Constants.BROADCAST_MESSAGE_REJECT);
    }

    /* Defining the extras used to save turnInfo in intent */
    public static final String EXTRA_SDP = "apprtc.SDP";
    public static final String EXTRA_CANDIDATE = "apprtc.ICE_CANDIDATE";
    public static final String EXTRA_CALLERID = "apprtc.CALLERID";
    public static final String EXTRA_LOOPBACK = "apprtc.LOOPBACK";
    public static final String EXTRA_VIDEO_CALL = "apprtc.VIDEO_CALL";
    public static final String EXTRA_SCREENCAPTURE = "apprtc.SCREENCAPTURE";
    public static final String EXTRA_CAMERA2 = "apprtc.CAMERA2";
    public static final String EXTRA_VIDEO_WIDTH = "apprtc.VIDEO_WIDTH";
    public static final String EXTRA_VIDEO_HEIGHT = "apprtc.VIDEO_HEIGHT";
    public static final String EXTRA_VIDEO_FPS = "apprtc.VIDEO_FPS";
    public static final String EXTRA_VIDEO_CAPTUREQUALITYSLIDER_ENABLED = "apprtc.VIDEO_CAPTUREQUALITYSLIDER";
    public static final String EXTRA_VIDEO_BITRATE = "apprtc.VIDEO_BITRATE";
    public static final String EXTRA_VIDEOCODEC = "apprtc.VIDEOCODEC";
    public static final String EXTRA_HWCODEC_ENABLED = "apprtc.HWCODEC";
    public static final String EXTRA_CAPTURETOTEXTURE_ENABLED = "apprtc.CAPTURETOTEXTURE";
    public static final String EXTRA_FLEXFEC_ENABLED = "apprtc.FLEXFEC";
    public static final String EXTRA_AUDIO_BITRATE = "apprtc.AUDIO_BITRATE";
    public static final String EXTRA_AUDIOCODEC = "apprtc.AUDIOCODEC";
    public static final String EXTRA_NOAUDIOPROCESSING_ENABLED = "apprtc.NOAUDIOPROCESSING";
    public static final String EXTRA_AECDUMP_ENABLED = "apprtc.AECDUMP";
    public static final String EXTRA_OPENSLES_ENABLED = "apprtc.OPENSLES";
    public static final String EXTRA_DISABLE_BUILT_IN_AEC = "apprtc.DISABLE_BUILT_IN_AEC";
    public static final String EXTRA_DISABLE_BUILT_IN_AGC = "apprtc.DISABLE_BUILT_IN_AGC";
    public static final String EXTRA_DISABLE_BUILT_IN_NS = "apprtc.DISABLE_BUILT_IN_NS";
    public static final String EXTRA_ENABLE_LEVEL_CONTROL = "apprtc.ENABLE_LEVEL_CONTROL";
    public static final String EXTRA_DISABLE_WEBRTC_AGC_AND_HPF = "apprtc.DISABLE_WEBRTC_GAIN_CONTROL";
    public static final String EXTRA_TRACING = "apprtc.TRACING";
    public static final String EXTRA_VIDEO_FILE_AS_CAMERA = "apprtc.VIDEO_FILE_AS_CAMERA";
    public static final String EXTRA_SAVE_REMOTE_VIDEO_TO_FILE = "apprtc.SAVE_REMOTE_VIDEO_TO_FILE";
    public static final String EXTRA_SAVE_REMOTE_VIDEO_TO_FILE_WIDTH = "apprtc.SAVE_REMOTE_VIDEO_TO_FILE_WIDTH";
    public static final String EXTRA_SAVE_REMOTE_VIDEO_TO_FILE_HEIGHT = "apprtc.SAVE_REMOTE_VIDEO_TO_FILE_HEIGHT";
    public static final String EXTRA_DATA_CHANNEL_ENABLED = "apprtc.DATA_CHANNEL_ENABLED";
    public static final String EXTRA_ORDERED = "apprtc.ORDERED";
    public static final String EXTRA_MAX_RETRANSMITS_MS = "apprtc.MAX_RETRANSMITS_MS";
    public static final String EXTRA_MAX_RETRANSMITS = "apprtc.MAX_RETRANSMITS";
    public static final String EXTRA_PROTOCOL = "apprtc.PROTOCOL";
    public static final String EXTRA_NEGOTIATED = "apprtc.NEGOTIATED";
    public static final String EXTRA_ID = "apprtc.ID";

    private EglBase rootEglBase;
    private SurfaceViewRenderer pipRenderer;
    private SurfaceViewRenderer fullscreenRenderer;
    private VideoFileRenderer videoFileRenderer;
    private final List<VideoSink> remoteSinks = new ArrayList<>();

    private PeerConnectionClientVideoCall.PeerConnectionParameters peerConnectionParameters;
    private boolean iceConnected;
    private boolean isError;
    private boolean callControlContainerVisible = true;
    private long callStartedTimeMs = 0;
    private boolean screenCaptureEnabled = false;
    private static Intent mediaProjectionPermissionResultData;
    private static int mediaProjectionPermissionResultCode;

    // True if local view is in the fullscreen renderer.
    private boolean isSwappedFeeds;

    public static boolean readyToReceiveBroadcast = false;
    public List<String> localCandidateList = new ArrayList<String>();
    public static List<String> remoteCandidateList = new ArrayList<>();
    public String localTempSDP = "";
    public boolean remoteSdpSet = false;
    public int remoteCandidateSoFar = 0;
    private SharedPreferences sharedPref;
    private Intent infoIntent;
    /* List of mandatory application permissions. */
    private static final String[] MANDATORY_PERMISSIONS = {"android.permission.MODIFY_AUDIO_SETTINGS",
            "android.permission.RECORD_AUDIO", "android.permission.INTERNET"};

    public static String getLocalFinalSDP() {
//        if (callAccepted || caller) return localFinalSDP;
//        else return "";
        return localFinalSDP;
    }

    public static void setRemoteSDP(String sdpMsg) {
        remoteSDP = sdpMsg;
    }

    /**
     * This method Gather the ice turnInfo like the ip address and port of the STUN and TURN servers.
     * We used KOTURN which is used as both STUN and TURN servers.
     * so both TURN and STUN servers are same here.
     * We parse the string and and set the signaling parameters.
     * Then we call onConnectedToRoomInternal with the signalling parameters
     *
     * @param sdp
     */
    public void gatherICEInfo(SessionDescription sdp) {
        try {

            String jSonString = "{\n" +
                    "   \"iceServers\":[\n" +
                    "      {\n" +
                    "         \"urls\":[\n" +
                    "            \"turn:" + SIPProvider.getStunInfo().turnServerIP.toString() + ":" + SIPProvider.getStunInfo().turnServerPort + "\"\n" +
                    "         ],\n" +
                    "         \"username\":\"" + SIPProvider.getStunInfo().turnServerUserName.toString() + "\",\n" +
                    "         \"credential\":\"" + SIPProvider.getStunInfo().turnServerPassword.toString() + "\"\n" +
                    "      },\n" +
                    "      {\n" +
                    "         \"urls\":[\n" +
                    "            \"stun:" + SIPProvider.getStunInfo().turnServerIP.toString() + ":" + SIPProvider.getStunInfo().turnServerPort + "\"\n" +
                    "         ]\n" +
                    "      }\n" +
                    "   ]\n" +
                    "}";

//			String jSonString = "{\n" +
//					"   \"iceServers\":[\n" +
//					"      {\n" +
//					"         \"urls\":[\n" +
//					"            \"turn:213.251.215.85:3479\"\n" +
//					"         ],\n" +
//					"         \"username\":\"reve\",\n" +
//					"         \"credential\":\"devel\"\n" +
//					"      },\n" +
//					"      {\n" +
//					"         \"urls\":[\n" +
//					"            \"stun:213.251.215.85:3479\"\n" +
//					"         ]\n" +
//					"      }\n" +
//					"   ]\n" +
//					"}";

            Log.i(TAG, "ICEServerInfo: " + jSonString);
            LinkedList<PeerConnection.IceServer> iceServers = new LinkedList<>();
            JSONObject responseJSON = new JSONObject(jSonString);
            JSONArray iceServersArray = responseJSON.getJSONArray("iceServers");
            for (int i = 0; i < iceServersArray.length(); ++i) {
                JSONObject server = iceServersArray.getJSONObject(i);
                JSONArray turnUrls = server.getJSONArray("urls");
                String username = server.has("username") ? server.getString("username") : "";
                String credential = server.has("credential") ? server.getString("credential") : "";
                for (int j = 0; j < turnUrls.length(); j++) {
                    String turnUrl = turnUrls.getString(j);
                    iceServers.add(new PeerConnection.IceServer(turnUrl, username, credential));
//                    iceServers.add(new PeerConnection.IceServer(turnUrl));
                }
            }

            SignalingParameters params = new SignalingParameters(
                    iceServers, caller, sdp, null);
            onConnectedToRoomInternal(params);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * Remote SDP is set here and return answer is called to make.
     *
     * @param sdp : Remote SDP received from the caller.
     */
    public void onRemoteDescription(final SessionDescription sdp) {
        final long delta = System.currentTimeMillis() - callStartedTimeMs;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (peerConnectionClientVideoCall == null) {
                    Log.e(TAG, "Received remote SDP for non-initilized peer connection.");
                    return;
                }
                Log.d(TAG, "Received remote " + sdp.type + ", delay=" + delta + "ms");
                peerConnectionClientVideoCall.setRemoteDescription(sdp);
                if (!signalingParameters.initiator) {
                    Log.d(TAG, "Creating ANSWER...");
                    // Create answer. Answer SDP will be sent to offering client in
                    // PeerConnectionEvents.onLocalDescription event.
                    peerConnectionClientVideoCall.createAnswer();
                }
            }
        });
    }

    /**
     * -----Implementation of AppRTCClient.AppRTCSignalingEvents ---------------
     * ALL callbacks are invoked from websocket signaling looper thread and
     * are routed to UI thread.
     * With the signal parameters we initialize peerConnectionClientVideoCall
     * then depending on the caller / calle we initialize offer/ answer
     *
     * @param params
     */
    private void onConnectedToRoomInternal(final SignalingParameters params) {
        final long delta = System.currentTimeMillis() - callStartedTimeMs;

        signalingParameters = params;
        VideoCapturer videoCapturer = null;
        if (peerConnectionParameters.videoCallEnabled) {
            videoCapturer = createVideoCapturer();
        }
        peerConnectionClientVideoCall.createPeerConnection(
                localProxyRenderer, remoteSinks, videoCapturer, signalingParameters);

        if (signalingParameters.initiator) {
            Log.d(TAG, "Creating OFFER...");
            peerConnectionClientVideoCall.createOffer();
        } else {
            if (params.offerSdp != null) {
                peerConnectionClientVideoCall.setRemoteDescription(params.offerSdp);
                peerConnectionClientVideoCall.createAnswer();
            }
            if (params.iceCandidates != null) {
                for (IceCandidate iceCandidate : params.iceCandidates) {
                    peerConnectionClientVideoCall.addRemoteIceCandidate(iceCandidate);
                }
            }
        }
    }
    /**
     * Remote SDP is set here and return answer is called to make.
     * @param sdp : Remote SDP received from the caller.
     */

    /**
     * Methiod toi call peerConnectionClientVideoCall.addRemoteIceCandidate(candidate) in a runnable.
     *
     * @param candidate : Generated Candidate from the SDP message.
     */
    public void onRemoteIceCandidate(final IceCandidate candidate) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (peerConnectionClientVideoCall == null) {
                    Log.e(TAG, "Received ICE candidate for a non-initialized peer connection.");
                    return;
                }
                peerConnectionClientVideoCall.addRemoteIceCandidate(candidate);
            }
        });
    }

    public void onRemoteIceCandidatesRemoved(final IceCandidate[] candidates) {
        runOnUiThread(() -> {
            if (peerConnectionClientVideoCall == null) {
                Log.e(TAG, "Received ICE candidate removals for a non-initialized peer connection.");
                return;
            }
            Log.w(TAG, "onRemoteIceCandidatesRemoved removed candidates: " + Arrays.toString(candidates));
            peerConnectionClientVideoCall.removeRemoteIceCandidates(candidates);
        });
    }


    private VideoCapturer createVideoCapturer() {
        VideoCapturer videoCapturer = null;
        String videoFileAsCamera = getIntent().getStringExtra(EXTRA_VIDEO_FILE_AS_CAMERA);
        if (videoFileAsCamera != null) {
            try {
                videoCapturer = new FileVideoCapturer(videoFileAsCamera);
            } catch (IOException e) {
                reportError("Failed to open video file for emulated camera");
                return null;
            }
        } else if (screenCaptureEnabled) {
            return createScreenCapturer();
        } else if (useCamera2()) {
            if (!captureToTexture()) {
                reportError(getString(R.string.camera2_texture_only_error));
                return null;
            }

            Logging.d(TAG, "Creating capturer using camera2 API.");
            videoCapturer = createCameraCapturer(new Camera2Enumerator(this));
        } else {
            Logging.d(TAG, "Creating capturer using camera1 API.");
            videoCapturer = createCameraCapturer(new Camera1Enumerator(captureToTexture()));
        }
        if (videoCapturer == null) {
            reportError("Failed to open camera");
            return null;
        }
        return videoCapturer;
    }

    /**
     * To set the temporary local SDP
     *
     * @param sdp : created SDP setting to local Description field
     */
    @Override
    public void onLocalDescription(final SessionDescription sdp) {
        final long delta = System.currentTimeMillis() - callStartedTimeMs;
        runOnUiThread(() -> {

            localTempSDP = sdp.description;
            Log.e("LocalSDP", localTempSDP);
            Log.e(TAG_NEW, "Local SDP set: ");
            if (peerConnectionParameters.videoMaxBitrate > 0) {
                Log.d(TAG, "Set video maximum bitrate: " + peerConnectionParameters.videoMaxBitrate);
                peerConnectionClientVideoCall.setVideoMaxBitrate(peerConnectionParameters.videoMaxBitrate);
            }

            Log.v(TAG_NEW, "full generated SDP: length: " + localTempSDP.length() + " Mesage: \n" + localTempSDP);
            localFinalSDP = normalizeSDP(localTempSDP);
            Log.i(TAG, "FinalSDP : length: " + localFinalSDP.length() + " Message: " + localFinalSDP);

            if (caller) {
                if (videoCall) {
                    sendInviteForVideoCall(number, identity);
                } else if (paidCall) {
                    sendInviteForPaidCall(number, identity);
                } else {
                    sendInviteForCall(number, identity);
                }
            } else if (SIPProvider.callState != CallState._200_OK) {
//					send183forCallid(callID);
                CallUtil.sendCandidateInfoBroadcast(CallFrameGUIActivityAppRTC.this, number, callID, "sdp=" + localFinalSDP);
            }
        });
    }

    /**
     * On creating each ice candidate this method gets called. It checks the completeness of creating the
     * iceCandidate. And then it sends message to dialer.
     *
     * @param candidate : generated candidates
     */
    @Override
    public void onIceCandidate(final IceCandidate candidate) {
        Log.e(TAG, "ICECandidate " + candidate.toString());
        runOnUiThread(() -> {
//                localCandidateList.add(candidate.sdp);
//                Log.v(TAG_NEW, "full generated SDP: "+ localTempSDP.toString() );
//                localFinalSDP = normalizeSDP(localTempSDP);
//                Log.i(TAG, "FinalSDP "+ localFinalSDP);
//                if (caller && peerConnectionClientVideoCall.getIceGatheringState().equals(PeerConnection.IceGatheringState.COMPLETE)){
//                    sendInviteForVideoCall(number, identity);
//                }
//                if(!caller && callAccepted && peerConnectionClientVideoCall.getIceGatheringState().equals(PeerConnection.IceGatheringState.COMPLETE)){
//                    sendInviteForVideoCall(number, identity);
//                }
            if (caller && (SIPProvider.callState == CallState.INVITE || SIPProvider.callState == CallState.READY || SIPProvider.callState == CallState._180_RING)) {
                localCandidateList.add(ICECandidateUtilVideoCall.getJSONFromICECandidate(candidate));
                Log.i(TAG, "Saving ice candidate in local list: " + candidate.toString());
            } else {
                CallUtil.sendCandidateInfoBroadcast(CallFrameGUIActivityAppRTC.this, number, callID, ICECandidateUtilVideoCall.getJSONFromICECandidate(candidate));
                Log.i(TAG, "Sending ice candidate " + candidate.toString());
            }
        });
    }

    @Override
    public void onIceCandidatesRemoved(final IceCandidate[] candidates) {
        runOnUiThread(() -> {
            Log.w(TAG, "onIceCandidatesRemoved removed candidates: " + Arrays.toString(candidates));
            if (caller && (SIPProvider.callState == CallState.INVITE || SIPProvider.callState == CallState.READY)) {
                localCandidateList.add(ICECandidateUtilVideoCall.getJSONArrayFromICECandidates(candidates));
            } else {
                CallUtil.sendCandidateInfoBroadcast(CallFrameGUIActivityAppRTC.this, number, callID, ICECandidateUtilVideoCall.getJSONArrayFromICECandidates(candidates));
                Log.w(TAG, "Sending ice candidate for removing: size: " + (ICECandidateUtilVideoCall.getJSONArrayFromICECandidates(candidates).length() + 8) + " Data: " + ICECandidateUtilVideoCall.getJSONArrayFromICECandidates(candidates));
            }
        });
    }

    @Override
    public void onIceConnected() {
        final long delta = System.currentTimeMillis() - callStartedTimeMs;
        runOnUiThread(() -> {
            Log.w(TAG, "ICE Call connected, delay=" + delta + "ms");
            iceConnected = true;
            if (videoCall || isVideoEnabled) {
                holdVideoAction(false);
            } else {
                holdVideoAction(true);
            }
            if (SIPProvider.callState != CallState._200_OK) {
                pipRenderer.setVisibility(View.GONE);
                holdVideoAction(true);
            }
        });
    }

    boolean iceDisconnectedForNetwork = false;

    /**
     * This method is called when ice connection goes to Disconnected state. temporarily
     */
    @Override
    public void onIceDisconnected() {
        runOnUiThread(() -> {
            Log.w(TAG_NEW, "ICE disconnected");
            iceConnected = false;
            if (!dialogShown) {
                String message = "Poor internet connection";
                Log.e(TAG_NEW, "message : " + message);
            }
        });
    }

    @Override
    public void onPeerConnectionClosed() {
        Log.w(TAG_NEW, "onPeerConnectionClosed");
    }

    @Override
    public void onPeerConnectionStatsReady(final StatsReport[] reports) {
        runOnUiThread(() -> {
            if (!isError && iceConnected) {
                Log.w(TAG_NEW, "onPeerConnectionStatsReady");
            }
        });
    }

    @Override
    public void onPeerConnectionError(final String description) {
        reportError(description);
    }

    private final ProxyVideoSink remoteProxyRenderer = new ProxyVideoSink();
    private final ProxyVideoSink localProxyRenderer = new ProxyVideoSink();
    private PeerConnectionClientVideoCall peerConnectionClientVideoCall = null;
    private SignalingParameters signalingParameters;

    private void setRemoteICECandidate(String candidate) {
        try {
            Logging.d(TAG, "setRemoteICECandidate: " + candidate);
            onRemoteIceCandidate(ICECandidateUtilVideoCall.getICECandidateFromJSON(candidate));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setRemoteICECandidateForRemoving(String candidate) {
        try {
            Logging.d(TAG, "setRemoteICECandidateForRemoving: " + candidate);
            onRemoteIceCandidatesRemoved(ICECandidateUtilVideoCall.getICECandidatesFromJSONArray(candidate));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class CallInfoHolder {
        View llCallInfoHolder;
        TextView tvCallName;
        TextView tvCallStatus;
        String callID;
        String number;
        String name;
    }

    private void prepareCallInfoHolder(String callID, String number) {
        if (TextUtils.isEmpty(callID) || TextUtils.isEmpty(number) || callInfoMap.containsKey(callID))
            return;

        CallInfoHolder holder = new CallInfoHolder();


        View container = View.inflate(this, R.layout.call_info_layout, null);

        holder.llCallInfoHolder = container;
        holder.tvCallName = container.findViewById(R.id.nametview);
        holder.tvCallStatus = container.findViewById(R.id.statustview);

        holder.callID = callID;
        holder.number = number;
        if (Util.isValidEmail(Util.getProperEmail(number))) {
            holder.name = ContactEngine.getContactNamefromEmail(this, number);
        } else {
            holder.name = ContactEngine.getContactNamefromNumber(this, number);
        }
        if (TextUtils.isEmpty(holder.name))
            holder.name = Util.getProperEmail(holder.number);

        holder.tvCallName.setText(holder.name);

        callInfoContainer.addView(holder.llCallInfoHolder);
        callInfoMap.put(callID, holder);

        handleCallButtonVisibility();
    }

    private void prepareCallInfoHolder(String callID) {
        if (callInfoMap.containsKey(callID))
            return;
        CallManager callManager = CallManager.getCallManager();
        if (callManager == null)
            return;
        if (callManager.getCallIDs().size() == 0) {
            finish();
            return;
        }
        CallParameters callParameters = callManager.getCall(callID);
        if (callParameters == null)
            return;

        CallInfoHolder holder = new CallInfoHolder();


        View container = View.inflate(this, R.layout.call_info_layout, null);

        holder.llCallInfoHolder = container;
        holder.tvCallName = container.findViewById(R.id.nametview);
        holder.tvCallStatus = container.findViewById(R.id.statustview);

        holder.callID = callID;
        holder.number = callParameters.dialedNumber.toString();
        holder.name = CommonData.contactNumberToContactName.get(holder.number);
        if (TextUtils.isEmpty(holder.name))
            holder.name = Util.getProperEmail(callParameters.dialedNumber.toString());

        holder.tvCallName.setText(holder.name);

        callInfoContainer.addView(holder.llCallInfoHolder);
        callInfoMap.put(callID, holder);


        handleCallButtonVisibility();
    }

    final ArrayList<String> currentNumbers = new ArrayList<>();

    private void prepareCallInfoHolderForConference(String callID, String[] numbers) {
        currentNumbers.clear();
        currentNumbers.addAll(Arrays.asList(numbers));

        callInfoContainer.removeAllViews();
        callInfoMap.clear();

        CallInfoHolder holder = new CallInfoHolder();

        View container = View.inflate(this, R.layout.call_info_layout, null);

        holder.llCallInfoHolder = container;
        holder.tvCallName = container.findViewById(R.id.nametview);
        holder.tvCallStatus = container.findViewById(R.id.statustview);

        holder.callID = callID;
        String name;
        holder.name = "";
        for (String number : numbers) {
            holder.number = holder.number + (number + ",");
            name = ContactEngine.getContactNamefromNumber(this, number);
            if (TextUtils.isEmpty(name))
                name = number;

            holder.name = holder.name + (name + " & ");
        }

        holder.name = holder.name.substring(0, holder.name.length() - 3);

        holder.tvCallName.setText(holder.name);

        callInfoContainer.addView(holder.llCallInfoHolder);
        callInfoMap.put(callID, holder);

        handleCallButtonVisibility();
    }

    private void removeCallInfoHolder(String callID) {
        if (!callInfoMap.containsKey(callID))
            return;

        CallInfoHolder holder = callInfoMap.remove(callID);

        if (holder != null) {
            callInfoContainer.removeView(holder.llCallInfoHolder);
        }

        handleCallButtonVisibility();
    }

    boolean wasCallInfoEverGreaterThanOne;



    private void handleCallButtonVisibility() {
        if (callInfoMap.size() > 1) {
            wasCallInfoEverGreaterThanOne = true;
            findViewById(R.id.ll_add_conference_member).setEnabled(false);
            findViewById(R.id.btn_add_conference_member).setAlpha(0.4f);
            findViewById(R.id.ll_call_merge).setEnabled(true);
            findViewById(R.id.btn_call_merge).setAlpha(1.0f);

            findViewById(R.id.video_camera_switch_container).setVisibility(View.GONE);
            findViewById(R.id.call_switch_button_container).setVisibility(View.VISIBLE);
            findViewById(R.id.video_switch_button_container).setVisibility(View.GONE);

            findViewById(R.id.btn_call_transfer).setEnabled(false);
            findViewById(R.id.btn_call_transfer).setAlpha(0.4f);


        } else {
            findViewById(R.id.video_switch_button_container).setVisibility(View.VISIBLE);

            if (!isVideoEnabled) {
                findViewById(R.id.ll_add_conference_member).setEnabled(true);
                findViewById(R.id.btn_add_conference_member).setAlpha(1.0f);
            } else {
                findViewById(R.id.ll_add_conference_member).setEnabled(false);
                findViewById(R.id.btn_add_conference_member).setAlpha(0.4f);
            }
            findViewById(R.id.ll_call_merge).setEnabled(false);
            findViewById(R.id.btn_call_merge).setAlpha(0.4f);
            findViewById(R.id.call_switch_button_container).setVisibility(View.GONE);
            findViewById(R.id.video_camera_switch_container).setVisibility(View.VISIBLE);

            if (!wasCallInfoEverGreaterThanOne) {

                findViewById(R.id.video_switch_button_container).setEnabled(true);
                findViewById(R.id.video_switch_button).setAlpha(1.0f);
                findViewById(R.id.video_switch_button).setEnabled(true);
                if (isIncomingCall) {
                    findViewById(R.id.btn_call_transfer).setEnabled(true);
                    findViewById(R.id.btn_call_transfer).setAlpha(1.0f);
                } else {
                    findViewById(R.id.btn_call_transfer).setEnabled(false);
                    findViewById(R.id.btn_call_transfer).setAlpha(0.4f);
                }

            } else {
                findViewById(R.id.video_switch_button_container).setEnabled(false);
                findViewById(R.id.video_switch_button).setAlpha(0.4f);
                findViewById(R.id.video_switch_button).setEnabled(false);
                findViewById(R.id.btn_call_transfer).setEnabled(false);
                findViewById(R.id.btn_call_transfer).setAlpha(0.4f);
            }


        }
    }
}