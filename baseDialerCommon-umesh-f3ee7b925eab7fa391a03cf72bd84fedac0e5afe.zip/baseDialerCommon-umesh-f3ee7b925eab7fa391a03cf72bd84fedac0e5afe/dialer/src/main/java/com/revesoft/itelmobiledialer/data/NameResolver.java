package com.revesoft.itelmobiledialer.data;


import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

/**
 * @author Ifta on 2/4/2018.
 */

public class NameResolver {
    public static String getContactNameFromNumberOrEmail(String numberOrEmail) {
        if (UserDataManager.getUserName().equals(numberOrEmail)) {
            return Supplier.getString(R.string.you).replace(":", "");
        }
        if (CommonData.contactNumberToContactName.containsKey(numberOrEmail)) {
            return CommonData.contactNumberToContactName.get(numberOrEmail);
        }
        return Util.isValidEmail(Util.getProperEmail(numberOrEmail)) ? Util.getProperEmail(numberOrEmail) : numberOrEmail;
    }

    public static String getGroupNameById(String groupId) {
        if (true) return "start group info loader first";
        if (CommonData.groupIdToGroupName.containsKey(groupId)) {
            return CommonData.groupIdToGroupName.get(groupId);
        }
        return Supplier.getString(R.string.groupChat);
    }
}
