package com.revesoft.itelmobiledialer.ims.IMUtil;

/**
 * @author Ifta on 10/25/2017.
 */

public class EmojiHelper {
//    private static  final String regex = "([\\u20a0-\\u32ff\\ud83c\\udc00-\\ud83d\\udeff\\udbb9\\udce5-\\udbb9\\udcee]*)";
//private static  final String regex = "([\\u20a0-\\u32ff\\ud83c\\udc00-\\ud83d\\udeff\\udbb9\\udce5-\\udbb9\\udcee\\\uD83E\uDD13\uD83E\uDD11]*)";
//private static final String regex = "([\\u20a0-\\u32ff\\ud83c\\udc00-\\ud83d\\udeff\\udbb9\\udce5-\\udbb9\\udcee\\uDD13\\uD83E\\uDD11\\u1F912\\u1F915\\u1f91\\u1F916\\u1F914\\u1F917]*)";
private static final String regex = "([\\u20a0-\\u32ff\\ud83c\\udc00-\\ud83d\\udeff\\udbb9\\udce5-\\udbb9\\udcee\\uDD13\\uD83E\\uDD11\\uD83E\\uDD17\\uD83E\\uDD12\\uD83E\\uDD15\\uD83E\\uDD14\\uD83E\\uDD16\\uD83E\\uDD13]*)";
    //private static final String regex = ".*[^\\x20-\\x7E].*";
    public static boolean containsEmojiOnly(String source){
        return source.matches(regex);

    }
}
