package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;

/**
 * @author Ifta on 2/26/2018.
 */

public enum ChatWindowEvent {
    ExitQuoteMode,
    Highlight,
    UnHighlight,
    HideBottomFragment,
    MakeCallWithCheckingPermission,
    LocationRequestWithCheckingPermission,
    ContactShowingCheckingPermission,
    BackgroundChanged
}
