package com.revesoft.itelmobiledialer.chat.chatWindow.interfaces;

/**
 * @author Ifta on 12/27/2017.
 */

public interface Controllable {
    enum RequestType {
        HideBottomFragments,
        ShowEmojiKeyboard,
        ShowGif,
        ShowStickers,
        ShowBubbleToneStickers,
        ShowLocation,
        OpenOptionMenu,
        ExitQuoteMode,
        AUDIO_CALL,
        VIDEO_CALL,
        PAID_CALL
    }

    void onControlRequest(RequestType requestType);
}
