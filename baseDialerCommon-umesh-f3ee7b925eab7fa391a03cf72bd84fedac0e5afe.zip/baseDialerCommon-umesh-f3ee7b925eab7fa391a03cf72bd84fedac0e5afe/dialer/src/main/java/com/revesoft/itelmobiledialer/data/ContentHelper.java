package com.revesoft.itelmobiledialer.data;

import android.content.ContentUris;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.io.InputStream;

/**
 * ZipT Content Helper class.
 */
public class ContentHelper {

    public static InputStream openThumbnailPhoto(Context context, long contactId){
        Uri contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId);

        return ContactsContract.Contacts.openContactPhotoInputStream(context.getContentResolver(), contactUri);
    }

    /**
     * Open the display photo if it exists, otherwise try to open the thumbnail photo
     *
     * @param context
     * @param contactId
     * @return
     */
    public static InputStream openPhoto(Context context, long contactId){
        Uri contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId);

        Uri displayPhotoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.DISPLAY_PHOTO);
        try {
            AssetFileDescriptor fd = context.getContentResolver().openAssetFileDescriptor(displayPhotoUri, "r");
            return fd.createInputStream();
        } catch (Exception e) {
            // fallback to the thumbnail code
        }

        return ContactsContract.Contacts.openContactPhotoInputStream(context.getContentResolver(), contactUri);
    }

}
