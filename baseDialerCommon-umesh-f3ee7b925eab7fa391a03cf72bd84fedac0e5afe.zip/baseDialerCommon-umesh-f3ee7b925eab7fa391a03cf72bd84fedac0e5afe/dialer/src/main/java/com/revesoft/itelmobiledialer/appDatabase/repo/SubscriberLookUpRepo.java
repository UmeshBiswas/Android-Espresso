package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;

public class SubscriberLookUpRepo {
    private static final SubscriberLookUpRepo ourInstance = new SubscriberLookUpRepo();

    public static SubscriberLookUpRepo get() {
        return ourInstance;
    }

    private SubscriberLookUpRepo() {
    }

    public boolean checkForSubscriberLookupInLookupTable(String lookup) {
        return AppDatabase.get().subscriberLookUpDao().checkIfSubscriberLookExists(lookup);
    }


    public void deleteAllSubscribers() {
        AppDatabase.get().subscriberLookUpDao().deleteAllSubscribers();
    }


    public void deleteSubscriberLookup(String number) {
        AppDatabase.get().subscriberLookUpDao().deleteSubscriberLookup(number);
    }


    public Cursor getSubscriberLookUpCursor() {
        return AppDatabase.get().subscriberLookUpDao().getSubscriberLookUpCursor();
    }
}
