package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.ims.IMUtil.VoipSmsRequestUtil;
import com.revesoft.itelmobiledialer.sms.SMSLogStatus;
import com.revesoft.itelmobiledialer.sms.SmsLogEntry;
import com.revesoft.itelmobiledialer.util.AppContext;

import java.util.Date;

public class SMSRepo {
    private static final SMSRepo ourInstance = new SMSRepo();

    private SMSRepo() {
    }

    public static SMSRepo get() {
        return ourInstance;
    }

    public SmsLogEntry getSMSByRequestId(String smsRequestId) {
        String callerId = smsRequestId + ""; // SMS request id is saved as caller id in message table
        Message message = AppDatabase.get().messageDao().getMessageByCallId(callerId);
        String foundRequestID = message.callerId;
        return SmsLogEntry.newBuilder().content(message.content)
                .number(message.number)
                .groupId(message.groupId)
                .request_id(foundRequestID)
                .build();

    }

    public void createSMSLog(SmsLogEntry smsLogEntry) {
        String userName = UserDataManager.getUserName();
        smsLogEntry.content = smsLogEntry.content.replace(userName + "\n", "");
        Message message = Message.newBuilder()
                .callerId(smsLogEntry.request_id)
                .deliveryStatus(smsLogEntry.status == SMSLogStatus.FAILED ? MessageEntry.DeliveryStatus.FAILED : MessageEntry.DeliveryStatus.PENDING)
                .groupId(smsLogEntry.groupId)
                .date(new Date(smsLogEntry.time))
                .messageType(MessageEntry.MessageType.SMS)
                .notification(MessageEntry.MessageStatus.READ)
                .content(smsLogEntry.content)
                .queryId(smsLogEntry.query_id)
//                .futureSendTime(smsLogEntry.futureTime)  //TODO
                .editCount(0)
                .number(smsLogEntry.number)
                .build();
        AppDatabase.get().messageDao().insert(message);

    }

    public void updateSMS(SmsLogEntry smsLogEntry, int editCount) {
        Message message = Message.newBuilder()
                .callerId(smsLogEntry.request_id)
                .deliveryStatus(MessageEntry.DeliveryStatus.PENDING)
                .groupId(smsLogEntry.groupId)
                .date(new Date(smsLogEntry.time))
                .messageType(MessageEntry.MessageType.SMS)
                .notification(MessageEntry.MessageStatus.READ)
                .content(smsLogEntry.content)
                .queryId(smsLogEntry.query_id)
//                .futureSendTime(smsLogEntry.futureTime) //TODO
                .editCount(editCount)
                .number(smsLogEntry.number)
                .build();
        AppDatabase.get().messageDao().insert(message);
    }


    public void updateSMSDeliveryStatusByQueryId(String query_id, int status) {
        int deliveryStatus;
        if (status == SMSLogStatus.PENDING) {
            deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
            AppDatabase.get().messageDao().updateMessageDeliveryStatusByQueryId(query_id, deliveryStatus);
        } else if (status == SMSLogStatus.FAILED) {
            deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
            VoipSmsRequestUtil voipSmsRequestUtil = new VoipSmsRequestUtil();
            voipSmsRequestUtil.setRetryForFutureSMS(AppContext.getAccess().getContext(), query_id, false);
            AppDatabase.get().messageDao().updateMessageDeliveryStatusAndFutureSendTimeByQueryId(query_id, deliveryStatus, 0);
        } else if (status == SMSLogStatus.SUCCESSFUL) {
            deliveryStatus = MessageEntry.DeliveryStatus.SUCCESSFUL;
            AppDatabase.get().messageDao().updateMessageDeliveryStatusAndFutureSendTimeByQueryId(query_id, deliveryStatus, 0);
        }
    }


    public void updateSMSDeliveryStatusByRequestId(String requestId, int status) {
        String callerId = requestId + "";
        int deliveryStatus = SMSLogStatus.PENDING;
        if (status == SMSLogStatus.PENDING) {
            deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
        } else if (status == SMSLogStatus.FAILED) {
            deliveryStatus = MessageEntry.DeliveryStatus.FAILED;
        } else if (status == SMSLogStatus.SUCCESSFUL) {
            deliveryStatus = MessageEntry.DeliveryStatus.SUCCESSFUL;
        }
        AppDatabase.get().messageDao().updateMessageDeliveryStatus(callerId, deliveryStatus);
    }

    public void deleteSMSByQueryId(String query_id) {
        AppDatabase.get().messageDao().deleteByQueryId(query_id);
    }


    public void updateQueryIdByRequestId(String requestId, String queryId) {
        String callerId = requestId + "";
        AppDatabase.get().messageDao().updateQueryIdByCallerId(callerId, queryId);
    }

    public String getGroupIDByRequestId(String requestId) {
        String callerId = requestId + "";
        return AppDatabase.get().messageDao().getGroupIdByCallerId(callerId);
    }

    public boolean isGroupMessageSuccessful(String requestId) {
        int deliveryStatus = AppDatabase.get().messageDao().getMessageDeliveryStatusByCallerId(requestId);
        return deliveryStatus == MessageEntry.DeliveryStatus.SUCCESSFUL;
    }


}
