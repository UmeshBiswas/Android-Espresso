package com.revesoft.itelmobiledialer.chat.chatWindow.interfaces;

/**
 * @author Ifta on 1/15/2018.
 */

public interface MessageSelectionInteractionListener {
    void onSelectOrDeselect();
}
