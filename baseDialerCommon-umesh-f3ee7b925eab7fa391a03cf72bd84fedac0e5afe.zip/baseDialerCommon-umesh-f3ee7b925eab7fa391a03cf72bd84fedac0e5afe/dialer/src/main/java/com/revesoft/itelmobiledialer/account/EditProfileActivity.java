package com.revesoft.itelmobiledialer.account;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.revesoft.api.fileApi.FileApiError;
import com.revesoft.api.fileApi.fileApiInterfaces.ApiResponseListener;
import com.revesoft.api.fileApi.fileApiInterfaces.FileUploadListener;
import com.revesoft.itelmobiledialer.appApi.ProfileApi;
import com.revesoft.itelmobiledialer.braodcast.SimpleBroadcaster;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.ims.OnFragmentInteractionListener;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.CameraUtils;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Sayma
 * @author Ifta
 * on 5/15/2017.
 */

public class EditProfileActivity extends BaseActivity implements View.OnClickListener {
    Context context;
    Toolbar toolbar;
    TextView tvRegisteredNumber, tvMail, tvVirtualNumber, tvActivationText, tvSalamNumber;
    ImageView ivProfileImage;
    EditText etName;
    EditText etStatus;
    FloatingActionButton button;
    ProgressDialog progressDialog;

    private static final String TAG = "EditProfileActivity";
    private static final int REQUEST_IMAGE_CAPTURE = 50;
    private static final int PICK_IMAGE_REQUEST = 52;
    private Uri photoUri;
    private Uri selectedImageUri;
    private Uri finalCroppedImageUri = null;
    String initName;

    public static void startForTesting(Context context) {
        Intent intent = new Intent(context, EditProfileActivity.class);
        context.startActivity(intent);
    }


    final long timerStartedAt = System.currentTimeMillis();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_profile_layout);
        context = EditProfileActivity.this;
        handleToolbar();
        intiViews();
        updateViewData();
    }


    private void intiViews() {
        etStatus = findViewById(R.id.etStatus);
        tvRegisteredNumber =  findViewById(R.id.phoneNumber);
        ivProfileImage =  findViewById(R.id.ivProfileImage);
        etName =  findViewById(R.id.tvProfileName);
        tvMail =  findViewById(R.id.mail);
        button =  findViewById(R.id.button);
//        mailLayout = (RelativeLayout) findViewById(R.id.mail_layout);
//        virtualNumberLayout = findViewById(R.id.virtualNumberLayout);
        tvVirtualNumber = findViewById(R.id.virtualphoneNumber);
//        activationLayout = findViewById(R.id.activateSalamLayout);
        tvActivationText = findViewById(R.id.activeSalamOut);
        tvSalamNumber = findViewById(R.id.activationText);
//        mailLayout.setOnClickListener(this);
    }


    private void updateViewData() {
        tvRegisteredNumber.setText(Util.formatNumber(UserDataManager.getUserName()));
        String profilePicturePath = UserDataManager.getProfilePicturePath();
        ImageUtil.setImageButDefaultOnException(EditProfileActivity.this, profilePicturePath, ivProfileImage, R.drawable.person);
        initName = UserDataManager.getFullName();
        etName.setText(UserDataManager.getFullName());
        etName.setSelection(etName.getText().length());
        etStatus.setText(UserDataManager.getPresenceNote());
        String otherNumbers = getOtherPhoneNumbers().trim();
        tvMail.setText(UserDataManager.getEmail());
        button.setOnClickListener(this);
    }


    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(getString(R.string.editProfile));
        }
    }

    public void changeImage(View view) {
        showChangePictureDialog();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public void updateProfileInfo() {
        String fullName = etName.getText().toString().trim();
        if (fullName.length() == 0) {
            alert(getString(R.string.pleaseEnterName));
        } else {
            if (!UserDataManager.getFullName().equals(fullName)) {
                Log.i("Tanveee","entered");
                ProfileApi.updateUserProfileInfo(fullName, null, null, null, new ApiResponseListener() {
                    @Override
                    public void onSuccess(String response) {
                        UserDataManager.setFullName(fullName);
                        uploadPofilePicuture();
                    }

                    @Override
                    public void onFailed(String reason) {
                        Log.i(TAG,"Error : "+reason);
                        Toast.makeText(EditProfileActivity.this,R.string.something_went_wrong,Toast.LENGTH_LONG).show();
                    }
                });
            }
            else
            {

                uploadPofilePicuture();
            }

        }

    }

    private void updateImageNameStatus() {
        progressDialog = new ProgressDialog(EditProfileActivity.this);
        progressDialog.setMessage(getString(R.string.updating));
        progressDialog.setCancelable(false);
        progressDialog.show();
        setPresenceNote();
        updateProfileInfo();

    }

    private String getOtherPhoneNumbers() {
        return UserDataManager.getUserName();
    }

    private void showChangePictureDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(EditProfileActivity.this);
        builder.setTitle(getString(R.string.chooseMethod));
        ArrayList<String> methods = new ArrayList<String>();
        methods.add(getString(R.string.takeNewPhoto));
        methods.add(getString(R.string.selectFromGallery));
        ListAdapter adapter = new ArrayAdapter<String>(EditProfileActivity.this, android.R.layout.simple_list_item_1, methods);
        builder.setAdapter(adapter, (dialog, which) -> {
            switch (which) {
                case 0:
                    handleCameraCapture();
                    break;
                case 1:
                    handleGallerySelection();
                    break;
                default:
                    break;
            }
        });

        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private void handleCameraCapture() {
        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforCamera(this).length > 0) {
            Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
            ActivityCompat.requestPermissions(this, PermissionUtil.getPermissionsforCamera(this), OnFragmentInteractionListener.TYPE_IMAGE_VIDEO);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        photoUri = CameraUtils.getOutputMediaFileUri(CameraUtils.MediaFileType.IMAGE, EditProfileActivity.this);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } else {
            I.toast("No default camera found");
        }
    }

    private void handleGallerySelection() {
        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforGallery(this).length > 0) {
            Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
            ActivityCompat.requestPermissions(this, PermissionUtil.getPermissionsforGallery(this), OnFragmentInteractionListener.TYPE_GALLERY_IMAGE);
        } else {
            openGallery();
        }
    }

    private void openGallery() {
        Intent intent = new Intent();
        // Show only images, no videos or anything else
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        // Always show the chooser (if there are multiple options available)
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    private boolean performCrop(Uri picUri) {
        boolean supportsCrop;
        try {
            Uri targetFileUri = null;

            try {
                targetFileUri = Uri.fromFile(Util.createImageFile(this));
//                targetFileUri = FileProvider.getUriForFile(ProfileInfoUpdateActivity.this, getString(R.string.file_provider_authority), Util.createImageFile(this));
            } catch (IOException e) {
                Log.e(TAG, "Exception creating Image File in performCrop - " + e);
                e.printStackTrace();
            }

            CropImage.activity(picUri)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setOutputUri(targetFileUri)
                    .setOutputCompressQuality(100)
                    .setOutputCompressFormat(Bitmap.CompressFormat.JPEG)
                    .setRequestedSize(1024, 1024)
                    .setAspectRatio(1, 1)
                    .setFixAspectRatio(true)
                    .start(EditProfileActivity.this);

            supportsCrop = true;
        } catch (Exception e) {
            supportsCrop = false;
            e.printStackTrace();
            alert(getString(R.string.error_image_cropping_not_supported));
        }

        return supportsCrop;
    }

    private static boolean isPhotoDeleted = false;

    private void handleDeletePhoto() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(EditProfileActivity.this);
        dialog.setMessage(getString(R.string.are_you_sure_to_delete));
        dialog.setPositiveButton(getString(R.string.remove), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final Uri imageUri = Uri.parse("android.resource://com.nurtelecom.salam/" + R.drawable.default_pro_pic);
                InputStream in = null;
                OutputStream out = null;
                String filename = Environment.getExternalStorageDirectory() + "/salam_default_pro_pic98765445.jpg";
                try {
//                    in = new FileInputStream(imageUri.toString());
                    in = getAssets().open("default_pro_pic.png");
                    out = new FileOutputStream(filename);
                    byte[] buffer = new byte[1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                    in.close();
                    out.flush();
                    out.close();
                } catch (FileNotFoundException fnfe1) {
                    Log.e("tag", fnfe1.getMessage());
                } catch (Exception e) {
                    Log.e("tag", e.getMessage());
                }
                finalCroppedImageUri = Uri.fromFile(new File(filename));
                isPhotoDeleted = true;

                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        ImageUtil.setImageButDefaultOnException(EditProfileActivity.this, imageUri, ivProfileImage, R.drawable.person);
                    }
                });
//                performCrop(imageUri);
            }
        });
        dialog.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.show();


    }

    private void alert(String message) {
        android.app.AlertDialog.Builder bld = new android.app.AlertDialog.Builder(this);
        bld.setMessage(message);
        bld.setNeutralButton(android.R.string.ok, null);
        bld.create().show();
    }

    private void uploadPofilePicuture() {
        if (finalCroppedImageUri != null) {
            ProfileApi.uploadProfilePicture(finalCroppedImageUri.getPath(), new FileUploadListener() {
                @Override
                public void onUploadFinished(String response) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        int statusCode = jsonResponse.getInt("status");
                        if(statusCode == 0) {
                            progressDialog.dismiss();
                            copyFile(new File(finalCroppedImageUri.getPath()), new File(UserDataManager.getProfilePicturePath()));
                            finish();
                        }
                        else
                        {
                            Log.e(TAG,"Upload error with response :" + response);
                        }
                    } catch (JSONException e) {
                            Log.e(TAG,"error :",e);
                    }

                }

                @Override
                public void onUploadError(FileApiError e)
                {
                    progressDialog.dismiss();
                    Log.e(TAG,"error",e);
                }

                @Override
                public void onUploadProgress(int progress) {
                    Log.i(TAG,"Progress = "+progress);
                }
            });
        }
        else
        {
            progressDialog.dismiss();
            finish();
        }

    }


    private void setProfileImage() {
        Bitmap bm = BitmapFactory.decodeFile(ProfilePicUploadDownloadHelper.getProfilePictureFile(this, null).getAbsolutePath());
        if (bm != null) {
            ivProfileImage.setImageBitmap(bm);
        }
    }


    private void sendSomeoneChangedProfilePictureSignalBroadcast() {
        Intent intent = new Intent(Constants.DASHBOARD_INTENT_FILTER);
        intent.putExtra(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE, true);
        LocalBroadcastManager.getInstance(EditProfileActivity.this).sendBroadcast(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "Request Code: " + requestCode + " " + "Result Code: " + resultCode);
        if (requestCode == REQUEST_IMAGE_CAPTURE) {
            if (resultCode == RESULT_OK) {
                if (photoUri != null) {
                    selectedImageUri = photoUri;
                    if (performCrop(photoUri)) {
                        Log.d(TAG, "Crop supported");
                    } else {
                        finalCroppedImageUri = selectedImageUri;
                    }
                    deleteTempFile(EditProfileActivity.this, photoUri);
                } else {
                    I.toast(getString(R.string.error_no_image_selected));
                }
            }
        } else if (requestCode == PICK_IMAGE_REQUEST) {
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    Uri uri = data.getData();
                    if (uri != null) {
                        selectedImageUri = uri;
                        if (performCrop(uri)) {
                            Log.d(TAG, "Crop supported");
                        } else {
                            finalCroppedImageUri = selectedImageUri;
                        }
                    } else {
                        I.toast(getString(R.string.error_no_image_selected));
                    }
                }
            }
        } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            try {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == Activity.RESULT_OK) {
                    final Uri croppedFileUri = result.getUri();
                    selectedImageUri = croppedFileUri;
                    if (croppedFileUri != null) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                ImageUtil.setImageButDefaultOnException(EditProfileActivity.this, croppedFileUri, ivProfileImage, R.drawable.person);
                                finalCroppedImageUri = croppedFileUri;
                                isPhotoDeleted = false;
                                Log.e("sayma", "cropped uri " + finalCroppedImageUri);
                            }
                        });

                    } else {
                        alert(getString(R.string.error_image_cropping_failed));
                        Log.d(TAG, "Cropped uri  null ");
                    }

                } else if (resultCode == Activity.RESULT_CANCELED) {
                    Log.d(TAG, "Cropping was canceled ");
                    Toast.makeText(EditProfileActivity.this, R.string.error_no_image_selected, Toast.LENGTH_SHORT).show();
                }
                deleteTempFile(EditProfileActivity.this, selectedImageUri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private boolean deleteTempFile(Context context, Uri uri) {
        int deleted = 0;
        try {
            deleted = context.getContentResolver().delete(uri, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted > 0;
    }

    public void setPresenceNote() {
        String currentPresenceNote = UserDataManager.getPresenceNote();
        String newPresenceNote = etStatus.getText().toString().trim();
        if (newPresenceNote.equals("")) Log.e("sayma-stat", "empty note");
        if (!currentPresenceNote.equals(newPresenceNote) || newPresenceNote.equals("")) {
            UserDataManager.setPresenceNote(newPresenceNote);
            SimpleBroadcaster.sendSignalToDialer(Constants.Broadcast.TYPE_STATUS_CHANGED);
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                hideKeyboard(EditProfileActivity.this);
                if (!SIPProvider.registrationFlag) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(EditProfileActivity.this);
                    builder.setTitle(getString(R.string.no_internet_title));
                    builder.setMessage(getString(R.string.no_internet_message));
                    builder.setNegativeButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            finish();
                        }
                    });
                    builder.create().show();
                } else {
                    updateImageNameStatus();
                }

                break;
        }
    }

    public static void hideKeyboard(Activity activity) {
        try {
            InputMethodManager inputMethodManager =
                    (InputMethodManager) activity.getSystemService(
                            Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(
                    activity.getCurrentFocus().getWindowToken(), 0);

//        view = getActivity().getCurrentFocus();
//        if (view != null) {
//            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
//            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
//        }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void copyFile(File src, File dst) {
        try {
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }

            out.close();
            in.close();
        }catch (Exception e)
        {
            Log.i(TAG,"error",e);
        }

    }
}
