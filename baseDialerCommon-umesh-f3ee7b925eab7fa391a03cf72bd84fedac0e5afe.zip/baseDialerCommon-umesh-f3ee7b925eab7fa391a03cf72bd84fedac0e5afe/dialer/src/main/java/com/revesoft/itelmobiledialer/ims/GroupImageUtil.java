package com.revesoft.itelmobiledialer.ims;

import android.content.Context;
import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appApi.UploadDownloadApi;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.model.Group;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.signalling.fileInterfaces.FileDownloadListener;
import com.revesoft.itelmobiledialer.signalling.fileInterfaces.FileDownloadProgressListener;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.braodcast.SimpleBroadcaster;

import java.io.File;

import static com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants.MAX_DOWNLOAD_RETRY_LIMIT;

/**
 * @author Ifta on 7/13/2017.
 */

public class GroupImageUtil {
    public static void downloadGroupImage(Context context, String groupId) {
        Group group = GroupMessageAssistant.getGroupById(context, groupId);
        I.log(group.name + " " + group.groupImagePath);
        if (group.groupImagePath != null && !"null".equals(group.groupImagePath)) {
            I.log("image path ase " + group.groupImagePath);
            final File file = new File(ProfilePicUploadDownloadHelper.getReceivedMediaDirectory(), group.groupImagePath);
            if (ProfilePicUploadDownloadHelper.checkIfImageAvailable(file)) return;
            UploadDownloadApi.downloadFile(group.groupImagePath, file, group.id, true, new FileDownloadListener() {
                        @Override
                        public void OnDownloadFinished(String s, Boolean aBoolean, boolean b) {
                            SimpleBroadcaster.sendSignalToMessageModule(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE);
                        }
                    },
                    new FileDownloadProgressListener() {
                        @Override
                        public void onDownloadProgress(String callerID, String percentage) {
                            I.log("downloading group image " + percentage);
                        }
                    }, false, 1);

        } else {
            I.log("image path nai");
        }
    }
}
