package com.revesoft.itelmobiledialer.databaseentry;

/**
 * Created by Muhib on 5/14/2015.
 */
public class RechargeEntry {

    public long id;
    public String rechargeAmount;
    public String currencyCode;
    public String transactionId;
    public String paymentMethod;
    public int rechargeStatus;
    public String refundText;

    public RechargeEntry(String rechargeAmount, String currencyCode, String transactionId, String paymentMethod, int rechargeStatus) {
        this.rechargeAmount = rechargeAmount;
        this.currencyCode = currencyCode;
        this.transactionId = transactionId;
        this.paymentMethod = paymentMethod;
        this.rechargeStatus = rechargeStatus;
    }

    public RechargeEntry(String rechargeAmount, String currencyCode, String transactionId, String paymentMethod, int rechargeStatus, String refundText) {
        this(rechargeAmount, currencyCode, transactionId, paymentMethod, rechargeStatus);
        this.refundText = refundText;
    }

    public interface RechargeStatus {
        int PAYMENT_SUCCESSFUL = 0, RECHARGE_SUCCESSFUL = 1, FAILED = 2;
    }

    public interface PaymentMethod {
        String CREDIT_CARD="Credit Card",PAYPAL="PayPal";
    }
}
