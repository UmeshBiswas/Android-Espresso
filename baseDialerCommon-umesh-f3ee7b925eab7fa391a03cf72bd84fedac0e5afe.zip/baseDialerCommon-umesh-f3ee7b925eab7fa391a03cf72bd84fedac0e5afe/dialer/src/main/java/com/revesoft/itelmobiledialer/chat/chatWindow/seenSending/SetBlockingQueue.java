package com.revesoft.itelmobiledialer.chat.chatWindow.seenSending;

import java.util.Collection;
import java.util.concurrent.ArrayBlockingQueue;

/**
 * @author Ifta on 10/19/2017.
 */

class SetBlockingQueue<T> extends ArrayBlockingQueue<T> {
    public SetBlockingQueue(int capacity) {
        super(capacity);
    }

    @Override
    public boolean add(T t) {
        return !super.contains(t) && super.add(t);
    }

    @Override
    public boolean addAll(Collection<? extends T> c) {
        for(T t : c){
            add(t);
        }
        return true;
    }
}
