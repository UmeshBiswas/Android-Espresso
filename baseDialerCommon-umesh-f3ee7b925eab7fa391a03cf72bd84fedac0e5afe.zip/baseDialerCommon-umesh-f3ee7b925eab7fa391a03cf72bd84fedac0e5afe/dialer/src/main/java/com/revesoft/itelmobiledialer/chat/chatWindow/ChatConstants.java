package com.revesoft.itelmobiledialer.chat.chatWindow;

/**
 * @author Ifta on 12/9/2017.
 */

public class ChatConstants {
    public static final String KEY_NUMBER = "KEY_NUMBER";
    public static final String KEY_FROM_BUBBLE = "KEY_FROM_BUBBLE";
    public static final String KEY_GROUP_ID = "KEY_GROUP_ID";
    public static final String KEY_IS_SMS_CHAT = "KEY_IS_SMS_CHAT";
    public static final String KEY_IS_HIDDEN = "KEY_IS_HIDDEN";
    public static final String KEY_IS_CONFIDE = "KEY_IS_CONFIDE";
    public static final String KEY_IS_BROADCAST = "KEY_IS_BROADCAST";
    public static final String KEY_IS_ENCRYPTED = "KEY_IS_ENCRYPTED";
    public static final String KEY_GIF_URL = "KEY_GIF_URL";
    public static final String KEY_STICKER_URL = "KEY_STICKER_URL";
    public static final String INTENT_VALUES = "INTENT_VALUES";
    public static final String INTENT_TYPE = "INTENT_TYPE";
    public static final int REQUEST_GET_SMS_NUMBER = 199;
    public static final int GOOGLE_DRIVE_PICKER = 10223;
    public static final int MULTIPLE_MESSAGE_FORWARD_REQUEST_CODE = 200 ;
    public static final int NOTIF_ID_IM = 10002;
    public static final String KEY_OCID_ID = "KEY_OCID_ID";
}
