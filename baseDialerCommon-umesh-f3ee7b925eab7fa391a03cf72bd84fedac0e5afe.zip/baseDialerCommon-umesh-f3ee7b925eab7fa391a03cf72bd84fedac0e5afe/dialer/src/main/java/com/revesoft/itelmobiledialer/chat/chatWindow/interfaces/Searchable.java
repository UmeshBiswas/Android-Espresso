package com.revesoft.itelmobiledialer.chat.chatWindow.interfaces;

/**
 * @author Ifta on 12/28/2017.
 */

public interface Searchable {
    void search(String searchString);
}
