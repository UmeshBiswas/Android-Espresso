package com.revesoft.itelmobiledialer.ims;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GoogleMapFragment#newInstance} factory method to
 * initialize an instance of this fragment.
 */
public class GoogleMapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMapClickListener {

    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    private LatLng latestLatLng;
    private SupportMapFragment mapFragment;
    private boolean hasMarked = false;
    private boolean pendingFlag = false;
    private FloatingActionButton sendLocation;
    private FloatingActionButton getCurrentLocation;
    private RelativeLayout contentView;
    private RelativeLayout askPermissionView;


    private OnFragmentInteractionListener mListener;

    private Handler handler;

    /**
     * Use this factory method to initialize a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment GoogleMapFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static GoogleMapFragment newInstance() {
        GoogleMapFragment fragment = new GoogleMapFragment();
        return fragment;
    }

    public GoogleMapFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_google_map, container, false);

        handler = new Handler();
        sendLocation = view.findViewById(R.id.imageButtonImageSend);
        getCurrentLocation = view.findViewById(R.id.getCurrentLocation);
        contentView = view.findViewById(R.id.content_view);
        askPermissionView = view.findViewById(R.id.ask_permission_view);
        Button askPermissionButton = view.findViewById(R.id.accept_button);

        sendLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (latestLatLng != null && mListener != null) {
                    mListener.onFragmentInteraction(OnFragmentInteractionListener.TYPE_LOCATION, Constants.LOCATION_PREFIX + latestLatLng.latitude + "," + latestLatLng.longitude + Constants.LS_SUFIX);
                } else {
                    Toast.makeText(getActivity(), R.string.select_a_location_first, Toast.LENGTH_SHORT).show();
                }
            }
        });

        getCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                markLocationORenableGPS();
            }
        });

        askPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforLocation(getActivity()).length > 0) {
                    Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
                    requestPermissions(PermissionUtil.getPermissionsforLocation(getActivity()), OnFragmentInteractionListener.TYPE_LOCATION);
                }
            }
        });

        isMapLoaded = false;

        return view;
    }


    @Override
    public void onResume() {
        super.onResume();

        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforLocation(getActivity()).length > 0) {
            contentView.setVisibility(View.GONE);
            askPermissionView.setVisibility(View.VISIBLE);
        } else {
            contentView.setVisibility(View.VISIBLE);
            askPermissionView.setVisibility(View.GONE);
            handler.post(mapLoader);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        isMapLoaded = false;
    }

    private volatile boolean isMapLoaded = false;

    private Runnable mapLoader = new Runnable() {
        @Override
        public void run() {
            if (!isMapLoaded) {
                isMapLoaded = true;
                mapFragment = new SupportMapFragment();
                getActivity().getSupportFragmentManager().beginTransaction().add(R.id.google_map_fragment, mapFragment).commit();
                mapFragment.getMapAsync(GoogleMapFragment.this);
                if (pendingFlag) {
                    markInitialLocation();
                }
            }
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == OnFragmentInteractionListener.TYPE_LOCATION) {
            Log.i("StartupPermissions", "Received response for required permissions makeRequest.");
            if (PermissionUtil.verifyPermissions(grantResults)) {
                Log.i("StartupPermissions", "ALL required permissions have been granted, starting DialerService.");
                contentView.setVisibility(View.VISIBLE);
                askPermissionView.setVisibility(View.GONE);
                handler.post(mapLoader);
            } else {
                Log.i("StartupPermissions", "Permissions were NOT granted. Showing exit dialog");
                contentView.setVisibility(View.GONE);
                askPermissionView.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 23)
                    showExitOrGrantPermissionAlert();
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void showExitOrGrantPermissionAlert() {
        try {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage("You did not grant required permissions. You can grant them from application settings.");
            bld.setNegativeButton("Cancel", null);
            bld.setPositiveButton("App settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getActivity().getPackageName(), null));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    dialog.dismiss();
                }
            });
            bld.setCancelable(false);
            bld.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void markInitialLocation() {
//        if (isGPSEnabled()) {
        MyLocationProvider.LocationListener locationResult = new MyLocationProvider.LocationListener() {
            @Override
            public void locationReceived(Location location) {
                if (location != null) {
                    LatLng myLoc = new LatLng(location.getLatitude(), location.getLongitude());
                    latestLatLng = myLoc;
                    mMap.addMarker(new MarkerOptions().position(myLoc).title(getString(R.string.current_location)));
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(myLoc));
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(myLoc, 14.0f));
                } else {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity(), R.string.could_not_determine_current_location, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                hasMarked = true;
            }

            @Override
            public void error(String errorMessage) {
                I.toast(errorMessage);
            }
        };

        MyLocationProvider myLocation = new MyLocationProvider();
        myLocation.getLocation(getActivity(), locationResult);
//        }
    }

    public void markLocationORenableGPS() {
        if (isGPSEnabled()) {
            markInitialLocation();
        } else {
            new AlertDialog.Builder(getActivity())
                    .setMessage(R.string.gps_turned_off_turn_it_on)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        }
                    })
                    .setNegativeButton(android.R.string.no, null).show();
            pendingFlag = true;
        }
    }


    @Override
    public void onDestroy() {
        try {
            if (mapFragment != null)
                getFragmentManager().beginTransaction().remove(mapFragment).commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapClickListener(this);
        markInitialLocation();
    }

    @Override
    public void onMapClick(LatLng latLng) {
//        if (hasMarked) {
        mMap.clear();
        mMap.addMarker(new MarkerOptions().position(latLng).title(getString(R.string.selected_location)));
        CameraUpdate mCameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 14.0f);
        mMap.animateCamera(mCameraUpdate);
        latestLatLng = latLng;
//        } else {
//            Toast.makeText(getActivity(), "Searching for your location.", Toast.LENGTH_SHORT).show();
//        }
    }

    public boolean isGPSEnabled() {
        LocationManager locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

}
