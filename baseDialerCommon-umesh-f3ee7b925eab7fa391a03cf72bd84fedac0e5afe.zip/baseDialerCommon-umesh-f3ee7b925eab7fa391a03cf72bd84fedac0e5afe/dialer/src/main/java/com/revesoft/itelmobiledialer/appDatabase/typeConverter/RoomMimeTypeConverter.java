/*
 *  Created by Ifta on 8/8/18 11:04 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/5/18 3:35 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.typeConverter;

import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;

import androidx.room.TypeConverter;

public class RoomMimeTypeConverter {
    @TypeConverter
    public static MimeType toMimeType(String value) {
        return MimeTypeUtil.getMimeTypeByName(value);
    }

    @TypeConverter
    public static String toString(MimeType value) {
        return value.toString();
    }
}
