/*
 *  Created by Ifta on 8/8/18 11:02 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/8/18 10:53 AM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase;

import android.content.Context;
import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.dao.BlockDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.BurnMessageInfoDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.CallLogDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.ContactDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.CustomNotificationParamsDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.DIDDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.GroupDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.GroupMessageEligibleDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.HiddenMessageDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.LocationRequestDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.MessageDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.MessageHistoryTimeDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.MessageStatusDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.PersistentDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.RateDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.RechargeDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.RetryDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.SubscribedPackageDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.SubscriberDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.SubscriberLookUpDao;
import com.revesoft.itelmobiledialer.appDatabase.dao.TopUpLogDao;
import com.revesoft.itelmobiledialer.appDatabase.entities.Block;
import com.revesoft.itelmobiledialer.appDatabase.entities.BurnMessageInfo;
import com.revesoft.itelmobiledialer.appDatabase.entities.CallLog;
import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.appDatabase.entities.CustomNotificationParam;
import com.revesoft.itelmobiledialer.appDatabase.entities.DID;
import com.revesoft.itelmobiledialer.appDatabase.entities.Group;
import com.revesoft.itelmobiledialer.appDatabase.entities.GroupMessageEligible;
import com.revesoft.itelmobiledialer.appDatabase.entities.HiddenMessage;
import com.revesoft.itelmobiledialer.appDatabase.entities.LocationRequest;
import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.appDatabase.entities.MessageHistoryTime;
import com.revesoft.itelmobiledialer.appDatabase.entities.MessageStatus;
import com.revesoft.itelmobiledialer.appDatabase.entities.MultiPartMessage;
import com.revesoft.itelmobiledialer.appDatabase.entities.Persistent;
import com.revesoft.itelmobiledialer.appDatabase.entities.Rate;
import com.revesoft.itelmobiledialer.appDatabase.entities.Recharge;
import com.revesoft.itelmobiledialer.appDatabase.entities.RetryEntry;
import com.revesoft.itelmobiledialer.appDatabase.entities.SubscribedPackage;
import com.revesoft.itelmobiledialer.appDatabase.entities.Subscriber;
import com.revesoft.itelmobiledialer.appDatabase.entities.SubscriberLookUp;
import com.revesoft.itelmobiledialer.appDatabase.entities.TopUpLog;
import com.revesoft.itelmobiledialer.appDatabase.logger.AppDatabaseLogger;
import com.revesoft.itelmobiledialer.appDatabase.typeConverter.RoomBoolIntConverter;
import com.revesoft.itelmobiledialer.appDatabase.typeConverter.RoomDateTypeConverter;
import com.revesoft.itelmobiledialer.appDatabase.typeConverter.RoomMimeTypeConverter;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.util.AppContext;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

/**
 * @author Ifta at July 30, 2018
 */
@Database(entities = {
        Block.class,
        CallLog.class,
        Contact.class,
        DID.class,
        Group.class,
        GroupMessageEligible.class,
        LocationRequest.class,
        Message.class,
        HiddenMessage.class,
        Persistent.class,
        MessageHistoryTime.class,
        MessageStatus.class,
        MultiPartMessage.class,
        Rate.class,
        Recharge.class,
        RetryEntry.class,
        SubscribedPackage.class,
        Subscriber.class,
        SubscriberLookUp.class,
        TopUpLog.class,
        BurnMessageInfo.class,
        CustomNotificationParam.class
}, version = AppDatabaseDefault.DATABASE_VERSION)
@TypeConverters({RoomDateTypeConverter.class, RoomBoolIntConverter.class, RoomMimeTypeConverter.class})
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase appDatabase = null;


    public abstract CallLogDao callLogDao();

    public abstract SubscriberDao subscriberDao();

    public abstract SubscriberLookUpDao subscriberLookUpDao();

    public abstract MessageDao messageDao();

    public abstract GroupDao groupDao();

    public abstract GroupMessageEligibleDao groupMessageEligibleDao();

    public abstract ContactDao contactDao();
    public abstract BlockDao blockDao();


    public abstract MessageStatusDao messageStatusDao();

    private static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            try {
                database.execSQL("ALTER TABLE RETRY ADD COLUMN id TEXT");
            } catch (Exception e) {

            }

        }
    };

    public abstract LocationRequestDao locationRequestDao();

    public abstract DIDDao didDao();

    private static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            try {
                database.execSQL("CREATE TABLE IF NOT EXISTS custom_notification_param(" +
                        "target TEXT PRIMARY KEY," +
                        "call_ring_tone TEXT," +
                        "call_vibration INTEGER," +
                        "popup_notification INTEGER," +
                        "message_ring_tone TEXT," +
                        "notification_id TEXT," +
                        "message_vibration INTEGER)");
            } catch (Exception e) {

            }
        }
    };

    public abstract CustomNotificationParamsDao customNotificationParamsDao();

    public static void prepareForOperation(Context context) {
        if (appDatabase == null) {
            AppDatabaseLogger.log("prepareForOperation");
            synchronized (AppDatabase.class) {
                if (appDatabase == null) {
                    appDatabase = Room.databaseBuilder(context, AppDatabase.class, DatabaseConstants.DATABASE_NAME)
                            .addCallback(new Callback() {
                                @Override
                                public void onOpen(@NonNull SupportSQLiteDatabase db) {
                                    super.onOpen(db);
                                    AppDatabase.database = db;
                                }
                            })
                            .addMigrations(MIGRATION_1_2)
                            .build();
                }
            }
        }
    }

    public abstract HiddenMessageDao hiddenMessageDao();

    public abstract PersistentDao persistentDao();

    public abstract TopUpLogDao topUpLogDao();

    public abstract RechargeDao rechargeDao();

    public abstract RateDao rateDao();

    public abstract MessageHistoryTimeDao messageHistoryTimeDao();

    public abstract SubscribedPackageDao subscribedPackageDao();


    private static SupportSQLiteDatabase database;

    public abstract BurnMessageInfoDao burnMessageInfoDao();


    public Cursor rawQuery(String query){
        return database.query(query);
    }
//    public Cursor query(String tableName, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy){
////        SupportSQLiteQuery query = new SimpleSQLiteQuery()
////        return database.query();
//        return null;
//    }

    public synchronized static AppDatabase get() {
        if (appDatabase == null) {
            prepareForOperation(AppContext.getAccess().getContext());
        }
        return appDatabase;
    }

    public abstract RetryDao retryDao();


}
