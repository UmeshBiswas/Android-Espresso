package com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Controllable;
import com.revesoft.material.R;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * @author Ifta on 12/28/2017.
 */

public class EmoGifStickerFragment extends Fragment {
	private static Fragment fragment;

	public static Fragment getInstance() {
		if (fragment == null) {
			fragment = new EmoGifStickerFragment();
		}
		return fragment;
	}

	Controllable parentActivity = null;

	@Nullable
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.emo_gif_sticker_fragment_layout, container, false);
		final TextView tvEmoji =  view.findViewById(R.id.tvEmoji);
		View tvSticker = view.findViewById(R.id.tvSticker);
		View tvGIF = view.findViewById(R.id.tvGIF);
		View tvBSticker = view.findViewById(R.id.tvBSticker);
		if (getActivity() instanceof Controllable) {
			parentActivity = (Controllable) getActivity();
		}
		View.OnClickListener listener = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (parentActivity != null) {
					switch (v.getId()) {
						case R.id.tvEmoji:
							if (tvEmoji.getText().toString().equals(getString(R.string.emoji))) {
								tvEmoji.setText(getString(R.string.keyboard));

							} else {
								tvEmoji.setText(getString(R.string.emoji));
							}
							parentActivity.onControlRequest(Controllable.RequestType.ShowEmojiKeyboard);
							break;
						case R.id.tvSticker:
							parentActivity.onControlRequest(Controllable.RequestType.ShowStickers);
							break;
						case R.id.tvBSticker:
							parentActivity.onControlRequest(Controllable.RequestType.ShowBubbleToneStickers);
							break;
						case R.id.tvGIF:
							parentActivity.onControlRequest(Controllable.RequestType.ShowGif);
							break;
					}
				}
			}
		};
		tvEmoji.setOnClickListener(listener);
		tvSticker.setOnClickListener(listener);
		tvGIF.setOnClickListener(listener);
		tvBSticker.setOnClickListener(listener);
		return view;
	}
}
