package com.revesoft.itelmobiledialer.contact.details;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.util.CallMaker;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ContactDetailsNumberListSingleItemBinding;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

class NumberListAdapter extends ArrayAdapter<NumberListItem> {
    private Context context;

    NumberListAdapter(@NonNull Context context, int resource, @NonNull List<NumberListItem> objects) {
        super(context, resource, objects);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        Holder holder;
        if (view == null) {
            ContactDetailsNumberListSingleItemBinding binding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.getContext()),
                    R.layout.contact_details_number_list_single_item,
                    parent, false);
            holder = new Holder(binding);
            view = binding.getRoot();
            view.setTag(holder);
        } else {
            holder = (Holder) view.getTag();
        }
        holder.bind(getItem(position));
        return view;
    }

    private class Holder {
        ContactDetailsNumberListSingleItemBinding binding;
        NumberListItemClickListener clickListener = new NumberListItemClickListener() {
            @Override
            public void makeAudioCall(String number) {
                CallMaker.makeFreeCall(number);
            }

            @Override
            public void makeVideoCall(String number) {
                CallMaker.makeVideoCall(number);
            }

            @Override
            public void makePaidCall(String number) {
                CallMaker.makePaidCall(number);
            }

            @Override
            public void sendIM(String number) {
                Switcher.switchToChatWindow(context,Util.translateNumber(number),false,false,false,false);
            }

            @Override
            public void sendEmail(String number) {
                I.toast("WIP");
            }
        };
        Holder(ContactDetailsNumberListSingleItemBinding binding) {
            this.binding = binding;
        }

        public void bind(NumberListItem item) {
            binding.setItem(item);
            binding.setClicker(clickListener);
        }
    }
}
