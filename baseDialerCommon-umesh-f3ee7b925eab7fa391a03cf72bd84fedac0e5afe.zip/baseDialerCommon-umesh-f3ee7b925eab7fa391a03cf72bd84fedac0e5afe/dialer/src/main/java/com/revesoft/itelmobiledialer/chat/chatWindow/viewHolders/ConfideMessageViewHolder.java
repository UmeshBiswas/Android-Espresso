package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.view.View;
import android.widget.Space;

import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.material.R;

/**
 * @author Ifta on 12/12/2017.
 */

public class ConfideMessageViewHolder extends RetryAndProgressMessageViewHolder {
    private Space confideSpace;

    public ConfideMessageViewHolder(View view) {
        super(view);
        confideSpace = view.findViewById(R.id.confideSpace);
    }

    public void bindView(Message message) {
        super.bindView(message);
        if (message.isConfide && confideSpace != null) {
            if (message.mimeType == MimeType.Deleted) {
                confideSpace.setVisibility(View.GONE);
            } else {
                confideSpace.setVisibility(View.VISIBLE);
            }
        }

    }
}
