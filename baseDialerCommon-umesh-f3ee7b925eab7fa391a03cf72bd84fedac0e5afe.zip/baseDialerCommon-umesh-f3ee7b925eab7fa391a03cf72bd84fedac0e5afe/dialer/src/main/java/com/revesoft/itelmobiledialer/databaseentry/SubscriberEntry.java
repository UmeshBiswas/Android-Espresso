package com.revesoft.itelmobiledialer.databaseentry;

public class SubscriberEntry {
	public int _id;
	public int presencestate;
	public String number;
	public String presenceNote;
	public SubscriberEntry(){
		
	}
	public SubscriberEntry(int _id, String number,int presence , String presenceNote){
		this._id=_id;
		this.number=number;
		this.presencestate=presence;
		this.presenceNote = presenceNote;
	}	
	public SubscriberEntry(String number){
		this.number=number;
		this.presencestate= 0;
	}
	
	public interface PresenceState{
		final int AVAILABLE = 1;
		final int BUSY = 2;
		final int AWAY = 3;
		final int OFFLINE = 4;
	}
}
