package com.revesoft.itelmobiledialer.dialogues;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.core.app.ActivityCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.telephony.PhoneNumberUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.dialer.DashboardActivity;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.api.fileApi.HTTPUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.BuildConfig;import com.revesoft.material.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

/**
 * Created by dpaul on 5/14/15.
 */
public class InternationalCallInterceptDialog extends BaseActivity {
    public static final String NUMBER = "number";
    private static final int CHECK_CALL_PERMISSION = 12;
    private static final String TAG = "IntCallInterceptor";
    private static final int CONNECTION_TIMEOUT_IN_MILLS = 20000;
    private static final int READ_TIMEOUT_IN_MILLS = 20000;
    private static final String CHECK_RATE_URI = DialerService.BILLING_URL+"/api/checkRate.jsp";

    private String number;
    private ProgressBar progressBar;
    private TextView rate;
    private Button yes;
    private Button no;
    private SharedPreferences preferences;
    private Handler handler;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_intercept_international_call);
        preferences = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);

        rate = (TextView) findViewById(R.id.rate);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        handler = new Handler();

        String userName = UserDataManager.getUserName();

        number = getIntent().getStringExtra(NUMBER);
        if (number == null || number.equals("") || userName.equals(Constants.USERNAME_DEF)) {
            finish();
            return;
        } else {
            new RateChecker().execute(userName, number);
        }

        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        String formattedNumber;
        Phonenumber.PhoneNumber numberProto;
        try {
            numberProto = phoneUtil.parse(number.startsWith("+") ? number : ("+" + number), "");
            formattedNumber = phoneUtil.format(numberProto, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL);
        } catch (Exception e) {
            if (Build.VERSION.SDK_INT > 21) {
                formattedNumber = PhoneNumberUtils.formatNumber(number, phoneUtil.getRegionCodeForCountryCode(Integer.parseInt(Util.getUserCountryCode(number))));
            } else {
                formattedNumber = PhoneNumberUtils.formatNumber(number);
            }
        }

        ((TextView) findViewById(R.id.number)).setText(formattedNumber);

        yes = (Button) findViewById(R.id.yes_button);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialerService.FLAG = true;
                if (/*SIPProvider.registrationFlag*/Util.hasConnection(InternationalCallInterceptDialog.this)) {
                    Intent i = new Intent(InternationalCallInterceptDialog.this, DashboardActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(i);
                    sendIntentMessageToDialerForCall(number);
                    finish();
                } else {
                    alert(getString(R.string.not_yet_connected_with_server));
                }
            }
        });

        no = (Button) findViewById(R.id.no_button);
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(InternationalCallInterceptDialog.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to makeRequest the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    ActivityCompat.requestPermissions(InternationalCallInterceptDialog.this, new String[]{Manifest.permission.CALL_PHONE}, CHECK_CALL_PERMISSION);
                } else {
                    DialerService.FLAG = false;
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    Uri uri = Uri.parse("tel:" + processNumber("+" + number));
                    callIntent.setData(uri);
                    startActivity(callIntent);
                    finish();
                }
            }
        });

        ((CheckBox)findViewById(R.id.stop_showing_checkbox)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                preferences.edit().putBoolean(Constants.INTEGRATE_WITH_DIALER, !isChecked).commit();
                Log.d("Internationalcall", "Integrate with native dialer enabled : " + !isChecked+" Test : "+preferences.getBoolean(Constants.INTEGRATE_WITH_DIALER, false));
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (ActivityCompat.checkSelfPermission(InternationalCallInterceptDialog.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED){
            DialerService.FLAG = false;
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            Uri uri = Uri.parse("tel:" + processNumber("+" + number));
            callIntent.setData(uri);
            startActivity(callIntent);
            finish();
        }
    }

    private static String processNumber(CharSequence number) {
        try {
            return URLEncoder.encode(number.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void alert(String message) {
        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        bld.setMessage(message);
        bld.setNeutralButton(android.R.string.ok, null);
        Log.d("RateFragment", "Showing alert dialog: " + message);
        bld.create().show();
    }

    private void sendIntentMessageToDialerForCall(String number) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("startcall", number);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendIntentMessageToDialer(String type, String number) {
        Intent intent = new Intent(Constants.DASHBOARD_INTENT_FILTER);
        intent.putExtra(type, number);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public class RateChecker extends AsyncTask<String, Void, String> {
        private ProgressDialog pD = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            rate.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            HTTPUtil.disableConnectionReuseIfNecessary();

            String responseStr = null;
            try {
                URL urlToRequest = new URL(CHECK_RATE_URI);
                if (BuildConfig.DEBUG) Log.d(TAG, "RequestURI: " + urlToRequest.toString());

                urlConnection = (HttpURLConnection) urlToRequest.openConnection();
                urlConnection.setConnectTimeout(CONNECTION_TIMEOUT_IN_MILLS);
                urlConnection.setReadTimeout(READ_TIMEOUT_IN_MILLS);

                HashMap<String, String> postparamMap = new HashMap<>();
                postparamMap.put("username", params[0]);
                postparamMap.put("dialedNumber", params[1]);

                String postParameters = HTTPUtil.createQueryStringForParameters(postparamMap, TAG);

                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("GET");
                urlConnection.setFixedLengthStreamingMode(
                        postParameters.getBytes().length);
                urlConnection.setRequestProperty("Content-Type",
                        "application/x-www-form-urlencoded");

                PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
                out.print(postParameters);
                out.close();

                int statusCode = urlConnection.getResponseCode();
                Log.d("RateListActivity", "HTTP status code " + statusCode);
                if (statusCode != HttpURLConnection.HTTP_OK) {
                    // throw some exception
                    Log.e(TAG, "HTTP status code is not http ok!!!. status code : " + statusCode);
                    responseStr = null;
                } else {
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(urlConnection.getInputStream()));
                    String inputLine;
                    StringBuilder response = new StringBuilder();

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();
                    responseStr = response.toString().trim();
                    Log.d(TAG, "Response before parsing " + responseStr);
                }
            } catch (ProtocolException e) {
                e.printStackTrace();
                return null;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }

            return responseStr;
        }

        @Override
        protected void onPostExecute(final String response) {
            super.onPostExecute(response);
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (pD != null) {
                        pD.dismiss();
                        pD = null;
                    }
                    if(response != null){
//                showRateDialog(response.trim());
                        showRateDialog(response.trim());
                    } else {
//                alert(getString(R.string.error_loading_rate_info_for)+" "+selectedCountryName);
                    }
                }
            });
        }
    }

    private void showRateDialog(String rateStr){
        Log.d("RateFragment", "RateResponse: " + rate);
        try {
            double r = Double.parseDouble(rateStr);
            boolean isDollar;
            if(r>=1){
                isDollar = true;
            } else{
                isDollar = false;
                r = r*100;
            }
            rateStr = String.format( "%.2f", r );

            rate.setVisibility(View.VISIBLE);
            rate.setText(rateStr+" "+(isDollar?getString(R.string.dollar_per_minute):getString(R.string.cent_per_minute)));
            progressBar.setVisibility(View.GONE);
        } catch(Exception e){
            rate.setVisibility(View.VISIBLE);
            rate.setText("Could not fetch rate info");
            progressBar.setVisibility(View.GONE);
        }

    }

    @Override
    public void onBackPressed() {
        DialerService.FLAG = true;
        super.onBackPressed();
    }
}
