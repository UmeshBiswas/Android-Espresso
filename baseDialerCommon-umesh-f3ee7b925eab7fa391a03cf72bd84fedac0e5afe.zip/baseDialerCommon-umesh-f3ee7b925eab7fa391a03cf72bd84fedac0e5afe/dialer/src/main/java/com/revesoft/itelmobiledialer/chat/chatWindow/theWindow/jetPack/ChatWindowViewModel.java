package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.jetPack;

import android.os.Handler;
import android.os.Looper;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.JetPackChatAdapter;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModel;
import com.revesoft.itelmobiledialer.testunit.Voldemort;
import com.revesoft.itelmobiledialer.util.Log;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.paging.DataSource;
import androidx.paging.LivePagedListBuilder;
import androidx.paging.PagedList;

public class ChatWindowViewModel extends ViewModel {
    private JetPackChatAdapter.MessageType type;
    private String target;
    private boolean isGroup;
    private LiveData<PagedList<com.revesoft.itelmobiledialer.chat.chatWindow.Message>> futureMessages;
    private LiveData<PagedList<com.revesoft.itelmobiledialer.chat.chatWindow.Message>> regularMessages;

    ChatWindowViewModel(JetPackChatAdapter.MessageType type, String target, boolean isGroup) {
        this.type = type;
        this.target = target;
        this.isGroup = isGroup;
        futureMessages = loadFutureMessages();
        regularMessages = loadRegularMessages();
    }




    protected LiveData<PagedList<com.revesoft.itelmobiledialer.chat.chatWindow.Message>> loadRegularMessages() {
        DataSource.Factory<Integer, Message> dataSourceFactory;
        if (isGroup) {
            dataSourceFactory = MessageRepo.get().getAllRegularLivedPagedGroupMessage(target);
        } else {
            dataSourceFactory = MessageRepo.get().getAllRegularLivedPagedSingleMessage(target);
        }

        DataSource.Factory<Integer, com.revesoft.itelmobiledialer.chat.chatWindow.Message> messageFactory = dataSourceFactory.mapByPage(input -> {
            List<com.revesoft.itelmobiledialer.chat.chatWindow.Message> messageList = new ArrayList<>();
            for (Message message : input) {
                messageList.add(com.revesoft.itelmobiledialer.chat.chatWindow.Message.from(message));
            }
            return messageList;
        });
        return new LivePagedListBuilder<>(messageFactory, 20).build();
    }


    protected LiveData<PagedList<com.revesoft.itelmobiledialer.chat.chatWindow.Message>> loadFutureMessages() {
        DataSource.Factory<Integer, Message> dataSourceFactory;
        if (isGroup) {
            dataSourceFactory = MessageRepo.get().getAllRegularLivedPagedGroupFutureMessage(target);
        } else {
            dataSourceFactory = MessageRepo.get().getAllRegularLivedPagedSingleFutureMessage(target);
        }
        DataSource.Factory<Integer, com.revesoft.itelmobiledialer.chat.chatWindow.Message> messageFactory = dataSourceFactory.mapByPage(input -> {
            List<com.revesoft.itelmobiledialer.chat.chatWindow.Message> messageList = new ArrayList<>();
            for (Message message : input) {
                messageList.add(com.revesoft.itelmobiledialer.chat.chatWindow.Message.from(message));
            }
            return messageList;
        });
        return new LivePagedListBuilder<>(messageFactory, 20).build();
    }

    public LiveData<PagedList<com.revesoft.itelmobiledialer.chat.chatWindow.Message>> getRegularMessages() {
        return regularMessages;
    }

    public LiveData<PagedList<com.revesoft.itelmobiledialer.chat.chatWindow.Message>> getFutureMessages() {
        return futureMessages;
    }
    
}
