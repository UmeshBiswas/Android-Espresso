package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.SubscribedPackage;
import com.revesoft.itelmobiledialer.packageselection.PackageUtils.PackageSelectionObject;

import java.util.ArrayList;
import java.util.List;

public class SubscribedPackageRepo {
    private static final SubscribedPackageRepo ourInstance = new SubscribedPackageRepo();

    private SubscribedPackageRepo() {
    }

    public static SubscribedPackageRepo get() {
        return ourInstance;
    }

    public void createSubscribedLogs(ArrayList<PackageSelectionObject> arrayListPackageSelectionObject) {

        for (int i = 0; i < arrayListPackageSelectionObject.size(); i++) {

            PackageSelectionObject p = arrayListPackageSelectionObject.get(i);


            SubscribedPackage subscribedPackage = modelToEntity(p);

            AppDatabase.get().subscribedPackageDao().insert(subscribedPackage);
        }
    }


    public void deleteSubscribedLogs() {
        AppDatabase.get().subscribedPackageDao().deleteAll();
    }


    public PackageSelectionObject getSubscribedPackageInfoByID(String id) {
        SubscribedPackage subscribedPackage = AppDatabase.get().subscribedPackageDao().getSubscribedPackageInfoByID(id);
        PackageSelectionObject p = entityToModel(subscribedPackage);
        return p;
    }

    public ArrayList<PackageSelectionObject> getSubscribedPackages() {
        List<SubscribedPackage> list = AppDatabase.get().subscribedPackageDao().getAll();
        ArrayList<PackageSelectionObject> arrayList = new ArrayList<>();
        for (SubscribedPackage subscribedPackage : list) {
            arrayList.add(entityToModel(subscribedPackage));
        }
        return arrayList;
    }

    private SubscribedPackage modelToEntity(PackageSelectionObject p) {
        return SubscribedPackage.newBuilder()
                .withPackageId(p.packageID)
                .withPackageName(p.getPackageName())
                .withPackageValue(p.getPackageValue())
                .withPackageActivationTime(p.getActivationTime())
                .withPackageDeactivationTime(p.getDeactivationTime())
                .withGroupId(p.getGroupID())
                .withThumbnail(p.getThumbnail())
                .withValidTill(p.getValidTill())
                .withSubtitle(p.getSubtitle())
                .withUnusedBalance(p.getCreditLeft())
                .withAvailableMinutes(p.getAvailableMins())
                .withPackageType(p.getPackageType())
                .withUnusedMinutes(p.getUnUsedMinutes())
                .build();
    }

    private PackageSelectionObject entityToModel(SubscribedPackage subscribedPackage) {
        PackageSelectionObject p = new PackageSelectionObject();
        p.setPackageID(subscribedPackage.packageId);
        p.setPackageName(subscribedPackage.packageName);
        p.setPackageValue(subscribedPackage.packageValue);
        p.setActivationTime(subscribedPackage.packageActivationTime);
        p.setDeactivationTime(subscribedPackage.packageDeactivationTime);
        p.setGroupID(subscribedPackage.groupId);
        p.setThumbnail(subscribedPackage.thumbnail);
        p.setValidTill(subscribedPackage.validTill);
        p.setSubtitle(subscribedPackage.subtitle);
        p.setCreditLeft(subscribedPackage.unusedBalance);
        p.setAvailableMins(subscribedPackage.availableMinutes);
        p.setPackageType(subscribedPackage.packageType);
        p.setUnUsedMinutes(subscribedPackage.unusedMinutes);
        return p;
    }
}
