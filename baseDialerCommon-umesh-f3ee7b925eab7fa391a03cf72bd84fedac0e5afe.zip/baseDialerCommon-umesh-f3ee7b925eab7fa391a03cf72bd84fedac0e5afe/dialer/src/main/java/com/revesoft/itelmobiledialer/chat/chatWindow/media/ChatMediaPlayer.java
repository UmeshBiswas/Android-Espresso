package com.revesoft.itelmobiledialer.chat.chatWindow.media;

import android.media.MediaPlayer;
import android.widget.SeekBar;

import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDateTimeFormatter;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author on 12/18/2017.
 */

public class ChatMediaPlayer {
    private static ChatMediaPlayer chatMediaPlayer;
    private MediaPlayer mediaPlayer = new MediaPlayer();
    private Timer timer;
    private int playButtonResourceId = 0;
    private int pauseButtonResourceId = 0;

    private ChatMediaPlayer() {
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                freeLastAudioMessage();
            }
        });
        playButtonResourceId = R.drawable.ic_audio_play;
        pauseButtonResourceId = R.drawable.ic_audio_pause;
    }

    public static ChatMediaPlayer getInstance() {
        if (chatMediaPlayer == null) {
            chatMediaPlayer = new ChatMediaPlayer();
        }
        return chatMediaPlayer;
    }


    private AudioMessage audioMessage;

    public void handleAudioClick(AudioMessage audioMessage) {
        boolean isSameAudio = false;
        if (this.audioMessage != null) {
            isSameAudio = this.audioMessage.audioMessageId.equals(audioMessage.audioMessageId);
        }
        if (isSameAudio) {
            if (mediaPlayer.isPlaying()) {
                pauseAudioMessage();
            } else {
                if (this.audioMessage == null) {
                    playAudioMessage();
                } else {
                    resumeAudioMessage();
                }
            }
        } else {
            if (this.audioMessage != null) {
                freeLastAudioMessage();
            }
            this.audioMessage = audioMessage;
            playAudioMessage();
        }
    }

    private void resumeAudioMessage() {
        if (mediaPlayer != null) {
            mediaPlayer.start();
            audioMessage.ivPlayPause.setImageResource(pauseButtonResourceId);
            startTimer();
        }
    }

    public void pauseAudioMessage() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            audioMessage.ivPlayPause.setImageResource(playButtonResourceId);
            timer.cancel();
        }
    }

    public void playAudioMessage() {
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(audioMessage.audioFilePath);
            mediaPlayer.prepare();
            mediaPlayer.start();
            audioMessage.ivPlayPause.setImageResource(pauseButtonResourceId);
            audioMessage.seekBar.setProgress(0);
            audioMessage.seekBar.setOnSeekBarChangeListener(onSeekBarChangeListener);
            audioMessage.seekBar.setMax(mediaPlayer.getDuration() / 1000);
            audioMessage.tvPlayDuration.setText(Supplier.getString(R.string.playTimeZero));
            startTimer();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void freeLastAudioMessage() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.reset();
        }
        stopTimer();
        if (audioMessage != null) {
            if (audioMessage.ivPlayPause != null) {
                audioMessage.ivPlayPause.setImageResource(playButtonResourceId);
            }
            if (audioMessage.seekBar != null) {
                audioMessage.seekBar.setProgress(0);
            }
            if (audioMessage.tvPlayDuration != null) {
                audioMessage.tvPlayDuration.setText(Supplier.getString(R.string.playTimeZero));
            }
            audioMessage = null;
        }
    }

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                final int currentPosition = mediaPlayer.getCurrentPosition();
                audioMessage.seekBar.setProgress(currentPosition / 1000);
                if (audioMessage.tvPlayDuration != null) {
                    audioMessage.tvPlayDuration.post(new Runnable() {
                        @Override
                        public void run() {
                            audioMessage.tvPlayDuration.setText(ChatDateTimeFormatter.getDuration(currentPosition));
                        }
                    });
                }
            }
        }, 0, 1000);
    }

    private void stopTimer() {
        if (timer != null) {
            timer.cancel();
        }
    }

    public void finish() {
        if (audioMessage != null) {
            freeLastAudioMessage();
        }
    }

    private SeekBar.OnSeekBarChangeListener onSeekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if (fromUser) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.seekTo(seekBar.getProgress() * 1000);
                } else {
                    seekBar.setProgress(0);
                }
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };
}
