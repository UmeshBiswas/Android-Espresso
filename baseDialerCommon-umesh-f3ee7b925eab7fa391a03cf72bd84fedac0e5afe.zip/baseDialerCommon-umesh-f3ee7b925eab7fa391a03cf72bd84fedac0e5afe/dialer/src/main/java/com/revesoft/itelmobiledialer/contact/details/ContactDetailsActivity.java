package com.revesoft.itelmobiledialer.contact.details;


import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.appbar.SubtitleCollapsingToolbarLayout;
import com.revesoft.itelmobiledialer.account.NotificationSettingsActivity;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.SubscriberRepo;
import com.revesoft.itelmobiledialer.data.SubscriberStatusProvider;
import com.revesoft.itelmobiledialer.eventlistener.BlockStatusChangeData;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.eventlistener.DialerListener;
import com.revesoft.itelmobiledialer.eventlistener.EventData;
import com.revesoft.itelmobiledialer.eventlistener.MuteOrUnMuteEventData;
import com.revesoft.itelmobiledialer.eventlistener.SubscriberUpdatedData;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.ims.MediaDetails.MediaDetailsActivity;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.signalling.data.PresenceState;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.AttributeReader;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.Log;
import com.revesoft.itelmobiledialer.util.NativeContactUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ActivityContactDetailsBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import androidx.annotation.ColorInt;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.databinding.DataBindingUtil;


public class ContactDetailsActivity extends AppCompatActivity implements DialerListener {
    static final int RINGTONE_PICKER_REQUEST_CODE = 12;
    SubtitleCollapsingToolbarLayout subtitleCollapsingToolbarLayout;
    private ActionBar actionBar;

    public static void start(Context context, String contactId, String keyNumber) {
        Intent intent = new Intent(context, ContactDetailsActivity.class);
        intent.putExtra("contactId", contactId);
        intent.putExtra("keyNumber", keyNumber);
        context.startActivity(intent);
    }

    public static void startForTesting(Context context, String contactId, String keyNumber) {
        Intent intent = new Intent(context, ContactDetailsActivity.class);
        intent.putExtra("contactId", contactId);
        intent.putExtra("keyNumber", keyNumber);
        context.startActivity(intent);
    }

    private String contactId;
    private String keyNumber;
    private ContactDetails contactDetails;
    SwitchCompat switchCompat;
    private TextView tvBlock;
    List<String> subscribedList = new ArrayList<>();
    String statusNote;
    private LinearLayout tvPresenceNoteContainer;
    private TextView tvPresenceNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        readData();
        final ActivityContactDetailsBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_contact_details);
        setSupportActionBar(binding.toolbar);
        ContactDetailsViewModel viewModel = new ContactDetailsViewModel(contactId);
        viewModel.getContactDetailsLiveData().observe(this, contactDetails -> {
            this.contactDetails = contactDetails;
            Executor.ex(() -> {
                loadSubscriberData();
                Gui.get().run(() -> bindDataToView(binding));
            });

        });

        setUpCommonData(binding);

        ContactDetailsHelper.getAccess().muteOrUnMuteChat(ContactDetailsActivity.this, keyNumber, binding.sNotification);
        register();

    }

    String lastOnlineTime = "";

    private void bindDataToView(ActivityContactDetailsBinding binding) {
        subtitleCollapsingToolbarLayout = binding.collapsingToolBar;
        tvPresenceNoteContainer = binding.tvPresenceNoteContainer;
        tvPresenceNote = binding.tvPresenceNote;
        subtitleCollapsingToolbarLayout.setTitle("");
        subtitleCollapsingToolbarLayout.setSubtitle("");
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        subtitleCollapsingToolbarLayout.setTitle(contactDetails.getName());
        if (lastOnlineTime != null && !lastOnlineTime.trim().equals(""))
            subtitleCollapsingToolbarLayout.setSubtitle(lastOnlineTime);
        ImageUtil.setImageButTextImageOnException(ContactDetailsActivity.this, contactDetails.getImageUrl(), binding.ivProfileImage, contactDetails.getName());
        List<NumberListItem> numberListItemList = getNumberListItem(contactDetails.getNumbers());
        binding.numberList.setAdapter(new NumberListAdapter(ContactDetailsActivity.this, 0, numberListItemList));


    }

    private void setUpCommonData(ActivityContactDetailsBinding binding) {
        ContactDetailsHelper.getAccess().handleBlockView(keyNumber, binding.tvBlock);
        ContactDetailsHelper.getAccess().handleMuteNotificationView(keyNumber, binding.sNotification);
        switchCompat = binding.sNotification;
        tvBlock = binding.tvBlock;
    }


    private void readData() {
        contactId = getIntent().getStringExtra("contactId");
        keyNumber = getIntent().getStringExtra("keyNumber");
        keyNumber = Util.translateNumber(keyNumber);
        if (TextUtils.isEmpty(contactId) || TextUtils.isEmpty(keyNumber)) {
            finish();
        }
    }

    public void handleCustomNotification(View view) {

        Intent intent = new Intent(ContactDetailsActivity.this, NotificationSettingsActivity.class);
        intent.putExtra(NotificationSettingsActivity.TARGET_KEY, keyNumber);
        intent.putExtra(NotificationSettingsActivity.TARGET_NAME_KEY, contactDetails.getName());
        startActivity(intent);

    }

    public void seeSharedMedia(View view) {
        MediaDetailsActivity.start(ContactDetailsActivity.this, keyNumber, contactDetails.getName(), false);
    }

    public void block(View view) {
        ContactDetailsHelper.getAccess().handleBlocking(ContactDetailsActivity.this, keyNumber);
    }

    public void reportSpam(View view) {
        ContactDetailsHelper.getAccess().handleSpam(ContactDetailsActivity.this, keyNumber);
    }

    private List<NumberListItem> getNumberListItem(Set<String> numbers) {
        List<NumberListItem> numberListItems = new ArrayList<>();
        boolean hasSubscriberNumber = false;
        for (String number : numbers) {
            NumberListItem item = new NumberListItem();
            boolean flag = subscribedList != null && subscribedList.contains(Util.translateNumber(number));
            if (flag) {
                hasSubscriberNumber = true;
            }
            item.showAudioCall
                    = item.showVideoCall = item.showChat = flag
                    ? View.VISIBLE : View.GONE;
            item.showEmail = Util.isValidEmail(Util.getProperEmail(number)) ? View.VISIBLE : View.GONE;
            item.showOutCall = item.showAudioCall == View.GONE ? View.VISIBLE : View.GONE;
            item.number = number;
            numberListItems.add(item);
        }
        if (hasSubscriberNumber) {
            if (statusNote != null && !statusNote.trim().equals("")) {
                tvPresenceNoteContainer.setVisibility(View.VISIBLE);
                tvPresenceNote.setVisibility(View.VISIBLE);
                tvPresenceNote.setText(statusNote);
            } else {
                tvPresenceNoteContainer.setVisibility(View.GONE);
                tvPresenceNote.setVisibility(View.GONE);
            }

        } else {
            tvPresenceNoteContainer.setVisibility(View.GONE);
        }
        return numberListItems;
    }


    MenuItem itemActionFavorite;

    @ColorInt
    int color_on_primary_id;


    public void setFavoriteIcon() {
        Log.d("Contact Details", "Name :" + contactDetails.getName() + " is fav:" + contactDetails.isFavorite());
        isFavorite = contactDetails.isFavorite();
        if (isFavorite) {
            itemActionFavorite.setIcon(R.drawable.ic_star_white_24dp);
        }
        itemActionFavorite.getIcon().setColorFilter(color_on_primary_id, PorterDuff.Mode.SRC_ATOP);
    }


    public void loadSubscriberData() {
        List<String> translatedNumber = new ArrayList<>();
        for (String number : contactDetails.getNumbers())
            translatedNumber.add(Util.translateNumber(number));
        subscribedList = SubscriberRepo.get().isSubscriber(translatedNumber);
        if (subscribedList != null) {
            for (String number : subscribedList)
                IntentUtil.sendSubscribeMessage(AppContext.getAccess().getContext(), number);
            for (String number : subscribedList) {
                statusNote = SubscriberRepo.get().getPresenceNote(number);
                {
                    if (SubscriberStatusProvider.isOnline(number)) lastOnlineTime = "Online";
                    else
                        lastOnlineTime = SubscriberStatusProvider.getLastOnlineTime(ContactDetailsActivity.this, number);
                }

            }

        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.contact_details, menu);
        color_on_primary_id = AttributeReader.getAttributeColor(ContactDetailsActivity.this, R.attr.colorOnPrimary);
        itemActionFavorite = menu.findItem(R.id.make_fav);
        setFavoriteIcon();

        for (int i = 0; i < menu.size(); i++) {
            Drawable drawable = menu.getItem(i).getIcon();
            if (drawable != null) {
                drawable.mutate();
                drawable.setColorFilter(color_on_primary_id, PorterDuff.Mode.SRC_ATOP);
            }
        }
        return super.onCreateOptionsMenu(menu);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.edit_contact:
                handleEditProfile();
                return true;
            case R.id.make_fav:
                handleFavorite();
                return true;
            case android.R.id.home:
                finish();
                break;
            default:
                break;
        }
        return true;
    }


    boolean isFavorite = false;


    private void handleFavorite() {
        if (isFavorite) {
            itemActionFavorite.setIcon(R.drawable.ic_star_border_white_24dp);

        } else {
            itemActionFavorite.setIcon(R.drawable.ic_star_white_24dp);
        }
        isFavorite = !isFavorite;
        itemActionFavorite.getIcon().setColorFilter(color_on_primary_id, PorterDuff.Mode.SRC_ATOP);

        int status = isFavorite ? 1 : 0;
        ContactEngine.updateFavouriteStatus(ContactDetailsActivity.this, contactDetails.getLookUpKey(), status);
    }


    private void handleEditProfile() {
        NativeContactUtil.editContact(this, keyNumber);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RINGTONE_PICKER_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (uri != null) {
                    String ringTonePath = uri.toString();
                    AccountPreference.put(keyNumber + AccountPreference.Keys.RINGTONE_URI, ringTonePath);
                }
            }
        }
    }


    @Override
    public void register() {
        DialerEventHock.getInstance().addListener(this);
    }

    @Override
    public void performOnEvent(DialerEvent event, EventData eventData) {
        if (event == DialerEvent.MuteOrUnMuteChangeEvent) {
            MuteOrUnMuteEventData muteOrUnMuteEventData = (MuteOrUnMuteEventData) eventData;
            switchCompat.setChecked(!muteOrUnMuteEventData.isMute_status());
        }
        if (event == DialerEvent.BlockStatusChangeEvent) {
            BlockStatusChangeData blockStatusChangeData = (BlockStatusChangeData) eventData;
            if (((BlockStatusChangeData) eventData).getKeyNumber().equals(keyNumber)) {
                ContactDetailsHelper.getAccess().handleBlockView(blockStatusChangeData, tvBlock);
            }
        }
        if (event == DialerEvent.SubscriberUpdatedEvent) {
            SubscriberUpdatedData data = (SubscriberUpdatedData) eventData;

            for (String number : contactDetails.getNumbers()) {


                if (Util.translateNumber(number).equals(data.getNumber())) {


                    if (data.getState() == PresenceState.Offline) {
                        Gui.get().run(() -> subtitleCollapsingToolbarLayout.setSubtitle(SubscriberStatusProvider.convertToLastOnlineTime(data.getLastOnlineTime())));

                    } else {
                        Gui.get().run(() -> {
                            subtitleCollapsingToolbarLayout.setSubtitle("Online");
                            if (data.getNote() != null && !data.getNote().trim().equals("")) {
                                tvPresenceNote.setVisibility(View.VISIBLE);
                                tvPresenceNoteContainer.setVisibility(View.VISIBLE);
                                tvPresenceNote.setText(data.getNote());

                            } else {

                                tvPresenceNote.setVisibility(View.GONE);
                                tvPresenceNoteContainer.setVisibility(View.GONE);

                            }
                        });

                    }


                }
            }
        }
    }
}
