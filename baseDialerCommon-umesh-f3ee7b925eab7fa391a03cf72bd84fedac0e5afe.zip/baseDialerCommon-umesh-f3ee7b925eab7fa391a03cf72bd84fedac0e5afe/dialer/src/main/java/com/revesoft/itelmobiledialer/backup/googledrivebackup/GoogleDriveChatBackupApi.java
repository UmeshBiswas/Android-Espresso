package com.revesoft.itelmobiledialer.backup.googledrivebackup;


import android.widget.Toast;

import com.google.gson.Gson;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.BurnMessageInfoRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupMessageEligibleRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.HiddenMessageRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageStatusRepo;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.eventlistener.BackupOperationStatusData;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.util.AppContext;

/**
 * Created By suvo on February 07, 2019
 * Project baseDialerCommon
 **/

public class GoogleDriveChatBackupApi {


    private static final String TAG = "CHAT BACKUP : ";
    private final int PRIME_NUMBER = 71;
    private DriveServiceHelper driveServiceHelper;

    public static final String BACKUP_NETWORK_ERROR = "newtork_error";
    public static final String BACKUP_AUTH_ERROR = "auth_error";

    public GoogleDriveChatBackupApi(DriveServiceHelper driveServiceHelper) {
        this.driveServiceHelper = driveServiceHelper;
    }


    private String getCurrentChatAsJsonString() {
        Gson gson = new Gson();
        JsonMessageData jsonMessageData = new JsonMessageData();
        jsonMessageData.initializeFromDatabase();
        return gson.toJson(jsonMessageData);
    }


    public void requestToCheckConnectionIsOk() {
        driveServiceHelper.getConnectionResult();
    }

    public void backUpChatNow() {
        driveServiceHelper.getChatBackUpFileId().addOnCompleteListener(task -> {
            String fileID = task.getResult();
            writeFile(fileID);
        }).addOnFailureListener(e -> {
            showBackupFailedToast();
        });
    }


    private void writeFile(String fileId) {
        Executor.ex(() -> {
            String content = getCurrentChatAsJsonString();
            driveServiceHelper.saveFile(fileId, encodeString(content)).addOnFailureListener(e -> {
                showBackupFailedToast();
            }).addOnSuccessListener(v -> {
                showBackupSuccessfulToast();
                UserDataManager.setLastBackupTime(System.currentTimeMillis());
                UserDataManager.setLastBackupSize(content.getBytes().length);
            });
        });

    }


    public void restoreChatNow() {
        driveServiceHelper.getChatBackUpFileId().addOnCompleteListener(task -> {
            String fileID = task.getResult();
            readFile(fileID);
        }).addOnFailureListener(e -> {

        });
    }


    private void readFile(String fileId) {
        driveServiceHelper.readFile(fileId).addOnSuccessListener(nameAndContent -> {
            String jsonChat = nameAndContent.second;
            try {
                if (jsonChat != null) {
                    Gson gson = new Gson();
                    JsonMessageData jsonMessageData = gson.fromJson(decodeString(jsonChat), JsonMessageData.class);
                    Executor.ex(() -> {
                        BurnMessageInfoRepo.get().insertAll(jsonMessageData.burnMessageInfoList);
                        GroupRepo.get().insertAll(jsonMessageData.groupList);
                        GroupMessageEligibleRepo.get().insertAll(jsonMessageData.groupMessageEligibleList);
                        HiddenMessageRepo.get().insertAll(jsonMessageData.hiddenMessageList);
                        MessageRepo.get().insertAll(jsonMessageData.messageList);
                        MessageStatusRepo.get().insertAll(jsonMessageData.messageStatusList);

                    });
                    showRestoreSuccessfulToast();
                }
            } catch (Exception e) {
                showRestoreFailedToast();
            }


        }).addOnFailureListener(e -> {
            showRestoreFailedToast();
        });
    }


    private String encodeString(String str) {
        StringBuilder encodedStringBuilder = new StringBuilder();
        int key = getKey();
        for (int i = 0; i < str.length(); i++)
            encodedStringBuilder.append((char) (str.charAt(i) + key));
        System.out.println(TAG + encodedStringBuilder.toString());
        return encodedStringBuilder.toString();

    }


    private String decodeString(String str) {
        StringBuilder decodedStringBuilder = new StringBuilder();
        int key = getKey();
        for (int i = 0; i < str.length(); i++)
            decodedStringBuilder.append((char) (str.charAt(i) - key));
        System.out.println(TAG + decodedStringBuilder.toString());
        return decodedStringBuilder.toString();
    }


    private int getKey() {
        String user_name = UserDataManager.getUserName();
        int key = 0;
        for (int i = 0; i < user_name.length(); i++) key += (int) user_name.charAt(i);
        return key % PRIME_NUMBER;
    }

    private void showRestoreFailedToast() {
        showToast("Chat restore from Google Drive failed");
    }

    private void showBackupFailedToast() {
        DialerEventHock.getInstance().dispatchEvent(DialerEvent.BackUpOperationStatus,
                BackupOperationStatusData.newBuilder().operationStatus(false)
                        .isGoogleDriveReachable(true)
                        .isGoogleDrivePermitted(true).build());
        showToast("Google drive chat backup failed");
    }

    private void showBackupSuccessfulToast() {
        DialerEventHock.getInstance().dispatchEvent(DialerEvent.BackUpOperationStatus,
                BackupOperationStatusData.newBuilder().operationStatus(true)
                        .isGoogleDrivePermitted(true)
                        .isGoogleDriveReachable(true).build());
        showToast("Google drive chat backup successful");
    }

    private void showRestoreSuccessfulToast() {
        showToast("Chat restored from Google Drive Successfully");
    }

    private void showToast(String message) {
        Gui.get().run(() -> {
            Toast.makeText(AppContext.getAccess().getContext(), message, Toast.LENGTH_LONG).show();
        });
    }


}
