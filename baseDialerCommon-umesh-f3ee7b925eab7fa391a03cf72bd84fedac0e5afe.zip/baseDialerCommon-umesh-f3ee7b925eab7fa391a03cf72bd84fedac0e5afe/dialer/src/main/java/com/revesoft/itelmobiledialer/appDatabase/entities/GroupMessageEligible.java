package com.revesoft.itelmobiledialer.appDatabase.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
/*
db.execSQL("CREATE TABLE  IF NOT EXISTS
group_message_eligible_table(
callerid text primary key not null,
groupid text not null,
eligibleCount integer default 0)");
 */
@Entity(tableName = "group_message_eligible_table")
public class GroupMessageEligible {
    @PrimaryKey
    public int _id;

    @NonNull
    @ColumnInfo(name = "callerid")
    public String callId = "";

    @ColumnInfo(name = "groupid")
    public String groupId =null;

    public int eligibleCount = 0;

    private GroupMessageEligible(Builder builder) {
        _id = builder._id;
        callId = builder.callId;
        groupId = builder.groupId;
        eligibleCount = builder.eligibleCount;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public GroupMessageEligible() {
    }

    public static final class Builder {
        private int _id;
        private String callId;
        private String groupId;
        private int eligibleCount;

        private Builder() {
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withCallId(String val) {
            callId = val;
            return this;
        }

        public Builder withGroupId(String val) {
            groupId = val;
            return this;
        }

        public Builder withEligibleCount(int val) {
            eligibleCount = val;
            return this;
        }

        public GroupMessageEligible build() {
            return new GroupMessageEligible(this);
        }
    }
}
