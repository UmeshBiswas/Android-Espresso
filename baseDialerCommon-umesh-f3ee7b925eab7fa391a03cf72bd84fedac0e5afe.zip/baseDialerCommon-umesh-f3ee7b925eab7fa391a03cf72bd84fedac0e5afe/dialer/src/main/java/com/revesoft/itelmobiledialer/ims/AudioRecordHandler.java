package com.revesoft.itelmobiledialer.ims;

import android.app.AlertDialog;
import android.content.Context;
import android.media.MediaRecorder;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.revesoft.material.R;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by ashikee on 5/22/17.
 */

public class AudioRecordHandler {
    //    private ExtAudioRecorder mRecorder = null;
    private static final String LOG_TAG = "Mkhan";
    private static final String RECORD_DIR = "/Recordings";
    Handler handler = null;
    CountDownTimer timer = null;
    boolean isStoppedRecording = true;
    private MediaRecorder mRecorder = null;
    private File mAudioFile = null;
    private boolean mStartRecording = true;
    Context context;
    AudioRecordListener audioRecordListener;

    AudioRecordHandler(Context context, AudioRecordListener audioRecordListener) {
        this.context = context;
        this.audioRecordListener = audioRecordListener;
        handler = new Handler(Looper.getMainLooper());

    }


    void startRecording() {
        Log.d(LOG_TAG, "start recording");
        if (!isStoppedRecording)
            return;

        try {
//            mRecorder = ExtAudioRecorder.getInstanse(false);
            mRecorder = new MediaRecorder();
            Log.d(LOG_TAG, "New media recorder created");
            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            Log.d(LOG_TAG, " media recorder audio source set");

            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            try {
                mAudioFile = createAudioFile();
                Log.d(LOG_TAG, " audio file created: " + mAudioFile.getAbsolutePath());

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            mRecorder.setOutputFile(mAudioFile.getAbsolutePath());
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
//            mRecorder.setAudioSamplingRate(8000);

            Log.d(LOG_TAG, " media recorder outputfile and audioencoder is set");


            try {
                mRecorder.prepare();
                Log.d(LOG_TAG, " media recorder is prepared");
            } catch (Exception e) {
                Log.e(LOG_TAG, "prepare() failed");
                return;
            }

            try {
                mRecorder.start();
            } catch (IllegalStateException e) {
                Log.e(LOG_TAG, "Audio recorder start() failed " + e);
                alert(context.getString(R.string.cant_access_microphone), context.getString(R.string.error));
                return;
            }

            isStoppedRecording = false;

            timer = new CountDownTimer(60000, 50) {
                int count = 0;
                String time = "00:00";

                public void onTick(long millisUntilFinished) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                count++;
                                if (count % 20 == 0) {
                                    int sec = (count * 50) / 1000;
                                    time = "00:" + (sec < 10 ? ("0" + sec) : ("" + sec));
                                }
//                            pw.incrementProgress(0.3f);
                                if (mRecorder != null) {
                                    //sometime mRecorder becomes null earlier and then timer is getting called
                                    int maxAmplitude = mRecorder.getMaxAmplitude();
                                    audioRecordListener.OnAudioRecordTick(time);
                                    Log.d(LOG_TAG, " media recorder is not null and  visualizerView factor set");

                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }

                public void onFinish() {
                    count = 0;
                    time = "00:00";
                    audioRecordListener.OnAudioRecordTick(time);
                    Log.d(LOG_TAG, " CountDownTimer is stopped");
                    stopRecording();
                }
            }.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void stopRecording() {
        if (isStoppedRecording)
            return;
        try {
            Log.d(LOG_TAG, "stop recording");
//            pw.resetCountWithoutText();
            audioRecordListener.OnAudioRecordTick("00:00");
            if (timer != null) {
                timer.cancel();
                timer = null;
                Log.d(LOG_TAG, " CountDownTimer is set to null");

            }

            isStoppedRecording = true;

            mRecorder.stop();
            Log.d(LOG_TAG, " Media recorder stopped");

            mRecorder.release();
            Log.d(LOG_TAG, " Media recorder released");
            mRecorder = null;
            Log.d(LOG_TAG, " Media recorder is set to null");

            onRecordComplete(mAudioFile.getAbsolutePath());

            Log.d(LOG_TAG, " OnRecordComplete Listener is called and isStoppedRecording flag is set true");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopAndCancelRecording() {
        if (isStoppedRecording)
            return;
        try {
            Log.d(LOG_TAG, "stop recording");
//            pw.resetCountWithoutText();
            audioRecordListener.OnAudioRecordTick("00:00");
            if (timer != null) {
                timer.cancel();
                timer = null;
                Log.d(LOG_TAG, " CountDownTimer is set to null");

            }
            isStoppedRecording = true;
            mRecorder.stop();
            Log.d(LOG_TAG, " Media recorder stopped");
            mRecorder.release();
            Log.d(LOG_TAG, " Media recorder released");
            mRecorder = null;
            Log.d(LOG_TAG, " Media recorder is set to null");
            Log.d(LOG_TAG, " OnRecordComplete Listener is called and isStoppedRecording flag is set true");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private File createAudioFile() throws IOException {
        // Create an Audio file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String audioFileName = "RECORDING_" + timeStamp + ".m4a";
        File recordDir = new File(Environment.getExternalStorageDirectory() + RECORD_DIR);
        if (!recordDir.exists()) {
            recordDir.mkdir();
        }

        File audioFile = new File(recordDir, audioFileName);

        return audioFile;
    }

    public void onRecordComplete(String path) {
        if (new File(path).length() <= 0) {
            Toast.makeText(context, R.string.can_not_send_empty_file, Toast.LENGTH_LONG).show();
            return;
        }
        audioRecordListener.OnAudioRecordFinished(path);
    }

    private void alert(String message, String title) {
        if (context != null) {
            AlertDialog.Builder bld = new AlertDialog.Builder(context);
            bld.setMessage(message).setTitle(title).setNeutralButton(R.string.ok, null);
            Log.d(LOG_TAG, "Showing alert dialog: " + message);
            bld.create().show();
        }
    }

    public interface AudioRecordListener {
        void OnAudioRecordFinished(String filePath);

        void OnAudioRecordTick(String time);
    }
}
