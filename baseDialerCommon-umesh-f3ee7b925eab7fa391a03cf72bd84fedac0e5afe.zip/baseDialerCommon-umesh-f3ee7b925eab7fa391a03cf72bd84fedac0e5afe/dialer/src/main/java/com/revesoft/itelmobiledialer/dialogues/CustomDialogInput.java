package com.revesoft.itelmobiledialer.dialogues;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.revesoft.material.R;


/**
 * @author ashikee on 10/30/16.
 */
public class CustomDialogInput extends Dialog {
    public Context c;
    Activity a;
    public Dialog d;
    public EditText input;
    public TextView head;
    private Button yes, no;
    private String stringInput, stringHead, yesText, noText;
    private View.OnClickListener yesListener, noListener;
    private String inputType = null;

    public void setInput(String input) {
        this.stringInput = input;
    }

    public void setHead(String head) {
        this.stringHead = head;
    }

    public void setActivity(Activity a){ this.a = a;}




    public CustomDialogInput(Context context) {
        super(context);
        this.c =context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        int width = (int) (c.getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.90);
        Window window = this.getWindow();
        if (window != null) {
            window.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setGravity(Gravity.CENTER);
            window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        }
        setContentView(R.layout.custom_dialog_input);
        this.setCancelable(false);
        yes = (Button) findViewById(R.id.btn_ok);
        yes.setText(yesText);
        yes.setOnClickListener(yesListener);
        no = (Button) findViewById(R.id.btn_cancel);
        no.setText(noText);
        no.setOnClickListener(noListener);
        input = (EditText) findViewById(R.id.edit_text_input);
        head = (TextView) findViewById(R.id.head);
        if (stringInput != null && stringInput.length() != 0) {
            input.setText(stringInput);
            input.setSelection(input.getText().length());
        }
        if (stringHead != null && stringHead.length() != 0) {
            head.setText(stringHead);
        }


        if(inputType != null && inputType.equalsIgnoreCase("mail")) {
            input.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS | InputType.TYPE_CLASS_TEXT);
        }


    }

    public void setPositiveButton(String text, View.OnClickListener listener) {
        yesText = text;
        yesListener = listener;
//        inputType = "hideKeyboard";
    }

    public void setNegativeButton(String text, View.OnClickListener listener) {
        noText = text;
        noListener = listener;
//        inputType = "hideKeyboard";
    }

    public String getCurrentInput() {
        if(input!=null){
            return input.getText().toString();
        }
        return "";
    }

    public void setInputType(String type){
        inputType = type;
    }

}
