package com.revesoft.itelmobiledialer.downloadhelper;


public abstract class DownloadClient{

    public abstract void onCompleted(int requestIdentifier);


    public abstract void onError(int requestIdentifier, Exception exception);


    public void onProgress(int requestIdentifier, long currentOffset, long totalLength) {

    }

}
