package com.revesoft.itelmobiledialer.customview;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.widget.TextView;
import android.widget.TimePicker;

/**
 * Created by acer on 7/27/2016.
 */
public class CustomTimePicker extends TimePicker {

    public CustomTimePicker(Context context) {
        super(context);
        init();
    }

    public CustomTimePicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomTimePicker(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    void init() {
        TextView divider = (TextView) findViewById(Resources.getSystem()
                .getIdentifier("divider", "id", "android"));
        // the divider doesn't exist in the old-school widget style
        if (divider != null) {
            divider.setText("");
        }
    }

    @Override
    public void setMinute(int minute) {
        super.setMinute(minute);
    }

    @Override
    public void setHour(int hour) {
        super.setHour(hour);
    }
}
