package com.revesoft.itelmobiledialer.backup;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.DriveServiceHelper;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.GoogleDriveChatBackupApi;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.signup.PrepareDatabaseActivity;
import com.revesoft.itelmobiledialer.signup.PrepareDialerActivity;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import java.util.Collections;


public class BackupInFirstRunActivity extends BaseActivity {


    private static final int REQUEST_CODE_SIGN_IN = 1;
    TextView backupFoundStatus;
    private DriveServiceHelper mDriveServiceHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_backup_restore_in_first_run);
        backupFoundStatus = findViewById(R.id.backup_status);
        requestSignIn();


    }


    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onStop() {
        super.onStop();
    }


    @Override
    protected void onActivityResult(final int requestCode,
                                    final int resultCode, final Intent data) {


        switch (requestCode) {
            case REQUEST_CODE_SIGN_IN:
                if (resultCode == RESULT_OK) {
                    handleSignInResult(data);
                } else startDialerInitialization();
        }
    }


    public void checkIfBackupExists() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Searching for chat backup in Google Drive...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        mDriveServiceHelper.checkBackUpExists().addOnCompleteListener(task -> {
            progressDialog.dismiss();
            boolean res = task.getResult();
            if (!res) {
                backupFoundStatus.setText("No backup found");
                startDialerInitialization();
            } else backupFoundStatus.setText("Backup found");
        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
            Toast.makeText(this, "Failed to find backup in your Google Drive", Toast.LENGTH_LONG).show();
            startDialerInitialization();
        });
    }


    public void restoreBackup(View view) {
        GoogleDriveChatBackupApi googleDriveChatBackupApi = new GoogleDriveChatBackupApi(mDriveServiceHelper);
        googleDriveChatBackupApi.restoreChatNow();
        startDialerInitialization();
    }

    public void skipBackup(View view) {
        startDialerInitialization();
    }


    private void requestSignIn() {

        GoogleSignInOptions signInOptions =
                new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail()
                        .requestScopes(new Scope(DriveScopes.DRIVE_FILE))
                        .build();
        GoogleSignInClient client = GoogleSignIn.getClient(this, signInOptions);
        startActivityForResult(client.getSignInIntent(), REQUEST_CODE_SIGN_IN);
    }

    private void handleSignInResult(Intent result) {
        GoogleSignIn.getSignedInAccountFromIntent(result)
                .addOnSuccessListener(googleAccount -> {
                    UserDataManager.setGoogleEmailAddress(googleAccount.getEmail());
                    GoogleAccountCredential credential =
                            GoogleAccountCredential.usingOAuth2(
                                    this, Collections.singleton(DriveScopes.DRIVE_FILE));
                    credential.setSelectedAccount(googleAccount.getAccount());
                    Drive googleDriveService =
                            new Drive.Builder(
                                    AndroidHttp.newCompatibleTransport(),
                                    new GsonFactory(),
                                    credential)
                                    .setApplicationName("Drive API Migration")
                                    .build();
                    mDriveServiceHelper = new DriveServiceHelper(googleDriveService);
                    checkIfBackupExists();
                })
                .addOnFailureListener(exception -> {
                    Toast.makeText(this, "Failed to login Google", Toast.LENGTH_LONG).show();
                    startDialerInitialization();
                });
    }


    private void startDialerInitialization() {
        Intent intent = new Intent(BackupInFirstRunActivity.this, PrepareDialerActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra(PrepareDatabaseActivity.KEY_IS_BACK_UP_RESTORED, false);
        startActivity(intent);
        finish();
    }


}

