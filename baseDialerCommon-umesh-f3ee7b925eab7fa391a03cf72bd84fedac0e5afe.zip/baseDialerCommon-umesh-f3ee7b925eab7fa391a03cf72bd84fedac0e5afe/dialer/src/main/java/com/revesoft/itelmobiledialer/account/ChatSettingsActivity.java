package com.revesoft.itelmobiledialer.account;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.backup.ChatBackupSettingsActivity;
import com.revesoft.itelmobiledialer.data.UnseenMessageCounter;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

/**
 * @author Ifta
 *         on 5/22/2017.
 */

public class ChatSettingsActivity extends BaseActivity {
    Context context;
    Toolbar toolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_settings_layout);
        context = this;
        handleToolbar();
    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.blockedContacts));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(getString(R.string.chats));
        }
    }

    public void showChatWallpaper(View view) {
        Intent intent = new Intent(ChatSettingsActivity.this, ChatBackgroundSelectionActivity.class);
        startActivity(intent);
    }

    public void clearAllChat(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(getString(R.string.confirm));
        builder.setMessage(getString(R.string.areYouSureToClearAllChats));
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                clearAllSingleChat();
                clearAllGroupChat();
                I.toast(getString(R.string.successful));
                UnseenMessageCounter.sendSignalToDashBoard();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton(getString(R.string.neverMind), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private void clearAllSingleChat() {
        Executor.ex(() -> {
            List<String> phoneNumbers = MessageRepo.get().allActiveMessageParticipantPhoneNumbers();
            for (String number : phoneNumbers) {
                clearSingleChat(number);
            }
        });

    }

    private void clearSingleChat(String phoneNumber) {
//        Executor.ex(()->{
        long lastMessageTime = MessageRepo.get().lastMessageDate(phoneNumber);
        if (lastMessageTime > 1) {
            if (MessageRepo.get().deleteMessageByNumber(phoneNumber) > 0) {
                MessageRepo.get().dummyWithDate(phoneNumber, lastMessageTime);
//                Database.MessageHistoryTime.Update.update(phoneNumber);
            }
        }
//        });

    }

    private void clearAllGroupChat() {
        Executor.ex(() -> {
            List<String> groupIds = MessageRepo.get().allActiveGroupMessageGroupId();
            for (String groupId : groupIds) {
                clearGroupChat(groupId);
            }
        });

    }

    private void clearGroupChat(String groupId) {
        Executor.ex(() -> {
            long lastMessageTime = MessageRepo.get().lastMessageDateForGroup(groupId);
            if (lastMessageTime > 1) {
                if (MessageRepo.get().deleteMessageByGroupId(groupId) > 0) {
                    MessageRepo.get().dummyWithDateForGroup(groupId, lastMessageTime);
//                    Database.MessageHistoryTime.Update.update(groupId);
                }
            }
        });

    }

    public void deleteAllChat(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(getString(R.string.confirm));
        builder.setMessage(getString(R.string.areYouSureToDeleteAllChats));
        builder.setPositiveButton(getString(R.string.ok), (dialog, which) -> {
            Executor.ex(() -> {
                List<String> numbersAndGroupIds = getActiveChatNumbersAndGroupIds();
                long affectedRowsSingleChat = MessageRepo.get().deleteAllMessages();

                Gui.get().run(() -> {
                    if (affectedRowsSingleChat > 0) {
                        I.toast(getString(R.string.successful));
                    } else {
                        I.toast(getString(R.string.nothingToDelete));
                    }
                    UnseenMessageCounter.sendSignalToDashBoard();
                });
            });
            dialog.dismiss();

        });
        builder.setNegativeButton(getString(R.string.neverMind), (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private List<String> getActiveChatNumbersAndGroupIds() {
        List<String> data = new ArrayList<>();
        data.addAll(MessageRepo.get().allActiveMessageParticipantPhoneNumbers());
        data.addAll(MessageRepo.get().allActiveGroupMessageGroupId());
        return data;
    }

    public void handleChatBackup(View view){
        startActivity(new Intent(ChatSettingsActivity.this, ChatBackupSettingsActivity.class));
    }
}
