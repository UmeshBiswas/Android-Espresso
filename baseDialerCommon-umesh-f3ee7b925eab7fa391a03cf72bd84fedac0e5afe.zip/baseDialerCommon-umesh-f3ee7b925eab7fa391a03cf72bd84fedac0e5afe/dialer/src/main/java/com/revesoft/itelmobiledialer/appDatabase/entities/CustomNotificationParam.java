package com.revesoft.itelmobiledialer.appDatabase.entities;


import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Created By suvo on February 27, 2019
 * Project baseDialerCommon
 **/
@Entity(tableName = "custom_notification_param")
public class CustomNotificationParam {

    @NonNull
    @PrimaryKey
    @ColumnInfo(name = "target")
    public String target = AppDatabaseDefault.DEFAULT_CUSTOM_NOTIFICATION_TARGET;

    @ColumnInfo(name = "call_ring_tone")
    public String callRingTone;

    @ColumnInfo(name = "call_vibration")
    public int callVibrationMode;

    @ColumnInfo(name = "popup_notification")
    public boolean popUpNotification;

    @ColumnInfo(name = "message_ring_tone")
    public String messageRingTone;


    @ColumnInfo(name = "message_vibration")
    public int messageVibrationMode;


    @ColumnInfo(name = "notification_id")
    public String notificationChannelID;


    @ColumnInfo(name = "custom_notification_enable")
    public boolean isCustomNotificationEnable = true;


    public CustomNotificationParam() {

    }

    private CustomNotificationParam(Builder builder) {
        target = builder.target;
        callRingTone = builder.callRingTone;
        callVibrationMode = builder.callVibrationMode;
        popUpNotification = builder.popUpNotification;
        messageRingTone = builder.messageRingTone;
        messageVibrationMode = builder.messageVibrationMode;
        notificationChannelID = builder.notificationChannelID;
        isCustomNotificationEnable = builder.isCustomNotificationEnable;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private String target;
        private String callRingTone;
        private int callVibrationMode;
        private boolean popUpNotification;
        private String messageRingTone;
        private int messageVibrationMode;
        private String notificationChannelID;
        private boolean isCustomNotificationEnable = true;

        private Builder() {
        }

        public Builder target(String val) {
            target = val;
            return this;
        }

        public Builder callRingTone(String val) {
            callRingTone = val;
            return this;
        }

        public Builder callVibrationMode(int val) {
            callVibrationMode = val;
            return this;
        }

        public Builder popUpNotification(boolean val) {
            popUpNotification = val;
            return this;
        }

        public Builder messageRingTone(String val) {
            messageRingTone = val;
            return this;
        }

        public Builder messageVibrationMode(int val) {
            messageVibrationMode = val;
            return this;
        }

        public Builder notificationChannelID(String val) {
            notificationChannelID = val;
            return this;
        }

        public Builder isCustomNotificationEnable(boolean val) {
            isCustomNotificationEnable = val;
            return this;
        }

        public CustomNotificationParam build() {
            return new CustomNotificationParam(this);
        }
    }
}
