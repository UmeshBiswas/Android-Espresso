package com.revesoft.itelmobiledialer.arch;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

/**
 * @author Ifta on 7/27/2017.
 */

public class Supplier {
    private static Resources resources;
    public static void initialize(Context context){
        resources = context.getResources();
    }
    public static String getString(int stringId){
        return resources.getString(stringId);
    }

    public static Resources getResources() {
        return resources;
    }
    public static int getColor(int colorId){
        return resources.getColor(colorId);
    }
    public static DisplayMetrics getDisplayMetrics(){
        return resources.getDisplayMetrics();
    }
    public static String[] getStringArray(int stringArrayId){
        return resources.getStringArray(stringArrayId);
    }

    public static Resources getResource(){
        return resources;
    }
}
