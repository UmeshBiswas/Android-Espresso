package com.revesoft.itelmobiledialer.Config;

public class Features {
    private static boolean callerId = false;
    private static boolean did = false;
    private static boolean recharge = false;
    private static boolean topUp = false;
    private static boolean packages = false;
    private static boolean rates = false;
    private static boolean support = false;
    private static boolean futureMessage = false;
    private static boolean burnMessage = false;
    private static boolean e2e = false;

    public static boolean hasE2e() {
        return e2e;
    }

    public static boolean hasCallerId() {
        return callerId;
    }

    public static boolean hasDid() {
        return did;
    }

    public static boolean hasRecharge() {
        return recharge;
    }

    public static boolean hasTopUp() {
        return topUp;
    }

    public static boolean hasPackages() {
        return packages;
    }

    public static boolean hasRates() {
        return rates;
    }

    public static boolean hasSupport() {
        return support;
    }

    public static boolean hasFutureMessage() {
        return futureMessage;
    }

    public static boolean hasBurnMessage() {
        return burnMessage;
    }

    private Features(Builder builder) {
        callerId = builder.callerId;
        did = builder.did;
        recharge = builder.recharge;
        topUp = builder.topUp;
        packages = builder.packages;
        rates = builder.rates;
        support = builder.support;
        futureMessage = builder.futureMessage;
        burnMessage = builder.burnMessage;
        e2e = builder.e2e;
    }


    public static Builder newBuilder(){
        return new Builder();
    }
    public static final class Builder {
        private boolean callerId;
        private boolean did;
        private boolean recharge;
        private boolean topUp;
        private boolean packages;
        private boolean rates;
        private boolean support;
        private boolean futureMessage = false;
        private boolean burnMessage = false;
        private boolean e2e = false;
        public Builder() {
        }

        public Builder withCallerId(boolean val) {
            callerId = val;
            return this;
        }

        public Builder withFutureMessage(boolean val) {
            futureMessage = val;
            return this;
        }

        public Builder withBurnMessage(boolean val) {
            burnMessage = val;
            return this;
        }

        public Builder withDid(boolean val) {
            did = val;
            return this;
        }

        public Builder withRecharge(boolean val) {
            recharge = val;
            return this;
        }

        public Builder withTopUp(boolean val) {
            topUp = val;
            return this;
        }

        public Builder withPackages(boolean val) {
            packages = val;
            return this;
        }

        public Builder withRates(boolean val) {
            rates = val;
            return this;
        }

        public Builder withSupport(boolean val) {
            support = val;
            return this;
        }

        public Builder withE2E(boolean val) {
            e2e = val;
            return this;
        }

        public Features build() {
            return new Features(this);
        }
    }
}
