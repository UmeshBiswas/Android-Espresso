package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.RetryEntry;

import java.util.Date;
import java.util.List;

/**
 * Created By suvo on January 31, 2019
 * Project baseDialerCommon
 */

public class RetryRepo {
    private static final RetryRepo ourInstance = new RetryRepo();

    private RetryRepo() {
    }


    public List<RetryEntry> getAll() {
        return AppDatabase.get().retryDao().getAll();
    }

    public void insertAll(List<RetryEntry> retryEntryList) {
        AppDatabase.get().retryDao().insertAll(retryEntryList);
    }

    public static RetryRepo get() {
        return ourInstance;
    }

    public void createRetryEntry(String callerId, int bTime, String number, boolean isGroup, int retry_count) {
        RetryEntry retryEntry = RetryEntry.newBuilder()
                .callerId(callerId)
                .number(number)
                .exactRetryTime(new Date(System.currentTimeMillis() + (bTime * 1000)))
                .retryTime(bTime)
                .type(isGroup ? RetryEntry.BurnTimerEntryType.GROUP_CHAT : RetryEntry.BurnTimerEntryType.SINGLE_CHAT)
                .retryCount(retry_count)
                .build();
        AppDatabase.get().retryDao().insert(retryEntry);

    }

    public boolean checkRetryExists(String callerId) {
        return AppDatabase.get().retryDao().checkRetryExistsByCallerId(callerId);
    }

    public int getRetryCountByCallerId(String callerId) {
        return AppDatabase.get().retryDao().getRetryCountByCallerId(callerId);
    }


    public int deleteRetryByCallerId(String callerId) {
        return AppDatabase.get().retryDao().deleteRetryByCallerId(callerId);
    }


}
