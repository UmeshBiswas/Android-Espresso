package com.revesoft.itelmobiledialer.did;

/**
 * Created by Rahat on 10/17/2017.
 */

public class CallHistory {
    private String si, originator, terminator, connectTime, duration, callCost, didNumber;

    public CallHistory(String si, String originator, String terminator, String connectTime, String duration, String callCost, String didNumber) {
        this.si = si;
        this.originator = originator;
        this.terminator = terminator;
        this.connectTime = connectTime;
        this.duration = duration;
        this.callCost = callCost;
        this.didNumber = didNumber;
    }

    public String getSi() {
        return si;
    }

    public String getOriginator() {
        return originator;
    }

    public String getTerminator() {
        return terminator;
    }

    public String getConnectTime() {
        return connectTime;
    }

    public String getDuration() {
        return duration;
    }

    public String getCallCost() {
        return callCost;
    }

    public String getDidNumber() {
        return didNumber;
    }
}
