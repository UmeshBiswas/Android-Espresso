package com.revesoft.itelmobiledialer.dialer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.revesoft.api.fileApi.FileApiError;
import com.revesoft.api.fileApi.fileApiInterfaces.ApiResponseListener;
import com.revesoft.api.fileApi.fileApiInterfaces.FileDownloadListener;
import com.revesoft.itelmobiledialer.Config.Config;
import com.revesoft.itelmobiledialer.Config.Features;
import com.revesoft.itelmobiledialer.account.AboutActivity;
import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.account.EditProfileActivity;
import com.revesoft.itelmobiledialer.adapter.ViewPagerAdapter;
import com.revesoft.itelmobiledialer.appApi.API;
import com.revesoft.itelmobiledialer.appApi.ProfileApi;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.callog.callLogList.CallLogListFragment;
import com.revesoft.itelmobiledialer.chat.chatList.ChatListFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatConstants;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.contact.list.ContactFragmentMultiList;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickedListener;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickerActivity;
import com.revesoft.itelmobiledialer.contact.picker.ContactSelectiontype;
import com.revesoft.itelmobiledialer.customview.LockableViewPager;
import com.revesoft.itelmobiledialer.customview.RoundedImageView;
import com.revesoft.itelmobiledialer.data.MissedCallCounter;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.dialer.dialpad.DialPadActivity;
import com.revesoft.itelmobiledialer.did.CallerIDSelectionActivity;
import com.revesoft.itelmobiledialer.did.DIDNumbersActivity;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.ims.ShareDataFromExternalAppActivity;
import com.revesoft.itelmobiledialer.interfaces.Controllable;
import com.revesoft.itelmobiledialer.interfaces.Searchable;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.notification.custom_notification.MissedCallNotification;
import com.revesoft.itelmobiledialer.packageselection.PackageHomeActivity;
import com.revesoft.itelmobiledialer.phonebook.ContactSelectionActivity;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.rates.RateListActivity;
import com.revesoft.itelmobiledialer.recharge.PaymentFragment;
import com.revesoft.itelmobiledialer.recharge.RechargeOptionsActivity;
import com.revesoft.itelmobiledialer.service.ActionConstants;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.service.DialerServiceBinder;
import com.revesoft.itelmobiledialer.service.DialerServiceUtil;
import com.revesoft.itelmobiledialer.service.contact.CommonDataLoaderService;
import com.revesoft.itelmobiledialer.service.contact.ContactManagerService;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.topup.TopUpLogReportActivity;
import com.revesoft.itelmobiledialer.util.AppIconNotification;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.CustomNotification;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.NativeContactUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.util.Version;
import com.revesoft.material.BuildConfig;
import com.revesoft.material.R;
import com.revesoft.revechatsdk.Utility.ReveChat;
import com.revesoft.revechatsdk.ui.ReveChatActivity;
import com.revesoft.revechatsdk.visitor.VisitorInfo;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.viewpager.widget.ViewPager;

import static com.revesoft.itelmobiledialer.util.Constants.STATUS_CHANGED_ACTION;

@SuppressWarnings("all")
public class DashboardActivity extends BaseActivity implements TabLayout.OnTabSelectedListener, ViewPager.OnPageChangeListener, Controllable,
        NavigationView.OnNavigationItemSelectedListener {
    private static final String TAG = "DashboardActivity";
    public static final String RESET_TEXT = "copaidCallVisibilitym.revesoft.itelmobiledialer.message.reset_text";
    public static final String UPDATE_BALANCE = "com.revesoft.itelmobiledialer.message.update_balance";
    public static final String UPDATE_INFO = "com.revesoft.itelmobiledialer.message.update_info";
    public static final String CLEAR_NUMBER = "com.revesoft.itelmobiledialer.message.update_number";
    public static final String UPDATE_DURATION = "com.revesoft.itelmobiledialer.message.update_duration";
    public static final String UPDATE_DISPLAY_STATUS = "com.revesoft.itelmobiledialer.message.update_display_status";
    public static final String UPDATE_REGISTRATION_IMAGE = "com.revesoft.itelmobiledialer.message.update_registration_image";
    public static final String GROUP_CREATED = "com.revesoft.itelmobiledialer.message.group_created";
    public static final String ENABLE_CALL_BUTTON = "com.revesoft.itelmobiledialer.message.enable_call_button";
    public static final String UPDATE_CALL_STATUS = "com.revesoft.itelmobiledialer.message.update_call_status";
    public static final String UPDATE_SMS_STATUS = "com.revesoft.itelmobiledialer.message.update_sms_status";
    public static final String START_RINGING = "com.revesoft.itelmobiledialer.message.start_ringing";
    public static final String STOP_RINGING = "com.revesoft.itelmobiledialer.message.stop_ringing";
    public static final String UPDATE_INFO_STATUS = "com.revesoft.itelmobiledialer.message.update_info_status";
    public static final String UPDATE_OPERATOR_NAME = "com.revesoft.itelmobiledialer.message.update_operator_name";
    public static final String UPDATE_OPERATOR_WEBSITE = "com.revesoft.itelmobiledialer.message.update_operator_website";
    public static final String UPDATE_NUMBER = "com.revesoft.itelmobiledialer.message.update_number";
    public static final String GET_OPERATOR_CODE = "com.revesoft.itelmobiledialer.message.get_operator_code";
    public static final String OPERATOR_NAME = "operator_name";
    public static final String OPERATOR_WEBSITE = "operator_website";
    public static final String RATE_DURATION = "rate_duration";
    public static final String PHONE_NUMBER = "phone_number";
    public static final String SHOW_TOPUP = "show_topup";

    public static final int POSITION_MESSAGE = -1;
    public static final int POSITION_DIALPAD = -2;
    public static final int POSITION_PROFILE = 0;
    public static final int POSITION_HOME = 1;
    public static final int POSITION_TOPUP = 2;
    public static final int POSITION_SUPPORT = 3;
    public static final int POSITION_ABOUT = 4;
    public static final int POSITION_RATES = 5;
    public static final int POSITION_INVITE = 6;
    public static final int POSITION_PACKAGE = 7;
    public static final int POSITION_SETTINGS = 8;

    public static boolean DASHBOARD_ACTIVE = false;
    private SharedPreferences pref;
    private DialerServiceBinder mServiceBinder = null;
    public static int navigationDrawerSelectedItem = 1;
    private final int APPVIRALITY_REQUEST_CODE = 5000;
    private Handler handler;
    public static final int REQUEST_INVITE = 3232;
    private BroadcastReceiver mDeepLinkReceiver;
    private Intent mCachedInvitationIntent;
    private int notification_count = 0;
    private TextView notification = null;
    private View message_notification;
    MenuItem actionMessageItem;
    Toolbar toolbar;
    FloatingActionButton fab;
    Snackbar snackbar;
    private Intent serviceIntent;
    public static Activity dashboardActivity;
    private static int imNotification = 0;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        LanguageManager.initialize(this.getApplicationContext());
        setContentView(R.layout.activity_dashboard_layout);
        dashboardActivity = this;
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            Window w = getWindow(); // in Activity's onCreate() for instance
//            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
//        }
//        UserDataManager.destroyCompletedProfileInfoUpdate();
        Log.i("notification_chat", "Logging out.. will crash now");
        UserDataManager.setIsReadyToSendSubscribe(true);
        PreferenceDataManager.quickPut(Constants.USER_READY_FOR_NOTIFICATION, true);
        PreferenceDataManager.quickPut(Constants.SHOW_NOTIFICATION, true);
        PreferenceDataManager.setIsReadyToCreateDB();
        Intent contactLoader = new Intent(getApplicationContext(), ContactManagerService.class);
        contactLoader.putExtra(Constants.RELOAD_CONTACTS, true);
        startService(contactLoader);
        serviceIntent = new Intent(this, DialerService.class);
        startService(serviceIntent);
        mServiceBinder = new DialerServiceBinder(DashboardActivity.this).doBindService();

        final long st = System.currentTimeMillis();
        handler = new Handler();
        pref = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
//        handlePush();
        handleToolbar();
        handleFab();
        handleTabs();
        handleViewpager();
        handleNav();
        IntentFilter filter = new IntentFilter(Constants.DASHBOARD_INTENT_FILTER);
        filter.addAction(Constants.DIALPAD_INTENT_FILTER);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter);

        if (pref.getInt(Constants.FIRST_LAUNCH_, 100) != 200) {
            pref.edit().putInt(Constants.FIRST_LAUNCH_, 200).commit();
            if (Config.DIALER_VARIANT == DialerService.DialerVariant.SALAM) handleAPIForAllRate();
        }

        if (Config.DIALER_VARIANT == DialerService.DialerVariant.SALAM) {
            handleAPIForBalanceQuery();
            handleAPIForSalamOutNumber();
            Util.getSalamONumberViaReturnID(this);
        }


        String s = getIntent().getAction();
        if (s != null && s.equals(Intent.ACTION_VIEW)) {

            Log.i("notification_chat","entered");
            if (getIntent().getExtras().containsKey(ChatConstants.KEY_NUMBER)) {
                final String groupId = getIntent().getStringExtra(ChatConstants.KEY_NUMBER);
                I.log(">> " + groupId);
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        Log.i("notification_chat", groupId + " called from gid");
                        ChatWindowActivity.start(DashboardActivity.this,"",groupId,false,false,false,null);
                    }
                }, 1000);
            }
            else if (getIntent().getExtras().containsKey(ChatConstants.KEY_NUMBER)) {
                final String phoneNumber = getIntent().getStringExtra(ChatConstants.KEY_NUMBER);
                I.log(">> " + phoneNumber);
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        Log.i("notification_chat",phoneNumber);
                        ChatWindowActivity.start(DashboardActivity.this,phoneNumber,"",false,false,false,null);
                    }
                }, 1000);
            }
            else {
                I.log(">> trick failed");
            }
            ContactEngine.CustomContactData ccd = ContactEngine.getCustomContactData(this, getIntent().getData());
            if (ccd != null) {
                Log.d("DATA", "tvName: " + ccd.name + "tvNumber: " + ccd.number + "mimetype: " + ccd.mimeType + "summery: " + ccd.summery + "details: " + ccd.details);
                if (ccd.mimeType != null) {
                    if (ccd.mimeType.equalsIgnoreCase("vnd.android.cursor.item/com.airtel.airteltalk.mimetype_call")) {
                        sendIntentMessageToDialer(Constants.START_CALL, ccd.number);
                    } else if (ccd.mimeType.equalsIgnoreCase("vnd.android.cursor.item/com.airtel.airteltalk.mimetype_im")) {
                        switchToMessage(null);
                        sendIntentMessageToDialer(Constants.START_IMS, ccd.number);
                    }
                }
            }
        }
        Bundle b = getIntent().getExtras();
        if (b != null) {
            if (b.containsKey(CustomNotification.INTENT_TYPE_IM)) {
                String number = b.getString(CustomNotification.INTENT_EXTRA_NUMBER);
                String groupid = b.getString(CustomNotification.INTENT_EXTRA_GROUP_ID);
                Log.d(TAG, "onResume - Phone tvNumber: " + number);
                if (DialerServiceUtil.getAccess().messagesToCallIDList != null) {
                    if (groupid != null)
                        DialerServiceUtil.getAccess().clearMessageToCallIdList(groupid);
                    else DialerServiceUtil.getAccess().clearMessageToCallIdList(number);
                }
                switchToMessage(null);
                if (groupid == null || groupid.length() == 0) {
                    sendIntentMessageToDialer(Constants.START_IMS, number);
                } else {
                    sendIntentMessageToDialer(Constants.START_GROUP_IMS, groupid);
                }

            }
            else if (b.containsKey(MissedCallNotification.INTENT_TYPE_MISSED_CALL)) {
                switchToHistory();
            }
            else if (b.containsKey("startcall")) {
                String number = b.getString("startcall");
                sendIntentMessageToDialer(Constants.START_CALL, number);
            }
        }

        DASHBOARD_ACTIVE = true;

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startService(new Intent(DashboardActivity.this, CommonDataLoaderService.class));
            }
        }, 5000);




        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadInfo();
            }
        }, 2000);

//        IntentFilter historyFetchingIntentFilter = new IntentFilter();
//        historyFetchingIntentFilter.addAction(Constants.GENERIC_HISTORY_RECEIVED_ACTION);
//        historyFetchingIntentFilter.addAction(Constants.INITIATE_IM_MAIN_HISTORY_REQUEST_ACTION);
//        LocalBroadcastManager.newInstance(this).registerReceiver(historyFetchingReceiver, historyFetchingIntentFilter);
//
//        boolean isFirstRequestMade = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Context.MODE_PRIVATE).getBoolean(Constants.FIRST_REQUEST_MADE, false);
//        if (!isFirstRequestMade && SIPProvider.registrationFlag) {
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE).edit().putBoolean(Constants.FIRST_REQUEST_MADE, true).commit();
//                    sendIMMainHistoryRequest();
//                }
//            }, 5000);
//        }
//        VirtualNumberCollector.getAndSetVirtualNumber();

        if (checkIfDataFromOtherAppAvailable(getIntent()))
            StartSharingDataFromOtherApp(getIntent(), this, ShareDataFromExternalAppActivity.class);

        IntentUtil.sendCurrentStatus(this);
        snackbar = Snackbar.make(findViewById(R.id.topCL),
                "Connecting to server ...", Snackbar.LENGTH_INDEFINITE);
        Util.updateConnectedSnackbarOnInternetStatus(this, snackbar);
        sendIntentMessageToDialer(Constants.START_RETRY_HANDLER, "");
    }

    private void handleNav() {
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(DashboardActivity.this);
        ivProfilePicture = navigationView.getHeaderView(0).findViewById(R.id.ivProfilePicture);
        ivProfilePictureBigBackground = navigationView.getHeaderView(0).findViewById(R.id.ivProfilePictureBigBackground);
        tvName = navigationView.getHeaderView(0).findViewById(R.id.tvName);
        tvNameBack = navigationView.getHeaderView(0).findViewById(R.id.tvNameBack);
        tvPresenceNote = navigationView.getHeaderView(0).findViewById(R.id.tvPresenceNote);
        tvPresenceNoteBack = navigationView.getHeaderView(0).findViewById(R.id.tvPresenceNoteBack);
        tvBalance = navigationView.getHeaderView(0).findViewById(R.id.tvBalance);
        tvBalanceBack = navigationView.getHeaderView(0).findViewById(R.id.tvBalanceBack);

        handleFeatures();
    }

    private void handleFeatures() {
        MenuItem account = navigationView.getMenu().getItem(0);
        MenuItem callerId = navigationView.getMenu().getItem(1);
        MenuItem did = navigationView.getMenu().getItem(2);
        MenuItem recharge = navigationView.getMenu().getItem(3);
        MenuItem topUp = navigationView.getMenu().getItem(4);
        MenuItem packages = navigationView.getMenu().getItem(5);
        MenuItem rates = navigationView.getMenu().getItem(6);
        MenuItem support = navigationView.getMenu().getItem(7);
        MenuItem about = navigationView.getMenu().getItem(8);

        callerId.setVisible(Features.hasCallerId());
        did.setVisible(Features.hasDid());
        recharge.setVisible(Features.hasRecharge());
        topUp.setVisible(Features.hasTopUp());
        packages.setVisible(Features.hasPackages());
        rates.setVisible(Features.hasRates());
        support.setVisible(Features.hasSupport());
    }

    RoundedImageView ivProfilePicture;
    ImageView ivProfilePictureBigBackground;
    TextView tvPresenceNote, tvPresenceNoteBack, tvName, tvNameBack;
    TextView tvBalance, tvBalanceBack;

    private void handleProfile() {
        final String profilePicturePath = UserDataManager.getProfilePicturePath();
        ImageUtil.setImageButDefaultOnException(DashboardActivity.this, profilePicturePath, ivProfilePicture, R.drawable.person);
        ivProfilePictureBigBackground.setImageResource(R.drawable.bg1);
        tvName.setText(UserDataManager.getFullName());
        tvNameBack.setText(UserDataManager.getFullName());
        tvPresenceNote.setText(UserDataManager.getPresenceNote());
        tvPresenceNoteBack.setText(UserDataManager.getPresenceNote());
        tvBalance.setText(getString(R.string.balance_colon) + " " + UserDataManager.getBalance() + " " + "USD");
        tvBalanceBack.setText(getString(R.string.balance_colon) + " " + UserDataManager.getBalance() + " " + "USD");
    }

    private void
    handleAPIForBalanceQuery() {
        Util.getBalance(this);
    }

    private void handleAPIForAllRate() {
        if (UserDataManager.getSalamNumberActivated()) {
            HashMap<String, String> map = new HashMap<>();
            map.put("requesttype", "3");
            map.put("virtualNumber", UserDataManager.getSalamNumber());
            API.getAccess().makeRequest(map, new ApiResponseListener() {
                @Override
                public void onSuccess(String response) {
                    Log.d("vir_all", response);
                    if (response.contains("errorCode=0")) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                I.toast("all rate found ", true);
                            }
                        });
                    } else {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                I.toast("all rate not found", true);
                            }
                        });
                    }


                }

                @Override
                public void onFailed(String reason) {
                    I.err(reason);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            I.toast(getString(R.string.somethingWentWrong), true);
                        }
                    });
                }
            });
        }
    }


    private void handleAPIForSalamOutNumber() {
        Log.e("hello_s", UserDataManager.getUserName());

        if (Util.isKyrgyzNumber(UserDataManager.getUserName()) && !UserDataManager.getSalamNumberActivated()) {
            HashMap<String, String> map = new HashMap<>();
            map.put("requesttype", "7");
            API.getAccess().makeRequest(map, new ApiResponseListener() {
                @Override
                public void onSuccess(String response) {
                    I.err("virtual_api_success" + response);
                    if (response.contains("errorCode=0")) {
                        UserDataManager.setSalmNumberActivated(true);
                        UserDataManager.setSalamNumber(UserDataManager.getUserName());
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                I.toast("virtual number activated", true);
                            }
                        });
                    } else {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                I.toast(getString(R.string.somethingWentWrong), true);
                            }
                        });
                    }


                }

                @Override
                public void onFailed(String reason) {
                    I.err("virtual_api_failed" + reason);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            I.toast(getString(R.string.somethingWentWrong), true);

                        }
                    });
                }
            });
        }
    }

    private boolean checkIfDataFromOtherAppAvailable(Intent receivedIntent) {
        return (receivedIntent.getAction() != null
                && (Intent.ACTION_SEND.equals(receivedIntent.getAction()) ||
                Intent.ACTION_SEND_MULTIPLE.equals(receivedIntent.getAction()))
                && receivedIntent.getType() != null) ? true : false;
    }

    private void StartSharingDataFromOtherApp(Intent receivedIntent, Activity activity, Class c) {
        receivedIntent.setClass(activity, c);
        startActivity(receivedIntent);
    }


    private boolean shouldUpdate(String appVersion, String stunVersion) {
        try {
            String[] appVersionParts = appVersion.split("\\.");
            String[] stunVersionParts = stunVersion.split("\\.");
            Log.d("ShouldUpdate", appVersionParts[0] + appVersionParts[1] + appVersionParts[2] + " " + stunVersionParts[0] + stunVersionParts[1] + stunVersionParts[2]);
            return !(appVersionParts.length < 3 || stunVersionParts.length < 3) &&
                    (Integer.parseInt(stunVersionParts[0]) > Integer.parseInt(appVersionParts[0]) ||
                            Integer.parseInt(stunVersionParts[0]) == Integer.parseInt(appVersionParts[0]) &&
                                    (Integer.parseInt(stunVersionParts[1]) > Integer.parseInt(appVersionParts[1]) ||
                                            Integer.parseInt(stunVersionParts[1]) == Integer.parseInt(appVersionParts[1]) &&
                                                    (Integer.parseInt(stunVersionParts[2]) > Integer.parseInt(appVersionParts[2]))));
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void checkForUpdate(String packageName) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName)));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + packageName)));
        }
    }

    protected void onPause() {
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        AppIconNotification.setCountInAppIcon();
        Log.d(TAG, "onResume");
        if (viewPager.getCurrentItem() == ITEM_CALLS) {
            MissedCallCounter.clearCount();
            MissedCallCounter.sendSignalToDashBoard();
        }
        checkForUpdateAndShowDialog();
        handleProfile();
        if (getIntent().getIntExtra("im_window", 0) == 1) imNotification = 1;
//        try {
////            updateNotificationCount();
//            if (enteredWiFiSettings) {
//                restartSipProvider();
//                enteredWiFiSettings = false;
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        try {
            updatePhoneAndMessageCountInTab();
            if (imNotification == 1) viewPager.setCurrentItem(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkForUpdateAndShowDialog() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!SIPProvider.getStunInfo().mandatoryAutoUpdate && SIPProvider.getStunInfo().dialerVersion.length > 0 && pref.getBoolean(Constants.SHOW_NEW_VERSION, Constants.SHOW_NEW_VERSION_DEF)) {
                        Log.d("DashaboardActivity", "version tvName: " + SIPProvider.getStunInfo().dialerVersion.toString() + " check value: " + (new Version(SIPProvider.getStunInfo().dialerVersion.toString()).compare(BuildConfig.VERSION_NAME)));
                        if ((new Version(SIPProvider.getStunInfo().dialerVersion.toString()).compare(BuildConfig.VERSION_NAME)) > 0) {
                            showUpdateDialog();
                        }
                    } else if (SIPProvider.getStunInfo().mandatoryAutoUpdate && SIPProvider.getStunInfo().dialerVersion.length > 0) {
                        if ((new Version(SIPProvider.getStunInfo().dialerVersion.toString()).compare(BuildConfig.VERSION_NAME)) > 0) {
                            showMandatoryDialog();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        Log.e("DashboardActivity", "onDestroy");
        getSupportLoaderManager().destroyLoader(0);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        sendIntentMessageToDialer(Constants.STOP_SERVICE, "");
        mServiceBinder.doUnbindService();
        DASHBOARD_ACTIVE = false;
        stopService(serviceIntent);
        Log.e("DashboardActivity", "Destroying app");
        super.onDestroy();
    }

    private void hideSoftKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String s = intent.getAction();
        if (s != null && s.equals(Intent.ACTION_VIEW)) {
            if (getIntent().getExtras().containsKey(ChatConstants.KEY_NUMBER)) {
                final String groupId = getIntent().getStringExtra(ChatConstants.KEY_NUMBER);
                I.log(">> " + groupId);
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        Log.i("notification_chat", groupId + " called from gid");
                        ChatWindowActivity.start(DashboardActivity.this,"",groupId,false,false,false,null);
                    }
                }, 1000);
            }
            else if (getIntent().getExtras().containsKey(ChatConstants.KEY_NUMBER)) {
                final String phoneNumber = getIntent().getStringExtra(ChatConstants.KEY_NUMBER);
                I.log(">> " + phoneNumber);
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        Log.i("notification_chat",phoneNumber);
                        ChatWindowActivity.start(DashboardActivity.this,phoneNumber,"",false,false,false,null);
                    }
                }, 1000);
            }
            else {
                I.log(">> trick failed");
            }
            ContactEngine.CustomContactData ccd = ContactEngine.getCustomContactData(this, intent.getData());
            if (ccd != null) {
                Log.d("DATA", "tvName: " + ccd.name + "tvNumber: " + ccd.number + "mimetype: " + ccd.mimeType + "summery: " + ccd.summery + "details: " + ccd.details);
                if (ccd.mimeType != null) {
                    if (ccd.mimeType.equalsIgnoreCase("vnd.android.cursor.item/com.airtel.airteltalk.mimetype_call")) {
                        sendIntentMessageToDialer(Constants.START_CALL, ccd.number);
                    } else if (ccd.mimeType.equalsIgnoreCase("vnd.android.cursor.item/com.airtel.airteltalk.mimetype_im")) {
                        switchToMessage(null);
                        sendIntentMessageToDialer(Constants.START_IMS, ccd.number);
                    }
                }
            }
        }
        Bundle b = intent.getExtras();
        if (b != null) {
            if (b.containsKey(CustomNotification.INTENT_TYPE_IM)) {
                String number = b.getString(CustomNotification.INTENT_EXTRA_NUMBER);
                String groupid = b.getString(CustomNotification.INTENT_EXTRA_GROUP_ID);
                Log.d(TAG, "onResume - Phone tvNumber: " + number);
                if (DialerServiceUtil.getAccess().messagesToCallIDList != null) {
//                    DialerServiceUtil.get().messagesToCallIDList.clear();       >>sayma
                    if (groupid != null)
                        DialerServiceUtil.getAccess().clearMessageToCallIdList(groupid);
                    else DialerServiceUtil.getAccess().clearMessageToCallIdList(number);
                }
                switchToMessage(null);
                if (groupid == null || groupid.length() == 0) {
                    sendIntentMessageToDialer(Constants.START_IMS, number);
                } else {
                    sendIntentMessageToDialer(Constants.START_GROUP_IMS, groupid);
                }
            } else if (b.containsKey(MissedCallNotification.INTENT_TYPE_MISSED_CALL)) {
                switchToHistory();
            } else if (b.containsKey("startcall")) {
                String number = b.getString("startcall");
                sendIntentMessageToDialer(Constants.START_CALL, number);
            }
        }

    }

    private void switchToMessage(String number) {
        try {
            if (number == null || number.equals("")) {
                //we do nothing
            } else {
                Intent i = new Intent(this, ChatWindowActivity.class);
                i.putExtra(ChatConstants.KEY_NUMBER, number);
                startActivity(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void switchToHistory() {
        try {
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkForCredential() {
        boolean credentialFound = false;
        pref = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
        String user = UserDataManager.getUserName();
        String password = UserDataManager.getUserPassword();

        if (user.length() != 0 && password.length() != 0) {
            credentialFound = true;
        }

        return credentialFound;
    }

    private void sendIntentMessageToDialer(String type, String number) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, number);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public void sendMakeCallMessage(String number, int type) {
        Message msg = mServiceBinder.getBoundedService().getNewMessage();
        msg.what = type;
        msg.obj = number;
        mServiceBinder.getBoundedService().sendMessage(msg, null);
    }

    public void sendEndCallMessage() {
        Message msg = mServiceBinder.getBoundedService().getNewMessage();
        msg.what = ActionConstants.END_CALL;
        mServiceBinder.getBoundedService().sendMessage(msg, null);
    }

    public void exit() {
        Log.e(TAG, "exit()");
        if (mServiceBinder != null && mServiceBinder.getBoundedService() != null) {
            Message msg = mServiceBinder.getBoundedService().getNewMessage();
            msg.what = ActionConstants.STOP_SERVICE;
            mServiceBinder.getBoundedService().sendMessage(msg, null);
            mServiceBinder.doUnbindService();
        }
//        IntentUtil.sendAppExitMessage(DashboardActivity.this);
        finish();
    }

    BroadcastReceiver receiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();

            if (bundle != null) {
                if (bundle.containsKey(Constants.EXIT)) {
                    exit();
                } else if (bundle.containsKey(MissedCallNotification.INTENT_TYPE_MISSED_CALL)) {
                    switchToHistory();
                } else if (bundle.containsKey("check_for_update")) {
                    checkForUpdateAndShowDialog();
                } else if (bundle.containsKey("startcall")) {
                    String number = bundle.getString("startcall");
                    sendIntentMessageToDialer(Constants.START_CALL, number);
                } else if (bundle.containsKey(UPDATE_REGISTRATION_IMAGE)) {
                    boolean registration_staus = bundle.getBoolean(UPDATE_REGISTRATION_IMAGE);
                    Log.d(TAG, "UPDATE_REGISTRATION_IMAGE " + registration_staus);
                    if (registration_staus) {
                        if (snackbar != null && snackbar.isShown()) {
                            snackbar.dismiss();
                        }
                    } else {
                        if (snackbar != null && !snackbar.isShown()) {
                            Util.updateConnectedSnackbarOnInternetStatus(DashboardActivity.this, snackbar);
                        }
                    }
                } else if (bundle.containsKey(STATUS_CHANGED_ACTION)) {
                } else if (bundle.containsKey(Constants.Broadcast.TYPE_MISSED_CALL_COUNT_SIGNAL)
                        || bundle.containsKey(Constants.Broadcast.TYPE_UNSEEN_IMS_COUNT_SIGNAL)) {
                    updatePhoneAndMessageCountInTab();
                } else if (bundle.containsKey(DashboardActivity.UPDATE_BALANCE)) {
                    tvBalance.setText(getString(R.string.balance_colon) + " " + UserDataManager.getBalance() + " " + "USD");
                    tvBalanceBack.setText(getString(R.string.balance_colon) + " " + UserDataManager.getBalance() + " " + "USD");
                }
                else if (bundle.containsKey(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE))
                {
                    Log.i("Tanveeee","received");
                }
            }
        }

    };

    private void updatePhoneAndMessageCountInTab() {
//        if (true)
//            return;//for teleport we don't need that. but not removing as will be need for some future project. just remove this line
        Executor.ex(() -> {
            String unseenMessageCount = MessageRepo.get().getUnseenPersonMessagesCount() + "";
            Gui.get().run(() -> {
                if (unseenMessageCount != null && !unseenMessageCount.trim().equals("0")) {
                    tvMessageBadge.setVisibility(View.VISIBLE);
                    tvMessageBadge.setText(unseenMessageCount);
                } else {
                    tvMessageBadge.setVisibility(View.GONE);
                }
                int unseenCallsCount = MissedCallCounter.getMissedCallCount();
                if (unseenCallsCount != 0) {
                    tvRecentBadge.setVisibility(View.VISIBLE);
                    tvRecentBadge.setText(String.format(Locale.ENGLISH, "%d", unseenCallsCount));
                } else {
                    tvRecentBadge.setVisibility(View.INVISIBLE);
                }
            });

        });


    }

    SearchView searchView;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        final MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
            setSearchCursorColorToAccent(searchView);
        }
        if (searchView != null) {
            changeSearchIcon();

            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setIconifiedByDefault(true);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    Fragment currentFragment = getCurrentFragment();
                    Searchable searchable = null;
                    if (currentFragment instanceof Searchable) {
                        searchable = (Searchable) currentFragment;
                    }
                    if (searchable != null) {
                        if (TextUtils.isEmpty(newText)) {
                            searchable.search("");
                        } else {
                            searchable.search(newText);
                        }
                    }
                    return true;
                }
            });
        }
        return super.onCreateOptionsMenu(menu);
    }

    private void setSearchCursorColorToAccent(SearchView searchView) {
        AutoCompleteTextView searchTextView = (AutoCompleteTextView) searchView.findViewById(R.id.search_src_text);
        try {
            Field mCursorDrawableRes = TextView.class.getDeclaredField("mCursorDrawableRes");
            mCursorDrawableRes.setAccessible(true);
            mCursorDrawableRes.set(searchTextView, R.drawable.cursor);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    int currentItemPosition = ITEM_CHATS;

    private Fragment getCurrentFragment() {
        return pagerAdapter.getItem(currentItemPosition);
    }

    private void changeSearchIcon() {
        ImageView ivSearchIcon = (ImageView) searchView.findViewById(R.id.search_button);
        if (ivSearchIcon != null) {
//            ivSearchIcon.setImageResource(R.drawable.ic_menu_search);
        }
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem searchViewMenuItem = menu.findItem(R.id.app_bar_search);
        searchView = (SearchView) searchViewMenuItem.getActionView();
        int searchImgId = getResources().getIdentifier("android:id/search_button", null, null);
        for (int i = 0; i < searchView.getChildCount(); i++) {
            View view = searchView.getChildAt(i);
            Log.e("err", view.getId() + " " + i);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(Gravity.LEFT);
                return true;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    synchronized private void replaceFragment(Fragment fragment) {
        try {
            supportInvalidateOptionsMenu();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.container, fragment).commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    boolean pressedBackOnce = false;

    @Override
    public void onBackPressed() {
        if (pressedBackOnce) {
            Util.exitDialer(this);
            finish();
        }
        pressedBackOnce = true;
        I.toast(getString(R.string.pressBackAgain));
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                pressedBackOnce = false;
            }
        }, 1500);
    }


    private ShowNetworkAlertRunnable showNetworkAlertRunnable = new ShowNetworkAlertRunnable();
    private static final int NETWORK_ALERT = 12;

    private void showNetworkAlert() {
        handler.post(showNetworkAlertRunnable);
    }


    private final class ShowNetworkAlertRunnable implements Runnable {
        @Override
        public void run() {
            showDialog(NETWORK_ALERT);
        }
    }

    private boolean enteredWiFiSettings = false;

    private Dialog createNetworkDialog(int title, int text) {
        return new AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_launcher)
                .setMessage(text)
                .setTitle(title)
                .setPositiveButton(R.string.network_dialog_connect,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                startActivity(new Intent(
                                        Settings.ACTION_WIFI_SETTINGS));
                                enteredWiFiSettings = true;
                            }
                        })
                .setNegativeButton(R.string.network_dialog_work_offlie,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                DialerService.WORK_OFFLINE = true;
                                restartSipProvider();
                            }
                        }).setOnCancelListener(new DialogInterface.OnCancelListener() {

                    @Override
                    public void onCancel(DialogInterface dialog) {
                        exit();

                    }
                }).create();
    }

    private synchronized void restartSipProvider() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.RESTART_SIP_PROVIDER, "");
        LocalBroadcastManager.getInstance(this).sendBroadcast(i);
    }

    private void showExitDialog() {
        final Dialog exitDialog = new Dialog(DashboardActivity.this);
        exitDialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // Removes empty padding at top
        exitDialog.setContentView(R.layout.dialogue_exit);
        exitDialog.show();
        exitDialog.setCancelable(true);

        // These should be found/cast as a button (findViewById expects a View to be returned)
        exitDialog.findViewById(R.id.exit_dialogue_button_ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exit();
                exitDialog.dismiss();
            }
        });

        exitDialog.findViewById(R.id.exit_dialogue_button_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitDialog.dismiss();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ContactSelectionActivity.CONTACT_SELECTION_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data.hasExtra(ContactSelectionActivity.KEY_RESULT)) {
                List<Contact> contacts = (List<Contact>) data.getSerializableExtra(ContactSelectionActivity.KEY_RESULT);
                if (contacts != null && contacts.size() > 0) {
                    String numbers = "";
                    for (Contact contact : contacts) {
                        numbers += contact.processedNumber + " ";
                    }
                    I.toast(numbers);
                } else {
                    I.toast("no contacts selected");
                }
            } else {
                I.toast("Cancelled or no data");
            }
        }
        Log.d("Mkhan-DashboardActivity", "onActivityResult in Dashboard activity (" + requestCode + "," + resultCode + "," + data);

        //The IAB helper passes the Activity result of In App purchase to the parent activity
        //In our case the Dashboard activity
        //pass the activity result handling of in app purchase to Payment fragment

        if (requestCode == PaymentFragment.REQUEST_CODE_GOOGLE_PLAY_IN_APP || requestCode == PaymentFragment.REQUEST_CODE_PAYPAL_PAYMENT) {
            PaymentFragment.getInstance().onActivityResult(requestCode, resultCode, data);
        }
//        else if ((requestCode == APPVIRALITY_REQUEST_CODE) && (resultCode == -1)) {
//            startActivity(new Intent(this, AppViralityRegistration.class));
//        }
        else if (requestCode == REQUEST_INVITE) {
            if (resultCode == RESULT_OK) {
                // Check how many invitations were sent and show message to the user
                // The ids array contains the unique invitation ids for each invitation sent
                // (one for each contact select by the user). You can use these for analytics
                // as the ID will be consistent on the sending and receiving devices.
//                String[] ids = AppInviteInvitation.getInvitationIds(resultCode, data);
//                for (String id : ids) {
//                    log("ID: " + id);
//                }
                showMessage(getString(R.string.sent_successful));
            }
//            else {
            // Sending failed or it was canceled, show failure message to the user
//                showMessage(getString(R.string.send_failed));
//            }
        } else if (requestCode == 140) {
            //twitter
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    // AlertDialogs do not show on Android 2.3 if they are trying to be displayed while the activity is pause.
    // We sleep for 500ms to wait for the activity to be ready before displaying.
    private void showNotificationDialog(final Intent intent) {
        handler.postDelayed(new Runnable() {
            public void run() {
                DashboardActivity.this.startActivity(intent);
            }
        }, 500);
    }

//    private static void showNotificationDialog(final Intent intent) {
//        new Thread(new Runnable() {
//            public void run() {
//                try {Thread.sleep(500);} catch(Throwable t) {}
//                DashboardActivity.currentActivity.runOnUiThread(new Runnable() {
//                    public void run() {
//                        DashboardActivity.currentActivity.startActivity(intent);
//                    }
//                });
//            }
//        }).start();
//
//    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Dashboard", "in onStart()");
    }

    @Override
    protected void onStop() {
        Log.d("Dashboard", "in onStop()");
        unregisterDeepLinkReceiver();
        super.onStop();
    }

    private void unregisterDeepLinkReceiver() {
        if (mDeepLinkReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mDeepLinkReceiver);
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    AlertDialog updateVersionDialog = null;

    private void showUpdateDialog() {
        if (updateVersionDialog != null && updateVersionDialog.isShowing()) {
            return;
        }

        final AlertDialog.Builder dialogBuilder;

//        if(Build.VERSION.SDK_INT > 10) dialogBuilder = new AlertDialog.Builder(this,R.style.ZiptTheme_Dialog);
//        else
        dialogBuilder = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialogue_update_dialer, null);
        dialogBuilder.setView(dialogView);
        Button updateButton = (Button) dialogView.findViewById(R.id.update_button);
        Button denyUpdateButton = (Button) dialogView.findViewById(R.id.dont_update_button);
        CheckBox stopRemindAboutUpdate = (CheckBox) dialogView.findViewById(R.id.dont_ask_again_button);

        updateVersionDialog = dialogBuilder.create();
        updateVersionDialog.setCanceledOnTouchOutside(false);

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkForUpdate(getPackageName());
                updateVersionDialog.dismiss();
            }
        });

        denyUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateVersionDialog.dismiss();
            }
        });

        stopRemindAboutUpdate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                pref.edit().putBoolean(Constants.SHOW_NEW_VERSION, !isChecked).apply();
            }
        });

        updateVersionDialog.setCancelable(false);
        updateVersionDialog.show();
    }

    private void showMandatoryDialog() {
        if (updateVersionDialog != null && updateVersionDialog.isShowing()) {
            updateVersionDialog.dismiss();
        }

        final AlertDialog.Builder dialogBuilder;

//        if(Build.VERSION.SDK_INT > 10) dialogBuilder = new AlertDialog.Builder(this,R.style.ZiptTheme_Dialog);
//        else
        dialogBuilder = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialogue_update_dialer_mandatory, null);
        dialogBuilder.setView(dialogView);
        Button updateButton = (Button) dialogView.findViewById(R.id.update_button);
        Button denyUpdateButton = (Button) dialogView.findViewById(R.id.dont_update_button);
        CheckBox stopRemindAboutUpdate = (CheckBox) dialogView.findViewById(R.id.dont_ask_again_button);
        if (SIPProvider.getStunInfo().mandatoryUpdateReason.length > 0) {
            ((TextView) dialogView.findViewById(R.id.message)).setText(SIPProvider.getStunInfo().mandatoryUpdateReason.toString());
        }

        updateVersionDialog = dialogBuilder.create();
        updateVersionDialog.setCanceledOnTouchOutside(false);

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkForUpdate(SIPProvider.getStunInfo().autoUpdateUrl.toString());
                updateVersionDialog.dismiss();
            }
        });

        denyUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateVersionDialog.dismiss();
            }
        });

        stopRemindAboutUpdate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                pref.edit().putBoolean(Constants.SHOW_NEW_VERSION, !isChecked).apply();
            }
        });

        updateVersionDialog.setCancelable(false);
        updateVersionDialog.show();
    }

//    public void updateNotificationCount() {
//        notification_count = DatabaseConstants.newInstance(DashboardActivity.this)
//                .getCombinedMessageNotificationCount();
//
//        if (notification == null) return;
//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                if (notification_count == 0)
//                    notification.setVisibility(View.INVISIBLE);
//                else {
//                    notification.setVisibility(View.VISIBLE);
//                    notification.setText(Integer.toString(notification_count));
//                }
//            }
//        });
//    }

    static abstract class MyMenuItemStuffListener implements View.OnClickListener, View.OnLongClickListener {
        private String hint;
        private View view;

        MyMenuItemStuffListener(View view, String hint) {
            this.view = view;
            this.hint = hint;
            view.setOnClickListener(this);
            view.setOnLongClickListener(this);
        }

        @Override
        abstract public void onClick(View v);

        @Override
        public boolean onLongClick(View v) {
            final int[] screenPos = new int[2];
            final Rect displayFrame = new Rect();
            view.getLocationOnScreen(screenPos);
            view.getWindowVisibleDisplayFrame(displayFrame);
            final Context context = view.getContext();
            final int width = view.getWidth();
            final int height = view.getHeight();
            final int midy = screenPos[1] + height / 2;
            final int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
            Toast cheatSheet = Toast.makeText(context, hint, Toast.LENGTH_SHORT);
            if (midy < displayFrame.height()) {
                cheatSheet.setGravity(Gravity.TOP | Gravity.RIGHT,
                        screenWidth - screenPos[0] - width / 2, height);
            } else {
                cheatSheet.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, height);
            }
            cheatSheet.show();
            return true;
        }
    }


    private void handleFab() {
        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentItemPosition == ITEM_CALLS) {
                    startActivity(new Intent(DashboardActivity.this, DialPadActivity.class));
                } else if (currentItemPosition == ITEM_CHATS) {
                    ContactPickerActivity.startPicker(DashboardActivity.this, ContactType.APP,ContactSelectiontype.SINGLE_SELECT,new ContactPickedListener() {
                        @Override
                        public void onContactPicked(List<String> contacts, List<ContactListItem> contactListItems) {
                            String selectedContact = contacts.get(0);
                            Switcher.switchToChatWindow(DashboardActivity.this,selectedContact,false,false,false,false);
                        }
                    });
                } else {
                    NativeContactUtil.startCreateContactAction(DashboardActivity.this);
                }
            }
        });
    }



    int countCallback = 0;

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setTitle(getString(R.string.app_name));
            actionBar.setHomeAsUpIndicator(R.drawable.teleport_logo);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    //=========================================TAB LAYOUT AND VIEW PAGER HACK=======================================
    TabLayout tabLayout;
    LockableViewPager viewPager;
    ViewPagerAdapter pagerAdapter;

    private void handleViewpager() {
        viewPager = (LockableViewPager) findViewById(R.id.viewPager);
        viewPager.setSwipeLocked(false);
        preparePagerAdapter();
        viewPager.setOffscreenPageLimit(TOTAL_TAB_ITEM);
        viewPager.setAdapter(pagerAdapter);
        viewPager.addOnPageChangeListener(this);
    }


    private void preparePagerAdapter() {
        pagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        pagerAdapter.addFragment(ChatListFragment.getInstance());
        pagerAdapter.addFragment(CallLogListFragment.newInstance());
        pagerAdapter.addFragment(ContactFragmentMultiList.getInstance());

    }

    private void handleTabs() {
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);

        callsTab = tabLayout.newTab();
        callsTab.setCustomView(R.layout.badge_tab_layout);

        messageTab = tabLayout.newTab();
        messageTab.setCustomView(R.layout.badge_tab_layout);

        contactsTab = tabLayout.newTab();
        contactsTab.setCustomView(R.layout.badge_tab_layout);


        tabLayout.addTab(messageTab);
        tabLayout.addTab(callsTab);
        tabLayout.addTab(contactsTab);
        handleRecentAndMessageTab();
        updatePhoneAndMessageCountInTab();
        tabLayout.clearOnTabSelectedListeners();
        tabLayout.addOnTabSelectedListener(DashboardActivity.this);
    }

    TabLayout.Tab messageTab, callsTab, contactsTab;
    TextView tvRecentBadge, tvMessageBadge;
    TextView tvMessageTabTitle;
    TextView tvRecentTabTitle;
    TextView tvContactsTabTitle;

    private void handleRecentAndMessageTab() {
        tvMessageTabTitle = (TextView) messageTab.getCustomView().findViewById(R.id.tvTabLabel);
        tvMessageTabTitle.setText(getString(R.string.chats));
        tvRecentTabTitle = (TextView) callsTab.getCustomView().findViewById(R.id.tvTabLabel);
        tvRecentTabTitle.setText(getString(R.string.calls));
        tvContactsTabTitle = (TextView) contactsTab.getCustomView().findViewById(R.id.tvTabLabel);
        tvContactsTabTitle.setText(getString(R.string.contacts));
        tvMessageBadge = (TextView) messageTab.getCustomView().findViewById(R.id.tvTabBadge);
        tvRecentBadge = (TextView) callsTab.getCustomView().findViewById(R.id.tvTabBadge);

        contactsTab.getCustomView().findViewById(R.id.tvTabBadge).setVisibility(View.GONE);
    }

    @SuppressLint("RestrictedApi")
    private void handleKeyboardHiding() {
        if (searchView != null) {
            searchView.clearFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(searchView.getWindowToken(), InputMethodManager.HIDE_IMPLICIT_ONLY);
        }
    }

    private void handleFabIcon() {
        switch (currentItemPosition) {
            case ITEM_CALLS:
                fab.setImageResource(R.drawable.ic_fab_dialpad);
                break;
            case ITEM_CHATS:
                fab.setImageResource(R.drawable.ic_fab_chat);
                break;
            case ITEM_CONTACTS:
                fab.setImageResource(R.drawable.ic_fab_add_contact);
                break;
        }
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        if (viewPager.getCurrentItem() != tab.getPosition()) {
            invalidateOptionsMenu();
            currentItemPosition = tab.getPosition();
            viewPager.setCurrentItem(tab.getPosition());
            handleKeyboardHiding();
            handleFabIcon();
        }
        if (tab.getPosition() == 0) {
            MissedCallNotification.cancelAll();
        }


    }


    @Override
    public void onControlRequest(ControlRequestType controlRequestType) {

    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        currentItemPosition = position;
        tabLayout.getTabAt(position).select();
        handleFabIcon();
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private static final int TOTAL_TAB_ITEM = 3;
    private static final int ITEM_CALLS = 1;
    private static final int ITEM_CHATS = 0;
    private static final int ITEM_CONTACTS = 2;


    private void loadInfo() {
        ProfilePicUploadDownloadHelper profilePicUploadDownloadHelper = new ProfilePicUploadDownloadHelper(this);
        if (UserDataManager.getFullName().length() == 0) {
            profilePicUploadDownloadHelper.getProfileInfoAndSave(ProfilePicUploadDownloadHelper.mPictureServerUri, UserDataManager.getUserName(), UserDataManager.getUserPassword());
        }
        if (!ProfilePicUploadDownloadHelper.getProfilePictureFile(DashboardActivity.this, null).exists() && !getString(R.string.opcode).equals("")) {
            ProfileApi.downloadProfilePicture(DashboardActivity.this, null, new FileDownloadListener() {
                @Override
                public void onDownloadFinished(String filePath) {
                    handleProfile();
                }

                @Override
                public void onDownloadError(FileApiError e) {
                    Log.e(TAG,"error ",e);
                }

                @Override
                public void onDownloadProgress(int progress) {
                    Log.i(TAG,"Progress = "+progress);
                }
            });
        }
    }

    public void goToEditProfile(View view) {
        Intent intent = new Intent(DashboardActivity.this, EditProfileActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
//        if (id == R.id.nav_chat) {
//            Toast.makeText(DashboardActivity.this, "new chat", Toast.LENGTH_SHORT).show();
//        }
//        else
//        if (id == R.id.nav_call) {
//            startActivity(new Intent(DashboardActivity.this, CallLogListActivity.class));
//        } else if (id == R.id.nav_contacts) {
//            startActivity(new Intent(DashboardActivity.this, ContactListActivity.class));
//        } else
        if (id == R.id.nav_caller_id) {
            startActivity(new Intent(this, CallerIDSelectionActivity.class));
        } else if (id == R.id.nav_did) {
//            Toast.makeText(DashboardActivity.this, getString(R.string.wip), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, DIDNumbersActivity.class));
        } else if (id == R.id.nav_recharge) {
//            Toast.makeText(DashboardActivity.this, getString(R.string.wip), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(DashboardActivity.this, RechargeOptionsActivity.class));
        } else if (id == R.id.nav_topup) {
//            Toast.makeText(DashboardActivity.this, getString(R.string.wip), Toast.LENGTH_SHORT).show();
            mServiceBinder.getBoundedService().setTopupCredential();
            startActivity(new Intent(DashboardActivity.this, TopUpLogReportActivity.class));
        } else if (id == R.id.nav_packages) {
//            Toast.makeText(DashboardActivity.this, getString(R.string.wip), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(DashboardActivity.this, PackageHomeActivity.class));
        } else if (id == R.id.nav_rates) {
//            Toast.makeText(DashboardActivity.this, getString(R.string.wip), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, RateListActivity.class));
        } else if (id == R.id.nav_account) {
            startActivity(new Intent(this, AccountActivity.class));
        } else if (id == R.id.nav_support) {
            initReveChatVisitorInfo();
            startActivity(new Intent(this, ReveChatActivity.class));
        } else if (id == R.id.nav_about) {
            startActivity(new Intent(this, AboutActivity.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    private void initReveChatVisitorInfo()
    {
        Log.i("tanveer",UserDataManager.getEmail());
        VisitorInfo visitorInfo = new VisitorInfo.Builder()
                .name(UserDataManager.getFullName()).email(UserDataManager.getEmail())
                .phoneNumber(UserDataManager.getUserPhoneNo()).build();
        ReveChat.setVisitorInfo(visitorInfo);
    }


}

