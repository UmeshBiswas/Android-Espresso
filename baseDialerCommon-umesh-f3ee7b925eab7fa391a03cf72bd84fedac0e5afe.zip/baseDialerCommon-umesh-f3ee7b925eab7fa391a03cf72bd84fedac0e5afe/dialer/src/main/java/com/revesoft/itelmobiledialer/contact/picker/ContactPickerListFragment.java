package com.revesoft.itelmobiledialer.contact.picker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.arch.LazyFragment;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.contact.list.ContactListViewModel;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.list.ContactViewModelFactory;
import com.revesoft.itelmobiledialer.contact.FavoriteContactsActivity;
import com.revesoft.itelmobiledialer.block.BlockedContactActivity;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModelOwner;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ContactPickerListFragmentLayoutBinding;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Ifta Noor Mahmood
 * Created by Ifta Noor Mahmood on 1/24/2017.
 */

public class ContactPickerListFragment extends LazyFragment implements FilterableViewModelOwner,ContactChangeListener {
    private static final boolean gotFoolishRequest = false;//make it true for fools
    public static final String TAG = "ContactPickerListFragment";
    private static final String KEY_HAS_OPTION_MENU = "KEY_HAS_OPTION_MENU";
    private static final String KEY_CONTACT_TYPE = "KEY_CONTACT_TYPE";
    private static final String KEY_CONTACT_SELECTION_TYPE = "KEY_CONTACT_SELECTION_TYPE";
    private ContactPickerListFragmentLayoutBinding binding;

    public ContactPickerListFragment() {
    }


    public static ContactPickerListFragment newInstance(boolean hasOptionMenu, ContactType contactType, ContactSelectiontype contactSelectiontype) {
        Bundle bundle = new Bundle();
        bundle.putBoolean(KEY_HAS_OPTION_MENU, hasOptionMenu);
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        bundle.putSerializable(KEY_CONTACT_SELECTION_TYPE,contactSelectiontype);
        ContactPickerListFragment fragment = new ContactPickerListFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    public static Fragment newInstance(ContactType contactType) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        Fragment fragment = new ContactPickerListFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            boolean hasOptionMenu = bundle.getBoolean(KEY_HAS_OPTION_MENU);
            contactTypeToLoad = (ContactType) bundle.getSerializable(KEY_CONTACT_TYPE);
            contactSelectiontype = (ContactSelectiontype) bundle.getSerializable(KEY_CONTACT_SELECTION_TYPE);
            setHasOptionsMenu(hasOptionMenu);
        }
    }


    private ContactPickerListAdapter adapter;
    private ContactListViewModel viewModel;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        binding = DataBindingUtil.inflate(inflater, R.layout.contact_picker_list_fragment_layout, container, false);
        initEmptyListLayout();
        adapter = new ContactPickerListAdapter(getActivity(),contactSelectiontype);
        binding.rv.setAdapter(adapter);
        if (gotFoolishRequest) {
            IntentFilter filter = new IntentFilter(Constants.DASHBOARD_INTENT_FILTER);
            if (getActivity() != null && isAdded()) {
                LocalBroadcastManager.getInstance(getActivity()).registerReceiver(broadcastReceiver, filter);
            }
        }
        return binding.getRoot();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (gotFoolishRequest) {
            LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(broadcastReceiver);
        }
    }


    private void initEmptyListLayout() {
        binding.emptyListLayout.tvEmptyListDescription.setText(getString(R.string.noContactFound));
        binding.emptyListLayout.ivEmptyListIcon.setImageResource(R.drawable.ic_big_no_contact);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private ContactType contactTypeToLoad = ContactType.ALL;
    private ContactSelectiontype contactSelectiontype = ContactSelectiontype.MULTIPLE_SELECT;


    private void showEmptyViewMessage() {
        if (searchText.length() != 0) {
            return;
        }
        binding.emptyListLayout.getRoot().setVisibility(View.VISIBLE);
        binding.indexFragmentHolderPhoneBook.setVisibility(View.GONE);
    }

    private void hideEmptyViewMessage() {
        binding.emptyListLayout.getRoot().setVisibility(View.GONE);
        binding.indexFragmentHolderPhoneBook.setVisibility(View.VISIBLE);
    }

    @Override
    public void search(String searchString) {
        this.searchText = searchString;
        viewModel.filter(this, searchString);
        watchViewModel();
    }

    private String searchText = "";

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_contacts, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuFavoritesContacts:
                Intent intent = new Intent(getActivity(), FavoriteContactsActivity.class);
                startActivity(intent);
                return true;
            case R.id.menuBlockedContacts:
                startBlockedContactActivity();
                return true;
            case R.id.menuAccount:
                Intent accountIntent = new Intent(getActivity(), AccountActivity.class);
                startActivity(accountIntent);
                return true;
        }
        return false;
    }

    private void startBlockedContactActivity() {
        Intent intent = new Intent(getActivity(), BlockedContactActivity.class);
        startActivity(intent);
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (this.isVisible()) {
            if (!isVisibleToUser) {
                if (!searchText.equals("")) {
                    search("");
                }
            }
        }
    }

    @Override
    public void loadData() {
        viewModel = ViewModelProviders.of(this, new ContactViewModelFactory(contactTypeToLoad)).get(ContactListViewModel.class);
        watchViewModel();
    }

    public static String getTAG() {
        return TAG;
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(Constants.Broadcast.TYPE_SUBSCRIBER_INFO_LOADED_SIGNAL)) {
                    adapter.notifyDataSetChanged();
                } else if (bag.containsKey(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE)) {
                    adapter.notifyDataSetChanged();
                }
            }
        }
    };

    private int totalContactCount =0;

    @Override
    public void watchViewModel() {
        viewModel.getPagedData().observe(this, contactListItems -> {
            binding.progressBar.setVisibility(View.GONE);
            adapter.submitList(contactListItems);
            if(searchText.equals("")) {
                totalContactCount = contactListItems.size();
            }

            if (contactListItems.size() == 0) {
                showEmptyViewMessage();
            } else {
                hideEmptyViewMessage();
            }
        });
    }

    @Override
    public void onChangeContact(ContactListItem item) {
        adapter.changeSelection(item);
    }

    void reDrawAll() {
        adapter.notifyDataSetChanged();
    }

    String getCount() {
        return String.valueOf(totalContactCount);
    }
}
