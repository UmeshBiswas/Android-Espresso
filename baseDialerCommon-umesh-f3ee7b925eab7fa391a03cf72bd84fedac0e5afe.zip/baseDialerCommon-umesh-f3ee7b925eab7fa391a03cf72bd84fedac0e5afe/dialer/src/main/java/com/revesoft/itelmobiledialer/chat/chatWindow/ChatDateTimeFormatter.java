package com.revesoft.itelmobiledialer.chat.chatWindow;

import android.app.AlarmManager;
import android.widget.DatePicker;
import android.widget.TimePicker;


import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * @author Ifta on 12/13/2017.
 */

public class ChatDateTimeFormatter {
    private static final SimpleDateFormat headerDateFormat = new SimpleDateFormat("dd MMMM", Locale.ENGLISH);
    private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.ENGLISH);
    private static final SimpleDateFormat chatHistoryFormat = new SimpleDateFormat("dd, MMM yyyy", Locale.ENGLISH);
    private static final SimpleDateFormat chatHeaderDateComparatorFormatter = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);
    private static final SimpleDateFormat durationFormat = new SimpleDateFormat("mm:ss", Locale.ENGLISH);
    private static final SimpleDateFormat futureDateTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);

    public static String getHeaderDate(long time) {
        return headerDateFormat.format(time);
    }

    public static String getMessageTime(long time) {
        return timeFormat.format(time);
    }

    public static String getFutureMessageDateTime(long time) {
        return  futureDateTimeFormatter.format(time);
    }

    public static String getComparableDate(long time) {
        return chatHeaderDateComparatorFormatter.format(time);
    }

    public static String getChatHistoryDate(long time) {
        String comparableDate = chatHeaderDateComparatorFormatter.format(time);
        String today = chatHeaderDateComparatorFormatter.format(System.currentTimeMillis());
        String yesterDay = chatHeaderDateComparatorFormatter.format((System.currentTimeMillis() - AlarmManager.INTERVAL_DAY));
        if (comparableDate.equals(today)) {
            return Supplier.getString(R.string.today);
        } else if (comparableDate.equals(yesterDay)) {
            return Supplier.getString(R.string.yesterday);
        } else {
            return chatHistoryFormat.format(time);
        }
    }

    public static String getDuration(long millis) {
        return durationFormat.format(millis);
    }

    public static Date getTimeForFutureMessage(DatePicker datePicker, TimePicker timePicker) {
        StringBuilder sendTime = new StringBuilder();
        sendTime.append(datePicker.getYear()).append("-");
        int month = datePicker.getMonth();
        month++;
        if (month < 10) {
            sendTime.append("0").append(month).append("-");
        } else {
            sendTime.append(month).append("-");
        }

        int day = datePicker.getDayOfMonth();
        if (day < 10) {
            sendTime.append("0").append(day).append("T");
        } else {
            sendTime.append(day).append("T");
        }

        int hour = timePicker.getCurrentHour();
        if (hour < 10) {
            sendTime.append("0").append(hour).append(":");
        } else {
            sendTime.append(hour).append(":");
        }

        int minute = timePicker.getCurrentMinute();
        if (minute < 10) {
            sendTime.append("0").append(minute).append("Z");
        } else {
            sendTime.append(minute).append("Z");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.ENGLISH);
        try {
            return sdf.parse(sendTime.toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}
