package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.view.View;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.material.R;

public class LocationMessageViewHolder extends TextMessageViewHolder implements OnMapReadyCallback {
    private MapView mapView;
    private GoogleMap map;

    public LocationMessageViewHolder(View view) {
        super(view);
        mapView = view.findViewById(R.id.mapView);
        if (mapView != null) {
            mapView.onCreate(null);
            mapView.getMapAsync(LocationMessageViewHolder.this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        setMapLocation();
    }

    private void setMapLocation() {
        if (map == null) return;
        LatLng latLng = (LatLng) mapView.getTag();
        if (latLng == null) return;
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13f));
        map.addMarker(new MarkerOptions().position(latLng));
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }

    @Override
    public void bindView(Message message) {
        super.bindView(message);
        LatLng latLng = ChatContentParser.parseLocation(message.content);
        mapView.setTag(latLng);
        setMapLocation();
    }
}
