package com.revesoft.itelmobiledialer.account;

import android.content.res.Resources;

import com.revesoft.itelmobiledialer.privacy.PrivacyStates;
import com.revesoft.material.R;


/**
 * @author Ifta
 * on 5/21/2017.
 */

public class PrivacyStatesStringProvider {
    private static final int EVERYONE = 0;
    private static final int MY_CONTACTS = 1;
    private static final int NOBODY = 2;

    static String getStringByValue(Resources resources, PrivacyStates states) {
        switch (states) {
            case EveryOne:
                return resources.getString(R.string.everyOne);
            case NoBody:
                return resources.getString(R.string.nobody);

            case MyContacts:
                return resources.getString(R.string.myContacts);
            default:
                return "";
        }
    }

    public static String[] getStates(Resources resources) {
        return new String[]{resources.getString(R.string.everyOne), resources.getString(R.string.myContacts), resources.getString(R.string.nobody)};
    }
}
