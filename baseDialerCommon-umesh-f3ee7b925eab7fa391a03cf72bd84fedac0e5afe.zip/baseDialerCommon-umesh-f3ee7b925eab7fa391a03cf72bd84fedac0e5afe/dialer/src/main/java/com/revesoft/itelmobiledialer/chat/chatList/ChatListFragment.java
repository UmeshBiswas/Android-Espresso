package com.revesoft.itelmobiledialer.chat.chatList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.revesoft.itelmobiledialer.account.AccountActivity;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.arch.LazyFragment;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.DriveServiceHelper;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.GoogleDriveChatBackupApi;
import com.revesoft.itelmobiledialer.chat.chatCreation.ChatStarter;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickedListener;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickerActivity;
import com.revesoft.itelmobiledialer.ims.ChatMemberSelectionActivity;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModelOwner;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ChatListFragmentBinding;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

public class ChatListFragment extends LazyFragment implements FilterableViewModelOwner {
    private static Fragment fragment = null;
    private ChatListViewModel model;

    public static Fragment getInstance() {
        if (fragment == null) {
            fragment = new ChatListFragment();
        }
        return fragment;
    }

    private ChatListFragmentBinding binding;
    private ChatListAdapter adapter;

    private static final int REQUEST_CODE_SIGN_IN = 1;
    boolean isBackup = true;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        binding = DataBindingUtil.inflate(inflater,
                R.layout.chat_list_fragment,
                container, false);
        adapter = new ChatListAdapter(getActivity());
        binding.list.setAdapter(adapter);
        setHasOptionsMenu(true);
        return binding.getRoot();
    }

    @Override
    public void loadData() {
        model = ViewModelProviders.of(this).get(ChatListViewModel.class);
        watchViewModel();
    }

    @Override
    public void watchViewModel() {
        model.getPagedData().observe(ChatListFragment.this, chatListItems -> {
            adapter.submitList(chatListItems);
            adapter.notifyDataSetChanged();
            binding.progressBar.setVisibility(View.GONE);
        });
    }

    @Override
    public void search(String searchString) {
        model.filter(this, searchString);
        watchViewModel();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_messages, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    private DriveServiceHelper mDriveServiceHelper;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_new_group) {
            Intent intent = new Intent(getActivity(), ChatMemberSelectionActivity.class);
//            startActivity(intent);
            ContactPickerActivity.startPicker(getActivity(), ContactType.APP, new ContactPickedListener() {
                @Override
                public void onContactPicked(List<String> contacts, List<ContactListItem>contactListItems) {
                    ChatStarter.createGroupChat(getActivity(),contacts);
                }
            });
            return true;
        } else if (item.getItemId() == R.id.action_account_show) {
            startActivity(new Intent(getActivity(), AccountActivity.class));
            return true;
        } else if (item.getItemId() == R.id.backup_chat_now) {
            isBackup = true;
            if (mDriveServiceHelper == null) {
                requestSignIn();
            } else backupOrRestoreChat();
        } else if (item.getItemId() == R.id.restore_chat_now) {
            isBackup = false;
            if (mDriveServiceHelper == null) {
                requestSignIn();
            } else backupOrRestoreChat();
        }



        return super.onOptionsItemSelected(item);
    }

    public void backupOrRestoreChat() {
        Executor.ex(() -> {
            GoogleDriveChatBackupApi googleDriveChatBackupApi = new GoogleDriveChatBackupApi(mDriveServiceHelper);
            if (isBackup) googleDriveChatBackupApi.backUpChatNow();
            else googleDriveChatBackupApi.restoreChatNow();
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == REQUEST_CODE_SIGN_IN) {
                handleSignInResult(data);
            }
        }
    }


    private void requestSignIn() {

        GoogleSignInOptions signInOptions =
                new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail()
                        .requestScopes(new Scope(DriveScopes.DRIVE_FILE))
                        .build();
        GoogleSignInClient client = GoogleSignIn.getClient(Objects.requireNonNull(getContext()), signInOptions);

        // The result of the sign-in Intent is handled in onActivityResult.
        startActivityForResult(client.getSignInIntent(), REQUEST_CODE_SIGN_IN);
    }

    /**
     * Handles the {@code result} of a completed sign-in activity initiated from {@link
     * #requestSignIn()}.
     */
    private void handleSignInResult(Intent result) {
        GoogleSignIn.getSignedInAccountFromIntent(result)
                .addOnSuccessListener(googleAccount -> {

                    // Use the authenticated account to sign in to the Drive service.
                    GoogleAccountCredential credential =
                            GoogleAccountCredential.usingOAuth2(
                                    getContext(), Collections.singleton(DriveScopes.DRIVE_FILE));
                    credential.setSelectedAccount(googleAccount.getAccount());
                    Drive googleDriveService =
                            new Drive.Builder(
                                    AndroidHttp.newCompatibleTransport(),
                                    new GsonFactory(),
                                    credential)
                                    .setApplicationName("Drive API Migration")
                                    .build();

                    // The DriveServiceHelper encapsulates all REST API and SAF functionality.
                    // Its instantiation is required before handling any onClick actions.
                    mDriveServiceHelper = new DriveServiceHelper(googleDriveService);
                    backupOrRestoreChat();
                })
                .addOnFailureListener(exception -> Log.e("", "Unable to sign in.", exception));
    }
}
