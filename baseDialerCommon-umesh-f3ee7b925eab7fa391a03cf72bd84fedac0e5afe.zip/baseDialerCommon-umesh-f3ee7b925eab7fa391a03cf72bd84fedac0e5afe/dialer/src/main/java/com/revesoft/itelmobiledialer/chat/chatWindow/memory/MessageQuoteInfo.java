package com.revesoft.itelmobiledialer.chat.chatWindow.memory;

/**
 * @author Ifta on 2/15/2018.
 */

public class MessageQuoteInfo {
    public static String quoteMessageOriginatorCallId;
    public static  boolean isInQuoteMode = false;
    public static void clear() {
        quoteMessageOriginatorCallId = null;
        isInQuoteMode = false;
    }
}
