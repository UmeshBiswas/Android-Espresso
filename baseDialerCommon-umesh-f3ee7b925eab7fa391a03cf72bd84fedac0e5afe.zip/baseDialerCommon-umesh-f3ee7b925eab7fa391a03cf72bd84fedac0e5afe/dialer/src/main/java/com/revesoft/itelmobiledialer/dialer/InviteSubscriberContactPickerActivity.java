package com.revesoft.itelmobiledialer.dialer;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.iftalab.runtimepermission.AppPermissionListener;
import com.iftalab.runtimepermission.PermissionDialogActivity;
import com.revesoft.itelmobiledialer.appDatabase.repo.SubscriberRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatConstants;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.chat.share.ShareActivity;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.revesoft.itelmobiledialer.util.Constants.compose;

public class InviteSubscriberContactPickerActivity extends BaseActivity implements
        LoaderManager.LoaderCallbacks<Cursor> {

    Button mCancelButton;
    TextView mSendButton;
    String mCurFilter;
    private ContactListAdapter mAdapter = null;
    private RecyclerView mRecyclerView = null;
    private RecyclerView.LayoutManager mLayoutManager;
    EditText mSearchEditText;
    private static final int CONTACT_LOADER_ID = 0;
    TextView mTvSelectedNumbers;
    TextView mTvSelectedNumbersCount;
    LinearLayout mLlSelectedNumbersCount;
    private LinkedHashMap<Long, ContactListAdapter.Contact> mCheckedHashMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_contact_picker);
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        IntentFilter mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(Constants.CALL_PROGRESSING_PAGE_FINISH_INTENT);
        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, mIntentFilter);

        initView();
    }

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };

    private void initView() {
        mCancelButton = findViewById(R.id.cancel);
        mCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        mSendButton = findViewById(R.id.send);
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((mCheckedHashMap.size() > 0)) {
                    showSendSmsDialog();
                } else {
                    I.toast(Supplier.getString(R.string.please_select_at_least_one_contact));
                }
            }
        });

        mSearchEditText = findViewById(R.id.searchText);
        mSearchEditText.addTextChangedListener(new SearchTextWatcher());

        mRecyclerView = findViewById(R.id.member_list);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new ContactListAdapter();
        mRecyclerView.setAdapter(mAdapter);

        mTvSelectedNumbers = findViewById(R.id.tv_selected_numbers);
        mTvSelectedNumbersCount = findViewById(R.id.tv_contact_count);
        mLlSelectedNumbersCount = findViewById(R.id.ll_contact_count);

        getSupportLoaderManager().initLoader(CONTACT_LOADER_ID, null, this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mReceiver);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new SQLiteCursorLoader(this) {

            @Override
            public Cursor loadInBackground() {

                Cursor cursor = null;
                try {
                    if (mCurFilter == null || mCurFilter.length() == 0) {
                        cursor = SubscriberRepo.get().getSubscriberCursor();
                    } else {
                        cursor = SubscriberRepo.get().getSubscriberSearch(mCurFilter);
//                        cursor = DatabaseConstants.getInstance(InviteSubscriberContactPickerActivity.this).getOnlySubscriberContacts(mCurFilter);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    int n = cursor.getCount();
                    Log.e("count", " " + n);
                    this.registerContentObserver(cursor, DatabaseConstants.SUBSCRIBER_URI);
                }

                return cursor;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (loader.getId() == CONTACT_LOADER_ID) {
            mAdapter.swapCursor(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        if (loader.getId() == CONTACT_LOADER_ID) {
            mAdapter.swapCursor(null);
        }
    }

    public boolean onQueryTextChange(String newText) {
        String newFilter = !TextUtils.isEmpty(newText) ? newText : null;
        if (mCurFilter == null && newFilter == null) {
            return true;
        }
        if (mCurFilter != null && mCurFilter.equals(newFilter)) {
            return true;
        }
        mCurFilter = newFilter;
        getSupportLoaderManager().restartLoader(CONTACT_LOADER_ID, null, this);
        return true;
    }

    private class SearchTextWatcher implements TextWatcher {
        @Override
        public void onTextChanged(CharSequence s, int start, int before,
                                  int count) {
            onQueryTextChange(mSearchEditText.getText().toString());
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
            // TODO Auto-generated method stub
        }

        @Override
        public void afterTextChanged(Editable s) {
            // TODO Auto-generated method stub
        }
    }

    class ContactListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int EMPTY_VIEW = 10;
        private Cursor mCursor;
        StringBuilder mSelectedNumbers;

        class Contact {
            String name;
            String number;

            public Contact(String name, String number) {
                this.name = name;
                this.number = number;
            }
        }

        public ContactListAdapter() {
            mCheckedHashMap = new LinkedHashMap<>();
            mSelectedNumbers = new StringBuilder();
        }

        private void updateSelectedNumbersHeader() {
            mSelectedNumbers.setLength(0);
            int i = 0;
            for (Map.Entry<Long, Contact> entry : mCheckedHashMap.entrySet()) {
                if (i == 0)
                    mSelectedNumbers.append(entry.getValue().name).append(",");
                else
                    mSelectedNumbers.append(" ").append(entry.getValue().name).append(",");
                i++;
            }
            if (mSelectedNumbers.length() > 0) {
                mTvSelectedNumbers.setText(mSelectedNumbers.toString().substring(0, mSelectedNumbers.toString().length() - 1));
            } else {
                mTvSelectedNumbers.setText(mSelectedNumbers.toString());
            }
            if (mCheckedHashMap.size() > 0) {
                mTvSelectedNumbersCount.setText(String.format("%d", mCheckedHashMap.size()));
                mLlSelectedNumbersCount.setVisibility(View.VISIBLE);
            } else {
                mLlSelectedNumbersCount.setVisibility(View.GONE);
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v;
            if (viewType == EMPTY_VIEW) {
                v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_empty_description, parent, false);
                ContactListAdapter.EmptyViewHolder vh = new ContactListAdapter.EmptyViewHolder(v);
                return vh;
            }

            v = LayoutInflater.from(parent.getContext()).inflate(R.layout.call_progressing_contact_member_row, parent, false);

            ContactListAdapter.ViewHolder vh = new ContactListAdapter.ViewHolder(v);

            return vh;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            try {
                if (holder instanceof ViewHolder) {
                    ViewHolder vh = (ViewHolder) holder;
                    vh.bindView();
                } else if (holder instanceof EmptyViewHolder) {
                    EmptyViewHolder vh = (EmptyViewHolder) holder;
                    vh.mEmptyDescription.setText(R.string.empty_contact_list);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            try {
                if (mCurFilter != null && !mCurFilter.equals("")) {
                    if (mCursor == null) {
                        return 1;
                    }

                    if (mCursor.getCount() == 0) {
                        return 1;
                    }

                    return mCursor.getCount();
                } else {
                    if (mCursor == null) {
                        return 0;
                    }

                    if (mCursor.getCount() == 0) {
                        return 0;
                    }

                    return mCursor.getCount();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }

        @Override
        public int getItemViewType(int position) {
            if (mCursor == null) return EMPTY_VIEW;
            else if (mCursor.getCount() == 0) return EMPTY_VIEW;
            return super.getItemViewType(position);

        }

        public void swapCursor(Cursor cursor) {
            mCursor = cursor;
            notifyDataSetChanged();
        }

        public class EmptyViewHolder extends RecyclerView.ViewHolder {
            public TextView mEmptyDescription;

            public EmptyViewHolder(View itemView) {
                super(itemView);
                mEmptyDescription = itemView.findViewById(R.id.empty_description);
            }
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView contactImage;
            ImageView subscriberIcon;
            AppCompatCheckBox checkBox;
            TextView contactName;
            TextView contactNumber;
            LinearLayout container;
            int intentType = 0;

            public ViewHolder(View view) {
                super(view);
                container = (LinearLayout) view;
                contactImage = view.findViewById(R.id.contact_image);
                subscriberIcon = view.findViewById(R.id.subscriber_icon);
                checkBox = view.findViewById(R.id.check_box);
                contactName = view.findViewById(R.id.contact_name);
                contactNumber = view.findViewById(R.id.contact_number);
                checkBox.setVisibility(View.GONE);
            }

            public void bindView() {
                if (mCursor == null) {
                    return;
                }
                try {
                    mCursor.moveToPosition(getAdapterPosition());

                    final String name = mCursor.getString(mCursor.getColumnIndex(DatabaseConstants.KEY_NAME));
                    final String number = mCursor.getString(mCursor.getColumnIndex(DatabaseConstants.KEY_NUMBER));
                    final String processed_number = mCursor.getString(mCursor.getColumnIndex(DatabaseConstants.KEY_PROCESSED_NUMBER));
//                    final String subscribed_number = mCursor.getString(mCursor.getColumnIndex(DatabaseConstants.KEY_SUBSCRIBED_NUMBER));
//                    final int presenceStatus = mCursor.getInt(mCursor.getColumnIndex(DatabaseConstants.KEY_PRESENCE_STATE));
//                    final String lookUpKey = mCursor.getString(mCursor.getColumnIndex(DatabaseConstants.KEY_PHONE_LOOKUP));

                    String numberN = "";
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        numberN = Util.getProperEmail(number);
                    } else {
                        //Deprecated method
                        numberN = PhoneNumberUtils.formatNumber(number);
                    }

                    contactNumber.setText(numberN);
                    contactName.setText(name);
                    String photoURI = mCursor.getString(mCursor.getColumnIndex(DatabaseConstants.KEY_PHOTO_URI));
                    final long _id = mCursor.getLong(mCursor.getColumnIndex(DatabaseConstants.KEY_ID));
                    checkBox.setChecked(mCheckedHashMap.containsKey(_id));

                    String profileImageLoadingPath = ProfilePictureDataProvider.getProfilePicturePath(processed_number);
                    ImageUtil.setImageButDefaultOnException(InviteSubscriberContactPickerActivity.this,
                            profileImageLoadingPath, this.contactImage, R.drawable.pic_phonebook_no_image);


//                    if (subscribed_number != null && subscribed_number.length() > 0) {
//                        subscriberIcon.setImageResource(R.drawable.bt_user_icon);
//                    } else {
//                        subscriberIcon.setImageResource(R.drawable.ic_out_call);
//                    }

                    subscriberIcon.setVisibility(View.GONE);

                    container.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (getIntent() != null) {
                                intentType = getIntent().getIntExtra(ChatConstants.INTENT_TYPE, -1);
                            }
                            if (intentType > 0) {
                                    PermissionDialogActivity.takePermission(v.getContext(),PermissionDialogActivity.PermissionType.Storage, new AppPermissionListener() {
                                        @Override
                                        public void onPermissionGranted() {
                                            moveToChatWindow(intentType,processed_number);
                                        }

                                        @Override
                                        public void onPermissionRejected() {
                                            moveToChatWindow(intentType,processed_number);
                                        }
                                    });

                            }
                        }
                    });

//                    checkBox.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (((CheckBox) v).isChecked()) {
//                                mCheckedHashMap.put(_id, new Contact(name, processed_number));
//                            } else {
//                                mCheckedHashMap.remove(_id);
//                            }
//
//                            updateSelectedNumbersHeader();
//                        }
//                    });

                } catch (Exception e) {
                    Log.e("ContactsFragment", "Error: " + e.getMessage());
                }
            }
        }
    }

    private void moveToChatWindow(int intentType, String processed_number){
        Intent intent = new Intent(InviteSubscriberContactPickerActivity.this, ChatWindowActivity.class);
        if (intentType == ShareActivity.FLAG_INTENT_SINGLE_TEXT) {
            intent.putExtra(ChatConstants.INTENT_VALUES, getIntent().getStringExtra(ChatConstants.INTENT_VALUES));
        } else if (intentType == ShareActivity.FLAG_INTENT_SINGLE_FILE) {
            Uri uri = getIntent().getParcelableExtra(ChatConstants.INTENT_VALUES);
            Log.d("InviteSubscriber", "onClick: single File: " + (uri != null ? uri.toString() : ""));
            intent.putExtra(ChatConstants.INTENT_VALUES, uri);
        } else if (intentType == ShareActivity.FLAG_INTENT_MULTIPLE_FILES) {
            ArrayList<Uri> arrayList = getIntent().getParcelableArrayListExtra(ChatConstants.INTENT_VALUES);
            intent.putParcelableArrayListExtra(ChatConstants.INTENT_VALUES, arrayList);
        }
        intent.putExtra(ChatConstants.INTENT_TYPE, intentType);

        intent.putExtra(ChatConstants.KEY_NUMBER, processed_number);
        intent.putExtra(ChatConstants.KEY_IS_BROADCAST, false);
        intent.putExtra(ChatConstants.KEY_IS_SMS_CHAT, false);
        intent.putExtra(ChatConstants.KEY_IS_ENCRYPTED, false);
        intent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
        startActivity(intent);
        finish();
    }


    private void showSendSmsDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.delete_alert_dialog);

        TextView dialogContent = dialog.findViewById(R.id.dialog_content);
        dialogContent.setText(R.string.sms_charged_low_rates);

        Button btnAgree = dialog.findViewById(R.id.dialog_yes_btn);
        btnAgree.setText(R.string.agree);
        btnAgree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCheckedHashMap.size() > 0) {
                    String[] numbers = new String[mCheckedHashMap.size()];
                    int i = 0;
                    for (Map.Entry<Long, ContactListAdapter.Contact> entry : mCheckedHashMap.entrySet()) {
                        numbers[i] = entry.getValue().number;
                        i++;
                    }
                    sendIntentMessageSMSToDialer(numbers);
                }

                dialog.dismiss();

                finish();
            }
        });

        Button btnCancel = dialog.findViewById(R.id.dialog_no_btn);
        btnCancel.setText(getString(R.string.cancel));
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void sendIntentMessageSMSToDialer(String[] numbers) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("sendsms", "");
        intent.putExtra(compose, getString(R.string.twitter_status));
        intent.putExtra("to1", numbers);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

}
