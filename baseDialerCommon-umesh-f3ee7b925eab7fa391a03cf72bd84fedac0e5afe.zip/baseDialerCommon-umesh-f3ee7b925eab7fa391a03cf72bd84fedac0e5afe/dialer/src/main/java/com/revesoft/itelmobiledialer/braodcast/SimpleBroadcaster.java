package com.revesoft.itelmobiledialer.braodcast;

import android.content.Context;
import android.content.Intent;

import com.revesoft.itelmobiledialer.util.Constants;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Ifta on 5/29/2017.
 */

public class SimpleBroadcaster {
    private static LocalBroadcastManager localBroadcastManager = null;

    public static void register(Context context) {
        localBroadcastManager = LocalBroadcastManager.getInstance(context);
    }

    public static void sendSignalToDashBoard(String signalType) {
        Intent intent = new Intent(Constants.DASHBOARD_INTENT_FILTER);
        intent.putExtra(signalType, true);
        localBroadcastManager.sendBroadcast(intent);
    }

    public static void sendSignalToDialer(String signalType) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.setAction(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(signalType, new String[]{});
        localBroadcastManager.sendBroadcast(intent);
    }
    public static void sendSignalToMessageModule(String signalType) {
        Intent intent = new Intent(Constants.MESSAGE_INTENT_FILTER);
        intent.putExtra(signalType,true);
        localBroadcastManager.sendBroadcast(intent);
    }
    public static void sendSignal(String signalType) {
        Intent intent = new Intent(Constants.SIGNAL_INTENT_FILTER);
        intent.putExtra(signalType,true);
        localBroadcastManager.sendBroadcast(intent);
    }

}
