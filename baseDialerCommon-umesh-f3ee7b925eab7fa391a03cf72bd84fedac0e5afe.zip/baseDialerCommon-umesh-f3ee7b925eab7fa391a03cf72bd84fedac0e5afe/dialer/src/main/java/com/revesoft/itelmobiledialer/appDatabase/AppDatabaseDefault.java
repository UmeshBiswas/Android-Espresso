package com.revesoft.itelmobiledialer.appDatabase;

import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;

import java.util.Date;

public interface AppDatabaseDefault {
    String callerId = "defaultCallerId";
    String groupId = null;
    String number = "";
    String messageContent = "";
    Date date = new Date(System.currentTimeMillis());
    MimeType mimeType = MimeType.Text;
    String lookUpKey = "";
    int DATABASE_VERSION = 1;

    String DEFAULT_CUSTOM_NOTIFICATION_TARGET = "default";
}
