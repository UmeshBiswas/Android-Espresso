package com.revesoft.itelmobiledialer.chat.chatWindow.messageSender;

import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.braodcast.QuickBroadCaster;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.group.Group;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageQuoteInfo;
import com.revesoft.itelmobiledialer.chat.stickeroid.Sticker;
import com.revesoft.itelmobiledialer.chat.tenor.TenorGif;
import com.revesoft.itelmobiledialer.confide.Smoker;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.ims.Burner;
import com.revesoft.itelmobiledialer.ims.MyLocationProvider;
import com.revesoft.itelmobiledialer.service.dialerService.BagName;
import com.revesoft.itelmobiledialer.service.dialerService.MessageBag;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.xdatabase.XTableKeys;
import com.revesoft.material.R;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import androidx.annotation.RequiresApi;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static com.revesoft.itelmobiledialer.arch.Supplier.getString;
import static com.revesoft.itelmobiledialer.util.Constants.SEND_FILE_PREFIX_SENDER;
import static com.revesoft.itelmobiledialer.util.Constants.SEND_FILE_SUFFIX_SENDER;
import static com.revesoft.itelmobiledialer.util.Constants.compose;

/**
 * @author Ifta on 12/24/2017.
 */

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class Sender {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");
    private String target;
    private boolean isGroupChat;
    private boolean isSMSChat;
    private Group group;
    private static Sender sender;
    private boolean isEncryptedChat;
    private String messageSecurityMode = "0";
    private String groupType = "1";
    private Configuration currentConfiguration;


    //public Context context;

    public static Sender getAccess() {
        if (sender == null) {
            sender = new Sender();
        }
        return sender;
    }

    public void sendLocationRequest() {
        StringBuilder askLocationData = new StringBuilder();
        float currTime = System.currentTimeMillis() / 1000f;
        askLocationData.append(Constants.ASK_LOCATION_MESSAGE_PREFIX).append(UserDataManager.getUserName()).append(Constants.ASK_LOCATION_MESSAGE_SEPARATOR)
                .append(currTime).append(Constants.ASK_LOCATION_MESSAGE_SUFFIX);
        sendTextMessage(askLocationData.toString());
    }

    public void sendLocation(LatLng latestLatLng) {
        String locationMessage = Constants.LOCATION_PREFIX + latestLatLng.latitude + "," + latestLatLng.longitude + Constants.LS_SUFIX;
        sendTextMessage(locationMessage);
    }

    public void sendCurrentLocation() {
//        PermissionDialogActivity.takePermission(PermissionDialogActivity.PermissionType.Location, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
        MyLocationProvider.LocationResult locationResult = new MyLocationProvider.LocationResult() {
            @Override
            public void gotLocation(Location location) {
                if (location == null) {
                    showToastMessage(getString(R.string.could_not_determine_current_location));
                } else {
                    LatLng myLoc = new LatLng(location.getLatitude(), location.getLongitude());
                    String locationMessage = Constants.LOCATION_PREFIX + myLoc.latitude + "," + myLoc.longitude + Constants.LS_SUFIX;
                    sendTextMessage(locationMessage);

                }
            }
        };
        MyLocationProvider myLocation = new MyLocationProvider();
        myLocation.getLocation(AppContext.getAccess().getContext(), locationResult);
//            }
//
//            @Override
//            public void onPermissionRejected() {
//
//            }
//        });
    }

    public void sendSticker(Sticker sticker) {
        String data = Constants.STICKER_PREFIX
                + Constants.WIDTH + sticker.width
                + Constants.SEPARATOR
                + Constants.HEIGHT + sticker.height
                + Constants.SEPARATOR
                + Constants.LINK + sticker.imageUrl
                + Constants.STICKER_SUFFIX;
        sendTextMessage(data);
    }

    public void sendGif(TenorGif tenorGif) {
        String data = Constants.GIF_PREFIX
                + Constants.WIDTH + tenorGif.width + Constants.SEPARATOR
                + Constants.HEIGHT + tenorGif.height + Constants.SEPARATOR
                + Constants.LINK + tenorGif.tinyGifUrl + Constants.GIF_SUFFIX;
        sendTextMessage(data);
    }

    public void sendTextSMS(String messageToSend) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) {
            intent.putExtra(SendingConstants.SMS_FROM_GROUP, true);
            //Target.group.allOtherMembersNumberButMe
            byte[] utf8Bytes = messageToSend.getBytes(StandardCharsets.UTF_8);
            int length = utf8Bytes.length;
            if (length <= 1000) {
                intent.putExtra(compose, messageToSend);
                if (!isGroupChat) {
                    String[] numbers;
                    numbers = new String[1];
                    numbers[0] = Target.target;
                    intent.putExtra("to1", numbers);
                } else {
//                        intent.putExtra("to1", Target.group.allOtherMembersNumberButMe);
                    intent.putExtra("groupid", Target.group.id);
                }
                QuickBroadCaster.broadcast(intent);
            } else {
                I.toast(getString(R.string.text_length_is_too_big));

            }
        } else {
            intent.putExtra(SendingConstants.SMS, true);
            byte[] utf8Bytes = messageToSend.getBytes(StandardCharsets.UTF_8);
            int length = utf8Bytes.length;
            if (length <= 1000) {
                intent.putExtra(compose, messageToSend);
                if (!isGroupChat) {
                    String[] numbers;
                    numbers = new String[1];
                    numbers[0] = Target.target;
                    intent.putExtra("to1", numbers);
                } else {
//                        intent.putExtra("to1", Target.group.allOtherMembersNumberButMe);
                    intent.putExtra("groupid", Target.group.id);
                }
                QuickBroadCaster.broadcast(intent);
            } else {
                I.toast(getString(R.string.text_length_is_too_big));

            }
        }
    }

    public void deleteForAll(Message message) {
        if (message.futureTime > 0) {
            sendDeleteFutureMessageSendingBroadcastToDialerService(message);
        } else {
            sendDeleteMessageSendingBroadcastToDialerService(message);
        }
    }

    private TaggedLogger messageQuoteLogger = new TaggedLogger("messageQuote");

    //    if (bag.isGoodBag()) {
//        String number = translateNumber(bag.getNumber());
//        int e2e = Util.e2e();
//        if (bag.gotE2EInBag()) {
//            e2e = bag.getE2e();
//        }
//        if (!number.equals(UserDataManager.getUserName())) {
//            sipProvider.messageQuote(number, bag.getMessageData(), false, e2e,
//                    new ByteArray(bag.getQuoteMessageData()), bag.getQuoteFromUser(), bag.getQcid(), "",bag.getBurnTimeInMillies());
//        } else {
//            I.toast(Supplier.getString(R.string.you_shall_not_be_able_send_message_to_yourself));
//        }
//    }
    private void sendQuoteMessageWithText(String textMessage, String quoteMessageCallId) {

        Executor.ex(() -> {
            Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
            MessageBag messageBag;
            com.revesoft.itelmobiledialer.appDatabase.entities.Message messageToQuote = MessageRepo.get().getMessagesByOcid(quoteMessageCallId);
            if (messageToQuote != null) {
                if (isGroupChat) {
                    messageBag = MessageBag.newBuilder()
                            .groupId(target)
                            .messageData(textMessage)
                            .e2e(isEncryptedChat ? 1 : 0)
                            .quoteMessageData(ChatUtil.getQuoteMessageData(messageToQuote))
                            .quoteFromUser(messageToQuote.number)
                            .qcid(messageToQuote.ocid)
                            .burnTimeInMillies(0)
                            .build();
                    intent.putExtra(BagName.Group.Quote, messageBag);
                } else {
                    messageBag = MessageBag.newBuilder()
                            .number(target)
                            .messageData(textMessage)
                            .e2e(isEncryptedChat ? 1 : 0)
                            .quoteMessageData(ChatUtil.getQuoteMessageData(messageToQuote))
                            .quoteFromUser(messageToQuote.number)
                            .qcid(messageToQuote.ocid)
                            .burnTimeInMillies(0)
                            .build();
                    intent.putExtra(BagName.SingleIM.Quote, messageBag);
                }
                QuickBroadCaster.broadcast(intent);
            } else {
                Gui.get().run(() -> I.toast(getString(R.string.somethingWentWrong)));
            }
            Gui.get().run(() -> ChatWindowEventHook.dispatchEvent(ChatWindowEvent.ExitQuoteMode));
        });

    }

    public void sendFutureTextSMS(String messageToSend, Date formattedDateTime, boolean shouldSendCurrentTimeStamp) {
        logger.log("sendFutureTextSMS");
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(SendingConstants.FUTURE_SMS, true);
        try {
            byte[] utf8Bytes = messageToSend.getBytes(StandardCharsets.UTF_8);
            int length = utf8Bytes.length;
            if (length <= 1000) {
                if (messageToSend.length() == 0) {
                    return;
                }
                intent.putExtra(compose, messageToSend);
                if (isGroupChat) {
                    intent.putExtra("to1", group.allOtherMembersNumberButMe);
                } else {
                    String[] numbers;
                    numbers = new String[1];
                    numbers[0] = target;
                    intent.putExtra("to1", numbers);
                }
                intent.putExtra("future_time_diff", formattedDateTime.getTime());
                if (isGroupChat) {
                    intent.putExtra("groupid", target);
                }
                logger.log("sendFutureTextSMS broadcasting");
                QuickBroadCaster.broadcast(intent);
            } else {
                I.toast(Supplier.getString(R.string.text_length_is_too_big));

            }
        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
        }

    }

    public void sendStaticSticker(String name) {
        String falseMessage = Constants.STATIC_STICKER_PREFIX + name + Constants.STATIC_STICKER_SUFFIX;
        sendTextMessage(falseMessage);
    }


    public void changeConfiguration(Configuration configuration) {
        this.currentConfiguration = configuration;
        this.target = configuration.target;
        this.isGroupChat = configuration.isGroupChat;
        this.isSMSChat = configuration.isSMSChat;
        this.isEncryptedChat = configuration.isEncryptedChat;
        messageSecurityMode = isEncryptedChat ? "1" : "0";
        if (isGroupChat) {
            group = new Group(configuration.group);
            groupType = group.groupType + "";
        }
    }

    public class Configuration {
        private String target = null;
        private boolean isGroupChat = false;
        private boolean isSMSChat = true;
        private boolean isEncryptedChat = false;
        com.revesoft.itelmobiledialer.appDatabase.entities.Group group;

        public Configuration target(String target) {
            this.target = target;
            return this;
        }


        public Configuration group(com.revesoft.itelmobiledialer.appDatabase.entities.Group group) {
            this.group = group;
            return this;
        }

        public Configuration isGroupChat(boolean groupChat) {
            this.isGroupChat = groupChat;
            return this;
        }

        public Configuration isSMSChat(boolean SMSChat) {
            this.isSMSChat = SMSChat;
            return this;
        }

        public Configuration isEncryptedChat(boolean isEncryptedChat) {
            this.isEncryptedChat = isEncryptedChat;
            return this;
        }

        public void configure() {
            Sender.getAccess().changeConfiguration(this);
        }

        public boolean getIsGroupChat() {
            return isGroupChat;
        }
    }

    public Configuration getConfiguration() {
        return new Configuration();
    }

    public Configuration getCurrentConfiguration() {
        return new Configuration();
    }

    public void sendTextMessage(String textMessage) {
        if (textMessage.length() > SendingConstants.MAX_IM_LENGTH) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        if (MessageQuoteInfo.isInQuoteMode) {
            sendQuoteMessageWithText(textMessage, MessageQuoteInfo.quoteMessageOriginatorCallId);
        } else {
            if (isGroupChat) {
                sendMessageSendingBroadcastToDialerService(BagName.Group.Message, textMessage);
            } else {
                sendMessageSendingBroadcastToDialerService(BagName.SingleIM.Message, textMessage);
            }
        }
    }

    public void sendConfideTextMessage(String textMessage) {
        if (textMessage.length() > SendingConstants.MAX_IM_LENGTH) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        if (MessageQuoteInfo.isInQuoteMode) {
            sendQuoteMessageWithText(textMessage, MessageQuoteInfo.quoteMessageOriginatorCallId);
        } else {
            if (isGroupChat) {
                sendConfideMessageSendingBroadcastToDialerService(SendingConstants.OUT_GOING_TEXT_GROUP, textMessage);
            } else {
                sendConfideMessageSendingBroadcastToDialerService(SendingConstants.OUT_GOING_TEXT_SINGLE, textMessage);
            }
        }
    }

    public void sendEditedTextMessage(String editedText, Message oldMessage) {
        if (editedText.length() > SendingConstants.MAX_IM_LENGTH) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        if (oldMessage.isConfide) {
            if (isGroupChat) {
                sendConfideEditedMessageSendingBroadcastToDialerService(SendingConstants.EDITED_TEXT_GROUP, editedText, oldMessage);
            } else {
                sendConfideEditedMessageSendingBroadcastToDialerService(SendingConstants.EDITED_TEXT_SINGLE, editedText, oldMessage);
            }
        } else {
            if (isGroupChat)
                sendEditedMessageSendingBroadcastToDialerService(SendingConstants.EDITED_TEXT_GROUP, editedText, oldMessage, true);
            else
                sendEditedMessageSendingBroadcastToDialerService(SendingConstants.EDITED_TEXT_SINGLE, editedText, oldMessage, false);

        }
    }

    public void sendEditedFutureTextMessage(String editedText, Date editedDate, Message oldMessage) {
        if (editedText.length() > SendingConstants.MAX_IM_LENGTH) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        if (editedText.length() > 0) {
            if (editedDate == null) {
                return;
            }
            if (editedDate.getTime() - System.currentTimeMillis() > 0) {
                Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
                if (isGroupChat) {
                    intent.putExtra(SendingConstants.FUTURE_EDITED_TEXT_GROUP,
                            new String[]{target, editedText, oldMessage.callerId,
                                    "" + editedDate.getTime(), "" + oldMessage.trueTimeStamp,
                                    oldMessage.editCount + 1 + "", messageSecurityMode});
                } else {
                    intent.putExtra(SendingConstants.FUTURE_EDITED_TEXT_SINGLE,
                            new String[]{target, editedText, oldMessage.callerId,
                                    "" + editedDate.getTime(), "" + oldMessage.trueTimeStamp,
                                    oldMessage.editCount + 1 + "", messageSecurityMode});
                }
                QuickBroadCaster.broadcast(intent);
            } else {
                I.toast((getString(R.string.future_error_message_time)));
            }

        } else {
            I.toast((getString(R.string.future_error_message_text)));
        }
    }

    private void sendMessageSendingBroadcastToDialerService(String type, String message) {
        MessageBag messageBag;
        if (isGroupChat) {
            messageBag = MessageBag.newBuilder().messageData(message).groupId(group.id).e2e(ChatProperties.isEncryptedChat ? 1 : 0).burnTimeInMillies(0).build();
        } else {
            messageBag = MessageBag.newBuilder().messageData(message).number(target).e2e(ChatProperties.isEncryptedChat ? 1 : 0).burnTimeInMillies(0).build();
        }
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, messageBag);
        QuickBroadCaster.broadcast(intent);
    }

    private void sendFutureMessageSendingBroadcastToDialerService(String type, String message, long futureMessageTime, boolean isSendingCurrentTimeStamp) {
        MessageBag messageBag;
        if (isGroupChat) {
            Log.i("FutureMsgTest","group id = "+group.id);
            messageBag = MessageBag.newBuilder()
                    .messageData(message)
                    .groupId(group.id)
                    .e2e(ChatProperties.isEncryptedChat ? 1 : 0)
                    .burnTimeInMillies(0)
                    .futureMessageTimeMillis(futureMessageTime)
                    .isSendingCurrentTimeStamp(isSendingCurrentTimeStamp)
                    .build();
        } else {
            messageBag = MessageBag.newBuilder()
                    .messageData(message)
                    .number(target)
                    .e2e(ChatProperties.isEncryptedChat ? 1 : 0)
                    .burnTimeInMillies(0)
                    .futureMessageTimeMillis(futureMessageTime)
                    .isSendingCurrentTimeStamp(isSendingCurrentTimeStamp)
                    .build();
        }
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, messageBag);
        QuickBroadCaster.broadcast(intent);
    }

    private void sendConfideMessageSendingBroadcastToDialerService(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, new String[]{target, message, groupType, messageSecurityMode, "isConfide"});
        QuickBroadCaster.broadcast(intent);
    }

    public void sendTypingMessageToDialer(String to, boolean isGroupChat, int e2e) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("typing", to);
        intent.putExtra("isGroup", isGroupChat);
        intent.putExtra("e2e", e2e);
        QuickBroadCaster.broadcast(intent);
    }


    private void sendQuoteMessageSendingBroadcastToDialerService(String type, String message, String quoteMessageCallId) {
        messageQuoteLogger.log("sendQuoteMessageSendingBroadcastToDialerService");
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, new String[]{target, message, messageSecurityMode, quoteMessageCallId});
        QuickBroadCaster.broadcast(intent);
    }

    private void sendEditedMessageSendingBroadcastToDialerService(String type, String message, Message oldMessage, boolean isGroup) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);


        MessageBag messageBag = MessageBag.newBuilder().messageData(message)
                .quoteMessageData(oldMessage.quoteData)
                .burnTimeInMillies(oldMessage.imBurnTime)
                .callId(oldMessage.callerId)
                .e2e(0)
                .editCount(oldMessage.editCount + 1)
                .filePath(oldMessage.filePathOriginal)
                .isGroup(isGroup)
                .number(target)
                .groupId(target)
                .qcid(oldMessage.qcid)
                .quoteFromUser(oldMessage.quoteFromUser)
                .timeStamp(System.currentTimeMillis())
                .build();


        intent.putExtra(type, messageBag);
        QuickBroadCaster.broadcast(intent);
    }

    private void sendConfideEditedMessageSendingBroadcastToDialerService(String type, String message, Message oldMessage) {

        Executor.ex(() -> {
            if (oldMessage.isConfide) {
                if (Smoker.isSmoking(oldMessage.callerId)) {
                    Gui.get().run(() -> I.toast(getString(R.string.cannotEditAlreadyDeletedMessage)));
                    return;
                } else {

                    Cursor cursor = MessageRepo.get().getMessageByCallerIdCursor(oldMessage.callerId);
                    if (cursor == null || cursor.getCount() == 0) {
                        Gui.get().run(() -> I.toast(getString(R.string.cannotEditAlreadyDeletedMessage)));
                        return;
                    }
                }
            }
            Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
            int newEditCount = oldMessage.editCount + 1;
            intent.putExtra(type, new String[]{target, message, oldMessage.callerId, "" + newEditCount, "" + oldMessage.trueTimeStamp, messageSecurityMode, "isConfide"});
            QuickBroadCaster.broadcast(intent);
        });

    }

    private void sendDeleteMessageSendingBroadcastToDialerService(Message message) {
        String type = isGroupChat ? SendingConstants.EDITED_TEXT_GROUP : SendingConstants.EDITED_TEXT_SINGLE;
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, new String[]{target, message.content, message.callerId, "-1", "" + message.trueTimeStamp, messageSecurityMode});
        QuickBroadCaster.broadcast(intent);
    }


    private void sendDeleteFutureMessageSendingBroadcastToDialerService(Message message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        String type = isGroupChat ? SendingConstants.EDITED_TEXT_GROUP : SendingConstants.EDITED_TEXT_SINGLE;
        intent.putExtra(type, new String[]{target, message.content, message.callerId,
                "-1", "" + message.trueTimeStamp,
                "-1", messageSecurityMode});
        QuickBroadCaster.broadcast(intent);
    }


    public void sendFutureTextMessage(String messageToSend, long futureMessageTimeStamp, boolean isSendingCurrentTimeStamp) {
        if (messageToSend.length() > SendingConstants.MAX_IM_LENGTH) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        if(!TextUtils.isEmpty(messageToSend))
        {
            if(isGroupChat)
            {
                sendFutureMessageSendingBroadcastToDialerService(BagName.Group.FutureMessage,messageToSend,futureMessageTimeStamp,isSendingCurrentTimeStamp);
            }
            else
            {
                sendFutureMessageSendingBroadcastToDialerService(BagName.SingleIM.FutureMessage,messageToSend,futureMessageTimeStamp,isSendingCurrentTimeStamp);
            }
        }

    }


    private static final int FILE_SIZE_THRESHOLD = 500 * 1024 * 1024;
    TaggedLogger fileDebugLogger = new TaggedLogger("fileDebugLogger");

    public void sendFile(String filePath) {
        fileDebugLogger.log("Sender sendFile =" + filePath);
        File file = new File(filePath);
        Log.e("HTTP", " file size: " + file.length());
        if (file.length() > FILE_SIZE_THRESHOLD) {
            I.toast(Supplier.getString(R.string.too_big_file));
        } else {
            Log.e(" normal group file path", " " + filePath);
            MessageEntry m = new MessageEntry();
            m.content = SEND_FILE_PREFIX_SENDER + filePath + SEND_FILE_SUFFIX_SENDER;
            m.number = target;
            m.time = System.currentTimeMillis() + UserDataManager.getTimeAdjustment();
            m.type = MessageEntry.MessageType.SEND;
            m.status = MessageEntry.MessageStatus.READ;
            m.delivery_status = MessageEntry.DeliveryStatus.NO_REPLY;
            m.callerId = System.currentTimeMillis() + m.number + Util.random();
            m.groupId = isGroupChat ? target : "";
            m.ocid = m.callerId;
            m.isEncrypted = isEncryptedChat ? 1 : 0;
            m.filePath = filePath;
            m.burnTimerMillis = Burner.getBurner(ChatProperties.getChatWindowContext()).isBurnerSet(target) ?
                    Burner.getBurner(ChatProperties.getChatWindowContext()).getBurnTimeInMillies(target) : -1;
            PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);


            Executor.ex(() -> {
                if (MessageQuoteInfo.isInQuoteMode) {
                    Cursor cursor = MessageRepo.get().getMessagesByOCID(MessageQuoteInfo.quoteMessageOriginatorCallId);
                    if (cursor != null && cursor.moveToFirst()) {
                        Message message = new Message(cursor);
                        m.quoteData = message.content;
                        m.quoteFromUser = message.sender;
                        m.quoteMessageFilePath = message.filePathLocal;
                        m.qcid = MessageQuoteInfo.quoteMessageOriginatorCallId;
                    }


                    sendIntentMessageFileUploadToDialer(filePath, m.callerId);
                    MessageRepo.get().createMessageLog(m);

                } else {
                    sendIntentMessageFileUploadToDialer(filePath, m.callerId);
                    MessageRepo.get().createMessageLog(m);
                }
            });


        }

        ChatWindowEventHook.dispatchEvent(ChatWindowEvent.ExitQuoteMode);
    }

    private boolean unsetBurn() {
        if (Burner.getBurner(ChatProperties.getChatWindowContext()).isBurnerSet(target)) {
            Burner.getBurner(ChatProperties.getChatWindowContext()).unsetBurner(target);
        }
        return false;
    }

    public void sendFile(String filePath, String caption) {
        Log.e("sending normal file ", "with caption");
        if (TextUtils.isEmpty(caption)) {
            sendFile(filePath);
            return;
        }
        File file = new File(filePath);
        Log.e("HTTP", " file size: " + file.length());
        if (file.length() > FILE_SIZE_THRESHOLD) {
            I.toast(Supplier.getString(R.string.too_big_file));
        } else {
            Log.e(" normal group file path", " " + filePath);
            MessageEntry m = new MessageEntry();
            m.content = SEND_FILE_PREFIX_SENDER + filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + caption + SEND_FILE_SUFFIX_SENDER;
            //m.content = SEND_FILE_PREFIX + filePath + SEND_FILE_SUFFIX;

            m.number = target;
            m.time = System.currentTimeMillis();
            m.type = MessageEntry.MessageType.SEND;
            m.status = MessageEntry.MessageStatus.READ;
            m.delivery_status = MessageEntry.DeliveryStatus.PENDING;
            m.filePath = filePath;
            m.callerId = System.currentTimeMillis() + UserDataManager.getUserName();
            m.groupId = isGroupChat ? target : "";
            m.isEncrypted = isEncryptedChat ? 1 : 0;
            m.burnTimeInsec = PreferenceDataManager.quickGet(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);
            PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);

            Executor.ex(() -> {
                if (MessageQuoteInfo.isInQuoteMode) {
                    m.qcid = MessageQuoteInfo.quoteMessageOriginatorCallId;
                    Cursor cursor = MessageRepo.get().getMessagesByOCID(MessageQuoteInfo.quoteMessageOriginatorCallId);
                    if (cursor != null && cursor.moveToFirst()) {
                        m.quoteData = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_MESSAGE_CONTENT));
                        m.quoteFromUser = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NUMBER));
                        m.quoteMessageFilePath = cursor.getString(cursor.getColumnIndex("file_path"));
                    }
                    sendIntentMessageFileUploadToDialer(filePath, caption, m.callerId);
                    MessageRepo.get().createMessageLog(m);
                } else {
                    sendIntentMessageFileUploadToDialer(filePath, caption, m.callerId);
                    MessageRepo.get().createMessageLog(m);
                }
            });

        }
        ChatWindowEventHook.dispatchEvent(ChatWindowEvent.ExitQuoteMode);
    }

    public void sendIntentMessageFileDownloadRetryToDialer(Message message) {
        logger.log(message.toString());
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) {
            intent.putExtra("filedownloadretry", new String[]{"", target, message.content, message.content, message.callerId});
        } else {
            intent.putExtra("filedownloadretry", new String[]{target, "", message.content, message.content, message.callerId});
        }
        LocalBroadcastManager.getInstance(AppContext.getAccess().getContext()).sendBroadcast(intent);
    }


    public void sendConfideFile(String filePath, String caption) {
        /*if (TextUtils.isEmpty(caption)) {
            sendFile(filePath);
            return;
        }*/
        File file = new File(filePath);
        Log.e("HTTP", " file size: " + file.length());
        if (file.length() > Constants.FILE_SIZE_THRESHOLD) {
            I.toast(Supplier.getString(R.string.too_big_file));
        } else {
            Log.e(" normal group file path", " " + filePath);
            MessageEntry m = new MessageEntry();
            m.content = SEND_FILE_PREFIX_SENDER + filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + caption + SEND_FILE_SUFFIX_SENDER;
            if (TextUtils.isEmpty(caption)) {
                //m.content = SEND_FILE_PREFIX_SENDER + filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + "\u0020" + SEND_FILE_SUFFIX_SENDER;
                caption = "\u0020";
            }
            m.content = SEND_FILE_PREFIX_SENDER + filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + caption + SEND_FILE_SUFFIX_SENDER;
            //m.content = SEND_FILE_PREFIX + filePath + SEND_FILE_SUFFIX;
            m.filePath = filePath;
            m.number = target;
            m.time = System.currentTimeMillis() + UserDataManager.getTimeAdjustment();
            m.type = MessageEntry.MessageType.SEND;
            m.status = MessageEntry.MessageStatus.READ;
            m.delivery_status = MessageEntry.DeliveryStatus.PENDING;
            m.callerId = System.currentTimeMillis() + UserDataManager.getUserName();
            m.groupId = target;
            m.isEncrypted = isEncryptedChat ? 1 : 0;
            m.burnTimeInsec = PreferenceDataManager.quickGet(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);
            m.isConfide = true;
            PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);

            sendConfideIntentMessageFileUploadToDialer(filePath, caption, m.callerId);
            Executor.ex(() -> MessageRepo.get().createMessageLog(m));
        }
    }

    private void sendConfideIntentMessageFileUploadToDialer(String filePath, String caption, String callerId) {
        Log.d("Abhi", "File Transfer" + "sendIntentMessageFileUploadToDialer");
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) { //this block won't work for Confide
            intent.putExtra(Constants.COMMAND_FILE_UPLOARD, new String[]{"", target,
                    filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + caption,
                    callerId, messageSecurityMode + "", "isCaptionConfide"});
        } else {
            intent.putExtra(Constants.COMMAND_FILE_UPLOARD, new String[]{target, "",
                    filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + caption,
                    callerId, messageSecurityMode + "", "isCaptionConfide"});
        }
        QuickBroadCaster.broadcast(intent);
    }

    public void sendFutureFile(final String filePath, long time, boolean shouldSendCurrentTimeStamp) { //modified, new parameter isTimeStamp passed
        File file = new File(filePath);
        Log.e("HTTP", " file size: " + file.length());
        if (file.length() > FILE_SIZE_THRESHOLD) {
            I.toast(Supplier.getString(R.string.too_big_file));
        } else {
            Log.e(" normal group file path", " " + filePath);
            MessageEntry m = new MessageEntry();
            m.content = SEND_FILE_PREFIX_SENDER + filePath + SEND_FILE_SUFFIX_SENDER;
            m.number = target;
            m.time = System.currentTimeMillis() + UserDataManager.getTimeAdjustment();
            m.type = MessageEntry.MessageType.SEND;
            m.status = MessageEntry.MessageStatus.READ;
            m.delivery_status = MessageEntry.DeliveryStatus.NO_REPLY;
            m.callerId = System.currentTimeMillis() + m.number + Util.random();
            m.groupId = isGroupChat ? target : "";
            m.ocid = m.callerId;
            m.isEncrypted = isEncryptedChat ? 1 : 0;
            m.filePath = filePath;
            m.futureSendTime = time;
            m.sendOriginalTimestampFlag = shouldSendCurrentTimeStamp ?(short)1 :0;
            m.burnTimerMillis = Burner.getBurner(ChatProperties.getChatWindowContext()).isBurnerSet(target) ?
                    Burner.getBurner(ChatProperties.getChatWindowContext()).getBurnTimeInMillies(target) : -1;
            PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);


            Executor.ex(() -> {
                if (MessageQuoteInfo.isInQuoteMode) {
                    Cursor cursor = MessageRepo.get().getMessagesByOCID(MessageQuoteInfo.quoteMessageOriginatorCallId);
                    if (cursor != null && cursor.moveToFirst()) {
                        Message message = new Message(cursor);
                        m.quoteData = message.content;
                        m.quoteFromUser = message.sender;
                        m.quoteMessageFilePath = message.filePathLocal;
                        m.qcid = MessageQuoteInfo.quoteMessageOriginatorCallId;
                    }


                    sendIntentMessageFileUploadToDialer(filePath, m.callerId);
                    MessageRepo.get().createMessageLog(m);

                } else {
                    sendIntentMessageFileUploadToDialer(filePath, m.callerId);
                    MessageRepo.get().createMessageLog(m);
                }
            });


        }

        ChatWindowEventHook.dispatchEvent(ChatWindowEvent.ExitQuoteMode);
    }

    public void sendFutureFile(final String filePath, String caption, long time, boolean shouldSendCurrentTimeStamp) {

        if (TextUtils.isEmpty(caption)) {
            sendFutureFile(filePath,time,shouldSendCurrentTimeStamp);
            return;
        }
        File file = new File(filePath);
        Log.e("HTTP", " file size: " + file.length());
        if (file.length() > FILE_SIZE_THRESHOLD) {
            I.toast(Supplier.getString(R.string.too_big_file));
        } else {
            MessageEntry m = new MessageEntry();
            m.content = SEND_FILE_PREFIX_SENDER + filePath + Constants.SEND_FILE_URI_CAPTION_SEPARATOR + caption + SEND_FILE_SUFFIX_SENDER;
            m.number = target;
            m.time = System.currentTimeMillis();
            m.type = MessageEntry.MessageType.SEND;
            m.status = MessageEntry.MessageStatus.READ;
            m.delivery_status = MessageEntry.DeliveryStatus.PENDING;
            m.filePath = filePath;
            m.callerId = System.currentTimeMillis() + UserDataManager.getUserName();
            m.groupId = isGroupChat ? target : "";
            m.isEncrypted = isEncryptedChat ? 1 : 0;
            m.futureSendTime = time;
            m.sendOriginalTimestampFlag = shouldSendCurrentTimeStamp? (short) 1 :0;
            m.burnTimeInsec = PreferenceDataManager.quickGet(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);
            PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, Constants.BURN_TIME_DEFAULT);

            Executor.ex(() -> {
                if (MessageQuoteInfo.isInQuoteMode) {
                    m.qcid = MessageQuoteInfo.quoteMessageOriginatorCallId;
                    Cursor cursor = MessageRepo.get().getMessagesByOCID(MessageQuoteInfo.quoteMessageOriginatorCallId);
                    if (cursor != null && cursor.moveToFirst()) {
                        m.quoteData = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_MESSAGE_CONTENT));
                        m.quoteFromUser = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NUMBER));
                        m.quoteMessageFilePath = cursor.getString(cursor.getColumnIndex("file_path"));
                    }
                    sendIntentMessageFutureFileUploadToDialer(filePath, caption, m.callerId,shouldSendCurrentTimeStamp);
                    MessageRepo.get().createMessageLog(m);
                } else {
                    sendIntentMessageFutureFileUploadToDialer(filePath, caption, m.callerId,shouldSendCurrentTimeStamp);
                    MessageRepo.get().createMessageLog(m);
                }
            });

        }
        ChatWindowEventHook.dispatchEvent(ChatWindowEvent.ExitQuoteMode);
    }

    private void sendIntentMessageFileUploadToDialer(String filePath, String callerId) {
        fileDebugLogger.log("Sender sendIntentMessageFileUploadToDialer =" + filePath);
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .groupId(target)
                    .isGroup(true)
                    .filePath(filePath)
                    .callId(callerId)
                    .e2e(isEncryptedChat ? 1 : 0).build());
        } else {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .number(target)
                    .e2e(isEncryptedChat ? 1 : 0)
                    .callId(callerId)
                    .filePath(filePath)
                    .build());
        }
        QuickBroadCaster.broadcast(intent);
    }

    private void sendIntentMessageFutureFileUploadToDialer(String filePath, String callerId,boolean isSendingCurrentTimeStamp) {
        fileDebugLogger.log("Sender sendIntentMessageFileUploadToDialer =" + filePath);
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .groupId(target)
                    .isGroup(true)
                    .filePath(filePath)
                    .callId(callerId)
                    .isSendingCurrentTimeStamp(isSendingCurrentTimeStamp)
                    .e2e(isEncryptedChat ? 1 : 0).build());
        } else {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .number(target)
                    .e2e(isEncryptedChat ? 1 : 0)
                    .callId(callerId)
                    .filePath(filePath)
                    .isSendingCurrentTimeStamp(isSendingCurrentTimeStamp)
                    .build());
        }
        QuickBroadCaster.broadcast(intent);
    }


    private void sendIntentMessageFileUploadToDialer(String filePath, String caption, String callerId) {
        fileDebugLogger.log("Sender sendIntentMessageFileUploadToDialer =" + filePath);
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .groupId(target)
                    .isGroup(true)
                    .filePath(filePath)
                    .callId(callerId)
                    .caption(caption)
                    .e2e(isEncryptedChat ? 1 : 0).build());
        } else {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .number(target)
                    .e2e(isEncryptedChat ? 1 : 0)
                    .callId(callerId)
                    .caption(caption)
                    .filePath(filePath)
                    .build());
        }
        QuickBroadCaster.broadcast(intent);
    }

    private void sendIntentMessageFutureFileUploadToDialer(String filePath, String caption, String callerId, boolean isSendingCurrentTimeStamp) {
        fileDebugLogger.log("Sender sendIntentMessageFileUploadToDialer =" + filePath);
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .groupId(target)
                    .isGroup(true)
                    .filePath(filePath)
                    .callId(callerId)
                    .isSendingCurrentTimeStamp(isSendingCurrentTimeStamp)
                    .caption(caption)
                    .e2e(isEncryptedChat ? 1 : 0).build());
        } else {
            intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                    .number(target)
                    .e2e(isEncryptedChat ? 1 : 0)
                    .callId(callerId)
                    .caption(caption)
                    .isSendingCurrentTimeStamp(isSendingCurrentTimeStamp)
                    .filePath(filePath)
                    .build());
        }
        QuickBroadCaster.broadcast(intent);
    }


    private void showToastMessage(String message) {
        final String showTextMsg = message;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                I.toast(showTextMsg);
            }
        });
    }

    public void sendTypingMessageToDialer() {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("typing", target);
        intent.putExtra("isGroup", isGroupChat);
        intent.putExtra("e2e", isEncryptedChat ? 1 : 0);
        QuickBroadCaster.broadcast(intent);
    }
}
