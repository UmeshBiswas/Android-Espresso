package com.revesoft.itelmobiledialer.chat.chatWindow.memory;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.JetPackChatAdapter;

import java.util.Timer;
import java.util.TimerTask;

/**
 * @author Ifta on 3/4/2018.
 */

public class MessageHighlighter {
    private static String OCIIdToHighlight;
    private static Timer timer;

    public static void highLight(String ocid) {
        Executor.ex(() -> {
            if (ocid == null) return;
            MessageHighlighter.OCIIdToHighlight = ocid;
            if (timer == null) {
                final int positionToHighlight = getPositionFor(ocid);

                if (positionToHighlight != -1) {
                    ChatWindowEventHook.dispatchEvent(ChatWindowEvent.Highlight, positionToHighlight);
                    timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            OCIIdToHighlight = null;
                            ChatWindowEventHook.dispatchEvent(ChatWindowEvent.UnHighlight, positionToHighlight);
                            timer.cancel();
                            timer = null;
                        }
                    }, 1000);
                }

            } else {
                timer.cancel();
                timer = null;
                final int positionToHighlight = getPositionFor(ocid);

                if (positionToHighlight != -1) {
                    ChatWindowEventHook.dispatchEvent(ChatWindowEvent.Highlight, positionToHighlight);
                    timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            OCIIdToHighlight = null;
                            ChatWindowEventHook.dispatchEvent(ChatWindowEvent.Highlight, positionToHighlight);
                            timer.cancel();
                            timer = null;
                        }
                    }, 1000);
                }

            }
        });

    }

    public static boolean isHighlighted(String ocid) {
        return OCIIdToHighlight != null && OCIIdToHighlight.equals(ocid);
    }

    public static void invalidateHighLighterInfo() {
        MessageHighlighter.chatAdapter = null;
    }

    public static int getPositionFor(String ocid) {
        if (chatAdapter != null && chatAdapter.getCurrentList() != null) {
            int position = 0;
            for (Message messages : chatAdapter.getCurrentList().snapshot()) {
                if (messages!=null && messages.ocid != null && messages.ocid.equals(ocid)) {
                    return position;
                }
                position++;
            }
        }
        return -1;
    }

    private static JetPackChatAdapter chatAdapter;

    public static void createHighLighterInfo(JetPackChatAdapter chatAdapter) {
        MessageHighlighter.chatAdapter = chatAdapter;
    }
}
