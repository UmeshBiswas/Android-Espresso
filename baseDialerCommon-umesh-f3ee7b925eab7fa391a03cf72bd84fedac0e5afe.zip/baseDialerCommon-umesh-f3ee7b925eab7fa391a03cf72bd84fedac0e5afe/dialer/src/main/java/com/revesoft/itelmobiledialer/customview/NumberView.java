package com.revesoft.itelmobiledialer.customview;

import android.content.Context;
import android.os.Handler;
import androidx.appcompat.widget.AppCompatEditText;
import android.text.Layout;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;

public class NumberView extends AppCompatEditText implements OnTouchListener {
	private Context c;
	private static final int NUMBER_FIELD_LIMIT = 22;
	InputMethodManager imm;
	Handler handler;

	public NumberView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		setListeners();
		c = context;
		imm = (InputMethodManager) c.getSystemService(Context.INPUT_METHOD_SERVICE);
		handler = new Handler();
	}

	public NumberView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setListeners();
		c = context;
		imm = (InputMethodManager) c.getSystemService(Context.INPUT_METHOD_SERVICE);
		handler = new Handler();
	}

	public NumberView(Context context) {
		super(context);
		setListeners();
		imm = (InputMethodManager) c.getSystemService(Context.INPUT_METHOD_SERVICE);
		handler = new Handler();
	}

	private void setListeners() {
		setOnTouchListener(this);
	}

	@Override
	public boolean onCheckIsTextEditor() {
		return true;
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		if(event.getAction() == MotionEvent.ACTION_DOWN) {
			Layout layout = getLayout();
			float x = event.getX() + getScrollX();
			float y = event.getY() + getScrollY();
			int line = layout.getLineForVertical((int) y);
			int offset = layout.getOffsetForHorizontal(line, x);
			setSelection(offset);
		}
		hideSoftKey();
		return false;
	}

	private void hideSoftKey() {
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				imm.hideSoftInputFromWindow(getWindowToken(), 0);
			}
		}, 50);
	}

	public void insertDigit(String digit) {
		String currentNumberFieldValue = this.getText().toString();
		int currentNumberFieldValueSize = currentNumberFieldValue.length();
		int selectionPosition = this.getSelectionStart();
		if (NUMBER_FIELD_LIMIT > currentNumberFieldValueSize) {
			if (selectionPosition < currentNumberFieldValueSize) {
				StringBuffer buffer = new StringBuffer(currentNumberFieldValue);
				buffer.insert(selectionPosition, digit);
				this.setText(buffer);
				setSelection(selectionPosition + 1);
			} else if (selectionPosition == currentNumberFieldValueSize) {
				this.append(digit);
			}
		}
	}

	public void deleteSelectedPart(){
		int start = this.getSelectionStart();
		int end = this.getSelectionEnd();
		String firstPart = this.getText().toString().substring(0,end).substring(0,start);
		String lastPart = this.getText().toString().substring(end);
		this.setText(firstPart);
		this.append(lastPart);
		this.setSelection(start);
	}
	public void deleteDigit() {
		if (numberLocked) {
			deleteAllDigit();
			return;
		}
		String currentNumberFieldValue = this.getText().toString();
		int currentNumberFieldValueSize = currentNumberFieldValue.length();
		int selectionPosition = this.getSelectionStart();

		if (selectionPosition > 0) {

			if (selectionPosition < currentNumberFieldValueSize) {
				String firstPart = currentNumberFieldValue.substring(0,
						selectionPosition - 1);

				String secondPart = currentNumberFieldValue.substring(
						selectionPosition, currentNumberFieldValueSize);

				String newNumberFieldValue = firstPart.concat(secondPart);

				this.setText(newNumberFieldValue);
				this.setSelection(selectionPosition - 1);

			} else {
				this.setText(currentNumberFieldValue.substring(0,
						currentNumberFieldValueSize - 1));
				this.setSelection(this.length());

			}
		}

	}

	public void rapidDeleteDigit() {
		if (numberLocked) {
			deleteAllDigit();
			return;
		}
		String currentNumberFieldValue = this.getText().toString();
		int currentNumberFieldValueSize = currentNumberFieldValue.length();
		int selectionPosition = this.getSelectionStart();

		if (selectionPosition > 0) {

			if (selectionPosition < currentNumberFieldValueSize) {
				String firstPart = "";

				String secondPart = currentNumberFieldValue.substring(
						selectionPosition, currentNumberFieldValueSize);

				String newNumberFieldValue = firstPart.concat(secondPart);

				this.setText(newNumberFieldValue);
				this.setSelection(0);

			} else {
				deleteAllDigit();
			}
		}

	}

	public void deleteAllDigit() {
		this.setText("");
	}

	private boolean numberLocked = false;

	public void setNumberLocked() {
		numberLocked = true;
	}

	public synchronized String getNumber() {
		return getText().toString();
	}
}
