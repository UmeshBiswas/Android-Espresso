package com.revesoft.itelmobiledialer.arch;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

/**
 * @author Ifta on 4/24/2018
 *
 * When to use:
 * -you want to load the data in fragment on it is visible first time. then your fragment should exdent this LazyFragment
 *
 * How to use:
 * -Extend LazyFragment to your fragment and over ride the loadData() method;
 * -onCreateView() of yourfragment, call super.onCreateView() on the first line
 * -If you override setUserVisibleHint() must ensure of calling super.setUserVisibleHint() on first line
 * -load your data in loadData() function
 */

public abstract class LazyFragment extends Fragment {
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		if(getUserVisibleHint()){ // fragment is visible
			loadData();
		}
		return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser && isResumed()) { // fragment is visible and have created
			loadData();
		}
	}

	public abstract void loadData();
}
