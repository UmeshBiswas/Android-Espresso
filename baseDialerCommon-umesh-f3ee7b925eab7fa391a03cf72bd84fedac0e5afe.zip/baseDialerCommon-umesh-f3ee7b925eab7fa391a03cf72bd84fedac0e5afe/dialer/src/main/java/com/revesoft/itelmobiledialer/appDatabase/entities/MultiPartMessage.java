package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "multipartmessages")
public class MultiPartMessage {
    public int _id;
    @PrimaryKey(autoGenerate = false)
    @NonNull
    @ColumnInfo(name = "callerid")
    public String callerId = AppDatabaseDefault.callerId;
    @ColumnInfo(name = "calleridlocal")
    public String callerIdLocal = AppDatabaseDefault.callerId;
    @NonNull
    public String number = AppDatabaseDefault.number;
    @NonNull
    @ColumnInfo(name = "groupid")
    public String groupId;
    @NonNull
    public Date date  = AppDatabaseDefault.date;
    @ColumnInfo(name = "multipart_number")
    public int multipartNumber = 1;
    @ColumnInfo(name = "is_decrypted")
    public boolean isDecrypted = false;
    @ColumnInfo(name = "total_parts")
    public int totalParts = 1;
    @ColumnInfo(name = "is_outgoing")
    public boolean isOutgoing = false;
    @NonNull
    @ColumnInfo(name = "messagecontent")
    public String messageContent = AppDatabaseDefault.messageContent;

    public MultiPartMessage() {
    }

    private MultiPartMessage(Builder builder) {
        _id = builder._id;
        callerId = builder.callerId;
        callerIdLocal = builder.callerIdLocal;
        number = builder.number;
        groupId = builder.groupId;
        date = builder.date;
        multipartNumber = builder.multipartNumber;
        isDecrypted = builder.isDecrypted;
        totalParts = builder.totalParts;
        isOutgoing = builder.isOutgoing;
        messageContent = builder.messageContent;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private int _id = Util.random();
        private String callerId = AppDatabaseDefault.callerId;
        private String callerIdLocal = AppDatabaseDefault.callerId;
        private String number = AppDatabaseDefault.number;
        private String groupId = null;
        private Date date = AppDatabaseDefault.date;
        private int multipartNumber = 1;
        private boolean isDecrypted = false;
        private int totalParts = 1;
        private boolean isOutgoing = false;
        private String messageContent = AppDatabaseDefault.messageContent;

        private Builder() {
        }

        public Builder _id(int _id) {
            this._id = _id;
            return this;
        }

        public Builder callerId(String callerId) {
            this.callerId = callerId;
            return this;
        }

        public Builder callerIdLocal(String callerIdLocal) {
            this.callerIdLocal = callerIdLocal;
            return this;
        }

        public Builder number(String number) {
            this.number = number;
            return this;
        }

        public Builder groupId(String groupId) {
            this.groupId = groupId;
            return this;
        }

        public Builder date(Date date) {
            this.date = date;
            return this;
        }

        public Builder multipartNumber(int multipartNumber) {
            this.multipartNumber = multipartNumber;
            return this;
        }

        public Builder isDecrypted(boolean isDecrypted) {
            this.isDecrypted = isDecrypted;
            return this;
        }

        public Builder totalParts(int totalParts) {
            this.totalParts = totalParts;
            return this;
        }

        public Builder isOutgoing(boolean isOutgoing) {
            this.isOutgoing = isOutgoing;
            return this;
        }

        public Builder messageContent(String messageContent) {
            this.messageContent = messageContent;
            return this;
        }

        public MultiPartMessage build() {
            return new MultiPartMessage(this);
        }
    }
}
