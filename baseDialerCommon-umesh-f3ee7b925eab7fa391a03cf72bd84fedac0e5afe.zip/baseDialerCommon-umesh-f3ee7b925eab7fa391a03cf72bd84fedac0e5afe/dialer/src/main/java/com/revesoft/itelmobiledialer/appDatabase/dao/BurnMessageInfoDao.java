package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.BurnMessageInfo;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface BurnMessageInfoDao extends BaseDao<BurnMessageInfo> {

    @Query("SELECT * FROM BURN_MESSAGE_INFO")
    Cursor getAllBurnMessageInfoCursor();

    @Query("DELETE FROM BURN_MESSAGE_INFO WHERE callerid=:callerId")
    void deleteBurnMessageEntryByCallerId(String callerId);

    @Query("DELETE FROM BURN_MESSAGE_INFO WHERE number=:number")
    void deleteBurnMessageEntryByNumber(String number);


    @Query("SELECT burn_timer_index FROM BURN_MESSAGE_INFO WHERE number=:number")
    int getBurnTimerIndex(String number);

    @Query("SELECT COUNT(*) FROM BURN_MESSAGE_INFO WHERE number=:number")
    boolean isBurnTimeEntryAvailable(String number);


    @Query("SELECT * FROM BURN_MESSAGE_INFO")
    List<BurnMessageInfo> getAll();
}
