package com.revesoft.itelmobiledialer.contact.picker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ContactPickerListSingleItemBinding;

import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

class ContactPickerListAdapter extends PagedListAdapter<ContactListItem, ContactPickerListAdapter.ViewHolder> {
    private HashMap<ContactListItem, ViewHolder> contactListItemViewHolderHashMap = new HashMap<>();
    private Context fragmentActivityContext;
    private ContactSelectiontype contactSelectiontype;

    ContactPickerListAdapter(Context fragmentActivityContext, ContactSelectiontype contactSelectiontype) {
        super(DIFF_CALLBACK);
        this.fragmentActivityContext = fragmentActivityContext;
        this.contactSelectiontype = contactSelectiontype;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ContactPickerListSingleItemBinding binding =
                DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                        R.layout.contact_picker_list_single_item,
                        parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ContactListItem item = getItem(position);
        if (item != null) {
            contactListItemViewHolderHashMap.put(item, holder);
            holder.binding.setItem(item);
            holder.binding.content.setOnClickListener(v -> {
                if (fragmentActivityContext instanceof ContactPickerActivity) {
                    ContactPickerActivity contactPickerActivity = (ContactPickerActivity) fragmentActivityContext;
                    if (contactSelectiontype == ContactSelectiontype.SINGLE_SELECT) {
                        PickedContacts.add(item);
                        contactPickerActivity.done(v);
                    } else {
                        if (!PickedContacts.add(item)) {
                            PickedContacts.remove(item);
                        }
                        bindImage(holder, item);
                    }
                }

            });
            bindImage(holder, item);
        } else {
            holder.binding.invalidateAll();
        }
    }

    private void bindImage(ViewHolder holder, ContactListItem item) {
        if (PickedContacts.contains(item)) {
            holder.binding.ivProfileImage.setImageResource(R.drawable.ic_checked);
        } else {
            ImageUtil.setImage(holder.binding.ivProfileImage, item.getImagePath(), item.getName());
        }
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        private ContactPickerListSingleItemBinding binding;

        private ViewHolder(ContactPickerListSingleItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

    }

    private static DiffUtil.ItemCallback<ContactListItem> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<ContactListItem>() {
                @Override
                public boolean areItemsTheSame(ContactListItem oldItem, ContactListItem newItem) {
                    return oldItem.getProcessedNumber().equals(newItem.getProcessedNumber());
                }

                @Override
                public boolean areContentsTheSame(@NonNull ContactListItem oldItem, @NonNull ContactListItem newItem) {
                    return areItemsTheSame(oldItem, newItem);
                }
            };

    void changeSelection(ContactListItem item) {
        if (contactSelectiontype == ContactSelectiontype.MULTIPLE_SELECT) {
            if (contactListItemViewHolderHashMap.containsKey(item)) {
                ViewHolder viewHolder = contactListItemViewHolderHashMap.get(item);
                if (viewHolder != null) {
                    bindImage(viewHolder, item);
                }
            }
        }
    }
}
