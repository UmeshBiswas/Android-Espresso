package com.revesoft.itelmobiledialer.chat.chatWindow.helper;

import android.graphics.Color;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.widget.EditText;

import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.util.Log;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.lang.ref.WeakReference;

/**
 * @author Ifta on 1/14/2018.
 */

public class DraftManager {
    private static final String KEY_PREFIX_DRAFT_MESSAGE = "DRAFT";
    private static WeakReference<EditText> et;
    private static String messageSecurityMode;

    public static void prepare(EditText editText, boolean isEncrypted) {
        DraftManager.et = new WeakReference<>(editText);
        messageSecurityMode = isEncrypted ? "1" : "0";
    }

    private static boolean isDraftClearingNeeded = false;

    public static void saveDraft() {

        try {
            String currentMessage = et.get().getText().toString().trim();
            if (!TextUtils.isEmpty(currentMessage)) {
                PreferenceDataManager.quickPut(KEY_PREFIX_DRAFT_MESSAGE + messageSecurityMode + Target.target, currentMessage);
            } else {
                clearDraft();
            }
        } catch (Exception e) {
            Log.d("Chat Window", "DraftManager Error", e);
        }

    }

    public static void restoreDraft() {

        String draftMessage = PreferenceDataManager.quickGet(KEY_PREFIX_DRAFT_MESSAGE + messageSecurityMode + Target.target, "");
        if (!TextUtils.isEmpty(draftMessage)) {
            et.get().setText(draftMessage);
            et.get().setSelection(draftMessage.length());
            isDraftClearingNeeded = true;
        }
    }

    public static void clearDraft() {
        if (isDraftClearingNeeded) {
            PreferenceDataManager.quickPut(KEY_PREFIX_DRAFT_MESSAGE + messageSecurityMode + Target.target, "");
            isDraftClearingNeeded = false;
        }
    }

    public static SpannableStringBuilder getDraftMessageFor(String target, boolean isEncrypted) {
        String messageSecurity = isEncrypted ? "1" : "0";
        String message = PreferenceDataManager.quickGet(KEY_PREFIX_DRAFT_MESSAGE + messageSecurity + target, "");
        if (TextUtils.isEmpty(message)) {
            return null;
        }
        SpannableStringBuilder builder = new SpannableStringBuilder();
        SpannableString draftIndicationWord = new SpannableString(Supplier.getString(R.string.draft));
        draftIndicationWord.setSpan(new ForegroundColorSpan(Color.RED), 0, draftIndicationWord.length(), 0);
        builder.append(draftIndicationWord);
        builder.append(" ");
        SpannableString messageSpan = new SpannableString(message);
        messageSpan.setSpan(new ForegroundColorSpan(Color.BLACK), 0, messageSpan.length(), 0);
        builder.append(messageSpan);
        return builder;
    }

}
