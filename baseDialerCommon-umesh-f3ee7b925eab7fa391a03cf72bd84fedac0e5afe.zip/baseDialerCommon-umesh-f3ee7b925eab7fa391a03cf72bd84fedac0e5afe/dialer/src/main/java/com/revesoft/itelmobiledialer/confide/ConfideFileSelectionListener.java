package com.revesoft.itelmobiledialer.confide;

/**
 * @author Ifta on 1/31/2018.
 */

public interface ConfideFileSelectionListener {
    void onFileSelect(String filePath);
}
