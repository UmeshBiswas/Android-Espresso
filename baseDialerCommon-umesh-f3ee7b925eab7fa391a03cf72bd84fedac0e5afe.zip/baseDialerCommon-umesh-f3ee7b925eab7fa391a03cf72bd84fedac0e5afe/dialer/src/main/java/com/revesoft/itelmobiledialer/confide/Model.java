package com.revesoft.itelmobiledialer.confide;

import java.util.ArrayList;

/**
 * Created by Ashrafi on 12/31/2017.
 */

public class Model {
    ArrayList<String> strings;

    boolean image = false;
    boolean video = false;
    boolean audio = false;
    boolean reply = false;
    String filepath = "";
    /*public Model(ArrayList<String> strings){
        this.strings = strings;
    }*/

    public Model(){
        strings = new ArrayList<String>(); //memory allocated
    }

}