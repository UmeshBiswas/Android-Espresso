package com.revesoft.itelmobiledialer.customview;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;

import com.revesoft.material.R;

/**
 * @author  ifta on 4/9/17.
 */

public class WorkingIndication {

    public static Dialog show(Activity activity)
    {
        int time = 500;
        int windowSize = activity.getResources().getDimensionPixelSize(R.dimen.loaderSize);
        int boxSize = activity.getResources().getDimensionPixelSize(R.dimen.standard_16);
        int positiveMove = windowSize-boxSize;
        int negativeMove =  boxSize-windowSize;
        final Dialog dialog = new Dialog(activity , android.R.style.Theme_Translucent);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.app_common_loader_layout_for_dialog);

        View sqOne = dialog.findViewById(R.id.sqOne);
        View sqTwo = dialog.findViewById(R.id.sqTwo);


        ScaleAnimation scaleDown1 = new ScaleAnimation(1.0f,0.5f,1.0f,0.5f);
        scaleDown1.setDuration(time);

        ScaleAnimation scaleUp1 = new ScaleAnimation(1.0f,2.0f,1.0f,2.0f);
        scaleUp1.setDuration(time);
        scaleUp1.setStartOffset(time);

        ScaleAnimation scaleDown2 = new ScaleAnimation(1.0f,0.5f,1.0f,0.5f);
        scaleDown2.setDuration(time);
        scaleDown2.setStartOffset(time*2);

        ScaleAnimation scaleUp2 = new ScaleAnimation(1.0f,2.0f,1.0f,2.0f);
        scaleUp2.setDuration(time);
        scaleUp2.setStartOffset(time*3);

        final AnimationSet animationSetForSqOne = new AnimationSet(true);


        animationSetForSqOne.addAnimation(scaleDown1);
        animationSetForSqOne.addAnimation(scaleUp1);
        animationSetForSqOne.addAnimation(scaleDown2);
        animationSetForSqOne.addAnimation(scaleUp2);

        TranslateAnimation t1 = new TranslateAnimation(0,positiveMove,0,0);
        t1.setDuration(time);

        TranslateAnimation t2 = new TranslateAnimation(0,0,0,positiveMove);
        t2.setDuration(time);
        t2.setStartOffset(time);

        TranslateAnimation t3 = new TranslateAnimation(0,negativeMove,0,0);
        t3.setDuration(time);
        t3.setStartOffset(time*2);

        TranslateAnimation t4 = new TranslateAnimation(0,0,0,negativeMove);
        t4.setDuration(time);
        t4.setStartOffset(time*3);
        t4.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                animationSetForSqOne.start();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


        animationSetForSqOne.addAnimation(t1);
        animationSetForSqOne.addAnimation(t2);
        animationSetForSqOne.addAnimation(t3);
        animationSetForSqOne.addAnimation(t4);

        final AnimationSet animationSetForSqTwo = new AnimationSet(true);
        animationSetForSqTwo.addAnimation(scaleDown1);
        animationSetForSqTwo.addAnimation(scaleUp1);
        animationSetForSqTwo.addAnimation(scaleDown2);
        animationSetForSqTwo.addAnimation(scaleUp2);
        TranslateAnimation t1For2 = new TranslateAnimation(0,negativeMove,0,0);
        t1For2.setDuration(time);

        TranslateAnimation t2For2 = new TranslateAnimation(0,0,0,negativeMove);
        t2For2.setDuration(time);
        t2For2.setStartOffset(time);

        TranslateAnimation t3For2 = new TranslateAnimation(0,positiveMove,0,0);
        t3For2.setDuration(time);
        t3For2.setStartOffset(time*2);

        TranslateAnimation t4For2 = new TranslateAnimation(0,0,0,positiveMove);
        t4For2.setDuration(time);
        t4For2.setStartOffset(time*3);
        t4For2.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                animationSetForSqTwo.start();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animationSetForSqTwo.addAnimation(t1For2);
        animationSetForSqTwo.addAnimation(t2For2);
        animationSetForSqTwo.addAnimation(t3For2);
        animationSetForSqTwo.addAnimation(t4For2);


        sqOne.startAnimation(animationSetForSqOne);
        sqTwo.startAnimation(animationSetForSqTwo);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        return dialog;

    }
}
