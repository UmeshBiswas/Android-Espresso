/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 11:05 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 11:05 AM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.Recharge;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */

@Dao
public interface RechargeDao extends BaseDao<Recharge> {
    @Query("SELECT * FROM recharge_table")
    List<Recharge> getAll();


}
