package com.revesoft.itelmobiledialer.customview.imageListDialog;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.revesoft.material.R;

import java.util.List;

/**
 * @author Ifta
 *         on 8/28/2017.
 */

public class ImageListAdapter extends ArrayAdapter<ImageListItem> {
    LayoutInflater layoutInflater;
    private boolean showDivider = false;
    private int textColor;

    public ImageListAdapter(@NonNull Context context, @NonNull List<ImageListItem> objects, boolean showDivider, int textColorId) {
        super(context, 0, objects);
        layoutInflater = ((Activity) context).getLayoutInflater();
        this.showDivider = showDivider;

        this.textColor = ContextCompat.getColor(context, textColorId);
    }

    public ImageListAdapter(@NonNull Context context, @NonNull List<ImageListItem> objects, boolean showDivider) {
        super(context, 0, objects);
        layoutInflater = ((Activity) context).getLayoutInflater();
        this.showDivider = showDivider;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        Holder holder;
        if (convertView == null) {
            view = layoutInflater.inflate(R.layout.image_list_dialog_single_item, parent, false);
            holder = new Holder();
            holder.iv = (ImageView) view.findViewById(R.id.iv);
            holder.tv = (TextView) view.findViewById(R.id.tv);
            holder.divider = view.findViewById(R.id.divider);
            view.setTag(holder);
        } else {
            holder = (Holder) view.getTag();
        }
        ImageListItem imageListItem = getItem(position);
        if (imageListItem != null) {
            holder.iv.setImageResource(imageListItem.imageDrawableId);
            holder.tv.setText(imageListItem.itemName);
//            holder.tv.setTextColor(textColor);
            if (position == getCount() - 1) {
                holder.divider.setVisibility(View.GONE);
            } else if (showDivider) {
                holder.divider.setVisibility(View.VISIBLE);
            } else {
                holder.divider.setVisibility(View.GONE);
            }
        }
        return view;
    }

    private class Holder {
        View divider;
        TextView tv;
        ImageView iv;
    }
}
