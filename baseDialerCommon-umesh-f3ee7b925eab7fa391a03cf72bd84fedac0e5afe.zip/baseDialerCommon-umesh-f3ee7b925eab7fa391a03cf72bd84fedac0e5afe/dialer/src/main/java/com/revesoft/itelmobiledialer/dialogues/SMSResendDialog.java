package com.revesoft.itelmobiledialer.dialogues;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static com.revesoft.itelmobiledialer.util.Constants.compose;

/**
 * Created by dpaul on 3/22/15.
 */
public class SMSResendDialog extends Activity {
    public static final String MESSAGE = "message";
    public static final String REQUEST_ID = "request_id";

    private String request_id;
    private Button resend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_confirmation_dialog);

        request_id = getIntent().getStringExtra(REQUEST_ID);
        if (request_id == null || request_id.equals("")) {
            finish();
        }

        String message = getIntent().getStringExtra(MESSAGE);
        if (message != null) {
            ((TextView) findViewById(R.id.confirmation_message)).setText(message);
        } else {
            finish();
        }

        resend = findViewById(R.id.buttonOK);
        resend.setText(getString(R.string.resend));
        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Util.hasConnection(SMSResendDialog.this)) {
                    alert(getString(R.string.error_no_data_connection));
                    return;
                }
//                else if (!SIPProvider.registrationFlag ) {
//                    alert(getString(R.string.error_connection_to_server_failed));
//                    return;
//                }
                else {
//                    SmsLogEntry sle = DatabaseConstants.newInstance(SMSResendDialog.this).getSmsByRequestID(request_id);
//                    sendIntentMessageToDialerForSMS(sle.number, sle.content);
//                    CustomNotification.getNotificationInstance(SMSResendDialog.this).cancelFailedSMSNotiication();
                }
                finish();
            }
        });

        findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

//        CustomNotification.getNotificationInstance(this).cancelFailedSMSNotiication();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        if (intent == null)
            return;

        request_id = intent.getStringExtra(REQUEST_ID);
        if (request_id == null || request_id.equals("")) {
            finish();
        }

        String message = intent.getStringExtra(MESSAGE);
        if (message != null) {
            ((TextView) findViewById(R.id.confirmation_message)).setText(message);
        } else {
            finish();
        }

    }

    private void sendIntentMessageToDialerForSMS(String number, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("sendsms", "");
        intent.putExtra("to1", new String[]{number});
        intent.putExtra(compose, message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void alert(String message) {
        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        bld.setMessage(message);
        bld.setNeutralButton(android.R.string.ok, null);
        Log.d("RateFragment", "Showing alert dialog: " + message);
        bld.create().show();
    }
}
