package com.revesoft.itelmobiledialer.chat.tenor.tools.validator;


import android.text.TextUtils;

import com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces.IValidator;

import java.util.regex.Pattern;

import androidx.annotation.NonNull;

public abstract class AbstractValidator<T> implements IValidator<T> {

    private static final long serialVersionUID = 1605380452419139489L;
    private final Pattern mPattern;

    public AbstractValidator(@NonNull String regex) {
        if (TextUtils.isEmpty(regex)) {
            throw new IllegalArgumentException("regex cannot be empty");
        }
        mPattern = Pattern.compile(regex);
    }

    @NonNull
    @Override
    public Pattern get() {
        return mPattern;
    }
}
