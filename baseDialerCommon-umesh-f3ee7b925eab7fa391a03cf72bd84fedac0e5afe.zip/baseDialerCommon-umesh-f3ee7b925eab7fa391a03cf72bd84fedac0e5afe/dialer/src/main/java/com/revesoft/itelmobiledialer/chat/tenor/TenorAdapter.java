package com.revesoft.itelmobiledialer.chat.tenor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces.IDrawableLoaderTaskListener;
import com.revesoft.itelmobiledialer.chat.tenor.tools.loaders.GifLoader;
import com.revesoft.itelmobiledialer.chat.tenor.tools.params.GlideTaskParams;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 10/29/2017.
 */

public class TenorAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    TaggedLogger logger = new TaggedLogger("TenorGif");
    private ArrayList<TenorGif> tenorGifs = new ArrayList<>();
    private Context context;
    private Drawable placeHolder;

    public TenorAdapter(Context context) {
        this.context = context;
        placeHolder = ContextCompat.getDrawable(context, R.drawable.ic_cloud_download_black_24dp);
    }


    private TenorClickListener tenorClickListener = null;

    public void attachTenorClickListener(TenorClickListener tenorClickListener) {
        this.tenorClickListener = tenorClickListener;
    }

    void addMore(ArrayList<TenorGif> tenorGifs) {
        this.tenorGifs.addAll(tenorGifs);
        logger.log("size after adding = " + tenorGifs.size());
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.tenor_item, parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder) holder).bindView(position);
    }


    @Override
    public int getItemCount() {
        return tenorGifs.size();
    }

    public void refresh(ArrayList<TenorGif> tenorGifs) {
        this.tenorGifs.clear();
        this.tenorGifs.addAll(tenorGifs);
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPreview, dummy;
        ShimmerFrameLayout shimmerFrameLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            ivPreview = itemView.findViewById(R.id.ivPreview);
            dummy = itemView.findViewById(R.id.dummyIvPreview);
            shimmerFrameLayout = itemView.findViewById(R.id.sticker_shimmer_view_container);
        }

        public void bindView(final int position) {
            TenorGif tenorGif = tenorGifs.get(position);
            if (tenorGif.isPreview) {
                dummy.setVisibility(View.VISIBLE);
                ivPreview.setVisibility(View.GONE);
            } else {

                itemView.setOnClickListener(v -> {
                    if (tenorClickListener != null) {
                        tenorClickListener.onTenorClick(tenorGif);
                    }
                });

                final String nanoGifUrl = tenorGif.nanoGifUrl;
                GlideTaskParams<ImageView> params = new GlideTaskParams<>(ivPreview, nanoGifUrl);
                params.setHeight(tenorGif.nanoHeight);
                params.setWidth(tenorGif.nanoWidth);
                params.setPlaceholder(Color.LTGRAY);
                params.setListener(new IDrawableLoaderTaskListener<ImageView, Drawable>() {
                    @Override
                    public void success(@NonNull ImageView target, @NonNull Drawable taskResult) {
                        ivPreview.setVisibility(View.VISIBLE);
                        dummy.setVisibility(View.GONE);
                    }

                    @Override
                    public void failure(@NonNull ImageView target, @NonNull Drawable errorResult) {

                    }
                });
                GifLoader.loadGif(context, params);
            }
        }

    }
}
