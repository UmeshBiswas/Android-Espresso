package com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces;



import java.io.Serializable;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;

public interface IValidator<T> extends Serializable {
    @NonNull
    Pattern get();

    /**
     * @return true if validation result is positive, else false
     */
    boolean validate(T t);
}
