package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.MultiPartMessage;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface MultiPartMessageDao extends BaseDao<MultiPartMessage> {
    @Query("SELECT * FROM MULTIPARTMESSAGES WHERE number=:number AND is_decrypted=0 AND is_outgoing=0")
    Cursor getUnDecryptedMultiPartMessagesByNumber(String number);

    @Query("SELECT * FROM MULTIPARTMESSAGES WHERE groupid=:groupID AND is_decrypted=0 AND is_outgoing=0")
    Cursor getUnDecryptedIncomingMultiPartMessagesByGroupID(String groupID);

    @Query("SELECT * FROM MULTIPARTMESSAGES WHERE calleridlocal=:localCallerID")
    Cursor getMultiPartMessagesByCallerIDLocal(String localCallerID);

    @Query("DELETE FROM MULTIPARTMESSAGES WHERE calleridlocal=:localCallId")
    void deleteMultiPartMessage(String localCallId);


    @Query("UPDATE MULTIPARTMESSAGES SET messagecontent=:content,is_decrypted=1 WHERE callerid=:callerId")
    void updateMultipartMessageContentToDecrypted(String callerId, String content);


    @Query("DELETE FROM MULTIPARTMESSAGES WHERE calleridlocal=:callIDLocal AND multipart_number>=:multipartIndex")
    void deleteMultiPartMessage(String callIDLocal, int multipartIndex);

    @Query("SELECT calleridlocal FROM MULTIPARTMESSAGES WHERE date=:time LIMIT 1")
    String getlocalCallIDFromTimeStamp(long time);
}