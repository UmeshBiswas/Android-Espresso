package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Recharge;
import com.revesoft.itelmobiledialer.databaseentry.RechargeEntry;

public class RechargeRepo {
    private static final RechargeRepo ourInstance = new RechargeRepo();

    private RechargeRepo() {
    }

    public static RechargeRepo get() {
        return ourInstance;
    }

    public int insertRechargeEntry(RechargeEntry entry) {
        String refundText = "";
        if (entry.refundText != null) {
            refundText = entry.refundText;
        }
        Recharge recharge = Recharge.newBuilder().withAmount(entry.rechargeAmount)
                .withCurrencyCode(entry.currencyCode)
                .withTransactionId(entry.transactionId)
                .withPaymentMethod(entry.paymentMethod)
                .withStatus(entry.rechargeStatus)
                .withRefundText(refundText)
                .build();
        AppDatabase.get().rechargeDao().insert(recharge);
        return recharge._id;
    }

    public void updateRechargeEntry(int entry_id, RechargeEntry entry) {
        String refundText = "";
        if (entry.refundText != null) {
            refundText = entry.refundText;
        }
        Recharge recharge = Recharge.newBuilder().withAmount(entry.rechargeAmount)
                .with_id(entry_id)
                .withCurrencyCode(entry.currencyCode)
                .withTransactionId(entry.transactionId)
                .withPaymentMethod(entry.paymentMethod)
                .withStatus(entry.rechargeStatus)
                .withRefundText(refundText)
                .build();
        AppDatabase.get().rechargeDao().update(recharge);
    }
}
