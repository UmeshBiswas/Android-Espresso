package com.revesoft.itelmobiledialer.appDatabase;

public interface UriNotifyEventListener {
    void notifyUri();
}
