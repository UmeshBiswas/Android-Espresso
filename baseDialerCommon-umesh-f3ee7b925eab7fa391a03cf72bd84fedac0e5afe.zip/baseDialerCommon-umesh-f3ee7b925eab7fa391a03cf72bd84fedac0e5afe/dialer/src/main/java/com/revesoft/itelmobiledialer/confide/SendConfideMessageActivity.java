package com.revesoft.itelmobiledialer.confide;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import com.iftalab.runtimepermission.AppPermissionListener;
import com.iftalab.runtimepermission.DangerousPermission;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.ImageGalleryFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.SoundRecorderFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.LanguageManager;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import static com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants.MULTIPART_MESSAGE_UPPER_LIMIT_IN_STRING;


/**
 * @author Sajib and Ashrafi on 1/4/2018.
 */
@SuppressWarnings("all")

public class SendConfideMessageActivity extends AppCompatActivity implements ConfideFileSelectionListener {
    private static final TaggedLogger logger = new TaggedLogger("ConfideChat");
    public static final String KEY_NUMBER = "KEY_NUMBER";
    public static String number = "";

    private EditText etMessage;

    private boolean attachement_sent = false;
    private boolean isAttachement_ready = false;
    private Fragment lastActiveFragment;


    public enum attachment_type {image_file, video_file, audio_file}

    ;
    public String audio_file_path = "";
    attachment_type type = null;


    public String filePath = "";

    ImageView ivSend;
    ImageView ivCamera;
    ImageView ivVoiceMessage;
    View bottomFragmentsHolder;
    View tvRemoveAttachment;
    View mediaOptionsHolder;
    View filePreviewHolder;

    private int icSendImageResourceId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        LanguageManager.initLanguage();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_confide_message_layout);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        number = this.getIntent().getStringExtra(KEY_NUMBER);
        if (TextUtils.isEmpty(number)) {
            finish();
        } else {
            ConfideSender.configureFor(number);
        }
        handleToolbar();
        initViews();

    }


    Toolbar toolbar;

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
            if (!TextUtils.isEmpty(number) && CommonData.contactNumberToContactName.containsKey(number)) {
                actionBar.setTitle(CommonData.contactNumberToContactName.get(number));
            } else {
                actionBar.setTitle(getString(R.string.smokeChat));
            }

        }
    }


    private void initViews() {
        bottomFragmentsHolder = findViewById(R.id.bottomFragmentsHolder);
        ivSend = (ImageView) findViewById(R.id.ivSend);
        ivSend.setImageResource(icSendImageResourceId);
        etMessage = (EditText) findViewById(R.id.compose_text);
        ivCamera = (ImageView) findViewById(R.id.ivCamera);
        ivVoiceMessage = (ImageView) findViewById(R.id.ivVoiceMessage);
        mediaOptionsHolder = findViewById(R.id.mediaOptionsHolder);
        tvRemoveAttachment = findViewById(R.id.tvRemoveAttachment);
        tvRemoveAttachment.setVisibility(View.GONE);
        filePreviewHolder = findViewById(R.id.filePreviewHolder);
        filePreviewHolder.setVisibility(View.GONE);
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.ivCamera:
                        cameraPermission();
                        break;
                    case R.id.ivVoiceMessage:
                        DangerousPermission.MicrophonePermission.getAccess(SendConfideMessageActivity.this).requestPermission(SendConfideMessageActivity.this, new AppPermissionListener() {
                            @Override
                            public void onPermissionGranted() {
                                getStoragePermission();
                            }

                            @Override
                            public void onPermissionRejected() {

                            }
                        });

                        break;
                }
            }
        };
        ivCamera.setOnClickListener(listener);
        ivVoiceMessage.setOnClickListener(listener);
        ivSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
        etMessage.setOnClickListener(v -> hideBottomFragment());
        etMessage.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    hideBottomFragment();
                }
            }
        });
    }

    private void getStoragePermission() {
        DangerousPermission.StoragePermission.getAccess(SendConfideMessageActivity.this).requestPermission(SendConfideMessageActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                showBottomFragment(SoundRecorderFragment.getInstance());
            }

            @Override
            public void onPermissionRejected() {

            }
        });
    }

    private void cameraPermission() {
        DangerousPermission.CameraPermission.getAccess(SendConfideMessageActivity.this).requestPermission(SendConfideMessageActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                readWriteStoragePermission();
            }

            @Override
            public void onPermissionRejected() {

            }
        });
    }

    void readWriteStoragePermission() {
        DangerousPermission.StoragePermission.getAccess(SendConfideMessageActivity.this).requestPermission(SendConfideMessageActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                showBottomFragment(ImageGalleryFragment.getInstance());
            }

            @Override
            public void onPermissionRejected() {

            }
        });
    }

    private void sendMessage() {
        String message = etMessage.getText().toString().trim();
        if (message.length() > 2500) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        etMessage.setText(null);
        if (TextUtils.isEmpty(filePath)) {
            if (!TextUtils.isEmpty(message)) {
                Sender.getAccess().sendConfideTextMessage(message);
            }
        } else {
            Sender.getAccess().sendConfideFile(filePath, message);
        }
        finish();
    }


    private void showBottomFragment(Fragment fragment) {
        hideKeyBoard();
        bottomFragmentsHolder.setVisibility(View.VISIBLE);
        if (fragment == null) return;
        lastActiveFragment = fragment;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.bottomFragmentsHolder, fragment)
                .commit();
        handleBottomOptionSelectionStates();
    }

    private void hideBottomFragment() {
        bottomFragmentsHolder.setVisibility(View.INVISIBLE);
        if (lastActiveFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .remove(lastActiveFragment)
                    .commit();
            lastActiveFragment = null;
        }
        deselectAllBottomOptions();
    }

    private void hideKeyBoard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        }
    }

    private void deselectAllBottomOptions() {
        ivCamera.setSelected(false);
        ivVoiceMessage.setSelected(false);
    }

    private void handleBottomOptionSelectionStates() {
        deselectAllBottomOptions();
        if (lastActiveFragment == null) {
            return;
        }
        if (lastActiveFragment instanceof ImageGalleryFragment) {
            ivCamera.setSelected(true);
        } else if (lastActiveFragment instanceof SoundRecorderFragment) {
            ivVoiceMessage.setSelected(true);
        }
    }

    private void showPreviewMessageWindow(String message) {
        Intent intent = new Intent(SendConfideMessageActivity.this, ConfidePreviewActivity.class);
        intent.putExtra(ConfidePreviewActivity.KEY_TEXT, message);
        intent.putExtra(ConfidePreviewActivity.KEY_TARGET, number);
        if (!(!TextUtils.isEmpty(message) &&
                message.getBytes().length > MULTIPART_MESSAGE_UPPER_LIMIT_IN_STRING &&
                TextUtils.isEmpty(filePath)))
            intent.putExtra(ConfidePreviewActivity.KEY_FILE_PATH, filePath);
        intent.putExtra(ConfidePreviewActivity.KEY_IS_PREVIEW, true);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (lastActiveFragment != null) {
                    hideBottomFragment();
                } else {
                    finish();
                }
                break;
            case R.id.actionPreview:
                String message = etMessage.getText().toString().trim();
                if (!TextUtils.isEmpty(message) || !TextUtils.isEmpty(filePath)) {
                    showPreviewMessageWindow(message);
                } else {
                    I.toast(getString(R.string.nothingToPreview));
                }
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.confide_message_send_activity_menu, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (lastActiveFragment != null) {
            hideBottomFragment();
        } else {
            finish();
        }
        super.onBackPressed();
    }

    @Override
    public void onFileSelect(String filePath) {
        this.filePath = filePath;
        showFilePreview();
        hideBottomFragment();
        disableFileAttachment();
    }

    private void disableFileAttachment() {
        mediaOptionsHolder.setVisibility(View.INVISIBLE);
        tvRemoveAttachment.setVisibility(View.VISIBLE);
    }

    public void removeAttachment(View view) {
        mediaOptionsHolder.setVisibility(View.VISIBLE);
        tvRemoveAttachment.setVisibility(View.GONE);
        filePath = null;
        removeFilePreview();
    }

    private void showFilePreview() {
        filePreviewHolder.setVisibility(View.VISIBLE);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.filePreviewHolder, FilePreviewFragment.getInstance(filePath), FilePreviewFragment.TAG)
                .commit();
    }

    private void removeFilePreview() {
        filePreviewHolder.setVisibility(View.GONE);
        getSupportFragmentManager().beginTransaction()
                .remove(getSupportFragmentManager().findFragmentByTag(FilePreviewFragment.TAG))
                .commit();
    }


}
