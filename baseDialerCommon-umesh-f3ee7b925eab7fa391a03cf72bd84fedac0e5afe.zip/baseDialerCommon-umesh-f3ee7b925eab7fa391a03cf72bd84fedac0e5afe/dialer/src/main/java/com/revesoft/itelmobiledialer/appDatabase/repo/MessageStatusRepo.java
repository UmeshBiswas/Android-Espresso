package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.MessageStatus;

import java.util.List;

public class MessageStatusRepo {
    private static final MessageStatusRepo ourInstance = new MessageStatusRepo();

    private MessageStatusRepo() {
    }


    public List<MessageStatus> getAll() {
        return AppDatabase.get().messageStatusDao().getAll();
    }

    public void insertAll(List<MessageStatus> messageStatusList) {
        AppDatabase.get().messageStatusDao().insertAll(messageStatusList);
    }

    public static MessageStatusRepo get() {
        return ourInstance;
    }

    public void delivered(String callId, String number, long deliveredTime) {
        MessageStatus messageStatus = MessageStatus.newBuilder()._id(100).callerId(callId).deliveryTime(deliveredTime).number(number).build();
//            try {
        AppDatabase.get().messageStatusDao().insert(messageStatus);
//                if (rowAffected > 0) {
//                    XUriChangeNotifier.notify(XUriChangeNotifier.UriType.MESSAGE);
//                    XUriChangeNotifier.notify(XUriChangeNotifier.UriType.MESSAGE_HISTORY);
//                }
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//        return 0;
    }


    public void seen(String callId, String number, long seenTime) {
//        Executor.ex(() -> {
        MessageStatus[] messageStatuses = AppDatabase.get().messageStatusDao().getStatusMessageByCallID(callId);

        MessageStatus messageStatus;
        if (messageStatuses.length > 0) {
            messageStatus = messageStatuses[0];
            messageStatus.seenTime = seenTime;
        } else
            messageStatus = MessageStatus.newBuilder()._id(100).callerId(callId).seenTime(seenTime).number(number).build();


        AppDatabase.get().messageStatusDao().insert(messageStatus);
//            if (rowAffected > 0) {
//                XUriChangeNotifier.notify(XUriChangeNotifier.UriType.MESSAGE);
//                XUriChangeNotifier.notify(XUriChangeNotifier.UriType.MESSAGE_HISTORY);
//            }

//        });
//        return 0;
    }


    public Cursor getMessageStatusByCallerId(String calledId) {
        return AppDatabase.get().messageStatusDao().getMessageStatusByCallerId(calledId);
    }


    public Cursor seenDeliveryCountWithGroupMemberCount(String groupId) {
        return AppDatabase.get().messageStatusDao().seenDeliveryCountWithGroupMemberCount(groupId);
    }


    public Cursor lastMessageSeenDeliveryCountWithGroupMemberCount() {
        return AppDatabase.get().messageStatusDao().lastMessageSeenDeliveryCountWithGroupMemberCount();
    }
}
