package com.revesoft.itelmobiledialer.callog.callLogDetails;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.material.R;
import com.revesoft.material.databinding.CallLogDetailIndividualBinding;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;


public class CallLogDetailsAdapter extends RecyclerView.Adapter<CallLogDetailsAdapter.ViewHolder> {
    private List<CallLogDetailsCallItem> data = new ArrayList<>();
    private int currentPosition = -1;
    Context c;
    private boolean isPlaying = false;
    MediaPlayer mp = null;

    public CallLogDetailsAdapter(Context c){
        this.c = c;
    }



    public void swapData(List<CallLogDetailsCallItem> data) {
        this.data.clear();
        this.data.addAll(data);
        notifyDataSetChanged();//technical debt left for next coder. (devil)
        //user diff util here for data change update
        //https://android.jlelse.eu/smart-way-to-update-recyclerview-using-diffutil-345941a160e0
    }

    @NonNull
    @Override
    public CallLogDetailsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CallLogDetailIndividualBinding binding =
                DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                        R.layout.call_log_detail_individual,
                        parent, false);
        return new ViewHolder(binding);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(@NonNull CallLogDetailsAdapter.ViewHolder holder, int position) {
        CallLogDetailsCallItem detailsCallItem = data.get(position);
        if (detailsCallItem != null) {
            holder.binding.setItem(detailsCallItem);
            if(currentPosition == position) holder.binding.playAudioLayout.setVisibility(View.VISIBLE);
            else holder.binding.playAudioLayout.setVisibility(View.GONE);
            holder.binding.getRoot().findViewById(R.id.soundClip).setOnClickListener((v)->{
                if(position == currentPosition){
                    holder.binding.playAudioLayout.setVisibility(View.GONE);
                    currentPosition = -1;
                }else{
                    currentPosition = position;
                    notifyDataSetChanged();
                }
            });
            holder.binding.getRoot().findViewById(R.id.recordPlayButton).setOnClickListener((v)->{
                if(mp == null ){
                    try {
                        mp = new MediaPlayer();
                        mp.setDataSource(data.get(position).getRecordedAudiopath());
                        mp.prepareAsync();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

//                    mp.start();
                    mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mp.start();
                        }
                    });

                }
//                else if(mp != null){
//                    if(isPlaying){
//                        mp.pause();
//                        isPlaying = false;
//                    }
//                    else {
//                        isPlaying = true;
//                        mp.start();
//                    }
//                }
                mp.setOnCompletionListener((listener)->{
                    if(mp != null){
                        mp.reset();
                        mp.release();
                        mp = null;
                    }

                });

            });

        }
    }




    @Override
    public int getItemCount() {
        return data.size();
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        CallLogDetailIndividualBinding binding;

        public ViewHolder(@NonNull CallLogDetailIndividualBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

    }
}
