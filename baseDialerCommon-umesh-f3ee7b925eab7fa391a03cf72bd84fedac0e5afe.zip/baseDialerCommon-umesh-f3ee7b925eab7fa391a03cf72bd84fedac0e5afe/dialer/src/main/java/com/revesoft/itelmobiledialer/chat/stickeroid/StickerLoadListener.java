package com.revesoft.itelmobiledialer.chat.stickeroid;

import java.util.ArrayList;

/**
 * @author Ifta on 10/30/2017.
 */

public interface StickerLoadListener {
    void onStickerLoad(ArrayList<Sticker> stickers);
    void onStickerLoadError(String errorInfo);
}
