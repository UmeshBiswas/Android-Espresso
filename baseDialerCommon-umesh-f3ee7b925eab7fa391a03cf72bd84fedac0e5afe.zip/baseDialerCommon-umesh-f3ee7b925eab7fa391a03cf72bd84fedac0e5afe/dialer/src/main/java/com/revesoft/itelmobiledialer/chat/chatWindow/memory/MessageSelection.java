package com.revesoft.itelmobiledialer.chat.chatWindow.memory;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDialogs;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.SeenSender;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.MessageSelectionInteractionListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.CustomizableSender;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.GenericFileProvider;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.io.File;
import java.util.ArrayList;

import androidx.appcompat.app.AlertDialog;

/**
 * @author Ifta on 1/15/2018.
 */

public class MessageSelection {
    private static MessageSelectionInteractionListener listener;
    public static boolean isInSelectionMode = false;
    private static ArrayList<Message> selectedMessage = new ArrayList<>();
    private static boolean isInMessageEditMode = false;

    public static void addOrRemove(Message message) {
        if (isInMessageEditMode) return;
        if (selectedMessage.contains(message)) {
            selectedMessage.remove(message);
        } else {
            selectedMessage.add(message);
        }
        isInSelectionMode = selectedMessage.size() > 0;
        listener.onSelectOrDeselect();
    }

    public static void setIsInMessageEditMode(boolean isInMessageEditMode) {
        MessageSelection.isInMessageEditMode = isInMessageEditMode;
    }

    public static boolean isIsInMessageEditMode() {
        return isInMessageEditMode;
    }

    public static ArrayList<Message> getAll() {
        return selectedMessage;
    }

    public static int getCount() {
        return selectedMessage.size();
    }

    public static boolean isSelected(Message message) {
        return selectedMessage.contains(message);
    }

    public static void attachListener(MessageSelectionInteractionListener selectionInteractionListener) {
        MessageSelection.listener = selectionInteractionListener;
    }

    public static void exitSelection() {
        selectedMessage.clear();
        isInSelectionMode = false;
        listener.onSelectOrDeselect();
    }

    public static void copySelectionToClipBoard(Activity activity) {
        ClipboardManager clipboardManager = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
        StringBuilder builder = new StringBuilder();
        for (Message message : selectedMessage) {
            if (message.mimeType == MimeType.Text || message.mimeType == MimeType.Link) {
                if (message.content.startsWith(Constants.GROUP_SMS_PREFIX)) {
                    String text = message.content.substring(message.content.indexOf(Constants.GROUP_SMS_SEPARATOR)).replace(Constants.GROUP_SMS_SEPARATOR, "").replace(Constants.GROUP_SMS_SUFFIX, "");
                    builder.append(text);
                } else {
                    builder.append(message.content);
                }
                builder.append("\n");
            } else {
                I.toast(Supplier.getString(R.string.cannotBeCopied));
                break;
            }
        }
        if (builder.toString().trim().length() > 0) {
            ClipData clipData = ClipData.newPlainText("ChatWindowClipData", builder.toString());
            if (clipboardManager != null && clipData != null) {
                clipboardManager.setPrimaryClip(clipData);
                I.toast(Supplier.getString(R.string.text_copied_to_clipboard));
                exitSelection();
            }
        } else {
            I.toast(Supplier.getString(R.string.nothingToCopy));
        }
    }

    public static void deleteSelectedMessage(Activity activity) {
        if (allSentMessage() && doesNotHaveAlreadyDeletedMessage() && !hasFutureMessage()) {
            showOptionForDeleteType(activity);
        } else {
            deleteMessages(activity);
        }

    }

    private static void deleteMessages(Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(Supplier.getString(R.string.delete_message));
        builder.setMessage(Supplier.getString(R.string.aryYouSureToDeleteSelectedMessages));
        builder.setPositiveButton(Supplier.getString(R.string.yes_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ArrayList<String> callIds = new ArrayList<>(selectedMessage.size());
                for (Message message : selectedMessage) {
                    callIds.add(message.callerId);
                    if (message.isConfide) {
                        SeenSender.getAccess().sendSeen(message.callerId);
                    }
// //////                   Util.deleteFile(message.filePathLocal, message.filePathOriginal);
                }

                Executor.ex(() -> {
                    MessageRepo.get().deleteMessageByCallIdList(callIds);
                    Gui.get().run(() -> {
                        I.toast(Supplier.getString(R.string.deleted));
                    });
                });
                exitSelection();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton(Supplier.getString(R.string.no_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                exitSelection();
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private static void deleteMessagesForAll(Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(Supplier.getString(R.string.delete_message));
        builder.setMessage(Supplier.getString(R.string.aryYouSureToDeleteSelectedMessagesForAll));
        builder.setPositiveButton(Supplier.getString(R.string.yes_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ArrayList<String> callIdsForMarkedDelete = new ArrayList<>();
                ArrayList<String> callIdsForActualDelete = new ArrayList<>();
                for (Message message : selectedMessage) {
                    Sender.getAccess().deleteForAll(message);
                }
                for (Message message : selectedMessage) {
                    if (message.mimeType == MimeType.Deleted) {
                        callIdsForActualDelete.add(message.callerId);
                    } else {
                        callIdsForMarkedDelete.add(message.callerId);
                    }
                }
                Executor.ex(() -> {
//                    if (ChatProperties.isGroupChat) {
//                        MessageRepo.get().markAsDeleted(callIdsForMarkedDelete);
//                        Database.GroupMessages.Delete.byCallId(callIdsForActualDelete);
//                    } else {
//
//                        Database.Message.Update.markAsDeleted(callIdsForMarkedDelete);
//                        for(String id:callIdsForActualDelete)
//                            Database.Message.Delete.byCallId(id);
//
//                    }
                    MessageRepo.get().markAsDeleted(callIdsForMarkedDelete);
                    MessageRepo.get().deleteMessageByCallIdList(callIdsForActualDelete);

                    Gui.get().run(() -> {
                        I.toast(Supplier.getString(R.string.deleted));
                        exitSelection();
                    });

                });
                dialog.dismiss();


            }
        });
        builder.setNegativeButton(Supplier.getString(R.string.no_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                exitSelection();
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private static void showOptionForDeleteType(final Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(Supplier.getString(R.string.delete_message));
        builder.setPositiveButton(Supplier.getString(R.string.delete_for_everyone), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteMessagesForAll(activity);
            }
        });
        builder.setNegativeButton(Supplier.getString(R.string.delete_for_myself), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteMessages(activity);
            }
        });
        builder.create().show();
    }

    private static boolean allSentMessage() {
        for (Message message : selectedMessage) {
            if (message.messageType == MessageEntry.MessageType.RECEIVED || message.messageType == MessageEntry.MessageType.RECEIVED_SMS) {
                return false;
            }
        }
        return true;
    }

    public static boolean doesNotHaveAlreadyDeletedMessage() {
        for (Message message : selectedMessage) {
            if (message.mimeType == MimeType.Deleted) {
                return false;
            }
        }
        return true;
    }

    public static boolean containsFile() {
        boolean hasFile = false;
        for (Message message : selectedMessage) {
            if (message.mimeType != MimeType.Text && message.mimeType != MimeType.Link) {
                hasFile = true;
                break;
            }
        }
        return hasFile;
    }

    public static boolean containsAnythingThanTextAndFile() {
        for (Message message : selectedMessage) {
            if (!(message.mimeType == MimeType.Text || message.mimeType == MimeType.Video || message.mimeType == MimeType.Image || message.mimeType == MimeType.Audio)) {
                return true;
            }
        }
        return false;
    }

    public static void forwardByOtherApp(Activity activity) {
        StringBuilder textMessageBuilder = new StringBuilder();
        ArrayList<Uri> fileUriList = new ArrayList<>();
        File file = null;
        Uri photoUri = null;
        for (Message message : selectedMessage) {
            if (message.mimeType == MimeType.Text) {
                textMessageBuilder.append(message.content);
                textMessageBuilder.append("\n");
            } else {
                file = new File(message.filePathLocal);
                if (file.exists()) {
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
                        String authority = AppContext.getAccess().getContext().getPackageName() + ".my.package.name.provider";
                        photoUri = GenericFileProvider.getUriForFile(AppContext.getAccess().getContext(), authority, file);
                        fileUriList.add(photoUri);
                    } else {
                        fileUriList.add(Uri.fromFile(file));
                    }
                }
            }
        }

        Intent shareIntent = new Intent();
        if (fileUriList.size() > 0) {
            shareIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            shareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, fileUriList);
            shareIntent.setType("*/*");
        } else {
            shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
        }

        shareIntent.putExtra(Intent.EXTRA_TEXT, textMessageBuilder.toString());

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            shareIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(shareIntent);
        } else {
            activity.startActivity(Intent.createChooser(shareIntent, Supplier.getString(R.string.share_via)));
        }
        exitSelection();
    }

    public static void sendSelectedMessages(String target, boolean isGroup, boolean isEncrypted) {
        for (Message message : selectedMessage) {
            if (message.mimeType == MimeType.Image) {
                String caption = ChatContentParser.parseCaption(message.content);
                if (!TextUtils.isEmpty(caption)) {
                    CustomizableSender.sendFileMessageWithCaption(message.filePathLocal, caption, target, isGroup, isEncrypted);
                } else {
                    CustomizableSender.sendFileMessage(message.filePathLocal, target, isGroup, isEncrypted);
                }
            } else if (message.mimeType == MimeType.Video || message.mimeType == MimeType.Audio) {
                CustomizableSender.sendFileMessage(message.filePathLocal, target, isGroup, isEncrypted);
            } else if (message.mimeType == MimeType.Document || message.mimeType == MimeType.Contact) {
                CustomizableSender.sendFileMessage(message.filePathLocal, target, isGroup, isEncrypted);
            } else {
                CustomizableSender.sendMessage(message.content, target, isGroup, isEncrypted);
            }
        }
        exitSelection();
    }

    public static void sendSelectedMessagesAsSMS(String target, boolean isGroup) {
        for (Message message : selectedMessage) {
            if (message.mimeType == MimeType.Text) {
                CustomizableSender.sendSMS(message.content, target, isGroup);
            }
        }
        exitSelection();
    }

    public static boolean containsAnythingThanText() {
        for (Message message : selectedMessage) {
            if (message.mimeType != MimeType.Text) {
                return true;
            }
        }
        return false;
    }

    public static void editSelectedMessage(Activity activity) {
        if (selectedMessage.size() == 1) {
            Message message = selectedMessage.get(0);
            if (message.futureTime > 0) {
                ChatDialogs.showEditFutureMessageDialog(activity, message);
            } else {
                ChatDialogs.showEditMessageDialog(activity, message);
            }
        } else {
            I.toast(Supplier.getString(R.string.something_went_wrong));
        }
        exitSelection();
    }

    public static boolean hadReceivedMessage() {
        for (Message message : selectedMessage) {
            if (message.messageType == MessageEntry.MessageType.RECEIVED || message.messageType == MessageEntry.MessageType.RECEIVED_SMS) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasQuoteMessage() {
        for (Message message : selectedMessage) {
            if (!TextUtils.isEmpty(message.qcid) || "null".equals(message.qcid)) {
                return true;
            }
        }
        return false;
    }

    public static boolean containsSMS() {
        for (Message message : selectedMessage) {
            if (message.content.startsWith(Constants.GROUP_SMS_PREFIX)) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasConfide() {
        for (Message message : selectedMessage) {
            if (message.isConfide) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasFutureMessage() {
        for (Message message : selectedMessage) {
            if (message.futureTime > 0) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasReceivedMessage() {
        for (Message message : selectedMessage) {
            if (message.messageType == MessageEntry.MessageType.RECEIVED || message.messageType == MessageEntry.MessageType.RECEIVED_SMS) {
                return true;
            }
        }
        return false;
    }
}
