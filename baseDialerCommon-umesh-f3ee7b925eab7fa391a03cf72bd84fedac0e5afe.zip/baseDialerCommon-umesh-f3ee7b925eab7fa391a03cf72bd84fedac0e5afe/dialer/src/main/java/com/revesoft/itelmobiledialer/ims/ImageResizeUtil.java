package com.revesoft.itelmobiledialer.ims;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import java.io.IOException;

/**
 * Created by Muhib on 8/13/2015.
 */
public class ImageResizeUtil {


    private static final String TAG = "Mkhan";

    /**
     * @param imagePath   The image File path
     * @param imageWidth  The image width
     * @param imageHeight The image height
     * @return {@code ImageDimension} containing the would be scaled size of the Bitmap
     * @author Muhib
     * This function calculates {@code ImageDimension} which is a convenience class
     * for storing height and width information. The Height and width is also adjusted
     * for rotation that are read from the Exif. This ensures that rotated bitmaps will be displayed
     * correctly
     */
    public static ImageDimension getScaledSizeofBitmap(String imagePath, int imageWidth, int imageHeight) {


        // Read the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        // Determine how much to scale down the image


        int scaleFactor = Math.min(photoW / imageWidth, photoH / imageHeight);


        //we are rounding down the scale factor to the nearest power of 2
        //because that is what will be done when actually resizing the image
        int powerOfTwo = -1;
        while (scaleFactor > 0) {

            powerOfTwo++;
            scaleFactor = scaleFactor >> 1;
        }

        int actualScaleFactor = 1 << powerOfTwo;

        actualScaleFactor = actualScaleFactor < 1 ? 1 : actualScaleFactor;
        Log.d(TAG, "File path " + imagePath + " scale factor " + actualScaleFactor);


        //now check if we need to rotate the picture
        //if 90 or 270 degree rotation is needed then we must interchange height and width
        ImageDimension imageDimension = new ImageDimension();
        int rotationInDegrees = getRotationFromExif(imagePath);
        if (rotationInDegrees == 90 || rotationInDegrees == 270) {

            imageDimension.imageWidth = photoH / actualScaleFactor;
            imageDimension.imageHeight = photoW / actualScaleFactor;
        } else {

            imageDimension.imageWidth = photoW / actualScaleFactor;
            imageDimension.imageHeight = photoH / actualScaleFactor;
        }


        return imageDimension;
    }

    /**
     * @param imageFilePath The complete File path of the Image
     * @return The rotation in degree in multiple of 90
     * @author Muhib
     */
    private static int getRotationFromExif(String imageFilePath) {

        ExifInterface exif;
        try {
            exif = new ExifInterface(imageFilePath);
            int exifOrientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
                return 90;
            } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
                return 180;
            } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
                return 270;
            }
            return 0;
        } catch (IOException e) {
            // TODO Auto-generated catch block

            e.printStackTrace();
            Log.e(TAG, "Exception in reading exif");
            return 0;
        }


    }


    public static ImageDimension getVideoDimensions(String imagePath) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        Bitmap bmp = null;

        ImageDimension imageDimension = new ImageDimension();
        try {
            retriever.setDataSource(imagePath);
            bmp = retriever.getFrameAtTime();
            imageDimension.imageHeight = bmp.getHeight();
            imageDimension.imageWidth = bmp.getWidth();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imageDimension;
    }


    public static ImageDimension getImageDimensions(String imagePath) {
        // Read the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;
        ImageDimension imageDimension = new ImageDimension();
        int rotationInDegrees = getRotationFromExif(imagePath);
        if (rotationInDegrees == 90 || rotationInDegrees == 270) {

            imageDimension.imageWidth = photoH;
            imageDimension.imageHeight = photoW;
        } else {

            imageDimension.imageWidth = photoW;
            imageDimension.imageHeight = photoH;
        }

        return imageDimension;
    }


    @SuppressWarnings("deprecation")
    @SuppressLint("NewApi")
    public static int getDisplayWidth(Context context) {

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();

        int width;

        if (android.os.Build.VERSION.SDK_INT < 13) {
            width = display.getWidth();
        } else {

            Point size = new Point();
            display.getSize(size);

            width = size.x;
        }

        return width;

    }

    public static int getDisplayHeight(Context context) {

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();

        int height;

        if (android.os.Build.VERSION.SDK_INT < 13) {
            height = display.getHeight();
        } else {

            Point size = new Point();
            display.getSize(size);

            height = size.y;
        }

        return height;

    }

    /**
     * This method converts dp unit to equivalent pixels, depending on device density.
     *
     * @param dp      A value in dp (density independent pixels) unit. Which we need to convert into pixels
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent px equivalent to dp depending on device density
     */
    public static int convertDpToPixel(float dp, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        int px = (int) (dp * (metrics.densityDpi / 160f));
        return px;
    }

    /**
     * This method converts device specific pixels to density independent pixels.
     *
     * @param px      A value in px (pixels) unit. Which we need to convert into db
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent dp equivalent to px value
     */
    public static float convertPixelsToDp(float px, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float dp = px / (metrics.densityDpi / 160f);
        return dp;
    }

    public static class ImageDimension {

        public ImageDimension() {
            imageWidth = 0;
            imageHeight = 0;
        }

        public int imageWidth;
        public int imageHeight;

    }


}
