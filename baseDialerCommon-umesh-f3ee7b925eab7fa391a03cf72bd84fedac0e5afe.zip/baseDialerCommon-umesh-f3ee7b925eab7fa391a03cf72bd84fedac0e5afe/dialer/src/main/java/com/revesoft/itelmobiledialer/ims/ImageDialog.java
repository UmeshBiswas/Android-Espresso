package com.revesoft.itelmobiledialer.ims;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;


import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.GenericFileProvider;
import com.revesoft.material.R;
import com.revesoft.itelmobiledialer.util.BaseActivity;

import java.io.File;
import java.net.MalformedURLException;

import uk.co.senab.photoview.PhotoViewAttacher;

public class ImageDialog extends BaseActivity {

    private ImageView mDialog;
    PhotoViewAttacher mAttacher;
    String filePath = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_image_dialog);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            filePath = extras.getString("FILE_PATH");
        }

        mDialog = (ImageView) findViewById(R.id.image_view);
        setImage(filePath, mDialog);
        mDialog.setClickable(true);
        mAttacher = new PhotoViewAttacher(mDialog);
        mAttacher.setAllowParentInterceptOnEdge(true);

        ImageView openWithButton;
        openWithButton = (ImageView) findViewById(R.id.open_with_button);
        openWithButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File file = new File(filePath);
                String fileMimeType = determineFileMimeType(file);
                Log.d("Asif", "File Name " + file.getName() + " Type " + fileMimeType);

                if (fileMimeType != null) {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    String authority = AppContext.getAccess().getContext().getPackageName() + ".my.package.name.provider";
                    Uri fileUri = GenericFileProvider.getUriForFile(AppContext.getAccess().getContext(), authority, file);
                    Log.d("fileUri", "openDocument: fileUri " + fileUri);
                    intent.setDataAndType(fileUri, fileMimeType);
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                    startActivity(intent);
                } else {
                    AlertDialog.Builder bld = new AlertDialog.Builder(ImageDialog.this);
                    bld.setMessage("Can not determine file type").setNeutralButton("OK", null);
                    Log.d("Asif", "Showing alert dialog: " + "can not determine file type");
                    bld.create().show();
                }
            }
        });

        //finish the activity (dismiss the image dialog) if the user clicks
        //anywhere on the image
        mDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private String determineFileMimeType(File file) {
        String mimeType = null;
        try {
            String fileUrl = file.toURI().toURL().toString();
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(fileUrl).toLowerCase();
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
        } catch (MalformedURLException e) {

            Log.e("Mkhan", "Exception in determineFileMimeType");
            e.printStackTrace();
        } catch (NullPointerException e) {

            e.printStackTrace();
            Log.e("Mkhan", "Exception in determineFileMimeType");
        }

        return mimeType;

    }

    public void setImage(String filePath, ImageView imageView) {
        File imgFile = new File(filePath);
        if (imgFile.exists()) {
            Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            imageView.setImageBitmap(myBitmap);
        }
    }

    public void onClose(View view) {
        finish();
    }
}