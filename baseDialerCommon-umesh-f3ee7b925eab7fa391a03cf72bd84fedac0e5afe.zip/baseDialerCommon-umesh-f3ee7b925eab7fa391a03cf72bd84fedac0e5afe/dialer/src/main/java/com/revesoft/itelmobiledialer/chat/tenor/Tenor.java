package com.revesoft.itelmobiledialer.chat.tenor;

/**
 * @author Ifta on 11/1/2017.
 */

public class Tenor {
    public static void initialize(String apiKey){
        TenorDataLoader.getAccess().setApiKey(apiKey);
    }
}
