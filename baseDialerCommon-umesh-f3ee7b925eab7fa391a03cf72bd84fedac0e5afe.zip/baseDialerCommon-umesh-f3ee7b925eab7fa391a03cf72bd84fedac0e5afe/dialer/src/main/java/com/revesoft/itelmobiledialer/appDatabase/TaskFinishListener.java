package com.revesoft.itelmobiledialer.appDatabase;

public interface TaskFinishListener {
    void onTaskFinished();
}
