package com.revesoft.itelmobiledialer.appApi;

import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;

import com.revesoft.api.fileApi.ApiConfig;
import com.revesoft.api.fileApi.HTTPUtil;
import com.revesoft.api.fileApi.InternalResponseClient;
import com.revesoft.api.fileApi.IonRequest;
import com.revesoft.api.fileApi.Nonce;
import com.revesoft.api.fileApi.fileApiInterfaces.ApiResponseListener;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashMap;

/**
 * @author Ifta on 8/29/2017.
 */

public class API {
    private static API api;
    private static Logger logger;
    public static final int CONNECTION_TIMEOUT_IN_MILLS = 30000;
    public static final int READ_TIMEOUT_IN_MILLS = 30000;
    private static String middleUrl;
    private static String baseUrl;
    private static String userName;
    private static String password;
    private static String lastNonce = "";

    private API() {
        logger = new Logger();
    }

    public static API getAccess() {
        if (api == null) {
            synchronized (API.class) {
                if (api == null) {
                    api = new API();
                }
            }

        }
        return api;
    }

    public static void configureWith(ApiConfig config) {
        API.baseUrl = config.getUrl();
        API.userName = config.getUserName();
        API.password = config.getPassword();
        API.middleUrl = config.getMiddleUrl();
    }

    public void makeRequest(final HashMap<String, String> parameter, final ApiResponseListener apiResponseListener) {
        getNounce(parameter, new PrivateListener() {
            @Override
            public void onSuccess(String response) {
                String nonce = parseNonce(response);
                logger.log("nonce = " + nonce);
                parameter.put("nonce", nonce);
                getData(parameter, new PrivateListener() {
                    @Override
                    public void onFailed(String reason) {
                        logger.error(reason);
                        apiResponseListener.onFailed(reason);
                    }

                    @Override
                    public void onSuccess(String response) {
                        apiResponseListener.onSuccess(response);
                        logger.log(response);
                    }
                });
            }

            @Override
            public void onFailed(String reason) {
                apiResponseListener.onFailed(reason);
            }
        });
    }


    public void makeRequest(String route, HashMap<String, String> formDatas, HashMap<String, String> nonceFetchParams, final ApiResponseListener apiResponseListener) {
        makeRequest(route, formDatas, nonceFetchParams, apiResponseListener, 0);
    }

    private void makeRequest(String route, HashMap<String, String> formDatas, HashMap<String, String> nonceFetchParams, final ApiResponseListener apiResponseListener, int tryCount) {
        final String requestUrl = baseUrl + route;
        if (tryCount >= 5) {
            apiResponseListener.onFailed("Nonce cannot be parsed for some reason");
            return;
        }

        if (TextUtils.isEmpty(lastNonce)) {
            Nonce.getNonce(requestUrl, nonceFetchParams, nonce -> {
                if (nonce == null) {
                    apiResponseListener.onFailed("Nonce cannot be fetched. Nonce is null");
                    return;
                }
                lastNonce = nonce;
                makeRequest(route, formDatas, nonceFetchParams, apiResponseListener, 0);
            });
            return;
        }
        addGeneratedFormDatas(formDatas);
        IonRequest.access().makeStringRequest(requestUrl, formDatas, new InternalResponseClient() {
            @Override
            public void onResponse(String response) {
                apiResponseListener.onSuccess(response);
            }


            @Override
            public void onErrorResponse(Exception error) {
                apiResponseListener.onFailed(error.getMessage());
            }

            @Override
            public void needNonceAgain() {
                Nonce.getNonce(requestUrl, nonceFetchParams, nonce -> {
                    if (nonce == null) {
                        apiResponseListener.onFailed("Nonce cannot be fetched. Nonce is null");
                        return;
                    }
                    lastNonce = nonce;
                    makeRequest(route, formDatas, nonceFetchParams, apiResponseListener, tryCount + 1);
                });
            }



        });

    }


    private void addGeneratedFormDatas(HashMap<String, String> formDatas) {
        formDatas.put("username", userName);
        formDatas.put("user", userName);
        formDatas.put("nonce", lastNonce);
        formDatas.put("password", getPassword());
    }

    public void getRate(HashMap<String, String> parameter, ApiResponseListener listener) {
        getRateInTeleport(parameter, new PrivateListener() {
            @Override
            public void onSuccess(String response) {
                listener.onSuccess(response);
            }

            @Override
            public void onFailed(String reason) {
                listener.onFailed(reason);
            }
        });
    }

    private void getRateInTeleport(HashMap<String, String> parameter, PrivateListener listener) {
        String payLoad = "";
        for (String parameterName : parameter.keySet()) {
            String value = parameter.get(parameterName);
            value = value.replaceAll("\\s+", "%20");
            payLoad += ("&" + parameterName + "=" + value);
        }

        String url = baseUrl + "/api/checkRate.jsp?username=" + userName + payLoad;
        logger.log("getData url : " + url);
        HardWorker hardWorker = new HardWorker();
        hardWorker.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new TaskParam(url, listener));
    }


    private String parseNonce(String response) {
        try {
            if (response != null) {
                if (response.contains("nonce")) {
                    return response.substring(response.lastIndexOf("=") + 1);
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }


    private void getNounce(HashMap<String, String> parameter, PrivateListener listener) {
        String payLoad = "";
        for (String parameterName : parameter.keySet()) {
            String value = parameter.get(parameterName);
            value = value.replaceAll("\\s+", "%20");
            payLoad += ("&" + parameterName + "=" + value);
        }
        String url = baseUrl + middleUrl + userName + "&nonce=&password=" + HTTPUtil.getMD5Digest((userName + password)) + payLoad;
        Log.i("Tanvvvv", "getNounce url : " + url);
        HardWorker hardWorker = new HardWorker();
        hardWorker.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new TaskParam(url, listener));
    }

    private void getData(final HashMap<String, String> parameter, PrivateListener listener) {
        String nonce = "";
        String payLoad = "";
        for (String parameterName : parameter.keySet()) {
            if (parameterName.equals("nonce")) {
                nonce = parameter.get(parameterName);
            }
            String value = parameter.get(parameterName);
            value = value.replaceAll("\\s+", "%20");
            payLoad += ("&" + parameterName + "=" + value);
        }
        if (nonce.equals("")) {
            listener.onFailed("Nonce not found");
            return;
        }
        String url = baseUrl + middleUrl + userName + "&password=" + HTTPUtil.getMD5Digest((nonce + userName + password)) + payLoad;
        logger.log("getData url : " + url);
        HardWorker hardWorker = new HardWorker();
        hardWorker.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new TaskParam(url, listener));
    }


    private static class HardWorker extends AsyncTask<TaskParam, Void, Void> {
        @Override
        protected Void doInBackground(TaskParam... params) {
            TaskParam taskParam = params[0];
            if (taskParam == null) {
                return null;
            }
            HttpURLConnection urlConnection = null;
            HTTPUtil.disableConnectionReuseIfNecessary();

            String responseStr = null;
            try {
//                String url = .replaceAll(" ", "%20");
                URL urlToRequest = new URL(taskParam.url);
                logger.log("RequestURI: " + urlToRequest.toString());

                urlConnection = (HttpURLConnection) urlToRequest.openConnection();
                urlConnection.setConnectTimeout(CONNECTION_TIMEOUT_IN_MILLS);
                urlConnection.setReadTimeout(READ_TIMEOUT_IN_MILLS);

                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//                urlConnection.setRequestProperty("Connection", "close");
                urlConnection.setUseCaches(false);

//                urlConnection.connect();
                int statusCode = urlConnection.getResponseCode();
                if (statusCode != HttpURLConnection.HTTP_OK) {
                    logger.error("HTTP status code is not http ok!!!. status code : " + statusCode);
                    taskParam.getPostListener.onFailed("Http error " + statusCode);
                } else {
                    BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    String inputLine;
                    StringBuilder response = new StringBuilder();

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();
                    responseStr = response.toString().trim();
                    logger.log("Response before parsing " + responseStr);
                    taskParam.getPostListener.onSuccess(responseStr);
                }
            } catch (ProtocolException e) {
                e.printStackTrace();
                logger.error(e.getLocalizedMessage());
                taskParam.getPostListener.onFailed(e.getLocalizedMessage());
                return null;
            } catch (Exception e) {
                logger.error(e.getLocalizedMessage());
                taskParam.getPostListener.onFailed(e.getLocalizedMessage());
                e.printStackTrace();
                return null;
            }
            return null;
        }
    }

    private static class TaskParam {
        String url;
        PrivateListener getPostListener;

        TaskParam(String url, PrivateListener getPostListener) {
            this.url = url;
            this.getPostListener = getPostListener;
        }
    }

    private interface PrivateListener {
        void onSuccess(String response);

        void onFailed(String reason);
    }

    private class Logger {
        public void log(String data) {
            if (data != null) {
                Log.i("iftaApiLog", data);
            } else {
                Log.i("iftaApiLog", "no data send on logger");
            }
        }

        public void error(String data) {
            if (data != null) {
                Log.e("iftaApiLog", data);
            } else {
                Log.e("iftaApiLog", "No error message found");
            }
        }
    }

    private String getPassword() {
        String toBeHashed = lastNonce + userName + password;
        //logger.log("getPassword : toBeHashed = " + toBeHashed);
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(toBeHashed.getBytes("UTF-8"));

            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte d : digest) {
                sb.append(Integer.toString((d & 0xff) + 0x100, 16).substring(1));
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }


}
