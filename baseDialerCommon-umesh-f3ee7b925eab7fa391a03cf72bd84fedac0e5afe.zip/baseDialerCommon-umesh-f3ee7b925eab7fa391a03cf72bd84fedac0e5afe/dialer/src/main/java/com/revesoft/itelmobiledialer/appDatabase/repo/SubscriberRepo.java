package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;
import android.util.Log;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Subscriber;
import com.revesoft.itelmobiledialer.e2eencryption.E2EPublicKeySeedAndPrivateKeyHolder;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.List;

public class SubscriberRepo {
    private static final SubscriberRepo ourInstance = new SubscriberRepo();
    public static SubscriberRepo get() {
        return ourInstance;
    }

    private SubscriberRepo() {
    }


    public List<Subscriber> getSubscriber() {
        return AppDatabase.get().subscriberDao().getSubscriber();
    }


    public Subscriber getSubscriberByNumber(String num) {
        return AppDatabase.get().subscriberDao().getSubscriberByNumber(num);
    }


    public void updateE2EPublicKeyAndSeedForBuddy(String buddy, String publicKey, String seed) {
        AppDatabase.get().subscriberDao().updateE2EPublicKeyAndSeedForBuddy(buddy, publicKey, seed);
    }


    public boolean isE2EPublicKeyAndSeedAvailableForBuddy(String buddy) {
        Subscriber subscriber = getSubscriberByNumber(buddy);
        boolean result = subscriber != null;
        result = result && (!subscriber.buddyPublicKey.equals("") && !subscriber.buddySeed.equals(""));
        return result;
    }


    public E2EPublicKeySeedAndPrivateKeyHolder getE2EPublicKeySeedAndPrivateKeyHolderForBuddy(String buddy) {
        E2EPublicKeySeedAndPrivateKeyHolder e2EPublicKeySeedAndPrivateKeyHolder = new E2EPublicKeySeedAndPrivateKeyHolder();

        Subscriber subscriber = getSubscriberByNumber(buddy);
        if (buddy != null) {
            e2EPublicKeySeedAndPrivateKeyHolder.publicKey = subscriber.buddyPublicKey.equals("") ? null : subscriber.buddyPublicKey;
            e2EPublicKeySeedAndPrivateKeyHolder.seed = subscriber.buddySeed.equals("") ? null : subscriber.buddySeed;
        }
        return e2EPublicKeySeedAndPrivateKeyHolder;
    }


    public boolean checkForSubscriber(String number) {
        Subscriber subscriber = getSubscriberByNumber("%" + Util.removePrefixes(number));
        return subscriber != null;
    }


    public void deleteSubscriberHash(String number) {
        AppDatabase.get().subscriberDao().deleteSubscriberHash(number);
    }


    public String getSubscriberHash(String number) {
        return AppDatabase.get().subscriberDao().getSubscriberHash(number);
    }


    public boolean isSubscriber(String number) {
        return getSubscriberByNumber(number) != null;
    }

    public List<String> isSubscriber(List<String> numberList) {
        return AppDatabase.get().subscriberDao().isSubscriber(numberList);
    }


    public boolean isSubscriber(String nonTranslatedNumber, int countryCode) {
        String translatedNumber = Util.translateNumber(nonTranslatedNumber, countryCode);
        return isSubscriber(nonTranslatedNumber) || isSubscriber(translatedNumber);
    }


    public boolean createSubscriber(String number) {
        try {
            ContactEngine.createSubscriberLookup(AppContext.getAccess().getContext(), number);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (isSubscriber(number)) {
            Log.d("DatabaseConstants", "got Subscriber: returning...");
            return false;
        }
        try {
            String name = ContactRepo.get().getNameByNumber(number);
            Subscriber subscriber = Subscriber.newBuilder()
                    .number(number)
                    .name(name == null ? "" : name)
                    .presenceNote("")
                    .lookUpKey(ContactRepo.get().lookUpKeyByProcessedNumber(number))
                    .build();
            AppDatabase.get().subscriberDao().insert(subscriber);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            Log.d("DatabaseConstants", "CreateSubscriber: ", e);

            return false;
        }
    }


    public void deleteSubscriberByNumber(String number) {
        AppDatabase.get().subscriberDao().deleteSubscriberByNumber(number);
    }


    public void updateSubscriber(String number, int state, String note, Long lastOnline) {
        AppDatabase.get().subscriberDao().updateSubscriber(number, state, note, lastOnline);
    }

    public void updateSubscriber(String number, int state, Long lastOnline) {
        AppDatabase.get().subscriberDao().updateSubscriber(number, state, lastOnline);
    }


    public void updateSubscriber(String number, String lookUpKey, String subscriberPicHash) {
        AppDatabase.get().subscriberDao().updateSubscriber(number, lookUpKey, subscriberPicHash);
    }

    public void updateSubscriber(String number, String subscriberPicHash) {
        String lookUp = ContactRepo.get().lookUpKeyByProcessedNumber(number);
        updateSubscriber(number, lookUp, subscriberPicHash);
    }


    public void updateSubscriber(String number, int id, String lookUp, String subscriberPicHash) {
        AppDatabase.get().subscriberDao().updateSubscriber(number, id, lookUp, subscriberPicHash);
    }


    public void checkValidityOfSubscriberNames() {
        List<Subscriber> subscriberList = getSubscriber();
        for (Subscriber subscriber : subscriberList) {
            String number = subscriber.number;
            String name = subscriber.name;
            String contactName = ContactRepo.get().getNameByNumber(number);
            if (name == null || name.equalsIgnoreCase(contactName)) {
                String lookUpKey = ContactRepo.get().lookUpKeyByProcessedNumber(number);
                AppDatabase.get().subscriberDao().updateSubscriberName(number, contactName, lookUpKey);
            }
        }
    }


    public void deleteAllSubscribers() {
        SubscriberLookUpRepo.get().deleteAllSubscribers();
        AppDatabase.get().subscriberDao()._deleteAllSubscribers();
    }


    public void deleteSubscriber(String number) {
        SubscriberLookUpRepo.get().deleteSubscriberLookup(number);
        AppDatabase.get().subscriberDao()._deleteSubscriber(number);
    }


    public String presenceNoteByNumber(String number) {
        return AppDatabase.get().subscriberDao().presenceNoteByNumber(number);
    }


    public boolean checkForSubscriberNumberAndKey(String number) {
        String key = ContactEngine.getContactLookupKey(AppContext.getAccess().getContext(), Util.removePrefixes(number));
        return AppDatabase.get().subscriberDao().checkForSubscriberNumberAndKey("%" + number, key) != null;

    }


    public String getSubscribedNumber(String number) {
        String key = ContactEngine.getContactLookupKey(AppContext.getAccess().getContext(), Util.removePrefixes(number));
        return AppDatabase.get().subscriberDao().checkForSubscriberNumberAndKey("%" + number, key).number;
    }


    public void resetSubscriber() {
        AppDatabase.get().subscriberDao().resetSubscriber();
    }


    public Cursor getSubscriberCursor() {
        return AppDatabase.get().subscriberDao().getSubscriberCursor();
    }


    public Cursor searchSubscriberCursor(String searchItem) {
        return AppDatabase.get().subscriberDao()._searchSubscriberCursor("%" + searchItem + "%");

    }


    public List<String> getSubscriberNumbers() {
        return AppDatabase.get().subscriberDao().getSubscriberNumbers();
    }


    public List<Subscriber> getSubscribersHavingSpecifiedNumbers(String[] subscriberNumbers) {
        return AppDatabase.get().subscriberDao().getSubscribersHavingSpecifiedNumbers(subscriberNumbers);
    }


    public Cursor getSubscribersExcludingSpecifiedNumbers(String[] subscriberNumbers) {
        return AppDatabase.get().subscriberDao().getSubscribersExcludingSpecifiedNumbers(subscriberNumbers);
    }


//TODO Have to find Solutions here//

    //    @Query("SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//            " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//            " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number AND s.buddy_public_key <> '' AND s.buddy_seed <> '' ) as temp " +
//            " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC")
//    Cursor getE2ESubscriber();
    public Cursor getE2ESubscriber() {
        return null;
    }


//TODO Error Here in Query//

//    @Query("SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//            " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//            " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number AND s.buddy_public_key <> '' AND s.buddy_seed <> '') as temp " +
//            " WHERE temp.name LIKE  OR temp.subscribed_number LIKE :searchStr" +
//            " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC")
//    Cursor _getE2ESubscriberSearch(String searchStr);

    public Cursor getE2ESubscriberSearch(String searchStr) {
        return null;
//        return _getE2ESubscriberSearch("%"+searchStr+"%");
    }

//    @Query("SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//            " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//            " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number) as temp " +
//            " WHERE temp.name LIKE :searchStr OR temp.subscribed_number LIKE :searchStr " +
////					"AND temp.name<>'' and temp.name not null" +
////					" GROUP BY temp.subscribed_number ORDER BY temp.presencestate ASC, temp.name COLLATE LOCALIZED ASC";
//            " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC")
//    Cursor _getSubscriberSearch(String searchStr);


    public Cursor getSubscriberSearch(String searchStr) {
        return null;
//        return _getSubscriberSearch("%"+searchStr+"%");
    }


    public Cursor getNonSubscriberContacts() {
        return AppDatabase.get().subscriberDao().getNonSubscriberContacts();
    }


    public Cursor getNonSubscriberContacts(String searchStr) {
        return AppDatabase.get().subscriberDao()._getNonSubscriberContacts(searchStr);
    }


    public String getPresenceNote(String number) {
        return AppDatabase.get().subscriberDao().getPresenceNote(number);
    }
}
