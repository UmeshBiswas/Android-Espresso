package com.revesoft.itelmobiledialer.chat.chatWindow.supportiveActivities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.revesoft.itelmobiledialer.Config.Features;
import com.revesoft.itelmobiledialer.chat.chatWindow.futureMessage.FutureMessageTimeDialogs;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.ContactSelector;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.FutureMessageDateTimeListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageQuoteInfo;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.phonebook.Contact;
import com.revesoft.itelmobiledialer.service.contactmanager.ContactManagerServiceContact;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.parameter.ImageType;
import ezvcard.property.Photo;

/**
 * @author Ifta on 12/31/2017.
 */

public class ContactShareActivity extends BaseActivity implements ContactSelector {
    RecyclerView rvSelectedContacts;
    SelectedContactsAdapter selectedContactsAdapter;
    ArrayList<Contact> selectedContacts = new ArrayList<>();
    ImageView ivSend;
    ImageView ivSendInFuture;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_share_activity_layout);

        startService(new Intent(ContactShareActivity.this, ContactManagerServiceContact.class));
//        getSupportFragmentManager().beginTransaction()
//                .add(R.id.contactListHolder, ContactPickerFragment.newInstance(ContactType.ALL
//                ))
//                .commit();
        rvSelectedContacts = findViewById(R.id.rvSelectedContacts);
        selectedContactsAdapter = new SelectedContactsAdapter();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ContactShareActivity.this, LinearLayoutManager.HORIZONTAL, false);
        rvSelectedContacts.setLayoutManager(linearLayoutManager);
        rvSelectedContacts.setAdapter(selectedContactsAdapter);
        ivSend = findViewById(R.id.ivSend);
        ivSendInFuture = findViewById(R.id.ivSendInFuture);
        if (!Features.hasFutureMessage()) {
            ivSendInFuture.setVisibility(View.GONE);
        }
        ivSend.animate().scaleX(0).scaleY(0).setDuration(1).start();
        ivSendInFuture.animate().scaleX(0).scaleY(0).setDuration(1).start();
        ivSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                processSending(false);

            }
        });
        ivSendInFuture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processSending(true);
            }
        });
    }

    private void processSending(final boolean shouldSendAsFutureMessage) {
        for (final Contact contact : selectedContacts) {
            final VCard vCard = new VCard();
            vCard.setFormattedName(contact.name);
            if (Util.isValidEmail(Util.getProperEmail(contact.phoneNumberOrEmail))) {
                vCard.addEmail(Util.getProperEmail(contact.phoneNumberOrEmail));
            } else {
                vCard.addTelephoneNumber(Util.getProperEmail(contact.phoneNumberOrEmail));
            }
            if (!TextUtils.isEmpty(contact.photoUri)) {
                final ProgressDialog progressDialog = new ProgressDialog(ContactShareActivity.this);
                progressDialog.setMessage(getString(R.string.please_wait));
                progressDialog.setCancelable(false);
                progressDialog.show();

                Glide.with(ContactShareActivity.this)
                        .load(contact.photoUri)
                        .asBitmap()
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .dontAnimate()
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onLoadFailed(Exception e, Drawable errorDrawable) {
                                progressDialog.dismiss();
                                sendContact(shouldSendAsFutureMessage, vCard, contact);
                            }

                            @Override
                            public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                                if (resource != null) {
                                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                                    resource.compress(Bitmap.CompressFormat.PNG, 100, stream);
                                    byte[] byteArray = stream.toByteArray();
                                    vCard.addPhoto(new Photo(byteArray, ImageType.JPEG));
                                    progressDialog.dismiss();
                                    sendContact(shouldSendAsFutureMessage, vCard, contact);
                                }
                            }
                        });
            } else {
                sendContact(shouldSendAsFutureMessage, vCard, contact);
            }
        }
    }

    private static final String CONTACT_DIRECTORY = "/BubbleToneMedia";

    private void sendContact(boolean shouldSendAsFutureMessage, VCard vCard, Contact contact) {
        File parent = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + CONTACT_DIRECTORY);
        if (!parent.exists()) {
            parent.mkdir();
        }
        try {
            final File contactFile = new File(parent, contact.phoneNumberOrEmail + ".vcf");
            Ezvcard.write(vCard).go(contactFile);
            if (shouldSendAsFutureMessage) {
                FutureMessageTimeDialogs.showDateTimePicker(new FutureMessageDateTimeListener() {
                    @Override
                    public void onDateTimePicked(Date formattedDateTime, boolean sendCurrentTimeStamp) {
                        Sender.getAccess().sendFutureFile(contactFile.getAbsolutePath(), formattedDateTime.getTime(), sendCurrentTimeStamp);
                    }
                });
            } else {
                Sender.getAccess().sendFile(contactFile.getAbsolutePath());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        finish();
    }

    @Override
    public void onContactClick(Contact contact) {
        if (selectedContacts.contains(contact)) {
            selectedContacts.remove(contact);
            if (selectedContacts.size() == 0) {
                rvSelectedContacts.setVisibility(View.GONE);
                ivSend.animate().scaleX(0).scaleY(0).setDuration(250).start();
                ivSendInFuture.animate().scaleX(0).scaleY(0).setDuration(250).start();
            }
        } else {
            selectedContacts.add(contact);
            rvSelectedContacts.setVisibility(View.VISIBLE);
            ivSend.animate().scaleX(1).scaleY(1).setDuration(250).start();
            if (MessageQuoteInfo.isInQuoteMode) {
                ivSendInFuture.animate().scaleX(0).scaleY(0).setDuration(250).start();
            } else {
                ivSendInFuture.animate().scaleX(1).scaleY(1).setDuration(250).start();
            }
        }
        selectedContactsAdapter.notifyDataSetChanged();
    }

    @Override
    public ArrayList<Contact> getSelectedContacts() {
        return selectedContacts;
    }

    private class SelectedContactsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_picker_single_contact, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof ViewHolder) {
                ((ViewHolder) holder).bindView(position);
            }
        }

        @Override
        public int getItemCount() {
            return selectedContacts.size();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivContactImage;

            public ViewHolder(View itemView) {
                super(itemView);
                ivContactImage = (ImageView) itemView.findViewById(R.id.ivContactImage);
            }

            public void bindView(int position) {
                if (selectedContacts.size() > 0) {
                    Contact contact = selectedContacts.get(position);
                    if (contact != null) {
                        String contactImagePath = ProfilePictureDataProvider.getProfilePicturePath(contact.processedNumber);
                        ImageUtil.setImageButDefaultOnException(ContactShareActivity.this, contactImagePath, ivContactImage, R.drawable.person_icon);
                    }
                }
            }
        }
    }
}
