package com.revesoft.itelmobiledialer.account;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.block.BlockedContactActivity;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.privacy.PrivacyHelperDataHook;
import com.revesoft.itelmobiledialer.privacy.PrivacyModuleManager;
import com.revesoft.itelmobiledialer.privacy.PrivacyStates;
import com.revesoft.itelmobiledialer.privacy.ProfilePicturePrivacyController;
import com.revesoft.itelmobiledialer.privacy.ProfileStatusPrivacyController;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import java.util.ArrayList;

/**
 * @author Ifta on 5/21/2017.
 */
public class AccountPrivacyActivity extends BaseActivity {
    Context context;
    Toolbar toolbar;
    TextView tvProfilePhotoPrivacyPreference;
    TextView tvStatusPrivacyPreference;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_privacy_activity_layout);
        setupPrivacyModuleController();
        context = this;
        handleToolbar();
        initViews();
        updateViewData();
    }

    private void setupPrivacyModuleController() {
        PrivacyModuleManager.configurator()
                .withIsEnabledModule(true)
                .withPrivacyHelperDataHook(new PrivacyHelperDataHook() {
                    @Override
                    public ArrayList<String> getSubscriberNumbers() {
                        return new ArrayList<>(CommonData.subscriberPhoneNumberToLookUpKeyOnlyContact.keySet());
                    }

                    @Override
                    public String getUserName() {
                        return UserDataManager.getUserName();
                    }

                    @Override
                    public String getUserPassword() {
                        return UserDataManager.getUserPassword();
                    }
                }).configure();
    }

    public static String getPrivacyState(Resources resources, PrivacyStates states) {
        return PrivacyStatesStringProvider.getStringByValue(resources, states);
    }

    private void updateViewData() {
        String profilePicturePrivacy = getPrivacyState(getResources(), AccountPreference.getPrivacy(AccountPreference.Keys.PROFILE_PICTURE_PRIVACY));
        tvProfilePhotoPrivacyPreference.setText(profilePicturePrivacy);
        String statusPrivacy = getPrivacyState(getResources(), AccountPreference.getPrivacy(AccountPreference.Keys.STATUS_PRIVACY));
        tvStatusPrivacyPreference.setText(statusPrivacy);
    }

    private void initViews() {
        tvStatusPrivacyPreference = (TextView) findViewById(R.id.tvStatusPrivacyPreference);
        tvProfilePhotoPrivacyPreference = (TextView) findViewById(R.id.tvProfilePhotoPrivacyPreference);
    }

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.blockedContacts));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(getString(R.string.accountPrivacy));
        }
    }

    public void handleProfilePicturePrivacy(View view) {
        showPrivacyStateDialogFor(getString(R.string.profilePhoto), AccountPreference.Keys.PROFILE_PICTURE_PRIVACY);
    }

    public void handleStatusPrivacy(View view) {
        showPrivacyStateDialogFor(getString(R.string.status), AccountPreference.Keys.STATUS_PRIVACY);
    }

    private void showPrivacyStateDialogFor(String title, final String preferenceKey) {
        String[] items = PrivacyStatesStringProvider.getStates(getResources());
        AlertDialog.Builder builder = new AlertDialog.Builder(AccountPrivacyActivity.this);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                AccountPreference.put(preferenceKey, which);
                if (preferenceKey.equals(AccountPreference.Keys.PROFILE_PICTURE_PRIVACY)) {
                    AccountPreference.put(AccountPreference.Keys.KEY_SENDING_CHANGE_REQUEST_FOR, AccountPreference.Constants.PROFILE_PICTURE_PRIVACY_REQUEST_CODE);
                    ProfilePicturePrivacyController.changePrivacy();
                } else if (preferenceKey.equals(AccountPreference.Keys.STATUS_PRIVACY)) {
                    AccountPreference.put(AccountPreference.Keys.KEY_SENDING_CHANGE_REQUEST_FOR, AccountPreference.Constants.PROFILE_STATUS_PRIVACY_REQUEST_CODE);
                    ProfileStatusPrivacyController.changePrivacy();
                }
                updateViewData();
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    public void showBlockedContacts(View view) {
        Intent intent = new Intent(AccountPrivacyActivity.this, BlockedContactActivity.class);
        startActivity(intent);
    }
}
