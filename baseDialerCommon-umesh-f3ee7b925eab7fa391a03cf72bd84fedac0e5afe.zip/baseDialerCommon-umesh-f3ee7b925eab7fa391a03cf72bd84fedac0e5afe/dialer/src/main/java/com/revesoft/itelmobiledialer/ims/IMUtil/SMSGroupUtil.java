package com.revesoft.itelmobiledialer.ims.IMUtil;

import android.content.Context;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.data.NameResolver;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.ArrayList;

/**
 * Created by Acer on 4/5/2017.
 */

public class SMSGroupUtil {

    public void createSMSGroup(Context context, String[]numbers, String username, String groupName, int TYPE, String groupId)
    {
//        DatabaseConstants dataHelper = DatabaseConstants.getInstance();
       ArrayList<String> list=new ArrayList<>();
        for(int i=0;i<numbers.length;i++)
        {
            list.add(numbers[i]);
        }
        Executor.ex(()->{
            GroupRepo.get().createSMSGroup(groupName, Util.join(";", numbers), list, groupId);
            MessageRepo.get().createSystemMessage(System.currentTimeMillis() + "group_sms_chat", groupId,
                    groupInfoMessage(context,groupId), 0,System.currentTimeMillis());
        });

    }
    public String generateGroupID()
    {
        return System.currentTimeMillis()+"groupsmschat";
    }
    private String groupInfoMessage(Context context, String groupID)
    {
//        DatabaseConstants dataHelper=DatabaseConstants.getInstance(context);
        String message="";
        String[] groupMembers = GroupRepo.get().getGroupNumbers(groupID);
        if(groupMembers!=null && groupMembers.length>0)
        {
            if(groupMembers.length==1)
            {
                String name= ContactEngine.getContactNamefromNumber(context,groupMembers[0]);
                if(name == null || name.length()==0)
                    name=groupMembers[0];
                message=context.getString(R.string.you_have_added)+" "+ NameResolver.getContactNameFromNumberOrEmail(name) + " "+context.getString(R.string.to_this_group);
            }
            else
            {
                message=context.getString(R.string.you_have_added)+" ";
                int len=groupMembers.length;
                for(int i=0;i<len-1;i++)
                {
                    String name=ContactEngine.getContactNamefromNumber(context,groupMembers[i]);
                    if(name == null || name.length()==0)
                        name=groupMembers[i];
                    if(i==0)
                        message+=name;
                    else
                        message+=", "+name;
                }
                String name=ContactEngine.getContactNamefromNumber(context,groupMembers[len-1]);
                if(name == null || name.length()==0)
                    name=groupMembers[len-1];
                message+=" "+context.getString(R.string.and)+" "+name+" "+context.getString(R.string.to_this_group);

            }

        }
        return  message;
    }
}
