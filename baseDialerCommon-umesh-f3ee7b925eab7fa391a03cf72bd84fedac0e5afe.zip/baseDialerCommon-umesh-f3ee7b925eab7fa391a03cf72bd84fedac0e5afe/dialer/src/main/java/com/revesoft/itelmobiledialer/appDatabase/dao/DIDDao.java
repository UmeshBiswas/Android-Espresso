package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.DID;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface DIDDao extends BaseDao<DID> {
    @Query("SELECT * from did_table")
    List<DID> getAll();

    @Query("SELECT * from did_table")
    Cursor getUserDIDsCursor();
}
