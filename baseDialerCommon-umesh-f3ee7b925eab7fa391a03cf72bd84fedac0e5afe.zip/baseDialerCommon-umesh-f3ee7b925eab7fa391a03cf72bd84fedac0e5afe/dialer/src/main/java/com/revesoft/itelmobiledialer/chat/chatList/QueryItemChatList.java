package com.revesoft.itelmobiledialer.chat.chatList;

public class QueryItemChatList {
    String groupid;
    String number;
    String mime_type;
    String messagecontent;
    String callerid;
    int messagetype;
    int deliverystatus;
    long received;

    long date;
    int unread_count;
    int message_count;
    String name;
    long display_time;
    String long_message;
    String filepath;

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setMime_type(String mime_type) {
        this.mime_type = mime_type;
    }

    public void setMessagecontent(String messagecontent) {
        this.messagecontent = messagecontent;
    }

    public void setCallerid(String callerid) {
        this.callerid = callerid;
    }

    public void setMessagetype(int messagetype) {
        this.messagetype = messagetype;
    }

    public void setDeliverystatus(int deliverystatus) {
        this.deliverystatus = deliverystatus;
    }

    public void setReceived(long received) {
        this.received = received;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public void setUnread_count(int unread_count) {
        this.unread_count = unread_count;
    }

    public void setMessage_count(int message_count) {
        this.message_count = message_count;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDisplay_time(long display_time) {
        this.display_time = display_time;
    }

    public void setLong_message(String long_message) {
        this.long_message = long_message;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getGroupid() {
        return groupid;
    }

    public String getNumber() {
        return number;
    }

    public String getMime_type() {
        return mime_type;
    }

    public String getMessagecontent() {
        return messagecontent;
    }

    public String getCallerid() {
        return callerid;
    }

    public int getMessagetype() {
        return messagetype;
    }

    public int getDeliverystatus() {
        return deliverystatus;
    }

    public long getReceived() {
        return received;
    }

    public long getDate() {
        return date;
    }

    public int getUnread_count() {
        return unread_count;
    }

    public int getMessage_count() {
        return message_count;
    }

    public String getName() {
        return name;
    }

    public long getDisplay_time() {
        return display_time;
    }

    public String getLong_message() {
        return long_message;
    }

    public String getFilepath() {
        return filepath;
    }
}
