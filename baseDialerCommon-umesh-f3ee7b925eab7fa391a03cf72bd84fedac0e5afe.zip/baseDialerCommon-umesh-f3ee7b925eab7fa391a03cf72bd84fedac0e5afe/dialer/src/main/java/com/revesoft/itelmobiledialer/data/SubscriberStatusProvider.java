package com.revesoft.itelmobiledialer.data;

import android.content.Context;

import com.revesoft.itelmobiledialer.appDatabase.entities.Subscriber;
import com.revesoft.itelmobiledialer.appDatabase.repo.SubscriberRepo;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.signalling.data.PresenceState;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.material.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;


/**
 * @author Ifta
 */

public class SubscriberStatusProvider {




    public static boolean isSubscriber(String processedNumber){
        return CommonData.subscriberPhoneNumberToLookUpKey.containsKey(processedNumber);
    }
    public static boolean isOnline(String phoneNo) {
        return SIPProvider.statusMap.containsKey(phoneNo) && !(SIPProvider.statusMap.get(phoneNo) == PresenceState.Offline);
    }

    public static PresenceState getPresenceStatus(String phoneNo) {
        if(SIPProvider.statusMap.containsKey(phoneNo)) {
            return SIPProvider.statusMap.get(phoneNo);
        }
        return PresenceState.Offline;
    }

    public static String getLastOnlineTime(Context activity, String phoneNo) {
        List<Subscriber> subscriberList = SubscriberRepo.get().getSubscribersHavingSpecifiedNumbers(new String[]{phoneNo});
        if(subscriberList!=null && subscriberList.size()>0) {

            long time = subscriberList.get(0).lastOnlineTime.getTime();
            if (time == 0) return "Offline";
            Calendar lastTime = Calendar.getInstance();
            lastTime.setTimeInMillis(time);

            Calendar now = Calendar.getInstance();

            final String timeFormatString = "HH:mm";

            if (now.get(Calendar.DATE) == lastTime.get(Calendar.DATE) && now.get(Calendar.MONTH) == lastTime.get(Calendar.MONTH) && now.get(Calendar.YEAR) == lastTime.get(Calendar.YEAR)) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(timeFormatString, activity.getResources().getConfiguration().locale);
                return activity.getString(R.string.lastOnline)+" "+activity.getString(R.string.today_at_) + simpleDateFormat.format(time);
            } else if (now.get(Calendar.DATE) - lastTime.get(Calendar.DATE) == 1 && now.get(Calendar.MONTH) == lastTime.get(Calendar.MONTH) && now.get(Calendar.YEAR) == lastTime.get(Calendar.YEAR) ){
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(timeFormatString, activity.getResources().getConfiguration().locale);
                return activity.getString(R.string.lastOnline)+" "+activity.getString(R.string.yesterday_at_) + simpleDateFormat.format(time);
            } else if (now.get(Calendar.YEAR) == lastTime.get(Calendar.YEAR)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd", activity.getResources().getConfiguration().locale);
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", activity.getResources().getConfiguration().locale);
                return activity.getString(R.string.lastOnline)+" "+dateFormat.format(time) + activity.getString(R.string._at_) + timeFormat.format(time);
            } else {
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy", activity.getResources().getConfiguration().locale);
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", activity.getResources().getConfiguration().locale);
                return activity.getString(R.string.lastOnline)+" "+dateFormat.format(time) + activity.getString(R.string._at_) + timeFormat.format(time);
            }
        }
        return null;
    }

    public static String convertToLastOnlineTime(long time) {
        if (time == 0) return "Offline";
        Context context = AppContext.getAccess().getContext();
        Calendar lastTime = Calendar.getInstance();
        lastTime.setTimeInMillis(time);

        Calendar now = Calendar.getInstance();

        final String timeFormatString = "HH:mm";

        if (now.get(Calendar.DATE) == lastTime.get(Calendar.DATE) && now.get(Calendar.MONTH) == lastTime.get(Calendar.MONTH) && now.get(Calendar.YEAR) == lastTime.get(Calendar.YEAR)) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(timeFormatString, context.getResources().getConfiguration().locale);
            return context.getString(R.string.lastOnline) + " " + context.getString(R.string.today_at_) + simpleDateFormat.format(time);
        } else if (now.get(Calendar.DATE) - lastTime.get(Calendar.DATE) == 1 && now.get(Calendar.MONTH) == lastTime.get(Calendar.MONTH) && now.get(Calendar.YEAR) == lastTime.get(Calendar.YEAR)) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(timeFormatString, context.getResources().getConfiguration().locale);
            return context.getString(R.string.lastOnline) + " " + context.getString(R.string.yesterday_at_) + simpleDateFormat.format(time);
        } else if (now.get(Calendar.YEAR) == lastTime.get(Calendar.YEAR)) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd", context.getResources().getConfiguration().locale);
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", context.getResources().getConfiguration().locale);
            return context.getString(R.string.lastOnline) + " " + dateFormat.format(time) + context.getString(R.string._at_) + timeFormat.format(time);
        } else {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy", context.getResources().getConfiguration().locale);
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", context.getResources().getConfiguration().locale);
            return context.getString(R.string.lastOnline) + " " + dateFormat.format(time) + context.getString(R.string._at_) + timeFormat.format(time);
        }
    }
}
