package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.GroupMessageEligible;

import java.util.List;

public class GroupMessageEligibleRepo {
    private static final GroupMessageEligibleRepo ourInstance = new GroupMessageEligibleRepo();

    public static GroupMessageEligibleRepo get() {
        return ourInstance;
    }

    private GroupMessageEligibleRepo() {
    }


    public List<GroupMessageEligible> getAll() {
        return AppDatabase.get().groupMessageEligibleDao().getAll();
    }

    public void insertAll(List<GroupMessageEligible> groupMessageEligibleList) {
        AppDatabase.get().groupMessageEligibleDao().insertAll(groupMessageEligibleList);
    }



    public int eligiblePersonCountByCallId(String callId) {
        return AppDatabase.get().groupMessageEligibleDao().eligiblePersonCountByCallId(callId);
    }


    public boolean checkIfDataExists(String groupId, String callerId, int memberCount) {
        return AppDatabase.get().groupMessageEligibleDao().checkIfDataExists(groupId, callerId, memberCount);
    }

    public void createSingleEntry(String groupId, String callerId, int memberCount) {
        if (AppDatabase.get().groupMessageEligibleDao().checkIfDataExists(groupId, callerId, memberCount)) {
            GroupMessageEligible groupMessageEligible = new GroupMessageEligible();
            groupMessageEligible.groupId = groupId;
            groupMessageEligible.callId = callerId;
            groupMessageEligible.eligibleCount = memberCount;
            AppDatabase.get().groupMessageEligibleDao().insert(groupMessageEligible);
        }
    }
}
