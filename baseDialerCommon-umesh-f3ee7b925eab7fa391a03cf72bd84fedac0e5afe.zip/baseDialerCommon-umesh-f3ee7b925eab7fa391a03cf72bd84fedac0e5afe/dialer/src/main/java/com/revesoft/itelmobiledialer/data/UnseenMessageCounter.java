package com.revesoft.itelmobiledialer.data;

import android.content.Context;
import android.content.Intent;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.revesoft.itelmobiledialer.util.Constants;

/**
 * @author Ifta
 */

public class UnseenMessageCounter {
    private static LocalBroadcastManager localBroadcastManager = null;

    public static void register(Context context) {
        localBroadcastManager = LocalBroadcastManager.getInstance(context);
    }

    public static void sendSignalToDashBoard() {
        Intent intent = new Intent(Constants.DASHBOARD_INTENT_FILTER);
        intent.putExtra(Constants.Broadcast.TYPE_UNSEEN_IMS_COUNT_SIGNAL, true);
        localBroadcastManager.sendBroadcast(intent);
    }
}
