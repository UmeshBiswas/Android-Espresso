package com.revesoft.itelmobiledialer.data;

import android.content.Context;
import android.content.Intent;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.revesoft.itelmobiledialer.util.Constants;

/**
 * @author Ifta
 */

public class MissedCallCounter {
    private static LocalBroadcastManager localBroadcastManager = null;

    public static void register(Context context) {
        localBroadcastManager = LocalBroadcastManager.getInstance(context);
    }

    private static final String KEY_MISSED_CALL_COUNT = "KEY_MISSED_CALL_COUNT";

    public static void incrementCount() {
        int currentCount = PreferenceDataManager.quickGet(KEY_MISSED_CALL_COUNT, 0);
        currentCount++;
        PreferenceDataManager.quickPut(KEY_MISSED_CALL_COUNT, currentCount);
    }

    public static void sendSignalToDashBoard() {
        Intent intent = new Intent(Constants.DASHBOARD_INTENT_FILTER);
        intent.putExtra(Constants.Broadcast.TYPE_MISSED_CALL_COUNT_SIGNAL, getMissedCallCount());
        localBroadcastManager.sendBroadcast(intent);
    }

    public static void clearCount() {
        PreferenceDataManager.quickPut(KEY_MISSED_CALL_COUNT, 0);
    }

    public static int getMissedCallCount() {
        return PreferenceDataManager.quickGet(KEY_MISSED_CALL_COUNT, 0);
    }

}
