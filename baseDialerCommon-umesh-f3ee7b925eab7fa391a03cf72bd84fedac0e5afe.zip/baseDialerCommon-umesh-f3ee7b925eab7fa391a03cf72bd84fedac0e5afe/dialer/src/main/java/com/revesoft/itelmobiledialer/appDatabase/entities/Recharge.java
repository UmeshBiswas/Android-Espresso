/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 11:06 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 11:03 AM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "recharge_table")
public class Recharge {
    @NonNull
    @PrimaryKey(autoGenerate = true)
    public int _id;

    @NonNull
    public String amount = "";

    @NonNull
    @ColumnInfo(name = "currency_code")
    public String currencyCode = "";

    @NonNull
    @ColumnInfo(name = "transaction_id")
    public String transactionId = "";

    @NonNull
    @ColumnInfo(name = "payment_method")
    public String paymentMethod = "";

    public int status = 0;

    @NonNull
    @ColumnInfo(name = "refund_text")
    public String refundText = "";


    public Recharge(@NonNull String amount, @NonNull String currencyCode, @NonNull String transactionId, @NonNull String paymentMethod, int status) {
        this.amount = amount;
        this.currencyCode = currencyCode;
        this.transactionId = transactionId;
        this.paymentMethod = paymentMethod;
        this.status = status;

    }

    private Recharge(Builder builder) {
        _id = builder._id;
        amount = builder.amount;
        currencyCode = builder.currencyCode;
        transactionId = builder.transactionId;
        paymentMethod = builder.paymentMethod;
        status = builder.status;
        refundText = builder.refundText;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private int _id;
        private String amount;
        private String currencyCode;
        private String transactionId;
        private String paymentMethod;
        private int status;
        private String refundText;

        private Builder() {
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withAmount(String val) {
            amount = val;
            return this;
        }

        public Builder withCurrencyCode(String val) {
            currencyCode = val;
            return this;
        }

        public Builder withTransactionId(String val) {
            transactionId = val;
            return this;
        }

        public Builder withPaymentMethod(String val) {
            paymentMethod = val;
            return this;
        }

        public Builder withStatus(int val) {
            status = val;
            return this;
        }

        public Builder withRefundText(String val) {
            refundText = val;
            return this;
        }

        public Recharge build() {
            return new Recharge(this);
        }
    }
}

