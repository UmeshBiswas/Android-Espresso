package com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;

/**
 * Listener of loading {@link Drawable} task is completed
 */
public interface IDrawableLoaderTaskListener<T extends ImageView, R extends Drawable> {
    /**
     * Load task success case
     */
    void success(@NonNull T target, @NonNull R taskResult);

    /**
     * Load task fail case
     */
    void failure(@NonNull T target, @NonNull R errorResult);
}
