package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.Block;

import java.util.HashSet;
import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface BlockDao extends BaseDao<Block>{

    @Query("select count(*) from block where number=:translatedKeyNumber")
    boolean isBlockedContact(String translatedKeyNumber);


    @Query("SELECT number from block")
    List<String> getAllBlockedNumbers();


    @Query("SELECT * FROM BLOCK")
    List<Block> getAllBlockContact();


    @Query("SELECT COUNT(*) FROM BLOCK")
    int getBlockContactCount();



    @Query("DELETE FROM BLOCK WHERE number NOT IN (:blockedContacts)")
    void deleteBlockContactsNotINMap(HashSet<String> blockedContacts);





    @Query("SELECT * FROM" +
                " (SELECT BLOCK._id, BLOCK.number,CONTACTS.name,CONTACTS.processed_number,CONTACTS.contact_id," +
                "CONTACTS.photo_uri,CONTACTS.lookup_key FROM BLOCK LEFT JOIN CONTACTS ON BLOCK.number = CONTACTS.processed_number )" +
            "WHERE name LIKE :search OR number LIKE :search " +
            "GROUP BY number")
    Cursor getAllBlockContactBySearch(String search);




    @Query("SELECT block._id,block.number,contacts.name,contacts.processed_number," +
            "contacts.contact_id,contacts.photo_uri from block LEFT JOIN contacts " +
            "ON block.number=contacts.processed_number group by block.number")
    Cursor getAllBlockContactCursor();


}
