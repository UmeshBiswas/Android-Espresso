package com.revesoft.itelmobiledialer.chat.chatWindow.supportiveActivities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.CaptionSetterActivity;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.FullscreenCameraCaptureActivity;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.SelectedMediaDataHolder;
import com.revesoft.itelmobiledialer.customview.SquareImageView;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.ViewSetup;
import com.revesoft.material.R;
import com.revesoft.material.databinding.FullScreenImageGalleryActivityLayoutBinding;

import java.io.File;
import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.databinding.DataBindingUtil;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 1/2/2018.
 */

public class FullScreenImageGalleryActivity extends BaseActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    public static final String KEY_ALREADY_SELECTED_FILE_PATHS = "KEY_ALREADY_SELECTED_FILE_PATHS";
    private static final int CAPTURE_FULLSCREEN_REQUEST = 59;
    ArrayList<String> selectedFilePaths = new ArrayList<>();
    ImageGalleryAdapter imageGalleryAdapter;
    FullScreenImageGalleryActivityLayoutBinding binding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.selectedFilePaths.addAll(SelectedMediaDataHolder.getAll());
        binding = DataBindingUtil.setContentView(this, R.layout.full_screen_image_gallery_activity_layout);
        ViewSetup.setUpToolbar(this, getString(R.string.selectFromGallery), true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3, RecyclerView.VERTICAL, false);
        binding.recyclerView.setLayoutManager(gridLayoutManager);
        imageGalleryAdapter = new ImageGalleryAdapter();
        binding.recyclerView.setAdapter(imageGalleryAdapter);

        binding.ivNext.setOnClickListener(v -> {
            if (selectedFilePaths.size() > 0) {
                SelectedMediaDataHolder.addAll(selectedFilePaths);
                CaptionSetterActivity.start(FullScreenImageGalleryActivity.this);
                finish();
            }
        });
        if (selectedFilePaths.size() == 0) {
            binding.ivNext.animate().scaleY(0).scaleX(0).setDuration(10).start();
            binding.tvCount.setText("0");
        } else {
            binding.ivNext.animate().scaleY(1).scaleX(1).setDuration(10).start();
            binding.tvCount.setText(String.valueOf(selectedFilePaths.size()));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAPTURE_FULLSCREEN_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {
                String capturedFilePath = data.getStringExtra("resultFilePath");
                if (!TextUtils.isEmpty(capturedFilePath)) {
                    sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(new File(capturedFilePath))));
                    selectedFilePaths.add(capturedFilePath);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            getSupportLoaderManager().restartLoader(0, null, FullScreenImageGalleryActivity.this);
                        }
                    }, 500);
                }
            } else {
                I.toast(getString(R.string.cancelled));
            }
        }
    }

    private class ImageGalleryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private Cursor cursor;

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_gallery_single_item, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ((ViewHolder) holder).bindView(position);
        }

        @Override
        public int getItemCount() {
            if (cursor == null)
                return 1;
            else return cursor.getCount() + 1;
        }

        public void swapData(Cursor data) {
            this.cursor = data;
            notifyDataSetChanged();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {
            SquareImageView ivPreview;
            AppCompatRadioButton radioButton;
            ImageView ivVideoIndicator;

            public ViewHolder(View itemView) {
                super(itemView);
                ivPreview = (SquareImageView) itemView.findViewById(R.id.ivPreview);
                radioButton = (AppCompatRadioButton) itemView.findViewById(R.id.radioButton);
                ivVideoIndicator = (ImageView) itemView.findViewById(R.id.ivVideoIndicator);
            }

            public void bindView(int position) {
                if (position == 0) {
                    radioButton.setVisibility(View.GONE);
                    ivPreview.setImageResource(R.drawable.blue_gallery_photo);
                    ivPreview.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i = new Intent(FullScreenImageGalleryActivity.this, FullscreenCameraCaptureActivity.class);
                            startActivityForResult(i, CAPTURE_FULLSCREEN_REQUEST);
                        }
                    });
                    ivVideoIndicator.setVisibility(View.GONE);

                } else {
                    if (cursor != null && cursor.moveToPosition(position - 1)) {
                        final String filePath = cursor.getString(cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA));
                        String mimeType = cursor.getString(cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE));
                        Glide.with(FullScreenImageGalleryActivity.this)
                                .load(filePath)
                                .placeholder(R.drawable.loader_animation)
                                .centerCrop()
                                .crossFade()
                                .error(R.drawable.invalid_image_file)
                                .into(ivPreview);
                        if (mimeType.contains("image")) {
                            ivVideoIndicator.setVisibility(View.GONE);
                        } else {
                            ivVideoIndicator.setVisibility(View.VISIBLE);
                        }
                        radioButton.setChecked(selectedFilePaths.contains(filePath));
                        ivPreview.setOnClickListener(v -> {
                            if (selectedFilePaths.contains(filePath)) {
                                selectedFilePaths.remove(filePath);
                                SelectedMediaDataHolder.remove(filePath);
                                if (selectedFilePaths.size() == 0) {
                                    binding.ivNext.animate().scaleY(0).scaleX(0).setDuration(250).start();
                                    binding.tvCount.animate().scaleY(0).scaleX(0).setDuration(250).start();
                                }
                                radioButton.setChecked(false);
                            } else if (selectedFilePaths.size() == 10) {
                                I.toast(getString(R.string.youCanSelectTenFiles));
                            } else {
                                selectedFilePaths.add(filePath);
                                binding.ivNext.animate().scaleY(1).scaleX(1).setDuration(250).start();
                                binding.tvCount.animate().scaleY(1).scaleX(1).setDuration(250).start();
                                radioButton.setChecked(true);
                            }
                            binding.tvCount.setText(String.valueOf(selectedFilePaths.size()));
                        });
                    }
                }
            }

        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri queryUri = MediaStore.Files.getContentUri("external");

        String[] projection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.TITLE,
                MediaStore.Files.FileColumns.SIZE
        };

        String selection = "(" + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                + ") AND ("
                + MediaStore.Files.FileColumns.SIZE + " > 0 )";


        return new CursorLoader(
                FullScreenImageGalleryActivity.this,
                queryUri,
                projection,
                selection,
                null,
                MediaStore.Files.FileColumns.DATE_ADDED + " DESC"
        );
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null && data.moveToFirst()) {
            imageGalleryAdapter.swapData(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        getSupportLoaderManager().restartLoader(0, null, FullScreenImageGalleryActivity.this);
    }
}
