package com.revesoft.itelmobiledialer.chat.chatWindow;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.google.android.gms.maps.model.LatLng;
import com.iftalab.runtimepermission.DangerousPermission;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.CaptionSetterActivity;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatAdapterHelper;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.chat.preview.GifAndStickerPreviewActivity;
import com.revesoft.itelmobiledialer.chat.preview.ImagePreviewActivity;
import com.revesoft.itelmobiledialer.chat.preview.VideoPlayerActivity;
import com.revesoft.itelmobiledialer.confide.ConfidePreviewActivity;
import com.revesoft.itelmobiledialer.confide.SendConfideMessageActivity;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.ims.ChatMemberSelectionActivity;
import com.revesoft.itelmobiledialer.ims.GroupDetailsActivity;
import com.revesoft.itelmobiledialer.ims.group.CreateGroupActivity;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.GenericFileProvider;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.NativeContactUtil;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import androidx.appcompat.app.AlertDialog;

/**
 * @author Ifta on 12/9/2017.
 */

public class Switcher {
    public static void switchToChatDetails(Context context, String target, boolean isGroupChat, boolean isSMSChat) {
        if (isGroupChat) {
            switchToGroupDetails(context, target);
        } else {
            switchToContactDetails(context, target);
        }
    }

    private static void switchToGroupDetails(Context context, String groupId) {
        Intent intent = new Intent(context, GroupDetailsActivity.class);
        intent.putExtra(Constants.IMS.GROUP_ID, groupId);
        context.startActivity(intent);
    }

    public static void switchToContactDetails(Context context, String target) {
        Executor.ex(() -> {
            String processedNumber = Util.translateNumber(target);
            String contactId = ContactRepo.get().getContactIdByFlatNumber(processedNumber);
            Gui.get().run(() -> {
                if (contactId != null)
                    ContactDetailsActivity.start(context, contactId, processedNumber);
                else {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                    alertDialogBuilder.setMessage("Do you want to add this number to contact list?");
                    alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            NativeContactUtil.saveContact(context, target);
                        }
                    });
                    alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alertDialogBuilder.show();
                }
            });
        });
    }

    public static void switchToImagePreview(String filePath) {
        Intent intent = new Intent(AppContext.getAccess().getContext(), ImagePreviewActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        intent.putExtra("FILE_PATH", filePath);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        AppContext.getAccess().getContext().startActivity(intent);
    }

    public static void switchToVideoPreview(String filePath) {
//        PermissionDialogActivity.takePermission(PermissionDialogActivity.PermissionType.Storage, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
                Intent intent = new Intent(AppContext.getAccess().getContext(), VideoPlayerActivity.class);
                intent.putExtra("FILE_PATH", filePath);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                AppContext.getAccess().getContext().startActivity(intent);
//            }
//
//            @Override
//            public void onPermissionRejected() {
//
//            }
//        });

    }

    public static void switchToGifPreview(String gifUrl) {
        Intent intent = new Intent(AppContext.getAccess().getContext(), GifAndStickerPreviewActivity.class);
        intent.putExtra(ChatConstants.KEY_GIF_URL, gifUrl);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        AppContext.getAccess().getContext().startActivity(intent);
    }

    public static void switchToStickerPreview(String stickerUrl) {
        Intent intent = new Intent(AppContext.getAccess().getContext(), GifAndStickerPreviewActivity.class);
        intent.putExtra(ChatConstants.KEY_STICKER_URL, stickerUrl);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        AppContext.getAccess().getContext().startActivity(intent);
    }

    public static void switchToChatWindow(Context context, String target, boolean isGroupChat, boolean isBroadcastIM, boolean isSMSChat, boolean isEncrypted) {
        if (UserDataManager.getUserName().equals(target)) {
            I.toast(Supplier.getString(R.string.you_shall_not_be_able_send_message_to_yourself));
            return;
        }

//        PermissionDialogActivity.takePermission(PermissionDialogActivity.PermissionType.Storage, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
                Intent intent = new Intent(context, ChatWindowActivity.class);
                if (isGroupChat) {
                    intent.putExtra(ChatConstants.KEY_GROUP_ID, target);
                    //Log.e("switching to group ","chat");
                } else {
                    intent.putExtra(ChatConstants.KEY_NUMBER, target);
                }
                intent.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadcastIM);
                intent.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
		/*if(isSMSChat){
			Log.e("switching to sms ","chat");

		}*/
                intent.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
                intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                context.startActivity(intent);
//            }

//            @Override
//            public void onPermissionRejected() {
//                Intent intent = new Intent(context, ChatWindowActivity.class);
//                if (isGroupChat) {
//                    intent.putExtra(ChatConstants.KEY_GROUP_ID, target);
//                    //Log.e("switching to group ","chat");
//                } else {
//                    intent.putExtra(ChatConstants.KEY_NUMBER, target);
//                }
//                intent.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadcastIM);
//                intent.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
//		/*if(isSMSChat){
//			Log.e("switching to sms ","chat");
//
//		}*/
//                intent.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
//                intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
//                context.startActivity(intent);
//            }
//        });

    }


    public static void switchToChatWindow(Context context, String target, boolean isGroupChat, boolean isBroadcastIM, boolean isSMSChat, boolean isEncrypted, String callerIdForHighlight) {

//        PermissionDialogActivity.takePermission(PermissionDialogActivity.PermissionType.Storage, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
                Intent intent = new Intent(context, ChatWindowActivity.class);
                if (isGroupChat) {
                    intent.putExtra(ChatConstants.KEY_GROUP_ID, target);
                } else {
                    intent.putExtra(ChatConstants.KEY_NUMBER, target);
                }
                intent.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadcastIM);
                intent.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
                intent.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
                intent.putExtra(ChatConstants.KEY_OCID_ID, callerIdForHighlight);
                intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                context.startActivity(intent);
//            }
//
//            @Override
//            public void onPermissionRejected() {
//                Intent intent = new Intent(context, ChatWindowActivity.class);
//                if (isGroupChat) {
//                    intent.putExtra(ChatConstants.KEY_GROUP_ID, target);
//                } else {
//                    intent.putExtra(ChatConstants.KEY_NUMBER, target);
//                }
//                intent.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadcastIM);
//                intent.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
//                intent.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
//                intent.putExtra(ChatConstants.KEY_OCID_ID, callerIdForHighlight);
//                intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
//                context.startActivity(intent);
//            }
//        });


    }

    public static void switchToChatWindowFromChatBubble(Context context, String target, boolean isGroupChat, boolean isBroadcastIM, boolean isSMSChat, boolean isEncrypted) {

//        PermissionDialogActivity.takePermission(PermissionDialogActivity.PermissionType.Storage, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
                Intent intent = new Intent(context, ChatWindowActivity.class);
                if (isGroupChat) {
                    intent.putExtra(ChatConstants.KEY_GROUP_ID, target);
                } else {
                    intent.putExtra(ChatConstants.KEY_NUMBER, target);
                }
                intent.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadcastIM);
                intent.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
                intent.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
                intent.putExtra((ChatConstants.KEY_FROM_BUBBLE), true);

                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);

                context.startActivity(intent);
//            }
//
//            @Override
//            public void onPermissionRejected() {
//                Intent intent = new Intent(context, ChatWindowActivity.class);
//                if (isGroupChat) {
//                    intent.putExtra(ChatConstants.KEY_GROUP_ID, target);
//                } else {
//                    intent.putExtra(ChatConstants.KEY_NUMBER, target);
//                }
//                intent.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadcastIM);
//                intent.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
//                intent.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
//                intent.putExtra((ChatConstants.KEY_FROM_BUBBLE), true);
//
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
//
//                context.startActivity(intent);
//            }
//        });
    }

    public static void switchToMapApplication(LatLng latLng) {
        if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
            try {
                String label = Supplier.getString(R.string.selected_location);
                String uriBegin = "geo:" + latLng.latitude + "," + latLng.longitude;
                String query = latLng.latitude + "," + latLng.longitude + "(" + label + ")";
                String encodedQuery = Uri.encode(query);
                String uriString = uriBegin + "?q=" + encodedQuery + "&z=16";
                Uri uri = Uri.parse(uriString);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if (mapIntent.resolveActivity(AppContext.getAccess().getContext().getPackageManager()) != null) {
                    AppContext.getAccess().getContext().startActivity(mapIntent);
                } else {
                    I.toast(Supplier.getString(R.string.something_went_wrong));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            I.toast(Supplier.getString(R.string.location_permission));
        }
    }

    static void switchToAddChatParty(Context context) {

        if (!ChatProperties.isGroupChat) { //that means this is not already a group
            ChatMemberSelectionActivity.startForGroupCreationFromSingleChat(context, Target.target);
        } else { //this is already a group
            Intent intent = new Intent(context, CreateGroupActivity.class);
            intent.putExtra("CREATE", 0);
            intent.putExtra("GROUP_ID", Target.group.id);
            intent.putExtra("GROUP_NAME", Target.group.name);
            intent.putExtra("SELECTED_LIST", new ArrayList<>(Arrays.asList(Target.group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber)));
            intent.putExtra("PREVIOUS_LIST", new ArrayList<>(Arrays.asList(Target.group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber)));
            intent.putExtra("IS_GROUP_CHAT_CREATOR", Target.group.isCreator);
            intent.putExtra("is_encrypted", ChatProperties.isEncryptedChat);
            intent.putExtra("group_type", Target.group.isOpenGroup ? Constants.GROUP_TYPE_PUBLIC : Constants.GROUP_TYPE_PRIVATE);
            context.startActivity(intent);
        }

    }

    public static void switchToSingleSMSSendingActivityFromGroupChat(String number) {
//        Intent intent = new Intent(AppContext.getAccess().getContext(), DialogSingleSMSActivity.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        intent.putExtra("number", number);
//        intent.putExtra("group_id", Target.group.id);
//        intent.putExtra("group_type", Target.group.groupType + "");
//        intent.putExtra("encryption_type", ChatProperties.isEncryptedChat);
//        AppContext.getAccess().getContext().startActivity(intent);
    }


    public static void switchToReadConfideChat(String callerId) {
        Intent intent = new Intent(AppContext.getAccess().getContext(), ConfidePreviewActivity.class);
        intent.putExtra(ConfidePreviewActivity.KEY_CALLER_ID, callerId);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        AppContext.getAccess().getContext().startActivity(intent);
    }


    public static void switchToSendConfideChat(Context context, String target) {
        ChatWindowEventHook.dispatchEvent(ChatWindowEvent.ExitQuoteMode);
        ChatWindowEventHook.dispatchEvent(ChatWindowEvent.HideBottomFragment);
        Intent intent = new Intent(context, SendConfideMessageActivity.class);
        intent.putExtra(SendConfideMessageActivity.KEY_NUMBER, target);
        context.startActivity(intent);
    }

    public static void switchToCaptionSetterActivity(Activity activity) {
        Intent intent = new Intent(activity, CaptionSetterActivity.class);
        activity.startActivity(intent);
    }

    public static void openDocument(Message message) {
        if (ChatUtil.isUploadingOrDownloadingNow(message)) {
            I.toast(Supplier.getString(R.string.sorryNotReadyYet));
        } else {
            if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                File file = new File(message.filePathLocal);
                if (file.exists()) {
                    MimeTypeMap myMime = MimeTypeMap.getSingleton();
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    String mimeType = myMime.getMimeTypeFromExtension(ChatAdapterHelper.Document.getDocumentExtension(message.content));
                    String authority = AppContext.getAccess().getContext().getPackageName() + ".my.package.name.provider";
                    Uri fileUri = GenericFileProvider.getUriForFile(AppContext.getAccess().getContext(), authority, file);
                    Log.d("fileUri", "openDocument: fileUri " + fileUri);
                    intent.setDataAndType(fileUri, mimeType);
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(intent, Supplier.getString(R.string.open_file_with));
                    chooser.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    AppContext.getAccess().getContext().startActivity(chooser);
                } else {
                    I.toast(Supplier.getString(R.string.file_does_not_exist));
                }
            } else {
                I.toast(Supplier.getString(R.string.file_read_write_permission));
            }
        }
    }

    public static void switchToAddContactOrContactDetails(String numberOrEmail) {
        if (UserDataManager.getUserName().equals(numberOrEmail)) {
            return;
        }
        if (DangerousPermission.ContactsPermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
            if (ContactEngine.getContactIDFromNumber(AppContext.getAccess().getContext(), numberOrEmail) != -1) {
                I.toast("To be implemented");
            } else {
                addToContact(numberOrEmail, ProfilePictureDataProvider.getProfilePictureAsBitmap(numberOrEmail));
            }
        } else {
            I.toast(Supplier.getString(R.string.contacts_permission));
        }
    }

    private static void addToContact(String number, Bitmap bitmap) {
        if (DangerousPermission.ContactsPermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
            ArrayList<ContentValues> data = new ArrayList<>();
            ContentValues row = new ContentValues();
            row.put(ContactsContract.Contacts.Data.MIMETYPE, ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE);
            if (bitmap != null) {
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                row.put(ContactsContract.CommonDataKinds.Photo.PHOTO, byteArray);
            }
            data.add(row);
            Intent intent = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putParcelableArrayListExtra(ContactsContract.Intents.Insert.DATA, data);

            if (Util.isValidEmail(Util.getProperEmail(number))) {
                intent.putExtra(ContactsContract.Intents.Insert.EMAIL, Util.getProperEmail(number));
            } else {
                intent.putExtra(ContactsContract.Intents.Insert.PHONE, number);
            }
            AppContext.getAccess().getContext().startActivity(intent);
        } else {
            I.toast(Supplier.getString(R.string.contacts_permission));
        }
    }

}
