package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.UriNotifyEventListener;

public abstract class EntityBase {
   public abstract void save(UriNotifyEventListener listener);
    public abstract void delete(UriNotifyEventListener listener);
    public abstract void update(UriNotifyEventListener listener);
}
