package com.revesoft.itelmobiledialer.appDatabase;

import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.ArrayList;
import java.util.List;

public class ContactAppDatabaseLoader {
    public static synchronized int reloadContactTable(Cursor cursor) {

        int n = 0;
        String username = UserDataManager.getUserName();
        int countryCode = UserDataManager.getUserCountryCode();
        long my_last_sync_time = UserDataManager.getLastContactSyncTime();
        List<String> updated_all_contact_id_list = new ArrayList<>();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                try {
                    String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                    String lookup_key = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY));
                    String contact_id = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
                    int is_favourite = cursor.getInt(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED));

                    updated_all_contact_id_list.add(contact_id);

                    Uri photoUri = null;
                    if (android.os.Build.VERSION.SDK_INT > 10) {
                        String photoPath = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI));
                        if (photoPath != null) {
                            photoUri = Uri.parse(photoPath);
                        }
                    } else {
                        String photoID = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_ID));
                        if (photoID != null) {
                            photoUri = ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, Long.parseLong(photoID));
                        }
                    }

                    boolean is_contact_modified = true;

                    if (android.os.Build.VERSION.SDK_INT > 18) {
                        long contact_update_time =
                                cursor.getLong(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_LAST_UPDATED_TIMESTAMP));
                        is_contact_modified = contact_update_time > my_last_sync_time;
                    }

                    if (is_contact_modified) {
                        String photoUriStr = photoUri == null ? "" : photoUri.toString();
                        String processed_number = username.length() > 0 ?
                                Util.translateNumber(number, countryCode) : number.replaceAll("\\D", "");

                        if (ContactRepo.get().isContactExistsByProcessedNumber(processed_number)) {
                            //ContactRepo.get().replaceModifiedContact(name, number, lookup_key, contact_id, photoUriStr, processed_number, is_favourite);
                            ContactRepo.get().deleteContactByLookUpKey(processed_number);
                        }

                        Contact contact = Contact.newBuilder().setContact_id(contact_id)
                                    .setFavorite(is_favourite == 1)
                                    .setLookUpKey(lookup_key)
                                    .setName(name)
                                    .setNumber(number)
                                    .setPhotoUri(photoUriStr)
                                    .setProcessedNumber(processed_number)
                                    .build();
                            ContactRepo.get().insert(contact);

                        n++;

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (n % 250 == 0) {
//                    writeableDatabase.yieldIfContendedSafely();
                }
            } while (cursor.moveToNext());
        }
        try {
            if (updated_all_contact_id_list.size() != 0) {
                ContactRepo.get().deleteContactByContactIdsNotFound(updated_all_contact_id_list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            long updated_contact_sync_time = System.currentTimeMillis();
            UserDataManager.setLastContactSyncTime(updated_contact_sync_time);
        }
        return n;

    }

}
