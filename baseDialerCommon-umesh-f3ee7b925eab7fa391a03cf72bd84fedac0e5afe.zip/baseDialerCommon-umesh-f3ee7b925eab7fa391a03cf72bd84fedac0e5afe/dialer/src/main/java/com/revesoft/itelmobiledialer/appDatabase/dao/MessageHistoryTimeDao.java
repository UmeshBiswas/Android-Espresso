package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.MessageHistoryTime;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface MessageHistoryTimeDao extends BaseDao<MessageHistoryTime> {
    @Query("SELECT * FROM MESSAGE_HISTORY_TIME_TABLE")
    List<MessageHistoryTime> getAll();

    @Query("SELECT DISTINCT group_or_user FROM MESSAGE_HISTORY_TIME_TABLE")
    List<String> getAllGroupOrNumber();


    @Query("DELETE FROM MESSAGE_HISTORY_TIME_TABLE WHERE group_or_user IN (:list)")
    void deleteSelectedTimeLineEntries(List<String> list);

    @Query("SELECT * FROM MESSAGE_HISTORY_TIME_TABLE WHERE group_or_user IN (:list)")
    Cursor getTimeLineItemOrderByUserOrGroupIDAndStartDate(List<String> list);

    @Query("SELECT * FROM MESSAGE_HISTORY_TIME_TABLE WHERE group_or_user=:userOrGroupId")
    Cursor getTimeLineItemByUserOrGroupID(String userOrGroupId);
}
