package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.quote;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Controllable;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.data.NameResolver;
import com.revesoft.itelmobiledialer.ims.ChatUtil;
import com.revesoft.itelmobiledialer.signalling.sipUtil.TaggedLogger;
import com.revesoft.material.R;
import com.revesoft.material.databinding.MessageQuoteViewBinding;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;


public class MessageQuoteFragment extends Fragment {
    private static final String TAG = "MessageQuoteTag";

    public static String getTAG() {
        return TAG;
    }

    private final TaggedLogger logger = new TaggedLogger("messageQuote");
    private static final String KEY_CALL_ID = "KEY_CALL_ID";
    private String callId;

    public static Fragment newInstance(String callerId) {
        Bundle bundle = new Bundle();
        bundle.putString(KEY_CALL_ID, callerId);
        Fragment fragment = new MessageQuoteFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bag = getArguments();
        if (bag != null) {
            if (bag.containsKey(KEY_CALL_ID)) {
                callId = bag.getString(KEY_CALL_ID, null);
                if (callId == null && getActivity() != null) {
                    logger.log("MessageQuoteFragment onCreate e null call id :(");
                    getActivity().finish();
                }
            }
        }
    }

    private MessageQuoteViewBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.message_quote_view, container, false);
        Executor.ex(() -> {
            Message message = MessageRepo.get().getMessageByCallId(callId);
            if (message != null) {
                Gui.get().run(() -> bindMessage(message));
            }
        });
        return binding.getRoot();
    }

    private void bindMessage(Message message) {
        try {
            MessageQuoteBindingData quoteBindingData = new MessageQuoteBindingData();
            if (ChatUtil.isFileContent(message.content)) {
                quoteBindingData.filePath = message.filePath;
                String description = ChatUtil.getCaption(message.content);
                if (TextUtils.isEmpty(description)) {
                    description = MimeTypeUtil.getHumanReadableMimeType(message.mimeType);
                }
                quoteBindingData.message = description;
                quoteBindingData.previewVisibility = View.VISIBLE;
                if (message.mimeType == MimeType.Video) {
                    quoteBindingData.videoIconVisibility = View.VISIBLE;
                } else {
                    quoteBindingData.videoIconVisibility = View.GONE;
                }
            } else {
                quoteBindingData.filePath = null;
                quoteBindingData.message = (message.content.length() > 50) ? message.content.substring(0, 50) : message.content;
                quoteBindingData.previewVisibility = View.GONE;
            }
            quoteBindingData.name = NameResolver.getContactNameFromNumberOrEmail(message.number);
            binding.setQuoteBindingData(quoteBindingData);
            binding.ivCloseQuote.setOnClickListener(v -> {
                if(getActivity()!=null && getActivity() instanceof Controllable){
                    ((Controllable) getActivity()).onControlRequest(Controllable.RequestType.ExitQuoteMode);
                }
            });
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage());
        }
    }
//    }
//
//    private void setTextMessage(String content) {
//        tvNonTextMessage.setVisibility(View.GONE);
//        ivFilePreview.setVisibility(View.GONE);
//        tvTextMessage.setVisibility(View.VISIBLE);
//        tvTextMessage.setText(content);
//    }
//
//
//    private void setMediaMessage(Message message) {
//        tvNonTextMessage.setVisibility(View.VISIBLE);
//        ivFilePreview.setVisibility(View.GONE);
//        tvTextMessage.setVisibility(View.GONE);
//        int drawableId = ChatUtil.getDrawableIdForMimeType(message.mimeType);
//        tvNonTextMessage.setCompoundDrawablesWithIntrinsicBounds(drawableId, 0, 0, 0);
//        String description = ChatUtil.getCaption(message.content);
//        if (TextUtils.isEmpty(description)) {
//            description = MimeTypeUtil.getHumanReadableMimeType(message.mimeType);
//        }
//        tvNonTextMessage.setText(description);
//        if (message.mimeType == MimeType.Image || message.mimeType == MimeType.Video) {
//            setThumbnailForVideoAndImage(message.filePath);
//        } else if (message.mimeType == MimeType.Location) {
//            setThumbnailForMap(message.content);
//        } else {
//            ivFilePreview.setVisibility(View.GONE);
//        }
//    }
//
//    private void setThumbnailForMap(String content) {
//        ivFilePreview.setVisibility(View.VISIBLE);
//        String loc = content.replace(Constants.LOCATION_PREFIX, "");
//        loc = loc.replace(Constants.LS_SUFIX, "");
//        String[] arr = loc.split(",");
//        double lat = 0, lng = 0;
//        try {
//            if (arr.length == 2) {
//                lat = Double.parseDouble(arr[0].trim());
//                lng = Double.parseDouble(arr[1].trim());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        final LatLng latLng = new LatLng(lat, lng);
//        int dimension = getResources().getDimensionPixelSize(R.dimen.messageQuoteThumbSize);
//        String baseMapUri = "https://maps.googleapis.com/maps/api/staticmap?zoom=16&size=" + dimension + "x" + dimension + "&markers=size:mid|color:red|";
//        String mapUri = baseMapUri + latLng.latitude + "," + latLng.longitude + "&sensor=false";
//
//        Glide.with(getActivity())
//                .load(Uri.parse(mapUri))
//                .crossFade()
//                .centerCrop()
//                .override(dimension, dimension)
//                .error(R.drawable.file_broken)
//                .into(ivFilePreview);
//    }
//
//    private void setThumbnailForVideoAndImage(String filePath) {
//        ivFilePreview.setVisibility(View.VISIBLE);
//        int dimension = getResources().getDimensionPixelSize(R.dimen.messageQuoteThumbSize);
//        Glide.with(getActivity())
//                .load(filePath)
//                .centerCrop()
//                .override(dimension, dimension)
//                .crossFade()
//                .error(R.drawable.file_broken)
//                .into(ivFilePreview);
//    }
//
//    private void setName(String phoneNumber) {
//        String name = phoneNumber;
//        if (UserDataManager.getUserName().equals(phoneNumber)) {
//            name = getString(R.string.you);
//        } else {
//            if (CommonData.contactNumberToContactName.containsKey(phoneNumber)) {
//                name = CommonData.contactNumberToContactName.get(phoneNumber);
//            } else if (phoneNumber.equals(UserDataManager.getUserName())) {
//                name = getString(R.string.you);
//            }
//        }
//        tvName.setText(name);
//    }
//
//    private void setName(Message message) {
//        String name = message.phoneNumber;
//        if (message.type == MessageEntry.MessageType.SEND) {
//            name = getString(R.string.you);
//        } else {
//            if (CommonData.contactNumberToContactName.containsKey(message.phoneNumber)) {
//                name = CommonData.contactNumberToContactName.get(message.phoneNumber);
//            } else if (message.phoneNumber.equals(UserDataManager.getUserName())) {
//                name = getString(R.string.you);
//            }
//        }
//        tvName.setText(name);
//    }


}
