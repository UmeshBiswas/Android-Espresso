package com.revesoft.itelmobiledialer.appDatabase.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
//db.execSQL("CREATE TABLE  IF NOT EXISTS did_table(
// _id integer default 100,
// did_id text primary key not null,
// didOwner text,
// didNumber text not null,
// forwardedNumber text,
// expiredDate text)");
@Entity(tableName = "did_table")
public class DID {
    @NonNull
    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "did_id")
    public String didId = "";

    @ColumnInfo(name="didOwner")
    public String didOwner;

    @ColumnInfo(name = "didNumber")
    public String didNumber;

    @ColumnInfo(name="forwardedNumber")
    public String forwardedNumber;

    @ColumnInfo(name ="expiredDate")
    public String expiredDate;


    public static DID createAppDatabaseDID(com.revesoft.itelmobiledialer.did.DID did){
        DID appDatabaseDID=new DID();
        appDatabaseDID.didId=did.getDidID();
        appDatabaseDID.didNumber=did.getDidNumber();
        appDatabaseDID.didOwner=did.getDidOwner();
        appDatabaseDID.expiredDate=did.getExpireDate();
        appDatabaseDID.forwardedNumber=did.getForwardedNumber();
        return appDatabaseDID;
    }

    public com.revesoft.itelmobiledialer.did.DID convertDID(){
        com.revesoft.itelmobiledialer.did.DID did=new com.revesoft.itelmobiledialer.did.DID(
                didId,
                didOwner,
                didNumber,
                forwardedNumber,
                expiredDate
        );
        return did;
    }


}
