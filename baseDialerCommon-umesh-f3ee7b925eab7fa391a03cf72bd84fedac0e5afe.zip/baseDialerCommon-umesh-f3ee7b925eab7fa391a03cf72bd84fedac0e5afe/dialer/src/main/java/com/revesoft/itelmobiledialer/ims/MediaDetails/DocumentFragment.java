package com.revesoft.itelmobiledialer.ims.MediaDetails;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.ims.AudioPlayerActivity;
import com.revesoft.itelmobiledialer.ims.ImageDialog;
import com.revesoft.itelmobiledialer.ims.VideoPlayerActivity;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.GenericFileProvider;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import java.io.File;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by Acer on 6/8/2017.
 */

public class DocumentFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>{
    public static final String PAGE_TITLE = "PAGE_TITLE";
    LayoutInflater inflater;
    String fragmentName;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    ArrayList<Message> messageArrayList = new ArrayList<>();
    DocumentItemAdapter documentItemAdapter;

    public DocumentFragment(){

    }



    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        this.inflater = inflater;
        View view = inflater.inflate(R.layout.activity_media_detail_document_fragment, null);
        RelativeLayout relativeLayout = view.findViewById(R.id.cont_pager_item_root);
        getLoaderManager().initLoader(1000, null, this);
        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getContext());
        documentItemAdapter = new DocumentItemAdapter();
        recyclerView.setAdapter(documentItemAdapter);
        recyclerView.setLayoutManager(layoutManager);
        return view;
    }

    public void updateMessageList() {
        messageArrayList.clear();
        for(int i =0;  getActivity() != null  && i<messageList.size();i++)
        {

            MimeType mimeType = messageList.get(i).mimeType;
            Log.e("media-doc", mimeType.toString());
            if(mimeType == MimeType.Document )
            {
                File file =  new File(messageList.get(i).filePath);
                if(file.exists())
                {
                    messageArrayList.add(messageList.get(i));
                    messageArrayList.get(messageArrayList.size() -1).fileSize = Double.valueOf(file.length()/1024);
                }

            }

        }
        Log.e("media-doc", Integer.toString(messageArrayList.size()));
        documentItemAdapter.notifyDataSetChanged();

    }


    public static DocumentFragment getInstance(String pageTitle){
        DocumentFragment item = new DocumentFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PAGE_TITLE,pageTitle);
        item.setArguments(bundle);
        return item;
    }

    public void setFragmentName(String fragmentName){
        this.fragmentName = fragmentName;
        Log.e("fragment name",fragmentName);
    }

    private boolean isGroup;
    private String phoneNumberOrGroupNumber;

    public void setFragmentParams(boolean isGroup, String phoneNumberOrGroupNumber){
        this.isGroup = isGroup;
        this.phoneNumberOrGroupNumber = phoneNumberOrGroupNumber;
        Log.e("fragment param", this.phoneNumberOrGroupNumber);
    }

    public String getFragmentName(){
        return fragmentName;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new SQLiteCursorLoader(getActivity()) {
            @Override
            public Cursor loadInBackground() {
                Log.i("MediaDetailsActivity", "in MESSAGE_QUERY_LOADER");
                Cursor cursor = null;
                try {
                    if (isGroup) {
                        cursor = MessageRepo.get().getImsWithMediaByGroupId(phoneNumberOrGroupNumber);
                    } else {
                        cursor = MessageRepo.get().getImsWithMediaByNumber(phoneNumberOrGroupNumber);
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    this.registerContentObserver(cursor, DatabaseConstants.MESSAGE_URI);
                }

                return cursor;
            }
        };
    }

    private Cursor mediaMessageCursor;
    private ArrayList<Message> messageList = new ArrayList<>();

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null) {
            mediaMessageCursor = data;
        }
        Log.i("--------", "in MESSAGE_QUERY_LOADER_FINISHED_2");
        messageList.clear();
        if (mediaMessageCursor != null) {
            if (mediaMessageCursor.moveToFirst()) {
                do {
                    messageList.add(new Message(mediaMessageCursor));
                }
                while (mediaMessageCursor.moveToNext());

            }
        }
        Log.e("media-doc++", Integer.toString(messageList.size()));
        updateMessageList();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        messageList.clear();
        updateMessageList();
    }

    public interface FragmentItemCallback{
        void onPagerItemClick(String message);
    }

    private class DocumentItemAdapter extends RecyclerView.Adapter<DocumentItemAdapter.DocumentItemHolder>{

        @Override
        public DocumentItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new DocumentItemHolder(inflater.inflate(R.layout.activity_media_detail_document_item,null));
        }

        @Override
        public void onBindViewHolder(DocumentItemHolder holder, int position) {
            holder.tvDocumentTitle.setText(filterFileName(messageArrayList.get(position).filePath));
            holder.tvDate.setText(getDate(messageArrayList.get(position).time));
            holder.tvDocumentSize.setText(messageArrayList.get(position).fileSize +"KB");
            holder.tvDocumentType.setVisibility(View.GONE);
        }

        @Override
        public int getItemCount() {

            return  messageArrayList.size();
        }

        public class DocumentItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
            RelativeLayout container;
            ImageView documentIcon;
            TextView tvDocumentTitle;
            TextView tvDocumentSize;
            TextView tvDocumentType;
            TextView tvDate;

            public DocumentItemHolder(View itemView) {
                super(itemView);
                container = itemView.findViewById(R.id.container);
                documentIcon = itemView.findViewById(R.id.documentIcon);
                tvDocumentTitle = itemView.findViewById(R.id.documentTitle);
                tvDocumentSize = itemView.findViewById(R.id.documentSize);
                tvDocumentType = itemView.findViewById(R.id.documentType);
                tvDate = itemView.findViewById(R.id.date);
                container.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {
                openFileContent(new File(messageArrayList.get(getAdapterPosition()).filePath));
            }
        }

    }

    private String filterFileName(String filePath) {

        String filteredFilePath = filePath.substring(filePath.lastIndexOf('/')==filePath.length()-1?filePath.lastIndexOf('/'):filePath.lastIndexOf('/')+1 );
        if(filteredFilePath.length() != 0)
            return filteredFilePath;
        else
            return  filePath;
    }
    private String getDate(long timeStamp){

        try{
            DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date netDate = (new Date(timeStamp));
            return sdf.format(netDate);
        }
        catch(Exception ex){
            return "xx";
        }
    }

    private void openFileContent(File file) {
        if (file == null)
            return;
        String fileMimeType = determineFileMimeType(file);
        Log.d("Mkhan", "File Name " + file.getName() + " Type " + fileMimeType);

        if (!file.exists())
            return;
        if (fileMimeType != null) {

            //
            if (fileMimeType.contains("image")) {
                try {
                    Intent intent = new Intent(getActivity(), ImageDialog.class);
                    intent.putExtra("FILE_PATH", file.getAbsolutePath());
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("Asif", "Exception in opening image file");
                }
            } else if (fileMimeType.contains("video")) {
                try {
                    Intent intent = new Intent(getActivity(), VideoPlayerActivity.class);
                    intent.putExtra("FILE_PATH", file.getAbsolutePath());
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("Asif", "Exception in opening video file");
                }
            } else if (fileMimeType.contains("audio")) {
                try {
                    Intent intent = new Intent(getActivity(), AudioPlayerActivity.class);
                    intent.putExtra("AUDIO_FILE_PATH", file.getAbsolutePath());
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("Asif", "Exception in opening audio file");
                }
            } else {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                String authority = AppContext.getAccess().getContext().getPackageName() + ".my.package.name.provider";
                Uri fileUri = GenericFileProvider.getUriForFile(AppContext.getAccess().getContext(), authority, file);
                Log.d("fileUri", "openDocument: fileUri " + fileUri);
                intent.setDataAndType(fileUri, fileMimeType);
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(intent, Supplier.getString(R.string.option));
                chooser.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                AppContext.getAccess().getContext().startActivity(chooser);
            }

        } else {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage("Can not determine file anInt").setNeutralButton("OK", null);
            bld.create().show();
        }
    }

    private String determineFileMimeType(File file) {
        String mimeType = null;
        try {
            String fileUrl = file.toURI().toURL().toString();
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(fileUrl).toLowerCase();
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
        } catch (MalformedURLException e) {
            Log.e("Mkhan", "Exception in determineFileMimeType");
            e.printStackTrace();
            if (mimeType == null || mimeType.length() == 0) {
                mimeType = "application/octet-stream";
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            Log.e("Mkhan", "Exception in determineFileMimeType");
            if (mimeType == null || mimeType.length() == 0) {
                mimeType = "application/octet-stream";
            }
        }

        return mimeType;

    }
}