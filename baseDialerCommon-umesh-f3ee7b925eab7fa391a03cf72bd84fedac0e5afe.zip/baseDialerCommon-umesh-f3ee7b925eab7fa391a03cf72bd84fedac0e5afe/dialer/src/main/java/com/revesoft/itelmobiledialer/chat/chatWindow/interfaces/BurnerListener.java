package com.revesoft.itelmobiledialer.chat.chatWindow.interfaces;

/**
 * @author Ifta  on 10/23/2017.
 */

public interface BurnerListener {
    void onBurnFinished();
}
//handle block unblock properties
