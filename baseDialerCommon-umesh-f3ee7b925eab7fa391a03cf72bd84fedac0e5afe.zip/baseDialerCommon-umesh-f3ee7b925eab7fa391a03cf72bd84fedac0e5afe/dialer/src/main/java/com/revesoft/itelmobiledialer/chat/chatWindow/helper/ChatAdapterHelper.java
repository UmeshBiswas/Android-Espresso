package com.revesoft.itelmobiledialer.chat.chatWindow.helper;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.bumptech.glide.request.target.Target;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iftalab.runtimepermission.DangerousPermission;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.StaticStickerDataProvider;
import com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces.IDrawableLoaderTaskListener;
import com.revesoft.itelmobiledialer.chat.tenor.tools.loaders.GifLoader;
import com.revesoft.itelmobiledialer.chat.tenor.tools.params.GlideTaskParams;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.io.File;
import java.util.HashMap;

import androidx.annotation.NonNull;

/**
 * @author Ifta on 12/14/2017.
 */

public class ChatAdapterHelper {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");

    public static class Sticker {

        final static HashMap<String, Integer> stickerNameToId = new HashMap<>();

        static {
            stickerNameToId.put("call_reject_sticker_1", R.drawable.call_reject_sticker_1);
            stickerNameToId.put("call_reject_sticker_2", R.drawable.call_reject_sticker_2);
            stickerNameToId.put("call_reject_sticker_3", R.drawable.call_reject_sticker_3);
            stickerNameToId.put("call_reject_sticker_4", R.drawable.call_reject_sticker_4);
            stickerNameToId.put("call_reject_sticker_5", R.drawable.call_reject_sticker_5);
            stickerNameToId.put("call_reject_sticker_6", R.drawable.call_reject_sticker_6);
            stickerNameToId.put("call_reject_sticker_7", R.drawable.call_reject_sticker_7);
            stickerNameToId.put("call_reject_sticker_8", R.drawable.call_reject_sticker_8);
            stickerNameToId.put("call_reject_sticker_9", R.drawable.call_reject_sticker_9);
            stickerNameToId.put("call_reject_sticker_10", R.drawable.call_reject_sticker_10);
            stickerNameToId.put("call_reject_sticker_11", R.drawable.call_reject_sticker_11);
            stickerNameToId.put("call_reject_sticker_12", R.drawable.call_reject_sticker_12);
        }

        public static void handleStickerPreview(String content, final ImageView ivPreview) {
            String stickerUrl = ChatContentParser.parseStickerUrl(content);
            Glide.with(AppContext.getAccess().getContext())
                    .load(stickerUrl)
                    .asBitmap()
                    .placeholder(R.drawable.loader_animation)
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .into(new BitmapImageViewTarget(ivPreview) {
                        @Override
                        protected void setResource(Bitmap resource) {
                            ivPreview.setImageBitmap(resource);
                        }

                        @Override
                        public void onLoadFailed(Exception e, Drawable errorDrawable) {
                            ivPreview.setImageResource(R.drawable.ic_error);
                        }
                    });
        }

        public static void handleStickerPreview(String content, final ImageView ivPreview, final ImageView dummy, final ShimmerFrameLayout
                shimmerFrameLayout) {

            ivPreview.setVisibility(View.GONE);
            shimmerFrameLayout.setVisibility(View.VISIBLE);
            dummy.setVisibility(View.VISIBLE);

            String stickerUrl = ChatContentParser.parseStickerUrl(content);
            Glide.with(AppContext.getAccess().getContext())
                    .load(stickerUrl)
                    .asBitmap()
                    .placeholder(R.drawable.loader_animation)
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .listener(new RequestListener<String, Bitmap>() {
                        @Override
                        public boolean onException(Exception e, String model, Target<Bitmap> target, boolean isFirstResource) {
                            ivPreview.setVisibility(View.VISIBLE);
                            shimmerFrameLayout.setVisibility(View.GONE);
                            dummy.setVisibility(View.GONE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Bitmap resource, String model, Target<Bitmap> target, boolean isFromMemoryCache, boolean isFirstResource) {
                            ivPreview.setVisibility(View.VISIBLE);
                            shimmerFrameLayout.setVisibility(View.GONE);
                            dummy.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .into(new BitmapImageViewTarget(ivPreview) {
                        @Override
                        protected void setResource(Bitmap resource) {
                            ivPreview.setImageBitmap(resource);
                        }

                        @Override
                        public void onLoadFailed(Exception e, Drawable errorDrawable) {
                            ivPreview.setImageResource(R.drawable.ic_error);
                        }
                    });
        }


        public static void handleCallRejectStickerPreview(String content, ImageView ivPreview) {
            String stickerFileName = ChatContentParser.parseCallRejectStickerFileName(content);
            int stickerResourceId = stickerNameToId.containsKey(stickerFileName) ? stickerNameToId.get(stickerFileName) : 0;
            Glide.with(AppContext.getAccess().getContext())
                    .load(stickerResourceId)
                    .asBitmap()
                    .error(R.drawable.ic_broken_file)
                    .into(ivPreview);
        }

        public static void handleStaticStickerPreview(String content, ImageView ivPreview) {
            String stickerName = ChatContentParser.parseStaticStickerFileName(content);
            int stickerResourceId = StaticStickerDataProvider.getResourceIdByName(stickerName);
            Glide.with(AppContext.getAccess().getContext())
                    .load(stickerResourceId)
                    .error(R.drawable.b5)
                    .into(ivPreview);
        }
    }

    public static class Gif {
        public static void handleGifPreview(Message message, ImageView ivPreview, final ImageView dummy, final ShimmerFrameLayout
                shimmerFrameLayout) {

            ivPreview.setVisibility(View.GONE);
            shimmerFrameLayout.setVisibility(View.VISIBLE);
            dummy.setVisibility(View.VISIBLE);
            String gifUrl = ChatContentParser.parseGifUrl(message.content);
            int width = ChatContentParser.parseGifWidth(message.content);
            int height = ChatContentParser.parseGifHeight(message.content);
            GlideTaskParams<ImageView> params = new GlideTaskParams<>(ivPreview, gifUrl);
            if (width != -1 && height != -1) {
                params.setWidth(width);
                params.setHeight(height);
            }
            params.setPlaceholder(Color.LTGRAY);
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) ivPreview.getLayoutParams();
            ShimmerFrameLayout.LayoutParams layoutParams1 = (ShimmerFrameLayout.LayoutParams) dummy.getLayoutParams();
            float ratio = (height*1.0f)/(width*1.0f);
            layoutParams.height = (int) (layoutParams.width*ratio);
            layoutParams1.height = layoutParams.height;
            ivPreview.setLayoutParams(layoutParams);
            dummy.setLayoutParams(layoutParams1);


            params.setListener(new IDrawableLoaderTaskListener<ImageView, Drawable>() {
                @Override
                public void success(@NonNull ImageView target, @NonNull Drawable taskResult) {
                    ivPreview.setVisibility(View.VISIBLE);
                    shimmerFrameLayout.setVisibility(View.GONE);
                    dummy.setVisibility(View.GONE);
                }

                @Override
                public void failure(@NonNull ImageView target, @NonNull Drawable errorResult) {
                    ivPreview.setVisibility(View.VISIBLE);
                    shimmerFrameLayout.setVisibility(View.GONE);
                    dummy.setVisibility(View.GONE);

                }
            });
            GifLoader.loadGif(AppContext.getAccess().getContext(), params);
        }
    }


    private static final TaggedLogger imageLogger = new TaggedLogger("imageLogger");

    public static class Image {
        public static void handleImagePreview(Message message, ImageView ivPreview) {
            String textToSet;
            int textSize = 48;
            if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                if (message.isConfide) {
                    ivPreview.setVisibility(View.GONE);
                    return;
                }
                ivPreview.setVisibility(View.VISIBLE);
                imageLogger.log("handleImagePreview te content " + message.content);
                String filePath;
                File file;
                boolean isDownloading = ChatUtil.isDownloadingNow(message);
                boolean isUploading = ChatUtil.isSendingNow(message);

                if (isDownloading) {
                    if (message.mimeType == MimeType.Video) {
                        Glide.with(AppContext.getAccess().getContext())
                                .load(R.drawable.white)
                                .crossFade()
                                .centerCrop()
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .error(R.drawable.file_broken)
                                .thumbnail(.2f).into(ivPreview);
                    } else {
                        ImageUtil.setImageInChatBubble("", ivPreview, (isDownloading));
                    }
                } else {
                    filePath = message.filePathLocal;
                    file = new File(filePath);

                    if (file.exists()) {
                        if (message.mimeType == MimeType.Video) {
                            Glide.with(AppContext.getAccess().getContext())
                                    .load(file)
                                    .crossFade()
                                    .centerCrop()
                                    .error(R.drawable.file_broken)
                                    .thumbnail(.2f).into(ivPreview);
                        } else {
                            ImageUtil.setImageInChatBubble(filePath, ivPreview, (isUploading));
                        }
                    } else {
                        ImageUtil.setImageInChatBubble(filePath, ivPreview, false);
                    }
                }
            } else {
                textToSet = Supplier.getString(R.string.storagePermissionMissing);
                textSize = 36;
//                int width = AppContext.get().getContext().getResources().getDimensionPixelSize(R.dimen.imageWidthChatBubble);
//                int height = 128;
//                ViewGroup.LayoutParams layoutParams = ivPreview.getLayoutParams();
//                layoutParams.height = height;
//                layoutParams.width = width;
                //  ivPreview.setLayoutParams(layoutParams);
                ColorGenerator generator = ColorGenerator.MATERIAL;
                TextDrawable drawable = TextDrawable
                        .builder()
                        .beginConfig()
                        .fontSize(textSize)
                        .endConfig()
                        .buildRect(textToSet.toUpperCase(), generator.getColor(textToSet));
                ivPreview.setImageDrawable(drawable);

            }


        }
    }

    public static class Location {
        public static void handleLocationPreview(Message message, ImageView ivPreview) {
            Uri mapUri = ChatUtil.getMapPreviewUri(message.content);
            Glide.with(AppContext.getAccess().getContext())
                    .load(mapUri)
                    .asBitmap()
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .into(ivPreview);
        }

        public static void handleLocationRequestPreview(ImageView ivPreview) {
            Glide.with(AppContext.getAccess().getContext())
                    .load(R.drawable.ic_ask_location)
                    .asBitmap()
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(ivPreview);
        }
    }

    public static class Document {
        public static void handleDocumentPreview(final Message message, final ImageView ivPreview) {
            String textToSet;
            int textSize = 48;
            if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                textToSet = getDocumentExtension(message.content);
            } else {
                textToSet = Supplier.getString(R.string.storagePermissionMissing);
                textSize = 36;
            }
            int width = AppContext.getAccess().getContext().getResources().getDimensionPixelSize(R.dimen.imageWidthChatBubble);
            int height = 128;
            ViewGroup.LayoutParams layoutParams = ivPreview.getLayoutParams();
            layoutParams.height = height;
            layoutParams.width = width;
            ivPreview.setLayoutParams(layoutParams);
            ColorGenerator generator = ColorGenerator.MATERIAL;
            TextDrawable drawable = TextDrawable
                    .builder()
                    .beginConfig()
                    .width(width)
                    .height(height)
                    .fontSize(textSize)
                    .endConfig()
                    .buildRect(textToSet.toUpperCase(), generator.getColor(textToSet));
            ivPreview.setImageDrawable(drawable);
        }

        public static String getDocumentExtension(String content) {
            String fileExtension = content.replace(IMConstants.SEND_FILE_PREFIX, "")
                    .replace(IMConstants.SEND_FILE_SUFFIX, "")
                    .replace(IMConstants.SEND_FILE_PREFIX_SENDER, "")
                    .replace(Constants.SEND_FILE_SUFFIX_SENDER, "");
            fileExtension = fileExtension.split(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR)[0];
            if (!fileExtension.contains(".")) {
                return "Unknown";
            } else {
                fileExtension = fileExtension.substring(fileExtension.lastIndexOf('.')).replace(".", "").toLowerCase();
            }
            return fileExtension;
        }
    }
}
