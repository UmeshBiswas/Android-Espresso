package com.revesoft.itelmobiledialer.chat.tenor;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * @author Ifta on 10/29/2017.
 */

public class TenorGif {
    public int width = 128;
    public int height = 128;
    public int nanoWidth = 128;
    public int nanoHeight = 128;
    public String nanoGifUrl;
    public String tinyGifUrl;
    public String gifUrl;

    public boolean isPreview;

    public TenorGif() {
        isPreview = true;
    }

    TenorGif(JSONObject tenorObject) {
        try {
            isPreview = false;
            JSONArray dimension = tenorObject.getJSONArray("media").getJSONObject(0).getJSONObject("tinygif").getJSONArray("dims");
            this.width = dimension.getInt(0);
            this.height = dimension.getInt(1);
            JSONArray nanoDimension = tenorObject.getJSONArray("media").getJSONObject(0).getJSONObject("nanogif").getJSONArray("dims");
            this.nanoWidth = dimension.getInt(0);
            this.nanoHeight = dimension.getInt(1);
            this.nanoGifUrl = tenorObject.getJSONArray("media").getJSONObject(0).getJSONObject("nanogif").getString("url");
            this.tinyGifUrl = tenorObject.getJSONArray("media").getJSONObject(0).getJSONObject("tinygif").getString("url");
            this.gifUrl = tenorObject.getJSONArray("media").getJSONObject(0).getJSONObject("gif").getString("url");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "TenorGif{" +
                "width=" + width +
                ", height=" + height +
                ", nanoGifUrl='" + nanoGifUrl + '\'' +
                ", tinyGifUrl='" + tinyGifUrl + '\'' +
                ", gifUrl='" + gifUrl + '\'' +
                '}';
    }
}
