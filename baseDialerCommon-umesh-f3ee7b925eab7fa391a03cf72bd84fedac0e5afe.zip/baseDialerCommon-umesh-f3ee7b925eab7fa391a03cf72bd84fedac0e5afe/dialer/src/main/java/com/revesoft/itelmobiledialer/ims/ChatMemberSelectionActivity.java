package com.revesoft.itelmobiledialer.ims;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.dialer.ContactSelectionFragment;
import com.revesoft.itelmobiledialer.dialer.DashboardActivity;
import com.revesoft.itelmobiledialer.interfaces.SelectionActivity;
import com.revesoft.itelmobiledialer.interfaces.SelectionFragment;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta
 */

public class ChatMemberSelectionActivity extends BaseActivity implements SelectionActivity {
    public static void startForGroupCreationFromSingleChat(Context context, String numberOfCurrentChatUser) {
        Intent intent = new Intent(context, ChatMemberSelectionActivity.class);
        intent.putExtra("numberOfCurrentChatUser", numberOfCurrentChatUser);
        context.startActivity(intent);
    }

    private String numberOfCurrentChatUser;
    private boolean isSingleChatToGroupChatCreationAction = false;
    RecyclerView rvSelectedContacts;
    ImageView ivNext;
    SelectionAdapter adapter;
    Toolbar toolbar;
    LinearLayoutManager layoutManager;
    ArrayList<Contact> selectedItems = new ArrayList<Contact>();
    Fragment contactSelectionFragment;
    String[] existingMembersNumber;
    boolean isAddMoreMemberAction = false;
    boolean isSingleChatPersonSelection = false;
    CardView selectedPeopleHolder;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_member_selection_layout);
        LocalBroadcastManager.
                getInstance(getApplicationContext()).
                registerReceiver(broadcastReceiver, new IntentFilter(Constants.MESSAGE_INTENT_FILTER));
        if (getIntent().hasExtra(Constants.IMS.EXISTING_GROUP_MEMBER_NUMBERS)) {
            existingMembersNumber = getIntent().getStringArrayExtra(Constants.IMS.EXISTING_GROUP_MEMBER_NUMBERS);
            isAddMoreMemberAction = true;
        }
        if (getIntent().hasExtra("numberOfCurrentChatUser")) {
            numberOfCurrentChatUser = getIntent().getStringExtra("numberOfCurrentChatUser");
            isSingleChatToGroupChatCreationAction = true;
        }
        isSingleChatPersonSelection = getIntent().getBooleanExtra(Constants.Message.KEY_IS_SINGLE_CHAT, false);
        if (isSingleChatPersonSelection)
            findViewById(R.id.tv_chosen_contacts).setVisibility(View.GONE);
        handleToolbar();
        rvSelectedContacts = findViewById(R.id.rvSelectedPeople);
        ivNext = findViewById(R.id.fab);
        if (!isSingleChatToGroupChatCreationAction) {
            ivNext.setScaleX(0);
            ivNext.setScaleY(0);
        }
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rvSelectedContacts.setLayoutManager(layoutManager);
        adapter = new SelectionAdapter(this);
        rvSelectedContacts.setAdapter(adapter);
        selectedPeopleHolder = findViewById(R.id.selectedPeopleHolder);
        if (!isSingleChatToGroupChatCreationAction) {
            selectedPeopleHolder.setVisibility(View.GONE);
        }
        if (getIntent().hasExtra(Constants.IMS.ALREADY_PICKED_MEMBER_BEFORE_CREATION)) {
            Executor.ex(()->{
                Cursor cursor = ContactRepo.get().byProcessedNumbers(getIntent().getStringArrayExtra(Constants.IMS.ALREADY_PICKED_MEMBER_BEFORE_CREATION));
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        addItemToSelectionList(new Contact(Contact.ContactType.DATABASE_CONTACT_APP, cursor));
                    } while (cursor.moveToNext());
                }
            });

        }
        if (numberOfCurrentChatUser!=null && (isAddMoreMemberAction || !TextUtils.isDigitsOnly(numberOfCurrentChatUser))) {
            contactSelectionFragment = ContactSelectionFragment.newInstance(ContactSelectionFragment.ContactType.APP, existingMembersNumber, true);
        } else {
            contactSelectionFragment = ContactSelectionFragment.newInstance(ContactSelectionFragment.ContactType.APP, isSingleChatPersonSelection, true);
        }
        getSupportFragmentManager().beginTransaction().add(R.id.contactListHolder, contactSelectionFragment, ContactSelectionFragment.getTAG()).commit();
        ivNext.setOnClickListener(v -> {
            if (isSingleChatToGroupChatCreationAction) {
                if (selectedItems.size() <= 1) {
                    finish();
                } else {
                    Intent intent = new Intent(ChatMemberSelectionActivity.this, GroupChatCreationActivity.class);
                    String[] selectedMembersNumber = new String[selectedItems.size()];
                    for (int i = 0; i < selectedMembersNumber.length; i++) {
                        selectedMembersNumber[i] = selectedItems.get(i).processedNumber;
                    }
                    intent.putExtra(Constants.GroupChat.KEY_SELECTED_MEMBERS, selectedMembersNumber);
                    startActivity(intent);
                }
            } else if (isAddMoreMemberAction) {
                if (selectedItems.size() != 0) {
                    Intent resultIntent = new Intent();
                    ArrayList<String> selectedContactsNumber = new ArrayList<String>(selectedItems.size());
                    for (Contact contact : selectedItems) {
                        selectedContactsNumber.add(contact.phoneNumber);
                    }
                    resultIntent.putExtra(Constants.IMS.SELECTED_NUMBERS, selectedContactsNumber);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    I.toast(getString(R.string.noNewMemberSelected));
                    finish();
                }
            } else {
                if (selectedItems.size() == 0) {
                    Toast.makeText(ChatMemberSelectionActivity.this, getString(R.string.pleaseSelectOneContact), Toast.LENGTH_LONG).show();
                } else if (selectedItems.size() == 1) {
                    startSingleChat(selectedItems.get(0).phoneNumber);

                } else {
                    Intent intent = new Intent(ChatMemberSelectionActivity.this, GroupChatCreationActivity.class);
                    String[] selectedMembersNumber = new String[selectedItems.size()];
                    for (int i = 0; i < selectedMembersNumber.length; i++) {
                        selectedMembersNumber[i] = selectedItems.get(i).processedNumber;
                    }
                    intent.putExtra(Constants.GroupChat.KEY_SELECTED_MEMBERS, selectedMembersNumber);
                    startActivity(intent);
                }
            }
        });
        if(isSingleChatToGroupChatCreationAction){
            addItemToSelectionList(new Contact(numberOfCurrentChatUser));
        }
    }

    private void startSingleChat(String phoneNumber) {
        IntentUtil.sendStartIMSIntent(ChatMemberSelectionActivity.this,
                Util.translateNumber(phoneNumber, UserDataManager.getUserCountryCode()));
    }

    Dialog creatingGroupDialog = null;

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(broadcastReceiver);
        finish();

    }

    private void updateSelectedMemberNumberCountView() {
        if (getSupportActionBar() != null && contactSelectionFragment != null) {
            int totalContact = ((SelectionFragment) contactSelectionFragment).getTotalContactCount();
            String countMessage = selectedItems.size() + " " + getString(R.string.outOf) + " " + totalContact + " " + getString(R.string.selected);
            if (selectedItems.size() == 0) {
                getSupportActionBar().setSubtitle(null);
            } else {
                getSupportActionBar().setSubtitle(countMessage);
            }
        }
    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home_up);
            if (isAddMoreMemberAction) {
                getSupportActionBar().setTitle(getString(R.string.addAMember));
            } else {
                if (!isSingleChatPersonSelection)
                    getSupportActionBar().setTitle(getString(R.string.new_group));
                else
                    getSupportActionBar().setTitle(getString(R.string.newChat));
            }
        }
    }

    @Override
    public ArrayList<Contact> getSelectionList() {
        return selectedItems;
    }

    @Override
    public void removeItemFromSelectionList(Contact item) {
        if (isSingleChatToGroupChatCreationAction && numberOfCurrentChatUser.equals(item.processedNumber))
            return;
        if (selectedItems.size() == 1) {
            selectedPeopleHolder.setVisibility(View.GONE);
            ivNext.animate().scaleX(0).scaleY(0).setDuration(250);
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    getResources().getDimensionPixelSize(R.dimen.standard_48));
            params.setMargins(0, 0, 0, 0);
            params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        }
        selectedItems.remove(item);
        if (adapter != null) {
            adapter.swapData(selectedItems);
        }
        ((SelectionFragment) contactSelectionFragment).requestUpdateState();
        updateSelectedMemberNumberCountView();
    }

    @Override
    public void addItemToSelectionList(Contact item) {
        if (isSingleChatPersonSelection) {
            startSingleChat(item.phoneNumber);
            return;
        }
        if (selectedItems.size() == 0) {
            selectedPeopleHolder.setVisibility(View.VISIBLE);
            findViewById(R.id.tv_chosen_contacts).setVisibility(View.VISIBLE);
            ivNext.animate().scaleX(1).scaleY(1).setDuration(250);
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    getResources().getDimensionPixelSize(R.dimen.standard_48));
            params.setMargins(0, 0, 0, getResources().getDimensionPixelSize(R.dimen.appButtonHeight));
            params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        }
        selectedItems.add(item);

        if (adapter != null) {
            adapter.swapData(selectedItems);
        }
        updateSelectedMemberNumberCountView();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    class SelectionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int ITEM_VIEW = 5000;
        ArrayList<Contact> items = new ArrayList<Contact>();
        Context context;

        private SelectionAdapter(Context context) {
            this.context = context;
        }

        public void swapData(ArrayList<Contact> selectedItems) {
            items.clear();
            items.addAll(selectedItems);
            notifyDataSetChanged();
        }


        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v;
            if (viewType == ITEM_VIEW) {
                v = LayoutInflater.from(context).inflate(R.layout.selected_contact_single_item, parent, false);
                return new ViewHolder(v);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ViewHolder vh = (ViewHolder) holder;
            final int currentPosition = position;
            ImageView ivRemoveSelection = vh.itemView.findViewById(R.id.ivRemoveSelection);
            ivRemoveSelection.setOnClickListener(v -> removeItemFromSelectionList(items.get(currentPosition)));
            vh.bindView();
        }


        @Override
        public int getItemCount() {
            return items.size();
        }

        @Override
        public int getItemViewType(int position) {
            return ITEM_VIEW;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivPhoneContactImage;

            private ViewHolder(View itemView) {
                super(itemView);
                ivPhoneContactImage = itemView.findViewById(R.id.ivPhoneContactImage);

            }

            public void bindView() {
                ImageUtil.setImageButTextImageOnException(ChatMemberSelectionActivity.this, selectedItems.get(getAdapterPosition()).imageUri, ivPhoneContactImage, selectedItems.get(getAdapterPosition()).name);
            }
        }
    }


    String groupId = "";
    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(DashboardActivity.GROUP_CREATED)) {
                    groupId = bag.getString(DashboardActivity.GROUP_CREATED);
                    if (creatingGroupDialog != null) {
                        creatingGroupDialog.dismiss();
                    }
                    Intent groupDetailsIntent = new Intent(context.getApplicationContext(), GroupDetailsActivity.class);
                    groupDetailsIntent.putExtra(Constants.IMS.GROUP_ID, groupId);
                    groupDetailsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(groupDetailsIntent);
                }
            }
        }
    };
}
