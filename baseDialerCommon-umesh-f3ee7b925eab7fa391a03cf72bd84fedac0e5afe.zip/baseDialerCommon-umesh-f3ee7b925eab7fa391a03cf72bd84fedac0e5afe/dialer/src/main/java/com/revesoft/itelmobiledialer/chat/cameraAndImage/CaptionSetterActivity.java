package com.revesoft.itelmobiledialer.chat.cameraAndImage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.revesoft.itelmobiledialer.Config.Features;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.futureMessage.FutureMessageTimeDialogs;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.FutureMessageDateTimeListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageQuoteInfo;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.chat.chatWindow.supportiveActivities.FullScreenImageGalleryActivity;
import com.revesoft.itelmobiledialer.customview.SquareImageView;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 1/1/2018.
 */

public class CaptionSetterActivity extends BaseActivity {
    private int currentSelectedPosition = 0;
    public static final String KEY_FILE_PATH_LIST = "KEY_FILE_PATH_LIST";
    ArrayList<CaptionMedia> captionMediaList = new ArrayList<>();
    RecyclerView recyclerView;
    ImageView ivAddMore;
    ImageView ivCurrentImagePreview;
    ImageStripeAdapter imageStripeAdapter;
    EditText etCaption;
    ImageView ivSend;
    ImageView ivSendInFuture;
    ImageView ivVideoIndicator;

    public static void start(Activity activity) {
        Intent intent = new Intent(activity, CaptionSetterActivity.class);
        activity.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        readData();
        setContentView(R.layout.caption_setter_activity);
        initViews();
        handleRecyclerView();
        handleAddMoreButton();
        setUpForCurrentSelectedPosition();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setContentView(R.layout.caption_setter_activity);
        initViews();
        readData();
        handleRecyclerView();
        handleAddMoreButton();
        setUpForCurrentSelectedPosition();
    }

    private void initViews() {
        ivAddMore = findViewById(R.id.ivAddMore);
        ivVideoIndicator = (ImageView) findViewById(R.id.ivVideoIndicator);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        ivCurrentImagePreview = (ImageView) findViewById(R.id.ivCurrentImagePreview);
        ivCurrentImagePreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String filePath = captionMediaList.get(currentSelectedPosition).filePath;
                if (isImage(filePath)) {
                    Switcher.switchToImagePreview(filePath);
                } else {
                    Switcher.switchToVideoPreview(filePath);
                }
            }
        });
        etCaption = findViewById(R.id.etCaption);
        ivSend = findViewById(R.id.ivSend);
        ivSendInFuture = findViewById(R.id.ivSendInFuture);
        if (MessageQuoteInfo.isInQuoteMode) {
            ivSendInFuture.setVisibility(View.GONE);
        } else {
            if (Features.hasFutureMessage()) {
                ivSendInFuture.setVisibility(View.VISIBLE);
            }else {
                ivSendInFuture.setVisibility(View.GONE);
            }
        }
        ivSend.setOnClickListener(v -> {
            setCaptionForCurrentPosition();
            for (CaptionMedia captionMedia : captionMediaList) {
                Sender.getAccess().sendFile(captionMedia.filePath, captionMedia.caption);
            }
            finish();
        });

        ivSendInFuture.setOnClickListener(v -> {
            setCaptionForCurrentPosition();
            FutureMessageTimeDialogs.showDateTimePicker(CaptionSetterActivity.this, new FutureMessageDateTimeListener() {
                @Override
                public void onDateTimePicked(Date formattedDateTime, boolean sendCurrentTimeStamp) {
                    for (CaptionMedia captionMedia : captionMediaList) {
                        Sender.getAccess().sendFutureFile(captionMedia.filePath, captionMedia.caption, formattedDateTime.getTime(), sendCurrentTimeStamp);
                    }
                    finish();
                }
            });
        });

        etCaption.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > Constants.MAX_CAPTION_LENGTH) {
                    etCaption.setText(s.toString().substring(0, Constants.MAX_CAPTION_LENGTH));
                    etCaption.setSelection(etCaption.getText().toString().length());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void handleAddMoreButton() {
        ivAddMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> currentList = new ArrayList<>();
                for (CaptionMedia captionMedia : captionMediaList) {
                    currentList.add(captionMedia.filePath);
                }
                Intent intent = new Intent(CaptionSetterActivity.this, FullScreenImageGalleryActivity.class);
                intent.putStringArrayListExtra(FullScreenImageGalleryActivity.KEY_ALREADY_SELECTED_FILE_PATHS, currentList);
                startActivity(intent);
                finish();
            }
        });
    }

    private void handleRecyclerView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        imageStripeAdapter = new ImageStripeAdapter();
        recyclerView.setAdapter(imageStripeAdapter);
    }

    private void readData() {
        for (String filePath : SelectedMediaDataHolder.getAll()) {
            if (!containsPath(filePath)) {
                captionMediaList.add(new CaptionMedia(filePath, ""));
            }
        }
        List<CaptionMedia> toBeRemoved = new ArrayList<>();
        for (CaptionMedia captionMedia : captionMediaList) {
            if (!SelectedMediaDataHolder.contains(captionMedia.filePath)) {
                toBeRemoved.add(captionMedia);
            }
        }
        captionMediaList.removeAll(toBeRemoved);
    }

    private boolean containsPath(String path) {
        for (CaptionMedia captionMedia : captionMediaList) {
            if (captionMedia.filePath.equals(path)) return true;
        }
        return false;
    }

    private void setUpForCurrentSelectedPosition() {
        etCaption.setText(captionMediaList.get(currentSelectedPosition).caption);
        etCaption.setSelection(etCaption.getText().length());
        Glide.with(CaptionSetterActivity.this)
                .load(captionMediaList.get(currentSelectedPosition).filePath)
                .placeholder(R.drawable.loader_animation)
                .centerCrop()
                .crossFade()
                .error(R.drawable.ic_broken_file)
                .into(ivCurrentImagePreview);
        if (isImage(captionMediaList.get(currentSelectedPosition).filePath)) {
            ivVideoIndicator.setVisibility(View.GONE);
        } else {
            ivVideoIndicator.setVisibility(View.VISIBLE);
        }
    }

    private class ImageStripeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_stripe_single_item, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ((ViewHolder) holder).bindView(position);
        }

        @Override
        public int getItemCount() {
            return captionMediaList.size();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {
            SquareImageView ivPreview;
            ImageView ivVideoIndicator;

            public ViewHolder(View itemView) {
                super(itemView);
                ivPreview = itemView.findViewById(R.id.ivPreview);
                ivVideoIndicator = itemView.findViewById(R.id.ivVideoIndicator);
            }

            public void bindView(final int position) {
                if (captionMediaList != null && captionMediaList.size() > 0) {
                    final String filePath = captionMediaList.get(position).filePath;
                    Glide.with(CaptionSetterActivity.this)
                            .load(filePath)
                            .placeholder(R.drawable.loader_animation)
                            .centerCrop()
                            .crossFade()
                            .error(R.drawable.invalid_image_file)
                            .into(ivPreview);
                    if (isImage(filePath)) {
                        ivVideoIndicator.setVisibility(View.GONE);
                    } else {
                        ivVideoIndicator.setVisibility(View.VISIBLE);
                    }
                    ivPreview.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            setCaptionForCurrentPosition();
                            currentSelectedPosition = position;
                            setUpForCurrentSelectedPosition();
                        }
                    });
                }
            }


        }
    }

    private void setCaptionForCurrentPosition() {
        String caption = etCaption.getText().toString().trim();
        if (!TextUtils.isEmpty(caption)) {
            captionMediaList.get(currentSelectedPosition).caption = caption;
            etCaption.setText(null);
        }
    }

    private boolean isImage(String filePath) {
        I.log("isImage file path = " + filePath);
        if (filePath.contains(".")) {
            String toBeSearched = filePath.substring(filePath.lastIndexOf(".") + 1, filePath.length());
            I.log("toBeSearched = " + toBeSearched);
            I.log(toBeSearched);
            for (String item : IMAGE_FILE_FORMAT) {
                if (item.equals(toBeSearched)) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }

    private static final String[] IMAGE_FILE_FORMAT = {"jpg", "jpeg", "png", "bmp", "tiff", "jfif", "webp"};

    @Override
    protected void onPause() {
        super.onPause();
    }
}

