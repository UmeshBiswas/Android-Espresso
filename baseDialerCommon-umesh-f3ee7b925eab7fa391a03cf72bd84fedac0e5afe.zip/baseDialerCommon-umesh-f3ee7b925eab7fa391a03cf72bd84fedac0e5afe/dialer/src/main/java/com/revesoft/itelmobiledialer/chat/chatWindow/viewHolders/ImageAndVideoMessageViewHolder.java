package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.view.View;
import android.widget.ImageView;

import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.util.Log;
import com.revesoft.material.R;

/**
 * @author Ifta on 12/17/2017.
 */

public class ImageAndVideoMessageViewHolder extends MediaMessageViewHolder {
    private ImageView ivPlayButton;

    public ImageAndVideoMessageViewHolder(View view) {
        super(view);
        ivPlayButton = (ImageView) view.findViewById(R.id.ivPlayButton);
    }

    public void bindView(Message message) {
        super.bindView(message);
        Log.i("Message_delivery_status",message.deliveryStatus+"");
        if (message.mimeType == MimeType.Video) {
            ivPlayButton.setVisibility(View.VISIBLE);
        } else {
            ivPlayButton.setVisibility(View.GONE);
        }
    }


}
