package com.revesoft.itelmobiledialer.backup;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.revesoft.itelmobiledialer.util.Constants;


/**
 * @author ashikee and Ifta on 8/9/17.
 */

public class AutoBackupAlarmSetAfterBootBroadCastReceiver extends BroadcastReceiver {
    private PendingIntent pendingIntentAutoBackupService;
    @Override
    public void onReceive(Context context, Intent intent) {

        SharedPreferences preferences = context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Context.MODE_PRIVATE);
        int position =  preferences.getInt(Constants.AUTO_BACKUP_SELECTION_POSITION, Constants.AUTO_BACKUP_POSITION_DEF);
        pendingIntentAutoBackupService = PendingIntent.getService(context,0,new Intent(context, AutoBackupService.class),0);
        if(position == 0)
            setDailyAlarm(context);
        if(position == 1)
            setWeeklyAlarm(context);
        if(position == 2)
            setMonthlyAlarm(context);
        if(position == 4)
            cancelAlarm(context);
    }


    private void cancelAlarm(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pendingIntentAutoBackupService);
    }

    private void setDailyAlarm(Context context) {

        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        long interval = AlarmManager.INTERVAL_DAY;
//        int interval = 20000;
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntentAutoBackupService);
        Log.d("BackupGooGleDrive", "Daily Backup set");
    }
    private void setWeeklyAlarm(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        long interval = AlarmManager.INTERVAL_DAY*7;
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntentAutoBackupService);
        Log.d("BackupGooGleDrive", "Weekly Backup set");

    }
    private void setMonthlyAlarm(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        long interval =AlarmManager.INTERVAL_DAY*30;
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntentAutoBackupService);
        Log.d("BackupGooGleDrive", "Monthly Backup set");

    }
}
