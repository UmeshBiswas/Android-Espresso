package com.revesoft.itelmobiledialer.appDatabase;


public class PrepareContact {
//    public static void processContacts(){
//
//    }
//
//
//    private synchronized static void reloadContactTable(){
//        String query="initialize table if not exists  contacts_temp (" +
//                "_id integer primary key autoincrement, " +
//                "number text not null, " +
//                "name text, " +
//                "lookup_key text not null, " +
//                "contact_id text not null, " +
//                "photo_uri text default null, " +
//                "processed_number text , " +
//                "is_favourite integer)";
//        SDKDatabase.get().rawQuery(query);
//    }
//
//
//    private static void processContactsWithEmails() {
//        try {
////            logger.log("processContactsWithEmails tid = " + Long.toHexString(Thread.currentThread().getId()));
//            Cursor cursor = Database.getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null, null, null, null);
////            if (cursor == null) {
////                return;
////            }
//            int CHUNK_SIZE = 2000;
//            long WAIT_TIME = 10;
//            int startFrom = 0, endAt = CHUNK_SIZE;
//            int dataProcessedCount = 0;
//            do {
//                try {
////                        writableDatabase.beginTransaction();
//                    dataProcessedCount = processContactChunkWithEmail(cursor, startFrom, endAt);
////                        writableDatabase.setTransactionSuccessful();
////                        writableDatabase.endTransaction();
//                    startFrom += dataProcessedCount;
//                    endAt = startFrom + CHUNK_SIZE;
//                    if (dataProcessedCount != 0) {
//                        XUriChangeNotifier.notify(XUriChangeNotifier.UriType.CONTACT);
//                        if (dataProcessedCount % CHUNK_SIZE == 0) {
//                            Thread.sleep(WAIT_TIME);
//                        }
//                    }
//                } catch (Exception e) {
////                    logger.log(e.getLocalizedMessage());
//                }
//            } while (dataProcessedCount != 0);
//            if (!cursor.isClosed()) {
//                cursor.close();
//            }
//        } catch (Exception e) {
////            logger.log(e.getLocalizedMessage());
//        }
//    }
//
//    private static void processContactsWithNumbers() {
//        try {
//            logger.log("processContacts tid = " + Long.toHexString(Thread.currentThread().getId()));
//            Cursor cursor = Database.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
//                    ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER + "=?", new String[]{"1"}, null);
//            if (cursor == null) {
//                return;
//            }
//            int CHUNK_SIZE = 2000;
//            long WAIT_TIME = 10;
//            int startFrom = 0, endAt = CHUNK_SIZE;
//            int dataProcessedCount = 0;
//            do {
//                try {
////                        writableDatabase.beginTransaction();
//                    dataProcessedCount = processContactChunk(cursor, startFrom, endAt);
////                        writableDatabase.setTransactionSuccessful();
////                        writableDatabase.endTransaction();
//                    startFrom += dataProcessedCount;
//                    endAt = startFrom + CHUNK_SIZE;
//                    if (dataProcessedCount != 0) {
//                        XUriChangeNotifier.notify(XUriChangeNotifier.UriType.CONTACT);
//                        if (dataProcessedCount % CHUNK_SIZE == 0) {
//                            Thread.sleep(WAIT_TIME);
//                        }
//                    }
//                } catch (Exception e) {
////                    logger.log(e.getLocalizedMessage());
//                }
//            } while (dataProcessedCount != 0);
//            if (!cursor.isClosed()) {
//                cursor.close();
//            }
//        } catch (Exception e) {
////            logger.log(e.getLocalizedMessage());
//        }
//    }
//
//    private static int processContactChunk(Cursor cursor, int startFrom, int endAt) {
////        logger.log("processContactChunk: startFrom = " + startFrom + " endAt = " + endAt);
//        String sql = "INSERT INTO " + CONTACTS_TABLE_TEMP + " (number, name, lookup_key, contact_id, photo_uri, is_favourite, processed_number) VALUES (?, ?, ?, ?, ?, ?, ?)";
//        SQLiteStatement stmt = writableDatabase.compileStatement(sql);
//        int dataProcessedCount = 0;
//        String translatedNumber;
//        String number;
//        String name;
//        String lookup_key;
//        String contact_id;
//        int is_favourite;
//        String photoPath;
//        if (cursor.moveToPosition(startFrom)) {
//            do {
//                try {
//                    //insert contact
//                    number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
//                    name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
//                    lookup_key = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY));
//                    contact_id = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
//                    is_favourite = cursor.getInt(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED));
//
//                    photoPath = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI));
//                    if (number.contains("160137")) {
////                        logger.log(" >>>>>>>>>>>>>>>>>>> number found" + number);
//                    }
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//                        number = PhoneNumberUtils.formatNumber(number, Locale.getDefault().getCountry());
//                    } else {
//                        number = PhoneNumberUtils.formatNumber(number);
//                    }
//
//                    if (number == null) {
//                        number = "";
//                    }
//
//                    stmt.bindString(1, number);
//                    stmt.bindString(2, name);
//                    stmt.bindString(3, lookup_key);
//                    stmt.bindString(4, contact_id);
//                    if (photoPath == null) {
//                        stmt.bindString(5, "");
//                    } else {
//                        stmt.bindString(5, photoPath);
//                    }
//                    stmt.bindLong(6, is_favourite);
//
//                    if (Util.isValidNumber(number)) {
//                        translatedNumber = Util.translateNumber(number);
//                    } else {
//                        translatedNumber = number;
//                    }
//                    stmt.bindString(7, translatedNumber);
//                    stmt.execute();
//                    stmt.clearBindings();
//                } catch (Exception e) {
////                    logger.log(e.getLocalizedMessage());
//                }
//                dataProcessedCount++;
//            } while (cursor.moveToNext() && dataProcessedCount < endAt);
//            stmt.close();
//        } else {
////            logger.log("moving to " + startFrom + " has been failed");
//        }
//
//        return dataProcessedCount;
//    }
//
//
//    private static int processContactChunkWithEmail(Cursor cursor, int startFrom, int endAt) {
////        logger.log("processContactChunkWithEmail: startFrom = " + startFrom + " endAt = " + endAt);
//        String sql = "INSERT INTO  " + CONTACTS_TABLE_TEMP + "  (number, name, lookup_key, contact_id, photo_uri, is_favourite, processed_number) VALUES (?, ?, ?, ?, ?, ?, ?)";
//        SQLiteStatement stmt = writableDatabase.compileStatement(sql);
//        int dataProcessedCount = 0;
//        String translatedEmail;
//        String email;
//        String name;
//        String lookup_key;
//        String contact_id;
//        int is_favourite;
//        String photoPath;
//        if (cursor.moveToPosition(startFrom)) {
////            logger.log(cursor);
//            do {
//                try {
//                    //insert contact
//                    email = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS));
//                    name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DISPLAY_NAME_PRIMARY));
//                    lookup_key = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.LOOKUP_KEY));
//                    contact_id = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.CONTACT_ID));
//                    is_favourite = cursor.getInt(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.STARRED));
//
//                    photoPath = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.PHOTO_URI));
//
//                    if (!TextUtils.isEmpty(email) && Util.isValidEmail(email)) {
//                        stmt.bindString(1, email);
//                        stmt.bindString(2, name);
//                        stmt.bindString(3, lookup_key);
//                        stmt.bindString(4, contact_id);
//                        if (photoPath == null) {
//                            stmt.bindString(5, "");
//                        } else {
//                            stmt.bindString(5, photoPath);
//                        }
//                        stmt.bindLong(6, is_favourite);
//
//
//                        translatedEmail = Util.translateNumber(email);
//                        stmt.bindString(7, translatedEmail);
//                        stmt.execute();
//                        stmt.clearBindings();
//                    }
//                } catch (Exception e) {
////                    logger.log(e.getLocalizedMessage());
//                }
//                dataProcessedCount++;
//            } while (cursor.moveToNext() && dataProcessedCount < endAt);
//            stmt.close();
//        } else {
////            logger.log("moving to " + startFrom + " has been failed");
//        }
//
//        return dataProcessedCount;
//    }
//}
}
