package com.revesoft.itelmobiledialer.chat.chatWindow.helper;

import com.google.android.gms.maps.model.LatLng;
import com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TaggedLogger;

import ezvcard.VCard;
import ezvcard.property.Email;
import ezvcard.property.Telephone;

/**
 * @author Ifta on 12/14/2017.
 */

public class ChatContentParser {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");

    public static String parseGifUrl(String content) {
        String strippedContent = content.replace(Constants.GIF_PREFIX, "").replace(Constants.GIF_SUFFIX, "");
        String[] data = strippedContent.split(Constants.SEPARATOR);
        if (data.length < 3) {
            return null;
        } else {
            return data[2].replace(Constants.LINK, "");
        }
    }


    public static String parseStickerUrl(String content) {
        String strippedContent = content.replace(Constants.STICKER_PREFIX, "").replace(Constants.STICKER_SUFFIX, "");
        String[] data = strippedContent.split(Constants.SEPARATOR);
        if (data.length < 3) {
            return null;
        } else {
            return data[2].replace(Constants.LINK, "");
        }
    }

    static String parseCallRejectStickerFileName(String content) {
        return content.replace(Constants.CALL_REJECT_STICKER_PREFIX, "").replace(Constants.CALL_REJECT_STICKER_SUFFIX, "");
    }

    public static String parseCaption(String content) {
        final String CAPTION_HOLDER_START = "caption{{";
        final String CAPTION_HOLDER_END = "}}";
        String caption = "";
        try {
            if ((content.startsWith(IMConstants.SEND_FILE_PREFIX) || content.startsWith(IMConstants.SEND_FILE_PREFIX_SENDER))/* && content.endsWith(Constants.SEND_FILE_SUFFIX)*/) {
                if (content.contains(IMConstants.SEND_FILE_PREFIX_SENDER)) {
                    if (content.contains(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR)) {
                        caption = content
                                .substring(content.indexOf(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR))
                                .replace(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR, "")
                                .replace(Constants.SEND_FILE_SUFFIX_SENDER, "");
//                    I.log("caption after 1st strip >>>> " + caption);

                    } else {
                        caption = "";
//                    I.log("caption after 1st strip >>>> cation nai ");
                    }

                } else {
                    caption = content.substring(content.indexOf(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR))
                            .replace(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR, "");
                    //            I.log("caption after 1st strip = " + caption);
                    if (caption.contains(CAPTION_HOLDER_START)) {
                        caption = caption.substring(0, caption.indexOf(CAPTION_HOLDER_END)).replace(CAPTION_HOLDER_START, "");
//                I.log("caption after 2nd strip = " + caption);
                    } else {
                        caption = caption.replace(IMConstants.SEND_FILE_SUFFIX, "");
//                I.log("caption after 2nd strip = " + caption);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return caption;
    }

    public static LatLng parseLocation(String content) {
        LatLng latLng = null;
        String loc = content.replace(Constants.LOCATION_PREFIX, "")
                .replace(Constants.LS_SUFIX, "");
        String[] arr = loc.split(",");
        double latitude, longitude;
        try {
            if (arr.length >= 2) {
                latitude = Double.parseDouble(arr[0].trim());
                longitude = Double.parseDouble(arr[1].trim());
                latLng = new LatLng(latitude, longitude);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return latLng;
    }

    public static CallType parseCallType(String content) {
        String[] data = content.replace(Constants.Call.MISSED_CALL_MESSAGE_PREFIX, "")
                .replace(Constants.Call.MISSED_CALL_MESSAGE_SUFFIX, "")
                .split(Constants.Call.CALL_TYPE_SEPARATORS_IN_MESSAGE);
        if (data.length > 0) {
            if (data[0].equals(Constants.Call.AUDIO_CALL_TYPE)) {
                return CallType.AUDIO;
            }
            return CallType.VIDEO;
        }
        return null;
    }

    public static String parseCallerNumber(String content) {
        String[] data = content.replace(Constants.Call.MISSED_CALL_MESSAGE_PREFIX, "")
                .replace(Constants.Call.MISSED_CALL_MESSAGE_SUFFIX, "")
                .split(Constants.Call.CALL_TYPE_SEPARATORS_IN_MESSAGE);
        if (data.length > 1) {
            return data[1];
        }
        return null;
    }

    public static String parseFilePath(String content) {
        if (content.contains(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR)) {
            content = content.split(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR)[0];
        }
        return content.replace(IMConstants.SEND_FILE_PREFIX_SENDER, "")
                .replace(IMConstants.SEND_FILE_SUFFIX, "")
                .replace(IMConstants.SEND_FILE_PREFIX, "")
                .replace(Constants.SEND_FILE_SUFFIX_SENDER, "")
                .trim();
    }

    public static String parseAddress(String content) {
        String loc = content.replace(Constants.LOCATION_PREFIX, "")
                .replace(Constants.LS_SUFIX, "");
        String[] arr = loc.split(",");
        StringBuilder address = new StringBuilder();
        try {
            if (arr.length >= 2) {
                for (int i = 2; i < arr.length; i++) {
                    address.append(arr[i]);
                    if (i < arr.length - 1) {
                        address.append(",");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return address.toString();
    }

    public static boolean parseLocationRequestActionNeed(String content) {
        if (content.contains("askLocationUsed")) {
            return false;
        } else if (content.contains("askLocationRejected")) {
            return false;
        } else if (content.contains("askLocationAccepted")) {
            return false;
        } else if (content.contains("askLocationInvalid")) {
            return false;
        }
        return true;
    }

    public static String parseStaticStickerFileName(String content) {
        return content.replace(Constants.STATIC_STICKER_PREFIX, "").replace(Constants.STATIC_STICKER_SUFFIX, "");
    }

    public static int parseGifWidth(String content) {
        //animated_gif:{{w=220;h=124;LINK=https://media.tenor.com/images/a1687f1b66f5b4f5d31f3ff8c70cd7d2/tenor.gif}}
        int width = -1;
        String strippedContent = content.replace(Constants.GIF_PREFIX, "").replace(Constants.GIF_SUFFIX, "");
        String[] data = strippedContent.split(Constants.SEPARATOR);
        if (data.length > 0) {
            try {
                width = Integer.parseInt(data[0].replace(Constants.WIDTH, ""));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return width;
    }
    public static int parseGifHeight(String content) {
        //animated_gif:{{w=220;h=124;LINK=https://media.tenor.com/images/a1687f1b66f5b4f5d31f3ff8c70cd7d2/tenor.gif}}
        int height = -1;
        String strippedContent = content.replace(Constants.GIF_PREFIX, "").replace(Constants.GIF_SUFFIX, "");
        String[] data = strippedContent.split(Constants.SEPARATOR);
        if (data.length > 1) {
            try {
                height = Integer.parseInt(data[1].replace(Constants.HEIGHT, ""));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return height;
    }

    public static class VCardParser {
        public static String parseNameFromVCard(VCard vCard) {
            try {
                return vCard.getFormattedName().getValue();
            } catch (Exception e) {
                e.printStackTrace();
                logger.log(e.getLocalizedMessage());
            }
            logger.log("parsing contact name failed");
            return null;
        }

        public static String parseNumber(VCard vCard) {
            StringBuilder numbers = new StringBuilder();
            for (Telephone tel : vCard.getTelephoneNumbers()) {
                numbers.append(tel.getText());
                numbers.append("\n");
            }
            return numbers.toString();
        }

        public static String parseEmail(VCard vCard) {
            StringBuilder emails = new StringBuilder();
            for (Email email : vCard.getEmails()) {
                emails.append(email.getValue());
                emails.append("\n");
            }
            return emails.toString();
        }

        public static byte[] parseImage(VCard vCard) {
            if (vCard.getPhotos() != null && vCard.getPhotos().size() > 0) {
                byte[] data = vCard.getPhotos().get(0).getData();
                if (data != null) {
                    return data;
                } else {
                    logger.log("parseImage null data");
                }
            }
            logger.log("parsing contact image failed");
            return null;
        }
    }
}
