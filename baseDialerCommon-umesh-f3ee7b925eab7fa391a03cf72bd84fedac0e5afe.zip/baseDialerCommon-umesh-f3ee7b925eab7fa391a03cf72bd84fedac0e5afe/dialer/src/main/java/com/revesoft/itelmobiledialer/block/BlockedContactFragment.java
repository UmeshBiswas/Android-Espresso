package com.revesoft.itelmobiledialer.block;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.BlockRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.interfaces.AddRequestListener;
import com.revesoft.itelmobiledialer.interfaces.Searchable;
import com.revesoft.itelmobiledialer.processor.contactblock.ContactBlockHelper;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.SwapDeleteWizard;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.xdatabase.DatabaseUris;
import com.revesoft.itelmobiledialer.xdatabase.XTableKeys;
import com.revesoft.material.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta
 */

public class BlockedContactFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>, Searchable, AddRequestListener {
    public static final String TAG = "BlockedContactFragment";
    private static final int LOADER_ID = 150;
    RecyclerView rv;
    RecyclerView.LayoutManager layoutManager;
    LinearLayout nothingIsHereHolder;
    LinearLayoutManager llm;
    BlockedListAdapter adapter;


    public BlockedContactFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.simple_contact_holder_layout, container, false);
        rv = v.findViewById(R.id.rv);
        initEmptyListLayout(v);
        layoutManager = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(layoutManager);
        llm = (LinearLayoutManager) rv.getLayoutManager();
        adapter = new BlockedListAdapter(getActivity());
        rv.setAdapter(adapter);
        v.setFocusableInTouchMode(true);
        v.requestFocus();
        getLoaderManager().initLoader(LOADER_ID, null, this);
        IntentFilter filter = new IntentFilter(Constants.DASHBOARD_INTENT_FILTER);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(broadcastReceiver, filter);
        return v;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(broadcastReceiver);
    }


    private void initEmptyListLayout(View v) {
        nothingIsHereHolder = v.findViewById(R.id.llEmptyListHolder);
        TextView tvEmptyListDescription = v.findViewById(R.id.tvEmptyListDescription);
        ImageView ivEmptyListIcon = v.findViewById(R.id.ivEmptyListIcon);
        tvEmptyListDescription.setText(getString(R.string.noContactInBlockList));
        ivEmptyListIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.ic_big_no_contact));
    }

    @Override
    public void onResume() {
        super.onResume();
//        if (getView() != null) {
//            if (isSelectionMode) {
//                switchToIndexViewMode();
//            }
//            getView().setFocusableInTouchMode(true);
//            getView().requestFocus();
//            getView().setOnKeyListener(new View.OnKeyListener() {
//                @Override
//                public boolean onKey(View v, int keyCode, KeyEvent event) {
//
//                    if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
//                        if (isSelectionMode) {
//                            switchToIndexViewMode();
//                        } else {
//                            parentActivity.onControlRequest(ControlRequestType.SWITCH_TO_FIRST_TAB);
//                        }
//                        return true;
//                    }
//                    return false;
//                }
//            });
//        }
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        if (id == LOADER_ID) {
            return new SQLiteCursorLoader(getActivity()) {
                @Override
                public Cursor loadInBackground() {
                    Cursor cursor;
                    try {
                        cursor = BlockRepo.get().getAllBlockContactBySearch(searchText);
                        if (cursor != null && cursor.moveToFirst()) {
                            this.registerContentObserver(cursor, DatabaseUris.BLOCK_URI);
                            return cursor;
                        } else {
                            return null;
                        }
                    } catch (SQLiteException ex) {
                        ex.printStackTrace();
                    }
                    return null;
                }
            };

        }
        return null;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (loader.getId() == LOADER_ID) {
//            I.log("onLoadFinished ALL_CONTACTS_LOADER");
            if (data != null && data.getCount() != 0) {
                hideEmptyViewMessage();
                if (data.moveToFirst() && data.getCount() > 0) {
                    if (adapter != null) {
                        adapter.swapCursor(data);
                    }
                }
            } else {
                if (adapter != null) {
                    adapter.swapCursor(null);
                }
                showEmptyViewMessage();
            }
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    @Override
    public void onDestroyView() {
        getLoaderManager().destroyLoader(LOADER_ID);
        super.onDestroyView();
    }


    private void showEmptyViewMessage() {
        nothingIsHereHolder.setVisibility(View.VISIBLE);
    }

    private void hideEmptyViewMessage() {
        nothingIsHereHolder.setVisibility(View.GONE);
    }

    @Override
    public void search(String searchString) {
        this.searchText = searchString;
        getLoaderManager().restartLoader(LOADER_ID, null, this);
    }

    @Override
    public void onAddRequest() {
        Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
        intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
        getActivity().startActivity(intent);
    }

    private class BlockedListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements SwapDeleteWizard.SwapDeletableAdapter {
        private static final int ITEM_VIEW = 5000;
        Cursor dataCursor = null;
        Context context;

        BlockedListAdapter(Context context) {
            this.context = context;
        }

        protected void swapCursor(Cursor cursor) {
            dataCursor = cursor;
            notifyDataSetChanged();
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v;
            if (viewType == ITEM_VIEW) {
                v = LayoutInflater.from(context).inflate(R.layout.blocked_contact_signle_item, parent, false);
                return new ViewHolder(v);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            final int pos = position;
            ViewHolder vh = (ViewHolder) holder;
            vh.itemView.findViewById(R.id.mainContent).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dataCursor.moveToPosition(pos);
                    String lookUpKey = dataCursor.getString(dataCursor.getColumnIndex(XTableKeys.KEY_PHONE_LOOKUP));
                    if (lookUpKey == null) {
                        I.toast("No look up key found");
                    } else {
                        Intent i = new Intent(getActivity(), ContactDetailsActivity.class);
                        i.putExtra(Constants.Contact.KEY_LOOKUP_KEY, lookUpKey);
                        startActivity(i);
                    }
                }
            });
            vh.itemView.findViewById(R.id.mainContent).setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
//                    switchToSelectionViewMode();
//                    makeCurrentLongPressedItemSelected(pos);
                    return true;
                }
            });
            vh.bindView();
        }

        @Override
        public int getItemCount() {
            if (dataCursor == null || dataCursor.isClosed()) {
                showEmptyViewMessage();
                return 0;
            }
            hideEmptyViewMessage();
            return dataCursor.getCount();
        }

        @Override
        public int getItemViewType(int position) {
            return ITEM_VIEW;
        }

        @Override
        public void remove(int position) {
            dataCursor.moveToPosition(position);
            final String lookupKey = dataCursor.getString(dataCursor.getColumnIndex(XTableKeys.KEY_PHONE_LOOKUP));
            String name = dataCursor.getString(dataCursor.getColumnIndex(XTableKeys.KEY_NAME));
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("Delete Contact");
            builder.setMessage("Are you sure you want to delete contact information of " + name);
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    Executor.ex(()->{
                        ContactRepo.get().deleteContactByLookUpKey(lookupKey);
                        Uri uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, lookupKey);
                        Gui.get().run(()->{
                            getActivity().getContentResolver().delete(uri, null, null);
                        });

                    });


//                    getActivity().runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            adapter.notifyDataSetChanged();
//                        }
//                    });
                    dialog.dismiss();
                }
            });
            builder.setNegativeButton("Never Mind", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            notifyDataSetChanged();
                        }
                    });
                    dialog.dismiss();
                }
            });
            builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    adapter.notifyDataSetChanged();
                }
            });
            builder.create().show();
        }


        class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivPhoneContactImage;
            TextView tvName, tvPhoneNumber;
            TextView tvUnblock;

            private ViewHolder(View itemView) {
                super(itemView);
                ivPhoneContactImage = itemView.findViewById(R.id.ivPhoneContactImage);
                tvName = itemView.findViewById(R.id.tvNameOfQuotee);
                tvPhoneNumber = itemView.findViewById(R.id.tvPhoneNumber);
                tvUnblock = itemView.findViewById(R.id.tvUnblock);
            }

            public void bindView() {
                if (dataCursor == null) {
                    return;
                }
                try {
                    int position = getAdapterPosition();
                    dataCursor.moveToPosition(position);
                    PhoneBuddy phoneBuddy = new PhoneBuddy(dataCursor);
                    setNameAndNumber(phoneBuddy);
                    String priorityPhotoUri = ProfilePictureDataProvider.getProfilePicturePath(getActivity(), phoneBuddy.phoneNo);
                    if (priorityPhotoUri != null) {
                        phoneBuddy.imageUri = priorityPhotoUri;
                    }
                    ImageUtil.setImageButTextImageOnException(getActivity(), phoneBuddy.imageUri, ivPhoneContactImage, tvName.getText().toString());
                    handleUnblockButton(phoneBuddy);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            private void setNameAndNumber(PhoneBuddy phoneBuddy) {
                if (TextUtils.isEmpty(searchText) || searchText.trim().length() < 1) {
                    tvName.setText(phoneBuddy.name);
                    tvPhoneNumber.setText(phoneBuddy.phoneNo);
                } else {
                    Pattern searchPattern = Pattern.compile(searchText.toLowerCase());

                    Matcher nameMatcher = searchPattern.matcher(phoneBuddy.name.toLowerCase());
                    SpannableString highlightedName = new SpannableString(phoneBuddy.name);
                    while (nameMatcher.find()) {
                        highlightedName.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getActivity(), R.color.appBlue)),
                                nameMatcher.start(), nameMatcher.end(),0);
                    }
                    tvName.setText(highlightedName);

                    Matcher numberPattern = searchPattern.matcher(phoneBuddy.phoneNo);
                    SpannableString highlightedNumber = new SpannableString(phoneBuddy.phoneNo);
                    while (numberPattern.find()) {
                        highlightedNumber.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getActivity(), R.color.appBlue)),
                                numberPattern.start(), numberPattern.end(),0);
                    }
                    tvPhoneNumber.setText(highlightedNumber);
                }
            }



            private void handleUnblockButton(final PhoneBuddy phoneBuddy) {
                tvUnblock.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ContactBlockHelper.getAccess().unblock(Util.translateNumber( phoneBuddy.phoneNo));
                    }
                });
            }
        }
    }

    private class PhoneBuddy {
        String name, imageUri, lookUpKey;
        String phoneNo;

        PhoneBuddy(Cursor cursor) {
            if (cursor == null) {
                return;
            }
            this.name = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NAME));
            this.lookUpKey = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_PHONE_LOOKUP));
            this.phoneNo = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NUMBER));
            this.imageUri = ProfilePictureDataProvider.getProfilePicturePath(getActivity(), this.phoneNo);
            if (imageUri == null) {
                this.imageUri = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_PHOTO_URI));
            }

        }

    }

    String searchText = "";

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        // Make sure that we are currently visible
        if (this.isVisible()) {
            // If we are becoming invisible, then...
            if (!isVisibleToUser) {
                if (!searchText.equals("")) {
                    searchText = "";
                    getLoaderManager().restartLoader(LOADER_ID, null, this);
                }
            }
        }
    }

    public static String getTAG() {
        return TAG;
    }

    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(Constants.Broadcast.TYPE_SUBSCRIBER_INFO_LOADED_SIGNAL)) {
                    adapter.notifyDataSetChanged();
                } else if (bag.containsKey(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE)) {
                    adapter.notifyDataSetChanged();
                }
            }
        }
    };
}

