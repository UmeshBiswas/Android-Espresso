package com.revesoft.itelmobiledialer.did;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.DIDRepo;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Rahat on 9/18/2017.
 */
public class DIDAsyncTask extends AsyncTask {

    int json = 1, csv = 0;
    int responseType = json;
    private final String DID_BASE_URL = DialerService.BILLING_URL + "/api/v2/did.jsp?";
    private static final int INVALID_REQUEST_TYPE = -1;
    private final int SERVICE_TYPE_COUNTRY = 3;
    private final String urlWithUserAndPass, urlWithUser;
    private String selectedCountryName;
    private Activity activity;
    private int serviceType, requestType;
    private ProgressDialog blockDialog;
    private OnDidResponseListener onDidResponseListener;
    private String TAG = "DIDAsyncTask";
    private String userName, password;
    private ArrayList<DID> didList;
    private String[] countryNames;
    private String[] stateNames;
    private String[] stateCodes;
    private int[] countryFlags;
    private ArrayList<DID> usersDidList;
    private DID selectedDID;
    private String stateCode;
    private String[] cityNames;
    private String[] cityCodes;

    public DIDAsyncTask(int service_type, int requestType, String selectedCountryName, Activity activity, OnDidResponseListener onDidResponseListener) {
        this.serviceType = service_type;
        this.requestType = requestType;
        this.selectedCountryName = selectedCountryName;
        this.activity = activity;

        blockDialog = new ProgressDialog(activity);
        blockDialog.setMessage(activity.getString(R.string.please_wait));
        this.onDidResponseListener = onDidResponseListener;
        SharedPreferences preferences = activity.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
        userName = UserDataManager.getUserName();
        password = UserDataManager.getUserPassword();

        urlWithUserAndPass = DID_BASE_URL + "user=" + userName + "&pass=" + "";
        urlWithUser = DID_BASE_URL + "user=" + userName;
    }

    public DIDAsyncTask(int service_type, int requestType, String selectedCountryName, String stateCode, Activity activity, OnDidResponseListener onDidResponseListener) {
        this.stateCode = stateCode;
        this.serviceType = service_type;
        this.requestType = requestType;
        this.selectedCountryName = selectedCountryName;
        this.activity = activity;

        blockDialog = new ProgressDialog(activity);
        blockDialog.setCancelable(false);
        blockDialog.setMessage( activity.getString(R.string.please_wait));
        this.onDidResponseListener = onDidResponseListener;
        SharedPreferences preferences = activity.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
        userName = UserDataManager.getUserName();
        password = UserDataManager.getUserPassword();

        urlWithUserAndPass = DID_BASE_URL + "user=" + userName + "&pass=" + "";
        urlWithUser = DID_BASE_URL + "user=" + userName;
    }


    public DIDAsyncTask(int service_type, int requestType, DID did, Activity activity, OnDidResponseListener onDidResponseListener) {
        this.serviceType = service_type;
        this.requestType = requestType;
        this.selectedDID = did;
        this.activity = activity;

        blockDialog = new ProgressDialog(activity);
        blockDialog.setMessage(getString(R.string.please_wait));
        this.onDidResponseListener = onDidResponseListener;


        SharedPreferences preferences = activity.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
        userName = UserDataManager.getUserName();
        password = UserDataManager.getUserPassword();

        urlWithUserAndPass = DID_BASE_URL + "user=" + userName + "&pass=" + "";
        urlWithUser = DID_BASE_URL + "user=" + userName;
    }

    public DIDAsyncTask(int service_type, int requestType, DID did, Activity activity, String selectedCountry, OnDidResponseListener onDidResponseListener) {
        this.serviceType = service_type;
        this.requestType = requestType;
        this.selectedDID = did;
        this.activity = activity;
        this.selectedCountryName = selectedCountry;
        blockDialog = new ProgressDialog(activity);
        blockDialog.setMessage(getString(R.string.please_wait));
        this.onDidResponseListener = onDidResponseListener;


        SharedPreferences preferences = activity.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
        userName = UserDataManager.getUserName();
        password = UserDataManager.getUserPassword();

        urlWithUserAndPass = DID_BASE_URL + "user=" + userName + "&pass=" + "";
        urlWithUser = DID_BASE_URL + "user=" + userName;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        blockDialog.show();
    }

    @Override
    protected Object doInBackground(Object[] objects) {

        if (!isInternetAvailable()) {
            return "-1";
        }

        String firstUrl = buildFirstUrl(serviceType);
        Log.d(TAG, "doInBackground: firstUrl: " + firstUrl);
        String nonceReceived = connectUrlAndReadStream(firstUrl, true);
        String md5 = createMD5Password(nonceReceived, userName, password);
        Log.e(TAG, "md5= " + md5);
        //********* Second Request (Getting data) ********

        //connectUrlAndReadStreamForDIDList(nonceReceived);

        String secondUrl = buildSecondUrl(md5, nonceReceived, serviceType, requestType);
        Log.d(TAG, "doInBackground: secondUrl: " + secondUrl);
        String secondResponse = connectUrlAndReadStream(secondUrl, false);
        Log.d(TAG, "doInBackground: secondresponse " + secondResponse);
        String errorCode = "";
        String[] responses = null;
        if (responseType == csv) {
            responses = secondResponse.split(",");
            errorCode = getErrorCode(responses);
            Log.d(TAG, "doInBackground: error_code: " + errorCode);
        } else {
            try {
                JSONObject jsonObject = new JSONObject(secondResponse);
                errorCode = jsonObject.getString("status_code");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Log.d(TAG, "doInBackground: error_code: " + errorCode);
        }

        if (errorCode != null && errorCode.equalsIgnoreCase("0")) { //success

            if (serviceType == SERVICE_TYPE_COUNTRY) { // request for getting available countries
                if (responseType == csv)
                    parseCountriesForSpinner(responses);
                else parseCountriesForSpinnerJson(secondResponse);
                return true;
            } else if (serviceType == 2 && requestType == 2) { // request for getting available dids for a country
                if (responseType == csv)
                    parseDidsForDIDSpinner(responses);
                else parseDidsForDIDSpinnerJson(secondResponse);
                return true;
            } else if (serviceType == 2 && requestType == 1) { // request for getting registered dids of a user
                if (responseType == csv)
                    parseUsersDid(responses);
                else
                    parseUsersDidJson(secondResponse);
                return true;
            } else if (serviceType == 2 && requestType == 5) {  // request for buying a did
                if (responseType == csv)
                    return parseNewlyBoughtDID(responses);
                else
                    return parseNewlyBoughtDIDJson(secondResponse);
            } else if (serviceType == 2 && requestType == 4) { // request for unsubscribing a did
                //Toast.makeText(activity, "Unsubscribed "+selectedDID.getDidNumber(), Toast.LENGTH_SHORT).show();
                Executor.ex(() -> DIDRepo.get().removeUserDidEntry(selectedDID));

                return true;
            } else if (serviceType == 2 && requestType == 3) { // request for forwarding a did
                //Toast.makeText(activity, "Unsubscribed "+selectedDID.getDidNumber(), Toast.LENGTH_SHORT).show();
                //DatabaseConstants.newInstance(activity).removeUserDidEntry(selectedDID);
                return true;
            } else if (serviceType == 4) {
                if (responseType == csv)
                    parseStatesForACountry(responses);
                else
                    parseStatesForACountryJson(secondResponse);
                return true;
            } else if (serviceType == 5) {
                if (responseType == csv)
                    parseCitisForAState(responses);
                else parseCitisForAStateJson(secondResponse);
                return true;
            }


        }

        return errorCode;
    }


    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);

        /*if (o != null && o instanceof Boolean && !(boolean) o) {
            Toast.makeText(activity, "There was something wrong", Toast.LENGTH_SHORT).show();
            blockDialog.dismiss();
            return;
        }*/

        if (o instanceof String) {
            String errorCode = (String) o;
            dismissDialog();

            /**
             * while getting a countries DID, if there are very low balance, api returns error_code=1.
             *
             * This particular case is handled in the if clause.
             *
             */
            if (errorCode.equals("1") && serviceType == 2 && requestType == 2) {


                onDidResponseListener.onDIDListResponse(null);


            } else {
                showErrorMessage(errorCode);
            }
            return;
        }

        if (serviceType == SERVICE_TYPE_COUNTRY && requestType == -1) {
            setupCountrySpinner();

            //new DIDAsyncTask(2, 2).ex();
        } else if (serviceType == 2 && requestType == 2) {
            setupDIDSpinner();
        } else if (serviceType == 2 && requestType == 1) {
            sendUsersDid();
        } else if (serviceType == 2 && requestType == 5) {
            if (responseType == csv) {
                if (o instanceof DID) {
                    DID did = (DID) o;
                    onDidResponseListener.onBuyUsersDID(did);
                }
            } else {
                onDidResponseListener.onBuyUsersDID(null);
            }

        } else if (serviceType == 2 && requestType == 4) {
            Toast.makeText(activity, activity.getString(R.string.unsubscribed) + " DID:" + selectedDID.getDidNumber(), Toast.LENGTH_SHORT).show();
            onDidResponseListener.onUnsubscribeDid(selectedDID);
//            new DIDAsyncTask(SERVICE_TYPE_COUNTRY, -1, selectedCountryName, activity, onDidResponseListener).ex();


        } else if (serviceType == 2 && requestType == 3) {
            onDidResponseListener.onForwardedNumberSet(selectedDID.getForwardedNumber());
        } else if (serviceType == 4) {
            onDidResponseListener.onStatesListResponse(stateNames, stateCodes);
        } else if (serviceType == 5) {
            onDidResponseListener.onCityListResponse(cityNames, cityCodes);
        }


        dismissDialog(); //null check

    }

    private void dismissDialog() {
        if ((blockDialog != null) && blockDialog.isShowing()) {  //null check
            blockDialog.dismiss();
        }
    }

    private boolean isInternetAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }

    //rahat 06-11-2017
    private void showErrorMessage(String errorCode) {
        if (errorCode.equals("-1")) {
            Util.showNoNetworkDialog(activity);
            return;
        }
        String message;
        switch (errorCode) {
            case "108":
                message = getString(R.string.invalid_password_alert);
                break;
            case "109":
                message = getString(R.string.invalid_user);
                break;
            case "103":
                message = getString(R.string.invalid_country);
                break;

            default:
                message = getString(R.string.something_wrong);
                break;
        }


        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
    }

    private String getString(int id) {
        return activity.getString(id);
    }

    private DID parseNewlyBoughtDID(String[] responses) {
        if (!TextUtils.isEmpty(responses[1])) {
            Log.d(TAG, "parseNewlyBoughtDID: " + responses[1]);
            String[] responseItem = responses[1].split(";");
            return new DID(getDIDitem(responseItem[0]), "", getDIDitem(responseItem[1]), "");
        }
        return null;
    }

    private DID parseNewlyBoughtDIDJson(String secondResponse) {
        try {
            JSONObject jsonObject = new JSONObject(secondResponse);
            return new DID(jsonObject.getString("did_id"), jsonObject.getString("did_owner"),
                    jsonObject.getString("did"), jsonObject.getString("rate"));
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    private String createMD5Password(String nonce, String username, String password) {

        String md5String = nonce + username + password;

        Log.d(TAG, "String to be md5 " + md5String);
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
            md.update(md5String.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            e.printStackTrace();
        }
        byte[] mdbytes = md.digest();
        // convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < mdbytes.length; i++) {
            sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
        }
        return sb.toString();

    }


    private void parseDidsForDIDSpinner(String[] responses) {
        didList = new ArrayList();
        for (int i = 1; i < responses.length; i++) {
            String[] responseItems = responses[i].split(";");
            DID did = new DID(getDIDitem(responseItems[0]), getDIDitem(responseItems[1]), getDIDitem(responseItems[2]), getDIDitem(responseItems[3]));
            didList.add(did);
        }
    }

    private void parseDidsForDIDSpinnerJson(String secondResponse) {
        didList = new ArrayList();
        try {
            JSONArray jsonArray = new JSONObject(secondResponse).getJSONArray("dids");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject didJson = jsonArray.getJSONObject(i);
                DID did = new DID(didJson.getString("did_id"), didJson.getString("did_owner"), didJson.getString("rate"));
                try {
                    did.setDidNumber(didJson.getString("did"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                didList.add(did);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseUsersDid(String[] responses) {
        usersDidList = new ArrayList();
        for (int i = 1; i < responses.length; i++) {
            String[] responseItems = responses[i].split(";");
//            Log.d(TAG, "parseUsersDid: " + responseItems[4]);
            DID did = new DID(getDIDitem(responseItems[1]), getDIDitem(responseItems[2]), getDIDitem(responseItems[0]), getDIDitem(responseItems[3]), getDIDitem(responseItems[4]));
            did.setForwardedNumber(getDIDitem(responseItems[3]));
            usersDidList.add(did);

        }
    }

    private void parseUsersDidJson(String secondResponse) {
        usersDidList = new ArrayList();
        try {
            JSONArray jsonArray = new JSONObject(secondResponse).getJSONArray("didInfo");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject didJson = jsonArray.getJSONObject(i);
                DID did = new DID(didJson.getString("did_id"), didJson.getString("did_owner"),
                        didJson.getString("did"), didJson.getString("forwarded_number"),
                        didJson.getString("expire_date"));
                did.setForwardedNumber(didJson.getString("forwarded_number"));
                usersDidList.add(did);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private String getDIDitem(String val) {
        String[] vals = val.split("=");
        if (vals.length > 1) {
            return vals[1];
        }
        return "";
    }


    private void sendUsersDid() {
        onDidResponseListener.onUsersDidListResponse(usersDidList);
    }

    private String connectUrlAndReadStream(String urlStr, boolean isFirstUrl) {
        URL url = null;

        try {
            url = new URL(urlStr);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();


            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            if (isFirstUrl) {
                return readStreamFirstRequest(in);
            } else {
                return readStreamSecondRequest(in);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return "";
    }


    private String readStreamSecondRequest(InputStream content) {
        BufferedReader buffer = new BufferedReader(new InputStreamReader(content));

        String response = "";
        try {
            String s = "";
            while ((s = buffer.readLine()) != null) {
                if (!s.isEmpty()) {
                    s = s.replaceAll("<br/>", "");
                    Log.d(TAG, "doInBackground:  buffer " + s);
                    response += s + ",";
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }


    private String readStreamFirstRequest(InputStream content) {
        BufferedReader buffer = new BufferedReader(new InputStreamReader(content));

        String s, response = "", nonceReceived = "";
        try {
            while ((s = buffer.readLine()) != null) {
                response += s;
            }
            Log.d(TAG, "readStreamFirstRequest: " + response);

            if (responseType == csv) {
                String[] tmp = response.split(";");
                String status = tmp[0].replaceAll("[^0-9]", "");
                if (!status.equals("110") || tmp[1] == null) {
                    return null;
                }
                nonceReceived = tmp[1].substring(tmp[1].indexOf("=") + 1);
                Log.e("Thread :101 ", "Nonce= " + nonceReceived);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status_code").trim();
                    nonceReceived = jsonObject.getString("nonce").trim();
                    if (!status.equals("110") || nonceReceived == null) {
                        return null;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                Log.e("Thread :101 ", "Nonce= " + nonceReceived);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return nonceReceived;
    }


    private String buildSecondUrl(String md5, String nonceReceived, int serviceType, int requestType) {
        if (serviceType == SERVICE_TYPE_COUNTRY && requestType == INVALID_REQUEST_TYPE) {
            return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=3";
        } else if (serviceType == 2 && requestType == 2) {
            try {
                if (TextUtils.isEmpty(stateCode))
                    return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=2" + "&request_type=2&country_name="
                            + URLEncoder.encode(selectedCountryName, "utf-8");
                return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=2" + "&request_type=2&country_name=" + URLEncoder.encode(selectedCountryName, "utf-8") +
                        "&city_code=" + stateCode;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        } else if (serviceType == 2 && requestType == 1) { // get users did
            return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=2&request_type=1";

        } else if (serviceType == 2 && requestType == 5) { //buy

            try {
                if (TextUtils.isEmpty(selectedCountryName))
                    return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=2&request_type=5&did_id=" + selectedDID.getDidID() + "&did_owner=" + selectedDID.getDidOwner();
                else
                    return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=2&request_type=5&did_id=" + selectedDID.getDidID() +
                            "&did_owner=" + selectedDID.getDidOwner() + "&country_name=" + URLEncoder.encode(selectedCountryName, "utf-8");

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }


        } else if (serviceType == 2 && requestType == 4) { //unsubscribe
            return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=2&request_type=4&did_id=" + selectedDID.getDidID() + "&did_owner=" + selectedDID.getDidOwner() + "&did=" + selectedDID.getDidNumber();

        } else if (serviceType == 2 && requestType == 3) { //forward
            return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&service_type=2&request_type=3&did_id=" + selectedDID.getDidID() + "&forwarded_number=" + selectedDID.getForwardedNumber();

        } else if (serviceType == 4) { //VoxBone Modification for states
            try {
                return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived +
                        "&service_type=4" + "&country_name=" + URLEncoder.encode(selectedCountryName, "utf-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        } else if (serviceType == 5) {
            try {
                return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived +
                        "&service_type=5" + "&country_name=" + URLEncoder.encode(selectedCountryName, "utf-8") + "&state_code=" + stateCode;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }


        return "";
    }

    private String buildFirstUrl(int serviceType) {
        if (serviceType == SERVICE_TYPE_COUNTRY || serviceType == 4 || serviceType == 5) {
            return urlWithUserAndPass + "&service_type=" + serviceType;
        } else if (serviceType == 2 && requestType == 2) {
            if (selectedCountryName == null) {
                return urlWithUserAndPass + "&service_type=2&request_type=2&country_name=" + selectedCountryName;
            }
            try {
                return urlWithUserAndPass + "&service_type=2&request_type=2&country_name=" + URLEncoder.encode(selectedCountryName, "utf-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        } else if (serviceType == 2 && requestType == 1) {
            return urlWithUserAndPass + "&service_type=2&request_type=1";

        } else if (serviceType == 2 && requestType == 5) {
            return urlWithUserAndPass + "&service_type=2&request_type=5";

        } else if (serviceType == 2 && requestType == 4) {
            return urlWithUserAndPass + "&service_type=2&request_type=4";

        } else if (serviceType == 2 && requestType == 3) {
            return urlWithUserAndPass + "&service_type=2&request_type=3";

        }
        return "";
    }

    private String getErrorCode(String[] responses) {
        if (responses.length > 0) {
            String firstResponse = responses[0];
            String[] errorCodeResponseArray = firstResponse.split("=");
            if (errorCodeResponseArray.length > 1) {
                return errorCodeResponseArray[1];

            }
        }
        return "";
    }

    private void parseCountriesForSpinner(String[] responses) {
        countryNames = new String[responses.length - 1];
        countryFlags = new int[responses.length - 1];
        for (int i = 1; i < responses.length; i++) {
            countryNames[i - 1] = responses[i].split("=")[1];
//            countryFlags[i - 1] = CountryCodes.countryFlags[CountryCodes.getIndexOfArrayFromCountryName(countryNames[i - 1])];
//            Log.d(TAG, "doInBackground: country " + countryNames[i - 1]);
        }
        Log.d(TAG, "doInBackground: countries size " + countryNames.length);
    }

    private void parseCountriesForSpinnerJson(String secondResponse) {
        try {
            JSONObject jsonObject = new JSONObject(secondResponse);
            JSONArray jsonArray = jsonObject.getJSONArray("countries");
            countryNames = new String[jsonArray.length()];
            countryFlags = new int[jsonArray.length()];
            for (int i = 0; i < jsonArray.length(); i++)
                countryNames[i] = jsonArray.getJSONObject(i).getString("country_name");
            Log.d(TAG, "doInBackground: countries size " + countryNames.length);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void parseStatesForACountry(String[] responses) {
        stateNames = new String[responses.length - 1];
        stateCodes = new String[responses.length - 1];
        for (int i = 1; i < responses.length; i++) {
            String stateData[] = responses[i].split(";");
            if (stateData.length >= 2) {
                String[] stringStateCodeData = stateData[0].split("=");
                String[] stringStateNameData = stateData[1].split("=");
                if (stringStateNameData.length > 1 && stringStateCodeData.length > 1) {
                    stateCodes[i - 1] = stringStateCodeData[1].trim();
                    stateNames[i - 1] = stringStateNameData[1].trim();
                }
            }
        }
        Log.d(TAG, "doInBackground: states size " + stateNames.length);
    }

    private void parseStatesForACountryJson(String secondResponse) {
        try {
            JSONObject jsonObject = new JSONObject(secondResponse);
            JSONArray jsonArray = jsonObject.getJSONArray("states");
            stateNames = new String[jsonArray.length()];
            stateCodes = new String[jsonArray.length()];
            for (int i = 0; i < jsonArray.length(); i++) {
                stateNames[i] = jsonArray.getJSONObject(i).getString("state_name");
                stateCodes[i] = jsonArray.getJSONObject(i).getString("state_code");

            }
            Log.d(TAG, "doInBackground: states size " + stateNames.length);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseCitisForAState(String[] responses) {
        cityNames = new String[responses.length - 1];
        cityCodes = new String[responses.length - 1];
        for (int i = 1; i < responses.length; i++) {
            String cityData[] = responses[i].split(";");
            if (cityData.length >= 2) {
                String[] stringStateCodeData = cityData[0].split("=");
                String[] stringStateNameData = cityData[1].split("=");
                if (stringStateNameData.length > 1 && stringStateCodeData.length > 1) {
                    cityCodes[i - 1] = stringStateCodeData[1].trim();
                    cityNames[i - 1] = stringStateNameData[1].trim();
                }
            }
        }
        Log.d(TAG, "doInBackground: states size " + cityNames.length);
    }

    private void parseCitisForAStateJson(String secondResponse) {
        try {
            JSONObject jsonObject = new JSONObject(secondResponse);
            JSONArray jsonArray = jsonObject.getJSONArray("cities");
            cityNames = new String[jsonArray.length()];
            cityCodes = new String[jsonArray.length()];
            for (int i = 0; i < jsonArray.length(); i++) {
                cityNames[i] = jsonArray.getJSONObject(i).getString("city_name");
                cityCodes[i] = jsonArray.getJSONObject(i).getString("city_code");

            }
            Log.d(TAG, "doInBackground: states size " + stateNames.length);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setupCountrySpinner() {
        if (countryNames != null) {
            onDidResponseListener.onCountryListResponse(countryNames, countryFlags);
            //countrySpinner.setSelection(1);
        }
    }

    private void setupDIDSpinner() {
        if (didList != null) {
            onDidResponseListener.onDIDListResponse(didList);

        }
    }


}

