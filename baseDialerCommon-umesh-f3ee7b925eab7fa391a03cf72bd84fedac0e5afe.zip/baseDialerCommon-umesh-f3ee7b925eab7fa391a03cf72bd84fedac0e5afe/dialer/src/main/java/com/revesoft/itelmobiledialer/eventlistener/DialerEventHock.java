package com.revesoft.itelmobiledialer.eventlistener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class DialerEventHock {

    private List<DialerListener> dialerListeners=new ArrayList<>();

    private static DialerEventHock dialerEventHock=null;

    private DialerEventHock(){}


    public static DialerEventHock getInstance(){
        if(dialerEventHock==null) dialerEventHock=new DialerEventHock();
        return dialerEventHock;
    }


    public void addListener(DialerListener dialerListener){
        dialerListeners.add(dialerListener);
    }

    public void removeListener(DialerListener listener){
        dialerListeners.remove(listener);
    }



    public void dispatchEvent(DialerEvent dialerEvent, EventData eventData){
        for(DialerListener dialerListener:dialerListeners){
            dialerListener.performOnEvent(dialerEvent,eventData);
        }
    }


}
