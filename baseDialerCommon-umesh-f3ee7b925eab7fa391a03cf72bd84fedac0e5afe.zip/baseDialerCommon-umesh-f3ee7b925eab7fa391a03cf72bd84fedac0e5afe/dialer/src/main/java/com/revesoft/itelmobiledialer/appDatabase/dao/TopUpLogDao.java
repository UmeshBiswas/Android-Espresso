/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:50 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:50 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.TopUpLog;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface TopUpLogDao extends BaseDao<TopUpLog> {
    @Query("SELECT * FROM TOPUPLOG")
    List<TopUpLog> getAll();

    @Query("SELECT * FROM TOPUPLOG ORDER BY date DESC")
    Cursor getTopUpLogs();

    @Query("SELECT topupid FROM TOPUPLOG WHERE status=2 OR status=3")
    int[] getPendingTopUpID();

    @Query("UPDATE TOPUPLOG SET status=:status WHERE topupid=:topupid")
    void updateTopUpLog(int topupid, int status);
}
