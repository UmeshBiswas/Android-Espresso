package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.view.View;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDateTimeFormatter;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.CallType;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 12/12/2017.
 */

public class CallViewHolder extends RecyclerView.ViewHolder {
    private View callViewContentHolder;
    private TextView tvDate;
    private TextView tvCallDescription;
    private TextView tvTime;

    public CallViewHolder(View view) {
        super(view);
        tvDate =  view.findViewById(R.id.tvDate);
        tvTime =  view.findViewById(R.id.tvTime);
        tvCallDescription =  view.findViewById(R.id.tvCallDescription);
        callViewContentHolder = view.findViewById(R.id.callViewContentHolder);
    }

    public void bindView(Message message) {
        handleDate(message);
        tvTime.setText(ChatDateTimeFormatter.getMessageTime(message.receivedTime));
        handleCallDescriptionAndClicks(message);
    }

    private void handleCallDescriptionAndClicks(Message message) {
        CallType callType = ChatContentParser.parseCallType(message.content);
        final String callerNumber = ChatContentParser.parseCallerNumber(message.content);
        if (callType == null) {
            tvCallDescription.setText(Supplier.getString(R.string.missed_call));
            callViewContentHolder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ChatWindowEventHook.dispatchEvent(ChatWindowEvent.MakeCallWithCheckingPermission,0);
                }
            });
        } else if (callType == CallType.AUDIO) {
            tvCallDescription.setText((Supplier.getString(R.string.missed_audio_call_from) + " " + Target.name));
            callViewContentHolder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ChatWindowEventHook.dispatchEvent(ChatWindowEvent.MakeCallWithCheckingPermission,1);
                }
            });

        } else if (callType == CallType.VIDEO) {
            tvCallDescription.setText((Supplier.getString(R.string.missed_video_call_from) + " " + Target.name));
            callViewContentHolder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ChatWindowEventHook.dispatchEvent(ChatWindowEvent.MakeCallWithCheckingPermission,2);
                }
            });
        }
    }

    private void handleDate(Message message) {
        if (message.isHeader) {
            tvDate.setVisibility(View.VISIBLE);
            tvDate.setText(ChatDateTimeFormatter.getHeaderDate(message.receivedTime));
        } else {
            tvDate.setVisibility(View.GONE);
        }
    }


}
