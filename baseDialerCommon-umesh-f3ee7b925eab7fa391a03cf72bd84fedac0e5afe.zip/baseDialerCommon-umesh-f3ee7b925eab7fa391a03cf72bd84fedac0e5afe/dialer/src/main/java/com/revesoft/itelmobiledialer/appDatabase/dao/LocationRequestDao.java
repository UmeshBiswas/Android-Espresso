package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.LocationRequest;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface LocationRequestDao extends BaseDao<LocationRequest> {
    @Query("SELECT * FROM location_request_table")
    List<LocationRequest> getAll();

    @Query("SELECT location_request_expire_time FROM LOCATION_REQUEST_TABLE WHERE number=:phoneNumber")
    long expireTime(String phoneNumber);
}
