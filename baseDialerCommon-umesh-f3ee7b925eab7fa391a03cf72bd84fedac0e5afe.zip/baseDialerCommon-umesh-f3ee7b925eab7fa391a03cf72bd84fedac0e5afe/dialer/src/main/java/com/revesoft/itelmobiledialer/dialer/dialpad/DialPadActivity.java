package com.revesoft.itelmobiledialer.dialer.dialpad;

import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.revesoft.itelmobiledialer.interfaces.Controllable;
import com.revesoft.itelmobiledialer.interfaces.SearchTextReceiver;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Display;
import com.revesoft.itelmobiledialer.util.ViewSetup;
import com.revesoft.material.R;

import java.lang.reflect.Field;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

/**
 * @author Ifta
 */

public class DialPadActivity extends BaseActivity implements Controllable, SearchTextReceiver {
    FrameLayout keyPadHolder;
    View keyPadHolderMother;
    DialPadContactsFragment dialPadContactFragment;
    FloatingActionButton fabShowDialPad;
    KeyPadFragment keyPadFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dial_pad_layout);
        handleKeyPadHolder();
        ViewSetup.setUpToolbar(this,getString(R.string.dialPad),true);
        handleToolbar();
        handleFab();
        dialPadContactFragment = DialPadContactsFragment.newInstance(false);
        keyPadFragment = new KeyPadFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.contactHolder, dialPadContactFragment, dialPadContactFragment.getTag()).commit();
        getSupportFragmentManager().beginTransaction().add(R.id.keyPadHolder, keyPadFragment, KeyPadFragment.getTAG()).commit();
    }

    private void handleFab() {
        fabShowDialPad = (FloatingActionButton) findViewById(R.id.fabShowDialPad);
        fabShowDialPad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showKeyPad();
                hideSearchOption();
            }
        });
        fabShowDialPad.setScaleX(0);
        fabShowDialPad.setScaleY(0);
    }

    private void handleKeyPadHolder() {
        keyPadHolderMother = findViewById(R.id.keyPadHolderMother);
        keyPadHolder = (FrameLayout) findViewById(R.id.keyPadHolder);
        ViewGroup.LayoutParams params = keyPadHolder.getLayoutParams();
        params.height = (int) (Display.getHeight(DialPadActivity.this) * 0.65);
        keyPadHolder.setLayoutParams(params);
    }

    private void handleToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.app_name));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(getString(R.string.dialPad));
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
        }

    }

    @Override
    public void onControlRequest(ControlRequestType controlRequestType) {
        if (controlRequestType == ControlRequestType.CHANGE_GUI_TO_HIDE_KEY_PAD) {
            hideKeyPad();
            showSearchOption();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isKeyPadVisible()) {
            hideKeyPad();
            showSearchOption();
        } else {
            finish();
        }
        return true;
    }

    private void showSearchOption() {
        if (searchView != null) {
            searchView.setVisibility(View.VISIBLE);
            searchView.setIconified(false);
            searchView.setQuery(keyPadFragment.getQuery(), false);
        }
    }

    private void hideSearchOption() {
        if (searchView != null) {
            searchView.setVisibility(View.GONE);
        }
    }

    boolean isKeyPadVisible = true;

    private void hideKeyPad() {
        isKeyPadVisible = false;
        keyPadHolderMother.animate().translationY(Display.getHeight(DialPadActivity.this)).setDuration(500);
        fabShowDialPad.setVisibility(View.VISIBLE);
        fabShowDialPad.animate().scaleX(1).scaleY(1).setDuration(250);
    }

    private void showKeyPad() {
        isKeyPadVisible = true;
        keyPadHolderMother.animate().translationY(0).setDuration(500);
        fabShowDialPad.animate().scaleX(0).scaleY(0).setDuration(250);
        fabShowDialPad.setVisibility(View.GONE);
        dialPadContactFragment.search(keyPadFragment.getQuery());
    }

    private boolean isKeyPadVisible() {
        return isKeyPadVisible;
    }

    @Override
    public void onReceiveSearchText(String searchText) {
        dialPadContactFragment.search(searchText);
    }

    SearchView searchView;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        final MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
            setSearchCursorColorToAccent(searchView);
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setIconifiedByDefault(true);
            searchView.setVisibility(View.GONE);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    if (TextUtils.isEmpty(newText)) {
                        dialPadContactFragment.search("");
                    } else {
                        dialPadContactFragment.search(newText);
                    }
                    return true;
                }
            });
            searchView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    hideSearchOption();
                }
            },100);
        }
        return true;
    }

    private void setSearchCursorColorToAccent(SearchView searchView) {
        AutoCompleteTextView searchTextView = (AutoCompleteTextView) searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        try {
            Field mCursorDrawableRes = TextView.class.getDeclaredField("mCursorDrawableRes");
            mCursorDrawableRes.setAccessible(true);
            mCursorDrawableRes.set(searchTextView, R.drawable.cursor);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
