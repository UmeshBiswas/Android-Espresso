package com.revesoft.itelmobiledialer.chat.stickeroid;

import com.revesoft.itelmobiledialer.util.TaggedLogger;

import org.json.JSONObject;

/**
 * @author Ifta on 11/5/2017.
 */

public class Sticker {
    TaggedLogger logger = new TaggedLogger("Stickroid");
    public String id;
    public String title;
    public String imageUrl;
    public String thumbUrl;
    public int width;
    public int height;
    public boolean isAcceptable = true;
    public boolean isPlaceHolder;
    public Sticker(JSONObject data) {
        try {
            this.isPlaceHolder = false;
//            this.id = data.getString("id");
//            this.title = data.getString("title");
            this.imageUrl = Stickeroid.getRoot() + data.getString("img");
            this.thumbUrl = Stickeroid.getRoot() + data.getString("thumb");
            this.width = data.getInt("width");
            this.height = data.getInt("height");

            //reject stickers with height width ratio of >=4
            float ratio = 1f;
            if(width > height){
                ratio = width/height;
            }else {
                ratio = height/width;
            }
            isAcceptable = ratio < 4.0f;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
    }

    public Sticker() {
        isPlaceHolder = true;
    }

    @Override
    public String toString() {
        return "Sticker{" +
                "  id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", thumbUrl='" + thumbUrl + '\'' +
                ", width=" + width +
                ", height=" + height +
                '}';
    }
}
