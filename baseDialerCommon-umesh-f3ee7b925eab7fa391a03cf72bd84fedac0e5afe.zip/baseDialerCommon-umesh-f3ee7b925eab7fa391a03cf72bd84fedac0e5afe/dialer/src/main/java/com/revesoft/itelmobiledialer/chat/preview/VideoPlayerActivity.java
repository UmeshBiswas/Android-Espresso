package com.revesoft.itelmobiledialer.chat.preview;

import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;


import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.FileUtil;
import com.revesoft.itelmobiledialer.util.GenericFileProvider;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;

import java.io.File;
import java.net.MalformedURLException;

import androidx.appcompat.app.AlertDialog;

public class VideoPlayerActivity extends BaseActivity {


        VideoView video_player_view;
        DisplayMetrics dm;
        MediaController media_Controller;
        String filePath = ""; //filePath for the video?
        ImageView openWithButton ;
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);

            setContentView(R.layout.video_player_activity_layout);
        }

    @Override
        protected void onResume() {
            super.onResume();
            Log.d("Asif", "onResume");
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            filePath = extras.getString("FILE_PATH");
            Log.d("Asif", "path: "+filePath);
            if(filePath == null){
                finish();
                return;
            }
        }

        openWithButton = (ImageView) findViewById(R.id.open_with_button);
        openWithButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(filePath==null)return;
                File file = new File(filePath);
                String fileMimeType = determineFileMimeType(file);
                Log.d("Asif", "File Name " + file.getName() + " Type " + fileMimeType);

                if (fileMimeType != null) {

//                        Intent intent = new Intent(Intent.ACTION_VIEW);
//                        intent.setDataAndType(Uri.fromFile(file), fileMimeType);
//                        intent.setDataAndType(Uri.fromFile(file), fileMimeType);
//                        startActivity(intent);

                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    String authority = AppContext.getAccess().getContext().getPackageName() + ".my.package.name.provider";
                    Uri fileUri = GenericFileProvider.getUriForFile(AppContext.getAccess().getContext(), authority, file);
                    Log.d("fileUri", "openDocument: fileUri " + fileUri);
                    intent.setDataAndType(fileUri, fileMimeType);
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(intent);

                } else {
                    AlertDialog.Builder bld = new AlertDialog.Builder(VideoPlayerActivity.this);
                    bld.setMessage("Can not determine file type").setNeutralButton("OK", null);
                    Log.d("Asif", "Showing alert dialog: " + "can not determine file type");
                    bld.create().show();
                }
            }
        });

        video_player_view = (VideoView) findViewById(R.id.video_player_view);
        media_Controller = new MediaController(this);
        dm = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(dm);
        video_player_view.setMinimumWidth(dm.widthPixels);
        video_player_view.setMinimumHeight(dm.heightPixels);
        video_player_view.setMediaController(media_Controller);
        video_player_view.setVideoPath(filePath);
        try {
            MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
            metaRetriever.setDataSource(filePath);
//            String height = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
//            String width = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);

//            if (Integer.parseInt(width) <= Integer.parseInt(height))
//                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//            else
//                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

            View placeholder = (View) findViewById(R.id.placeholder);
            placeholder.setVisibility(View.GONE);
            video_player_view.start();
        }catch (Exception e){
            I.toast(getString(R.string.invalidFile));
            finish();
            e.printStackTrace();
        }


        }

        @Override
        protected void onPause() {
            super.onPause();
            Log.d("Asif", "onPause");
            if(video_player_view!= null)
            {
                if(video_player_view.isPlaying())
                {
                    video_player_view.stopPlayback();
                    video_player_view.suspend();
                }
            }

        }

    private String determineFileMimeType(File file) {
        String mimeType = null;
        try {
            String fileUrl = file.toURI().toURL().toString();
            String fileExtension = FileUtil.getFileExtensionFromUrl(fileUrl);
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
        } catch (MalformedURLException e) {

            Log.e("Mkhan", "Exception in determineFileMimeType");
            e.printStackTrace();
        } catch (NullPointerException e) {

            e.printStackTrace();
            Log.e("Mkhan", "Exception in determineFileMimeType");
        }

        return mimeType;

    }
}