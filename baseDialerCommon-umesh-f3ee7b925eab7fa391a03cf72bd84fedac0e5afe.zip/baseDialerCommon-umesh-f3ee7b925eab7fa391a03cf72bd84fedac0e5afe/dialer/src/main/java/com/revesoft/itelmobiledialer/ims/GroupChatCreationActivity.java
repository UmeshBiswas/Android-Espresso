package com.revesoft.itelmobiledialer.ims;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.TaskFinishListener;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.dialer.DashboardActivity;
import com.revesoft.itelmobiledialer.dialogues.DialogActivity;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.model.Group;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.itelmobiledialer.service.dialerService.BagName;
import com.revesoft.itelmobiledialer.service.dialerService.MessageBag;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.CameraUtils;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Ifta
 * on 5/28/2017.
 */

public class GroupChatCreationActivity extends BaseActivity {
    private static final String TAG = "GroupChatCreation";
    private ArrayList<Contact> selectedContacts;
    SelectedContactsAdapter adapter;
    EditText etGroupName, etGroupDescription;
    ListView listView;
    Toolbar toolbar;
    com.revesoft.itelmobiledialer.customview.RoundedImageView ivAddGroupImage;
    int encryptionEnabled = Util.e2e();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_chat_creation_activity_lauout);
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(broadcastReceiver, new IntentFilter(Constants.MESSAGE_INTENT_FILTER));
        IntentFilter messageIntentFilter = new IntentFilter();
        messageIntentFilter.addAction(Constants.MESSAGE_INTENT_FILTER);
        messageIntentFilter.addAction(Constants.PROGRESS_INTENT_FILTER);
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(fileUploadStatusReceiver, messageIntentFilter);
        initViews();
        loadSelectedContacts(() -> {
            showListData();
            handleToolbar();
        });
    }

    private void loadSelectedContacts(TaskFinishListener  taskFinishListener) {
        String[] selectedMembersNumber = getIntent().getExtras().getStringArray(Constants.GroupChat.KEY_SELECTED_MEMBERS);
        Executor.ex(()->{
            Cursor cursor = ContactRepo.get().byProcessedNumbers(selectedMembersNumber);
            if (cursor != null && cursor.moveToFirst()) {
                selectedContacts = new ArrayList<>(cursor.getCount());
                do {
                    selectedContacts.add(new Contact(Contact.ContactType.DATABASE_CONTACT_APP, cursor));
                } while (cursor.moveToNext());
                Gui.get().run(taskFinishListener::onTaskFinished);
            } else {
                Gui.get().run(()->{
                    taskFinishListener.onTaskFinished();
                    finish();
                });
            }

        });

    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.new_group));
        }
    }

    private void showListData() {
        adapter = new SelectedContactsAdapter(GroupChatCreationActivity.this, 0, selectedContacts);
        listView.setAdapter(adapter);
    }

    private void initViews() {
        etGroupName = findViewById(R.id.etGroupName);
        etGroupDescription = findViewById(R.id.etGroupDescription);
        listView = findViewById(R.id.lv);
        ivAddGroupImage = findViewById(R.id.ivProfilePicture);
        ivAddGroupImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChangePictureDialog();
            }
        });
    }

    ProgressDialog groupCreationProgressDialog = null;

    public void createGroup(View view) {
        String groupName = etGroupName.getText().toString();
        if (TextUtils.isEmpty(groupName) || groupName.trim().length() == 0) {
            I.toast(getString(R.string.invalidGroupName));
        } else if (selectedContacts.size() <= 1) {
            I.toast(getString(R.string.pleaseSelectAtLeastTwoMember));
        } else if (!Util.hasConnection(GroupChatCreationActivity.this)) {
            showNoInternetAlert();
            return;
        } else {
            groupCreationProgressDialog = new ProgressDialog(GroupChatCreationActivity.this);
            groupCreationProgressDialog.setMessage(getString(R.string.creatingGroup));
            groupCreationProgressDialog.setTitle(getString(R.string.please_wait));
            groupCreationProgressDialog.show();
            GroupMessageAssistant.createGroup(GroupChatCreationActivity.this, selectedContacts, groupName, encryptionEnabled);
        }

    }

    private void showNoInternetAlert() {
        Intent i = new Intent();
        i.setClass(this, DialogActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra(DialogActivity.KEY_DIALOG_TYPE, DialogActivity.DialogType.NO_INTERNET);
        startActivity(i);
    }

    private class SelectedContactsAdapter extends ArrayAdapter<Contact> {
        Context context;
        LayoutInflater layoutInflater;

        SelectedContactsAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Contact> objects) {
            super(context, resource, objects);
            this.context = context;
            this.layoutInflater = ((Activity) context).getLayoutInflater();
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View view = convertView;
            ViewHolder holder;
            if (convertView == null) {
                view = layoutInflater.inflate(R.layout.group_chat_creation_group_member_single_item, parent, false);
                holder = new ViewHolder();
                holder.ivContactImage = view.findViewById(R.id.ivContactImage);
                holder.ivRemoveContact = view.findViewById(R.id.ivRemoveContact);
                holder.tvContactName = view.findViewById(R.id.tvNameOfQuotee);
                view.setTag(holder);
            } else {
                holder = (ViewHolder) view.getTag();
            }
            Contact contact = getItem(position);
            holder.tvContactName.setText(contact.name == null ? contact.processedNumber : contact.name);
            String serverImageUri = ProfilePictureDataProvider.getProfilePicturePath(GroupChatCreationActivity.this, contact.phoneNumber);
            if (serverImageUri != null) {
                contact.imageUri = serverImageUri;
            }
            ImageUtil.setImageButTextImageOnException(GroupChatCreationActivity.this, contact.imageUri, holder.ivContactImage,
                    holder.tvContactName.getText().toString());

            holder.ivRemoveContact.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeContact(position);
                }
            });
            return view;
        }

        private class ViewHolder {
            ImageView ivContactImage;
            TextView tvContactName;
            ImageView ivRemoveContact;
        }
    }

    private void removeContact(int position) {
        selectedContacts.remove(position);
        adapter = new SelectedContactsAdapter(GroupChatCreationActivity.this, 0, selectedContacts);
        listView.setAdapter(adapter);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void addMoreMember(View view) {
        String[] selectedMembersPhoneNumber = new String[selectedContacts.size()];
        for (int i = 0; i < selectedContacts.size(); i++) {
            selectedMembersPhoneNumber[i] = selectedContacts.get(i).processedNumber;
        }
        Intent intent = new Intent(GroupChatCreationActivity.this, ChatMemberSelectionActivity.class);
        intent.putExtra(Constants.IMS.ALREADY_PICKED_MEMBER_BEFORE_CREATION, selectedMembersPhoneNumber);
        startActivity(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(broadcastReceiver);
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(fileUploadStatusReceiver);
    }

    String groupId = "";
    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(DashboardActivity.GROUP_CREATED)) {
                    groupId = bag.getString(DashboardActivity.GROUP_CREATED);
                    if (groupCreationProgressDialog != null) {
                        groupCreationProgressDialog.dismiss();
                    }
                    if (selectedImageUri != null) {
                        uploadGroupPicToServer(selectedImageUri);
                    } else {
                        switchToMessageWindow();
                    }
                } else if (bag.containsKey("update_group_name")) {
                    I.log("update_group_name");
                    switchToMessageWindow();
                }
            }
        }
    };

    private void switchToMessageWindow() {
//        Intent groupMessageIntent = new Intent(GroupChatCreationActivity.this, MessageActivity.class);
//        groupMessageIntent.putExtra(MessageActivity.EXTRA_GROUP_ID, groupId);
//        startActivity(groupMessageIntent);
        Switcher.switchToChatWindow(GroupChatCreationActivity.this, groupId, true, false, false, false);
        finish();
    }

    //=========================================================================================================================//
    BroadcastReceiver fileUploadStatusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(Constants.PROGRESS)) {
                    String percentage = bag.getString(Constants.PROGRESS);
                    int progress = Integer.parseInt(percentage.substring(0, percentage.length() - 1));
                    if (progressDialog != null) {
                        progressDialog.setProgress(progress);
                        if (progress == 100) {
                            progressDialog.setMessage(getString(R.string.uploadFinishAndVerify));
                        }
                    }
                } else if (bag.containsKey(Constants.IMS.GROUP_CHAT_GROUP_IMAGE_PATH)) {
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                    }
                    String filePath = bag.getString(Constants.IMS.GROUP_CHAT_GROUP_IMAGE_PATH);
                    if (Constants.IMS.FAILED.equals(filePath)) {
                        I.toast(getString(R.string.somethingWentWrong));
                        switchToMessageWindow();
                    } else {
                        changeGroupNameToReflectChangeOfGroupImage(filePath);
                    }
                }
            }
        }
    };

    private void changeGroupNameToReflectChangeOfGroupImage(String filePath) {
        Group group = GroupMessageAssistant.getGroupById(GroupChatCreationActivity.this, groupId);
        String groupNameWithProfilePicture = group.name + Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR + filePath;
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
        IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.CHANGE_GROUP_NAME, groupId, groupNameWithProfilePicture);
    }

    private Uri photoUri = null;
    private static final int REQUEST_IMAGE_CAPTURE = 50;
    private static final int PICK_IMAGE_REQUEST = 52;

    private void showChangePictureDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(GroupChatCreationActivity.this);
        builder.setTitle(getString(R.string.chooseMethod));
        ArrayList<String> methods = new ArrayList<String>();
        methods.add(getString(R.string.takeNewPhoto));
        methods.add(getString(R.string.selectFromGallery));
        ListAdapter adapter = new ArrayAdapter<String>(GroupChatCreationActivity.this, android.R.layout.simple_list_item_1, methods);
        builder.setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        handleCameraCapture();
                        break;
                    case 1:
                        handleGallerySelection();
                        break;
                    default:
                        break;
                }
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private void handleCameraCapture() {
        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforCamera(this).length > 0) {
            Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
            ActivityCompat.requestPermissions(this, PermissionUtil.getPermissionsforCamera(this), OnFragmentInteractionListener.TYPE_IMAGE_VIDEO);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        photoUri = CameraUtils.getOutputMediaFileUri(CameraUtils.MediaFileType.IMAGE, GroupChatCreationActivity.this);
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } else {
            I.toast(getString(R.string.noDefaultCameraFound));
        }
    }

    private void handleGallerySelection() {
        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforGallery(this).length > 0) {
            Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
            ActivityCompat.requestPermissions(this, PermissionUtil.getPermissionsforGallery(this), OnFragmentInteractionListener.TYPE_GALLERY_IMAGE);
        } else {
            openGallery();
        }
    }

    private void openGallery() {
        Intent intent = new Intent();
        // Show only images, no videos or anything else
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        // Always show the chooser (if there are multiple options available)
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    private Uri selectedImageUri;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE) {
            if (resultCode == RESULT_OK) {
                if (photoUri != null) {
                    selectedImageUri = photoUri;
                    if (performCrop(photoUri)) {
                        Log.d(TAG, "Crop supported");
                    } else {
                        setImagePreviewAndShowPendingMessage();

                    }
                    deleteTempFile(GroupChatCreationActivity.this, photoUri);
                } else {
                    I.toast(getString(R.string.error_no_image_selected));
                }
            }
        } else if (requestCode == PICK_IMAGE_REQUEST) {
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    Uri uri = data.getData();
                    if (uri != null) {
                        selectedImageUri = uri;
                        if (performCrop(uri)) {
                            Log.d(TAG, "Crop supported");
                        } else {
                            setImagePreviewAndShowPendingMessage();
                        }
                    } else {
                        I.toast(getString(R.string.error_no_image_selected));
                    }
                }
            }
        } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            try {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == Activity.RESULT_OK) {
                    Uri croppedFileUri = result.getUri();
                    selectedImageUri = croppedFileUri;
                    if (croppedFileUri != null) {
                        setImagePreviewAndShowPendingMessage();
                    } else {
                        I.toast(getString(R.string.error_image_cropping_failed));
                        Log.d(TAG, "Cropped uri  null ");
                    }

                } else if (resultCode == Activity.RESULT_CANCELED) {
                    Log.d(TAG, "Cropping was canceled ");
                    Toast.makeText(GroupChatCreationActivity.this, R.string.error_no_image_selected, Toast.LENGTH_SHORT).show();
                }
                deleteTempFile(GroupChatCreationActivity.this, selectedImageUri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void setImagePreviewAndShowPendingMessage() {
        I.toast(getString(R.string.imageWillBeSetUponGroupCreation));
        Glide.with(GroupChatCreationActivity.this)
                .load(selectedImageUri)
                .crossFade()
                .into(ivAddGroupImage)
                .onLoadFailed(
                        new Exception("Failed"),
                        ContextCompat.getDrawable(GroupChatCreationActivity.this, R.drawable.group_details_group_image)
                );
    }

    private void sendIntentMessageFileUploadToDialer(String groupId, String filePath, String callerId) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                .groupId(groupId)
                .isGroup(true)
                .filePath(filePath)
                .callId(callerId).build());
        LocalBroadcastManager.getInstance(GroupChatCreationActivity.this).sendBroadcast(intent);
    }

    ProgressDialog progressDialog;

    private void uploadGroupPicToServer(Uri selectedImageUri) {
        String filePath = (new File(selectedImageUri.getPath())).getAbsolutePath();
        progressDialog = new ProgressDialog(GroupChatCreationActivity.this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle(getString(R.string.please_wait));
        progressDialog.setMessage(getString(R.string.uploading));
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setMax(100);
        progressDialog.show();
        sendIntentMessageFileUploadToDialer(groupId, filePath, Constants.IMS.GROUP_PROFILE_PICTURE_INDICATOR + System.currentTimeMillis());
    }

    private boolean deleteTempFile(Context context, Uri uri) {
        int deleted = 0;
        try {
            deleted = context.getContentResolver().delete(uri, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted > 0;
    }

    private boolean performCrop(Uri picUri) {
        boolean supportsCrop;
        try {
            Uri targetFileUri = null;

            try {
                targetFileUri = Uri.fromFile(Util.createImageFile(this));
//                targetFileUri = FileProvider.getUriForFile(ProfileInfoUpdateActivity.this, getString(R.string.file_provider_authority), Util.createImageFile(this));
            } catch (IOException e) {
                Log.e(TAG, "Exception creating Image File in performCrop - " + e);
                e.printStackTrace();
            }

            CropImage.activity(picUri)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setOutputUri(targetFileUri)
                    .setOutputCompressQuality(100)
                    .setOutputCompressFormat(Bitmap.CompressFormat.JPEG)
                    .setRequestedSize(500, 500)
                    .setAspectRatio(1, 1)
                    .setFixAspectRatio(true)
                    .start(GroupChatCreationActivity.this);

            supportsCrop = true;
        } catch (Exception e) {
            supportsCrop = false;
            e.printStackTrace();
            I.toast(getString(R.string.error_image_cropping_not_supported));
        }

        return supportsCrop;
    }
}
