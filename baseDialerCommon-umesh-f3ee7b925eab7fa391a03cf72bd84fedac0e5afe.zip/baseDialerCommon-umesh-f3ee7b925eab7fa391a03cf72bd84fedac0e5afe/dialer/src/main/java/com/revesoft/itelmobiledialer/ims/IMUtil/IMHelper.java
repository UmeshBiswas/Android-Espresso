package com.revesoft.itelmobiledialer.ims.IMUtil;

import android.util.Log;
import android.webkit.MimeTypeMap;

import com.revesoft.itelmobiledialer.util.FileUtil;

import java.io.File;
import java.net.MalformedURLException;

import static com.revesoft.itelmobiledialer.util.Constants.tag;

/**
 * Created by Acer on 3/28/2017.
 */

public class IMHelper {
    public interface MessageFileType {
        public int IMAGE_FILE = 100;
        public int VIDEO_FILE = 101;
        public int AUDIO_FILE = 102;
        public int GENERIC_FILE = 103;

    }
    public static int determineFileType(File file) {

        int fileType = MessageFileType.GENERIC_FILE;

        String fileMimeType = determineFileMimeType(file);
        // if the file can not be categorized into image,video or audio it
        // will
        // be shown as an generic file
        if (fileMimeType != null) {

            if (fileMimeType.contains("djvu")) {
                fileType = MessageFileType.GENERIC_FILE;
            } else if (fileMimeType.contains("image")) {
                fileType = MessageFileType.IMAGE_FILE;
            } else if (fileMimeType.contains("video")) {
                fileType = MessageFileType.VIDEO_FILE;
            } else if (fileMimeType.contains("audio")) {
                fileType = MessageFileType.AUDIO_FILE;
            }
        } else {
            fileType = MessageFileType.GENERIC_FILE;
        }

        return fileType;
    }

    // url = file path or whatever suitable URL you want.
    public static String getMimeType(String url) {
        String type = null;
        String extension = FileUtil.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }

    private static String determineFileMimeType(File file) {
        String mimeType = null;
        Log.e(tag, "file_extension"+ "here");
        try {
            String fileUrl = file.toURI().toURL().toString();
            Log.e(tag, "file_url"+ fileUrl);
            String fileExtension = FileUtil
                    .getFileExtensionFromUrl(fileUrl);
            if(fileExtension==null || fileExtension.length()==0)
                fileExtension=getExtention(file.getName());

            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension);
            Log.e(tag, "file_extension"+ fileExtension);
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NullPointerException e) {
            // TODO: handle exception
            e.printStackTrace();

        }
        Log.e(tag, "file_extension"+ "here2");
        return mimeType;

    }
    private static String getExtention(String fileName){
        char[] arrayOfFilename = fileName.toCharArray();
        for(int i = arrayOfFilename.length-1; i > 0; i--){
            if(arrayOfFilename[i] == '.'){
                return fileName.substring(i+1, fileName.length());
            }
        }
        return "";
    }

}
