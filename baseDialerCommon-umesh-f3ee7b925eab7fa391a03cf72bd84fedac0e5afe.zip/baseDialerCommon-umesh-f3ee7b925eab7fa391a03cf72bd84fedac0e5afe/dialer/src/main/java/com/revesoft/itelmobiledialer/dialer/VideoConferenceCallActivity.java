package com.revesoft.itelmobiledialer.dialer;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.iftalab.runtimepermission.AppPermissionListener;
import com.iftalab.runtimepermission.DangerousPermission;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.apprtc.AppRTCAudioManager;
import com.revesoft.itelmobiledialer.apprtc.AppRTCAudioManager.AudioDevice;
import com.revesoft.itelmobiledialer.apprtc.AppRTCCallManager;
import com.revesoft.itelmobiledialer.apprtc.ProxyVideoSink;
import com.revesoft.itelmobiledialer.apprtc.SDPUtil;
import com.revesoft.itelmobiledialer.apprtc.SignalingParameters;
import com.revesoft.itelmobiledialer.apprtc.TurnInfo;
import com.revesoft.itelmobiledialer.apprtc.conference.DataChannelParameters;
import com.revesoft.itelmobiledialer.apprtc.conference.ICECandidateUtilConference;
import com.revesoft.itelmobiledialer.apprtc.conference.PeerConnectionManager;
import com.revesoft.itelmobiledialer.apprtc.conference.PeerConnectionParameters;
import com.revesoft.itelmobiledialer.apprtc.websocket.SignallingManager;
import com.revesoft.itelmobiledialer.apprtc.websocket.dao.Request;
import com.revesoft.itelmobiledialer.apprtc.websocket.dao.Response;
import com.revesoft.itelmobiledialer.apprtc.websocket.dao.WebRTCResponse;
import com.revesoft.itelmobiledialer.chat.chatWindow.group.Group;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.e2eencryption.E2EPublicKeySeedAndPrivateKeyHolder;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.phonebook.ContactSelectionActivity;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.EglBase;
import org.webrtc.FileVideoCapturer;
import org.webrtc.Logging;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RendererCommon.ScalingType;
import org.webrtc.ScreenCapturerAndroid;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;

import androidx.annotation.RequiresApi;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageAttributes.ATTRIBUTE_GROUPID;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageAttributes.ATTRIBUTE_GROUP_MEMBERS;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageAttributes.ATTRIBUTE_NOTIFICATION_TYPE;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageAttributes.ATTRIBUTE_RUNNING_CONFERENCE_IDS;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageAttributes.ATTRIBUTE_SEND_FROM_USERID;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageAttributes.ATTRIBUTE_USERID;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.GROUP_NOTIFICATION_TYPE_GROUP_LEFT;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.MESSAGE_TYPE_CREATE_GROUP_CALL;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.MESSAGE_TYPE_FETCH_RUNNIG_GROUP_CALL;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.MESSAGE_TYPE_GROUP_CONFERENCE_TERMINATED;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.MESSAGE_TYPE_JOIN_GROUP_CALL;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.MESSAGE_TYPE_LEAVE_GROUP_CALL;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.MESSAGE_TYPE_NOTIFICATION_FROM_GROUP;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.MESSAGE_TYPE_RECEIVE_WEBRTC_MESSAGE;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.WB_MESSAGE_TYPE_ANSWER;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.WB_MESSAGE_TYPE_CANDIDATE;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.WB_MESSAGE_TYPE_OFFER;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.WB_MESSAGE_TYPE_PRANSWER;
import static com.revesoft.itelmobiledialer.apprtc.websocket.MessageTypes.WB_MESSAGE_TYPE_REMOVED_CANDIDATES;

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class VideoConferenceCallActivity extends BaseActivity
        implements View.OnClickListener, SignallingManager.WebSocketChannelEvents {

    private static final String TAG = "RTCVideoCall";
    //    private static final String TAG = "RTCVideoCall";
    public static final String ROOMID = "roomid";
    public static final String IS_OUTGOING_CALL = "isoutgoingcall";
    public static final String LOGIN_NUMBER = "login_number";
    public static final int ADD_MEMBER_ACTION = 123456;

    private static final int HD_VIDEO_WIDTH = 1280;
    private static final int HD_VIDEO_HEIGHT = 720;
    private static final int VIDEO_PREFERRED_FPS = 15;
    private static final int VIDEO_MAX_BITRATE = 1024;
    private static final int AUDIO_MAX_BITRATE = 32;

    private static final boolean USE_CAMERA_TWO = true;
    private static final boolean CAPTURETOTEXTURE_ENABLED = USE_CAMERA_TWO;

    /* Defining the extras used to save turnInfo in intent */
    public static final String EXTRA_SDP = "apprtc.SDP";
    public static final String EXTRA_CANDIDATE = "apprtc.ICE_CANDIDATE";
    public static final String EXTRA_CALLERID = "apprtc.CALLERID";

    public static final String WEBSOCKET_DATA = "org.appspot.apprtc.WEBSOCKET_DATA";
    public static final String WEBSOCKET_DATA_TYPE = "org.appspot.apprtc.WEBSOCKET_DATA_TYPE";

    public static final String WEBSOCKET_DATA_TYPE_OFFER = "offer";
    public static final String WEBSOCKET_DATA_TYPE_ANSWER = "answer";
    public static final String WEBSOCKET_DATA_TYPE_MAKE_CALL = "makecall";

    private static final int CAPTURE_PERMISSION_REQUEST_CODE = 1;

    /* List of mandatory application permissions. */
    private static final String[] MANDATORY_PERMISSIONS = {"android.permission.MODIFY_AUDIO_SETTINGS",
            "android.permission.RECORD_AUDIO", "android.permission.INTERNET"};

    /* Peer connection statistics callback period in ms. */
    private static final int STAT_CALLBACK_PERIOD = 1000;

    boolean callDisconnected = false;

    private ProxyVideoSink localFullScreenProxyVideoSink = new ProxyVideoSink();
    private final ProxyVideoSink localProxyVideoSink = new ProxyVideoSink();
    private VideoCapturer videoCapturer = null;

    //    private PeerConnectionClient peerConnectionClient = null;
    private SignalingParameters signalingParameters;

    private AppRTCAudioManager audioManager = null;
    private EglBase rootEglBase;
    private SurfaceViewRenderer pipRenderer;
    private SurfaceViewRenderer fullscreenRenderer;
    private PeerConnectionParameters peerConnectionParameters;
    private boolean iceConnected;
    private boolean isError;
    private boolean callControlContainerVisible = true;
    private long callStartedTimeMs = 0;
    private boolean screenCaptureEnabled = false;
    private static Intent mediaProjectionPermissionResultData;
    private static int mediaProjectionPermissionResultCode;

    // True if local view is in the fullscreen renderer.
    private boolean isSwappedFeeds;


    public List<String> localCandidateList = new ArrayList<String>();

    private SharedPreferences sharedPref;
    private Intent infoIntent;

    private boolean returnFromCrash = false;
    private Handler handler = null;

    private String roomid = "";
    private String loginNumber = "";
    private boolean isOutGoingCall = true;
    private boolean dialogShown = false;
    private LinearLayout remoteViewContainers;

    private PeerConnectionManager peerConnectionManager = null;

    private static boolean conferenceRunning = false;

    private Group group;

    public static boolean isConferenceRunning(){
        return conferenceRunning;
    }
//    private ToggleButton muteButton;
//    private ToggleButton bluetoothButton;
    private ToggleButton speakerButton;
//    private ToggleButton soundButton;
    private Button switchButton;
    private ToggleButton videoButton;

    SignallingManager callManager = null;
    AudioManager am;

    HashMap<String, AppRTCCallManager> conferenceCallHolder = new HashMap<>();
    TurnInfo turnInfo = getTurnInfo();

    private BroadcastReceiver networkChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                final String action = intent.getAction();
                if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    /**
     * The on initialize override method.
     * the window setting done to full screen
     * getting the intent turnInfo from the calling intent
     * Then Initialize the video calling activity
     * Setting the Gui to the appropriate format and initialize them
     * Registering the broadcast receiver
     * Then formatting the video renderer to the window
     * After checking the mandatory permissions needed
     * we set the peer connection parameters .
     *
     * @param savedInstanceState
     */

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Thread.setDefaultUncaughtExceptionHandler(new UnhandledExceptionHandler(this));
        handler = new Handler();
        // Set window styles for fullscreen-window size. Needs to be done before
        // adding content.
        conferenceRunning = true;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(LayoutParams.FLAG_FULLSCREEN | LayoutParams.FLAG_KEEP_SCREEN_ON
                | LayoutParams.FLAG_DISMISS_KEYGUARD | LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(getSystemUiVisibility());
        setContentView(R.layout.activity_video_conference);

        roomid = getIntent().getStringExtra(ROOMID);
        isOutGoingCall = getIntent().getBooleanExtra(IS_OUTGOING_CALL, true);
        loginNumber = getIntent().getStringExtra(LOGIN_NUMBER);
        callManager = SignallingManager.getInstance(handler, this, loginNumber);
        callManager.addWebSocketChannelEvents(this);

        if (isOutGoingCall) {
            findViewById(R.id.single_button_space).setVisibility(View.VISIBLE);
            findViewById(R.id.double_button_space).setVisibility(View.GONE);
        } else {
            findViewById(R.id.single_button_space).setVisibility(View.GONE);
            findViewById(R.id.double_button_space).setVisibility(View.VISIBLE);
        }

        Executor.ex(() -> {
            group = new Group(GroupRepo.get().getGroupById(roomid));
        });
        contactsPermission();
    }

    private TurnInfo getTurnInfo(){
        return TurnInfo.newBuilder().turnIp(SIPProvider.getStunInfo().turnServerIP.toString())
                .turnPort(SIPProvider.getStunInfo().turnServerPort)
                .turnUsername(SIPProvider.getStunInfo().turnServerUserName.toString())
                .turnPassword(SIPProvider.getStunInfo().turnServerPassword.toString())
                .sipUsername(UserDataManager.getUserName()).build();
    }

    private void contactsPermission() {
        DangerousPermission.ContactsPermission.getAccess(VideoConferenceCallActivity.this).requestPermission(VideoConferenceCallActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                cameraPermission();
            }

            @Override
            public void onPermissionRejected() {
                cameraPermission();
            }
        });
    }


    private void cameraPermission() {
        DangerousPermission.CameraPermission.getAccess(VideoConferenceCallActivity.this).requestPermission(VideoConferenceCallActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                microPhonePermission();
            }

            @Override
            public void onPermissionRejected() {
                rejectForNoPermission();
            }
        });
    }

    private void microPhonePermission() {
        DangerousPermission.MicrophonePermission.getAccess(VideoConferenceCallActivity.this).requestPermission(VideoConferenceCallActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                phonePermission();
            }

            @Override
            public void onPermissionRejected() {
                rejectForNoPermission();
            }
        });
    }

    private void phonePermission() {

        DangerousPermission.PhonePermission.getAccess(VideoConferenceCallActivity.this).requestPermission(VideoConferenceCallActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                onCreateInitialization();
            }

            @Override
            public void onPermissionRejected() {
                rejectForNoPermission();
            }
        });
    }

    private void rejectForNoPermission() {
        finish();
    }

    private void onCreateInitialization(){

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkChangeReceiver, intentFilter);

        iceConnected = false;
        signalingParameters = null;
        pipRenderer = findViewById(R.id.pip_video_view);
        fullscreenRenderer = findViewById(R.id.fullscreen_video_view);
        remoteViewContainers = findViewById(R.id.remoteViewContainers);

        videoCapturer = createVideoCapturer();

        rootEglBase = EglBase.create();
        pipRenderer.init(rootEglBase.getEglBaseContext(), null);
        pipRenderer.setScalingType(ScalingType.SCALE_ASPECT_FIT);


        fullscreenRenderer.init(rootEglBase.getEglBaseContext(), null);
        fullscreenRenderer.setScalingType(ScalingType.SCALE_ASPECT_FILL);

        pipRenderer.setZOrderMediaOverlay(true);
        pipRenderer.setEnableHardwareScaler(true /* enabled */);
        fullscreenRenderer.setEnableHardwareScaler(true /* enabled */);
        // Start with local feed in fullscreen and swap it to the pip when the call is connected.
        if(isOutGoingCall) {
            setSwappedFeeds(true /* isSwappedFeeds */);
        } else {
            pipRenderer.setVisibility(View.GONE);
            fullscreenRenderer.setVisibility(View.GONE);
        }

        // Check for mandatory permissions.
        for (String permission : MANDATORY_PERMISSIONS) {
            if (checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                Log.i(TAG, "Permission " + permission + " is not granted");
                finish();
                Log.w(TAG, " finish from MANDATORY_PERMISSIONS");
                return;
            }
        }

        boolean loopback = false;
        boolean isDataChannelEnabled = false;
        boolean tracing = false;

        int videoWidth = HD_VIDEO_WIDTH;
        int videoHeight = HD_VIDEO_HEIGHT;
        int videoMaxBitRate = VIDEO_MAX_BITRATE;
        int audioMaxBitrate = AUDIO_MAX_BITRATE;
        String videoPreferredCodec = "VP8";
        String audioPreferredCodec = "OPUS";

        boolean saveInputAudioToFile = false;
        boolean enableOpenslESAudio = false;
        screenCaptureEnabled = false;

        // If capturing format is not specified for screencapture, use screen resolution.
        if (screenCaptureEnabled && videoWidth == 0 && videoHeight == 0) {
            DisplayMetrics displayMetrics = getDisplayMetrics();
            videoWidth = displayMetrics.widthPixels;
            videoHeight = displayMetrics.heightPixels;
        }
        DataChannelParameters dataChannelParameters = null;
        if (isDataChannelEnabled) {
            dataChannelParameters = new DataChannelParameters(true, -1, -1, "false", false, -1);
        }

        //peer connection parameter settings....
        peerConnectionParameters =
                new PeerConnectionParameters(true, false, tracing, videoWidth, videoHeight, VIDEO_PREFERRED_FPS,
                        videoMaxBitRate, videoPreferredCodec, true, false,
                        audioMaxBitrate, audioPreferredCodec, false, false,
                        saveInputAudioToFile, enableOpenslESAudio, false, false, false, false,
                        false, false, dataChannelParameters);

//        Log.i(TAG, "VIDEO_FILE: '" + infoIntent.getStringExtra(EXTRA_VIDEO_FILE_AS_CAMERA) + "'");

        peerConnectionManager = new PeerConnectionManager(getApplicationContext(), rootEglBase, peerConnectionParameters, localProxyVideoSink, videoCapturer);
        PeerConnectionFactory.Options options = new PeerConnectionFactory.Options();
        peerConnectionManager.createPeerConnectionFactory(options);

        if (screenCaptureEnabled) {
            startScreenCapture();
        } else {
            startCall();
        }

        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        am.setSpeakerphoneOn(false);

        if (isOutGoingCall) {
            try {
//                processAppRTCResponse(getIntent());
                fetchRunningGroupCalls(loginNumber);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

//        muteButton = findViewById(R.id.mute_button);
//        muteButton.setOnCheckedChangeListener((buttonView, isChecked) -> muteAction(isChecked));
//        bluetoothButton = findViewById(R.id.bluetooth_button);
//        bluetoothButton.setOnCheckedChangeListener((buttonView, isChecked) -> bluetoothAction(isChecked));
        speakerButton = findViewById(R.id.speaker_button);
        speakerButton.setOnCheckedChangeListener((buttonView, isChecked) -> handleSpeaker(isChecked));
//        soundButton = findViewById(R.id.sound_button);
//        soundButton.setOnCheckedChangeListener((buttonView, isChecked) -> soundAction(isChecked));
        videoButton = findViewById(R.id.video_button);
        videoButton.setOnCheckedChangeListener((buttonView, isChecked) -> videoAction(isChecked));
        switchButton = findViewById(R.id.switch_button);
        switchButton.setOnClickListener((buttonView) -> onCameraSwitch());

        speakerButton.setChecked(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Executor.ex(() -> {
            group = new Group(GroupRepo.get().getGroupById(roomid));
            ((TextView)findViewById(R.id.nametview)).setText(group.name);
        });
        findViewById(R.id.add_group_members).setOnClickListener(v -> Executor.ex(() -> {
            group = new Group(GroupRepo.get().getGroupById(roomid));
            if(group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber.length < 4) {
                handleAddMember(v);
            } else {
                Toast.makeText(VideoConferenceCallActivity.this, "You already have 4 members in this group. You shall not be able to add more", Toast.LENGTH_LONG).show();
            }
        }));
    }

    public void handleAddMember(View view) {
        ContactSelectionActivity.startSelection(this, ContactSelectionFragment.ContactType.APP, true, true, Arrays.asList(group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber), "Add member", R.drawable.ic_done_black_24dp);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        isOutGoingCall = intent.getBooleanExtra(IS_OUTGOING_CALL, true);
        if (isOutGoingCall) {
            try {
//                processAppRTCResponse(intent);
                fetchRunningGroupCalls(loginNumber);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void processAppRTCResponse(Intent intent) throws JSONException {
        if (intent == null || intent.getExtras() == null)
            return;

        Bundle bundles = intent.getExtras();
        if (bundles.containsKey(WEBSOCKET_DATA_TYPE)) {
            String type = bundles.getString(WEBSOCKET_DATA_TYPE);
            String data;
            if (type != null) {
                switch (type) {
//                    case WEBSOCKET_DATA_TYPE_OFFER:
//                        data = bundles.getString(WEBSOCKET_DATA);
//                        processOffer(new JSONObject(data));
//                        break;
//                    case WEBSOCKET_DATA_TYPE_ANSWER:
//                        data = bundles.getString(WEBSOCKET_DATA);
//                        processAnswer(new JSONObject(data));
//                        break;
                    case WEBSOCKET_DATA_TYPE_MAKE_CALL:
                        data = bundles.getString(WEBSOCKET_DATA);
//                        makeCallToNumber(data);
                        fetchRunningGroupCalls(loginNumber);
                        break;

                }
            }
        }
    }

    private String sharedPrefGetString(int attributeId, int defaultId) {
        String defaultValue = getString(defaultId);
        String attributeName = getString(attributeId);
        return sharedPref.getString(attributeName, defaultValue);
    }

    private boolean sharedPrefGetBoolean(int attributeId, int defaultId) {
        boolean defaultValue = Boolean.valueOf(getString(defaultId));
        String attributeName = getString(attributeId);
        return sharedPref.getBoolean(attributeName, defaultValue);
    }

    private int sharedPrefGetInteger(int attributeId, int defaultId) {
        String defaultString = getString(defaultId);
        int defaultValue = Integer.parseInt(defaultString);
        String attributeName = getString(attributeId);
        String value = sharedPref.getString(attributeName, defaultString);
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            Log.e(TAG, "Wrong setting for: " + attributeName + ":" + value);
            return defaultValue;
        }
    }

    @TargetApi(17)
    private DisplayMetrics getDisplayMetrics() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager =
                (WindowManager) getApplication().getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
        return displayMetrics;
    }

    @TargetApi(19)
    private static int getSystemUiVisibility() {
        int flags = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        return flags;
    }


    /**
     * It starts the video capture to save in a file
     */
    @TargetApi(21)
    private void startScreenCapture() {
        MediaProjectionManager mediaProjectionManager =
                (MediaProjectionManager) getApplication().getSystemService(
                        Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(
                mediaProjectionManager.createScreenCaptureIntent(), CAPTURE_PERMISSION_REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ContactSelectionActivity.CONTACT_SELECTION_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data.hasExtra(ContactSelectionActivity.KEY_RESULT)) {
                List<Contact> contacts = (List<Contact>) data.getSerializableExtra(ContactSelectionActivity.KEY_RESULT);
                if (contacts != null && contacts.size() > 0) {
                    String numbers = "";
                    for (Contact contact : contacts) {
                        numbers += contact.processedNumber + " ";
                        sendIntentMessageToDialer("addgroupmember", roomid, contact.processedNumber);
                    }
                } else {
                    I.toast("no contacts selected");
                }
            } else {
                if (requestCode != CAPTURE_PERMISSION_REQUEST_CODE)
                    return;
                mediaProjectionPermissionResultCode = resultCode;
                mediaProjectionPermissionResultData = data;
                startCall();
            }
        }
    }

    private boolean useCamera2() {
        return Camera2Enumerator.isSupported(this) && USE_CAMERA_TWO;
    }

    private boolean captureToTexture() {
        return CAPTURETOTEXTURE_ENABLED;
    }

    private @Nullable
    VideoCapturer createCameraCapturer(CameraEnumerator enumerator) {
        final String[] deviceNames = enumerator.getDeviceNames();

        // First, try to find front facing camera
        Logging.d(TAG, "Looking for front facing cameras.");
        for (String deviceName : deviceNames) {
            if (enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating front facing camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }

        // Front facing camera not found, try something else
        Logging.d(TAG, "Looking for other cameras.");
        for (String deviceName : deviceNames) {
            if (!enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating other camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }

        return null;
    }

    @TargetApi(21)
    private VideoCapturer createScreenCapturer() {
        if (mediaProjectionPermissionResultCode != Activity.RESULT_OK) {
            reportError("User didn't give permission to capture the screen.");
            return null;
        }
        return new ScreenCapturerAndroid(
                mediaProjectionPermissionResultData, new MediaProjection.Callback() {
            @Override
            public void onStop() {
                reportError("User revoked permission to capture the screen.");
            }
        });
    }

    @Override
    protected void onDestroy() {
        try {
            leaveGroupCall(roomid, loginNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (AppRTCCallManager appRTCCallManager : conferenceCallHolder.values()) {
            if (appRTCCallManager != null) {
                appRTCCallManager.close();
            }
        }
        sendIntentMessageToDialer("stop_ringing","1");

        peerConnectionManager.close();
//        Thread.setDefaultUncaughtExceptionHandler(null);
        disconnect();
//        rootEglBase.release();

        unregisterReceiver(networkChangeReceiver);
        callManager.removeWebSocketChannelEvents(this);
        conferenceRunning = false;
        super.onDestroy();
    }


    private void muteAction(boolean isChecked) {
        peerConnectionManager.setAudioEnabled(isChecked);
    }

    public void handleSpeaker(boolean isChecked) {
        am.setSpeakerphoneOn(isChecked);
    }

//    private void speakerAction(boolean isChecked) {
//        speakerButton.setChecked(isChecked);
//        if (isChecked) {
//            // Toast.makeText(this, getString(R.string.speaker_on),
//            // 3000).show();
//            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                    Constants.BROADCAST_MESSAGE_START_SPEAKER);
//            SPEAKER_FLAG = true;
//        } else {
//            // Toast.makeText(this, getString(R.string.speaker_off),
//            // 3000).show();
//            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                    Constants.BROADCAST_MESSAGE_STOP_SPEAKER);
//            SPEAKER_FLAG = false;
//        }
//    }

//    private void soundAction(boolean isChecked) {
//        if (isChecked) {
//            // Toast.makeText(this, getString(R.string.sound_off), 3000).show();
//            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                    Constants.BROADCAST_MESSAGE_STOP_SOUND);
//        } else {
//            // Toast.makeText(this, getString(R.string.sound_on), 3000).show();
//            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                    Constants.BROADCAST_MESSAGE_START_SOUND);
//        }
//    }

    private void videoAction(boolean isChecked) {
        if (isChecked) {
            peerConnectionManager.startVideoSource();
        } else {
            peerConnectionManager.stopVideoSource();
        }
    }

    public void onCameraSwitch() {
        if (videoCapturer != null) {
            if (videoCapturer instanceof CameraVideoCapturer) {
                ((CameraVideoCapturer) videoCapturer).switchCamera(null);
            }
        }
    }

    public void onVideoScalingSwitch(ScalingType scalingType) {
        fullscreenRenderer.setScalingType(scalingType);
    }

    // Helper functions.
    private void toggleCallControlFragmentVisibility() {
        if (!iceConnected) {
            return;
        }

        callControlContainerVisible = !callControlContainerVisible;
//        RelativeLayout fullPageContainer = (RelativeLayout) findViewById(R.id.full_page_container);
//        if (callControlContainerVisible) {
//            fullPageContainer.setVisibility(View.VISIBLE);
//            fullPageContainer.bringToFront();
//        } else {
//            fullPageContainer.setVisibility(View.INVISIBLE);
//        }
    }


    /**
     * It just starts a timer of the call
     */
    private void startCall() {
        callStartedTimeMs = System.currentTimeMillis();

        // Create and audio manager that will take care of audio routing,
        // audio modes, audio device enumeration etc.
        audioManager = AppRTCAudioManager.create(getApplicationContext());
        // Store existing audio settings and change audio mode to
        // MODE_IN_COMMUNICATION for best possible VoIP performance.
        // Log.i(TAG, "Starting the audio manager...");
        audioManager.start(new AppRTCAudioManager.AudioManagerEvents() {
            // This method will be called each time the number of available audio
            // devices has changed.
            @Override
            public void onAudioDeviceChanged(
                    AudioDevice audioDevice, Set<AudioDevice> availableAudioDevices) {
                onAudioManagerDevicesChanged(audioDevice, availableAudioDevices);
            }
        });
    }

    // Should be called from UI thread
    private void callConnected() {
//        final long delta = System.currentTimeMillis() - callStartedTimeMs;
//        Log.i(TAG, "Call connected: delay=" + delta + "ms");
//        if (peerConnectionClient == null || isError) {
//            Log.w(TAG, "Call connected in closed or error state");
//            return;
//        }
//        // Enable statistics callback.
//        peerConnectionClient.enableStatsEvents(true, STAT_CALLBACK_PERIOD);
//        setSwappedFeeds(false /* isSwappedFeeds */);
    }

    // This method is called when the audio manager reports audio device change,
    // e.g. from wired headset to speakerphone.
    private void onAudioManagerDevicesChanged(
            final AudioDevice device, final Set<AudioDevice> availableDevices) {
        Log.i(TAG, "onAudioManagerDevicesChanged: " + availableDevices + ", "
                + "selected: " + device);
        // TODO(henrika): add callback handler.
    }

    // Disconnect from remote resources, dispose of local resources, and exit.
    private void disconnect() {
//        remoteProxyVideoSink.setTarget(null);
        localProxyVideoSink.setTarget(null);
        if (pipRenderer != null) {
            pipRenderer.release();
            pipRenderer = null;
        }
        if (fullscreenRenderer != null) {
            fullscreenRenderer.release();
            fullscreenRenderer = null;
        }
        if (audioManager != null) {
            audioManager.stop();
            audioManager = null;
        }

        for (int i = 0; i < remoteViewContainers.getChildCount(); i++) {
            View v = remoteViewContainers.getChildAt(i);
            if (v instanceof SurfaceViewRenderer) {
                ((SurfaceViewRenderer) v).release();
            }
        }
    }

    /**
     * On ice connectrion state goes to failed then we temporarily finished the activity
     * Here the Ice Restart procedure have to be implemented.
     *
     * @param description
     */
    private void reportError(final String description) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (!isError) {
                    isError = true;
                    Log.e(TAG, description);
//                    finish();
                }
            }
        });
    }

    private VideoCapturer createVideoCapturer() {
        VideoCapturer videoCapturer = null;
        String videoFileAsCamera = null;//getIntent().getStringExtra(EXTRA_VIDEO_FILE_AS_CAMERA);
        if (videoFileAsCamera != null) {
            try {
                videoCapturer = new FileVideoCapturer(videoFileAsCamera);
            } catch (IOException e) {
                reportError("Failed to open video file for emulated camera");
                return null;
            }
        } else if (screenCaptureEnabled) {
            return createScreenCapturer();
        } else if (useCamera2()) {
            if (!captureToTexture()) {
                reportError(getString(R.string.camera2_texture_only_error));
                return null;
            }

            Logging.d(TAG, "Creating capturer using camera2 API.");
            videoCapturer = createCameraCapturer(new Camera2Enumerator(this));
        } else {
            Logging.d(TAG, "Creating capturer using camera1 API.");
            videoCapturer = createCameraCapturer(new Camera1Enumerator(captureToTexture()));
        }
        if (videoCapturer == null) {
            reportError("Failed to open camera");
            return null;
        }
        return videoCapturer;
    }

    /**
     * The UI interchanges between preview window and on Call video window.
     * witching of the two window is done here.
     *
     * @param isSwappedFeeds : boolean value to determine which window will get full window access.
     */
    private void setSwappedFeeds(boolean isSwappedFeeds) {
        Logging.d(TAG, "setSwappedFeeds: " + isSwappedFeeds);
        this.isSwappedFeeds = isSwappedFeeds;
        pipRenderer.setVisibility(View.VISIBLE);
        fullscreenRenderer.setVisibility(View.VISIBLE);
        localProxyVideoSink.setTarget(isSwappedFeeds ? fullscreenRenderer : pipRenderer);
        localFullScreenProxyVideoSink.setTarget(isSwappedFeeds ? pipRenderer : fullscreenRenderer);
        fullscreenRenderer.setMirror(isSwappedFeeds);
        pipRenderer.setMirror(!isSwappedFeeds);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        }
    }

    private boolean ifWiredHeadsetOn() {
        AudioManager mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        return (mAudioManager.isWiredHeadsetOn());
    }


    public void fetchRunningGroupCalls(String userID) throws JSONException {
        Request newMemberMessage = new Request();
        newMemberMessage.type = MESSAGE_TYPE_FETCH_RUNNIG_GROUP_CALL;
        JSONObject request = new JSONObject();
        request.put(ATTRIBUTE_USERID, userID);
        newMemberMessage.info = request;
        callManager.send(newMemberMessage);
    }

    public void joinGroupCall(String groupid, String userID) throws JSONException {
        findViewById(R.id.single_button_space).setVisibility(View.VISIBLE);
        findViewById(R.id.double_button_space).setVisibility(View.GONE);

        Request newMemberMessage = new Request();
        newMemberMessage.type = MESSAGE_TYPE_JOIN_GROUP_CALL;
        JSONObject request = new JSONObject();
        request.put(ATTRIBUTE_GROUPID, groupid);
        request.put(ATTRIBUTE_USERID, userID);
        newMemberMessage.info = request;
        callManager.send(newMemberMessage);
//        DataHelper.getInstance(this).createSystemMessage(""+System.nanoTime(), groupid, "You have joined a group call", 0, System.currentTimeMillis());
    }


    public void createGroupCall(String groupid, String userID) throws JSONException {
//        String[] members = DataHelper.getInstance().getGroupNumbers(groupid);
//        if (members.length <= 1) {
//            Toast.makeText(this, "Not enough member in the group to make a conference call, please add some participants to make a successful call", Toast.LENGTH_LONG).show();
//            finish();
//            return;
//        }
        Request newMemberMessage = new Request();
        newMemberMessage.type = MESSAGE_TYPE_CREATE_GROUP_CALL;
        JSONObject request = new JSONObject();
        request.put(ATTRIBUTE_GROUPID, groupid);
        request.put(ATTRIBUTE_USERID, userID);
        ArrayList<String> numbers = new ArrayList<>(Arrays.asList(group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber));
        if (!numbers.contains(userID)) {
            numbers.add(userID);
        }
        request.put(ATTRIBUTE_GROUP_MEMBERS, new JSONArray(numbers));
        newMemberMessage.info = request;
        callManager.send(newMemberMessage);
        E2EPublicKeySeedAndPrivateKeyHolder holder = GroupRepo.get().getE2EPublicKeySeedAndPrivateKeyHolderForGroup(groupid);
        sendMessage(groupid, !TextUtils.isEmpty(holder.privateKey), Constants.Call.VIDEO_CONFERNECE_PREFIX);
//        DataHelper.getInstance(this).createSystemMessage(""+System.nanoTime(), groupid, "You have joined a group call", 0, System.currentTimeMillis());
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void sendMessage(String to, boolean isEncryptedChat, String message){
        Sender.getAccess().getConfiguration().target(to).isEncryptedChat(isEncryptedChat).isGroupChat(true).configure();
        Sender.getAccess().sendTextMessage(message);
    }

    public void leaveGroupCall(String groupid, String userID) throws JSONException {
        Request newMemberMessage = new Request();
        newMemberMessage.type = MESSAGE_TYPE_LEAVE_GROUP_CALL;
        JSONObject request = new JSONObject();
        request.put(ATTRIBUTE_GROUPID, groupid);
        request.put(ATTRIBUTE_USERID, userID);
        newMemberMessage.info = request;
        callManager.send(newMemberMessage);
    }


    private ProxyVideoSink getNewRemoteVideoSinks(String numToCall) {
//        final ArrayList<ProxyVideoSink> remoteSinks = new ArrayList<>();
        if(conferenceCallHolder.size() > 0) {
            ProxyVideoSink remoteSink = new ProxyVideoSink();
//        ProxyVideoSink remoteProxyVideoSink = new ProxyVideoSink();
            final SurfaceViewRenderer remoteVideoRenderer = new SurfaceViewRenderer(this);
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) (metrics.density * 100), (int) (metrics.density * 144));
            params.leftMargin = (int) (metrics.density * 4);
            params.rightMargin = (int) (metrics.density * 4);
            params.topMargin = (int) (metrics.density * 4);
            params.bottomMargin = (int) (metrics.density * 4);
            remoteVideoRenderer.setLayoutParams(params);
            remoteVideoRenderer.setId(Math.abs(numToCall.hashCode()));
            Log.e("VideoConference", "remote_pip_renderer: " + Integer.toHexString(Math.abs(numToCall.hashCode())));
            remoteVideoRenderer.init(rootEglBase.getEglBaseContext(), null);
            remoteVideoRenderer.setScalingType(ScalingType.SCALE_ASPECT_FIT);
            remoteVideoRenderer.setZOrderMediaOverlay(true);
            remoteVideoRenderer.setEnableHardwareScaler(true);

            remoteViewContainers.addView(remoteVideoRenderer);
            remoteSink.setTarget(remoteVideoRenderer);
//            remoteSinks.add(remoteSink);
//        remoteSinks.add(remoteProxyVideoSink);

//        if (conferenceCallHolder.size() == 0) {
//            remoteProxyVideoSink.setTarget(fullscreenRenderer);
//            if (localFullScreenProxyVideoSink != null) {
//                localFullScreenProxyVideoSink.setTarget(null);
//            }
//            localFullScreenProxyVideoSink = remoteProxyVideoSink;
//        }

            remoteVideoRenderer.setTag(remoteSink);
            remoteVideoRenderer.setOnClickListener(renderer -> {
                ProxyVideoSink fullSink = (ProxyVideoSink) renderer.getTag();
                ProxyVideoSink smallSink = localFullScreenProxyVideoSink;

                renderer.setTag(smallSink);
                if (smallSink != null) {
                    smallSink.setTarget((SurfaceViewRenderer) renderer);
                }

                fullscreenRenderer.setTag(fullSink);
                localFullScreenProxyVideoSink = fullSink;
                if (localFullScreenProxyVideoSink != null) {
                    localFullScreenProxyVideoSink.setTarget(fullscreenRenderer);
                }
            });
            Log.i(TAG, "getNewRemoteVideoSinks for number: " + numToCall);
            return remoteSink;
        } else {
//            remoteSinks.add(localFullScreenProxyVideoSink);
            fullscreenRenderer.setTag(localFullScreenProxyVideoSink);
            return localFullScreenProxyVideoSink;
        }
    }


    public void makeCallToNumber(String numToCall) {
        runOnUiThread(() -> {
            Log.i(TAG, "Make call to number: " + numToCall);
            if (!conferenceCallHolder.containsKey(numToCall)) {
                AppRTCCallManager CallManager = new AppRTCCallManager(this, roomid, numToCall, getNewRemoteVideoSinks(numToCall), callManager, peerConnectionManager, turnInfo);
                CallManager.gatherICEInfo(null, true);
                conferenceCallHolder.put(numToCall, CallManager);
            }
        });
    }


    private void processOffer(JSONObject response, String numToCall) {
        runOnUiThread(() -> {
            setSwappedFeeds(false /* isSwappedFeeds */);
            Log.i(TAG, "processOffer from number: " + numToCall);
            try {
                AppRTCCallManager appRTCCallManager = conferenceCallHolder.get(numToCall);
                if (appRTCCallManager == null) {
                    appRTCCallManager = new AppRTCCallManager(this, roomid, numToCall, getNewRemoteVideoSinks(numToCall), callManager, peerConnectionManager, turnInfo);
                    conferenceCallHolder.put(numToCall, appRTCCallManager);
                }
                appRTCCallManager.setRemoteSDP(SDPUtil.getSDPFromJSON(response.toString()), false);
            } catch (Exception e) {
                Toast.makeText(this, "invalid offer from server : " + response.toString(), Toast.LENGTH_LONG).show();
                Log.e(TAG, "invalid offer from server: ", e);
//            e.printStackTrace();
            }
        });
    }

    private void processAnswer(JSONObject response, String numToCall) {
        runOnUiThread(() -> {
            setSwappedFeeds(false /* isSwappedFeeds */);
            Log.i(TAG, "processAnswer from number: " + numToCall);
            try {
                AppRTCCallManager appRTCCallManager = conferenceCallHolder.get(numToCall);
                if (appRTCCallManager == null) {
                    appRTCCallManager = new AppRTCCallManager(this, roomid, numToCall, getNewRemoteVideoSinks(numToCall), callManager, peerConnectionManager, turnInfo);
                    conferenceCallHolder.put(numToCall, appRTCCallManager);
                }
                appRTCCallManager.setRemoteSDP(SDPUtil.getSDPFromJSON(response.toString()), true);
            } catch (Exception e) {
                Toast.makeText(this, "invalid answer from server : " + response.toString(), Toast.LENGTH_LONG).show();
                Log.e(TAG, "invalid answer from server: ", e);
            }
        });
    }

    public void handleNotificationFromGroup(String groupID, String fromUser, String notifyType) {
        if (roomid.equals(groupID)) {
            switch (notifyType) {
                case GROUP_NOTIFICATION_TYPE_GROUP_LEFT:
                    handleGroupLeft(fromUser);
                    break;
            }
        }
    }

    private void handleGroupLeft(String userID) {
        if (conferenceCallHolder.containsKey(userID)) {
            if (conferenceCallHolder.size() > 1) {
                AppRTCCallManager appRTCCallManager = conferenceCallHolder.remove(userID);
                if (appRTCCallManager != null) {
                    appRTCCallManager.close();
                }
                runOnUiThread(() -> {
//                            View v = remoteViewContainers.findViewById(Math.abs(userID.hashCode()));
//                            if (v != null) {
//
//                                ((SurfaceViewRenderer) v).release();
//                                remoteViewContainers.removeView(v);
//                                remoteViewContainers.invalidate();
//
//                                if(localFullScreenProxyVideoSink == (ProxyVideoSink) v.getTag()){
//                                    if (localFullScreenProxyVideoSink != null) {
//                                        localFullScreenProxyVideoSink.setTarget(null);
//                                    }
//                                    if(remoteViewContainers.getChildCount() > 0) {
//                                        Object sink = remoteViewContainers.getChildAt(0).getTag();
//                                        if(sink instanceof ProxyVideoSink) {
//                                            localFullScreenProxyVideoSink = (ProxyVideoSink) sink;
//                                            localFullScreenProxyVideoSink.setTarget(fullscreenRenderer);
//                                        }
//                                    }
//                                }
//                            }
                    boolean removed = false;
                            for (int i = 0; i < remoteViewContainers.getChildCount(); i++){
                                View v = remoteViewContainers.getChildAt(i);
                                if (appRTCCallManager != null && appRTCCallManager.getRemoteSink().equals(v.getTag())) {
                                    remoteViewContainers.removeView(v);
                                    removed = true;
                                }
                            }
                            if (!removed && remoteViewContainers.getChildCount() > 0){
                                View v = remoteViewContainers.getChildAt(0);
                                if (localFullScreenProxyVideoSink != null) {
                                    localFullScreenProxyVideoSink.setTarget(null);
                                }
                                localFullScreenProxyVideoSink = (ProxyVideoSink) v.getTag();
                                if (localFullScreenProxyVideoSink != null) {
                                    localFullScreenProxyVideoSink.setTarget(fullscreenRenderer);
                                }
                                fullscreenRenderer.setTag(localFullScreenProxyVideoSink);
                                remoteViewContainers.removeView(v);
                            }
                        }
                    );
            } else {
                AppRTCCallManager appRTCCallManager = conferenceCallHolder.remove(userID);
                if (appRTCCallManager != null) {
                    appRTCCallManager.close();
                }
                finish();
                Log.w(TAG, " finish from handleGroupLeft");
            }
        }
    }

    @Override
    public void onWebSocketMessage(String message) {
        Log.w(TAG, "Response in web socket : " + message);
        try {
            Response response = Response.toObject(new JSONObject(message));
            switch (response.type) {
                case MESSAGE_TYPE_RECEIVE_WEBRTC_MESSAGE:
                    WebRTCResponse rtcResponse = WebRTCResponse.toObject(response.response);
                    if (!TextUtils.isEmpty(rtcResponse.wbRtcMsgType)) {
                        AppRTCCallManager appRTCCallManager = null;
                        String numToCall = "";
                        switch (rtcResponse.wbRtcMsgType) {
                            case WB_MESSAGE_TYPE_OFFER:
                                numToCall = rtcResponse.sendFromUserID;
                                processOffer((JSONObject) rtcResponse.wbRtcMsg, numToCall);
                                break;
                            case WB_MESSAGE_TYPE_ANSWER:
                                numToCall = rtcResponse.sendFromUserID;
                                processAnswer((JSONObject) rtcResponse.wbRtcMsg, numToCall);
                                break;
                            case WB_MESSAGE_TYPE_PRANSWER:

                                break;
                            case WB_MESSAGE_TYPE_CANDIDATE:
                                numToCall = rtcResponse.sendFromUserID;
                                appRTCCallManager = conferenceCallHolder.get(numToCall);
                                if (appRTCCallManager != null) {
                                    appRTCCallManager.onRemoteIceCandidate(ICECandidateUtilConference.getICECandidateFromJSON(rtcResponse.wbRtcMsg.toString()));
                                }
                                break;
                            case WB_MESSAGE_TYPE_REMOVED_CANDIDATES:
                                numToCall = rtcResponse.sendFromUserID;
                                appRTCCallManager = conferenceCallHolder.get(numToCall);
                                if (appRTCCallManager != null) {
                                    appRTCCallManager.onRemoteIceCandidatesRemoved(ICECandidateUtilConference.getICECandidatesFromJSONArray(rtcResponse.wbRtcMsg.toString()));
                                }
                                break;
//                            case "leave":
//                                numToCall = response.getString("name");
//                                appRTCCallManager = conferenceCallHolder.get(numToCall);
//                                if(appRTCCallManager != null){
//                                    appRTCCallManager.close();
//                                    conferenceCallHolder.remove(numToCall);
//                                }
//                                break;
//                            case "connectedUsers":
//                                if(response.has("connectedUsers")){
//                                    JSONArray array = response.getJSONArray("connectedUsers");
//                                    for(int i = 0; i < array.length(); i++) {
//                                        String num = array.getString(i);
//                                        makeCallToNumber(num);
//                                    }
//                                }
//                                break;
                            default:
                                Toast.makeText(this, "invalid wbmessage from server : " + message, Toast.LENGTH_LONG).show();
                                Log.e(TAG, "Invalid wbmessage from server: " + message);
                                break;
                        }
                    } else {
                        Toast.makeText(this, "invalid message from server: " + message, Toast.LENGTH_LONG).show();
                    }
                    break;
                case MESSAGE_TYPE_GROUP_CONFERENCE_TERMINATED:
                    Toast.makeText(this, "Video conference terminated", Toast.LENGTH_LONG).show();
                    Log.w(TAG, " finish from MESSAGE_TYPE_GROUP_CONFERENCE_TERMINATED");
                    finish();
                    break;
                case MESSAGE_TYPE_FETCH_RUNNIG_GROUP_CALL:
                    if (response.status == Response.STATUS_SUCCESS) {
                        boolean found = false;
                        try {
                            JSONArray rooms = response.response.getJSONArray(ATTRIBUTE_RUNNING_CONFERENCE_IDS);
                            for (int i = 0; i < rooms.length(); i++) {
                                String room = rooms.get(i).toString();
                                if (room.equals(roomid)) {
                                    found = true;
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        if (found) {
                            joinGroupCall(roomid, loginNumber);
                        } else {
                            createGroupCall(roomid, loginNumber);
                        }
                    } else {
                        Toast.makeText(this, "Running call fetching failed", Toast.LENGTH_LONG).show();
                        Log.w(TAG, "Running call fetching failed");
                        Log.w(TAG, " finish from MESSAGE_TYPE_FETCH_RUNNIG_GROUP_CALL");
                        finish();
                    }
                    break;
                case MESSAGE_TYPE_CREATE_GROUP_CALL:
                    if (response.status == Response.STATUS_SUCCESS) {
                        Toast.makeText(this, "You have successfully created a group call", Toast.LENGTH_LONG).show();
                        Log.i(TAG, "You have successfully created a group call");
                    } else {
                        Toast.makeText(this, "Group call creation failed", Toast.LENGTH_LONG).show();
                        Log.w(TAG, "Group call creation failed");
                        Log.w(TAG, " finish from MESSAGE_TYPE_CREATE_GROUP_CALL");
                        finish();
                    }
                    break;
                case MESSAGE_TYPE_JOIN_GROUP_CALL:
                    if (response.status == Response.STATUS_SUCCESS) {
                        try {
                            JSONArray members = response.response.getJSONArray(ATTRIBUTE_GROUP_MEMBERS);
                            for (int i = 0; i < members.length(); i++) {
                                String member = members.get(i).toString();
                                if (!member.equals(loginNumber)) {
                                    makeCallToNumber(member);
                                    try {
                                        Thread.sleep(1000);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        Toast.makeText(this, "Joining to the group call failed", Toast.LENGTH_LONG).show();
                        Log.w(TAG, "Joining to the group call failed");
                        Log.w(TAG, " finish from MESSAGE_TYPE_JOIN_GROUP_CALL");
                        finish();
                    }
                    break;
                case MESSAGE_TYPE_NOTIFICATION_FROM_GROUP:
                    if (response.status == Response.STATUS_SUCCESS) {
                        try {
                            String fromUser = response.response.getString(ATTRIBUTE_SEND_FROM_USERID);
                            String groupID = response.response.getString(ATTRIBUTE_GROUPID);
                            String notificationType = response.response.getString(ATTRIBUTE_NOTIFICATION_TYPE);
                            handleNotificationFromGroup(groupID, fromUser, notificationType);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        Toast.makeText(this, "Joining to the group call failed", Toast.LENGTH_LONG).show();
                        Log.w(TAG, "Joining to the group call failed");
                        Log.w(TAG, " finish from MESSAGE_TYPE_NOTIFICATION_FROM_GROUP");
                        finish();
                    }
                    break;
            }
        } catch (Exception e) {
            Toast.makeText(this, "Failed, Invalid response" + message, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onWebSocketClose() {
        Toast.makeText(this, "Connection closed", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onWebSocketError(String description) {
        Toast.makeText(this, "Connection error", Toast.LENGTH_LONG).show();
    }

    public void endCall(View view) {
        sendIntentMessageToDialer("stop_ringing","1");
        finish();
        Log.w(TAG, " finish from endCall");
    }

    public void acceptCall(View view) {
        sendIntentMessageToDialer("stop_ringing","0");
        try {
            joinGroupCall(roomid, loginNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }
        setSwappedFeeds(false);
    }

    private void sendIntentMessageToDialer(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, new String[]{"", message, "0", "0"});
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendIntentMessageToDialer(String type, String groupId, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, new String[]{groupId, message, "1", "1"});
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
}
