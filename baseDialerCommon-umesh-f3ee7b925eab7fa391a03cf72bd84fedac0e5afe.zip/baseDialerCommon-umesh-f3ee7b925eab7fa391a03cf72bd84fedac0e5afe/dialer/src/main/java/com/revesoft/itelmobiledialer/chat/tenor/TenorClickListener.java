package com.revesoft.itelmobiledialer.chat.tenor;

/**
 * @author Ifta on 11/1/2017.
 */

public interface TenorClickListener {
    void onTenorClick(TenorGif tenorGif);
}
