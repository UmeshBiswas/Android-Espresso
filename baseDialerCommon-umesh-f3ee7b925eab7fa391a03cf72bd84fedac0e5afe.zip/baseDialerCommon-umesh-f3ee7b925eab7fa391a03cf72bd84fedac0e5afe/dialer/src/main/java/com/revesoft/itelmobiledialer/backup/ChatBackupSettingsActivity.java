package com.revesoft.itelmobiledialer.backup;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.DriveServiceHelper;
import com.revesoft.itelmobiledialer.backup.googledrivebackup.GoogleDriveChatBackupApi;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.eventlistener.BackupOperationStatusData;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.eventlistener.DialerListener;
import com.revesoft.itelmobiledialer.eventlistener.EventData;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;


@SuppressWarnings("all")
public class ChatBackupSettingsActivity extends BaseActivity implements DialerListener {




    SharedPreferences preferences;
    TextView textViewBackupDate, textViewBackupSize;
    private static final int REQUEST_CODE_SIGN_IN = 1;
    private PendingIntent pendingIntentAutoBackupService;
    private TextView tvAutoBackUpOption;
    long lastBackupDate, lastBackupSize;
    boolean isGoogleAccountLinked = false;
    String googleAccountEmailAddress;
    boolean isBackupRequest = false;
    private DriveServiceHelper mDriveServiceHelper = null;


    View rlBackupInfo, rlBackupError;
    TextView tvBackupInfo, tvBackupError;


    private void handleToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(getString(R.string.chats));
        }
    }


    private void cancelAlarm() {
        AlarmManager manager = (AlarmManager) getSystemService(this.ALARM_SERVICE);
        manager.cancel(pendingIntentAutoBackupService);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_chat_backup_settings);
        tvAutoBackUpOption = (TextView) findViewById(R.id.tvAutoBackUpOption);
        preferences = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
        textViewBackupDate = (TextView) findViewById(R.id.tv_last_backupdate);
        textViewBackupSize = (TextView) findViewById(R.id.tv_backup_size);
        pendingIntentAutoBackupService = PendingIntent.getService(this, 0, new Intent(this, AutoBackupService.class), 0);
        rlBackupError = findViewById(R.id.rl_backup_error);
        rlBackupInfo = findViewById(R.id.rl_backup_info);
        tvBackupInfo = findViewById(R.id.tv_backup_info_text);
        tvBackupError = findViewById(R.id.tv_backup_error_text);
        updateView();
        handleToolbar();
        register();

    }

    private void setWeeklyAlarm() {
        AlarmManager manager = (AlarmManager) getSystemService(this.ALARM_SERVICE);
        long interval = 1000 * 60 * 60 * 24 * 7;
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntentAutoBackupService);

    }

    private void setMonthlyAlarm() {
        AlarmManager manager = (AlarmManager) getSystemService(this.ALARM_SERVICE);
        long interval = 1000 * 60 * 60 * 24 * 7 * 30;
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntentAutoBackupService);

    }

    private void setDailyAlarm() {
        AlarmManager manager = (AlarmManager) getSystemService(this.ALARM_SERVICE);
        long interval = 1000 * 60 * 60 * 24;
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), interval, pendingIntentAutoBackupService);

    }

    void updateView() {

        handleGoogleAccountView();
        findViewById(R.id.ll_auto_back_up).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ChatBackupSettingsActivity.this);
                builder.setItems(getResources().getStringArray(R.array.auto_backup_options), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        preferences.edit().putInt(Constants.AUTO_BACKUP_SELECTION_POSITION,which).apply();
                        switch (which) {
                            case 0:
                                setDailyAlarm();
                                break;
                            case 1:
                                setWeeklyAlarm();
                                break;
                            case 2:
                                setMonthlyAlarm();
                                break;
                            case 3:
                                cancelAlarm();
                                break;
                        }
                        if (which < 3 && !isGoogleAccountLinked) {
                            requestSignIn();
                        }
                        updateView();
                        dialog.dismiss();
                    }
                });
                builder.create().show();
            }
        });


        lastBackupDate = UserDataManager.getLastBackupTime();
        lastBackupSize = UserDataManager.getLastBackupSize();
        if (lastBackupSize == 0 && lastBackupDate == 0) {
            findViewById(R.id.rl_last_backup).setVisibility(View.GONE);
        } else {
            findViewById(R.id.rl_last_backup).setVisibility(View.VISIBLE);
            updateCreationDateAndSizeView();
        }

        int autoBackUpStatusPosition = preferences.getInt(Constants.AUTO_BACKUP_SELECTION_POSITION, Constants.AUTO_BACKUP_POSITION_DEF);
        String autoBackUpStatus = getResources().getStringArray(R.array.auto_backup_options)[autoBackUpStatusPosition];
        tvAutoBackUpOption.setText(autoBackUpStatus);

    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onStop() {
        super.onStop();
        super.onPause();
    }




    public void finishActivity(View v) {
        finish();
    }

    void handleGoogleAccountView() {
        googleAccountEmailAddress = UserDataManager.getGoogleEmailAddress();
        if (googleAccountEmailAddress.trim().equals("")) {
            findViewById(R.id.rl_google_drive_backup_account_view).setVisibility(View.VISIBLE);
            TextView textView = findViewById(R.id.tv_google_drive_email);
            textView.setText(getString(R.string.sign_in));
            isGoogleAccountLinked = false;

            findViewById(R.id.rl_google_drive_backup_account_view).setOnClickListener(v -> {
                if (!isGoogleAccountLinked) requestSignIn();
            });

            rlBackupInfo.setVisibility(View.VISIBLE);
            tvBackupInfo.setText(getString(R.string.no_google_account));

        } else {
            findViewById(R.id.rl_google_drive_backup_account_view).setVisibility(View.VISIBLE);
            TextView textView = findViewById(R.id.tv_google_drive_email);
            textView.setText(googleAccountEmailAddress);
            isGoogleAccountLinked = true;
            rlBackupInfo.setVisibility(View.GONE);
            rlBackupError.setVisibility(View.GONE);
        }
    }

    private String getFormattedSize(long fileSize) {

        double size;
        DecimalFormat decim = (DecimalFormat) DecimalFormat.getInstance(Locale.US);
        decim.applyPattern("0.00");
        if (fileSize >= (1024 * 1024)) {
            size = fileSize / (1024 * 1024);
            return decim.format(size) + " mb";
        }
        if (fileSize >= 1024) {
            size = fileSize / 1024;
            return decim.format(size) + " kb";
        }
        return fileSize + " b";
    }

    private void updateCreationDateAndSizeView() {
        Date date = new Date(lastBackupDate);

        textViewBackupDate.setText(getString(R.string.last_backup) + " " + getFormattedDateTime(lastBackupDate));
        textViewBackupSize.setText(getString(R.string.total_size) + " " + getFormattedSize(lastBackupSize));
    }

    @Override
    protected void onActivityResult(final int requestCode,
                                    final int resultCode, final Intent data) {

        switch (requestCode) {
            case REQUEST_CODE_SIGN_IN:
                if (resultCode == RESULT_OK) {
                    handleSignInResult(data);
                } else {
                    preferences.edit().putInt(Constants.AUTO_BACKUP_SELECTION_POSITION, 3).apply();
                    cancelAlarm();
                    updateView();
                }
        }
    }

    private void requestSignIn() {

        GoogleSignInOptions signInOptions =
                new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail()
                        .requestScopes(new Scope(DriveScopes.DRIVE_FILE))
                        .build();
        GoogleSignInClient client = GoogleSignIn.getClient(this, signInOptions);
        startActivityForResult(client.getSignInIntent(), REQUEST_CODE_SIGN_IN);
    }

    private void handleSignInResult(Intent result) {
        GoogleSignIn.getSignedInAccountFromIntent(result)
                .addOnSuccessListener(googleAccount -> {
                    UserDataManager.setGoogleEmailAddress(googleAccount.getEmail());
                    GoogleAccountCredential credential =
                            GoogleAccountCredential.usingOAuth2(
                                    this, Collections.singleton(DriveScopes.DRIVE_FILE));
                    credential.setSelectedAccount(googleAccount.getAccount());
                    Drive googleDriveService =
                            new Drive.Builder(
                                    AndroidHttp.newCompatibleTransport(),
                                    new GsonFactory(),
                                    credential)
                                    .setApplicationName("Drive API Migration")
                                    .build();
                    mDriveServiceHelper = new DriveServiceHelper(googleDriveService);
                    updateView();
                    if (isBackupRequest) backupNowAction();
                })
                .addOnFailureListener(exception -> {
                    Toast.makeText(this, "Failed to login Google", Toast.LENGTH_LONG).show();
                    preferences.edit().putInt(Constants.AUTO_BACKUP_SELECTION_POSITION, 3).apply();
                    cancelAlarm();
                    updateView();
                });
    }

    private void handleSignInFromLastContext() {

        GoogleAccountCredential credential = GoogleAccountCredential.usingOAuth2(getApplicationContext(),
                Collections.singleton(DriveScopes.DRIVE_FILE));

        credential.setSelectedAccount(GoogleSignIn.getLastSignedInAccount(getApplicationContext()).getAccount());
        Drive googleDriveService =
                new Drive.Builder(
                        AndroidHttp.newCompatibleTransport(),
                        new GsonFactory(),
                        credential)
                        .setApplicationName("Drive API Migration")
                        .build();
        mDriveServiceHelper = new DriveServiceHelper(googleDriveService);
        GoogleDriveChatBackupApi googleDriveChatBackupApi = new GoogleDriveChatBackupApi(mDriveServiceHelper);
        googleDriveChatBackupApi.requestToCheckConnectionIsOk();
    }

    public void deleteBackup() {

    }



    @Override
    public void onBackPressed() {
        finishActivity(null);
        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return false;
    }

    private String getFormattedDateTime(Long mDateTime) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy ", Locale.ENGLISH);
        return simpleDateFormat.format(mDateTime);
    }

    public void backupChatNow(View view) {
        isBackupRequest = true;


        if (!isGoogleAccountLinked) {
            requestSignIn();
        } else {
            backupNowAction();
        }
    }


    public void backupNowAction() {

        try {
            findViewById(R.id.rl_backup_now).setEnabled(false);
            ((TextView) findViewById(R.id.tv_backup_now)).setText(R.string.backing_up);
            handleSignInFromLastContext();
            findViewById(R.id.progressbar_backup).setVisibility(View.VISIBLE);
        } catch (Exception e) {
        }

    }

    @Override
    public void register() {
        DialerEventHock.getInstance().addListener(this);
    }

    @Override
    public void performOnEvent(DialerEvent event, EventData eventData) {
        Gui.get().run(() -> {
            if (event == DialerEvent.BackUpOperationStatus) {

                ((TextView) findViewById(R.id.tv_backup_now)).setText(R.string.backup_now);
                findViewById(R.id.rl_backup_now).setEnabled(true);
                rlBackupError.setVisibility(View.GONE);
                rlBackupInfo.setVisibility(View.GONE);
                findViewById(R.id.progressbar_backup).setVisibility(View.GONE);
                BackupOperationStatusData data = (BackupOperationStatusData) eventData;
                if (!data.isGoogleDriveReachable()) {
                    rlBackupError.setVisibility(View.VISIBLE);
                    tvBackupError.setText(getString(R.string.google_drive_not_reachable));
                } else if (!data.isGoogleDrivePermitted()) {
                    rlBackupInfo.setVisibility(View.VISIBLE);
                    tvBackupInfo.setText(getString(R.string.no_drive_permission));
                    isGoogleAccountLinked = false;
                    preferences.edit().putInt(Constants.AUTO_BACKUP_SELECTION_POSITION, 3).apply();
                    cancelAlarm();
                    String autoBackUpStatus = getResources().getStringArray(R.array.auto_backup_options)[3];
                    tvAutoBackUpOption.setText(autoBackUpStatus);
                } else if (isBackupRequest && data.isGoogleDriveReachable() && data.isGoogleDrivePermitted()) {
                    ((TextView) findViewById(R.id.tv_backup_now)).setText(R.string.backing_up);
                    findViewById(R.id.rl_backup_now).setEnabled(false);
                    findViewById(R.id.progressbar_backup).setVisibility(View.VISIBLE);
                    GoogleDriveChatBackupApi googleDriveChatBackupApi = new GoogleDriveChatBackupApi(mDriveServiceHelper);
                    googleDriveChatBackupApi.backUpChatNow();
                    isBackupRequest = false;
                } else if (data.isOperationStatus()) {
                    updateView();
                }

            }
        });

    }
}