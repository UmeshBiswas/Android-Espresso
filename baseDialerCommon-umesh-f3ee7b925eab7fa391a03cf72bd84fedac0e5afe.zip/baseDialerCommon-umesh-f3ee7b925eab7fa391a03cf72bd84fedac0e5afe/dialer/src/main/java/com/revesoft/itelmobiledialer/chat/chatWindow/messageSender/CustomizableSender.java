package com.revesoft.itelmobiledialer.chat.chatWindow.messageSender;

import android.content.Intent;

import com.revesoft.itelmobiledialer.braodcast.QuickBroadCaster;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.material.R;

import java.io.UnsupportedEncodingException;

import static com.revesoft.itelmobiledialer.util.Constants.compose;
import static com.revesoft.itelmobiledialer.arch.Supplier.getString;

/**
 * @author Ifta on 1/17/2018.
 */

public class CustomizableSender {
    public static void sendMessage(String message, String target, boolean isGroup, boolean isEncrypted) {
        if(message.length() > SendingConstants.MAX_IM_LENGTH){
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        Sender.Configuration currentConfiguration = Sender.getAccess().getCurrentConfiguration();
        Sender.getAccess().getConfiguration().isEncryptedChat(isEncrypted).isGroupChat(isGroup).isSMSChat(false).target(target).configure();
        Sender.getAccess().sendTextMessage(message);
        Sender.getAccess().changeConfiguration(currentConfiguration);
    }

    public static void sendSMS(String messageToSend, String target, boolean isGroupChat) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        if (isGroupChat) {
            intent.putExtra(SendingConstants.SMS_FROM_GROUP, true);
            //Target.group.allOtherMembersNumberButMe
            try {
                byte[] utf8Bytes = messageToSend.getBytes("UTF-8");
                int length = utf8Bytes.length;
                if (length <= 1000) {
                    intent.putExtra(compose, messageToSend);
                    if (!isGroupChat) {
                        String[] numbers;
                        numbers = new String[1];
                        numbers[0] = target;
                        intent.putExtra("to1", numbers);
                    } else {
//
//                        Group group = GroupChatAssistance.getGroupById(target);
//                        intent.putExtra("to1", group.allOtherMembersNumberButMe);
//                        intent.putExtra("groupid", group.id);
                    }
                    QuickBroadCaster.broadcast(intent);
                } else {
                    I.toast(getString(R.string.text_length_is_too_big));

                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        } else {
            intent.putExtra(SendingConstants.SMS, true);
            try {
                byte[] utf8Bytes = messageToSend.getBytes("UTF-8");
                int length = utf8Bytes.length;
                if (length <= 1000) {
                    intent.putExtra(compose, messageToSend);
                    if (!isGroupChat) {
                        String[] numbers;
                        numbers = new String[1];
                        numbers[0] = Target.target;
                        intent.putExtra("to1", numbers);
                    } else {
//                        Group group = GroupChatAssistance.getGroupById(target);
//                        intent.putExtra("to1", group.allOtherMembersNumberButMe);
//                        intent.putExtra("groupid", group.id);
                    }
                    QuickBroadCaster.broadcast(intent);
                } else {
                    I.toast(getString(R.string.text_length_is_too_big));

                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
    }

    public static void sendFileMessage(String filePath, String target, boolean isGroup, boolean isEncrypted) {
        Sender.Configuration currentConfiguration = Sender.getAccess().getCurrentConfiguration();
        Sender.getAccess().getConfiguration().isEncryptedChat(isEncrypted).isGroupChat(isGroup).isSMSChat(false).target(target).configure();
        Sender.getAccess().sendFile(filePath);
        Sender.getAccess().changeConfiguration(currentConfiguration);
    }

    public static void sendFileMessageWithCaption(String filePath, String caption, String target, boolean isGroup, boolean isEncrypted) {
        Sender.Configuration currentConfiguration = Sender.getAccess().getCurrentConfiguration();
        Sender.getAccess().getConfiguration().isEncryptedChat(isEncrypted).isGroupChat(isGroup).isSMSChat(false).target(target).configure();
        Sender.getAccess().sendFile(filePath, caption);
        Sender.getAccess().changeConfiguration(currentConfiguration);
    }
}
