package com.revesoft.itelmobiledialer.contact.details;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.util.Log;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.BlockRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.block.ContactBlocker;
import com.revesoft.itelmobiledialer.chat.chatList.ChatListAdapter;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.dialogues.CustomDialogNotificationSet;
import com.revesoft.itelmobiledialer.eventlistener.BlockStatusChangeData;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.eventlistener.MuteOrUnMuteEventData;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.processor.contactblock.ContactBlockHelper;
import com.revesoft.itelmobiledialer.sdkdb.repository.MessageHistoryTimeRepo;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.Ringer;
import com.revesoft.material.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;

public class ContactDetailsHelper {
    private static ContactDetailsHelper helper = null;
    private MediaPlayer audioPlayer;

    private ContactDetailsHelper() {
        audioPlayer = new MediaPlayer();
    }

    public static ContactDetailsHelper getAccess() {
        if (helper == null) {
            helper = new ContactDetailsHelper();
        }
        return helper;
    }


    public void handleCustomTone(Activity activity, String keyNumber) {
        final HashMap<Integer, String> ringtoneMap = new HashMap<Integer, String>() {
            {
                put(0, "ringtone_one");
                put(1, "ringtone_two");
                put(2, "ringtone_three");
                put(3, "ringtone_four");
                put(4, "ringtone_five");
                put(5, "ringtone_six");
                put(6, "ringtone_seven");
                put(7, "ringtone_eight");
            }
        };
        AlertDialog.Builder dialog = new AlertDialog.Builder(activity);
        final CharSequence[] items = {Supplier.getString(R.string.phone_ringtone), Supplier.getString(R.string.salam_ringtone)};
        dialog.setItems(items, (dialog1, which) -> {
            if (which == 0) {
                Intent ringtoneSelectionIntent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
                ringtoneSelectionIntent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(AccountPreference.get(keyNumber + AccountPreference.Keys.RINGTONE_URI, Ringer.getDefaultRingToneUri())));
                Log.e("ringtone picker", Uri.parse(AccountPreference.get(keyNumber + AccountPreference.Keys.RINGTONE_URI, Ringer.getDefaultRingToneUri())).toString());
                ringtoneSelectionIntent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
                ringtoneSelectionIntent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
                activity.startActivityForResult(ringtoneSelectionIntent, ContactDetailsActivity.RINGTONE_PICKER_REQUEST_CODE);
            } else {
                final AlertDialog.Builder selectTone = new AlertDialog.Builder(activity);
                final CharSequence ringTones[] = new CharSequence[ringtoneMap.size()];
                for (int i = 0; i < ringtoneMap.size(); i++) {
                    ringTones[i] = "Ringtone " + Integer.toString(i + 1);

                }
                selectTone.setTitle(Supplier.getString(R.string.select_salam_Ringtone));
                final ArrayList<Integer> whichList = new ArrayList<>();
                selectTone.setSingleChoiceItems(ringTones, -1, (dialog11, which1) -> {
                    try {
                        if (audioPlayer != null) {
                            audioPlayer.stop();
                            audioPlayer.reset();

                        }
                        audioPlayer.setDataSource(activity,
                                Uri.parse("android.resource://" + activity.getPackageName() + "/raw/"
                                        + ringtoneMap.get(which1)));
                        whichList.add(which1);
                        audioPlayer.prepare();
                        audioPlayer.start();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                });
                selectTone.setPositiveButton(Supplier.getString(R.string.ok), (dialog112, which12) -> {
                    if (audioPlayer != null) {
                        audioPlayer.stop();
                        audioPlayer.reset();
                    }
                    if (whichList.size() > 0) {
                        AccountPreference.put(keyNumber + AccountPreference.Keys.RINGTONE_URI,
                                "android.resource://" + activity.getPackageName() + "/raw/"
                                        + ringtoneMap.get(whichList.get(whichList.size() - 1)));
                        Log.e("path", "android.resource://" + activity.getPackageName() + "/raw/"
                                + ringtoneMap.get(whichList.get(whichList.size() - 1)));
                    }

                });
                selectTone.setOnDismissListener(dialog113 -> {
                    if (audioPlayer != null) {
                        audioPlayer.stop();
                        audioPlayer.reset();
                    }
                });

                selectTone.setOnCancelListener(dialog114 -> {
                    if (audioPlayer != null) {
                        audioPlayer.stop();
                        audioPlayer.reset();
                    }
                });
                selectTone.show();
            }
        });
        dialog.show();
    }

    public void handleBlocking(Activity activity, String translatedKeyNumber) {
        ContactBlocker.getInstance().toggleContactBlockStatus(activity, translatedKeyNumber);
    }

    void handleBlockView(String translatedKeyNumber, TextView tvBlock) {
        Executor.ex(() -> {
            boolean isBlocked = BlockRepo.get().isBlockedContact(translatedKeyNumber);
            Gui.get().run(() -> {
                if (isBlocked) {
                    tvBlock.setText(Supplier.getString(R.string.unblock));
                    tvBlock.setTextColor(Supplier.getResources().getColor(R.color.brandPositive));
                    tvBlock.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_unblock, 0, 0, 0);
                } else {
                    tvBlock.setText(Supplier.getString(R.string.block));
                    tvBlock.setTextColor(Supplier.getResources().getColor(R.color.error));
                    tvBlock.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_block, 0, 0, 0);
                }
            });
        });

    }

    void handleBlockView(BlockStatusChangeData blockStatusChangeData, TextView tvBlock) {
        boolean isBlocked = blockStatusChangeData.isBlockStatus();
        Gui.get().run(() -> {
            if (isBlocked) {
                tvBlock.setText(Supplier.getString(R.string.unblock));
                tvBlock.setTextColor(Supplier.getResources().getColor(R.color.brandPositive));
                tvBlock.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_unblock, 0, 0, 0);
            } else {
                tvBlock.setText(Supplier.getString(R.string.block));
                tvBlock.setTextColor(Supplier.getResources().getColor(R.color.error));
                tvBlock.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_block, 0, 0, 0);
            }
        });

    }

    void handleMuteNotificationView(String keyNumber, SwitchCompat sNotification) {
        boolean isMuted = PreferenceDataManager.quickGet(keyNumber + AccountPreference.Keys.RING_MUTE_STATUS, (long) -1) != -1 &&
                isValidMuteDuration(keyNumber + AccountPreference.Keys.NOTIFICATION_MUTE_STATUS, keyNumber + AccountPreference.Keys.RING_MUTE_STATUS);

        sNotification.setChecked(!isMuted);

    }

    private void disPatchMuteOrUnMuteChangeStatus(String keyNumber) {
        boolean isMuted = PreferenceDataManager.quickGet(keyNumber + AccountPreference.Keys.RING_MUTE_STATUS, (long) -1) != -1 &&
                isValidMuteDuration(keyNumber + AccountPreference.Keys.NOTIFICATION_MUTE_STATUS, keyNumber + AccountPreference.Keys.RING_MUTE_STATUS);

        MuteOrUnMuteEventData muteOrUnMuteEventData = new MuteOrUnMuteEventData(keyNumber, isMuted);
        DialerEventHock.getInstance().dispatchEvent(DialerEvent.MuteOrUnMuteChangeEvent, muteOrUnMuteEventData);
    }


    @SuppressLint("ClickableViewAccessibility")
    public void muteOrUnMuteChat(Activity activity, String keyNumber, SwitchCompat switchCompat) {
        switchCompat.setOnClickListener((v) -> {
            handleMuteOrUnMuteChat(activity, keyNumber, switchCompat, null, 0);
        });

    }

    public void muteOrUnMuteChat(Activity activity, String keyNumber, ChatListAdapter chatListAdapter, int position) {
        handleMuteOrUnMuteChat(activity, keyNumber, null, chatListAdapter, position);
    }


    public void handleMuteOrUnMuteChat(Activity activity, String keyNumber, SwitchCompat switchCompat, ChatListAdapter chatListAdapter, int position) {

        if (PreferenceDataManager.quickGet(keyNumber + AccountPreference.Keys.RING_MUTE_STATUS, (long) -1) != -1) {
            PreferenceDataManager.quickRemove(keyNumber + AccountPreference.Keys.RING_MUTE_STATUS);
            PreferenceDataManager.quickRemove(keyNumber + AccountPreference.Keys.NOTIFICATION_MUTE_STATUS);
            disPatchMuteOrUnMuteChangeStatus(keyNumber);
        } else {
            CustomDialogNotificationSet customDialogNotificationSet = new CustomDialogNotificationSet(activity, keyNumber + AccountPreference.Keys.RING_MUTE_STATUS,
                    keyNumber + AccountPreference.Keys.NOTIFICATION_MUTE_STATUS, true);
            customDialogNotificationSet.show();
            customDialogNotificationSet.setOnDismissListener(dialog -> {
                disPatchMuteOrUnMuteChangeStatus(keyNumber);
            });
        }


    }

    private boolean isValidMuteDuration(String keyNotificationMute, String keyRingMute) {
        if (PreferenceDataManager.quickGet(keyRingMute, (long) -1) < System.currentTimeMillis()) {
            PreferenceDataManager.quickRemove(keyNotificationMute);
            PreferenceDataManager.quickRemove(keyRingMute);
            return false;
        }
        return true;
    }

    void handleSpam(Context context, String keyNumber) {
        AlertDialog.Builder bld = new AlertDialog.Builder(context);
        bld.setMessage(R.string.are_you_sure_you_want_to_report_this_as_spam);
        bld.setPositiveButton(R.string.yes, (dialogInterface, i) -> {
            Executor.ex(() -> {
                if (!BlockRepo.get().isBlockedContact(keyNumber)) {
                    Gui.get().run(() -> ContactBlockHelper.getAccess().block(keyNumber));
                }
                long lastMessageDate = MessageRepo.get().lastMessageDate(keyNumber);
                I.log(lastMessageDate);
                if (lastMessageDate > 0) {
                    if (MessageRepo.get().deleteMessageByNumber(keyNumber) > 0) {
                        MessageRepo.get().dummyWithDate(keyNumber, lastMessageDate);
                        MessageRepo.get().deleteMessageByNumber(keyNumber);
                        MessageHistoryTimeRepo.get().getTimeLineItemByUserOrGroupID(keyNumber);
                        Gui.get().run(() -> {
                            I.toast(Supplier.getString(R.string.successful));
                            ((Activity) context).finish();
                        });

                    } else {
                        Gui.get().run(() -> {
                            I.log("deletion failed");
                            I.toast(Supplier.getString(R.string.failed));
                        });

                    }
                } else {
                    I.log("clear chat failed...");
                }
                Gui.get().run(() -> dialogInterface.dismiss());
            });
        });
        bld.setNegativeButton(Supplier.getString(R.string.cancel), (dialogInterface, i) -> dialogInterface.dismiss());
        bld.create().show();
    }
}
