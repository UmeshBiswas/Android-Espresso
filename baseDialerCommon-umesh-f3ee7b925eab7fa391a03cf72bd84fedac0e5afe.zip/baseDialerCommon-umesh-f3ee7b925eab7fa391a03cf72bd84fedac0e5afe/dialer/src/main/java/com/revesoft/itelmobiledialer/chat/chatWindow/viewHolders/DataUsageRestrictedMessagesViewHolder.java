package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import com.revesoft.itelmobiledialer.account.extras.DataUsageRestrictedFileLoadType;
import com.revesoft.itelmobiledialer.braodcast.QuickBroadCaster;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

import androidx.annotation.NonNull;


public class DataUsageRestrictedMessagesViewHolder extends TextMessageViewHolder {
    private Button downloadAnywayButton;
    public DataUsageRestrictedMessagesViewHolder(@NonNull View itemView) {
        super(itemView);
        downloadAnywayButton = itemView.findViewById(R.id.downloadAnywayBtn);
    }

    public void bindView(Message message)
    {
        super.bindView(message);
        handleClickListener(message);
    }

    private void handleClickListener(Message message)
    {
        downloadAnywayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Constants.DATA_USAGE_SETTINGS_CHANGED_INTENT_FILTER);
                intent.putExtra("loading_type", DataUsageRestrictedFileLoadType.LOAD_SINGLE_FORCED);
                intent.putExtra("caller_id",message.callerId);
                QuickBroadCaster.broadcast(intent);
            }
        });
    }

}
