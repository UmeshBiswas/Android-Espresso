package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.iftalab.runtimepermission.DangerousPermission;
import com.iftalab.runtimepermission.PermissionDialogActivity;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.ContactMessage;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.SeenSender;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.ContactMessageCache;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageSelection;
import com.revesoft.itelmobiledialer.customview.RoundedImageView;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.GenericFileProvider;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.property.Telephone;

/**
 * @author Ifta on 12/12/2017.
 */

public class ContactMessageViewHolder extends RetryAndProgressMessageViewHolder {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");
    private View contactHolder;
    private RoundedImageView ivContactMessageContactImage;
    private TextView tvContactName;
    private TextView tvContactNumber;
    private String contactName;
    private String contactNumber;
    private Bitmap contactImage;

    public ContactMessageViewHolder(View view) {
        super(view);
        contactHolder = view.findViewById(R.id.contactHolder);
        ivContactMessageContactImage = (RoundedImageView) view.findViewById(R.id.ivContactMessageContactImage);
        tvContactName = (TextView) view.findViewById(R.id.tvContactName);
        tvContactNumber = (TextView) view.findViewById(R.id.tvContactNumber);
    }

    public void bindView(Message message, int position) {
        super.bindView(message);
        if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
            contactHolder.setBackgroundColor(Color.WHITE);
            if (ChatUtil.isDownloadingNow(message)) {
                tvContactName.setVisibility(View.GONE);
                tvContactNumber.setVisibility(View.GONE);
                ivContactMessageContactImage.setVisibility(View.GONE);
                return;
            }
            try {
                File contactFile = new File(message.filePathLocal);
                if (contactFile.exists()) {
                    List<VCard> vCards = Ezvcard.parse(contactFile).all();
                    if (vCards.size() > 0) {
                        VCard vCard = vCards.get(0);
                        handleClicks(contactFile, vCard, message.callerId, message);
                        ContactMessage contactMessage = new ContactMessage();
                        if (!ContactMessageCache.containsMessage(message.callerId)) {
                            handleContactName(vCard, contactMessage, position);
                            handleContactNumber(vCard, contactMessage, position);
                            handleContactImage(vCards, contactMessage, position);
                            ContactMessageCache.putMessage(message.callerId, contactMessage);
                        } else {
                            contactMessage = ContactMessageCache.findMessage(message.callerId);
                            tvContactName.setText(contactMessage.name);
                            tvContactNumber.setText(contactMessage.number);
                            ivContactMessageContactImage.setImageBitmap(contactMessage.imageBitmap);
                        }
                    }
                } else {
                    logger.log("file not exists");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            String textToSet;
            int textSize = 24;
            textToSet = Supplier.getString(R.string.storagePermissionMissing);
            ColorGenerator generator = ColorGenerator.MATERIAL;
            TextDrawable drawable = TextDrawable
                    .builder()
                    .beginConfig()
                    .fontSize(textSize)
                    .endConfig()
                    .buildRect(textToSet.toUpperCase(), generator.getColor(textToSet));
            contactHolder.setBackground(drawable);
            contactHolder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                        PermissionDialogActivity.takePermission(v.getContext(), PermissionDialogActivity.PermissionType.Storage);
                    } else if (!DangerousPermission.ContactsPermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                        PermissionDialogActivity.takePermission(v.getContext(), PermissionDialogActivity.PermissionType.Contacts);
                    } else {
                        ChatWindowEventHook.dispatchEvent(ChatWindowEvent.ContactShowingCheckingPermission);
                    }
                }
            });
        }
    }

    void grandPermissions() {

    }


    private void handleClicks(final File contactFile, VCard vCard, String callerId, Message message) {
        boolean isSavedContact = false;
        final String savedTarget = null;
        //SeenSender.get().sendSeen(callerId);
        String parserNumbersAndEmails = ChatContentParser.VCardParser.parseNumber(vCard);
        parserNumbersAndEmails += ChatContentParser.VCardParser.parseEmail(vCard);
        if (!TextUtils.isEmpty(parserNumbersAndEmails)) {
            String[] targets = parserNumbersAndEmails.split("\n");
            for (String target : targets) {
                if (!TextUtils.isEmpty(target)) {
                    final String translatedTarget = Util.translateNumber(target);
                    if (CommonData.contactNumberToContactLookUpKey.containsKey(translatedTarget)) {
                        isSavedContact = true;
                        contactHolder.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                if (MessageSelection.isInSelectionMode) {
                                    MessageSelection.addOrRemove(message);
                                    return;
                                }

                                if (tvContactName.getVisibility() == View.GONE) {
                                    return;
                                }
                                SeenSender.getAccess().sendSeen(callerId); //on click e seen sending

                                Switcher.switchToContactDetails(AppContext.getAccess().getContext(), translatedTarget);
                            }
                        });
                        break;
                    }
                }
            }
            if (!isSavedContact) {
                contactHolder.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (MessageSelection.isInSelectionMode) {
                            MessageSelection.addOrRemove(message);
                            return;
                        }
                        if (tvContactName.getVisibility() == View.GONE) {
                            return;
                        }
                        SeenSender.getAccess().sendSeen(callerId); //on click e seen sending

                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(GenericFileProvider.getUriForFile(AppContext.getAccess().getContext(),
                                AppContext.getAccess().getContext().getPackageName() + ".my.package.name.provider", contactFile),
                                ContactsContract.Contacts.CONTENT_VCARD_TYPE); //storage path is path of your vcf file and vFile is name of that file.
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        AppContext.getAccess().getContext().startActivity(intent);

                    }
                });
            }
        } else {
            contactHolder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()
                            && DangerousPermission.ContactsPermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                        if (MessageSelection.isInSelectionMode) {
                            MessageSelection.addOrRemove(message);
                            return;
                        }
                        if (tvContactName.getVisibility() == View.GONE) {
                            return;
                        }
                        SeenSender.getAccess().sendSeen(callerId); //on click e seen sending

                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(Uri.fromFile(contactFile), ContactsContract.Contacts.CONTENT_VCARD_TYPE); //storage path is path of your vcf file and vFile is name of that file.
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        AppContext.getAccess().getContext().startActivity(intent);
                    } else {
                        if (!DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
                            PermissionDialogActivity.takePermission(v.getContext(),PermissionDialogActivity.PermissionType.Storage);
                        } else {
                            PermissionDialogActivity.takePermission(v.getContext(),PermissionDialogActivity.PermissionType.Storage);
                        }
                    }
                }
            });
            contactHolder.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    MessageSelection.addOrRemove(message);
                    return true;
                }
            });
        }

    }

    private void handleContactImage(List<VCard> vCards, ContactMessage contactMessage, int position) {
        logger.log("vCars size = " + vCards.size());
        byte[] bitmapImage = null;
        for (VCard vCard : vCards) {
            bitmapImage = ChatContentParser.VCardParser.parseImage(vCard);
            if (bitmapImage != null) {
                break;
            }
        }
        ivContactMessageContactImage.setVisibility(View.VISIBLE);
        Glide.with(AppContext.getAccess().getContext())
                .load(bitmapImage)
                .asBitmap()
                .crossFade()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .error(R.drawable.person_icon)
                .into(ivContactMessageContactImage);

        if (bitmapImage != null) {
            contactMessage.imageBitmap = BitmapFactory.decodeByteArray(bitmapImage, 0, bitmapImage.length);
        } else {
            contactMessage.imageBitmap = BitmapFactory.decodeResource(Supplier.getResource(), R.drawable.person_icon);
        }
    }

    private void handleContactNumber(VCard vCard, ContactMessage contactMessage, int position) {
        String contactNumber = ChatContentParser.VCardParser.parseNumber(vCard);
        String contactEmail = ChatContentParser.VCardParser.parseEmail(vCard);
        if (TextUtils.isEmpty(contactNumber)) {
            if (TextUtils.isEmpty(contactEmail)) {
                tvContactNumber.setVisibility(View.GONE);
            } else {
                tvContactNumber.setVisibility(View.VISIBLE);
            }
        } else {
            tvContactNumber.setVisibility(View.VISIBLE);
            if (TextUtils.isEmpty(contactEmail)) {
                tvContactNumber.setText(contactNumber);
            } else {
                tvContactNumber.setText((contactNumber + "\n" + contactEmail));
            }
        }
        contactMessage.setNumber(tvContactNumber.getText().toString());
    }

    private void handleContactName(VCard vCard, ContactMessage contactMessage, int position) {
        String contactName = ChatContentParser.VCardParser.parseNameFromVCard(vCard);
        if (TextUtils.isEmpty(contactName)) {
            tvContactName.setVisibility(View.GONE);
        } else {
            tvContactName.setVisibility(View.VISIBLE);
            tvContactName.setText(contactName);
            contactMessage.setName(contactName);
        }
    }

    public void parse(File file) {
        try {

            List<VCard> vCards = Ezvcard.parse(file).all();
            for (VCard vcard : vCards) {
                String name = vcard.getFormattedName().getValue();
                Log.e("vcf", "Name: " + name);
                Log.e("vcf", "Telephone numbers:");
                String numbers = "";
                for (Telephone tel : vcard.getTelephoneNumbers()) {
                    Log.e("vcf", tel.getTypes() + ": " + tel.getText());
                    numbers += tel.getTypes() + ": " + tel.getText() + "\n";
                }
                if (vcard.getPhotos() != null && vcard.getPhotos().size() > 0) {
                    byte[] data = vcard.getPhotos().get(0).getData();
                    if (data != null) {
                        Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);


                        Log.e("vcf", "l4n" + data.length);
                    } else {
                        Log.e("vcf", "null");
                    }
                } else {

                    Log.e("vcf", "null");
                }

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
