package com.revesoft.itelmobiledialer.chat.chatWindow.memory;


import com.revesoft.material.R;

import java.util.LinkedHashMap;
import java.util.Set;

public class StaticStickerDataProvider {
    private static final LinkedHashMap<String, Integer> mapNameToResourceId = new LinkedHashMap<>();

    static {
        mapNameToResourceId.put("b1", R.drawable.b1);
        mapNameToResourceId.put("b2", R.drawable.b2);
        mapNameToResourceId.put("b3", R.drawable.b3);
        mapNameToResourceId.put("b4", R.drawable.b4);
        mapNameToResourceId.put("b5", R.drawable.b5);
        mapNameToResourceId.put("b6", R.drawable.b6);
//        mapNameToResourceId.put("b7.png", R.drawable.b7);
//        mapNameToResourceId.put("b8.png", R.drawable.b8);
//        mapNameToResourceId.put("b9.png", R.drawable.b9);
//        mapNameToResourceId.put("b10.png", R.drawable.b10);
//        mapNameToResourceId.put("b11.png", R.drawable.b11);
//        mapNameToResourceId.put("b12.png", R.drawable.b12);
//        mapNameToResourceId.put("b13.png", R.drawable.b13);
//        mapNameToResourceId.put("b14.png", R.drawable.b14);
//        mapNameToResourceId.put("b15.png", R.drawable.b15);
//        mapNameToResourceId.put("b16.png", R.drawable.b16);
//        mapNameToResourceId.put("b17.png", R.drawable.b17);
//        mapNameToResourceId.put("b18.png", R.drawable.b18);
//        mapNameToResourceId.put("b19.png", R.drawable.b19);
//        mapNameToResourceId.put("b20.png", R.drawable.b20);
//        mapNameToResourceId.put("b21.png", R.drawable.b21);
//        mapNameToResourceId.put("b22.png", R.drawable.b22);
//        mapNameToResourceId.put("b23.png", R.drawable.b23);
//        mapNameToResourceId.put("b24.png", R.drawable.b24);
//        mapNameToResourceId.put("b25.png", R.drawable.b25);
//        mapNameToResourceId.put("b26.png", R.drawable.b26);
//        mapNameToResourceId.put("b27.png", R.drawable.b27);
//        mapNameToResourceId.put("b28.png", R.drawable.b28);
//        mapNameToResourceId.put("b29.png", R.drawable.b29);
//        mapNameToResourceId.put("b30.png", R.drawable.b30);
//        mapNameToResourceId.put("b31.png", R.drawable.b31);
//        mapNameToResourceId.put("b32.png", R.drawable.b32);
//        mapNameToResourceId.put("b33.png", R.drawable.b33);
//        mapNameToResourceId.put("b34.png", R.drawable.b34);
//        mapNameToResourceId.put("b35.png", R.drawable.b35);
//        mapNameToResourceId.put("b36.png", R.drawable.b36);
//        mapNameToResourceId.put("b37.png", R.drawable.b37);
//        mapNameToResourceId.put("b38.png", R.drawable.b38);
//        mapNameToResourceId.put("b39.png", R.drawable.b39);
//        mapNameToResourceId.put("b40.png", R.drawable.b40);
//        mapNameToResourceId.put("b41.png", R.drawable.b41);
//        mapNameToResourceId.put("b42.png", R.drawable.b42);
//        mapNameToResourceId.put("b43.png", R.drawable.b43);
//        mapNameToResourceId.put("b44.png", R.drawable.b44);
//        mapNameToResourceId.put("b45.png", R.drawable.b45);
//        mapNameToResourceId.put("b46.png", R.drawable.b46);
//        mapNameToResourceId.put("b47.png", R.drawable.b47);
//        mapNameToResourceId.put("b48.png", R.drawable.b48);
//        mapNameToResourceId.put("b49.png", R.drawable.b49);
    }

    public static Set<String> getStickersNames() {
        return mapNameToResourceId.keySet();
    }

    public static int getResourceIdByName(String stickerName) {
        return mapNameToResourceId.containsKey(stickerName) ? mapNameToResourceId.get(stickerName) : R.drawable.b5;
    }
}
