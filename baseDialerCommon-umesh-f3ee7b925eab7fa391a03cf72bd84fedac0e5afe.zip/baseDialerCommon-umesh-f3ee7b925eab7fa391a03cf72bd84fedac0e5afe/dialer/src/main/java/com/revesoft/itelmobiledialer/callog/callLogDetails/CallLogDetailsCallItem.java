package com.revesoft.itelmobiledialer.callog.callLogDetails;

import com.revesoft.itelmobiledialer.appDatabase.entities.CallLog;
import com.revesoft.itelmobiledialer.util.TimeFormat;
import com.revesoft.material.R;

import static com.revesoft.itelmobiledialer.arch.Supplier.getString;

public class CallLogDetailsCallItem {
    private int callTypeIcon;
    private String callTime;
    private int typeIcon;
    private String callDuration;
    private int voiceIcon;
    private int playAudioLayout;
    private String recordedAudiopath;


    public static CallLogDetailsCallItem from(CallLog callLog) {
        CallLogDetailsCallItem item = new CallLogDetailsCallItem();
        if (callLog.isVideoCall) {
            item.callTypeIcon = R.drawable.ic_video_call_indicator;
        } else {
            item.callTypeIcon = R.drawable.ic_audio_call_indicator;
        }

        if(callLog.callLogType == 0) item.typeIcon = R.drawable.ic_calls_outgoing;
        else if(callLog.callLogType == 1) item.typeIcon = R.drawable.ic_calls_incoming;
        else item.typeIcon = R.drawable.ic_calls_missed;

        if(callLog.recorderFilePath != null && callLog.recorderFilePath.length() > 0)
            item.voiceIcon = R.drawable.outgoing_call_play_icon_up;
//         item.voiceIcon = 0;

        item.callDuration = TimeFormat.formatDuration(callLog.duration) +" " + getString(R.string.min);
        item.callTime = TimeFormat.getFormattedTime(callLog.date);

        item.playAudioLayout = 0;
        item.recordedAudiopath = callLog.recorderFilePath;
        return item;
    }

    public int getCallTypeIcon() {
        return callTypeIcon;
    }

    public String getCallTime() {
        return callTime;
    }

    public int getTypeIcon(){ return typeIcon;}

    public String getCallDuration(){return callDuration;}

    public int getVoiceIcon(){return voiceIcon;}

    public int getPlayAudioLayout(){return playAudioLayout;}

    public String getRecordedAudiopath(){return recordedAudiopath;}

}
