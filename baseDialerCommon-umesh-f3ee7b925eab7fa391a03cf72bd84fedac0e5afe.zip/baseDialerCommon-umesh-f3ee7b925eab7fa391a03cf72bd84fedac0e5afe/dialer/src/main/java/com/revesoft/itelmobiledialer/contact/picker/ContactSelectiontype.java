package com.revesoft.itelmobiledialer.contact.picker;

public enum ContactSelectiontype {
    SINGLE_SELECT, MULTIPLE_SELECT
}
