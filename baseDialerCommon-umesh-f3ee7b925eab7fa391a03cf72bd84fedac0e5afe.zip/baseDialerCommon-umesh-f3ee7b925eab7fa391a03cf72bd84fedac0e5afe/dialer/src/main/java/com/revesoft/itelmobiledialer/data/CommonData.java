package com.revesoft.itelmobiledialer.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Ifta
 * on 3/29/2017.
 */

public class CommonData {
    public static volatile HashMap<String,ArrayList<String>> subscriberLookUpToPhoneNumber = new HashMap<>();
    public static volatile HashMap<String,String> subscriberPhoneNumberToLookUpKey = new HashMap<>();
    public static volatile HashMap<String,String> subscriberPhoneNumberToLookUpKeyOnlyContact = new HashMap<>();
    public static volatile HashMap<String,String> contactNumberToContactName = new HashMap<>();
    public static volatile ConcurrentHashMap<String,String> groupIdToGroupName = new ConcurrentHashMap<>();
    public static volatile HashMap<String,String> contactNumberToContactLookUpKey = new HashMap<>();
    public static volatile HashMap<String,String> contactNumberToContactImageUri = new HashMap<>();
    public static volatile HashMap<String,Integer> groupIdToMemberCount = new HashMap<>();
    public static volatile HashSet<String> blockedNumber = new HashSet<>();
    public static ConcurrentHashMap<String, String> groupIdToGroupImageUrl = new ConcurrentHashMap<>();

    public static void clearAll() {
        subscriberLookUpToPhoneNumber.clear();
        subscriberPhoneNumberToLookUpKey.clear();
        subscriberPhoneNumberToLookUpKeyOnlyContact.clear();
        contactNumberToContactName.clear();
        contactNumberToContactLookUpKey.clear();
        contactNumberToContactImageUri.clear();
        blockedNumber.clear();
    }

}
