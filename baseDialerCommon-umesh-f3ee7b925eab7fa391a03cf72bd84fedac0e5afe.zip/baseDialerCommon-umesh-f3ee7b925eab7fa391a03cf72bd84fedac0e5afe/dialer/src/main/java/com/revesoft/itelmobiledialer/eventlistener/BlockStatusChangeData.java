package com.revesoft.itelmobiledialer.eventlistener;

public class BlockStatusChangeData extends EventData {
    private String keyNumber;
    private boolean blockStatus;

    public BlockStatusChangeData(String keyNumber, boolean blockStatus) {
        this.keyNumber = keyNumber;
        this.blockStatus = blockStatus;
    }

    public String getKeyNumber() {
        return keyNumber;
    }


    public boolean isBlockStatus() {
        return blockStatus;
    }

}
