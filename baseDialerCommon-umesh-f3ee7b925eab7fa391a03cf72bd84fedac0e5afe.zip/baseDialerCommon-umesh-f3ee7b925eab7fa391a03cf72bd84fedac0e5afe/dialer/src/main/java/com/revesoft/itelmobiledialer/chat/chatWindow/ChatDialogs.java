package com.revesoft.itelmobiledialer.chat.chatWindow;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.Config.Features;
import com.revesoft.itelmobiledialer.account.ChatBackgroundSelectionActivity;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.BlockRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.block.ContactBlocker;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Controllable;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.FutureMessageEditedListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.SendingConstants;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.customview.CustomTimePicker;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ContactUtil;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.Log;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.Calendar;
import java.util.Date;

import static com.revesoft.itelmobiledialer.arch.Supplier.getString;

/**
 * @author Ifta on 12/27/2017.
 */

public class ChatDialogs {
    public static void showLocationDialog(final Activity context) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_send_location_data);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialog.show();

        dialog.findViewById(R.id.content).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        final LinearLayout askForLocationData = dialog.findViewById(R.id.ask_location_data);
        askForLocationData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Sender.getAccess().sendLocationRequest();
                if (context instanceof Controllable) {
                    ((Controllable) context).onControlRequest(Controllable.RequestType.HideBottomFragments);
                }
                dialog.dismiss();
            }
        });

        LinearLayout sendLocationData = dialog.findViewById(R.id.send_location_data);
        sendLocationData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (context instanceof Controllable) {
                    ((Controllable) context).onControlRequest(Controllable.RequestType.ShowLocation);
                }
            }
        });
    }

    public static void showLocationRequestResponseDialog(Message message) {
        Log.d("tarique", "showLocationRequestResponseDialog");
        float currTime = System.currentTimeMillis() / 1000f;
        if (currTime - message.time <= 3600) {
            showReceivedLocationDialog(message.callerId, message.content);
        } else {
            String modifiedContent = message.content.replace("askLocation", "askLocationInvalid");
            Executor.ex(() -> {
                MessageRepo.get().updateMessageContent(message.callerId, modifiedContent);
            });
        }
    }

    private static void showReceivedLocationDialog(final String callerId, final String content) {
        final Dialog dialog = ChatWindowActivity.getDialog();
        dialog.setContentView(R.layout.dialog_receive_location_data);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialog.show();
        View container = dialog.findViewById(R.id.content);
        container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


        final LinearLayout sendCurrentLocation = dialog.findViewById(R.id.send_current_location);
        sendCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Util.isGPSEnabled(AppContext.getAccess().getContext())) {
                    Sender.getAccess().sendCurrentLocation();
                    String modifiedContent = content.replace("askLocation", "askLocationUsed");
                    Executor.ex(() -> {
                        MessageRepo.get().updateMessageContent(callerId, modifiedContent);
                    });
                } else {
                    ChatWindowActivity.getAlertDialogBuilder()
                            .setMessage(R.string.gps_turned_off_turn_it_on)
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    Intent intentLocationSettings = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    intentLocationSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    AppContext.getAccess().getContext().startActivity(intentLocationSettings);
                                }
                            })
                            .setNegativeButton(android.R.string.no, null).show();
                }
                dialog.dismiss();
            }
        });

        LinearLayout openLocationAccess = dialog.findViewById(R.id.open_location_access);
        openLocationAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Util.isGPSEnabled(AppContext.getAccess().getContext())) {
                    String modifiedContent = content.replace("askLocation", "askLocationAccepted");
                    Sender.getAccess().sendCurrentLocation();
                    Executor.ex(() -> {
                        MessageRepo.get().updateMessageContent(callerId, modifiedContent);
                    });
                } else {
                    ChatWindowActivity.getAlertDialogBuilder()
                            .setMessage(R.string.gps_turned_off_turn_it_on)
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    AppContext.getAccess().getContext().startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                                }
                            })
                            .setNegativeButton(android.R.string.no, null).show();
                }

                dialog.dismiss();
            }
        });

    }

    public static void showOptionsMenuDialog(final Activity activity, View anchor) {
        PopupMenu popup = new PopupMenu(activity, anchor);
        popup.getMenuInflater().inflate(R.menu.chat_window_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.addChatParty:
                    Switcher.switchToAddChatParty(activity);
                    break;
                case R.id.sendSMS:
                    if (ChatProperties.isGroupChat) {
                        I.toast("to do");
//                        Intent mIntent = new Intent(activity, AllContactActivity.class);
//                        mIntent.putExtra("send_sms", 1);
//                        activity.startActivityForResult(mIntent, ChatConstants.REQUEST_GET_SMS_NUMBER);
                    } else {
                        if (!Util.isValidEmail(Util.getProperEmail(Target.target))) {
                            Switcher.switchToChatWindow(activity,
                                    Target.target, ChatProperties.isGroupChat,
                                    false, true, false);
                        } else {
                            I.toast("You can't send sms to a person who has subscribed with e-mail");
                        }
                    }
                    break;
                case R.id.addToContacts:
                    ContactUtil.addToContact(activity, Target.target);
                    break;
                case R.id.block:
                    ContactBlocker.getInstance().toggleContactBlockStatus(activity, Target.target);
                    break;
                case R.id.unblock:
                    ContactBlocker.getInstance().toggleContactBlockStatus(activity, Target.target);
                    break;
                case R.id.openSecretChat:
                    Switcher.switchToChatWindow(activity,
                            Target.target, ChatProperties.isGroupChat,
                            false, false, true);
                    break;
                case R.id.openRegularChat:
                    Switcher.switchToChatWindow(activity,
                            Target.target, ChatProperties.isGroupChat,
                            false, false, false);
                    break;
                case R.id.changeBackground:
                    Intent i = new Intent(activity, ChatBackgroundSelectionActivity.class);
                    i.putExtra(Constants.IMS.CHAT_BACKGROUND_PICK_FOR, Target.target);
                    activity.startActivity(i);
                    break;
            }
            return true;
        });
        popup.show();

        MenuItem addToContacts = popup.getMenu().getItem(0);
        MenuItem addChatParty = popup.getMenu().getItem(1);
        MenuItem openRegularChat = popup.getMenu().getItem(2);
        MenuItem openSecretChat = popup.getMenu().getItem(3);
        MenuItem sendSMS = popup.getMenu().getItem(4);
        MenuItem block = popup.getMenu().getItem(5);
        MenuItem unblock = popup.getMenu().getItem(6);
        MenuItem changeBackground = popup.getMenu().getItem(7);
        if (ChatProperties.isGroupChat) {
            block.setVisible(false);
            unblock.setVisible(false);
        } else {
            Executor.ex(() -> {
                if (BlockRepo.get().isBlockedContact(Target.target)) {
                    Gui.get().run(() -> {
                        block.setVisible(false);
                        unblock.setVisible(true);
                    });

                } else {
                    Gui.get().run(() -> {
                        unblock.setVisible(false);
                        block.setVisible(true);
                    });

                }
            });

        }
        if (ChatProperties.isGroupChat || CommonData.contactNumberToContactImageUri.containsKey(Target.target)) {
            addToContacts.setVisible(false);
        }
        if (ChatProperties.isGroupChat) {
            if (Target.group.isCreator || Target.group.groupType == 1) {
                addChatParty.setVisible(true);
            } else {
                addChatParty.setVisible(false);
            }
        }
        //handle send sms properties
        if (Util.isValidEmail(Util.getProperEmail(Target.target))) {
            sendSMS.setVisible(false);
        }
        if (ChatProperties.isGroupChat && ChatProperties.isEncryptedChat) {
            sendSMS.setVisible(false);
        }
        if (ChatProperties.isSMSChat) {
            sendSMS.setVisible(false);
            addChatParty.setVisible(false);
        }
        if (!CommonData.subscriberPhoneNumberToLookUpKey.containsKey(Target.target)) {
            openRegularChat.setVisible(false);
            openSecretChat.setVisible(false);
        }
        if (ChatProperties.isEncryptedChat) {
            openSecretChat.setVisible(false);
            changeBackground.setVisible(false);
        } else {
            openRegularChat.setVisible(false);
            changeBackground.setVisible(true);
        }

        if (ChatProperties.isSMSChat) {
            if (CommonData.subscriberPhoneNumberToLookUpKey.containsKey(Target.target)) { //target is number
                openRegularChat.setVisible(true);
            }
        }

        if (!Features.hasE2e()) {
            openSecretChat.setVisible(false);
        }
        addChatParty.setVisible(false);
    }


    public static void showEditMessageDialog(Activity activity, final Message message) {
        final Dialog editMessageDialog = new Dialog(activity);
        editMessageDialog.setContentView(R.layout.dialog_edit_message);
        editMessageDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        final EditText editTextMessage = editMessageDialog.findViewById(R.id.message);
        editTextMessage.setText(message.content);
        //editTextMessage.setScroller(new Scroller(context));
        editTextMessage.setMaxLines(10);
        editTextMessage.setVerticalScrollBarEnabled(true);
        editTextMessage.setMovementMethod(new ScrollingMovementMethod());

        Button doneButton = editMessageDialog.findViewById(R.id.done_button);
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editTextMessage.getText().toString())) {
                    I.toast(Supplier.getString(R.string.cannotSendEmptyMessage));
                } else {
                    if (editTextMessage.getText().length() > SendingConstants.MAX_IM_LENGTH) {
                        I.toast(getString(R.string.text_length_is_too_big));
                        return;
                    }
                    editMessageDialog.dismiss();
                    Sender.getAccess().sendEditedTextMessage(editTextMessage.getText().toString(), message);
                }
            }
        });

        Button cancelButton = editMessageDialog.findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editMessageDialog.dismiss();
            }
        });
        editMessageDialog.show();
    }

    private static Dialog getThemeBasedDialog(Activity activity) {
        Dialog dialog = null;

        dialog = new Dialog(activity);
        return dialog;
    }


    public static void showEditFutureMessageDialog(final Activity activity, final Message message) {
        final short EDIT_ONLY_TIME = 0;
        final short EDIT_ONLY_MESSAGE = 1;
        final short EDIT_TIME_AND_MESSAGE = 2;
//        final Dialog dialog = new Dialog(activity, R.style.Theme_Dialog_Fullscreen);
        Dialog dialog = getThemeBasedDialog(activity);
        dialog.setContentView(R.layout.dialog_options_edit_future_message);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
        final LinearLayout editFutureMessageTimeOnly = dialog.findViewById(R.id.edit_future_message_time_only);
        editFutureMessageTimeOnly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDateTimePicker(activity, message, EDIT_ONLY_TIME, new FutureMessageEditedListener() {
                    @Override
                    public void onEdit(Date editedDate, String editedText) {
                        Sender.getAccess().sendEditedFutureTextMessage(editedText, editedDate, message);
                    }
                });
                dialog.dismiss();
            }
        });

        LinearLayout editFutureMessageOnly = dialog.findViewById(R.id.edit_future_message_only);
        editFutureMessageOnly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDateTimePicker(activity, message, EDIT_ONLY_MESSAGE, new FutureMessageEditedListener() {
                    @Override
                    public void onEdit(Date editedDate, String editedText) {
                        if (TextUtils.isEmpty(editedText)) {
                            I.toast(Supplier.getString(R.string.cannotSendEmptyMessage));
                        } else {
                            Sender.getAccess().sendEditedFutureTextMessage(editedText, editedDate, message);
                        }
                    }
                });
                dialog.dismiss();
            }
        });

        LinearLayout editFutureMessageAndTime = dialog.findViewById(R.id.edit_future_message_time_both);
        editFutureMessageAndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDateTimePicker(activity, message, EDIT_TIME_AND_MESSAGE, new FutureMessageEditedListener() {
                    @Override
                    public void onEdit(Date editedDate, String editedText) {
                        if (TextUtils.isEmpty(editedText)) {
                            I.toast(Supplier.getString(R.string.cannotSendEmptyMessage));
                        } else {
                            Sender.getAccess().sendEditedFutureTextMessage(editedText, editedDate, message);
                        }
                    }
                });
                dialog.dismiss();
            }
        });

        LinearLayout close = dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

    }

    private static void showEditDateTimePicker(Context context, Message message, short editType, final FutureMessageEditedListener futureMessageEditedListener) {
        final Dialog dateTimePickerEditorDialog = new Dialog(context);
        dateTimePickerEditorDialog.setContentView(R.layout.edit_future_message_dialog);
        dateTimePickerEditorDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        final EditText editTextFutureMessage = dateTimePickerEditorDialog.findViewById(R.id.future_message);
        editTextFutureMessage.setText(message.content);
        editTextFutureMessage.setEnabled(editType != Constants.EDIT_ONLY_TIME);

        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(message.futureTime);

        final CustomTimePicker timePicker = dateTimePickerEditorDialog.findViewById(R.id.timePicker);
        timePicker.setIs24HourView(true);
        timePicker.setEnabled(editType != Constants.EDIT_ONLY_MESSAGE);

        if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.LOLLIPOP_MR1) {
            timePicker.setMinute(c.get(Calendar.MINUTE));
            timePicker.setHour(c.get(Calendar.HOUR_OF_DAY));
        } else {
            timePicker.setCurrentMinute(c.get(Calendar.MINUTE));
            timePicker.setCurrentHour(c.get(Calendar.HOUR_OF_DAY));
        }


        final DatePicker datePicker = dateTimePickerEditorDialog.findViewById(R.id.datePicker);
        datePicker.setCalendarViewShown(false);
        datePicker.setEnabled(editType != Constants.EDIT_ONLY_MESSAGE);
        datePicker.updateDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dateTimePickerEditorDialog.show();

        final TextView dateButton = dateTimePickerEditorDialog.findViewById(R.id.date_button);
        dateButton.setBackgroundColor(Supplier.getColor(R.color.black_transparent_60));
        final TextView timeButton = dateTimePickerEditorDialog.findViewById(R.id.time_button);
        timeButton.setBackgroundColor(Color.TRANSPARENT);

        dateButton.setTextColor(Supplier.getColor(R.color.white));
        timeButton.setTextColor(Supplier.getColor(R.color.white_transparent_80));

        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker.setVisibility(View.VISIBLE);
                timePicker.setVisibility(View.GONE);

                timeButton.setBackgroundColor(Color.TRANSPARENT);
                timeButton.setTextColor(Supplier.getColor(R.color.white_transparent_80));
                dateButton.setBackgroundColor(Supplier.getColor(R.color.black_transparent_60));
                dateButton.setTextColor(Supplier.getColor(R.color.white));

            }
        });

        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timePicker.setVisibility(View.VISIBLE);
                datePicker.setVisibility(View.GONE);

                timeButton.setBackgroundColor(Supplier.getColor(R.color.black_transparent_60));
                timeButton.setTextColor(Supplier.getColor(R.color.white));
                dateButton.setBackgroundColor(Color.TRANSPARENT);
                dateButton.setTextColor(Supplier.getColor(R.color.white_transparent_80));
            }
        });

        Button doneButton = dateTimePickerEditorDialog.findViewById(R.id.done_button);
        Button cancelButton = dateTimePickerEditorDialog.findViewById(R.id.cancel_button);

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextFutureMessage.getText().length() > SendingConstants.MAX_IM_LENGTH) {
                    I.toast(getString(R.string.text_length_is_too_big));
                    return;
                }
                dateTimePickerEditorDialog.dismiss();
                futureMessageEditedListener.onEdit(ChatDateTimeFormatter.getTimeForFutureMessage(datePicker, timePicker), editTextFutureMessage.getText().toString().trim());
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dateTimePickerEditorDialog.dismiss();
            }
        });
    }


}
