package com.revesoft.itelmobiledialer.chat.chatWindow.helper;

import android.text.TextUtils;

import com.revesoft.itelmobiledialer.chat.chatWindow.group.Group;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.data.CommonData;

/**
 * @author Ifta on 1/3/2018.
 */

public class Target {
    public static String name;
    public static String target;
    public static Group group;

    public static void setUpTarget(boolean isGroup, String target) {
        destroyTarget();
        Target.target = target;
        if (isGroup) {

            group = new Group(ChatWindowActivity.getGroup());
            String groupName = group.name;
            if (TextUtils.isEmpty(groupName)) {
                Target.name = "Group Chat";
            } else {
                Target.name = groupName;
            }

        } else {
            String name = CommonData.contactNumberToContactName.get(target);
            if (TextUtils.isEmpty(name)) {
                Target.name = target;
            } else {
                Target.name = name;
            }
        }
    }

    public static void destroyTarget() {
        name = null;
        target = null;
        group = null;
    }

    public static void updateGroupState() {
        if (group != null) {
            group = new Group(ChatWindowActivity.getGroup());
            String groupName = group.name;
            if (TextUtils.isEmpty(groupName)) {
                Target.name = "Group Chat";
            } else {
                Target.name = groupName;
            }

        }
    }

    public static String dump() {
        return "Target:\nname = " + name +
                "\ntarget = " + target;
    }

    @Override
    public String toString() {
        return "Target{}";
    }
}
