package com.revesoft.itelmobiledialer.downloadhelper;

import android.app.Application;
import android.content.Context;

import com.liulishuo.okdownload.DownloadListener;
import com.liulishuo.okdownload.DownloadSerialQueue;
import com.liulishuo.okdownload.DownloadTask;
import com.liulishuo.okdownload.OkDownload;
import com.liulishuo.okdownload.OkDownloadProvider;
import com.liulishuo.okdownload.core.breakpoint.BreakpointInfo;
import com.liulishuo.okdownload.core.cause.EndCause;
import com.liulishuo.okdownload.core.cause.ResumeFailedCause;
import com.liulishuo.okdownload.core.connection.DownloadConnection;
import com.liulishuo.okdownload.core.dispatcher.DownloadDispatcher;
import com.liulishuo.okdownload.core.download.DownloadStrategy;
import com.liulishuo.okdownload.core.listener.DownloadListener1;
import com.liulishuo.okdownload.core.listener.assist.Listener1Assist;
import com.revesoft.itelmobiledialer.util.Log;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class DownloadHelper extends DownloadListener1 {
    private int requestIdentifierCount;
    private static DownloadHelper instance;
    private HashMap<Integer,DownloadClient> clientMap;
    private String TAG = "DownloadHelper";
    public static DownloadHelper getInstance()
    {
        if(instance ==null)
        {
            synchronized (DownloadHelper.class)
            {
                if(instance == null)
                {
                    instance = new DownloadHelper();
                }
            }
        }
        return instance;
    }

    private DownloadHelper()
    {
        clientMap = new HashMap<>();
        DownloadDispatcher.setMaxParallelRunningCount(1);
    }



    public synchronized ArrayList<Integer> download(UrlFileMapper... urlFileMappers)
    {
        ArrayList<Integer> requestIdentifiers = new ArrayList<>();
        for(UrlFileMapper urlFileMapper : urlFileMappers)
        {
            DownloadTask task = new DownloadTask.Builder(urlFileMapper.getUrl(), urlFileMapper.getFile())
                    .setMinIntervalMillisCallbackProcess(30)
                    .setPassIfAlreadyCompleted(false)
                    .build();

            task.setTag(requestIdentifierCount);
            task.enqueue(this);
            requestIdentifierCount++;
        }

        return requestIdentifiers;
    }


    public synchronized ArrayList<Integer> download(DownloadClient downloadClient,UrlFileMapper... urlFileMappers)
    {
        ArrayList<Integer> requestIdentifiers = new ArrayList<>();
        for(UrlFileMapper urlFileMapper : urlFileMappers)
        {
            DownloadTask task = new DownloadTask.Builder(urlFileMapper.getUrl(), urlFileMapper.getFile())
                    .setMinIntervalMillisCallbackProcess(30)
                    .setPassIfAlreadyCompleted(false)
                    .build();

            task.setTag(requestIdentifierCount);

            task.enqueue(this);
            clientMap.put(requestIdentifierCount,downloadClient);
            requestIdentifierCount++;
        }
        return requestIdentifiers;
    }








    private void notifyDownloadClientByIdentifier(DownloadTask downloadTask, String state, Exception exception, long currentOffset, long totalLength)
    {
        int requestIdentifier = (int) downloadTask.getTag();
        DownloadClient downloadClient = clientMap.get(requestIdentifier);
        if(downloadClient !=null)
        {
            switch (state)
            {
                case "completed" :
                    downloadClient.onCompleted(requestIdentifier);
                    break;

                case "error" :
                    downloadClient.onError(requestIdentifier,exception);
                    break;

                case "progress" :
                    downloadClient.onProgress(requestIdentifier,currentOffset,totalLength);
                    break;

            }

        }
    }

    @Override
    public void taskStart(@NonNull DownloadTask task, @NonNull Listener1Assist.Listener1Model model) {
        Log.i(TAG,"Task started");
    }

    @Override
    public void retry(@NonNull DownloadTask task, @NonNull ResumeFailedCause cause) {
        Log.i(TAG,"Retrying");
    }

    @Override
    public void connected(@NonNull DownloadTask task, int blockCount, long currentOffset, long totalLength) {
        Log.i(TAG,"Connected");
    }

    @Override
    public void progress(@NonNull DownloadTask task, long currentOffset, long totalLength) {
        notifyDownloadClientByIdentifier(task,"progress",null,currentOffset,totalLength);
    }

    @Override
    public void taskEnd(@NonNull DownloadTask task, @NonNull EndCause cause, @Nullable Exception realCause, @NonNull Listener1Assist.Listener1Model model) {
        if(realCause == null)
        {
            notifyDownloadClientByIdentifier(task,"completed",realCause,0,0);
        }
        else
        {
            notifyDownloadClientByIdentifier(task,"completed",realCause,0,0);
        }
    }
}
