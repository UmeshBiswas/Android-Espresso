package com.revesoft.itelmobiledialer.ims;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.signature.StringSignature;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.customview.RoundedImageView;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.theme.ThemeManager;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.io.File;
import java.util.Random;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Tanzeer on 10/16/2016.
 * edited by Ifta
 */
public class AnimationHandler {
    private Context context;
    private WindowManager windowManager;
    protected RoundedImageView ivChatHead;
    protected ImageView ivEncryted;
    protected TextView tvCounter;
    protected RelativeLayout rlBubbleHolder;
    protected WindowManager.LayoutParams params;
    private Handler handler = new Handler();
    protected String number;
    protected String groupId;
    protected String identifier;
    protected int e2e, broadcastId;
    private int INCREMENT_X_QUANTITY = 2;
    private int INCREMENT_Y_QUANTITY = 5;
    private int x_rand = 2;
    private int y_rand = 5;
    private int CHANGE_IMAGE_TIME_OUT = 25;
    private int width = 10;
    private int height = 10;
    private int messageCount = 1; //was 1 before
    protected ChatHeadService chatHeadService;
    private int MOTION_TYPE = 1;
    private int PARAMS_PARENT = 70;
    private int PARAMS_IMAGE = 68;

    public void incrementMessageCount() {
        Log.d("AnimationHandler", "incrementMessageCount: called");
        this.messageCount++;
        tvCounter.setText(("" + messageCount));
        setImageInBubble(!"".equals(groupId));
        try {
            windowManager.updateViewLayout(rlBubbleHolder, params);
        } catch (Exception e) {
            Log.d("AnimationHandler", "Draw over window not permitted");
        }
    }


    private Runnable timedTask = new Runnable() {

        @Override
        public void run() {

            if (params.y < -y_rand || params.y > height) {
                MOTION_TYPE++;
                if (MOTION_TYPE % 2 == 0)
                    params.y = 0;
                else
                    params.y = height - 100;
            }
            ballonAnimation();
            windowManager.updateViewLayout(rlBubbleHolder, params);
            handler.postDelayed(timedTask, CHANGE_IMAGE_TIME_OUT);
        }
    };

    public AnimationHandler(Context _context, String _number, String _groupId, String identifier, int _e2e, ChatHeadService chatHeadService, int broadcastId) {
        this.context = _context;
        this.chatHeadService = chatHeadService;
        this.number = _number;
        this.groupId = _groupId;
        this.identifier = identifier;
        this.e2e = _e2e;
        this.broadcastId = broadcastId;
        float DENSITY_FACTOR = (float) (context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        setWidthHeight();
        rlBubbleHolder = new RelativeLayout(context);
        rlBubbleHolder.setLayoutParams(new RelativeLayout.LayoutParams((int) (PARAMS_PARENT * DENSITY_FACTOR), (int) (PARAMS_PARENT * DENSITY_FACTOR)));
//        rlBubbleHolder.setBackgroundResource(R.drawable.bubble_round);

        View bubble = new View(context);
        bubble.setBackgroundResource(R.drawable.bubble_round);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
        layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
        bubble.setLayoutParams(layoutParams);


        ivChatHead = new RoundedImageView(context);
        RelativeLayout.LayoutParams paramsIv = new RelativeLayout.LayoutParams(
                (int) (PARAMS_IMAGE * DENSITY_FACTOR),
                (int) (PARAMS_IMAGE * DENSITY_FACTOR));
        paramsIv.addRule(RelativeLayout.CENTER_IN_PARENT);
        ivChatHead.setLayoutParams(paramsIv);
        setImageInBubble(!"".equals(groupId));


        rlBubbleHolder.addView(ivChatHead);
        rlBubbleHolder.addView(bubble);


        if (e2e == 1) {
            ivEncryted = new ImageView(context);
            RelativeLayout.LayoutParams paramsIvEncrypted = new RelativeLayout.LayoutParams(
                    (int) (PARAMS_IMAGE * DENSITY_FACTOR),
                    (int) (PARAMS_IMAGE * DENSITY_FACTOR));
            paramsIvEncrypted.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
            paramsIvEncrypted.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            paramsIvEncrypted.width = Util.convertDpToPixel(20, context);
            paramsIvEncrypted.height = Util.convertDpToPixel(20, context);
            ivEncryted.setLayoutParams(paramsIvEncrypted);
            switch (ThemeManager.getTheme()) {
                case Bounty:
                    ivEncryted.setImageResource(R.drawable.bounty_ic_sm_secret_chat);
                    break;
                case Graphite:
                    ivEncryted.setImageResource(R.drawable.graphite_ic_sm_secret_chat);
                    break;
                case Blue:
                default:
                    ivEncryted.setImageResource(R.drawable.blue_ic_sm_secret_chat);
                    break;
            }
            ivEncryted.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            rlBubbleHolder.addView(ivEncryted);
        }


        tvCounter = new TextView(context);
        RelativeLayout.LayoutParams paramsTv = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
//                (int) (22 * DENSITY_FACTOR),
//                (int) (22 * DENSITY_FACTOR)
        );
        tvCounter.setText("1");
        tvCounter.setTextSize(12);
        tvCounter.setTypeface(tvCounter.getTypeface(), Typeface.BOLD);


        switch (ThemeManager.getTheme()) {
            case Graphite:
                tvCounter.setBackgroundResource(R.drawable.ims_notification_background_graphite);
                break;
            case Bounty:
                tvCounter.setBackgroundResource(R.drawable.ims_notification_background_bounty);
                break;
            case Blue:
            default:
                tvCounter.setBackgroundResource(R.drawable.ims_notification_background_blue);
                break;
        }
        tvCounter.setTextColor(context.getResources().getColor(R.color.white));
        tvCounter.setGravity(Gravity.CENTER);
        paramsTv.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        paramsTv.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        tvCounter.setLayoutParams(paramsTv);
        rlBubbleHolder.addView(tvCounter);

        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            params = new WindowManager.LayoutParams(
                    (int) (PARAMS_PARENT * DENSITY_FACTOR),
                    (int) (PARAMS_PARENT * DENSITY_FACTOR),
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
        } else {
            params = new WindowManager.LayoutParams(
                    (int) (PARAMS_PARENT * DENSITY_FACTOR),
                    (int) (PARAMS_PARENT * DENSITY_FACTOR),
                    WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
        }

        setBallonRandIncrementIndex();
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.x = getBallonStaringX();
        params.y = height - 100;

        rlBubbleHolder.setOnClickListener(v -> {
            if (!SIPProvider.voiceRunning) {
                boolean isGroupChat = groupId != null && !groupId.equals("");
                boolean isBroadcastIM = false;
                if (broadcastId > 0) {
                    isBroadcastIM = true;
                }
                if (isGroupChat) {
                    Switcher.switchToChatWindowFromChatBubble(context, groupId, isGroupChat,
                            isBroadcastIM, false, e2e == 1);
                } else {
                    Switcher.switchToChatWindowFromChatBubble(context, number, isGroupChat,
                            isBroadcastIM, false, e2e == 1);
                }

                Log.d("tarique", "AnimationHandler rlBubbleHolder OnClick()");

                if (groupId == null || groupId.equals(""))
                    Executor.ex(() -> {
                        MessageRepo.get().
                                updateMessageNotification(number, e2e);
                    });

                else
                    Executor.ex(() -> {
                        MessageRepo.get().updateMessageNotificationAsReadByGroupID(groupId);
                    });
            }
//            sendIntentMessageofSPlash(DashboardActivity.SHOW_TAB_NOTIFICATION, "");
            AnimationHandler.this.chatHeadService.stopSelf();
        });
        try {
            windowManager.addView(rlBubbleHolder, params);
            handler.post(timedTask);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private int getBallonStaringX() {
        Random rand = new Random(System.currentTimeMillis());
        int num = rand.nextInt() % 5;
        if (num < 0)
            num *= -1;
        if (num == 0)
            return 0;
        else
            return width / num;
    }

    private void setBallonRandIncrementIndex() {
        Random rand = new Random(System.currentTimeMillis());
        int num = rand.nextInt() % 4;
        if (num < 0)
            num *= -1;
        x_rand = num + 2;
        num = rand.nextInt() % 4;
        if (num < 0)
            num *= -1;
        y_rand = num + 2;
    }

    private void sendIntentMessageofSPlash(String type, String message) {
        Intent intent = new Intent(Constants.SPLASH_INTENT);
        intent.putExtra(type, message);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    private void setWidthHeight() {
        width = context.getResources().getDisplayMetrics().widthPixels;
        height = context.getResources().getDisplayMetrics().heightPixels;
    }

    void setImageInBubble(boolean isGroup) {
        if (isGroup) {
//            String profilePicPath = DatabaseConstants.getInstance(context).getGroupProfilePicPath(groupId);
//            File file = new File(profilePicPath);
//            Log.i("AnimationHandler", "GroupImagePath: " + profilePicPath + " file.lastModified: " + file.lastModified());
//            ImageUtil.setImageButDefaultOnException(context, profilePicPath, ivChatHead, R.drawable.ic_default_group_image);
////            Glide.with(context)
////                    .load(profilePicPath)
////                    .crossFade()
////                    .thumbnail((float) 0.25)
////                    .diskCacheStrategy(DiskCacheStrategy.NONE)
////                    .signature(new StringSignature(String.valueOf(file.lastModified())))
////                    .error(R.drawable.ic_default_group_image)
////                    .into(ivChatHead);
        } else {
            String profileImageLoadingPath;
            if (ProfilePicUploadDownloadHelper.checkIfProfilePictureIsAvailable(context, number)) {
                File ProfileFile = ProfilePicUploadDownloadHelper.getProfilePictureFile(context, number);
                profileImageLoadingPath = ProfileFile.getAbsolutePath();
                Glide.with(context)
                        .load(profileImageLoadingPath)
                        .crossFade()
                        .thumbnail((float) 0.25)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .signature(new StringSignature(String.valueOf(ProfileFile.lastModified())))
                        .into(ivChatHead);
            } else {
                Uri photoURI = ContactEngine.getPhotoUri(context, number);
                if (photoURI != null) {
                    String uriPath = photoURI.toString();
                    if (uriPath != null && uriPath.length() > 0) {
                        profileImageLoadingPath = uriPath;
                        Glide.with(context)
                                .load(profileImageLoadingPath)
                                .crossFade()
                                .thumbnail((float) 0.10)
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .into(ivChatHead);
                    } else {
                        ivChatHead
                                .setImageResource(R.drawable.pic_phonebook_no_image);
                    }
                } else {
                    ivChatHead
                            .setImageResource(R.drawable.pic_phonebook_no_image);
                }

            }
        }


    }

    private void ballonAnimation() {

        params.x += INCREMENT_X_QUANTITY;
        params.y += INCREMENT_Y_QUANTITY;
        changeMovement();
    }

    private void changeMovement() {
        //  Log.e(" type","  "+MOTION_TYPE +"  "+params.y);
        if (MOTION_TYPE % 2 == 1) {
            if (params.y > (height / 2))
                INCREMENT_Y_QUANTITY = -1 * y_rand;
        } else {
            if (params.y < (height / 2)) {
                INCREMENT_Y_QUANTITY = y_rand;
            } else if (params.y > (height / 3)) {
                INCREMENT_Y_QUANTITY = y_rand;
            }
        }
        if (params.x < 50)
            INCREMENT_X_QUANTITY = x_rand;
        else if (params.x > width - 50)
            INCREMENT_X_QUANTITY = -1 * x_rand;

    }

    public void closeAnimation(boolean shouldDelete) {
        if (shouldDelete) {
            chatHeadService.deleteEntry(identifier);
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                if (ivChatHead != null && rlBubbleHolder.isAttachedToWindow()) {
                    windowManager.removeView(rlBubbleHolder);
                }
            } else {
                if (ivChatHead != null && rlBubbleHolder.getWindowToken() != null) {
                    windowManager.removeView(rlBubbleHolder);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        if (handler != null)
            handler.removeCallbacks(timedTask);
    }

    void updateProfilePicture() {
        setImageInBubble(true);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                windowManager.updateViewLayout(rlBubbleHolder, params);
            }
        }, 500);

    }
}
