package com.revesoft.itelmobiledialer.contact.list;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.data.SubscriberStatusProvider;
import com.revesoft.itelmobiledialer.eventlistener.DialerEvent;
import com.revesoft.itelmobiledialer.eventlistener.DialerEventHock;
import com.revesoft.itelmobiledialer.eventlistener.DialerListener;
import com.revesoft.itelmobiledialer.eventlistener.EventData;
import com.revesoft.itelmobiledialer.block.BlockedContactActivity;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ContactListSingleItemBinding;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

class ContactListAdapter extends PagedListAdapter<ContactListItem, ContactListAdapter.ViewHolder> implements DialerListener {
    private Activity activity;
    private ContactType contactType;

    ContactListAdapter(Activity activity, ContactType contactType) {
        super(DIFF_CALLBACK);
        this.activity = activity;
        register();
        this.contactType = contactType;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int contactType) {
        ContactListSingleItemBinding binding =
                DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                        R.layout.contact_list_single_item,
                        parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ContactListItem item = getItem(position);
        if (item != null) {
            holder.binding.setItem(item);
            holder.binding.content.setOnClickListener(v -> ContactDetailsActivity.start(activity, item.getContactId(), item.getProcessedNumber()));
            if (contactType == ContactType.BLOCKED) {
                holder.binding.unblock.setVisibility(View.VISIBLE);
                holder.binding.unblock.setOnClickListener(v -> {
                    if (activity instanceof BlockedContactActivity) {
                        BlockedContactActivity blockedContactActivity = (BlockedContactActivity) activity;
                        blockedContactActivity.unblockContact(item.getProcessedNumber());
                    }
                });
            } else {
                holder.binding.unblock.setVisibility(View.GONE);
            }

            ImageUtil.setImageButTextImageOnException(item.getImagePath(), holder.binding.ivProfileImage, item.getName());
            if (SubscriberStatusProvider.isSubscriber(item.getProcessedNumber())) {
                holder.binding.subscriberIcon.setVisibility(View.VISIBLE);
            } else holder.binding.subscriberIcon.setVisibility(View.GONE);
        }
        else {

            holder.binding.invalidateAll();
        }
    }

    @Override
    public void register() {
        DialerEventHock.getInstance().addListener(this);
    }

    @Override
    public void performOnEvent(DialerEvent event, EventData eventData) {
        if (event == DialerEvent.SubscriberTableLoaded) {
            Gui.get().run(() -> {
                notifyDataSetChanged();
                for (int i = 0; i < getItemCount(); i++) {
                    if (getItem(i) != null) notifyItemChanged(i);
                }
            });
        }
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        private ContactListSingleItemBinding binding;

        private ViewHolder(ContactListSingleItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

    }


    private static DiffUtil.ItemCallback<ContactListItem> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<ContactListItem>() {
                @Override
                public boolean areItemsTheSame(ContactListItem oldItem, ContactListItem newItem) {
                    return oldItem.getContactId().equals(newItem.getContactId());
                }

                @Override
                public boolean areContentsTheSame(@NonNull ContactListItem oldItem, @NonNull ContactListItem newItem) {
                    return areItemsTheSame(oldItem, newItem);
                }
            };
}
