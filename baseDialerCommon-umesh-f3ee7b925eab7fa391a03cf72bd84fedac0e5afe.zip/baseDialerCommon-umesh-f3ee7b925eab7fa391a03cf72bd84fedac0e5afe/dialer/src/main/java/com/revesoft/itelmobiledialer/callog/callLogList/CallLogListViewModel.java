package com.revesoft.itelmobiledialer.callog.callLogList;

import com.revesoft.itelmobiledialer.appDatabase.repo.CallLogRepo;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModel;
import com.revesoft.itelmobiledialer.util.TimeFormat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;
import androidx.paging.LivePagedListBuilder;
import androidx.paging.PagedList;


public class CallLogListViewModel extends FilterableViewModel<CallLogItem> {


    @Override
    protected LiveData<PagedList<CallLogItem>> prepareFilteredData() {

        DataSource.Factory<Integer, QueryItemCallLogList> dataSourceFactoryCallLog = CallLogRepo.get().getAllLivePagedFiltered(searchFilter);
        DataSource.Factory<Integer, CallLogItem> dataSourceFactoryCallLogItem = dataSourceFactoryCallLog.mapByPage(input -> {
            Set<String> alreadyFoundHeaders = new HashSet<>();
            List<CallLogItem> list = new ArrayList<>();
            for (int i = 0; i < input.size(); i++) {
                QueryItemCallLogList callLog = input.get(i);
                boolean isHeader = alreadyFoundHeaders.add(TimeFormat.getDateHeader(callLog.date));
                list.add(CallLogItem.Companion.from(callLog, isHeader));
            }
            return list;
        });
        return new LivePagedListBuilder<>(dataSourceFactoryCallLogItem, 10).build();
    }
}
