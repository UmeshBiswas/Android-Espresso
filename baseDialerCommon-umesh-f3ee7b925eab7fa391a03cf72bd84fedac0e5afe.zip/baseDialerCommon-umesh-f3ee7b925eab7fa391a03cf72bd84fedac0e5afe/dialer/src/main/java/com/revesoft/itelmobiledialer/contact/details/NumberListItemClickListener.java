package com.revesoft.itelmobiledialer.contact.details;

@SuppressWarnings("all")
public interface NumberListItemClickListener {
    public void makeAudioCall(String number);

    public void makeVideoCall(String number);

    public void makePaidCall(String number);

    public void sendIM(String number);

    public void sendEmail(String number);

}
