package com.revesoft.itelmobiledialer.chat.chatWindow.messageSender;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.text.TextUtils;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.revesoft.itelmobiledialer.chat.chatWindow.futureMessage.FutureMessageTimeDialogs;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.parameter.ImageType;
import ezvcard.property.Photo;

public class ContactSender {
    private static ContactSender contactSender = null;
    private Context context;

    public ContactSender(Context context) {
        this.context = context;
    }


    public static ContactSender getInstance(Context context) {
        if (contactSender == null) {
            contactSender = new ContactSender(context);
        }
        return contactSender;
    }

    public void sendContacts(List<ContactListItem> contactListItems) {
        for (ContactListItem contact : contactListItems) {
            sendSingleContact(contact);
        }
    }

    private void sendSingleContact(ContactListItem contact) {
        final VCard vCard = new VCard();
        vCard.setFormattedName(contact.getName());
        if (Util.isValidEmail(Util.getProperEmail(contact.getProcessedNumber()))) {
            vCard.addEmail(Util.getProperEmail(contact.getProcessedNumber()));
        } else {
            vCard.addTelephoneNumber(Util.getProperEmail(contact.getProcessedNumber()));
        }
        if (!TextUtils.isEmpty(contact.getImagePath())) {
            Glide.with(context)
                    .load(contact.getImagePath())
                    .asBitmap()
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(true)
                    .dontAnimate()
                    .into(new SimpleTarget<Bitmap>() {
                        @Override
                        public void onLoadFailed(Exception e, Drawable errorDrawable) {
                            sendContact(false, vCard, contact);
                        }

                        @Override
                        public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                            if (resource != null) {
                                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                                resource.compress(Bitmap.CompressFormat.PNG, 100, stream);
                                byte[] byteArray = stream.toByteArray();
                                vCard.addPhoto(new Photo(byteArray, ImageType.JPEG));
                                sendContact(false, vCard, contact);
                            }
                        }
                    });
        } else {
            sendContact(false, vCard, contact);
        }
    }

    private static final String CONTACT_DIRECTORY = "/" + Supplier.getString(R.string.appName) + " media";

    private void sendContact(boolean shouldSendAsFutureMessage, VCard vCard, ContactListItem contact) {
        File parent = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + CONTACT_DIRECTORY);
        if (!parent.exists()) {
            parent.mkdir();
        }
        try {
            final File contactFile = new File(parent, contact.getProcessedNumber() + ".vcf");
            Ezvcard.write(vCard).go(contactFile);
            if (shouldSendAsFutureMessage) {
                FutureMessageTimeDialogs.showDateTimePicker((formattedDateTime, sendCurrentTimeStamp) -> Sender.getAccess().sendFutureFile(contactFile.getAbsolutePath(), formattedDateTime.getTime(), sendCurrentTimeStamp));
            } else {
                Sender.getAccess().sendFile(contactFile.getAbsolutePath());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
