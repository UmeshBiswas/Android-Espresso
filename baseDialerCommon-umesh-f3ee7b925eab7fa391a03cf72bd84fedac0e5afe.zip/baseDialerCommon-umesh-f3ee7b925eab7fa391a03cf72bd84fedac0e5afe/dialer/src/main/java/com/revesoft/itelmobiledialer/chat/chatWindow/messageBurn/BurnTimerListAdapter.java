package com.revesoft.itelmobiledialer.chat.chatWindow.messageBurn;

import android.app.Activity;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Nazmul  on 10/19/2017.
 * moved to different package by Ifta
 */

class BurnTimerListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private String[] displayData;
    private LayoutInflater layoutInflater;


    BurnTimerListAdapter(Context context) {
        this.displayData = Supplier.getStringArray(R.array.burn_time_display_data);
        this.layoutInflater = ((Activity) context).getLayoutInflater();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvTimer;

        public ViewHolder(View itemView) {
            super(itemView);
            tvTimer = (TextView) itemView;
        }

        public void bindView(int position) {
            int pos = position % displayData.length;
            tvTimer.setText(displayData[pos]);
            tvTimer.setTag(position);

        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = layoutInflater.inflate(R.layout.burn_timer_data_row, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {
            ViewHolder vh = (ViewHolder) holder;
            vh.bindView(position);
        }
    }

    @Override
    public int getItemCount() {
        return Integer.MAX_VALUE;
    }
}

