package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.HiddenMessage;

import java.util.List;

public class HiddenMessageRepo {
    private static final HiddenMessageRepo ourInstance = new HiddenMessageRepo();

    private HiddenMessageRepo() {
    }

    public static HiddenMessageRepo get() {
        return ourInstance;
    }


    public List<HiddenMessage> getAll() {
        return AppDatabase.get().hiddenMessageDao().getAll();
    }

    public void insertAll(List<HiddenMessage> hiddenMessageList) {
        AppDatabase.get().hiddenMessageDao().insertAll(hiddenMessageList);
    }

    public int checkIfHiddenChat(String number) {
        return AppDatabase.get().hiddenMessageDao().checkIfHiddenChatByNumber(number);
    }


    public boolean checkIfHiddenChat(String number, int isEncrypted, String groupid, boolean isGroupChat) {
        if (isGroupChat) {
            return AppDatabase.get().hiddenMessageDao().checkIfHiddenChatByGroupId(groupid);
        } else {
            return AppDatabase.get().hiddenMessageDao().checkIfHiddenChatByNumberAndEncryption(number, isEncrypted);
        }
    }
}
