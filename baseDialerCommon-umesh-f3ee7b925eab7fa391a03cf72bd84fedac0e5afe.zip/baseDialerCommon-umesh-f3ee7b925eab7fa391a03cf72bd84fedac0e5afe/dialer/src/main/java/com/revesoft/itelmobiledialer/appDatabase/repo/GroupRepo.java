package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.text.TextUtils;
import android.util.Log;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Group;
import com.revesoft.itelmobiledialer.appDatabase.entities.Subscriber;
import com.revesoft.itelmobiledialer.e2eencryption.E2EPublicKeySeedAndPrivateKeyHolder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GroupRepo {
    private static final GroupRepo ourInstance = new GroupRepo();

    public static GroupRepo get() {
        return ourInstance;
    }

    private GroupRepo() {
    }


    public List<Group> getAll() {
        return AppDatabase.get().groupDao().getAll();
    }

    public void insertAll(List<Group> groupList) {
        AppDatabase.get().groupDao().insertAll(groupList);
    }

    public int getGroupE2EValue(String groupId) {
        return AppDatabase.get().groupDao().getGroupE2EValue(groupId);
    }


    public boolean checkForGroup(String groupId) {
        return getGroupById(groupId) != null;
    }


    public Group getGroupById(String groupId) {
        return AppDatabase.get().groupDao().getGroupById(groupId);
    }


    public Cursor getGroupCursorById(String groupId) {
        return AppDatabase.get().groupDao().getGroupCursorById(groupId);
    }


    public List<String> allUniqueGroupIds() {
        return AppDatabase.get().groupDao().allUniqueGroupIds();
    }


    public void createGroup(String callId, String groupId, String groupName, String numbers,
                            String creator, int isCreator, String groupType, int e2e) {


        Log.v("messageDao", "createGroup");

        if (groupName.length() == 0) {
            groupName = "Group Chat";
        }
        try {
            Group group = Group.newBuilder()
                    .number(numbers)
                    .groupId(groupId)
                    .groupName(groupName)
                    .isCreator(isCreator == 1)
                    .isMember(true)
                    .creatorNumber(TextUtils.isEmpty(creator) ? "" : creator)
                    .groupType(groupType != null && groupType.length() > 0 ? Integer.parseInt(groupType) : 0)
                    .isEncryptedGroup(e2e == 1)
                    .build();
            AppDatabase.get().groupDao().insert(group);
            Log.i("messageDao", "group added " + groupName);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void createSMSGroup(String name, String number, ArrayList<String> contacts, String groupId) {
        Group group = Group.newBuilder()
                .number(number)
                .groupId(groupId)
                .groupName(name)
                .isMember(true)
                .build();
        AppDatabase.get().groupDao().insert(group);
    }


    public void updateE2EPublicKeySeedAndPrivateKeyForGroup(String groupId, String publicKey,
                                                            String seed, String groupPrivateKey) {
        AppDatabase.get().groupDao().updateE2EPublicKeySeedAndPrivateKeyForGroup(groupId, publicKey, seed, groupPrivateKey);
    }


    public boolean isE2EPublicKeySeedAndPrivateKeyAvailableForGroup(String groupId) {
        Group group = getGroupById(groupId);
        boolean result = group != null;
        result = result && (!group.buddyPublicKey.equals("") && !group.buddySeed.equals("")
                && !group.groupPrivateKey.equals(""));

        return result;
    }


    public E2EPublicKeySeedAndPrivateKeyHolder getE2EPublicKeySeedAndPrivateKeyHolderForGroup(String groupId) {
        E2EPublicKeySeedAndPrivateKeyHolder e2EPublicKeySeedAndPrivateKeyHolder = new E2EPublicKeySeedAndPrivateKeyHolder();

        Group group = getGroupById(groupId);
        if (group != null) {
            e2EPublicKeySeedAndPrivateKeyHolder.publicKey = group.buddyPublicKey.equals("") ? null : group.buddyPublicKey;
            e2EPublicKeySeedAndPrivateKeyHolder.privateKey = group.groupPrivateKey.equals("") ? null : group.groupPrivateKey;
            e2EPublicKeySeedAndPrivateKeyHolder.seed = group.buddySeed.equals("") ? null : group.buddySeed;
        }
        return e2EPublicKeySeedAndPrivateKeyHolder;
    }


    public void updateGroup(String groupId, String groupName,
                            String numbers, int isCreator, int isMember, int e2e) {
        AppDatabase.get().groupDao().updateGroup(groupId, groupName, numbers, isCreator, isMember, e2e);
    }


    public void updateGroup(String groupId, String groupName, String numbers, String creator,
                            int isCreator, int isMember, String groupType, int e2e) {

        updateGroup(groupId, groupName, numbers, isCreator, isMember, e2e);
        if (!TextUtils.isEmpty(creator))
            AppDatabase.get().groupDao().updateGroupCreator(groupId, creator);
        if (groupType != null && groupType.length() > 0)
            AppDatabase.get().groupDao().updateGroupType(groupId, groupType);

    }


    public int checkIfMember(String groupId) {
        return AppDatabase.get().groupDao().checkIfMember(groupId);
    }


    public int checkIfCreator(String groupId) {
        return AppDatabase.get().groupDao().checkIfCreator(groupId);
    }


    public boolean hasLeftGroup(String groupId) {
        return checkIfMember(groupId) != 1;
    }


    public void changeGroupMemberShipStatus(String groupId, int isMember) {
        AppDatabase.get().groupDao().changeGroupMemberShipStatus(groupId, isMember);
    }


    public void updateGroupMembers(String groupId, String groupMembers) {
        AppDatabase.get().groupDao().updateGroupMembers(groupId, groupMembers);
    }


    public String getGroupName(String groupId) {
        return AppDatabase.get().groupDao().getGroupName(groupId);
    }


    public void updateGroupName(String groupId, String groupName) {
        AppDatabase.get().groupDao().updateGroupName(groupId, groupName);
    }


    public String[] getGroupNumbers(String groupId) {
        String numbers = AppDatabase.get().groupDao().getGroupNumbers(groupId);
        if (numbers != null) {
            return numbers.split(",");
        }
        return null;
    }


    public Cursor getGroupMembers(String[] groupMemberNumbers) {
        List<String> notSubscriberList = Arrays.asList(groupMemberNumbers);
        List<Subscriber> subscriberList = SubscriberRepo.get().getSubscribersHavingSpecifiedNumbers(groupMemberNumbers);
        MergeCursor mergeCursor;
        MatrixCursor matrixCursor;

        matrixCursor = new MatrixCursor(new String[]{"s_id", "_id",
                "number", "name", "lookup_key", "presencestate",
                "presencenote"});
        for (Subscriber subscriber : subscriberList) {
            notSubscriberList.remove(subscriber.number);
        }
        for (String memberNumber : notSubscriberList) {

            matrixCursor.addRow(new Object[]{1001, 1001,
                    memberNumber, "", memberNumber, 4, ""});
        }
        mergeCursor = new MergeCursor(new Cursor[]{matrixCursor});

        return mergeCursor;

    }


    public void deleteAllGroups() {
        AppDatabase.get().groupDao().deleteAllGroups();
    }


    public Cursor getAllGroupCursor() {
        return AppDatabase.get().groupDao().getAllGroupCursor();
    }
}
