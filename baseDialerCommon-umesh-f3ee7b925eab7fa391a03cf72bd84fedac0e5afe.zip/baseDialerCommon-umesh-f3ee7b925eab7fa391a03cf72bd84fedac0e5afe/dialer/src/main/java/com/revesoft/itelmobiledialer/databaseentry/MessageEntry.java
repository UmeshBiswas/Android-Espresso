package com.revesoft.itelmobiledialer.databaseentry;


public class MessageEntry {
	public int messageId, editCount;
	public String groupId;
	public String number, content;
	public short type = MessageType.SEND;
	public short status = MessageStatus.UNREAD;
	public short delivery_status = DeliveryStatus.PENDING;
	public long id, time, futureSendTime;
	public String callerId;
	public String filePath;
	public String mimeType;
    public String serverFilePath="";
    public int burnTimeInsec;
    public boolean isConfide;
	public short sendOriginalTimestampFlag;
	public String broadcastID="";
	public String query_id="";
	public String confideFileName="";
	private long timeStamp;
	private boolean pendingFlag;
	public boolean isGroup;
	public int isEncrypted = 0;
	public int isDecrypted = 1;

	public String ocid;
	public String qcid;
	public String quoteData;
	public String quoteFromUser;
	public String quoteMessageFilePath;
	public  long burnTimerMillis = -1;
	public interface MessageType {
		short SEND = 0, RECEIVED = 1, SYSTEM = 2, SMS = 3, RECEIVED_SMS = 4,SENT_SMS = 5;
	}

	public interface MessageStatus {
		short UNREAD = 1, READ = 0;
	}

	public interface DeliveryStatus {
		short SUCCESSFUL = 200, FAILED = 404, PENDING = 100,  RECEIVING = 2, NO_REPLY = -1, SEEN = 3210, READY_TO_DOWNLOAD = 7347;
	}

	public boolean isPending() {
		return pendingFlag;
	}

	public void setPending() {
		pendingFlag = true;
	}

	public boolean isExpired() {
		return (System.currentTimeMillis() - timeStamp) > 2000;
	}
	public String getLongMessage() {
		return longMessage;
	}

	public void setLongMessage(String longMessage) {
		this.longMessage = longMessage;
	}

	public String longMessage;

	public int getIsReadyForView() {
		return isReadyForView;
	}

	public void setIsReadyForView(int isReadyForView) {
		this.isReadyForView = isReadyForView;
	}


	private int isReadyForView = 1;




}
