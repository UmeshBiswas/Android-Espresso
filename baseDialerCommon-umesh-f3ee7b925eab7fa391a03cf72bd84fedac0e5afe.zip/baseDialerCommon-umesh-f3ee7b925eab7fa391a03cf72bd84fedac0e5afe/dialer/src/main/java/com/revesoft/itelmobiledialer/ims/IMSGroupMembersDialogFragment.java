package com.revesoft.itelmobiledialer.ims;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.provider.Contacts;
import android.provider.Contacts.People;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.databaseentry.SubscriberEntry;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import androidx.loader.app.LoaderManager.LoaderCallbacks;
import androidx.loader.content.Loader;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class IMSGroupMembersDialogFragment extends DialogFragment implements
        LoaderCallbacks<Cursor> {

    private ArrayList<String> mContactNumbers;
    private String mGroupName;
    private static final String CONTACT_NUMBERS_ARRAY_KEY = "numbersArray";
    private static final String GROUP_NAME_KEY = "groupname";
    private static final String GROUP_ID_KEY = "groupid";
    //	private DatabaseConstants mDbhelper;
    private ImsGroupAdapter mAdapter;
    private Bitmap mPlaceHolder;
    private String groupId;
    private boolean showRemoveOption;
    private static HashSet<String> sImageReloadSet = new HashSet<String>();

    public static IMSGroupMembersDialogFragment newInstance(
            String[] contactNumbers, String groupName, String groupId) {
        IMSGroupMembersDialogFragment frag = new IMSGroupMembersDialogFragment();

        // this is useless now but can later be used to pass arguments
        Bundle bundle = new Bundle();
        bundle.putStringArray(CONTACT_NUMBERS_ARRAY_KEY, contactNumbers);
        bundle.putString(GROUP_NAME_KEY, groupName);
        bundle.putString(GROUP_ID_KEY, groupId);
        frag.setArguments(bundle);
        return frag;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NO_TITLE, R.style.Dialog_No_Border);
        setCancelable(true);
//		mDbhelper = DatabaseConstants.getInstance(getActivity());
        mContactNumbers = new ArrayList<String>(Arrays.asList(getArguments()
                .getStringArray(CONTACT_NUMBERS_ARRAY_KEY)));
        mGroupName = getArguments().getString(GROUP_NAME_KEY);
        groupId = getArguments().getString(GROUP_ID_KEY);
        Executor.ex(() -> {
            showRemoveOption = GroupRepo.get().checkIfCreator(groupId) == 1
                    && GroupRepo.get().checkIfMember(groupId) == 1;
        });

        mPlaceHolder = BitmapFactory.decodeResource(getResources(),
                R.drawable.pic_phonebook_no_image);

        getLoaderManager().initLoader(0, null, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        View layout = inflater.inflate(
                R.layout.ims_group_members_dialog_fragment, container, false);
        TextView groupName = layout
                .findViewById(R.id.textViewGroupname);
        groupName.setText(mGroupName);
        if (mContactNumbers.size() == 1) {
            groupName.setVisibility(View.GONE);
        }

        ListView listView = layout
                .findViewById(R.id.listViewContacts);
        mAdapter = new ImsGroupAdapter(null);
        listView.setAdapter(mAdapter);

        listView.setOnScrollListener(new OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                // TODO Auto-generated method stub
                // Pause fetcher to ensure smoother scrolling when flinging
//				if (scrollState == OnScrollListener.SCROLL_STATE_FLING) {
//
//					mImageFetcher.setPauseWork(true);
//				} else if (scrollState == OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
//					mImageFetcher.setPauseWork(true);
//				} else {
//
//					mImageFetcher.setPauseWork(false);
//				}

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
                // TODO Auto-generated method stub

            }
        });
//		ImageCacheParams cacheParams = new ImageCacheParams(getActivity(),
//				ProfileImageFetcher.PRO_PIC_IMAGE_CACHE_DIR);
//
//		// The ImageFetcher takes care of loading images into our ImageView
//		// children asynchronously
//		mImageFetcher = new ProfileImageFetcher(getActivity(), 96);
//		mImageFetcher.setLoadingImage(mPlaceHolder);
//		mImageFetcher.addImageCache(getFragmentManager(), cacheParams);
//		mImageFetcher.setImageFadeIn(true);
        // sImageReloadSet = new HashSet<String>();
        // change end

        return layout;
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        mAdapter.notifyDataSetChanged();
//		mImageFetcher.setExitTasksEarly(false);
    }

    @Override
    public void onPause() {
        // TODO Auto-generated method stub
        super.onPause();

//		mImageFetcher.setPauseWork(false);
//		mImageFetcher.setExitTasksEarly(true);
//		mImageFetcher.flushCache();
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
//		mImageFetcher.closeCache();
    }

    @Override
    public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
        // TODO Auto-generated method stub
        return new SQLiteCursorLoader(getActivity()) {
            @Override
            public Cursor loadInBackground() {
                // TODO Auto-generated method stub dbhelper.getSubsciber()
                Cursor cursor = null;
                try {
                    // cursor = mDbhelper.getSubsciber();
                    cursor = GroupRepo.get().getGroupMembers(mContactNumbers
                            .toArray(new String[mContactNumbers.size()]));
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    cursor.getCount();
                    this.registerContentObserver(cursor,
                            DatabaseConstants.SUBSCRIBER_URI);
                }

                return cursor;
            }
        };
    }

    private static class ViewHolder {
        ImageView contactImage;
        ImageView contactState;
        TextView contactName;
        TextView contactStatus;

        ImageButton callContact;
        ImageButton addContact;
        ImageButton removeFromGroup;

    }

    private class ImsGroupAdapter extends CursorAdapter {

        public ImsGroupAdapter(Cursor c) {
            super(getActivity(), c, false);

        }

        @Override
        public void bindView(View convertView, Context context, Cursor cursor) {
            // TODO Auto-generated method stub
            ViewHolder holder = (ViewHolder) convertView.getTag();

            final String number = cursor.getString(cursor
                    .getColumnIndex(DatabaseConstants.KEY_NUMBER));
            final String name = cursor.getString(cursor
                    .getColumnIndex(DatabaseConstants.KEY_NAME));

            final int state = cursor.getInt(cursor
                    .getColumnIndex(DatabaseConstants.KEY_PRESENCE_STATE));
            final String status = cursor.getString(cursor
                    .getColumnIndex(DatabaseConstants.KEY_PRESENCE_NOTE));

            if (name == null || name.equals("") || name.equals(number)) {
                holder.contactName.setText(number);
                holder.addContact.setVisibility(View.VISIBLE);
            } else {
                holder.contactName.setText(name);
                holder.addContact.setVisibility(View.GONE);
            }

            holder.contactStatus.setText(status);

            // if (mScrollManager.getScrollState() !=
            // AbsListView.OnScrollListener.SCROLL_STATE_FLING) {
            if (state == SubscriberEntry.PresenceState.AVAILABLE) {
                holder.contactState
                        .setImageResource(android.R.drawable.presence_online);
            } else if (state == SubscriberEntry.PresenceState.AWAY) {
                holder.contactState
                        .setImageResource(android.R.drawable.presence_away);
            } else if (state == SubscriberEntry.PresenceState.BUSY) {
                holder.contactState
                        .setImageResource(android.R.drawable.presence_busy);
            } else {
                holder.contactState
                        .setImageResource(android.R.drawable.presence_offline);
            }

            // change related to image chaching
            // the image loading is done is the processBitmap function of the
            // ProfileImageFetcher
            // class.
//			if (sImageReloadSet.contains(number)) {
//				mImageFetcher.loadImage(number, holder.contactImage, true);
//				sImageReloadSet.remove(number);
//			} else {
//				mImageFetcher.loadImage(number, holder.contactImage, false);
//			}

            Bitmap image = ProfilePicUploadDownloadHelper.getContactThumbnailImage(getActivity(), number, 96, 96);
            if (image != null) {
                Glide.with(getActivity())
                        .load(image)
                        .crossFade()
                        .error(R.drawable.person)
                        .into(holder.contactImage);
            } else {
                Glide.with(getActivity())
                        .load(R.drawable.person)
                        .crossFade()
                        .error(R.drawable.person)
                        .into(holder.contactImage);
            }

            //

            if (cursor.getCount() == 1) {
                // not a group
                holder.removeFromGroup.setVisibility(View.GONE);
            } else {
                holder.removeFromGroup.setVisibility(View.VISIBLE);
            }

            holder.callContact.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub

                    sendIntentMessageToDialer("startcall", number);
                    dismiss();
                    // Toast.makeText(getActivity(), "Call " + contactNumber,
                    // Toast.LENGTH_SHORT).show();
                }
            });

            holder.addContact.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    addContact(number);
                    dismiss();
                }
            });
            if (!showRemoveOption)
                holder.removeFromGroup.setVisibility(View.GONE);

            holder.removeFromGroup.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    sendIntentMessageToDialer("removegroupmember", groupId, number, Util.e2e());
                    dismiss();
                    // Toast.makeText(getActivity(), "Remove " + contactNumber,
                    // Toast.LENGTH_SHORT).show();
                }
            });

        }

        @Override
        public View newView(Context arg0, Cursor arg1, ViewGroup arg2) {
            View convertView = LayoutInflater.from(getActivity()).inflate(
                    R.layout.ims_group_members_options_row, arg2, false);
            ViewHolder holder = new ViewHolder();
            holder.contactName = convertView
                    .findViewById(R.id.textViewContactName);
            holder.contactState = convertView
                    .findViewById(R.id.state);
            holder.contactStatus = convertView
                    .findViewById(R.id.textViewContactStatus);

            holder.contactImage = convertView
                    .findViewById(R.id.imageViewContactImage);
            holder.callContact = convertView
                    .findViewById(R.id.imageButtonCall);
            holder.addContact = convertView
                    .findViewById(R.id.imageButtonAddToContact);
            holder.removeFromGroup = convertView
                    .findViewById(R.id.imageButtonRemove);
            convertView.setTag(holder);
            return convertView;
        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> arg0, Cursor cursor) {
        mAdapter.swapCursor(cursor);

    }

    @Override
    public void onLoaderReset(Loader<Cursor> arg0) {
        mAdapter.swapCursor(null);

    }

    private void sendIntentMessageToDialer(String type, String number) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, number);
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    private void sendIntentMessageToDialer(String type, String number,
                                           String groupId, int e2e) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, new String[]{number, groupId, e2e + ""});
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    private void addContact(String number) {
        if (Build.VERSION.SDK_INT > 7) {
            // Creates a new Intent to insert or edit a contact
            Intent intentInsertEdit = new Intent(Intent.ACTION_INSERT_OR_EDIT);
            // Sets the MIME type
            intentInsertEdit
                    .setType(ContactsContract.Contacts.CONTENT_ITEM_TYPE);
            // Add code here to insert extended data, if desired
            intentInsertEdit.putExtra(ContactsContract.Intents.Insert.PHONE,
                    number);

            // Sends the Intent with an makeRequest ID
            startActivity(intentInsertEdit);
        } else {
            Intent intentInsert = new Intent(Contacts.Intents.Insert.ACTION);
            intentInsert.setData(People.CONTENT_URI);
            intentInsert.putExtra(People.NUMBER, number);
            startActivity(intentInsert);
        }
    }

    public static void addToImageReloadSet(String value) {
        sImageReloadSet.add(value);
    }

}
