package com.revesoft.itelmobiledialer.eventlistener;

public enum DialerEvent {
    MuteOrUnMuteChangeEvent,
    BlockStatusChangeEvent,
    SubscriberUpdatedEvent,
    SubscriberTableLoaded,
    BackUpOperationStatus
}
