package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.jetPack;

import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

public class ChatWindowSupportingViewModel extends ViewModel {
    LiveData<List<String>> unseenMessageCallerIds;
    public ChatWindowSupportingViewModel() {
        unseenMessageCallerIds = MessageRepo.get().getUnseenMessagesByNumber(Target.target,ChatProperties.isEncryptedChat);
    }

    public LiveData<List<String>> getUnseenMessageCallerIds() {
        return unseenMessageCallerIds;
    }
}
