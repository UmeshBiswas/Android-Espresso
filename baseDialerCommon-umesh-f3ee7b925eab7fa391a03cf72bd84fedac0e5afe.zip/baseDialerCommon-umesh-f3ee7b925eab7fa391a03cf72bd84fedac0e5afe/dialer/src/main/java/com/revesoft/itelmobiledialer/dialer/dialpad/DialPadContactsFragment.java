package com.revesoft.itelmobiledialer.dialer.dialpad;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.SpannableString;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.interfaces.AddRequestListener;
import com.revesoft.itelmobiledialer.interfaces.Controllable;
import com.revesoft.itelmobiledialer.interfaces.Searchable;
import com.revesoft.itelmobiledialer.processor.contactblock.ContactBlockHelper;
import com.revesoft.itelmobiledialer.util.CallMaker;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.TextHighlighter;
import com.revesoft.itelmobiledialer.xdatabase.DatabaseUris;
import com.revesoft.itelmobiledialer.xdatabase.XTableKeys;
import com.revesoft.material.R;

import java.util.HashSet;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta
 * on 5/31/2017.
 */

public class DialPadContactsFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>, Searchable, AddRequestListener {
    public static final String TAG = "PhoneBookFragmentTag";
    private static final int LOADER_ID = 50;
    private static final String KEY_HAS_OPTION_MENU = "KEY_HAS_OPTION_MENU";
    RecyclerView rv;
    RecyclerView.LayoutManager layoutManager;
    LinearLayout nothingIsHereHolder;
    DialPadContactsAdapter adapter;
    boolean hasOptionMenu;

    public DialPadContactsFragment() {
    }

    public static DialPadContactsFragment newInstance(boolean hasOptionMenu) {
        Bundle bundle = new Bundle();
        bundle.putBoolean(KEY_HAS_OPTION_MENU, hasOptionMenu);
        DialPadContactsFragment fragment = new DialPadContactsFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    Controllable parentActivity;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.dial_pad_contacts_layout, container, false);
        parentActivity = (Controllable) getActivity();
        rv = v.findViewById(R.id.rv);
        initEmptyListLayout(v);
        layoutManager = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(layoutManager);
        adapter = new DialPadContactsAdapter(getActivity());
        rv.setAdapter(adapter);
        v.setFocusableInTouchMode(true);
        v.requestFocus();
        getLoaderManager().initLoader(LOADER_ID, null, this);
        IntentFilter filter = new IntentFilter(Constants.DASHBOARD_INTENT_FILTER);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(broadcastReceiver, filter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        hasOptionMenu = bundle.getBoolean(KEY_HAS_OPTION_MENU);
        setHasOptionsMenu(hasOptionMenu);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (getActivity() != null && isAdded()) {
            LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(broadcastReceiver);
        }
    }


    private void initEmptyListLayout(View v) {
        nothingIsHereHolder = v.findViewById(R.id.llEmptyListHolder);
        TextView tvEmptyListDescription = v.findViewById(R.id.tvEmptyListDescription);
        ImageView ivEmptyListIcon = v.findViewById(R.id.ivEmptyListIcon);
        tvEmptyListDescription.setText(getString(R.string.noContactFound));
        if (getActivity() != null && isAdded()) {
            ivEmptyListIcon.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.ic_big_no_contact));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        if (id == LOADER_ID) {
            return new SQLiteCursorLoader(getActivity()) {
                @Override
                public Cursor loadInBackground() {
                    if (TextUtils.isEmpty(searchText) || searchText.trim().length() < 1) {
                        return null;
                    }
                    Cursor cursor;
                    try {
//                        if(searchText.startsWith("+")){
//                            searchText = searchText.substring(1);
//                        }
                        cursor = ContactRepo.get().allCursor(searchText);
                        if (cursor != null && cursor.moveToFirst()) {
                            this.registerContentObserver(cursor, DatabaseUris.CONTACTS_URI);
                            return cursor;
                        } else {
                            return null;
                        }
                    } catch (SQLiteException ex) {
                        I.errTrace(ex);
                        ex.printStackTrace();
                    }
                    return null;
                }
            };

        }
        return null;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (loader.getId() == LOADER_ID) {
            if (data != null && data.moveToFirst() && data.getCount() != 0) {
                hideEmptyViewMessage();
                if (adapter != null) {
                    adapter.swapCursor(data);
                }
            } else {
                if (adapter != null) {
                    adapter.swapCursor(null);
                }
                showEmptyViewMessage();
            }
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    @Override
    public void onDestroyView() {
        getLoaderManager().destroyLoader(LOADER_ID);
        super.onDestroyView();
    }

    private void showEmptyViewMessage() {
        nothingIsHereHolder.setVisibility(View.VISIBLE);
    }

    private void hideEmptyViewMessage() {
        nothingIsHereHolder.setVisibility(View.GONE);
    }

    @Override
    public void search(String searchString) {
        this.searchText = searchString;
        if (isAdded() && getActivity() != null)
            getLoaderManager().restartLoader(LOADER_ID, null, this);
    }

    @Override
    public void onAddRequest() {
        Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
        intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
        getActivity().startActivity(intent);
    }

    private class DialPadContactsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int ITEM_VIEW = 5020;
        Cursor dataCursor = null;
        Context context;

        DialPadContactsAdapter(Context context) {
            this.context = context;
        }

        protected void swapCursor(Cursor cursor) {
            dataCursor = cursor;
            notifyDataSetChanged();
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v;
            if (viewType == ITEM_VIEW) {
                v = LayoutInflater.from(context).inflate(R.layout.dial_pad_contacts_single_item, parent, false);
                return new ViewHolder(v);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ViewHolder vh = (ViewHolder) holder;
            vh.bindView();
        }

        @Override
        public int getItemCount() {
            if (dataCursor == null || dataCursor.isClosed()) {
                showEmptyViewMessage();
                return 0;
            }
            hideEmptyViewMessage();
            return dataCursor.getCount();
        }

        @Override
        public int getItemViewType(int position) {
            return ITEM_VIEW;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivPhoneContactImage;
            TextView tvName, tvPhoneNumber;
            Button bUnblock;
            ImageView ivOnlineStatus;

            private ViewHolder(View itemView) {
                super(itemView);
                ivPhoneContactImage = itemView.findViewById(R.id.ivPhoneContactImage);
                tvName = itemView.findViewById(R.id.tvNameOfQuotee);
                tvPhoneNumber = itemView.findViewById(R.id.tvPhoneNumber);
                bUnblock = itemView.findViewById(R.id.bUnblock);
                ivOnlineStatus = itemView.findViewById(R.id.onlineStatus);
            }

            public void bindView() {
                if (dataCursor == null) {
                    return;
                }
                try {
                    int position = getAdapterPosition();
                    dataCursor.moveToPosition(position);
                    final PhoneBuddy phoneBuddy = new PhoneBuddy(dataCursor);
                    setNameAndNumber(phoneBuddy);
                    String priorityPhotoUri = ProfilePictureDataProvider.getProfilePicturePath(getActivity(), phoneBuddy.phoneNo);
                    if (priorityPhotoUri != null) {
                        phoneBuddy.imageUri = priorityPhotoUri;
                    }
                    ImageUtil.setImageButTextImageOnException(getActivity(), phoneBuddy.imageUri, ivPhoneContactImage, tvName.getText().toString());
                    if (CommonData.blockedNumber.contains(phoneBuddy.processedNumber)) {
                        handleUnblockButton(phoneBuddy);
                        ivOnlineStatus.setVisibility(View.GONE);
                    } else {
                        hideUnblockButton();
                    }
                    itemView.findViewById(R.id.mainContent).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showCallOptions(phoneBuddy.processedNumber);
                        }
                    });
                } catch (Exception e) {
                    I.errTrace(e);
                    e.printStackTrace();
                }
            }

            private void hideUnblockButton() {
                bUnblock.setVisibility(View.GONE);
            }

            private void handleUnblockButton(final PhoneBuddy phoneBuddy) {
                bUnblock.setVisibility(View.VISIBLE);
                bUnblock.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ContactBlockHelper.getAccess().unblock(phoneBuddy.processedNumber);
                    }
                });
            }

            private void setNameAndNumber(PhoneBuddy phoneBuddy) {
                if (TextUtils.isEmpty(searchText) || searchText.trim().length() < 1) {
                    tvName.setText(phoneBuddy.name);
                    tvPhoneNumber.setText(phoneBuddy.phoneNo);
                } else {
                    SpannableString highlightedName = TextHighlighter.getHighlightedText(phoneBuddy.name, searchText);
                    tvName.setText(highlightedName);
                    SpannableString highlightedNumber = TextHighlighter.getHighlightedText(phoneBuddy.phoneNo, searchText);
                    tvPhoneNumber.setText(highlightedNumber);
                }
            }
        }
    }

    private void showCallOptions(String processedNumber) {
        CallMaker.handleAllTypesOfCall(getActivity(), processedNumber);
//        if (Database.Subscriber.Read.isSubscriber(processedNumber)) {
//            CallMaker.handleAllTypesOfCall(getActivity(),processedNumber);
//        } else {
//            CallMaker.makePaidCall(getActivity(),processedNumber);
//        }
    }

    private class PhoneBuddy {
        String name, imageUri, lookUpKey;
        String phoneNo, processedNumber;

        PhoneBuddy(Cursor cursor) {
            if (cursor == null) {
                return;
            }
            this.name = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NAME));
            this.lookUpKey = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_PHONE_LOOKUP));
            this.phoneNo = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NUMBER));
            this.imageUri = ProfilePictureDataProvider.getProfilePicturePath(getActivity(), this.phoneNo);
            this.processedNumber = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_PROCESSED_NUMBER));
            if (imageUri == null) {
                this.imageUri = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_PHOTO_URI));
            }

        }
    }

    String searchText = "";
    HashSet<String> selectedContacts = new HashSet<>();

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        // Make sure that we are currently visible
        if (this.isVisible()) {
            // If we are becoming invisible, then...
            if (!isVisibleToUser) {
                if (!searchText.equals("")) {
                    searchText = "";
                    getLoaderManager().restartLoader(LOADER_ID, null, this);
                }
            }
        }
    }

    public static String getTAG() {
        return TAG;
    }

    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(Constants.Broadcast.TYPE_SUBSCRIBER_INFO_LOADED_SIGNAL)) {
                    adapter.notifyDataSetChanged();
                } else if (bag.containsKey(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE)) {
                    adapter.notifyDataSetChanged();
                }
            }
        }
    };
}

