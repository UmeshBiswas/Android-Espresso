package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;


import java.util.HashMap;

public class MapDataAsParameter {
	public static class Builder{
		HashMap<String,String> map;
		public Builder() {
			map = new HashMap<>();
		}

		public Builder put(String key, String value){
			map.put(key,value);
			return this;
		}
		public HashMap<String, String> build() {
			return map;
		}
	}
	public static Builder getBuilder() {
		return new Builder();
	}
}
