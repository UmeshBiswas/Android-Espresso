package com.revesoft.itelmobiledialer.account;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.share.Sharer;
import com.facebook.share.model.AppInviteContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.AppInviteDialog;
import com.facebook.share.widget.ShareDialog;
import com.revesoft.material.R;

import java.util.Arrays;


public class FacebookSharingActivity extends Activity {
    private TextView shareOnTimeLineButton;
    private TextView sendPrivateMessageButton;
    private TextView sendInviteNotificationButton;

    private CallbackManager callbackManager;
    private ShareDialog shareDialog;
    private static AccessToken currentAccessToken;
    private AppInviteContent mAppInviteContent;
    private ShareLinkContent mShareLinkContent;
    private static final int SHARE_ON_FACEBOOK = 1;
    private static final int INVITE_ON_FACEBOOK = 2;

    private static int LOGGED_IN_ACTION = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_facebook);
        initFacebookEngine();
    }

    private void shareOnTimeLine() {
       // if (AccessToken.getCurrentAccessToken() != null && !AccessToken.getCurrentAccessToken().isExpired()) {
            postStatus();
        //} else {
            LOGGED_IN_ACTION = SHARE_ON_FACEBOOK;
          //  LoginManager.newInstance().logInWithReadPermissions(FacebookSharingActivity.this, Arrays.asList("public_profile", "user_friends", "email"));
        //}
        finish();
    }

    private void sendPrivateMessage() {
        if (isPackageInstalled("com.facebook.orca")) {
            sendInboxMessage();
        } else {
            openMessengerInPlayStore("com.facebook.orca");
        }
        finish();
    }

    private void sendInviteNotification() {
        if (AccessToken.getCurrentAccessToken() != null && !AccessToken.getCurrentAccessToken().isExpired()) {
            if (AppInviteDialog.canShow()) {
                AppInviteDialog.show(FacebookSharingActivity.this, mAppInviteContent);
            } else {
                showToast("Invitation cannot be sent.");
            }
            finish();
        } else {
            LOGGED_IN_ACTION = INVITE_ON_FACEBOOK;
            LoginManager.getInstance().logInWithReadPermissions(FacebookSharingActivity.this, Arrays.asList("public_profile", "user_friends", "email"));
        }
    }

    private void initFacebookEngine() {
        FacebookSdk.sdkInitialize(getApplicationContext());
        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);
        shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {
                if (result.getPostId() != null) {
                    showToast(getString(R.string.successful));
                } else {
                    showToast(getString(R.string.failed));
                }
            }

            @Override
            public void onCancel() {
                showToast(getString(R.string.cancelled));
            }

            @Override
            public void onError(FacebookException e) {
                showToast(getString(R.string.error) + " " + e.getMessage());
            }
        });

        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                currentAccessToken = loginResult.getAccessToken();
                if (LOGGED_IN_ACTION == SHARE_ON_FACEBOOK) {
                    postStatus();
                } else if (LOGGED_IN_ACTION == INVITE_ON_FACEBOOK) {
                    sendInviteNotification();
                }

                finish();
            }

            @Override
            public void onCancel() {
                showToast(getString(R.string.cancelled));
                finish();
            }

            @Override
            public void onError(FacebookException e) {
                showToast(getString(R.string.login_error) + " " + e.getMessage());
                finish();
            }
        });


        shareOnTimeLineButton = (TextView) findViewById(R.id.share_on_timeline_button);
        sendPrivateMessageButton = (TextView) findViewById(R.id.send_private_message_button);
        sendInviteNotificationButton = (TextView) findViewById(R.id.send_invite_notification_button);

        mAppInviteContent = new AppInviteContent.Builder()
                .setApplinkUrl(getString(R.string.facebook_redirect_url))
                .setPreviewImageUrl(getString(R.string.facebook_image_url))
                .build();


        mShareLinkContent = new ShareLinkContent.Builder()
                .setContentTitle(getString(R.string.app_name))
                .setContentDescription(
                        getString(R.string.invitationText))
                .setContentUrl(Uri.parse(getString(R.string.facebook_redirect_url)))
                .setImageUrl(Uri.parse(getString(R.string.facebook_image_url)))
                .build();


        shareOnTimeLineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareOnTimeLine();
            }
        });

        sendPrivateMessageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendPrivateMessage();
            }
        });

        sendInviteNotificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendInviteNotification();
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(FacebookSharingActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    private void postStatus() {
        if (ShareDialog.canShow(ShareLinkContent.class)) {
            shareDialog.show(mShareLinkContent);
        } else {
            showToast(getString(R.string.failed));
        }
    }

    private void sendInboxMessage() {
//        if (MessageDialog.canShow(ShareLinkContent.class)) {
//            ShareLinkContent linkContent = new ShareLinkContent.Builder()
//                    .setContentTitle(getString(R.string.app_name))
//                    .setContentDescription(
//                            getString(R.string.facebook_description))
//                    .setContentUrl(Uri.parse(getString(R.string.facebook_redirect_url)))
//                    .setImageUrl(Uri.parse(getString(R.string.facebook_image_url)))
//                    .build();
//
//            MessageDialog.show(FacebookActivity.this, linkContent);
//
//        } else {
//            showToast("Message cannot be sent.");
//        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.setPackage("com.facebook.orca");
        intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.invitationText));
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private boolean isPackageInstalled(String packageName) {
        PackageManager pm = getApplicationContext().getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public void openMessengerInPlayStore(String packageName) {
        try {
            startViewUri("market://details?id=" + packageName);
        } catch (ActivityNotFoundException anfe) {
            startViewUri("http://play.google.com/store/apps/details?id=" + packageName);
        }
    }

    private void startViewUri(String uri) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri)));
    }
}