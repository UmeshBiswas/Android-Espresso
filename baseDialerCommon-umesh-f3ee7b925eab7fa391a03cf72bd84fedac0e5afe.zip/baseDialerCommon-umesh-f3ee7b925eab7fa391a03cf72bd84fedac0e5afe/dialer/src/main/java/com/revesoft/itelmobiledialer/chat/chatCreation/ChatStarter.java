package com.revesoft.itelmobiledialer.chat.chatCreation;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.ims.GroupChatCreationActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.List;

public class ChatStarter {
    public static void createGroupChat(Context context, List<String> numbers) {
        if (numbers.size() == 0) {
            Toast.makeText(context, context.getString(R.string.pleaseSelectOneContact), Toast.LENGTH_LONG).show();
        } else if (numbers.size() == 1) {
            IntentUtil.sendStartIMSIntent(context, Util.translateNumber(numbers.get(0), UserDataManager.getUserCountryCode()));
        } else {
            Intent intent = new Intent(context, GroupChatCreationActivity.class);
            String[] selectedMembersNumber = new String[numbers.size()];
            for (int i = 0; i < selectedMembersNumber.length; i++) {
                selectedMembersNumber[i] = numbers.get(i);
            }
            intent.putExtra(Constants.GroupChat.KEY_SELECTED_MEMBERS, selectedMembersNumber);
            context.startActivity(intent);
        }
    }
}
