package com.revesoft.itelmobiledialer.dialogues;

import android.app.AlarmManager;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.revesoft.material.R;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;


/**
 * @author ashikee on 10/30/16.
 */
public class CustomDialogNotificationSet extends Dialog {
    public Context c;
    public Dialog d;
    public TextView head;
    Button yes, no;
    public CheckBox checkBox;
    public RadioGroup radioGroupMuteDuration;
    String keyMute, keyIsToShowNotifications;


    public void setmListenerYesButton(View.OnClickListener mListenerYesButton) {
        this.mListenerYesButton = mListenerYesButton;
    }

    View.OnClickListener mListenerYesButton;

    public void setmListenerNoButton(View.OnClickListener mListenerNoButton) {
        this.mListenerNoButton = mListenerNoButton;
    }

    View.OnClickListener mListenerNoButton;
    boolean isCancelable;

    public CustomDialogNotificationSet(Context a, String keyMute, String keyIsToShowNotifications, boolean isCancelable) {

        super(a);
        // TODO Auto-generated constructor stub
        this.c = a;
        this.keyMute = keyMute;
        this.isCancelable = isCancelable;
        this.keyIsToShowNotifications = keyIsToShowNotifications;

    }

    public long getMuteDuration() {
        int selectedId = radioGroupMuteDuration.getCheckedRadioButtonId();

        if (selectedId == R.id.radioEightHours) {
            return AlarmManager.INTERVAL_HOUR * 8;
        } else if (selectedId == R.id.radioOneWeek) {
            return AlarmManager.INTERVAL_DAY * 7;
        } else if (selectedId == R.id.radioOneYear) {
            return AlarmManager.INTERVAL_DAY * 365;
        }
        return -1;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        int width = (int) (c.getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.90);
        Window window = this.getWindow();
        if (window != null) {
            window.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setGravity(Gravity.CENTER);
            window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        }
        setContentView(R.layout.custom_dialog_notification_set);
        this.setCancelable(isCancelable);
        yes = (Button) findViewById(R.id.btn_ok);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PreferenceDataManager.quickPut(keyMute, System.currentTimeMillis() + getMuteDuration());
                PreferenceDataManager.quickPut(keyIsToShowNotifications, !checkBox.isChecked());
                Log.d("CustomNotificationSet", "set Mute for: " + System.currentTimeMillis() + getMuteDuration() +
                        "isNotificationsEnabled: " + checkBox.isChecked());
                dismiss();
            }
        });
        no = (Button) findViewById(R.id.btn_cancel);
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
        head = (TextView) findViewById(R.id.head);
        radioGroupMuteDuration = (RadioGroup) findViewById(R.id.radioGroupMuteDuration);
        checkBox = (CheckBox) findViewById(R.id.checkBox_showNotifications);

    }
}
