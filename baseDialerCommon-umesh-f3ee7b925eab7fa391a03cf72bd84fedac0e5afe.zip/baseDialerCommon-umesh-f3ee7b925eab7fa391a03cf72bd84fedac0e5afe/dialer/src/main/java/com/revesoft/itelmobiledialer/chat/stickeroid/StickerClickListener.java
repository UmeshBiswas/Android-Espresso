package com.revesoft.itelmobiledialer.chat.stickeroid;

/**
 * @author Ifta on 11/1/2017.
 */

public interface StickerClickListener {
    void onStickerClick(Sticker sticker);
}
