package com.revesoft.itelmobiledialer.account.extras;

public enum  DataUsageRestrictedFileLoadType {
    LOAD_ALL,
    LOAD_SINGLE_FORCED
}
