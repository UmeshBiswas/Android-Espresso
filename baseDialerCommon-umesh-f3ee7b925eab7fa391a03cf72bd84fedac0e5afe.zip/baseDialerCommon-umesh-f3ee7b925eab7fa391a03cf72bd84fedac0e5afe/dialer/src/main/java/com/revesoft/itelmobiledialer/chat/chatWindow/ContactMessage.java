package com.revesoft.itelmobiledialer.chat.chatWindow;

import android.graphics.Bitmap;

/**
 * Created by Zim on 24-Apr-18.
 */

public class ContactMessage {
    public String name;
    public String number;
    public Bitmap imageBitmap;


    public ContactMessage(){
    }

    public ContactMessage(String name, String number, Bitmap imageBitmap) {
        this.name = name;
        this.number = number;
        this.imageBitmap = imageBitmap;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setImageBitmap(Bitmap imageBitmap) {
        this.imageBitmap = imageBitmap;
    }


    @Override
    public String toString() {
        return "ContactMessage{" +
                "name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", imageBitmap=" + imageBitmap +
                '}';
    }

}
