package com.revesoft.itelmobiledialer.appDatabase.entities;

import org.jetbrains.annotations.NotNull;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "burn_message_info")
public class BurnMessageInfo {

    @ColumnInfo(name = "callerid")
    public String callerId;

    @NotNull
    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "number")
    public String number;

    @ColumnInfo(name = "entry_type")
    public int entryType;

    @ColumnInfo(name = "burn_entry_time")
    public long burnEntryTime;

    @ColumnInfo(name = "burn_time")
    public int burnTime;

    @ColumnInfo(name = "burn_timer_index")
    public int burnTimeIndex;

    @ColumnInfo(name = "messagetype")
    public int messageType;

    public BurnMessageInfo() {
    }

    private BurnMessageInfo(Builder builder) {
        callerId = builder.callerId;
        number = builder.number;
        entryType = builder.entryType;
        burnEntryTime = builder.burnEntryTime;
        burnTime = builder.burnTime;
        burnTimeIndex = builder.burnTimeIndex;
        messageType = builder.messageType;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private String callerId;
        private String number;
        private int entryType;
        private long burnEntryTime;
        private int burnTime;
        private int burnTimeIndex;
        private int messageType;

        private Builder() {
        }

        public Builder withCallerId(String val) {
            callerId = val;
            return this;
        }

        public Builder withNumber(String val) {
            number = val;
            return this;
        }

        public Builder withEntryType(int val) {
            entryType = val;
            return this;
        }

        public Builder withBurnEntryTime(long val) {
            burnEntryTime = val;
            return this;
        }

        public Builder withBurnTime(int val) {
            burnTime = val;
            return this;
        }

        public Builder withBurnTimeIndex(int val) {
            burnTimeIndex = val;
            return this;
        }

        public Builder withMessageType(int val) {
            messageType = val;
            return this;
        }

        public BurnMessageInfo build() {
            return new BurnMessageInfo(this);
        }
    }
}
