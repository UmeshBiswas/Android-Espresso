package com.revesoft.itelmobiledialer.callog.callLogDetails;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.data.NameResolver;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.util.ViewSetup;
import com.revesoft.material.R;
import com.revesoft.material.databinding.ActivityUserWiseFullCallLogBinding;

import androidx.databinding.DataBindingUtil;

public class UserWiseFullCallLogActivity extends BaseActivity {
    private static final String KEY_NUMBER = "KEY_NUMBER";
    private String number = null;
    ActivityUserWiseFullCallLogBinding binding;

    public static void start(Context context, String number) {
        Intent intent = new Intent(context, UserWiseFullCallLogActivity.class);
        intent.putExtra(KEY_NUMBER, number);
        context.startActivity(intent);
    }

    CallLogDetailsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_user_wise_full_call_log);
        readData();
        ViewSetup.setUpToolbar(this, getString(R.string.call_info), true);
        binding.tvUserName.setText(NameResolver.getContactNameFromNumberOrEmail(number));
        ViewSetup.setupImage(this, number, binding.ivProfilePhoto);
        binding.ivProfilePhoto.setOnClickListener((v) -> Switcher.switchToContactDetails(this, number));
        adapter = new CallLogDetailsAdapter(this);
        binding.recyclerView.setAdapter(adapter);
        CallLogDetailsViewModel viewModel = new CallLogDetailsViewModel(number);
        viewModel.getData().observe(this, callLogDetailsCallItems -> adapter.swapData(callLogDetailsCallItems));
    }

    private void readData() {
        if (getIntent().getExtras() != null && getIntent().getExtras().containsKey(KEY_NUMBER)) {
            number = getIntent().getExtras().getString(KEY_NUMBER);

        }
        if (number == null) finish();
        number = Util.translateNumber(number);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
