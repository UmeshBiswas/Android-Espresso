package com.revesoft.itelmobiledialer.chat.chatWindow;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.HiddenMessageRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.PersistentRepo;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.ims.TypeYourPinLayout;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;


/**
 * Created by Sajib on 1/16/2018.
 */

public class HiddenChatDialogs {

    private Context mContext;
    private String pinText = "";

    public HiddenChatDialogs(Context c) {
        this.mContext = c;
    }

    public void showSetPinForHideChatDialog(final String number, final String groupId, final int isEncrypted) {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));//(mContext.getResources().getColor(R.color.bt_background)));
        dialog.setContentView(R.layout.dialog_input_password);

        final TextView tvBody = dialog.findViewById(R.id.tv_hidden_chat_body);
        tvBody.setText(R.string.hide_pin_remember_alert);

        final TextView tvTitle = dialog.findViewById(R.id.dialog_input_password_title);
        tvTitle.setText(mContext.getString(R.string.hidden_chat_enter_pin));
        tvTitle.setVisibility(View.VISIBLE);

        pinText = "";
        TypeYourPinLayout typeYourPinlayout = dialog.findViewById(R.id.type_your_pin_layout);
        typeYourPinlayout.setTypeYourPinInterface(pin -> {
            //set your pin here
            pinText = pin;
        });
        //et_Editpassword.setVisibility(View.VISIBLE);
        final String saved_pin_code = mContext.getSharedPreferences(Constants.tag, Activity.MODE_PRIVATE).getString(Constants.PIN_CODE_FOR_HIDE_CHAT, "");
        final boolean createPin = saved_pin_code.isEmpty(); //? true : false;

        Button btnSetPin = dialog.findViewById(R.id.set_pin_button);
        btnSetPin.setOnClickListener(v -> {
            String entered_pin_code = pinText;

            Executor.ex(() -> {
                boolean willBeHidden = !HiddenMessageRepo.get().checkIfHiddenChat(number, isEncrypted, groupId, !TextUtils.isEmpty(groupId));

                if (entered_pin_code.length() != 4) {
                    I.toast(Supplier.getString(R.string.hide_pin_must_be_4digit));
                } //If first time, save this pin code in a shared preference
                else {
                    if (createPin) {
                        PreferenceDataManager.quickPut(Constants.PIN_CODE_FOR_HIDE_CHAT, entered_pin_code);
//                    DatabaseConstants.getInstance().createOrUpdatePersistentSettingsEntry(Constants.PIN_CODE_FOR_HIDE_CHAT, entered_pin_code);

                        PersistentRepo.get().createOrUpdatePersistentSettingsEntry(Constants.PIN_CODE_FOR_HIDE_CHAT, entered_pin_code);
                        MessageRepo.get().updateGroupChatHiddenStatus(number, groupId, isEncrypted, true);

                    }
                    //If not, then check the value with the pin code from shared preference-> if matches, then hide this chat, otherwise not.
                    else if (entered_pin_code.equals(saved_pin_code) == true) {


                        MessageRepo.get().updateGroupChatHiddenStatus(number, groupId, isEncrypted, willBeHidden);


                    } else {
                        Gui.get().run(() -> I.toast(Supplier.getString(R.string.pin_does_not_match)));
                    }

                }
            });


            dialog.dismiss();
        });

        Button btnCancel = dialog.findViewById(R.id.cancel_button);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }

    private void openNewChatWindow(String number) {
        Switcher.switchToChatWindow(mContext, Util.translateNumber(number),
                false, false,
                false, false);
    }


    public void showGetPinToOpenHiddenChatDialog(final String number) {

        final String _number = number;
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));//mContext.getResources().getColor(R.color.bt_background)));
        dialog.setContentView(R.layout.dialog_input_password);


        //final TextView tvTitle =(TextView) dialog.findViewById(R.id.tv_hidden_chat_title);
        //tvTitle.setText(R.string.hidden_chat_enter_pin);
        //tvTitle.setText(R.string.hidden_chats);
        final TextView tvBody = dialog.findViewById(R.id.tv_hidden_chat_body);
        //tvBody.setText(R.string.hide_alert);
        tvBody.setText(R.string.hide_pin_remember_alert);

        final TextView tvTitle = dialog.findViewById(R.id.dialog_input_password_title);
        tvTitle.setText(mContext.getString(R.string.enter_your_pin));
        tvTitle.setVisibility(View.VISIBLE);

        Button btnSetPin = dialog.findViewById(R.id.set_pin_button);
        btnSetPin.setText(mContext.getString(R.string.enter_pin));

        pinText = "";
        TypeYourPinLayout typeYourPinlayout = dialog.findViewById(R.id.type_your_pin_layout);
        typeYourPinlayout.setTypeYourPinInterface(new TypeYourPinLayout.TypeYourPinInterface() {
            @Override
            public void onPinTyped(String pin) {
                //set your pin here
                pinText = pin;
            }
        });

        //et_Editpassword.setVisibility(View.VISIBLE);
        final String saved_pin_code = mContext.getSharedPreferences(Constants.tag, Activity.MODE_PRIVATE).getString(Constants.PIN_CODE_FOR_HIDE_CHAT, "");
        final boolean emptyPin = saved_pin_code.isEmpty(); //? true : false;

        btnSetPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String entered_pin_code = pinText;
                if (entered_pin_code.length() != 4) {
                    I.toast(Supplier.getString(R.string.hide_pin_must_be_4digit));
                } else if (!emptyPin && saved_pin_code.equals(entered_pin_code)) {
                    //go to chat window of this buddy
                    openNewChatWindow(_number);
                } else {
                    I.toast(Supplier.getString(R.string.pin_does_not_match));
                }

                dialog.dismiss();
            }
        });

        Button btnCancel = dialog.findViewById(R.id.cancel_button);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }

    /*
    Clear PIN for hidden chat from shared preferences &
    delete all chat from db which was hidden before
    * */
    public void showResetPinForHideChatDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));//mContext.getResources().getColor(R.color.bt_background)));

        LinearLayout dialogLayout = (LinearLayout) ((Activity) mContext).getLayoutInflater().inflate(R.layout.dialog_input_password, null);
        dialog.setContentView(dialogLayout);

        dialogLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        final TextView tvBody = dialog.findViewById(R.id.tv_hidden_chat_body);
        //tvBody.setText(R.string.hide_alert);
        tvBody.setText(R.string.hide_pin_reset_alert);


        final TextView tvTitle = dialog.findViewById(R.id.dialog_input_password_title);
        tvTitle.setText(mContext.getString(R.string.hidden_chat_reset_pin));
        tvTitle.setVisibility(View.VISIBLE);

        Button btnSetPin = dialog.findViewById(R.id.set_pin_button);


        pinText = "";
        TypeYourPinLayout typeYourPinlayout = dialog.findViewById(R.id.type_your_pin_layout);
        typeYourPinlayout.setTypeYourPinInterface(new TypeYourPinLayout.TypeYourPinInterface() {
            @Override
            public void onPinTyped(String pin) {
                //set your pin here
                pinText = pin;
            }
        });

        //et_Editpassword.setVisibility(View.VISIBLE);
        final String saved_pin_code = mContext.getSharedPreferences(Constants.tag, Activity.MODE_PRIVATE).getString(Constants.PIN_CODE_FOR_HIDE_CHAT, "");
        final boolean emptyPin = saved_pin_code.isEmpty(); //? true : false;


        btnSetPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String entered_pin_code = pinText;
                if (entered_pin_code.length() != 4) {
                    I.toast(Supplier.getString(R.string.hide_pin_must_be_4digit));
                }
                //If first time, save this pin code in a shared preference
                else if (!emptyPin) {
                    if (entered_pin_code.equals(saved_pin_code) == true) {
                        mContext.getSharedPreferences(Constants.tag, Activity.MODE_PRIVATE).edit().putString(Constants.PIN_CODE_FOR_HIDE_CHAT, "").apply();
                        Executor.ex(() -> {
                            MessageRepo.get().deleteEveryHiddenMessageFromHistory();
                        });

                        I.toast(Supplier.getString(R.string.pin_reset_success));
                    } else {
                        I.toast(Supplier.getString(R.string.pin_does_not_match));
                    }
                }

                dialog.dismiss();
            }
        });

        Button btnCancel = dialog.findViewById(R.id.cancel_button);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }

    public void showChangePinForHideChatDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));//mContext.getResources().getColor(R.color.bt_background)));
        dialog.setContentView(R.layout.dialog_input_password);


        //final TextView tvTitle =(TextView) dialog.findViewById(R.id.tv_hidden_chat_title);
        //tvTitle.setText(R.string.hidden_chat_enter_pin);
        //tvTitle.setText(R.string.hidden_chats);
        final TextView tvBody = dialog.findViewById(R.id.tv_hidden_chat_body);
        //tvBody.setText(R.string.hide_alert);
        tvBody.setText(R.string.hide_pin_enter_current);

        final TextView tvTitle = dialog.findViewById(R.id.dialog_input_password_title);
        tvTitle.setText(mContext.getString(R.string.hidden_chat_change_pin));
        tvTitle.setVisibility(View.VISIBLE);


        Button btnSetPin = dialog.findViewById(R.id.set_pin_button);

        pinText = "";
        TypeYourPinLayout typeYourPinlayout = dialog.findViewById(R.id.type_your_pin_layout);
        typeYourPinlayout.setTypeYourPinInterface(new TypeYourPinLayout.TypeYourPinInterface() {
            @Override
            public void onPinTyped(String pin) {
                //set your pin here
                pinText = pin;
            }
        });

        //et_Editpassword.setVisibility(View.VISIBLE);
        final String saved_pin_code = mContext.getSharedPreferences(Constants.tag, Activity.MODE_PRIVATE).getString(Constants.PIN_CODE_FOR_HIDE_CHAT, "");
        final boolean emptyPin = saved_pin_code.isEmpty(); //? true : false;


        btnSetPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String entered_pin_code = pinText;

                if (emptyPin) {
                    I.toast(Supplier.getString(R.string.pin_not_set_yet));
                } else if (entered_pin_code.length() != 4) {
                    I.toast(Supplier.getString(R.string.hide_pin_must_be_4digit));
                } else {
                    if (entered_pin_code.equals(saved_pin_code)) {
                        confirmChangePinForHideChatDialog();
                    } else {
                        I.toast(Supplier.getString(R.string.pin_does_not_match));
                    }
                }

                dialog.dismiss();
            }
        });

        Button btnCancel = dialog.findViewById(R.id.cancel_button);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }


    private void confirmChangePinForHideChatDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));//mContext.getResources().getColor(R.color.bt_background)));
        dialog.setContentView(R.layout.dialog_input_password);


        //final TextView tvTitle =(TextView) dialog.findViewById(R.id.tv_hidden_chat_title);
        //tvTitle.setText(R.string.hidden_chat_enter_pin);
        //tvTitle.setText(R.string.hidden_chats);
        final TextView tvBody = dialog.findViewById(R.id.tv_hidden_chat_body);
        //tvBody.setText(R.string.hide_alert);
        tvBody.setText(R.string.hide_pin_remember_alert);

        final TextView tvTitle = dialog.findViewById(R.id.dialog_input_password_title);
        tvTitle.setText(mContext.getString(R.string.hidden_chat_change_pin));
        tvTitle.setVisibility(View.VISIBLE);


        Button btnSetPin = dialog.findViewById(R.id.set_pin_button);

        pinText = "";
        TypeYourPinLayout typeYourPinlayout = dialog.findViewById(R.id.type_your_pin_layout);
        typeYourPinlayout.setTypeYourPinInterface(new TypeYourPinLayout.TypeYourPinInterface() {
            @Override
            public void onPinTyped(String pin) {
                //set your pin here
                pinText = pin;
            }
        });

        btnSetPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String entered_pin_code = pinText;
                if (entered_pin_code.length() != 4) {
                    I.toast(Supplier.getString(R.string.hide_pin_must_be_4digit));
                } else {
                    mContext.getSharedPreferences(Constants.tag, Activity.MODE_PRIVATE).edit().putString(Constants.PIN_CODE_FOR_HIDE_CHAT, entered_pin_code).apply();
                    I.toast(Supplier.getString(R.string.pin_change_success));
                }

                dialog.dismiss();
            }
        });

        Button btnCancel = dialog.findViewById(R.id.cancel_button);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }




}
