package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.jetPack;

import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.JetPackChatAdapter;
import com.revesoft.itelmobiledialer.testunit.Voldemort;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class ChatWindowViewModelFactory implements ViewModelProvider.Factory {
    private JetPackChatAdapter.MessageType type = JetPackChatAdapter.MessageType.REGULAR;
    private String target;
    private boolean isGroup = false;

    public ChatWindowViewModelFactory(JetPackChatAdapter.MessageType type, String target, boolean isGroup) {
        this.type = type;
        this.target = target;
        this.isGroup = isGroup;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new ChatWindowViewModel(type, target, isGroup);
    }
}
