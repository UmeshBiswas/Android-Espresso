package com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments;


import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Controllable;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.ims.MyLocationProvider;
import com.revesoft.itelmobiledialer.ims.OnFragmentInteractionListener;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GoogleMapFragment#newInstance} factory method to
 * initialize an instance of this fragment.
 */
public class GoogleMapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMapClickListener {

    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    private LatLng latestLatLng;
    private SupportMapFragment mapFragment;
    //    private boolean hasMarked = false;
    private volatile boolean pendingFlag = false;
    private ImageButton sendLocation;
    private ImageButton getCurrentLocation;
    private RelativeLayout contentView;
    private RelativeLayout askPermissionView;


    private Handler handler;
    private volatile boolean isMapLoaded = false;
    private Runnable mapLoader = new Runnable() {
        @Override
        public void run() {
            if (!isMapLoaded) {
                isMapLoaded = true;
                mapFragment = new SupportMapFragment();
                getActivity().getSupportFragmentManager().beginTransaction().add(R.id.google_map_fragment, mapFragment).commit();
                mapFragment.getMapAsync(GoogleMapFragment.this);
                if (pendingFlag) {
                    markInitialLocation();
                }
            }
        }
    };

    public GoogleMapFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to initialize a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment GoogleMapFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static GoogleMapFragment newInstance() {
        GoogleMapFragment fragment = new GoogleMapFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.chat_window_google_map_fragment, null);

        handler = new Handler();

        int[][] states = new int[][]{
                new int[]{android.R.attr.state_pressed}, // enabled
                new int[]{android.R.attr.state_selected}, // unchecked
                new int[]{}
        };

        int[] colors = new int[]{
                getResources().getColor(R.color.pbx_color),
                getResources().getColor(R.color.pbx_color),
                Color.BLACK
        };

        ColorStateList ims_options_selector = new ColorStateList(states, colors);

        sendLocation = view.findViewById(R.id.imageButtonImageSend);
        Drawable normalDrawable = ContextCompat.getDrawable(getActivity(), R.drawable.btn_send_inactive_128);
        Drawable wrapDrawable = DrawableCompat.wrap(normalDrawable);
        DrawableCompat.setTintList(wrapDrawable, ims_options_selector);
        sendLocation.setImageDrawable(wrapDrawable);

        getCurrentLocation = view.findViewById(R.id.getCurrentLocation);
        contentView = view.findViewById(R.id.content_view);
        askPermissionView = view.findViewById(R.id.ask_permission_view);
        Button askPermissionButton = view.findViewById(R.id.accept_button);

        sendLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (latestLatLng != null) {
                    Sender.getAccess().sendLocation(latestLatLng);
                    if (getActivity() instanceof Controllable) {
                        ((Controllable) getActivity()).onControlRequest(Controllable.RequestType.HideBottomFragments);
                    }
                } else {
                    I.toast(Supplier.getString(R.string.select_a_location_first));
                }
            }
        });

        getCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                markLocationOReEnableGPS();
            }
        });

        askPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforLocation(getActivity()).length > 0) {
                    Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
                    requestPermissions(PermissionUtil.getPermissionsforLocation(getActivity()), OnFragmentInteractionListener.TYPE_LOCATION);
                }
            }
        });

        isMapLoaded = false;

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforLocation(getActivity()).length > 0) {
            contentView.setVisibility(View.GONE);
            askPermissionView.setVisibility(View.VISIBLE);
        } else {
            contentView.setVisibility(View.VISIBLE);
            askPermissionView.setVisibility(View.GONE);
            handler.post(mapLoader);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        isMapLoaded = false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == OnFragmentInteractionListener.TYPE_LOCATION) {
            Log.i("StartupPermissions", "Received response for required permissions request.");
            if (PermissionUtil.verifyPermissions(grantResults)) {
                Log.i("StartupPermissions", "ALL required permissions have been granted, starting DialerService.");
                contentView.setVisibility(View.VISIBLE);
                askPermissionView.setVisibility(View.GONE);
                handler.post(mapLoader);
            } else {
                Log.i("StartupPermissions", "Permissions were NOT granted. Showing exit dialog");
                contentView.setVisibility(View.GONE);
                askPermissionView.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 23)
                    showExitOrGrantPermissionAlert();
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void showExitOrGrantPermissionAlert() {
        try {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage("You did not grant required permissions. You can grant them from application settings.");
            bld.setNegativeButton("Cancel", null);
            bld.setPositiveButton("App settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getActivity().getPackageName(), null));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    dialog.dismiss();
                }
            });
            bld.setCancelable(false);
            bld.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void markInitialLocation() {
        MyLocationProvider.LocationResult locationResult = new MyLocationProvider.LocationResult() {
            @Override
            public void gotLocation(final Location location) {
                if (getActivity() != null) {
                    if (location != null) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                LatLng myLoc = new LatLng(location.getLatitude(), location.getLongitude());
                                latestLatLng = myLoc;
                                mMap.clear();
                                mMap.addMarker(new MarkerOptions().position(myLoc).title(getString(R.string.current_location)));
                                mMap.moveCamera(CameraUpdateFactory.newLatLng(myLoc));
                                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(myLoc, 14.0f));
                            }
                        });
                    } else {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                I.toast(Supplier.getString(R.string.could_not_determine_current_location));
                            }
                        });
                    }
                }
            }
        };

        MyLocationProvider myLocation = new MyLocationProvider();
        myLocation.getLocation(getActivity(), locationResult);
    }

    public void markLocationOReEnableGPS() {
        if (isGPSEnabled()) {
            markInitialLocation();
        } else {
            new AlertDialog.Builder(getActivity())
                    .setMessage(R.string.gps_turned_off_turn_it_on)
                    .setPositiveButton(R.string.yes_button, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        }
                    })
                    .setNegativeButton(R.string.no_button, null).show();
            pendingFlag = true;
        }
    }


    @Override
    public void onDestroy() {
        try {
            if (mapFragment != null)
                getFragmentManager().beginTransaction().remove(mapFragment).commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapClickListener(this);
        markInitialLocation();
    }

    @Override
    public void onMapClick(LatLng latLng) {
        mMap.clear();
        mMap.addMarker(new MarkerOptions().position(latLng).title(getString(R.string.selected_location)));
        CameraUpdate mCameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 14.0f);
        mMap.animateCamera(mCameraUpdate);
        latestLatLng = latLng;
    }

    public boolean isGPSEnabled() {
        LocationManager locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

}
