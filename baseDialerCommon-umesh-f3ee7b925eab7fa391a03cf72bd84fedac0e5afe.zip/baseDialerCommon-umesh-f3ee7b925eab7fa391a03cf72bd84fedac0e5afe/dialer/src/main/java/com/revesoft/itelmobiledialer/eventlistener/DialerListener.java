package com.revesoft.itelmobiledialer.eventlistener;

public interface DialerListener {
     void register();

     void performOnEvent(DialerEvent event, EventData eventData);
}
