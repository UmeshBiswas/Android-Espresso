package com.revesoft.itelmobiledialer.customview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by asif on 9/14/15.
 */
public class AudioRecordVisualizerView extends View {

    int factor =  0;
    ArrayList<Double> yList = new ArrayList<>();
    Paint paint;

    class Pt{

        double x, y;

        Pt(double _x, double _y)
        {
            x = _x;
            y = _y;
        }
    }

    public AudioRecordVisualizerView(Context context)
    {
        super(context);
        init();
    }

    public AudioRecordVisualizerView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        init();
    }

    public AudioRecordVisualizerView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
        init();
    }

    private void init()
    {
        calculateFunctionValue();
        paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(3);
        paint.setStyle(Paint.Style.STROKE);
    }

    private void calculateFunctionValue() {
        for(double i = 0 ; i<6; i= i+0.025)
        {
            yList.add(graphFunction(i));
        }
    }

    private double graphFunction(double x)
    {
        double evalue = Math.exp(-x);
        double cosvalue = Math.cos(4*Math.PI * x);
        return evalue * cosvalue;
    }

    public void setFactor(int f)
    {
        this.factor = -f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if(factor==0)
        {
            Path path = new Path();
            path.lineTo(getMeasuredWidth()-1,0);
            canvas.translate(0, getMeasuredHeight() / 2F);
            canvas.drawPath(path, paint);
            return;
        }
        ArrayList<Pt> pointList = new ArrayList<Pt>();
        int gap = 1;
        int width = getMeasuredWidth();
        int halfWidth = width/2;
        double x = halfWidth-(yList.size() * gap);
        for(int i = yList.size()-1 ; i >=0; i--)
        {
            Pt pt = new Pt(x, (factor * yList.get(i)) );
            pointList.add(pt);
            x= x+gap;
        }
        for(int i = 0 ; i < yList.size(); i++)
        {
            Pt pt = new Pt(x, (factor * yList.get(i)) );
            pointList.add(pt);
            x= x+gap;
        }

        Path mPath = new Path();
        mPath.quadTo(0,0, (int)pointList.get(0).x, (int) pointList.get(0).y);
        for(int i = 0 ; i < pointList.size()-1;i++)
        {
            mPath.quadTo((int)pointList.get(i).x,
                    (int)pointList.get(i).y,
                    (int)pointList.get(i+1).x,
                    (int)pointList.get(i+1).y);
        }
        mPath.quadTo((int) pointList.get(pointList.size() - 1).x, (int) pointList.get(pointList.size() - 1).y, getMeasuredWidth()-1, (int) pointList.get(pointList.size() - 1).y);
        canvas.translate(0, getMeasuredHeight() / 2F);
        canvas.drawPath(mPath, paint);
    }
}
