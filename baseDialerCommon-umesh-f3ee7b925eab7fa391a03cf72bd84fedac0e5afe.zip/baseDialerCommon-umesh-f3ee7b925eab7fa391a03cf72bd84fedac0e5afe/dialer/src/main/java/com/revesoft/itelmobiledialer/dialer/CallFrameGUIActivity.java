package com.revesoft.itelmobiledialer.dialer;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.Display;
import android.view.GestureDetector;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.chat.cameraAndImage.CameraUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.ChatWindowActivity;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickerActivity;
import com.revesoft.itelmobiledialer.contact.picker.ContactSelectiontype;
import com.revesoft.itelmobiledialer.customview.NumberView;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.media.MediaDataRecv;
import com.revesoft.itelmobiledialer.notification.custom_notification.IncomingCallNotification;
import com.revesoft.itelmobiledialer.notification.custom_notification.RunningCallNotification;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.signalling.sipUtil.ApplicationState;
import com.revesoft.itelmobiledialer.signalling.video.CodecParameters;
import com.revesoft.itelmobiledialer.signalling.video.VideoConstants;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.Country;
import com.revesoft.itelmobiledialer.util.CountryInfoProvider;
import com.revesoft.itelmobiledialer.util.DTMFTones;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.video.VideoParameters;
import com.revesoft.itelmobiledialer.video.encoding.Encoder;
import com.revesoft.itelmobiledialer.video.encoding.FFMpegH264Encoder;
import com.revesoft.itelmobiledialer.video.encoding.H263Encoder;
import com.revesoft.itelmobiledialer.video.encoding.H264Encoder;
import com.revesoft.itelmobiledialer.video.encoding.H264ParameterSets;
import com.revesoft.itelmobiledialer.video.player.FFMPEGBasedVideoPlayer;
import com.revesoft.itelmobiledialer.video.player.MediaCodecBasedVideoPlayer;
import com.revesoft.itelmobiledialer.video.player.RenderingSurface;
import com.revesoft.itelmobiledialer.video.player.VideoPlayer;
import com.revesoft.itelmobiledialer.video.receiver.H263PlusVideoReceiver;
import com.revesoft.itelmobiledialer.video.receiver.H263VideoReceiver;
import com.revesoft.itelmobiledialer.video.receiver.H264VideoReceiver;
import com.revesoft.itelmobiledialer.video.receiver.RtpReceiver;
import com.revesoft.itelmobiledialer.video.utility.ColorFormatAndRotationHandler;
import com.revesoft.material.R;

import java.io.IOException;
import java.net.SocketException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import androidx.cardview.widget.CardView;
import androidx.core.view.GestureDetectorCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static android.hardware.Sensor.TYPE_PROXIMITY;
import static android.hardware.SensorManager.SENSOR_DELAY_NORMAL;
import static android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP;
import static android.os.PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK;
import static android.os.PowerManager.SCREEN_DIM_WAKE_LOCK;
import static com.revesoft.itelmobiledialer.util.Constants.BROADCAST_MESSAGE_CALL_CONNECTED_FROM;
import static com.revesoft.itelmobiledialer.util.Constants.CALL_CONNECTED_FROM_ACCEPT;

@SuppressLint("NewApi")
public class CallFrameGUIActivity extends BaseActivity implements SensorEventListener {
    public static boolean isOnPause;
    //    private ImageView drawerHandle;
//    private MultiDirectionSlidingDrawer mDrawer;
    private Handler handler;
    private ImageView muteButton;
    //    private ImageView bluetoothButton;
    private ImageView speakerButton;
    private ImageView recordButton;
    private ImageView callTransferButton;
    //    private ImageView soundButton;
    private ImageView keypadButton;
    private ImageView holdButton;
    private ImageView startMessageButton;
    private ImageView btnDismissDIalpad;
    private LinearLayout popupDialpad;
    private boolean muteFlag = false;
    private boolean speakerFlag = false;
    private boolean recordFlag = false;
    private boolean holdFlag = false;
    private boolean callTransferFlag = false;

    //    private LinearLayout muteButtonBack;
//    private LinearLayout bluetoothButtonBack;
//    private LinearLayout speakerButtonBack;
//    private LinearLayout soundButtonBack;
    private SharedPreferences preferences;
    private Handler callQualityHandler;

    //    public static Activity activity = null;
    private TextView callTimer;
    TextView tvCallStatus;
    private TextView enteredNumber;
    private TextView calledCountryISO;
    private TextView calledNumber;
    //    private TextView calledName;
//    private TextView callStatus;
//    private TextView callRateTView;
    private TextView packageTView;
    private LinearLayout endCallButtonSpace;
    private View acceptDeclineButtonSpace;
    private LinearLayout qualityBar;
    private LinearLayout secondLineButtons;
    private RelativeLayout allButtonHolder, major_buttons;
    private TextView slide_message;
    private LinearLayout callerNameHolder;
    private ImageView ivChat;
    private TextView tvMicOnOff;
    private TextView tvRecord;
    private TextView tvSlideMessage;
    private TextView tvCallInfoText;
    WakeLock screenLock, proximityLock;
    private SensorManager sensorManager;
    private Sensor proximitySensor;
    private ImageView picture;
    private TextView linkQuality;
    //    private ImageView linkQualityImage;
    private AudioManager audioManager = null;
    DTMFTones tones;
    private String number = "";
    private final boolean DEBUG = false;
    /**
     * ***** Bluetooth Headset part ********
     */
    BluetoothAdapter bluetoothAdapter = null;
    private boolean bluetoothSettingsFlag = false;
    private BluetoothProfile.ServiceListener mProfileListener;
    private BluetoothHeadset mBluetoothHeadset;
    private int connectedHeadsetCount = 0;
    private BluetoothDevice headsetDevice = null;
    AudioManager localAudioManager;
    Timer timer;

//    private RelativeLayout callframeback = null;
//    private TextView callType = null;

    /**
     * ******* End *********
     */

    public static volatile boolean SPEAKER_FLAG;
    public static boolean isActivityActive = false;
    private boolean returnFromCrash = false;
    private boolean isIncomingCall = false;
    static final int BLUETOOTH_NOT_CONNECTED = 0;
    static final int A2DP_CONNECTED = 1;
    static final int SCO_CONNECTED = 2;
    int blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
    private int CALL_TRANSFER_REQUEST = 123;

    /**
     * video start
     */
    ImageView audioVideoSwitchButton;
    LinearLayout audioVideoSwitchButtonContainer;
    /**
     * video start
     */
    private boolean wasSpeakerOnBeforeHeadsetPluggedIn = false;
    HeadSetReceiver headsetReceiver;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("CallFrameGUIActivity", "CallFrameGUIActivity onCreate");
        Bundle bundle = getIntent().getExtras();
        checkIfReturnFromCrash(bundle);
        setContentView(R.layout.call_progress_layout);
        SPEAKER_FLAG = false;
        wasSpeakerOnBeforeHeadsetPluggedIn = SPEAKER_FLAG;
        isActivityActive = true;
        callQualityHandler = new Handler(Looper.getMainLooper());
//        callframeback = (RelativeLayout) findViewById(R.id.callframe);
//        callType = (TextView) findViewById(R.id.call_type);
//
//        if(!SIPProvider.isPaidCall){
//            callframeback.setBackgroundResource(R.drawable.background_call_page);
//            callType.setVisibility(View.INVISIBLE);
//        } else {
//            callframeback.setBackgroundResource(R.drawable.background_out_call_page);
//            callType.setVisibility(View.VISIBLE);
//        }
        preferences = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
        initViews();
        initObjects();
//        drawVisibleButtons();
//        activity = this;
        registerReceivers();
        setWakeLock();
        checkIfFromDialog();

//        TODO: test omit for customization
        acquireLocksInCall();
        endCallInitiated = false;
//        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
//        audioManager.getStreamVolume();
        handleBluetooth();
        initCameraViews();
    }

    private void initCameraViews() {
        videoPlayerContainer = findViewById(R.id.videoPlayerContainer);

        initialCameraPreviewContainer = findViewById(R.id.initialCameraPreviewContainer);
        initialCameraPreview = findViewById(R.id.initialCameraPreview);
        initialCameraPreview.getHolder().addCallback(surfaceHolderCallBack);
        bottomViewGroupContainer = findViewById(R.id.bottomViewGroup);
        topViewGroupContainer = findViewById(R.id.topViewGroupCard);
//        callFrameContainer = (LinearLayout) findViewById(R.id.call_frame_container);
        cameraSwitchButton = findViewById(R.id.camera_switch_button);
        cameraSwitchButtonContainer = findViewById(R.id.video_camera_switch_container);

        cameraSwitchButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                VideoParameters.CURRENT_DISPLAY_ROTATION = getWindowManager().getDefaultDisplay().getRotation();
                camera.switchCam(videoWidth, videoHeight, VideoParameters.CURRENT_DISPLAY_ROTATION);
            }
        });

        playerSurface = findViewById(R.id.videoPlayer);
        preview = findViewById(R.id.cameraPreview);
        try {
            preview.setZOrderMediaOverlay(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        preview.setVisibility(View.INVISIBLE);
        playerSurface.setVisibility(View.INVISIBLE);

        gestureDetector = new GestureDetectorCompat(this,
                new MySingleTapGestureListener());

        videoPlayerContainer = findViewById(R.id.videoPlayerContainer);

        boolean isVideoCall = getIntent().hasExtra(Constants.IS_VIDEO_CALL);
        String type = this.getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_FROM_DIALER);
        if (getIntent() != null) {
            if (isVideoCall && type != null) {
                if (type.equals(Constants.TYPE_OUTGOING)) {
                    initialCameraPreviewContainer.setVisibility(View.VISIBLE);
                    picture.setVisibility(View.GONE);
                    videoPlayerContainer.setVisibility(View.INVISIBLE);
                    VideoParameters.sendVideoData = true;
                } else {
                    initialCameraPreviewContainer.setVisibility(View.GONE);
                    videoPlayerContainer.setVisibility(View.VISIBLE);
                    VideoParameters.sendVideoData = true;
                }
                callStartedAsVideoCall = true;
            } else {
                initialCameraPreviewContainer.setVisibility(View.GONE);
                videoPlayerContainer.setVisibility(View.INVISIBLE);
                callStartedAsVideoCall = false;
            }
        }

        IntentUtil.sendCurrentStatus(this);
    }

    private void checkIfFromDialog() {
        boolean bb = getIntent().getBooleanExtra("fromDialogue", false);
        if (bb)
            accept();
    }

    private void setWakeLock() {
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        try {
            if (Build.VERSION.SDK_INT >= 21 && powerManager.isWakeLockLevelSupported(PROXIMITY_SCREEN_OFF_WAKE_LOCK))
                screenLock = powerManager.newWakeLock(PROXIMITY_SCREEN_OFF_WAKE_LOCK, "CallFrameGUIACtivity");
            else
                screenLock = powerManager.newWakeLock(SCREEN_DIM_WAKE_LOCK | ACQUIRE_CAUSES_WAKEUP, "CallFrameGUIACtivity");
        } catch (Exception e) {
            if (DEBUG)
                Log.e("CallFrameGUIACtivity", "ScreenLock: ", e);
        }
    }

    private void registerReceivers() {
        LocalBroadcastManager.getInstance(this).registerReceiver(
                mMessageReceiver,
                new IntentFilter(Constants.INTENT_FROM_DIALER));
        LocalBroadcastManager.getInstance(this).registerReceiver(
                mCallSwitchReceiver,
                new IntentFilter(Constants.CALL_SWITCH_ACTION));
        registerBluetoothConnectionStateReceiver();

        LocalBroadcastManager.getInstance(this).registerReceiver(
                openFFMPEGBroadcastReceiver,
                new IntentFilter(Constants.INTENT_OPEN_FFMPEG_DECODER));
        LocalBroadcastManager.getInstance(this).registerReceiver(
                openFFMPEGBroadcastReceiver,
                new IntentFilter(Constants.INTENT_OPEN_FFMPEG_ENCODER));
        LocalBroadcastManager.getInstance(this).registerReceiver(
                openFFMPEGBroadcastReceiver,
                new IntentFilter(Constants.INTENT_OPEN_MEDIA_CODEC_DECODER));
        LocalBroadcastManager.getInstance(this).registerReceiver(resizeVideoPlayer,
                new IntentFilter(Constants.INTENT_RESIZE_VIDEO_PLAYER));


    }

    private void initObjects() {
//        MissedCallNotification.cancelAll();
        tones = new DTMFTones();
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        proximitySensor = sensorManager.getDefaultSensor(TYPE_PROXIMITY);
        headsetReceiver = new HeadSetReceiver();

    }

    private void checkIfReturnFromCrash(Bundle bundle) {
        if (bundle != null) {
            if (bundle.containsKey(IncomingCallNotification.INTENT_TYPE_INCOMING_CALL) ||
                    bundle.containsKey(RunningCallNotification.INTENT_TYPE_RUNNING_CALL)) {
                returnFromCrash = true;
                finish();
                return;
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i("CallFrameGuiActivity", "CallFrameGUIActivity onNewIntent");
        Bundle b = intent.getExtras();
        if (b != null) {
            if (b.containsKey(IncomingCallNotification.INTENT_TYPE_INCOMING_CALL)) {
                String type = b.getString(IncomingCallNotification.INTENT_TYPE_INCOMING_CALL);
                if (type != null && type.equals(IncomingCallNotification.ACCEPT_VALUE)) {
                    accept();
                } else {
                    reject();
                }
            } else if (b.containsKey(RunningCallNotification.INTENT_TYPE_RUNNING_CALL)) {
                String type = b.getString(RunningCallNotification.INTENT_TYPE_RUNNING_CALL);
                if (type != null && type.equals(IncomingCallNotification.ACCEPT_VALUE)) {
                    onResume();
                } else {
                    reject();
                }
            }
        }
        audioVideoSwitchButtonContainer.setEnabled(true);
        audioVideoSwitchButton.setEnabled(true);
    }

    private void initViews() {
        handler = new Handler();
        qualityBar = findViewById(R.id.quality_bar);
        qualityBar.setVisibility(View.INVISIBLE);
        linkQuality = findViewById(R.id.link_quality);
        secondLineButtons = findViewById(R.id.secondLineButtons);
        tvCallInfoText = findViewById(R.id.call_info_text);
//        linkQualityImage = (ImageView) findViewById(R.id.link_quality_image);

//        findViewById(R.id.callOptionsInactive).setVisibility(View.VISIBLE);
//        findViewById(R.id.callOptionsActive).setVisibility(View.GONE);

//        mDrawer = (MultiDirectionSlidingDrawer) findViewById(R.id.dialpad_drawer);
//        mDrawer.setVisibility(View.VISIBLE);
//        drawerHandle = (ImageView) findViewById(R.id.handle);
//
//        mDrawer.setOnDrawerOpenListener(new MultiDirectionSlidingDrawer.OnDrawerOpenListener() {
//            public void onDrawerOpened() {
//                drawerHandle.setImageResource(R.drawable.ic_callframe_dtmfpad_close);
//            }
//        });
//        mDrawer.setOnDrawerCloseListener(new MultiDirectionSlidingDrawer.OnDrawerCloseListener() {
//            public void onDrawerClosed() {
//                drawerHandle.setImageResource(android.R.color.transparent);
//            }
//        });
        handleKeyPad();

        endCallButtonSpace = findViewById(R.id.endcall_button_space);
        acceptDeclineButtonSpace = findViewById(R.id.accept_decline_button_space);

//        callStatus = (TextView) findViewById(R.id.statustview);
        callTimer = findViewById(R.id.timertview);
        allButtonHolder = findViewById(R.id.all_button_holder);
        slide_message = findViewById(R.id.slide_message);
        callTimer.setVisibility(View.GONE);
        allButtonHolder.setVisibility(View.GONE);
        slide_message.setVisibility(View.VISIBLE);
        tvCallStatus = findViewById(R.id.tvCallStatus);
        calledCountryISO = findViewById(R.id.tvCountryName);

        calledNumber = findViewById(R.id.numtview);
//        callRateTView = (TextView) findViewById(R.id.ratetview);
//        callRateTView.setVisibility(View.GONE);
//        packageTView = (TextView) findViewById(R.id.packagetview);
//        packageTView.setVisibility(View.GONE);
//        calledName = (TextView) findViewById(R.id.nametview);
        picture = findViewById(R.id.contact_image);

        keypadButton = findViewById(R.id.keypad_button);

//        holdButton = (ImageView) findViewById(R.id.hold_button);
//        holdButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(holdFlag) {
//                    holdFlag = false;
//                    callHoldAction(holdFlag);
//                    holdButton.setBackgroundColor(getResources().getColor(android.R.color.transparent));
//                } else {
//                    holdFlag = true;
//                    callHoldAction(holdFlag);
//                    holdButton.setBackgroundResource(R.drawable.btn_rec_pressed);
//                }
//            }
//        });

        muteButton = findViewById(R.id.mute_button);

//        bluetoothButton = (ImageView) findViewById(R.id.bluetooth_button);
//        bluetoothButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                bluetoothAction(true);
//            }
//        });

        speakerButton = findViewById(R.id.speaker_button);
        recordButton = findViewById(R.id.record_button);
        callTransferButton = findViewById(R.id.btn_call_transfer);

//        soundButton = (ImageView) findViewById(R.id.sound_button);
//        soundButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                soundAction(true);
//            }
//        });

//        muteButtonBack = (LinearLayout) findViewById(R.id.mute_button_back);
//        bluetoothButtonBack = (LinearLayout) findViewById(R.id.bluetooth_button_back);
//        speakerButtonBack = (LinearLayout) findViewById(R.id.speaker_button_back);
//        soundButtonBack = (LinearLayout) findViewById(R.id.sound_button_back);

//        startMessageButton = (ImageView) findViewById(R.id.btn_start_message);
//        startMessageButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(CallFrameGUIActivity.this, MessageActivity.class);
//                i.putExtra(MessageActivity.EXTRA_PHONE_NUMBER, tvNumber);
//                startActivity(i);
//            }
//        });

        audioVideoSwitchButton = findViewById(R.id.video_switch_button);
        audioVideoSwitchButton.setEnabled(false);
        audioVideoSwitchButtonContainer = findViewById(R.id.video_switch_button_container);
        audioVideoSwitchButtonContainer.setEnabled(false);
        audioVideoSwitchButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SIPProvider.isVideoCall("")) {
                    if (!VideoParameters.sendVideoData) {
                        VideoParameters.sendVideoData = true;
                        sendIntentMessageToDialerForVideoStatus(number, 1);
                    } else {
                        VideoParameters.sendVideoData = false;
                        sendIntentMessageToDialerForVideoStatus(number, 0);
                    }
                    switchVideoPreviewStatus(VideoParameters.sendVideoData);
                } else {
                    sendIntentMessageToDialer("callswitch", number);
                    showVideoPreview(true);
                }
            }
        });

        //---------------------------------//

        major_buttons = findViewById(R.id.major_buttons);
        callerNameHolder = findViewById(R.id.caller_name_holder);
        ivChat = findViewById(R.id.chat_icon);
        tvSlideMessage = findViewById(R.id.slide_message);
        tvSlideMessage.setVisibility(View.GONE);
        callerNameHolder.setAlpha((float) 0.8);
        allButtonHolder.setAlpha((float) 0.8);
        localAudioManager = (AudioManager) CallFrameGUIActivity.this.getSystemService(AUDIO_SERVICE);
        tvMicOnOff = findViewById(R.id.tvMicOnOff);
        tvRecord = findViewById(R.id.tvRecord);
        acceptDeclineButtonSpace.setVisibility(View.GONE);
        endCallButtonSpace.setVisibility(View.VISIBLE);


        boolean isVideoCall = getIntent().hasExtra(Constants.IS_VIDEO_CALL);

        if (isVideoCall) {
            tvCallInfoText.setText(R.string.salamVideoCall);
        } else {
            tvCallInfoText.setText(R.string.voice_call_salam);
        }

        String type = this.getIntent().getStringExtra(Constants.BROADCAST_MESSAGE_FROM_DIALER);
        if (type == null) ;
        else if (type.compareTo(Constants.TYPE_INCOMING) == 0) {
            isIncomingCall = true;
            tvCallStatus.setText(R.string.incoming_call);
            incomingGUISetup();
//            callRateTView.setVisibility(View.VISIBLE);
//            callRateTView.setText("Free call");
        } else if (type.compareTo(Constants.TYPE_OUTGOING) == 0) {
            tvCallStatus.setText(R.string.calling);
            outgoingGUISetup();
        } else if (type.compareTo(Constants.TYPE_CONNECTED) == 0) {
            isIncomingCall = getIntent().getBooleanExtra(Constants.IS_INCOMING_CALL, false);
            connectedGUISetup();
        }
        number = this.getIntent().getStringExtra(
                Constants.BROADCAST_MESSAGE_NUMBER);
        if (number == null) {
            finish();
            return;
        }
        calledNumber.setText(number);
        if (number != null) {
            String name = ContactEngine.getContactNamefromNumber(this, number.replaceAll("\\D", ""));
            if (name == null)
                name = number;
            calledNumber.setText(name);
        }
        Bitmap profilePicture = ProfilePictureDataProvider.getProfilePictureAsBitmap(this, number);
        if (profilePicture == null) {
            profilePicture = ContactEngine.loadContactPhotoHighResolution(this, number);
        }
        if (profilePicture == null) {
            picture.setImageDrawable(getResources().getDrawable(R.drawable.salam_icon));
            picture.setBackgroundColor(getResources().getColor(R.color.salam_icon_background));
        } else {
            picture.setImageBitmap(profilePicture);
        }

        String countryCode = Util.getUserCountryCode(number);
        Country country = CountryInfoProvider.countryDialingCodeToCountry.get(countryCode);

        if (country != null) {
            calledCountryISO.setVisibility(View.VISIBLE);
            calledCountryISO.setText(country.isoCode.toUpperCase());
        } else {
            calledCountryISO.setVisibility(View.GONE);
        }
        calledCountryISO.setVisibility(View.GONE);
//		Bitmap b = ProfilePicUploadDownloadHelper.getContactThumbnailImage(
//				CallFrameGUIActivity.this, tvNumber, 96, 96, true);

        if (profilePicture != null)
            picture.setImageBitmap(profilePicture);
    }


    public void handleMute(View view) {
        if (muteFlag) {
            muteFlag = false;
            muteAction(muteFlag);
            muteButton.setImageResource(R.drawable.ic_call_window_soundless);
            tvMicOnOff.setText(getString(R.string.mikeOff));
            muteButton.invalidate();
        } else {
            muteFlag = true;
            muteAction(muteFlag);
            muteButton.setImageResource(R.drawable.ic_call_window_soundless_active);
            tvMicOnOff.setText(getString(R.string.mikeOn));
            muteButton.invalidate();
        }
    }

    public void handleSpeaker(View view) {
        //Do nothing if headset connected
        if (localAudioManager.isWiredHeadsetOn())
            return;
//        if(localAudioManager.isBluetoothA2dpOn() || localAudioManager.isBluetoothScoOn())
//            return;
        if (speakerFlag) {
            speakerFlag = false;
            Toast.makeText(this, R.string.speaker_off, Toast.LENGTH_SHORT).show();
            speakerAction(speakerFlag);
            wasSpeakerOnBeforeHeadsetPluggedIn = false;
        } else {
            speakerFlag = true;
            Toast.makeText(this, R.string.speaker_on, Toast.LENGTH_SHORT).show();
            speakerAction(speakerFlag);
            wasSpeakerOnBeforeHeadsetPluggedIn = true;
        }
    }

    public void handleCallTransfer(View view) {
        I.log("handleCallTransfer, callTransferFlag is " + callTransferFlag);
        if (callTransferFlag) {
            callTransferButton.setImageResource(R.drawable.ic_call_window_redirects_disabled);
//            Intent intent = new Intent(CallFrameGUIActivity.this, ContactPickerInCallProgressingActivity.class);
//            intent.putExtra("multiple_selection", false);
//            intent.putExtra("call_transfer", true);
//            startActivityForResult(intent, CALL_TRANSFER_REQUEST);
            ContactPickerActivity.startPicker(CallFrameGUIActivity.this, ContactType.ALL, ContactSelectiontype.SINGLE_SELECT, (contacts, contactListItems) -> {
                if (contacts.size() == 1) {
                    callTransferButton.setAlpha((float) 1.0);
                    IntentUtil.sendCallTransferRequest(CallFrameGUIActivity.this, contacts.get(0));
                } else {
                    callTransferFlag = false;
                    callTransferButton.setAlpha((float) 0.4);

                }
            });
        }
    }

    public void handleCallRecord(View view) {
        if (recordFlag) {
            recordFlag = false;
            callRecordAction(recordFlag);
            recordButton.setImageResource(R.drawable.ic_call_window_recording);
            tvRecord.setText(getString(R.string.record));
        } else {
            recordFlag = true;
            callRecordAction(recordFlag);
            recordButton.setImageResource(R.drawable.ic_call_window_recording_active);
            tvRecord.setText(getString(R.string.recording));
        }
    }

    public void wip(View view) {
        switch (view.getId()) {
            case R.id.video_switch_button_container:
                audioVideoSwitchButton.performClick();
                break;
            default:
                Util.workInProgress();
                break;
        }
    }

    LinearLayout keyPad;
    NumberView nvDigits;
    private static final long KEYPAD_ANIMATION_TIME = 200;
    boolean isShowingAnimation = false;

    public void showKeyPad(View view) {
        isShowingAnimation = true;
        keyPad.setVisibility(View.VISIBLE);
        keyPad.animate().scaleY(1).scaleX(1).setDuration(KEYPAD_ANIMATION_TIME);
    }

    private void hideKeyPad() {
        isShowingAnimation = false;
        keyPad.animate().scaleY(0).scaleX(0).setDuration(KEYPAD_ANIMATION_TIME).setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (!isShowingAnimation) {
                    keyPad.setVisibility(View.GONE);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }


    ImageView ivCalleePictureInDTMF;

    private void handleKeyPad() {
        ivCalleePictureInDTMF = findViewById(R.id.ivCalleePictureInDTMF);
        keyPad = findViewById(R.id.keyPad);
        nvDigits = findViewById(R.id.nvDigits);
        nvDigits.getBackground().mutate().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        nvDigits.requestFocus();
        nvDigits.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        setupKeys();
        keyPad.setScaleY(0);
        keyPad.setScaleX(0);
        LinearLayout llCloseKeyPad = findViewById(R.id.llCloseKeyPad);
        llCloseKeyPad.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyPad();
            }
        });
        keyPad.setVisibility(View.GONE);
        ivCalleePictureInDTMF.post(new Runnable() {
            @Override
            public void run() {
                String profilePicturePath = ProfilePictureDataProvider.getProfilePicturePath(CallFrameGUIActivity.this, number);
                if (profilePicturePath == null) {
                    profilePicturePath = CommonData.contactNumberToContactImageUri.get(number);
                }
                ImageUtil.setImageButDefaultOnException(CallFrameGUIActivity.this, profilePicturePath, ivCalleePictureInDTMF, R.drawable.person_bg);
            }
        });
    }

    private void setupKeys() {
        TableLayout tableLayout = findViewById(R.id.tableLayout);
        int index = 1;
        for (int i = 0; i < tableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            for (int j = 0; j < row.getChildCount(); j++) {
                View btnView = row.getChildAt(j);
                setDialButtonView(index, btnView);
                index++;
            }
        }
    }

    public void setDialButtonView(final int index, View btnView) {
        Log.d("setDialButtonView", "index: " + index);
        btnView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String digit = "";
                int tone = 0;
                if (index <= 9) {
                    digit = Integer.toString(index);
                    tone = index;
                } else if (index == 10) {
                    digit = "*";
                    tone = 10;
                } else if (index == 11) {
                    digit = "0";
                    tone = 0;
                } else if (index == 12) {
                    digit = "#";
                    tone = 11;
                }
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, digit);
                nvDigits.insertDigit(digit);
                tones.playTone(tone);
            }
        });
        TextView textNumber = btnView.findViewById(R.id.textNumber);
        TextView textLetter = btnView.findViewById(R.id.textLetter);
        switch (index) {
            case 1:
                textNumber.setText("1");
                textLetter.setText(getString(R.string.sixSpace));
                break;
            case 2:
                textNumber.setText("2");
                textLetter.setText("ABC");
                break;
            case 3:
                textNumber.setText("3");
                textLetter.setText("DEF\u0020");
                break;
            case 4:
                textNumber.setText("4");
                textLetter.setText("GHI\u0020");
                break;
            case 5:
                textNumber.setText("5");
                textLetter.setText("JKL");
                break;
            case 6:
                textNumber.setText("6");
                textLetter.setText("MNO\u0020");
                break;
            case 7:
                textNumber.setText("7");
                textLetter.setText("PQRS");
                break;
            case 8:
                textNumber.setText("8");
                textLetter.setText("TUV");
                break;
            case 9:
                textNumber.setText("9");
                textLetter.setText("WXYZ");
                break;
            case 10:
                textNumber.setText("*");
                textLetter.setText(getString(R.string.sixSpace));
                break;
            case 11:
                textNumber.setText("0");
                textLetter.setText("\u0020+");
                textLetter.setTextColor(Color.WHITE);
                break;
            case 12:
                textNumber.setText("#");
                textLetter.setText(getString(R.string.sixSpace));
                break;
        }
    }

    private void muteAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.mute_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_MUTE);
        } else {
            Toast.makeText(this, R.string.mute_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_MUTE);
        }
    }

    // private void bluetoothAction(boolean isChecked) {
    // if (isChecked) {
    // Toast.makeText(this, "bluetooth on", 3000).show();
    // sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
    // Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
    // } else {
    // Toast.makeText(this, "bluetooth off", 3000).show();
    // sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
    // Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);
    // }
    // }

    private void callHoldAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.call_paused, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_CALL_PAUSE);
        } else {
            Toast.makeText(this, R.string.call_resumed, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_CALL_PAUSE);
        }
    }

    private void speakerAction(boolean isChecked) {
        if (isChecked) {
//            Toast.makeText(this, R.string.speaker_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_SPEAKER);
            SPEAKER_FLAG = true;
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker_active);
            Log.d("Speaker", "speaker on request sent");
        } else {
//            Toast.makeText(this, R.string.speaker_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_SPEAKER);
            SPEAKER_FLAG = false;
            speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
            Log.d("Speaker", "speaker off request sent");

        }
    }

    private void callRecordAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.call_record_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.CALL_RECORDING_IMMEDIATE_START_ACTION, "");
            SPEAKER_FLAG = true;

        } else {
            Toast.makeText(this, R.string.call_record_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.CALL_RECORDING_IMMEDIATE_STOP_ACTION, "");
            SPEAKER_FLAG = false;


        }
    }

    private void soundAction(boolean isChecked) {
        if (isChecked) {
            Toast.makeText(this, R.string.sound_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_STOP_SOUND);
        } else {
            Toast.makeText(this, R.string.sound_on, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                    Constants.BROADCAST_MESSAGE_START_SOUND);
        }
    }

    public void onClick(View v) {
        Log.w("DTMF", "KEY PRESSED: id: " + v.getId());
        switch (v.getId()) {
            case R.id.cp_zero:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "0");
                enteredNumber.setText(enteredNumber.getText().toString() + "0");
                tones.playTone(0);
                break;
            case R.id.cp_one:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "1");
                enteredNumber.setText(enteredNumber.getText().toString() + "1");
                tones.playTone(1);
                break;
            case R.id.cp_two:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "2");
                enteredNumber.setText(enteredNumber.getText().toString() + "2");
                tones.playTone(2);
                break;
            case R.id.cp_three:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "3");
                enteredNumber.setText(enteredNumber.getText().toString() + "3");
                tones.playTone(3);
                break;
            case R.id.cp_four:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "4");
                enteredNumber.setText(enteredNumber.getText().toString() + "4");
                tones.playTone(4);
                break;
            case R.id.cp_five:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "5");
                enteredNumber.setText(enteredNumber.getText().toString() + "5");
                tones.playTone(5);
                break;
            case R.id.cp_six:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "6");
                enteredNumber.setText(enteredNumber.getText().toString() + "6");
                tones.playTone(6);
                break;
            case R.id.cp_seven:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "7");
                enteredNumber.setText(enteredNumber.getText().toString() + "7");
                tones.playTone(7);
                break;
            case R.id.cp_eight:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "8");
                enteredNumber.setText(enteredNumber.getText().toString() + "8");
                tones.playTone(8);
                break;
            case R.id.cp_nine:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "9");
                enteredNumber.setText(enteredNumber.getText().toString() + "9");
                tones.playTone(9);
                break;
            case R.id.cp_star:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "*");
                enteredNumber.setText(enteredNumber.getText().toString() + "*");
                tones.playTone(10);
                break;
            case R.id.cp_hash:
                sendMessage(Constants.BROADCAST_MESSAGE_SEND_DTMF, "#");
                enteredNumber.setText(enteredNumber.getText().toString() + "#");
                tones.playTone(11);
                break;

            case R.id.endcall_button:
                reject();
                // Toast.makeText(CallFrameGUIActivity.this, "End call",
                // Toast.LENGTH_SHORT).show();
                break;
            case R.id.accept_button:
                accept();
                // Toast.makeText(CallFrameGUIActivity.this, "Accept",
                // Toast.LENGTH_SHORT).show();
                break;
            case R.id.decline_button:
                reject();
                // Toast.makeText(CallFrameGUIActivity.this, "Decline",
                // Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    protected void onResume() {

        IntentFilter filter = new IntentFilter(Intent.ACTION_HEADSET_PLUG);
        registerReceiver(headsetReceiver, filter);
        super.onResume();
        Log.i("CallFrameGUIActivity", "CallFrameGUIActivity onResume");
        isActivityActive = true;
        isOnPause = false;
        ApplicationState.activityResumed();

        /*********** bluetooth headset part **********/
        if (bluetoothSettingsFlag == true
                && Build.VERSION.SDK_INT >= 11) {
            mProfileListener = new BluetoothProfile.ServiceListener() {
                public void onServiceConnected(int profile,
                                               BluetoothProfile proxy) {
                    if (profile == BluetoothProfile.HEADSET) {
                        mBluetoothHeadset = (BluetoothHeadset) proxy;
                        Log.d("Mkhan", "Enters");

                        List<BluetoothDevice> connectedHeadsets = mBluetoothHeadset
                                .getConnectedDevices();
                        bluetoothAdapter.closeProfileProxy(
                                BluetoothProfile.HEADSET, mBluetoothHeadset);
                        Log.d("Mkhan", "Connected headset count : "
                                + connectedHeadsets.size());

                        connectedHeadsetCount = connectedHeadsets.size();

                        if (connectedHeadsetCount == 1) {
                            Toast.makeText(CallFrameGUIActivity.this,
                                    R.string.bluetooth_on,
                                    Toast.LENGTH_LONG).show();
                            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                                    Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
                        } else {
                            Toast.makeText(CallFrameGUIActivity.this,
                                    R.string.no_device_connected,
                                    Toast.LENGTH_LONG).show();
                            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                                    Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);
                        }

                    }
                }

                public void onServiceDisconnected(int profile) {
                    if (profile == BluetoothProfile.HEADSET) {
                        mBluetoothHeadset = null;
                    }
                }
            };

            /**
             * for some reason this line must be after creation of service
             * listener
             */
            bluetoothAdapter.getProfileProxy(this, mProfileListener,
                    BluetoothProfile.HEADSET);

        }
        bluetoothSettingsFlag = false;

        /************** end **********/
    }

    @Override
    protected void onPause() {
        super.onPause();
        isActivityActive = false;
        isOnPause = true;
        Log.i("CallFrameGUIActivity", "CallFrameGUIActivity onPause");
    }

    @Override
    protected void onDestroy() {
        Log.i("CallFrameGUIActivity", "CallFrameGUIActivity onDestroy");
        cancelIncomingCallNotification();
        cancelRunningCallNotification();

        if (callQualityHandler != null)
            callQualityHandler.removeCallbacks(callQualityRunnable);
        if (returnFromCrash) {
            super.onDestroy();
            return;
        }

        // Unregister since the activity is about to be closed.

        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallSwitchReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(openFFMPEGBroadcastReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(resizeVideoPlayer);
        unregisterReceiver(headsetReceiver);


        // Destroy bluetooth, speaker and mute.
//        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                Constants.BROADCAST_MESSAGE_STOP_SPEAKER);

        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                Constants.BROADCAST_MESSAGE_STOP_MUTE);

//        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
//                Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);

        releaseLocksInCall();

        try {
            if (dialogShown && statsDialog != null)
                statsDialog.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // KeyguardManager km = (KeyguardManager)
        // getSystemService(Context.KEYGUARD_SERVICE);
        // KeyguardLock keyguard = km.newKeyguardLock("MyApp");
        // keyguard.reenableKeyguard();
        unregisterReceiver(mReceiver);
        if (localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "CallFrameGUIActivity On" +
                    " Destroy: Audio Mode set to: MODE_NORMAL");
            localAudioManager.setMode(AudioManager.MODE_NORMAL);
        }

        handleBluetoothOnDestroy();
        isConnectedCall = false;
        super.onDestroy();
    }

    public void startMessaging(View view) {
        if (CommonData.subscriberPhoneNumberToLookUpKey.containsKey(number)) {
            ChatWindowActivity.start(view.getContext(), number, null, false, false, false, null);
        } else {
            ChatWindowActivity.start(view.getContext(), number, null, true, false, false, null);
        }
    }

    private void handleBluetoothOnDestroy() {
        if (blueToothConnectionMode == A2DP_CONNECTED) {
            Log.d("BluetoothTest", "CallFrameGUIActivity" +
                    ":Ondestroy(): " +
                    ": LAST STATUS: A2DP: AUDIO set mode: MODE_NORMAL");
            localAudioManager.setMode(AudioManager.MODE_NORMAL);
            blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;

        } else if (blueToothConnectionMode == SCO_CONNECTED) {
            if (localAudioManager.isBluetoothScoOn()) {
                localAudioManager.setBluetoothScoOn(false);
                localAudioManager.stopBluetoothSco();
                DialerService.isBluetoothScoRequestedToSetOn = false;
                localAudioManager.setMode(AudioManager.MODE_NORMAL);
                blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                Log.e("BluetoothTest", "CallFrameGUIActivity Stopping BlueToothSCO" +
                        ":Ondestroy(): " +
                        ": LAST STATUS: SCO : AUDIO set mode: MODE_NORMAL");
            } else {
                localAudioManager.setMode(AudioManager.MODE_NORMAL);
                blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
            }


        } else {
            blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
            Log.d("BluetoothTest", "CallFrameGUIActivity" +
                    ":Ondestroy(): " +
                    ": LAST STATUS: None");

        }
    }

    private boolean callConnected = false;
    private long callStartTime = 0;
    private long callEndTime = 0;

    private boolean isCallProgressingOrConnected = false;
    private boolean isConnectedCall = false;
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Read extra data included in the Intent
            String message = intent
                    .getStringExtra(Constants.BROADCAST_MESSAGE_DISPLAY_DURATION);
            if (message != null) {
                callTimer.setVisibility(View.VISIBLE);
                allButtonHolder.setVisibility(View.VISIBLE);
                slide_message.setVisibility(View.GONE);
                callTimer.setText(message);
                if (!shouldHideViews()) {
                    bottomViewGroupContainer.setVisibility(View.VISIBLE);
                    topViewGroupContainer.setVisibility(View.VISIBLE);
                    tvCallInfoText.setText(R.string.voice_call_salam);
                } else {
                    tvCallInfoText.setText(R.string.salamVideoCall);
                }
                return;
            }

            message = intent.getStringExtra(Constants.BROADCAST_MESSAGE_DISPLAY_STATUS);
            if (message != null) {
                if (!endCallInitiated) {

//                    callTimer.setText(message);
                }
                if (message.equalsIgnoreCase(getString(R.string.connected))) {
                    outgoingGUISetup();
                    showRunningCallNotification(number);
                } else if (message == getString(R.string.call_end)) {
//                    endActivity();
                    endCall(message);
                }

                if (message.equalsIgnoreCase(getString(R.string.connected))) {
                    audioVideoSwitchButton.setEnabled(true);
                    audioVideoSwitchButtonContainer.setEnabled(true);

                    if (isIncomingCall) {
                        callTransferFlag = true;
                        callTransferButton.setImageResource(R.drawable.ic_call_window_redirects_diasabled);
                        callTransferButton.setAlpha((float) 1.0);
                    } else {
                        callTransferFlag = false;
                        callTransferButton.setImageResource(R.drawable.ic_call_window_redirects_diasabled);
                        callTransferButton.setAlpha((float) 0.4);
                    }
                    isCallProgressingOrConnected = true;
                    isConnectedCall = true;

                    if (initialCameraPreviewContainer.getVisibility() == View.VISIBLE) {
                        initialCameraPreviewContainer.setVisibility(View.GONE);
                        initialCameraPreview.setVisibility(View.GONE);
                    }

//                    switchToVideo(SIPProvider.callType == SIPProvider.CALLTYPE_VIDEO);

                    if (!localAudioManager.isBluetoothA2dpOn()) {
                        Log.d("BluetoothTest", "Checking if isBluetoothScoRequestedToSetOn: "
                                + DialerService.isBluetoothScoRequestedToSetOn);
                        if (isIncomingCall &&
                                Util.isBluetoothHeadsetConnected() &&
                                !DialerService.isBluetoothScoRequestedToSetOn) {
                            if (!localAudioManager.isBluetoothScoOn()) {
                                localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                                localAudioManager.setBluetoothScoOn(true);
                                localAudioManager.startBluetoothSco();
                                DialerService.isBluetoothScoRequestedToSetOn = true;
                                blueToothConnectionMode = SCO_CONNECTED;
                                Log.e("BluetoothTest", "CallFrameGUI Activity starting BlueToothSco " +
                                        "after incoming call connected");
                            }


                        }
                    } else {

                        if (localAudioManager.getMode() != AudioManager.STREAM_VOICE_CALL) {
                            Log.d("BluetoothTest", "CallFrameGUIActivity: Call Connected: " +
                                    "BluetoothA2DP connected: AudioMode Set: STREAM_VOICE_CALL "
                            );
                            localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                        }
                        blueToothConnectionMode = A2DP_CONNECTED;
                    }
                    tvCallStatus.setText(message);
                    callTimer.setText("");
                    callTimer.setVisibility(View.GONE);
                    allButtonHolder.setVisibility(View.GONE);
                    // Omitted this line as media package is not available
                    // MediaDataRecv.resetDataReceivedSoFar();

                    callQualityHandler.removeCallbacks(callQualityRunnable);
                    callQualityHandler.postDelayed(callQualityRunnable, 5000);
                    qualityBar.setVisibility(View.VISIBLE);
                    linkQuality.setText(R.string.excellent);
                    linkQuality.setTextColor(getResources().getColor(R.color.green));
                    ((TextView) findViewById(R.id.tv_network_quality)).setText(R.string.network_quality);

//                    findViewById(R.id.callOptionsInactive).setVisibility(View.GONE);
//                    findViewById(R.id.callOptionsActive).setVisibility(View.VISIBLE);

                    callConnected = true;
                    callStartTime = System.currentTimeMillis();
                }

                if (message.equalsIgnoreCase(getString(R.string.call_progressing))) {
                    isCallProgressingOrConnected = true;
                    tvCallStatus.setText(message);
                    callTimer.setText("");
                    callTimer.setVisibility(View.GONE);
                    allButtonHolder.setVisibility(View.GONE);
//                    findViewById(R.id.callOptionsInactive).setVisibility(View.GONE);
//                    findViewById(R.id.callOptionsActive).setVisibility(View.VISIBLE);
                }
                return;
            }

            message = intent.getStringExtra(Constants.BROADCAST_MESSAGE_FINISH);
            if (message != null) {
//                endActivity();
                endCall(message);
            }

            message = intent.getStringExtra(Constants.BROADCAST_MESSAGE_VIDEO_STATUS_NUMBER);
            if (message != null) {
                try {
                    int videoStatus = intent.getIntExtra(Constants.BROADCAST_MESSAGE_VIDEO_STATUS, 0);
                    if (SIPProvider.isVideoCall("")) {
                        switchVideoPlayerStatus(videoStatus == 1);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            message = intent.getStringExtra(BROADCAST_MESSAGE_CALL_CONNECTED_FROM);
            if (message != null) {
                try {
                    if (message.equals(CALL_CONNECTED_FROM_ACCEPT)) {
                        VideoParameters.sendVideoData = true;
                        switchVideoAudio(SIPProvider.isVideoCall(""));
                    } else {
                        if (callStartedAsVideoCall) {
                            VideoParameters.sendVideoData = true;
                            switchVideoAudio(SIPProvider.isVideoCall(""));
                        } else if (SIPProvider.isVideoCall("")) {
                            releaseCameraPreview();
                            VideoParameters.sendVideoData = true;
                            initializePreview();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    };

    boolean endCallInitiated = false;

    private void endCall(String message) {
        if (endCallInitiated)
            return;
        endCallInitiated = true;
        if (callConnected) {
            if (!dialogShown) {
                callEndTime = System.currentTimeMillis();
            }
        }

        tvCallStatus.setText(R.string.disconnecting);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!dialogShown) {
//                showCallDisconnectionDialog(message, callConnected);
                        endActivity();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 1000);
    }

    private void endActivity() {

        Log.i("CallFrameGUIActivity", "CallFrameGUIActivity endActivity");
        handler.removeCallbacks(callQualityRunnable);
        qualityBar.setVisibility(View.INVISIBLE);
        handler.post(new FinishRunnable());
    }

    private void sendMessage(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        char numberTyped = KeyCharacterMap.load(event.getDeviceId()).getNumber(keyCode);
        if ((numberTyped >= '0' && numberTyped <= '9') || numberTyped == '#'
                || numberTyped == '*') {

        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
                keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE) {
            if (isConnectedCall)
                reject();
            else {
                if (isIncomingCall)
                    accept();
                else
                    reject();
            }


        } else if (keyCode == KeyEvent.KEYCODE_DEL) {

        } else if (keyCode == KeyEvent.KEYCODE_CALL) {
            accept();
        } else if (keyCode == KeyEvent.KEYCODE_ENDCALL) {
            reject();
        } else
            return false;
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CALL_TRANSFER_REQUEST) {
            if (resultCode != Activity.RESULT_OK)
                callTransferButton.setImageResource(R.drawable.ic_call_window_redirects_diasabled);
            else {
                callTransferFlag = false;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void accept() {
        endCallInitiated = false;
        cancelIncomingCallNotification();
        showRunningCallNotification(number);
        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                Constants.BROADCAST_MESSAGE_ACCEPT);
    }

    private void reject() {
        cancelIncomingCallNotification();
        cancelRunningCallNotification();
        sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                Constants.BROADCAST_MESSAGE_REJECT);
//        endActivity();
        endCall(getString(R.string.you_have_disconnected_the_call));
    }

    private void incomingGUISetup() {

        setVolumeControlStream(AudioManager.STREAM_RING);
        findViewById(R.id.endcall_button_space).setVisibility(View.INVISIBLE);
        findViewById(R.id.accept_decline_button_space).setVisibility(
                View.VISIBLE);
        // findViewById(R.id.activitybutton).setVisibility(View.INVISIBLE);
//        allButtonHolder.setVisibility(View.GONE);
        ivChat.setVisibility(View.GONE);
        tvSlideMessage.setVisibility(View.VISIBLE);

    }

    private void outgoingGUISetup() {
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
        findViewById(R.id.accept_decline_button_space).setVisibility(
                View.INVISIBLE);
        findViewById(R.id.endcall_button_space).setVisibility(View.VISIBLE);
        // findViewById(R.id.activitybutton).setVisibility(View.INVISIBLE);
        ivChat.setVisibility(View.GONE);
//        audioVideoSwitchButton.setAlpha((float)0.4);
        audioVideoSwitchButton.setEnabled(false);
        callTransferButton.setAlpha((float) 0.4);
        callTransferButton.setEnabled(false);
    }

    private void connectedGUISetup() {
        outgoingGUISetup();
        ivChat.setVisibility(View.GONE);
//        audioVideoSwitchButton.setAlpha((float)1.0);
        allButtonHolder.setVisibility(View.VISIBLE);

        if (isIncomingCall) {
            callTransferFlag = true;
            callTransferButton.setImageResource(R.drawable.ic_call_window_redirects_diasabled);
        } else callTransferButton.setAlpha((float) 0.4);
        isCallProgressingOrConnected = true;
        isConnectedCall = true;

        if (!localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "Checking if isBluetoothScoRequestedToSetOn: "
                    + DialerService.isBluetoothScoRequestedToSetOn);
            if (isIncomingCall &&
                    Util.isBluetoothHeadsetConnected() &&
                    !DialerService.isBluetoothScoRequestedToSetOn) {
                if (!localAudioManager.isBluetoothScoOn()) {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    localAudioManager.setBluetoothScoOn(true);
                    localAudioManager.startBluetoothSco();
                    DialerService.isBluetoothScoRequestedToSetOn = true;
                    blueToothConnectionMode = SCO_CONNECTED;
                    Log.e("BluetoothTest", "CallFrameGUI Activity starting BlueToothSco " +
                            "after incoming call connected");
                }
            }
        } else {
            if (localAudioManager.getMode() != AudioManager.STREAM_VOICE_CALL) {
                Log.d("BluetoothTest", "CallFrameGUIActivity: Call Connected: " +
                        "BluetoothA2DP connected: AudioMode Set: STREAM_VOICE_CALL "
                );
                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
            }
            blueToothConnectionMode = A2DP_CONNECTED;
        }
        tvCallStatus.setText(getString(R.string.connected));

        callQualityHandler.removeCallbacks(callQualityRunnable);
        callQualityHandler.postDelayed(callQualityRunnable, 5000);
        qualityBar.setVisibility(View.VISIBLE);
        linkQuality.setText(R.string.excellent);
        linkQuality.setTextColor(getResources().getColor(R.color.green));
        ((TextView) findViewById(R.id.tv_network_quality)).setText(R.string.network_quality);

        audioVideoSwitchButtonContainer.setEnabled(true);
        audioVideoSwitchButton.setEnabled(true);

        callConnected = true;
    }

    private class FinishRunnable implements Runnable {
        public void run() {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            finish();
        }
    }

    public void acquireLocksInCall() {
        startProximitySensor();

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

//        PowerManager powerManager = (PowerManager) this.getSystemService(POWER_SERVICE);
//        long l = SystemClock.uptimeMillis();
//
//        // TODO: commented out following line for test
////        powerManager.userActivity(l, true);
    }

    public void startProximitySensor() {
        Log.i("CallFrameGUIActivity", "startProximitySensor()");
        sensorManager.registerListener(this, proximitySensor, SENSOR_DELAY_NORMAL, handler);
        if (screenLock != null && !screenLock.isHeld())
            screenLock.acquire();
    }

    public void stopProximitySensor() {
        Log.i("CallFrameGUIActivity", "stopProximitySensor()");
        sensorManager.unregisterListener(this);
        if (screenLock != null && screenLock.isHeld())
            screenLock.release(0);
    }

    public void releaseLocksInCall() {
        stopProximitySensor();
    }

    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) {
    }

    public void onSensorChanged(SensorEvent event) {
        Log.i("CallFrameGUIActivity", "onSensorChanged(event)");
        final Window window = getWindow();
        WindowManager.LayoutParams lAttrs = getWindow().getAttributes();


        View view = ((ViewGroup) window.getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        Log.i("CallFrameGUIActivity", "event.values[0]:" + event.values[0]);
        if (event.values[0] > 0.0) {
            Log.i("CallFrameGUIActivity", "showing view ");
            lAttrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            view.setVisibility(View.VISIBLE);
        } else if (isAudioCall()) {
            Log.i("CallFrameGUIActivity", "hiding view: isAudioCall(): " + isAudioCall());
            lAttrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            view.setVisibility(View.GONE);
        }
        window.setAttributes(lAttrs);
    }

    private void bluetoothAction(boolean isChecked) {

        if (isChecked) {

            if (Build.VERSION.SDK_INT >= 11) {
                mProfileListener = new BluetoothProfile.ServiceListener() {
                    public void onServiceConnected(int profile,
                                                   BluetoothProfile proxy) {
                        if (profile == BluetoothProfile.HEADSET) {
                            mBluetoothHeadset = (BluetoothHeadset) proxy;
                            Log.d("CallFrameGUIActivity", "Enters in is checked");

                            List<BluetoothDevice> connectedHeadsets = mBluetoothHeadset
                                    .getConnectedDevices();
                            bluetoothAdapter
                                    .closeProfileProxy(
                                            BluetoothProfile.HEADSET,
                                            mBluetoothHeadset);
                            Log.d("CallFrameGUIActivity", "Connected headset count : "
                                    + connectedHeadsets.size());

                            connectedHeadsetCount = connectedHeadsets.size();

                            Log.d("CallFrameGUIActivity", "Connected headset count var: "
                                    + connectedHeadsetCount);

                            if (connectedHeadsetCount == 1) {

                                Toast.makeText(CallFrameGUIActivity.this,
                                        R.string.bluetooth_on,
                                        Toast.LENGTH_SHORT).show();

                                sendMessage(
                                        Constants.BROADCAST_MESSAGE_FROM_CALL,
                                        Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
                            } else {
                                bluetoothSettingsFlag = true;
                                Intent intentBluetooth = new Intent();
                                intentBluetooth = new Intent();
                                intentBluetooth
                                        .setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                                startActivity(intentBluetooth);
                            }
                        }
                    }

                    public void onServiceDisconnected(int profile) {
                        if (profile == BluetoothProfile.HEADSET) {
                            mBluetoothHeadset = null;
                        }
                    }
                };

                /**
                 * for some reason this line must be after creation of service
                 * listener
                 */
                bluetoothAdapter.getProfileProxy(this, mProfileListener,
                        BluetoothProfile.HEADSET);
            } else {

                Toast.makeText(this, R.string.bluetooth_on, Toast.LENGTH_SHORT).show();
                sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL, Constants.BROADCAST_MESSAGE_START_BLUETOOTH);
            }

        } else {
            Toast.makeText(this, R.string.bluetooth_off, Toast.LENGTH_SHORT).show();
            sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL, Constants.BROADCAST_MESSAGE_STOP_BLUETOOTH);

        }

    }

    private void sendIntentMessageToDialer(String type, String number) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, number);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private Dialog statsDialog = null;
    private boolean dialogShown = false;

//    private void showCallDisconnectionDialog(final String message, final boolean showDuration) {
//        //do_not_have_enough_balance_to_make_call
//
//        if (message.equals(getString(R.string.do_not_have_enough_balance_to_make_call))) {
//            Intent intent = new Intent(this, CallFinishedDialogLowBalance.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            intent.putExtra(CallFinishedDialogLowBalance.NUMBER, number);
//            intent.putExtra(CallFinishedDialogLowBalance.MESSAGE, message);
//            startActivity(intent);
//        } else if (message.length() == 0 && preferences.getBoolean(Constants.RATE_CALL_ENABLED, Constants.RATE_CALL_ENABLED_DEF) && showDuration) {
//            Intent intent = new Intent(this, RateCallActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            intent.putExtra(RateCallActivity.NUMBER, number);
//            startActivity(intent);
//        } else if (message.startsWith(getString(R.string.call_was_not_answered)) && DatabaseConstants.getInstance(this).checkForSubscriberByNumber(number)) {
//            Intent intent = new Intent(this, UserOfflineDialog.class);
//            intent.putExtra(UserOfflineDialog.NUMBER, number);
//            String[] parts = message.split(":");
//            if (parts.length >= 2) {
//                intent.putExtra(UserOfflineDialog.RATE, parts[1]);
//            }
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//        } else {
//            Intent intent = new Intent(this, CallFinishedDialog.class);
//            intent.putExtra(CallFinishedDialog.NUMBER, number);
//            intent.putExtra(CallFinishedDialog.MESSAGE, message);
//            if (showDuration) {
//                int sec = (int) ((callEndTime - callStartTime) / 1000);
//                int min = 0;
//                if (sec > 60) {
//                    min = sec / 60;
//                }
//                sec = sec % 60;
//                intent.putExtra(CallFinishedDialog.SHOW_DURATION, " " + (min > 0 ? (min + " min ") : "") + sec + " sec");
//            }
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//        }
//        endActivity();
//
//    }

    private void showRunningCallNotification(String number) {
        RunningCallNotification.newBuilder().withContext(this)
                .withNumber(number).withIsOutGoingCall(false)
                .build()
                .showNotification();


    }

    private void cancelRunningCallNotification() {
        RunningCallNotification.cancelNotification();
    }

    private void cancelIncomingCallNotification() {
        IncomingCallNotification.cancelNotification();
    }

    private void handleBluetooth() {

        if (localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "CallFrameGuiActivity: checking Bluetooth A2DP: ON");
            if (isIncomingCall) {
                blueToothConnectionMode = A2DP_CONNECTED;

            } else {
                Log.d("BluetoothTest", "CallFrameGuiActivity: changing Audio Mode to " +
                        "STREAM_VOICE_CALL in Outgoing Call");
                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                blueToothConnectionMode = A2DP_CONNECTED;
            }

        } else {
            Log.d("BluetoothTest", "CallFrameGuiActivity: checking Bluetooth A2DP: OFF");
            if (!isIncomingCall) {
                if (isBluetoothHeadsetConnected() && !DialerService.isBluetoothScoRequestedToSetOn) {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    localAudioManager.setBluetoothScoOn(true);
                    localAudioManager.startBluetoothSco();
                    DialerService.isBluetoothScoRequestedToSetOn = true;
                    blueToothConnectionMode = SCO_CONNECTED;
                    Log.e("BluetoothTest", "CallFrameGuiActivity Outgoing Call Starting BluetoothSCO: changing Audio Mode to " +
                            "MODE_IN_COMMUNICATION");
                } else {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    Log.d("BluetoothTest", "CallFrameGuiActivity Outgoing Call changing Audio Mode to " +
                            "MODE_IN_COMMUNICATION");

                }
            }

        }

    }

    public boolean isBluetoothHeadsetConnected() {
        if (localAudioManager.isBluetoothA2dpOn())
            return true;
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            return mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()
                    && mBluetoothAdapter.getProfileConnectionState(BluetoothHeadset.HEADSET) == BluetoothHeadset.STATE_CONNECTED;
        } else
            return false;
    }

    private void registerBluetoothConnectionStateReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(mReceiver, filter);
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                //Device found

                postBluetoothOrHeadSetConnected();
                if (localAudioManager.isBluetoothA2dpOn()) {
                    if (!isIncomingCall) {
                        Log.d("BluetoothTest", "CallFrameGUIActivity OutGoingCall " +
                                ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                        localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                        blueToothConnectionMode = A2DP_CONNECTED;
                    } else {
                        if (SIPProvider.voiceRunning) {
                            Log.d("BluetoothTest", "CallFrameGUIActivity Incoming Call voiceRunning " +
                                    ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                    ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                            if (!isCallProgressingOrConnected)
                                localAudioManager.setMode(AudioManager.MODE_NORMAL);
                            else
                                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                            blueToothConnectionMode = A2DP_CONNECTED;

                        }
                    }

                } else {
                    if (isIncomingCall) {
                        if (SIPProvider.voiceRunning) {
                            if (!localAudioManager.isBluetoothScoOn() &&
                                    !DialerService.isBluetoothScoRequestedToSetOn) {
                                localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                                localAudioManager.setBluetoothScoOn(true);
                                localAudioManager.startBluetoothSco();
                                blueToothConnectionMode = SCO_CONNECTED;
                                DialerService.isBluetoothScoRequestedToSetOn = true;
                                Log.e("BluetoothTest", "CallFrameGUIActivity Incoming Call voiceRunning " +
                                        ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                        ": A2DP STATUS: OFF : AUDIO set mode: MODE_IN_COMMUNICATION");
                            }

                        }
                    } else {
                        if (!localAudioManager.isBluetoothScoOn() &&
                                !DialerService.isBluetoothScoRequestedToSetOn) {
                            localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                            localAudioManager.setBluetoothScoOn(true);
                            localAudioManager.startBluetoothSco();
                            blueToothConnectionMode = SCO_CONNECTED;
                            DialerService.isBluetoothScoRequestedToSetOn = true;
                            Log.e("BluetoothTest", "CallFrameGUIActivity OutGoing Call " +
                                    ": Broadcast: BluetoothDevice.ACTION_FOUND" +
                                    ": A2DP STATUS: OFF: AUDIO set mode: MODE_IN_COMMUNICATION");
                        }
                    }

                }


            } else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                //              Device is now connected
                postBluetoothOrHeadSetConnected();

                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        localAudioManager = (AudioManager) CallFrameGUIActivity.this.getSystemService(AUDIO_SERVICE);
                        Log.d("BluetoothTest", "IsVoiceRunning: " + SIPProvider.voiceRunning +
                                " IsConnected: " + isCallProgressingOrConnected + " isA2DP:  "
                                + localAudioManager.isBluetoothA2dpOn());
                        if (localAudioManager.isBluetoothA2dpOn()) {
                            if (!isIncomingCall) {
                                Log.d("BluetoothTest", "CallFrameGUIActivity OutGoingCall " +
                                        ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                        ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                blueToothConnectionMode = A2DP_CONNECTED;
                            } else {
                                if (SIPProvider.voiceRunning) {
                                    Log.d("BluetoothTest", "CallFrameGUIActivity Incoming Call voiceRunning " +
                                            ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                            ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                    if (isCallProgressingOrConnected)
                                        localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                    else
                                        localAudioManager.setMode(AudioManager.MODE_NORMAL);
                                    blueToothConnectionMode = A2DP_CONNECTED;

                                }
                            }

                        } else {

                            if (!isIncomingCall) {
                                Log.d("BluetoothTest", "CallFrameGUIActivity OutGoingCall " +
                                        ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                        ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                blueToothConnectionMode = SCO_CONNECTED;
                            } else {
                                if (SIPProvider.voiceRunning) {
                                    Log.d("BluetoothTest", "CallFrameGUIActivity Incoming Call voiceRunning " +
                                            ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
                                            ": A2DP STATUS: ON: AUDIO set mode: STREAM_VOICE_CALL");
                                    localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
                                    blueToothConnectionMode = SCO_CONNECTED;

                                }
                            }
//                            if (isIncomingCall) {
//                                if (SIPProvider.voiceRunning) {
//                                    if (!localAudioManager.isBluetoothScoOn() &&
//                                            !DialerService.isBluetoothScoRequestedToSetOn) {
//                                        localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
//                                        localAudioManager.setBluetoothScoOn(true);
//                                        localAudioManager.startBluetoothSco();
//                                        DialerService.isBluetoothScoRequestedToSetOn = true;
//                                        blueToothConnectionMode = SCO_CONNECTED;
//                                        Log.e("BluetoothTest", "CallFrameGUIActivity Incoming Call voiceRunning " +
//                                                ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
//                                                ": A2DP STATUS: OFF : AUDIO set mode: MODE_IN_COMMUNICATION");
//                                    }
//
//                                }
//                            } else {
//                                if (!localAudioManager.isBluetoothScoOn() && !DialerService.isBluetoothScoRequestedToSetOn) {
//                                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
//                                    localAudioManager.setBluetoothScoOn(true);
//                                    localAudioManager.startBluetoothSco();
//                                    DialerService.isBluetoothScoRequestedToSetOn = true;
//                                    blueToothConnectionMode = SCO_CONNECTED;
//                                    Log.e("BluetoothTest", "CallFrameGUIActivity OutGoing Call " +
//                                            ": Broadcast: BluetoothDevice.ACTION_ACL_CONNECTED" +
//                                            ": A2DP STATUS: OFF: AUDIO set mode: MODE_IN_COMMUNICATION");
//                                }
//                            }

                        }
                    }
                }, 200);


            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                //Done searching
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED.equals(action)) {
                //Device is about to disconnect

            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                postBluetoothOrHeadSetDisconnected();

                Log.d("BluetoothTest", "ACTION_ACL_DISCONNECTED: connectionMode: " + blueToothConnectionMode);
                if (blueToothConnectionMode == A2DP_CONNECTED) {
                    Log.d("BluetoothTest", "CallFrameGUIActivity" +
                            ": Broadcast: BluetoothDevice.ACTION_ACL_DISCONNECTED" +
                            ": LAST STATUS: A2DP: AUDIO set mode: MODE_NORMAL");
                    localAudioManager.setMode(AudioManager.MODE_NORMAL);
                    blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;

                } else if (blueToothConnectionMode == SCO_CONNECTED) {
                    if (localAudioManager.isBluetoothScoOn()) {
                        localAudioManager.setBluetoothScoOn(false);
                        localAudioManager.stopBluetoothSco();
                        DialerService.isBluetoothScoRequestedToSetOn = false;
                        localAudioManager.setMode(AudioManager.MODE_NORMAL);
                        blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                        Log.e("BluetoothTest", "CallFrameGUIActivity Stopping BlueToothSCO" +
                                ": Broadcast: BluetoothDevice.ACTION_ACL_DISCONNECTED" +
                                ": LAST STATUS: SCO : AUDIO set mode: MODE_NORMAL");
                    } else {
                        localAudioManager.setMode(AudioManager.MODE_NORMAL);
                        blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                    }


                } else {

                    localAudioManager.setMode(AudioManager.MODE_NORMAL);
                    blueToothConnectionMode = BLUETOOTH_NOT_CONNECTED;
                    Log.d("BluetoothTest", "CallFrameGUIActivity" +
                            ": Broadcast: BluetoothDevice.ACTION_ACL_DISCONNECTED" +
                            ": LAST STATUS: None : AUDIO set mode: MODE_NORMAL");

                }

            }
        }
    };

//    private void handleQualityFiveState() {
//        final int div = MediaDataRecv.getDataReceivedSoFar();
//        MediaDataRecv.resetDataReceivedSoFar();
//        Log.i("arefin", "quality is " + div);
//
//        callQualityHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                ((TextView)findViewById(R.id.tv_network_quality)).setText(R.string.network_quality);
//                if (div >= 90) {
//                    linkQuality.setText(R.string.excellent);
//                    linkQuality.setTextColor(getResources().getColor(R.color.green));
//                } else if (div >= 80) {
//                    linkQuality.setText(R.string.good);
//                    linkQuality.setTextColor(getResources().getColor(R.color.green));
//
//                } else if (div >= 70) {
//                    linkQuality.setText(R.string.medium);
//                    linkQuality.setTextColor(getResources().getColor(R.color.green));
//
//                } else if (div >= 60) {
//                    linkQuality.setText(R.string.bad);
//                    linkQuality.setTextColor(getResources().getColor(R.color.red));
//
//                } else {
//                    linkQuality.setText(R.string.poor);
//                    linkQuality.setTextColor(getResources().getColor(R.color.red));
//
//                }
//            }
//        });
//
//    }

    private Runnable callQualityRunnable = new Runnable() {
        @Override
        public void run() {
            callQualityHandler.post(new Runnable() {
                @Override
                public void run() {
                    final int div = MediaDataRecv.getDataReceivedSoFar();
                    MediaDataRecv.resetDataReceivedSoFar();
                    Log.i("CallFrameGUIActivity", "callQualityRunnable: quality is " + div);

                    ((TextView) findViewById(R.id.tv_network_quality)).setText(R.string.network_quality);
                    if (div >= 450) {
                        linkQuality.setText(R.string.excellent);
                        linkQuality.setTextColor(getResources().getColor(R.color.green));
                    } else if (div >= 400) {
                        linkQuality.setText(R.string.good);
                        linkQuality.setTextColor(getResources().getColor(R.color.green));

                    } else if (div >= 350) {
                        linkQuality.setText(R.string.medium);
                        linkQuality.setTextColor(getResources().getColor(R.color.green));

                    } else if (div >= 300) {
                        linkQuality.setText(R.string.bad);
                        linkQuality.setTextColor(getResources().getColor(R.color.red));

                    } else {
                        linkQuality.setText(R.string.poor);
                        linkQuality.setTextColor(getResources().getColor(R.color.red));

                    }
                }
            });

            callQualityHandler.postDelayed(this, 5000);
        }
    };


//    private BroadcastReceiver mCallSwitchReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            boolean isVideoCall = intent.getBooleanExtra(Constants.IS_VIDEO_CALL, false);
//            switchToVideo(isVideoCall);
//        }
//    };

    /**
     * Video start
     */
    boolean callStartedAsVideoCall;

    public SurfaceView preview;
    public String previewSizeInString = "SMALL"; // SMALL or MEDIUM or FULL
    float scale;
    SurfaceHolder.Callback decodingCallback;
    SurfaceHolder.Callback encodingCallback;
    CameraUtil camera;
    String preferedQuality = Constants.VIDEO_QUALITIES[2];
    private SurfaceView playerSurface;
    private RtpReceiver receiver;
    private VideoPlayer player = null;
    private H264ParameterSets h264params = null;
    private Encoder encoder = null;
    private int videoWidth, videoHeight;
    private int videoCodecType = CodecParameters.CODEC_ID_H264;
    private boolean fullScreen = true;
    private boolean videoCallInit = false;
    ImageView cameraSwitchButton;
    LinearLayout cameraSwitchButtonContainer;
    public static int CURRENT_DISPLAY_ROTATION = 0;
    //    LinearLayout callFrameContainer = null;
    LinearLayout bottomViewGroupContainer = null;
    CardView topViewGroupContainer = null;

    Animation.AnimationListener hideAnimationListener, showAnimationListener;
    long lastTappedTimeInMilisecond;
    Timer slideDownTimer;
    TimerTask slideDownTimerTask;
    GestureDetectorCompat gestureDetector;
    Animation buttonsHideAnimation, buttonsShowAnimation,
            durationContanerLinearLayoutHideAnimation,
            durationContanerLinearLayoutShowAnimation;
//    TouchListenerAudio touchListenerAudio;

    FrameLayout videoPlayerContainer;
    FrameLayout initialCameraPreviewContainer;
    SurfaceView initialCameraPreview;
    public static int CURRENT_CAMERA = Camera.CameraInfo.CAMERA_FACING_FRONT;
    //	PowerManager.WakeLock screenLock, proximityLock;
    Camera mCamera = null;
    boolean mPreviewRunning = false;
    private boolean cameraReleased = false;
    SurfaceHolder surfaceViewHolder;
    SurfaceHolder.Callback surfaceHolderCallBack = new SurfaceHolder.Callback() {

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            Log.d("VideoCallerAcitivity",
                    "initialCameraPreview surface created");

            // LocalBroadcastManager
            // .newInstance(OutgoingVideoCallerAcitivity.this)
            // .registerReceiver(connectionInfoBroadcastReceiver,
            // new IntentFilter(Constants.INTENT_FROM_DIALER));

            surfaceViewHolder = holder;

            // checking if front camera available or not
            if (isCameraPresent(Camera.CameraInfo.CAMERA_FACING_FRONT)) {
                CURRENT_CAMERA = Camera.CameraInfo.CAMERA_FACING_FRONT;
            } else {
                CURRENT_CAMERA = Camera.CameraInfo.CAMERA_FACING_BACK;
            }

            if (!safeCameraOpen(CURRENT_CAMERA)) {
                Log.e("cameraLog", "Could not open Camera!!");
                Toast.makeText(CallFrameGUIActivity.this,
                        "Failed camera open!!", Toast.LENGTH_SHORT).show();
                sendMessage(Constants.BROADCAST_MESSAGE_FROM_CALL,
                        Constants.BROADCAST_MESSAGE_REJECT);
                finish();
                return;
            }

            try {
                mCamera.setPreviewDisplay(holder);
                mCamera.startPreview();
                mPreviewRunning = true;
            } catch (Exception e) {
                Log.e("cameraLog",
                        "error while setting null in setPreviewDisplay of camera");
                e.printStackTrace();
            }

            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) initialCameraPreview.getLayoutParams();
            WindowManager w = getWindowManager();
            int measuredWidth;
            int measuredHeight;
            int margin;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
                Point size = new Point();
                w.getDefaultDisplay().getSize(size);
                measuredWidth = size.x;
                measuredHeight = size.y;
            } else {
                Display d = w.getDefaultDisplay();
                measuredWidth = d.getWidth();
                measuredHeight = d.getHeight();
            }
            lp.height = measuredHeight;
            lp.width = (int) (measuredHeight * 3.0f / 4.0f);
            margin = (lp.width - measuredWidth) / 2;
            lp.setMargins(-margin, 0, -margin, 0);
            initialCameraPreview.setLayoutParams(lp);

        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width,
                                   int height) {
            Log.e("Pias", width + " " + height);
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            releaseCameraPreview();
        }

    };

    private void releaseCameraPreview() {
        if (!cameraReleased && mCamera != null) {
            mCamera.setPreviewCallback(null);
            mCamera.stopPreview();
            try {
                mCamera.setPreviewDisplay(null);
            } catch (IOException e1) {
                Log.e("cameraLog",
                        "error while setting null in setPreviewDisplay of camera");
                e1.printStackTrace();
            }
            surfaceViewHolder.removeCallback(surfaceHolderCallBack);
            surfaceViewHolder = null;
            mCamera.lock();
            mCamera.release();
            mCamera = null;
            cameraReleased = true;
        }
    }

    public boolean safeCameraOpen(int id) {
        // Camera camera = null;

        try {
            releaseCamera();
            if (!isCameraPresent(id)) {
                Log.e("MySurfaceView", "no camera Present!!");
                return false;
            }
            mCamera = Camera.open(id);
            Camera.Parameters p = mCamera.getParameters();
            p.setPreviewSize(640, 480);
            p.set("orientation", "landscape");
            p.setRotation(getRotation(id, getWindowManager()
                    .getDefaultDisplay().getRotation()));
            mCamera.setParameters(p);
            setCameraDisplayOrientation(id, mCamera);

            // Method rotateMethod;
            // rotateMethod =
            // android.hardware.Camera.class.getMethod("setDisplayOrientation",
            // int.class);
            // rotateMethod.invoke(mCamera, 90);

            // Log.d(TAG, "Camera opened: " + id);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return mCamera != null;
    }

    private void releaseCamera() {
        Log.w("CameraLOG", "releaseCamera Function called");
        // mPreview.setCamera(null);
        if (mCamera != null) {
            mCamera.lock();
            mCamera.release();
            mCamera = null;
        }
    }

    public boolean isCameraPresent(int camID) {
        Camera.CameraInfo ci = new Camera.CameraInfo();
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.getCameraInfo(i, ci);
            if (ci.facing == camID)
                return true;
        }
        return false; // No front-facing camera found
    }

    public int getRotation(int cameraId, int orientation) {
        android.hardware.Camera.CameraInfo info = new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        orientation = (orientation + 45) / 90 * 90;
        int rotation = 0;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            rotation = (info.orientation - orientation + 360) % 360;
        } else { // back-facing camera
            rotation = (info.orientation + orientation) % 360;
        }
        return rotation;
    }

    private void setCameraDisplayOrientation(int cameraId,
                                             android.hardware.Camera camera) {
        android.hardware.Camera.CameraInfo info = new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360; // compensate the mirror
        } else { // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }
        camera.setDisplayOrientation(result);
    }

    /**
     * Video end
     */

    private void sendIntentMessageToDialerForVideoStatus(String number, int videoStatus) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("callswitchupdate", number);
        intent.putExtra("videostatus", videoStatus);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public void showVideoPreview(boolean isChecked) {

    }

    public void switchVideoAudio(boolean isChecked) {
        Log.w("CallFrameGUIActivity", "switchVideoAudio(): " + isChecked);
        if (isChecked) {
            videoPlayerContainer.setVisibility(View.VISIBLE);
        } else {
            videoPlayerContainer.setVisibility(View.GONE);
        }

        if (isChecked) {
            audioVideoSwitchButton.setImageResource(R.drawable.switch_video_to_audio_active);
        } else {
            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video);
        }
        if (!videoCallInit && isChecked) {
            picture.setVisibility(View.GONE);

            setVideoCallEnvironment();
            videoCallInit = true;
            preview.setVisibility(View.VISIBLE);
            playerSurface.setVisibility(View.VISIBLE);
//            cameraSwitchButton.setVisibility(View.VISIBLE);
            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
//            secondLineButtons.setVisibility(View.GONE);
            initAnimations();
//            updateSpeakerStatusIfVideoCall();
            preview.setZOrderMediaOverlay(true);
            playerSurface.setZOrderMediaOverlay(false);
            showHideButtonOptions();
            startStopSpeaker();
            return;
        }
        if (isChecked) {
            picture.setVisibility(View.GONE);
            preview.setVisibility(View.VISIBLE);
            playerSurface.setVisibility(View.VISIBLE);
            encoder = selectEncoder();
            camera.setEncoder(encoder);
//            cameraSwitchButton.setVisibility(View.VISIBLE);
            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
//            secondLineButtons.setVisibility(View.GONE);
            initAnimations();
//            updateSpeakerStatusIfVideoCall();
            preview.setZOrderMediaOverlay(true);
            playerSurface.setZOrderMediaOverlay(false);
            showHideButtonOptions();
            startStopSpeaker();
        } else {
            picture.setVisibility(View.VISIBLE);
            preview.setVisibility(View.GONE);
            playerSurface.setVisibility(View.GONE);
            if (encoder != null) {
                try {
                    encoder.stopSending();
                    encoder.stopEncoder();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
//            cameraSwitchButton.setVisibility(View.GONE);
            cameraSwitchButtonContainer.setVisibility(View.GONE);
//            secondLineButtons.setVisibility(View.VISIBLE);
            bottomViewGroupContainer.setVisibility(View.VISIBLE);
            topViewGroupContainer.setVisibility(View.VISIBLE);
//            speakerAction(false);
            wasSpeakerOnBeforeHeadsetPluggedIn = false;
            speakerFlag = false;
            showHideButtonOptions();
            startStopSpeaker();
        }
    }

    public void initializePreview() {
        Log.w("CallFrameGUIActivity", "initializePreview()");
        audioVideoSwitchButton.setImageResource(R.drawable.switch_video_to_audio_active);
        if (!videoCallInit) {
            setVideoCallEnvironment();
            videoCallInit = true;

            picture.setVisibility(View.VISIBLE);
            preview.setVisibility(View.VISIBLE);
//            cameraSwitchButton.setVisibility(View.VISIBLE);
            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
//            secondLineButtons.setVisibility(View.GONE);
            playerSurface.setVisibility(View.GONE);
            videoPlayerContainer.setVisibility(View.GONE);
//            updateSpeakerStatusIfVideoCall();
            preview.setZOrderMediaOverlay(true);
            playerSurface.setZOrderMediaOverlay(false);
            initAnimations();
            showHideButtonOptions();
            startStopSpeaker();
        }
    }

    public void initializePlayer() {
        Log.w("CallFrameGUIActivity", "initializePlayer()");
        if (!videoCallInit) {
            setVideoCallEnvironment();
            videoCallInit = true;
            picture.setVisibility(View.GONE);
            preview.setVisibility(View.GONE);
//            cameraSwitchButton.setVisibility(View.GONE);
//            cameraSwitchButtonContainer.setVisibility(View.GONE);
//            secondLineButtons.setVisibility(View.GONE);
            playerSurface.setVisibility(View.VISIBLE);
            videoPlayerContainer.setVisibility(View.VISIBLE);
//            updateSpeakerStatusIfVideoCall();
            preview.setZOrderMediaOverlay(true);
            playerSurface.setZOrderMediaOverlay(false);
            initAnimations();
            showHideButtonOptions();
            startStopSpeaker();
        }
    }


    public void switchVideoPlayerStatus(boolean isChecked) {
        Log.w("CallFrameGUIActivity", "switchVideoPlayerStatus(): " + isChecked);
        if (isChecked) {
            picture.setVisibility(View.GONE);
            videoPlayerContainer.setVisibility(View.VISIBLE);
            playerSurface.setVisibility(View.VISIBLE);
            initAnimations();
//            updateSpeakerStatusIfVideoCall();
            playerSurface.setZOrderMediaOverlay(false);
            showHideButtonOptions();
            startStopSpeaker();
        } else {
            picture.setVisibility(View.VISIBLE);
            videoPlayerContainer.setVisibility(View.GONE);
            playerSurface.setVisibility(View.GONE);
            bottomViewGroupContainer.setVisibility(View.VISIBLE);
            topViewGroupContainer.setVisibility(View.VISIBLE);
//            updateSpeakerStatusIfVideoCall();
            showHideButtonOptions();
            startStopSpeaker();
        }
    }

    public void resetBluetoothMode() {
        if (!localAudioManager.isBluetoothA2dpOn()) {
            Log.d("BluetoothTest", "Checking if isBluetoothScoRequestedToSetOn: "
                    + DialerService.isBluetoothScoRequestedToSetOn);
            if (isIncomingCall &&
                    Util.isBluetoothHeadsetConnected() &&
                    !DialerService.isBluetoothScoRequestedToSetOn) {
                if (!localAudioManager.isBluetoothScoOn()) {
                    localAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    localAudioManager.setBluetoothScoOn(true);
                    localAudioManager.startBluetoothSco();
                    DialerService.isBluetoothScoRequestedToSetOn = true;
                    blueToothConnectionMode = SCO_CONNECTED;
                    Log.e("BluetoothTest", "CallFrameGUI Activity starting BlueToothSco " +
                            "after incoming call connected");
                }


            }
        } else {

            if (localAudioManager.getMode() != AudioManager.STREAM_VOICE_CALL) {
                Log.d("BluetoothTest", "CallFrameGUIActivity: Call Connected: " +
                        "BluetoothA2DP connected: AudioMode Set: STREAM_VOICE_CALL "
                );
                localAudioManager.setMode(AudioManager.STREAM_VOICE_CALL);
            }
            blueToothConnectionMode = A2DP_CONNECTED;
        }
    }

    public void switchVideoPreviewStatus(boolean isChecked) {
        Log.w("CallFrameGUIActivity", "switchVideoPreviewStatus(): " + isChecked);
        if (isChecked) {
            audioVideoSwitchButton.setImageResource(R.drawable.switch_video_to_audio_active);
        } else {
            audioVideoSwitchButton.setImageResource(R.drawable.ic_call_window_video);
        }
        if (isChecked) {
            preview.setVisibility(View.VISIBLE);
//            cameraSwitchButton.setVisibility(View.VISIBLE);
            cameraSwitchButtonContainer.setVisibility(View.VISIBLE);
            initAnimations();
//            updateSpeakerStatusIfVideoCall();
            preview.setZOrderMediaOverlay(true);
            showHideButtonOptions();
            startStopSpeaker();
        } else {
            preview.setVisibility(View.GONE);
//            cameraSwitchButton.setVisibility(View.GONE);
            cameraSwitchButtonContainer.setVisibility(View.GONE);
            bottomViewGroupContainer.setVisibility(View.VISIBLE);
            topViewGroupContainer.setVisibility(View.VISIBLE);
//            speakerAction(false);
            wasSpeakerOnBeforeHeadsetPluggedIn = false;
            speakerFlag = false;
            showHideButtonOptions();
            startStopSpeaker();
        }
    }

    public void setVideoCallEnvironment() {

        VideoParameters.videoStartTime = System.currentTimeMillis();
        String videoCodecLibrary = preferences.getString(
                VideoConstants.VIDEO_SELECTED_CODEC_LIBRARY_FOR_NEXT_RUN_FOR_H264,
                Constants.VIDEO_CODEC_LIBRARY_UNDEFINED);
        if (videoCodecLibrary.equals(VideoConstants.VIDEO_CODEC_LIBRARY_FFMPEG)) {
            videoWidth = 320;
            videoHeight = 240;
        } else {
            preferedQuality = Constants.VIDEO_QUALITIES[preferences.getInt(
                    Constants.VIDEO_QUALITY, Constants.VIDEO_QUALITY_DEF)];
            if (preferedQuality.equalsIgnoreCase(Constants.VIDEO_QUALITIES[0])) {
                videoWidth = 640;
                videoHeight = 480;
            } else if (preferedQuality.equalsIgnoreCase(Constants.VIDEO_QUALITIES[1])) {
                videoWidth = 640;
                videoHeight = 480;
            } else {
                videoWidth = 640;
                videoHeight = 480;
            }
        }

        getDimention();

        VideoParameters.CURRENT_ORIENTATION = getResources().getConfiguration().orientation;

        scale = this.getResources().getDisplayMetrics().density;

        makePlayerBigger();

        encodingCallback = new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {

                Log.i("VideoCallActivity", "surfaceCreated");
                if (camera == null || !camera.isCameraOpen()) {
                    camera = new CameraUtil(getApplicationContext());

                    // checking if front camera available or not
                    if (CameraUtil.isCameraPresent(Camera.CameraInfo.CAMERA_FACING_FRONT)) {
                        VideoParameters.CURRENT_CAMERA = Camera.CameraInfo.CAMERA_FACING_FRONT;
                    } else {
                        VideoParameters.CURRENT_CAMERA = Camera.CameraInfo.CAMERA_FACING_BACK;
//                        cameraSwitchButton.setVisibility(View.GONE);
                        cameraSwitchButtonContainer.setVisibility(View.GONE);
//                        secondLineButtons.setVisibility(View.GONE);
                    }

                    VideoParameters.CURRENT_DISPLAY_ROTATION = getWindowManager().getDefaultDisplay().getRotation();
                    VideoParameters.CURRENT_ORIENTATION = getResources().getConfiguration().orientation;

                    boolean cameraOpenSuccessful = camera.safeCameraOpen(VideoParameters.CURRENT_CAMERA,
                            VideoParameters.CURRENT_DISPLAY_ROTATION,
                            VideoParameters.CURRENT_ORIENTATION);
                    if (cameraOpenSuccessful) {
                        if (!camera.setCameraParameters(videoWidth, videoHeight, ImageFormat.YV12)) {
                            // Toast.makeText(getApplicationContext(),
                            // "Failed to access camera",
                            // Toast.LENGTH_SHORT).show();
                            Log.e("VideoCallActivity", "Failed to access camera");
                            finish();
                            return;
                        }
                    } else {
                        // Toast.makeText(getApplicationContext(),
                        // "Failed to open camera.Exiting.",
                        // Toast.LENGTH_SHORT).show();
                        Log.e("VideoCallActivity", "Failed to open camera");
                        finish();
                        return;
                    }
                }
                encoder = selectEncoder();

                if (encoder == null) {
                    Log.e("VideoCallActivity",
                            "Encoder is null! Exiting...");
                    Toast.makeText(getApplicationContext(),
                            "Video not available! Encoder is null.",
                            Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                Log.d("VideoCallActivity",
                        "encodingCallback surfaceCreated");

                try {
                    camera.setEncoder(encoder);
                    camera.setPreviewDisplay(holder);
                    camera.startCameraPreview();
                } catch (Exception e) {
                    e.printStackTrace();
                    finish();
                }
                preview.setZOrderMediaOverlay(true);
                playerSurface.setZOrderMediaOverlay(false);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format,
                                       int width, int height) {
                Log.d("VideoCallActivity",
                        "encodingCallback surfaceChanged");
//                preview.setZOrderOnTop(true);
                preview.setZOrderMediaOverlay(true);
                playerSurface.setZOrderMediaOverlay(false);
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                // Toast.makeText(getApplicationContext(),
                // "encodingCallback surfaceDestroyed", Toast.LENGTH_SHORT)
                // .show();
                Log.w("VideoCallActivity",
                        "encodingCallback surfaceDestroyed");
                try {
                    if (camera != null) {
                        camera.releaseCamera();
                    }
                    if (encoder != null) {
                        encoder.stopSending();
                        encoder.stopEncoder();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    VideoParameters.sendVideoKillBroadcast(CallFrameGUIActivity.this, "");
                }

            }
        };

        decodingCallback = new SurfaceHolder.Callback() {

            @Override
            public void surfaceCreated(SurfaceHolder holder) {

                Log.i("VideoCallActivity", "decodingCallback surfaceCreated");
                if (Build.VERSION.SDK_INT > 16) {
                    startPlaying(new RenderingSurface(playerSurface.getHolder().getSurface(), CallFrameGUIActivity.this), false);
                } else {
                    startPlaying(new RenderingSurface(playerSurface.getHolder().getSurface(), CallFrameGUIActivity.this), true);
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format,
                                       int width, int height) {

                Log.d("VideoCallActivity", "decodingCallback surfaceChanged");
                preview.setZOrderMediaOverlay(true);
                playerSurface.setZOrderMediaOverlay(false);
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                Log.w("VideoCallActivity", "decodingCallback surfaceDestroyed");
                if (VideoParameters.receiveVideo) {
                    receiver.stopReceiving("surfaceDestroyed callframeguiactivity");
                    player.stop();
                    player.release();
                }
                VideoPlayer.isPlaying = false;
            }
        };

        preview.getHolder().addCallback(encodingCallback);
        playerSurface.getHolder().addCallback(decodingCallback);
    }

    public static double measuredWidth = 1;
    public static double measuredHeight = 1;

    public void getDimention() {
        WindowManager w = getWindowManager();
        VideoParameters.CURRENT_DISPLAY_ROTATION = w.getDefaultDisplay().getRotation();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            Point size = new Point();
            w.getDefaultDisplay().getSize(size);
            measuredWidth = size.x;
            measuredHeight = size.y;
        } else {
            Display d = w.getDefaultDisplay();
            measuredWidth = d.getWidth();
            measuredHeight = d.getHeight();
        }
    }

    public void togglePreviewSize() {
        if (previewSizeInString.equals("SMALL"))
            makePreviewBigger();
        else if (previewSizeInString.equals("MEDIUM"))
            makePreviewSmaller();
    }

    public void startStopSpeaker() {
        if (isAudioCall()) {
            speakerAction(false);
        } else {
            updateSpeakerStatusIfVideoCall();
        }
    }

    private void updateSpeakerStatusIfVideoCall() {

        if (!localAudioManager.isWiredHeadsetOn() && !isBluetoothHeadsetConnected())
            speakerAction(true);
        else {
            speakerAction(false);
            wasSpeakerOnBeforeHeadsetPluggedIn = true;
        }
        speakerFlag = true;
        if (isBluetoothHeadsetConnected())
            resetBluetoothMode();

    }

    public static double measuredVideoWidth = 240;
    public static double measuredVideoHeight = 320;

    public void makePlayerBigger() {
//        CURRENT_DISPLAY_ROTATION = getWindowManager().getDefaultDisplay().getRotation();
        getDimention();

        ViewGroup.LayoutParams lp = playerSurface.getLayoutParams();

        double displayRatio = measuredHeight / measuredWidth;
        double imageRatio = videoWidth / videoHeight;

//        if(displayRatio > videoHeight / videoWidth){
//            measuredVideoWidth =  measuredWidth;
//            measuredVideoHeight = (measuredWidth * videoWidth / videoHeight);
//        } else {
//            measuredVideoHeight = measuredHeight;
//            measuredVideoWidth = measuredHeight * videoHeight / videoWidth;
//        }
        if (VideoParameters.CURRENT_ORIENTATION == Configuration.ORIENTATION_PORTRAIT) {
            measuredVideoWidth = measuredWidth;
            measuredVideoHeight = (measuredWidth * imageRatio);
        } else {
            measuredVideoHeight = measuredHeight;
            measuredVideoWidth = (measuredHeight / imageRatio);
        }

        lp.width = (int) measuredVideoWidth;
        lp.height = (int) measuredVideoHeight;

        playerSurface.setLayoutParams(lp);

        try {
            lp = preview.getLayoutParams();
            VideoParameters.CURRENT_ORIENTATION = getResources().getConfiguration().orientation;
            if (VideoParameters.CURRENT_ORIENTATION == Configuration.ORIENTATION_LANDSCAPE) {
                lp.width = (int) (100 * scale + 0.5f);
                lp.height = (int) (75 * scale + 0.5f);
                preview.setPadding(0, 0, 0, 0);
            } else {
                lp.width = (int) (75 * scale + 0.5f);
                lp.height = (int) (100 * scale + 0.5f);
                preview.setPadding(0, 0, 0, 0);
            }
            preview.setLayoutParams(lp);

            preview.setX((int) (measuredWidth - lp.width - 10 * scale));
            preview.setY((int) (measuredHeight / 2));
            preview.invalidate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void makePreviewBigger() {
        View container = (View) preview.getParent();

        ViewGroup.LayoutParams lp = preview.getLayoutParams();
        VideoParameters.CURRENT_ORIENTATION = getResources().getConfiguration().orientation;
        if (VideoParameters.CURRENT_ORIENTATION == Configuration.ORIENTATION_LANDSCAPE) {
            lp.width = (int) (160 * scale + 0.5f);
            lp.height = (int) (120 * scale + 0.5f);
        } else {
            lp.width = (int) (120 * scale + 0.5f);
            lp.height = (int) (160 * scale + 0.5f);
        }
        preview.setLayoutParams(lp);

        try {
            float mContainerWidth = container.getWidth();
            float mContainerHeight = container.getHeight();
            float aPosX = preview.getX();
            float aPosY = preview.getY();

            if (aPosX + lp.width >= mContainerWidth) {
                preview.setX(mContainerWidth - lp.width);
            }
            if (aPosY + lp.height >= mContainerHeight) {
                preview.setY(mContainerHeight - lp.height);
            }
            preview.invalidate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        previewSizeInString = "MEDIUM";
    }

    public void makePreviewSmaller() {
        ViewGroup.LayoutParams lp = preview.getLayoutParams();
        VideoParameters.CURRENT_ORIENTATION = getResources().getConfiguration().orientation;
        if (VideoParameters.CURRENT_ORIENTATION == Configuration.ORIENTATION_LANDSCAPE) {
            lp.width = (int) (100 * scale + 0.5f);
            lp.height = (int) (75 * scale + 0.5f);
        } else {
            lp.width = (int) (75 * scale + 0.5f);
            lp.height = (int) (100 * scale + 0.5f);
        }
        preview.setLayoutParams(lp);
        previewSizeInString = "SMALL";
    }

    protected Encoder selectEncoder() {
        Encoder enc = null;
        try {
            if (videoCodecType == CodecParameters.CODEC_ID_H264) {
                String videoCodecLibrary = preferences
                        .getString(
                                VideoConstants.VIDEO_SELECTED_CODEC_LIBRARY_FOR_NEXT_RUN_FOR_H264,
                                Constants.VIDEO_CODEC_LIBRARY_UNDEFINED);
                Log.i("VideoCallActivity",
                        "VIDEO_SELECTED_CODEC_LIBRARY_FOR_NEXT_RUN_FOR_H264 : "
                                + videoCodecLibrary);
//				enc = new FFMpegH264Encoder(videoWidth, videoHeight, this);
                if (videoCodecLibrary.equals(VideoConstants.VIDEO_CODEC_LIBRARY_FFMPEG)) {
                    enc = new FFMpegH264Encoder(videoWidth, videoHeight, this);
                } else {
                    enc = new H264Encoder(videoWidth, videoHeight, this);
                }
                ColorFormatAndRotationHandler.setCodecWidthAndHeight(videoHeight, videoWidth);
                // enc.setStartMS(System.currentTimeMillis());
                enc.setStartMS(System.nanoTime() / 1000);
                enc.startSending();
            } else if (videoCodecType == CodecParameters.CODEC_ID_H263_1998) {
                enc = new H263Encoder(videoWidth, videoHeight, this);
                ColorFormatAndRotationHandler.setCodecWidthAndHeight(videoHeight, videoWidth);
                // enc.setStartMS(System.currentTimeMillis());
                enc.setStartMS(System.nanoTime() / 1000);
                enc.startSending();
            }
            VideoParameters.receiveVideo = true;
        } catch (Exception e) {
            e.printStackTrace();
            finish();
        }
        return enc;
    }

    private synchronized void startPlaying(RenderingSurface renderSurface, boolean ffmpeg) {
        Log.d("VideoCallActivity", "startPlaying() function called: ffmpeg: " + ffmpeg);
        try {
            try {
                if (player != null) {
                    player.stop();
                    player.release();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (videoCodecType == CodecParameters.CODEC_ID_H264) {
                Log.d("VideoCallActivity", "H.264");
                if (ffmpeg) {
                    player = new FFMPEGBasedVideoPlayer(
                            CodecParameters.CODEC_ID_H264,
                            CodecParameters.RES_320x240, this);
                } else {
                    player = new MediaCodecBasedVideoPlayer(
                            CodecParameters.CODEC_ID_H264,
                            CodecParameters.RES_320x240, this);
                }
                player.setResolution(videoWidth, videoHeight);
                player.setRenderingSurface(renderSurface);
                receiver = new H264VideoReceiver(player);

            } else {
                Log.d("VideoCallActivity", "H.263");
                if (ffmpeg) {
                    player = new FFMPEGBasedVideoPlayer(
                            CodecParameters.CODEC_ID_H263,
                            CodecParameters.RES_320x240, this);
                } else {
                    player = new MediaCodecBasedVideoPlayer(
                            CodecParameters.CODEC_ID_H263,
                            CodecParameters.RES_320x240, this);
                }
                player.setResolution(videoWidth, videoHeight);
                player.setRenderingSurface(renderSurface);

                if (videoCodecType == CodecParameters.CODEC_ID_H263) {
                    receiver = new H263VideoReceiver(player);
                } else if (videoCodecType == CodecParameters.CODEC_ID_H263_1998) {
                    receiver = new H263PlusVideoReceiver(player);
                }
            }
            receiver.start();

        } catch (NumberFormatException | SocketException e) {
            e.printStackTrace();
        }
    }

    private BroadcastReceiver openFFMPEGBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Constants.INTENT_OPEN_MEDIA_CODEC_DECODER)) {
                try {
                    if (receiver != null && player != null) {
                        receiver.stopReceiving("openFFMPEGBroadcastReceiver");
                        player.stop();
                        player.release();
                    }

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startPlaying(new RenderingSurface(playerSurface.getHolder().getSurface(), CallFrameGUIActivity.this), false);
                        }
                    }, 1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (intent.getAction().equals(Constants.INTENT_OPEN_FFMPEG_DECODER)) {
                try {
                    if (receiver != null && player != null) {
                        receiver.stopReceiving("openFFMPEGBroadcastReceiver-callframeguiactivity");
                        player.stop();
                        player.release();
                    }

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d("VideoCallActivity", "startPlaying() called from receiver");
                            startPlaying(new RenderingSurface(playerSurface.getHolder().getSurface(), CallFrameGUIActivity.this), true);
                        }
                    }, 1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (intent.getAction().equals(Constants.INTENT_OPEN_FFMPEG_ENCODER)) {
                try {
                    if (encoder != null) {
                        encoder.stopSending();
                        encoder.stopEncoder();
                    }
                    preferences.edit().putString(VideoConstants.VIDEO_SELECTED_CODEC_LIBRARY_FOR_NEXT_RUN_FOR_H264, VideoConstants.VIDEO_CODEC_LIBRARY_FFMPEG).commit();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            selectEncoder();
                        }
                    }, 1000);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    };

    private BroadcastReceiver resizeVideoPlayer = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                if (intent != null) {
                    int width = intent.getIntExtra("width", videoWidth);
                    int height = intent.getIntExtra("height", videoHeight);
                    int marginLR = 0;
                    int marginTB = 0;

                    if (playerSurface != null) {
                        getDimention();

                        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) playerSurface.getLayoutParams();

                        double displayRatio = measuredWidth / measuredHeight;
                        double imageRatio = width * 1.0 / height;

                        Log.i("Dimension", "image Ratio: width/height: " + imageRatio + " width: " + width + " height: " + height + " display ratio: " + displayRatio);

                        if (!fullScreen) {
                            if (VideoParameters.CURRENT_ORIENTATION == Configuration.ORIENTATION_PORTRAIT) {
                                measuredVideoWidth = measuredWidth;
                                measuredVideoHeight = measuredWidth / imageRatio;
                            } else {
                                measuredVideoHeight = measuredHeight;
                                measuredVideoWidth = measuredHeight * imageRatio;
                            }
                        } else {
                            if (VideoParameters.CURRENT_ORIENTATION == Configuration.ORIENTATION_PORTRAIT) {
                                measuredVideoHeight = measuredHeight;
                                measuredVideoWidth = measuredHeight * imageRatio;
                                if (measuredVideoWidth > measuredWidth) {
                                    marginLR = (int) (measuredVideoWidth - measuredWidth) / 2;
                                }

                            } else {
                                measuredVideoWidth = measuredWidth;
                                measuredVideoHeight = measuredWidth / imageRatio;
                                if (measuredVideoHeight > measuredHeight) {
                                    marginTB = (int) (measuredVideoHeight - measuredHeight) / 2;
                                }
                            }
                        }

                        lp.width = (int) measuredVideoWidth;
                        lp.height = (int) measuredVideoHeight;

                        Log.i("Dimension", "After Conversion: image Ratio:" + imageRatio + " Width: " + lp.width + " Height: " + lp.height);

                        lp.setMargins(-marginLR, -marginTB, -marginLR, -marginTB);

                        playerSurface.setLayoutParams(lp);
                        playerSurface.invalidate();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private BroadcastReceiver mCallSwitchReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean isVideoCall = intent.getBooleanExtra(Constants.IS_VIDEO_CALL, false);
//            switchVideoAudio(isVideoCall);
            initializePlayer();
            if (isVideoCall) {
                tvCallInfoText.setText(R.string.salamVideoCall);
            } else {
                tvCallInfoText.setText(R.string.voice_call_salam);
            }
            VideoParameters.sendVideoData = false;
        }
    };


    private void initAnimations() {
        hideAnimationListener = new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                bottomViewGroupContainer.setVisibility(View.GONE);
                topViewGroupContainer.setVisibility(View.GONE);
            }
        };

        showAnimationListener = new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                reScheduleSlideDownTimer(slideDownTimer, slideDownTimerTask, 5000);
            }
        };

        buttonsHideAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.buttons_slide_down);
        buttonsShowAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.buttons_slide_up);

        buttonsHideAnimation.setAnimationListener(hideAnimationListener);
        buttonsShowAnimation.setAnimationListener(showAnimationListener);

        // Contact & duration animation
        durationContanerLinearLayoutHideAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.duration_slide_up);
        durationContanerLinearLayoutShowAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.duration_slide_down);

        durationContanerLinearLayoutHideAnimation.setAnimationListener(hideAnimationListener);
        durationContanerLinearLayoutShowAnimation.setAnimationListener(showAnimationListener);


        lastTappedTimeInMilisecond = 0;
        slideDownTimer = new Timer(true);
        slideDownTimerTask = new TimerTask() {
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        bottomViewGroupContainer.startAnimation(buttonsHideAnimation);
                        topViewGroupContainer.startAnimation(durationContanerLinearLayoutHideAnimation);
                    }
                });
            }
        };
        slideDownTimer.schedule(slideDownTimerTask, 5 * 1000);
    }

    public void reScheduleSlideDownTimer(Timer timer, TimerTask timertask,
                                         final long duration) {
        if (timer != null) {
            timer.cancel();
        }

        if (timertask != null) {
            timertask.cancel();
        }

        timer = new Timer(true);
        timertask = new TimerTask() {
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (SIPProvider.isVideoCall("") && System.currentTimeMillis()
                                    - lastTappedTimeInMilisecond >= duration) {
                                bottomViewGroupContainer.startAnimation(buttonsHideAnimation);
                                topViewGroupContainer.startAnimation(durationContanerLinearLayoutHideAnimation);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        };
        if (shouldHideViews()) {
            timer.schedule(timertask, duration);
        }
    }

    public boolean shouldHideViews() {
        return playerSurface.getVisibility() == View.VISIBLE;
    }

    public void animateShowViewSliding() {
        lastTappedTimeInMilisecond = System.currentTimeMillis();
        Log.w("SingleTap", "visilibility : " + bottomViewGroupContainer.getVisibility());
        if (bottomViewGroupContainer.getVisibility() == View.INVISIBLE || bottomViewGroupContainer.getVisibility() == View.GONE) {
            bottomViewGroupContainer.setVisibility(View.VISIBLE);
            bottomViewGroupContainer.startAnimation(buttonsShowAnimation);

            topViewGroupContainer.setVisibility(View.VISIBLE);
            topViewGroupContainer
                    .startAnimation(durationContanerLinearLayoutShowAnimation);
        } else if (bottomViewGroupContainer.getVisibility() == View.VISIBLE) {
            reScheduleSlideDownTimer(slideDownTimer, slideDownTimerTask, 5000);
        }
    }

    private class MySingleTapGestureListener extends
            GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onDown(MotionEvent event) {
            Log.w("VideoCallFrameActivity", "onDown");
//            rlDialPad.setVisibility(View.INVISIBLE);
            ViewGroup.LayoutParams lp = preview.getLayoutParams();
            preview.setLayoutParams(lp);
            animateShowViewSliding();
            return true;
        }

        @Override
        public boolean onDoubleTap(MotionEvent e) {
//            fullScreen = !fullScreen;
            fullScreen = true;
            Log.e("Pias", "FullScreen is now " + fullScreen);
            return true;
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (!isAudioCall()) {
            this.gestureDetector.onTouchEvent(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    boolean isAudioCall() {
        return playerSurface.getVisibility() != View.VISIBLE && preview.getVisibility() != View.VISIBLE;
    }

    public void showHideButtonOptions() {
        if (isAudioCall()) {
            secondLineButtons.setVisibility(View.VISIBLE);
            startProximitySensor();
        } else {
            secondLineButtons.setVisibility(View.GONE);
            stopProximitySensor();
        }
    }

    private class HeadSetReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_HEADSET_PLUG)) {
                int state = intent.getIntExtra("state", -1);
                switch (state) {
                    case 0:
                        Log.d("Headset", "Headset unplugged");
                        postBluetoothOrHeadSetDisconnected();
                        break;
                    case 1:
                        Log.d("Headset", "Headset plugged");
                        postBluetoothOrHeadSetConnected();
                        break;
                }
            }
        }
    }

    void postBluetoothOrHeadSetConnected() {
        wasSpeakerOnBeforeHeadsetPluggedIn = speakerFlag;
        speakerFlag = false;
        speakerAction(speakerFlag);
//        speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
        findViewById(R.id.ll_handleSpeaker).setEnabled(false);
    }

    void postBluetoothOrHeadSetDisconnected() {
        speakerFlag = wasSpeakerOnBeforeHeadsetPluggedIn;
        speakerAction(speakerFlag);

//        if (speakerFlag)
//            speakerButton.setImageResource(R.drawable.ic_call_window_speaker);
//
//        speakerButton.setImageResource(R.drawable.ic_call_window_speaker_active);
        findViewById(R.id.ll_handleSpeaker).setEnabled(true);

    }

}
