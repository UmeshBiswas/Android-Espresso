package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.quote;

import android.view.View;

public class MessageQuoteBindingData {
   public String name;
    public String message;
    public String  filePath;
    public  int previewVisibility = View.GONE;
    public  int videoIconVisibility = View.GONE;
}
