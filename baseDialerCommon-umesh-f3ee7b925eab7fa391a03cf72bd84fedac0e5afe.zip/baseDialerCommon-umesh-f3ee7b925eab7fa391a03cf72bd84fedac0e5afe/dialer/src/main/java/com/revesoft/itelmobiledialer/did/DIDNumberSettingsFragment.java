package com.revesoft.itelmobiledialer.did;

import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;

public class DIDNumberSettingsFragment extends Fragment implements View.OnClickListener, OnDidResponseListener, OnDoNotDisturbListener {

    private TextView didNumber, expiresIn, forwardedNumberTv, mTextViewDIDNumber;
    private ImageView imageViewUnsubscribe;
    private boolean isDialogVisible;
    private DID did;
    private String TAG = "GlobalNumberSettings";
    private androidx.appcompat.widget.SwitchCompat doNotDistSwitch, forwardNumberSwitch;
    SharedPreferences preferences;
    private String userName, password;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_global_number_settings, container, false);
        initView(v);

        preferences = getActivity().getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
        userName = UserDataManager.getUserName();
        password = UserDataManager.getUserPassword();
        getBundle();

        if (did != null) {

            if (!Util.isNetworkAvailable(getActivity()))
                Util.showNoNetworkDialog(getActivity());
            else
                new DoNotDisturbAsynctask(6, -1, getActivity(), DIDNumberSettingsFragment.this, did.getDidID(), true).execute();  //get status of did
        }
        return v;
    }

    private void getBundle() {

        Bundle bundle = getArguments();

        did = (DID) bundle.getSerializable("did");

        if (did == null) return;
        didNumber.setText(Util.formatNumberInLocal(did.getDidNumber()));
        mTextViewDIDNumber.setText(Util.formatNumberInLocal(did.getDidNumber()));

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        DateFormat targetFormat = new SimpleDateFormat("dd MMM,yyyy");
        try {
            String dateStr = getString(R.string.exp) + " ";
            Date date = sdf.parse(did.getExpireDate());
            dateStr = dateStr + targetFormat.format(date);
            expiresIn.setText(dateStr);

        } catch (ParseException e) {
            e.printStackTrace();
        }


        Log.d(TAG, "getBundle: " + did.getForwardedNumber());
        setForwardedNumberText();
        setForwarderNumberSwitchListener();

    }

    private void setForwardedNumberText() {
        if (did.getForwardedNumber().isEmpty()) {
            forwardNumberSwitch.setChecked(false);
        } else {
            if (did.getForwardedNumber().replaceAll("\\D", "").equalsIgnoreCase(userName.replaceAll("\\D", ""))) {
                if (did.getForwardedNumber().startsWith("+")) {
                    forwardNumberSwitch.setChecked(true);
                    forwardedNumberTv.setText(did.getForwardedNumber());
                } else {
                    forwardNumberSwitch.setChecked(false);
                    forwardedNumberTv.setText(getString(R.string.in_app_forwarding));
                }
            } else {
                if (!did.getForwardedNumber().isEmpty() && !did.getForwardedNumber().startsWith("+")) {

                    forwardedNumberTv.setText("+" + did.getForwardedNumber().trim());
                } else {
                    forwardedNumberTv.setText(did.getForwardedNumber());

                }
                forwardNumberSwitch.setChecked(true);

            }
        }
    }

    @Override
    public void onForwardedNumberSet(String forwardedNumber) {
        forwardNumberSwitch.setOnCheckedChangeListener(null);
        did.setForwardedNumber(forwardedNumber);
        if (forwardedNumber.isEmpty()) {
            forwardNumberSwitch.setChecked(false);
            Toast.makeText(getActivity(), getString(R.string.call_forwarding_disabled), Toast.LENGTH_SHORT).show();

        } else {
            if (did.getForwardedNumber().replaceAll("\\D", "").equalsIgnoreCase(userName.replaceAll("\\D", ""))) {
                if (did.getForwardedNumber().startsWith("+")) {
                    Toast.makeText(getActivity(), getString(R.string.call_forwarding_enabled), Toast.LENGTH_SHORT).show();
                    forwardNumberSwitch.setChecked(true);
                } else {
                    forwardNumberSwitch.setChecked(false);
                    Toast.makeText(getActivity(), getString(R.string.call_forwarding_disabled), Toast.LENGTH_SHORT).show();
                }
            } else {

                Toast.makeText(getActivity(), getString(R.string.call_forwarding_enabled), Toast.LENGTH_SHORT).show();
                forwardNumberSwitch.setChecked(true);
            }
        }

        setForwardedNumberText();
        setForwarderNumberSwitchListener();


    }

    private void setForwarderNumberSwitchListener() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                forwardNumberSwitch.setOnCheckedChangeListener(onForwardedNumberCheckedChangeListener);
            }
        }, 500);
    }

    private void showForwarderNumberDialog() {

        Intent intent = new Intent(getActivity(), ForwardingNumberSettingsActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("did", did);
        intent.putExtras(bundle);
        startActivityForResult(intent, 101755);

    }

    private SwitchCompat.OnCheckedChangeListener onForwardedNumberCheckedChangeListener = (buttonView, isChecked) -> {
        Log.d(TAG, "onCheckedChanged: " + isChecked);
        if (isChecked) {
            showForwarderNumberDialog();
        } else {
            showDisableForwarderNumberConfirmationDialog();
        }
    };

    private SwitchCompat.OnCheckedChangeListener onCheckedChangeListener = new SwitchCompat.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            Log.d(TAG, "onCheckedChanged: " + isChecked);
            if (isChecked) {
                new DoNotDisturbAsynctask(7, 0, getActivity(), DIDNumberSettingsFragment.this, did.getDidID(), true).execute();  //enable do not disturb
            } else {
                new DoNotDisturbAsynctask(7, 1, getActivity(), DIDNumberSettingsFragment.this, did.getDidID(), true).execute(); //disable do not disturb

            }
        }
    };

    private void initView(View v) {
        didNumber = v.findViewById(R.id.did_number);
        expiresIn = v.findViewById(R.id.expire_in);
        forwardedNumberTv = v.findViewById(R.id.forwarder_number);
        imageViewUnsubscribe = v.findViewById(R.id.iv_cancel);
        doNotDistSwitch = v.findViewById(R.id.do_not_disturb_switch);
        forwardNumberSwitch = v.findViewById(R.id.call_forwarding_switch);
        mTextViewDIDNumber = v.findViewById(R.id.did_number_header);
        imageViewUnsubscribe.setOnClickListener(this);
        v.findViewById(R.id.root_layout).setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if (view == imageViewUnsubscribe) {
            showUnsubscribeConfirmationDialog(did);
        }
    }

    private void showUnsubscribeConfirmationDialog(final DID did) {

        if (isDialogVisible) return;
        isDialogVisible = true;
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppAlertDialogTheme);
        builder.setTitle(getString(R.string.unsubscribe));
        builder.setMessage(getActivity().getString(R.string.unsubscribe_confirmation)
                + " " + Util.formatNumberInLocal(did.getDidNumber()));
        builder.setPositiveButton(R.string.ok_button, (dialog1, which) -> {
            cancel(did);
            dialog1.dismiss();
        });
        builder.setNegativeButton(R.string.button_cancel, (dialog13, which) -> dialog13.dismiss());
        builder.setOnDismissListener(dialog12 -> isDialogVisible = false);
        builder.create().show();

    }

    private void cancel(DID did) {
        new DIDAsyncTask(2, 4, did, getActivity(), DIDNumberSettingsFragment.this).execute();

    }

    private void showDisableForwarderNumberConfirmationDialog() {
        if (isDialogVisible) return;
        isDialogVisible = true;
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppAlertDialogTheme);
        builder.setMessage(R.string.forwarding_disable_confirmation);
        builder.setPositiveButton(R.string.ok_button, (dialog1, which) -> {
            DID newDid = new DID(did.getDidID(), did.getDidOwner(), did.getDidNumber(), userName, did.getExpireDate()); //disable forwarded number means enable in pin
            new DIDAsyncTask(2, 3, newDid, getActivity(), DIDNumberSettingsFragment.this).execute();
            dialog1.dismiss();

        });
        builder.setNegativeButton(R.string.button_cancel, (dialog13, which) -> {
            forwardNumberSwitch.setOnCheckedChangeListener(null);
            forwardNumberSwitch.setChecked(true);
            setForwarderNumberSwitchListener();
            dialog13.dismiss();
        });
        builder.setOnDismissListener(dialog12 -> isDialogVisible = false);
        builder.create().show();
    }


    @Override
    public void onUnsubscribeDid(DID selectedDID) {

        Intent data = new Intent();
        data.setData(Uri.parse(selectedDID.getDidID()));
        getActivity().setResult(RESULT_OK, data);
        getActivity().finish();
    }


    @Override
    public void onCountryListResponse(String[] countryNames, int[] countryFlags) {

    }

    @Override
    public void onStatesListResponse(String[] stateNames, String[] stateCode) {

    }

    @Override
    public void onCityListResponse(String[] cityNames, String[] cityCode) {

    }

    @Override
    public void onDIDListResponse(ArrayList<DID> dids) {

    }

    @Override
    public void onUsersDidListResponse(ArrayList<DID> dids) {

    }

    @Override
    public void onBuyUsersDID(DID did) {

    }


    @Override
    public void onEnable(boolean showToast) {
        showCustomizedToast(getString(R.string.do_not_disturb_enabled));

    }

    @Override
    public void onDisable(boolean showToast) {
        showCustomizedToast(getString(R.string.do_not_disturb_disabled));

    }

    //rahat 08-11-2017
    @Override
    public void onFailed(boolean showToast) {
        showCustomizedToast(getString(R.string.failed));
        doNotDistSwitch.setOnCheckedChangeListener(null);
        doNotDistSwitch.setChecked(!doNotDistSwitch.isChecked());
//        doNotDistSwitch.toggle();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doNotDistSwitch.setOnCheckedChangeListener(onCheckedChangeListener);

            }
        }, 500);

    }

    @Override
    public void setSwitchStatus(String status) {
        doNotDistSwitch.setOnCheckedChangeListener(null);
        if (status.equals("0")) {
            //switch enable
            doNotDistSwitch.setChecked(true);
        } else {
            doNotDistSwitch.setChecked(false);

        }

        new Handler().postDelayed(() -> doNotDistSwitch.setOnCheckedChangeListener(onCheckedChangeListener), 500);
    }


    private void showCustomizedToast(String message) {
        Toast toast = Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT);
//      toast.setGravity(Gravity.CENTER ,0,0);

        toast.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101755) {
            if (resultCode == RESULT_OK) {
                String number = data.getData().toString();
                DID newDid = new DID(did.getDidID(), did.getDidOwner(), did.getDidNumber(), number, did.getExpireDate());
                new DIDAsyncTask(2, 3, newDid, getActivity(), DIDNumberSettingsFragment.this).execute();
            } else {
                forwardNumberSwitch.setOnCheckedChangeListener(null);
                forwardNumberSwitch.setChecked(false);
                setForwarderNumberSwitchListener();
            }
        }

    }
}
