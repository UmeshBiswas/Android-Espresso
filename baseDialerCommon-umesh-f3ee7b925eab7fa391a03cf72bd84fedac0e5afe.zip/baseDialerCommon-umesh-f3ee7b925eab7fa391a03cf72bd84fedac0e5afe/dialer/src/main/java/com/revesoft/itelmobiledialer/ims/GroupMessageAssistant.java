package com.revesoft.itelmobiledialer.ims;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.model.Group;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.ArrayList;
import java.util.List;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Ifta
 */

public class GroupMessageAssistant {
    static void createGroup(Context context, ArrayList<Contact> selectedItems, String groupName, int e2e) {
        String[] selectedNumbers = new String[selectedItems.size()];
        for (int i = 0; i < selectedNumbers.length; i++) {
            selectedNumbers[i] = selectedItems.get(i).phoneNumber;
        }
        sendGroupIntentMessageToDialer(context, selectedNumbers, groupName, e2e);
    }

    private static void sendGroupIntentMessageToDialer(Context context, String[] number, String name, int e2e) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra("creategroup", new String[]{Util.join(";", number), name, e2e+""});
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static Group getGroupById(Context context, String groupId) {
        Group group = null;
        group = GroupRepo.get().getGroupById(groupId).convertGroupModel();
        return group;
    }

    public static void updateGroupName(Activity activity, String groupId, String groupName) {
        IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.CHANGE_GROUP_NAME,groupId,groupName);
    }

    /**
     * @param activity calling activity
     * @param group    the group for with you wad to get the group admin name
     * @return
     */
//    public static String getGroupAdminByNumber(Activity activity, Group group) {
//        return DatabaseConstants.getInstance(activity).getContactNameByNumber(group.creatorsNumber);
//    }

    /**
     * @param activity calling activity
     * @param group    Group for which you want to get the members contact
     * @return A List of Contacts where group admin lies at the end of the list
     */
    public static List<Contact> getGroupMembers(Activity activity, Group group) {
//        ArrayList<Contact> groupMembers = new ArrayList<Contact>();
//        Cursor cursor = ContactRepo.get().getAppContactsCursor(group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber); // this method returns all phonebook contacts except user
//        if (cursor != null && cursor.moveToFirst()) {
//            do {
//                groupMembers.add(new Contact(Contact.ContactType.DATABASE_CONTACT_APP, cursor));
//            } while (cursor.moveToNext());
//        }
//        ArrayList<String> allNumber = new ArrayList<String>(Arrays.asList(group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber));
//        for (Contact contact : groupMembers) {
//            allNumber.remove(contact.phoneNumber);
//        }
//        Collections.sort(allNumber);
//        for (String number : allNumber) {
//            if(!number.equals(UserDataManager.getUserName())) {    // adding all contacts except user
//                groupMembers.add(new Contact(number));
//            }
//        }
////        if(!hasLeftGroup(activity, group.id)) {
////            groupMembers.add(new Contact(UserDataManager.getUserName())); // adding user
////        }
//        return groupMembers;
        return null;
    }

//    public static boolean hasLeftGroup(Activity activity, String groupId) {
//        return GroupRepo.get().checkIfMember(groupId) != 1;
//    }

    public static boolean clearChat(Activity activity, String groupId) {
        return MessageRepo.get().clearChatByGroupId(groupId) != 0;
    }

//    public static String getGroupCreationDate(Activity activity, Group group) {
//        long date = DatabaseConstants.getInstance(activity).getGroupCreationDate(group.id);
//        if(date == -1)
//        {
//            return null;
//        }
//        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM,yyyy");
//        return sdf.format(date);
//
//    }
}
