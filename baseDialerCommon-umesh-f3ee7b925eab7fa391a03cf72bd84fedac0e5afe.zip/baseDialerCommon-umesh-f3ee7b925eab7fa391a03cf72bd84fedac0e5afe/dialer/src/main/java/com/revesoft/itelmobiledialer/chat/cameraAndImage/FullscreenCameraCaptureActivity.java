package com.revesoft.itelmobiledialer.chat.cameraAndImage;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Point;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.revesoft.itelmobiledialer.ims.ImageResizeUtil;
import com.revesoft.itelmobiledialer.ims.MediaSendConfirmationActivity;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.fragment.app.FragmentActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import static com.revesoft.itelmobiledialer.util.Constants.COMMON_PREFERENCE_NAME;
import static com.revesoft.itelmobiledialer.util.Constants.IS_FLASH_ENABLED;

@SuppressWarnings("deprecation|SetTextI18n")
public class FullscreenCameraCaptureActivity extends FragmentActivity implements SurfaceHolder.Callback, LoaderManager.LoaderCallbacks<Cursor> {
    private static final String TAG = "FSCaptureActivity";
    public static final String KEY_SHOULD_CAPTURE_IMAGE_ONLY = "KEY_SHOULD_CAPTURE_IMAGE_ONLY";
    private static final int PICTURE_SIZE_MAX_WIDTH = 1280;
    private final int IMAGE_CAPTURE = 1;
    private final int VIDEO_CAPTURE = 2;
    private int captureMode = IMAGE_CAPTURE;
    private CustomImageView captureButton;
    private CustomImageView captureModeButton;
    private CustomImageView previewFullScreenButton;
    private ImageView rotateCamButton;
    private ImageView flashEnableButton;
    private View rootView;
    private SurfaceView cameraPreview;
    private CountDownTimer timer = null;
    private OutputStream fOutputStream = null;
    private int camcorderProfileName;// = CamcorderProfile.QUALITY_QVGA;
    private String videoFilePath = "";
    private int numCameras = 1;
    private int currentCameraID = -1;
    private Camera camera;
    private int currentZoomLevel = 0;
    private final int maxZoomLevel = 0;
    private ScaleGestureDetector mScaleDetector;
    private boolean cameraPreviewResized = false;
    private RecyclerView mRecyclerView;
    private ImageGalleryAdapter mAdapter;
    private File file;
    private boolean isFlashLightAvailable;
    private int time_elapsed_for_vid = 0;

    private final Camera.PictureCallback myPictureCallback_JPG = new Camera.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] data, Camera camera) {

            file = new File(ProfilePicUploadDownloadHelper.getCapturedMediaDirectory(getApplicationContext()) + "/image_"
                    + new SimpleDateFormat("yyyyMMddHHmmss", Locale.ENGLISH).format(new Date()) + ".jpg");
            Bitmap bitmapPicture = BitmapFactory.decodeByteArray(data, 0, data.length);
            Util.sendNewFileCreatedBroadcast(FullscreenCameraCaptureActivity.this, file.getAbsolutePath());


            switch (currentCameraID) {
                case Camera.CameraInfo.CAMERA_FACING_BACK:
                    break;
                case Camera.CameraInfo.CAMERA_FACING_FRONT:
                    bitmapPicture = RotateBitmap(bitmapPicture, 180);
                    break;
            }
            if (bitmapPicture.getWidth() > bitmapPicture.getHeight()) {
                bitmapPicture = RotateBitmap(bitmapPicture, 90);
            }

            if (file.exists()) {
                file.delete();
            }
            try {
                fOutputStream = new FileOutputStream(file);
                bitmapPicture.compress(Bitmap.CompressFormat.JPEG, 100, fOutputStream);
                fOutputStream.flush();
                fOutputStream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                return;
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
            finishActivity(RESULT_OK, file.getAbsolutePath());
        }
    };
    private final View.OnClickListener imageCaptureOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            captureButton.setEnabled(false);
            camera.takePicture(null, null, myPictureCallback_JPG);
        }
    };
    private SurfaceHolder surfaceHolder;
    private TextView timerCountDownTV;
    private MediaRecorder recorder;
    private CamcorderProfile camcorderProfile;
    private boolean isRecording = false;
    private final int MAX_VIDEO_LENGTH = 25000;
    private boolean isFLashEnabled;
    private boolean isCaptureButtonOnTouch;


    @Override
    protected void onPause() {
        try {
            stopVideoRecording();
            captureModeButton.setEnabled(true);
            if (numCameras > 1)
                rotateCamButton.setEnabled(true);
            captureButton.setImageResource(R.drawable.tap_for_photo_normal);
            timerCountDownTV.setText("- 25 sec");
            releaseMediaRecorder();
            Log.d(TAG, "Calling alpha");
            finishActivity(RESULT_CANCELED, videoFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

        super.onPause();
    }

    private static boolean isCameraPresent(int camID) {
        Camera.CameraInfo ci = new Camera.CameraInfo();
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.getCameraInfo(i, ci);
            if (ci.facing == camID)
                return true;
        }
        return false; // No front-facing camera found
    }

    private boolean isVideoRecordStarted;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_480P)) {
            camcorderProfileName = CamcorderProfile.QUALITY_480P;
        } else if (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_QVGA)) {
            camcorderProfileName = CamcorderProfile.QUALITY_QVGA;
        } else if (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_CIF)) {
            camcorderProfileName = CamcorderProfile.QUALITY_CIF;
        } else {
            camcorderProfileName = CamcorderProfile.QUALITY_HIGH;
        }


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen_camera_capture);

        ImageView ivCrossButton = findViewById(R.id.image_view_cross_button);
        ivCrossButton.setOnClickListener(view -> onBackPressed());
        Intent i = getIntent();
        int PREVIEW_SIZE_MAX_WIDTH = getResources().getDisplayMetrics().widthPixels;

        rootView = findViewById(R.id.root_view);
        cameraPreview = findViewById(R.id.camera_preview);
        surfaceHolder = cameraPreview.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        camcorderProfile = CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH);
        mRecyclerView = findViewById(R.id.gallery_recycler_view);
        RecyclerView.LayoutManager mLayoutManager = new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new ImageGalleryAdapter(ImageResizeUtil.convertDpToPixel(84, this),
                ImageResizeUtil.convertDpToPixel(84, this));
        mRecyclerView.setAdapter(mAdapter);
        captureButton = findViewById(R.id.capture_button);
        final Handler handler = new Handler();
        final Runnable mLongPressed = () -> {
            isVideoRecordStarted = true;
            Log.i(TAG, "Capture button clicked");
            Log.d("Abhi", "camera thread: " + Thread.currentThread().getName());
            captureMode = VIDEO_CAPTURE;
            setCaptureMode(captureMode);
            captureButton.setEnabled(false);
            if (!isRecording) {
                videoFilePath = ProfilePicUploadDownloadHelper.getCapturedMediaDirectory(getApplicationContext()).getAbsolutePath() + "/video_"
                        + new SimpleDateFormat("yyyyMMddHHmmss", Locale.ENGLISH).format(new Date()) + ".mp4";
                Util.sendNewFileCreatedBroadcast(FullscreenCameraCaptureActivity.this, videoFilePath);
                Log.d(TAG, "Initiating video recording");
                startVideoRecording(videoFilePath);
                captureModeButton.setEnabled(false);
                rotateCamButton.setEnabled(false);
                captureButton.setImageResource(R.drawable.tap_for_photo_pressed);
                timer = new CountDownTimer(MAX_VIDEO_LENGTH, 1000) {
                    int time = MAX_VIDEO_LENGTH / 1000;

                    @Override
                    public void onTick(long millisUntilFinished) {
                        captureButton.setEnabled(true);
                        timerCountDownTV.setText("- " + time + " sec");
                        time = time - 1;
                        if (!isCaptureButtonOnTouch) {
                            finishRecording();
                            return;
                        }
                        time_elapsed_for_vid++;
                        Log.d("Abhi", "vid: " + isCaptureButtonOnTouch + " " + time_elapsed_for_vid);
                    }

                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onFinish() {
                        stopVideoRecording();
                        captureModeButton.setEnabled(true);
                        if (numCameras > 1)
                            rotateCamButton.setEnabled(true);
                        captureButton.setImageResource(R.drawable.tap_for_photo_normal);
                        timerCountDownTV.setText("- 25 sec");
                        releaseMediaRecorder();
                        Log.d(TAG, "Calling beta");

                        finishActivity(RESULT_OK, videoFilePath);
                    }
                };
                timer.start();
            }
        };


        new Handler().post(() -> captureButton.setOnTouchListener((view, event) -> {
            Log.d("Abhi", "On Touch thread: " + Thread.currentThread().getName());
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                handler.postDelayed(mLongPressed, 1000);
                isCaptureButtonOnTouch = true;
            }

            if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                Log.d(TAG, "isRecording: " + isRecording);
                isCaptureButtonOnTouch = false;
                handler.removeCallbacks(mLongPressed);
                if (isRecording)
                    finishRecording();
                else if (!isVideoRecordStarted) {
                    captureButton.setEnabled(false);
                    if (camera != null) {
                        if (isFlashLightAvailable && isFLashEnabled) {
                            Camera.Parameters p = camera.getParameters();
                            p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                            camera.setParameters(p);
                        }

                        camera.takePicture(null, null, myPictureCallback_JPG);
                    }

                }

            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                Log.d(TAG, "isRecording: " + isRecording);
                isCaptureButtonOnTouch = false;
                handler.removeCallbacks(mLongPressed);
                if (isRecording)
                    finishRecording();
                else if (!isVideoRecordStarted) {
                    captureButton.setEnabled(false);
                    if (camera != null) {
                        if (isFlashLightAvailable && isFLashEnabled) {
                            Camera.Parameters p = camera.getParameters();
                            p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                            camera.setParameters(p);
                        }

                        camera.takePicture(null, null, myPictureCallback_JPG);
                    }

                }
            }

            return true;
        }));

        captureModeButton = findViewById(R.id.capture_mode_button);
        previewFullScreenButton = findViewById(R.id.preview_full_screen_button);
        rotateCamButton = rootView.findViewById(R.id.rotate_cam_button);
        timerCountDownTV = rootView.findViewById(R.id.duration_textView);
        flashEnableButton = rootView.findViewById(R.id.flash_switch_button);

        numCameras = Camera.getNumberOfCameras();
        if (numCameras < 2)
            rotateCamButton.setEnabled(false);

        previewFullScreenButton.setOnClickListener(view -> finishActivity(RESULT_CANCELED, null));

        captureModeButton.setOnClickListener(view -> {
            if (captureMode == IMAGE_CAPTURE) {
                captureMode = VIDEO_CAPTURE;
                setCaptureMode(captureMode);
                captureButton.setImageResource(R.drawable.tap_for_photo_normal);
//                    captureButton.setOnClickListener(videoCaptureOnClickListener);
                captureModeButton.setImageResource(R.drawable.camera_down);
                timerCountDownTV.setVisibility(View.VISIBLE);
            } else {
                captureMode = IMAGE_CAPTURE;
                setCaptureMode(captureMode);
                captureButton.setImageResource(R.drawable.tap_for_photo_normal);
//                    captureButton.setOnClickListener(imageCaptureOnClickListener);
                captureModeButton.setImageResource(R.drawable.video_up);
                timerCountDownTV.setVisibility(View.GONE);
            }
        });
        if (captureMode == IMAGE_CAPTURE) {
            captureButton.setImageResource(R.drawable.tap_for_photo_normal);
            captureButton.setOnClickListener(imageCaptureOnClickListener);
        } else {
            captureButton.setImageResource(R.drawable.tap_for_photo_normal);
        }

        rotateCamButton.setOnClickListener(view -> rotateCamera());
        isFlashLightAvailable = this.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        if (!isFlashLightAvailable)
            flashEnableButton.setEnabled(false);
        isFLashEnabled = this.getSharedPreferences(COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(IS_FLASH_ENABLED, false);

        if (isFLashEnabled)
            flashEnableButton.setImageResource(R.drawable.flash_down);
        else
            flashEnableButton.setImageResource(R.drawable.flash_up);
        flashEnableButton.setOnClickListener(view -> {
            if (isFLashEnabled) {
                isFLashEnabled = false;
                flashEnableButton.setImageResource(R.drawable.flash_up);
                FullscreenCameraCaptureActivity.this.getSharedPreferences
                        (COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).edit().putBoolean(IS_FLASH_ENABLED, false).commit();
            } else {
                isFLashEnabled = true;
                flashEnableButton.setImageResource(R.drawable.flash_down);
                FullscreenCameraCaptureActivity.this.getSharedPreferences
                        (COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).edit().putBoolean(IS_FLASH_ENABLED, true).commit();
            }

        });
        mScaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.OnScaleGestureListener() {
            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {

            }

            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                if (maxZoomLevel < 0) {
                    Toast.makeText(FullscreenCameraCaptureActivity.this, "Zoom not supported in this mode", Toast.LENGTH_LONG).show();
                }
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                Log.d("Bulbul", "Zoom ongoing, scale: " + detector.getScaleFactor());

                if (camera != null && maxZoomLevel > 0) {
                    Camera.Parameters params = camera.getParameters();
                    if (detector.getScaleFactor() > 1) {
                        if (currentZoomLevel < maxZoomLevel) {
                            currentZoomLevel++;
                            params.setZoom(currentZoomLevel);
                            camera.setParameters(params);
                        }
                    } else {
                        if (currentZoomLevel > 0) {
                            currentZoomLevel--;
                            params.setZoom(currentZoomLevel);
                            camera.setParameters(params);
                        }
                    }
                }
                return false;
            }
        });

    }

    private void finishRecording() {

        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        captureButton.setEnabled(false);
        stopVideoRecording();
        captureModeButton.setEnabled(true);
        if (numCameras > 1)
            rotateCamButton.setEnabled(true);
        captureButton.setImageResource(R.drawable.tap_for_photo_normal);
        timerCountDownTV.setText("- 25 sec");
        releaseMediaRecorder();
        Log.d(TAG, "Calling gama");
        if (time_elapsed_for_vid <= 1) {
            finishActivity(RESULT_CANCELED, videoFilePath);
            Toast.makeText(this, R.string.recorded_vid_is_empty, Toast.LENGTH_SHORT).show();
            return;

        }
        finishActivity(RESULT_OK, videoFilePath);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mScaleDetector.onTouchEvent(event);
        return true;
    }

    private void finishActivity(int resultCode, String filePath) {
        releaseCamera();
        Intent returnIntent = new Intent();
        if (TextUtils.isEmpty(filePath)) {
            resultCode = RESULT_CANCELED;
            setResult(resultCode, returnIntent);
            finish();
            return;
        }
        if (resultCode == RESULT_OK) {
            SelectedMediaDataHolder.add(filePath);
            CaptionSetterActivity.start(FullscreenCameraCaptureActivity.this);
            finish();
        } else if (resultCode == RESULT_CANCELED) {
            finish();
        }

    }

    @Override
    public void onBackPressed() {
        finishActivity(RESULT_CANCELED, null);
        super.onBackPressed();
    }

    private void rotateCamera() {

        try {
            if (isRecording) {
                return;
            }
            releaseCamera();
            currentCameraID = (currentCameraID == Camera.CameraInfo.CAMERA_FACING_BACK) ? Camera.CameraInfo.CAMERA_FACING_FRONT : Camera.CameraInfo.CAMERA_FACING_BACK;
            camera = Camera.open(currentCameraID);
            if (camera != null) {
                startCameraPreview();
            } else {
                Log.e(TAG, "CAMERA switching failed! Camera NULL");
            }
        } catch (Exception e) {
            finishActivity(RESULT_CANCELED, null);
            Log.e(TAG, "CAMERA switching failed!");
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.d(TAG, "surfaceCreated()");
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int i, int i1, int i2) {
        if (cameraPreviewResized) {
            cameraPreviewResized = false;
        } else {
            this.surfaceHolder = holder;
            Log.d(TAG, "surfaceChanged()");
            initCamera();
            if (captureMode == VIDEO_CAPTURE)
                prepareRecorder(videoFilePath);
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceDestroyed()");
        if (captureMode == VIDEO_CAPTURE) {
            if (isRecording) {
                releaseMediaRecorder();
                isRecording = false;
            }
        }
        releaseCamera();
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    private void reInitializeCamera() {
        releaseCamera();
        initCamera();
    }

    private boolean openCamera() {
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }
        try {
            if (currentCameraID == -1) {
                if (isCameraPresent(Camera.CameraInfo.CAMERA_FACING_BACK)) {
                    currentCameraID = Camera.CameraInfo.CAMERA_FACING_BACK;
                } else if (isCameraPresent(Camera.CameraInfo.CAMERA_FACING_FRONT)) {
                    currentCameraID = Camera.CameraInfo.CAMERA_FACING_FRONT;
                } else {
                    Log.e(TAG, "No camera available");
                }
            }
            camera = Camera.open(currentCameraID);
            return camera != null;

        } catch (Exception exception) {
            finishActivity(RESULT_CANCELED, null);
            Log.e(TAG, "Can't open camera with id " + currentCameraID, exception);
            exception.printStackTrace();
            return false;
        }
    }

    private void initCamera() {
        if (openCamera())
            startCameraPreview();
        else
            Log.e(TAG, "Failed to init camera!");
    }

    private void setCaptureMode(int mode) {
        captureMode = mode;
        reInitializeCamera();
    }

    private synchronized void startCameraPreview() {
        try {
            int displayOrientation = determineDisplayOrientation();
            camera.stopPreview();
            camera.setDisplayOrientation(displayOrientation);

            Camera.Parameters params = camera.getParameters();
            params.setRotation(displayOrientation);

            if (captureMode == IMAGE_CAPTURE) {
//                Camera.Size bestPreviewSize = determineBestPreviewSize(params);
                List<Camera.Size> sizes = params.getSupportedPreviewSizes();
                Camera.Size bestPreviewSize = null;

                for (Camera.Size currentSize : sizes) {
//                    boolean isDesiredRatio = (currentSize.width / 4) == (currentSize.height / 3);
                    boolean isBetterSize = (bestPreviewSize == null || currentSize.width > bestPreviewSize.width);
                    boolean isInBounds = currentSize.width <= PICTURE_SIZE_MAX_WIDTH;

                    if (isInBounds && isBetterSize) {
                        bestPreviewSize = currentSize;
                    }
                }

                if (bestPreviewSize == null) {

                    bestPreviewSize = sizes.get(0);
                }

                cameraPreview.getLayoutParams().width = bestPreviewSize.width;
//                cameraPreview.getLayoutParams().height = bestPreviewSize.height;

                Camera.Size bestPictureSize = determineBestPictureSize(params);

                params.setPreviewSize(bestPreviewSize.width, bestPreviewSize.height);
                params.setPictureSize(bestPictureSize.width, bestPictureSize.height);
//                Toast.makeText(this,"PreviewSize: " + bestPreviewSize.width + "x" + bestPreviewSize.height +
//                        ". PictureSize: " + bestPictureSize.width + "x" + bestPictureSize.height, Toast.LENGTH_LONG).show();
            } else {

                camcorderProfile = CamcorderProfile.get(currentCameraID, camcorderProfileName);
                params.setPreviewSize(camcorderProfile.videoFrameWidth, camcorderProfile.videoFrameHeight);
                params.setRecordingHint(true);
            }
            cameraPreviewResized = true;
            resizeVideoPreview(params.getPreviewSize().width, params.getPreviewSize().height);
            if (captureMode == IMAGE_CAPTURE) {
                if (params.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                }
            } else {
                if (params.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) {
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
                }
            }

            if (isFlashLightAvailable && isFLashEnabled)
                params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
            camera.lock();
            camera.setParameters(params);
            camera.setPreviewDisplay(surfaceHolder);
            camera.unlock();
            camera.reconnect();
            camera.startPreview();

//            currentZoomLevel = params.getZoom();
//            if (params.isZoomSupported()) {
//                maxZoomLevel = params.getMaxZoom();
//                Log.i("Bulbul", "Max zoom is " + maxZoomLevel);
//            } else {
//                maxZoomLevel = -1;
//                Log.e("Bulbul", "Zoom not supported in this mode");
//            }
            Log.d(TAG, "Camera Preview Set");
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(TAG, "Can't start camera preview due to IOException", exception);
            finishActivity(RESULT_CANCELED, null);
        }
    }

    private void releaseCamera() {
        if (camera != null) {
            Log.w(TAG, "releasing Camera");
            camera.lock();
            camera.stopPreview();
            camera.release();
            camera = null;
        }
    }

    private Camera.Size determineBestPictureSize(Camera.Parameters parameters) {
        List<Camera.Size> sizes = parameters.getSupportedPictureSizes();

        return determineBestSize(sizes);
    }

    private Camera.Size determineBestSize(List<Camera.Size> sizes) {
        Camera.Size bestSize = null;

        for (Camera.Size currentSize : sizes) {
            boolean isDesiredRatio = (currentSize.width / 4) == (currentSize.height / 3);
            boolean isBetterSize = (bestSize == null || currentSize.width > bestSize.width);
            boolean isInBounds = currentSize.width <= PICTURE_SIZE_MAX_WIDTH;

            if (isDesiredRatio && isInBounds && isBetterSize) {
                bestSize = currentSize;
            }
        }

        if (bestSize == null) {

            return sizes.get(0);
        }

        return bestSize;
    }

    private Bitmap RotateBitmap(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    //==================================== VIDEO CAPTURE METHODS ===============================================
    private void releaseMediaRecorder() {
        if (recorder != null) {
            try {
                recorder.reset();   // clear recorder configuration
                recorder.release(); // release the recorder object
                recorder = null;

                if (camera != null) {
                    camera.stopPreview();
                    camera.lock();
                    camera.release();
                    camera = null;
                }

                camera = Camera.open(currentCameraID);
                if (camera != null) {
                    startCameraPreview();
                } else {
                    Log.e(TAG, "camera is null");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {


        if (camera != null) {
            camera.stopPreview();
            camera.lock();
            camera.release();
            camera = null;
            Log.d("Abhi", "Released Camera");
        }

        super.onDestroy();
    }

    private void startVideoRecording(String filePath) {
        prepareRecorder(filePath);
        isRecording = true;
        recorder.start();
        Log.i(TAG, "Recording started! Filepath: " + filePath);
    }

    private void stopVideoRecording() {
        if (isRecording) {
            try {
                recorder.stop();
                Log.i(TAG, "Recording stopped!");
                releaseMediaRecorder();
                startCameraPreview();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        isRecording = false;
//        Toast.makeText(this, "Recording stopped..", Toast.LENGTH_SHORT).show();
//        Log.i(TAG, "file path: " + videoOutputFilePath);
    }

    private void prepareRecorder(String filePath) {
        Log.i(TAG, "in prepareRecorder function");
        recorder = new MediaRecorder();
        camera.unlock();
        recorder.setCamera(camera);

        recorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
        recorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

        Log.d(TAG, "cameraID: " + currentCameraID + "camcorderProfileName: " + camcorderProfileName);
        camcorderProfile = CamcorderProfile.get(currentCameraID, camcorderProfileName);
        recorder.setProfile(camcorderProfile);
        recorder.setOutputFile(filePath);

        recorder.setPreviewDisplay(surfaceHolder.getSurface());

        int displayOrientation = determineDisplayOrientation();
        Log.i(TAG, "rotaiton : " + displayOrientation);
        if (currentCameraID == Camera.CameraInfo.CAMERA_FACING_FRONT)
            displayOrientation = (displayOrientation + 180) % 360;
        recorder.setOrientationHint(displayOrientation);
        try {
            recorder.prepare();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int determineDisplayOrientation() {
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(currentCameraID, cameraInfo);

        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees = 0;

        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;

            case Surface.ROTATION_90:
                degrees = 90;
                break;

            case Surface.ROTATION_180:
                degrees = 180;
                break;

            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int displayOrientation;

        if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            displayOrientation = (cameraInfo.orientation + degrees) % 360;
            displayOrientation = (360 - displayOrientation) % 360;
        } else {
            displayOrientation = (cameraInfo.orientation - degrees + 360) % 360;
        }

        return displayOrientation;
    }

    private void resizeVideoPreview(int width, int height) {
        double measuredWidth, measuredVideoWidth;
        double measuredHeight, measuredVideoHeight;
        WindowManager w = getWindowManager();

        Point size = new Point();
        w.getDefaultDisplay().getSize(size);
        measuredWidth = size.x;
        measuredHeight = size.y;
        int marginLR = 0;
        int marginTB = 0;

        if (cameraPreview != null) {

            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) cameraPreview.getLayoutParams();

            double displayRatio = measuredHeight / measuredWidth;       //Portrait mode height>width
            double imageRatio = width * 1.0 / height;

            Log.i("Bulbul", "image Ratio: width/height: " + imageRatio + " width: " + width + " height: " + height + " display ratio: " + displayRatio);

            if (imageRatio < displayRatio) {
                measuredVideoHeight = measuredHeight;
                measuredVideoWidth = measuredHeight / imageRatio;
                if (measuredVideoWidth > measuredWidth) {
                    marginLR = (int) (measuredVideoWidth - measuredWidth) / 2;
                }
            } else {
                measuredVideoWidth = measuredWidth;
                measuredVideoHeight = measuredWidth * imageRatio;
                if (measuredVideoHeight > measuredHeight) {
                    marginTB = (int) (measuredVideoHeight - measuredHeight) / 2;
                }
            }

            lp.width = (int) measuredVideoWidth;
            lp.height = (int) measuredVideoHeight;

            Log.i("Bulbul", "After Conversion: Width: " + lp.width + " Height: " + lp.height);

            lp.setMargins(-marginLR, -marginTB, -marginLR, -marginTB);

            cameraPreview.setLayoutParams(lp);
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri queryUri = MediaStore.Files.getContentUri("external");

        String[] projection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.TITLE,
                MediaStore.Files.FileColumns.SIZE
        };

        String selection = "(" + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                + ") AND ("
                + MediaStore.Files.FileColumns.SIZE + " > 0 )";


        return new CursorLoader(
                FullscreenCameraCaptureActivity.this,
                queryUri,
                projection,
                selection,
                null,
                MediaStore.Files.FileColumns.DATE_ADDED + " DESC"
        );
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        Log.d(TAG, "Cursor size for gallery " + data.getCount());
        if (data.getCount() > 0) {
            Log.d(TAG, "Set recycle view as visible");
            mRecyclerView.setVisibility(View.VISIBLE);
//            mNoImageFoundTextView.setVisibility(View.GONE);
        }
        mAdapter.swapCursor(data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getSupportLoaderManager().initLoader(0, null, this);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
    }

    public class ImageGalleryAdapter extends RecyclerView.Adapter<ImageGalleryAdapter.ViewHolder> {
        private Cursor mCursor;
        private final int imageWidth;
        private final int imageHeight;

        boolean[] selected = new boolean[1];

        ImageGalleryAdapter(int imageWidth, int imageHeight) {

            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
        }

        @Override
        public ImageGalleryAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // initialize a new view
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_gallery_item, parent, false);

            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ImageGalleryAdapter.ViewHolder holder, int position) {

            mCursor.moveToPosition(position);
            try {
//                Log.d(TAG, "Image data " + mCursor.getString(mCursor.getColumnIndex(MediaStore.Images.Media.DATA)));
                holder.mImageFilepath = mCursor.getString(mCursor.getColumnIndex(MediaStore.Files.FileColumns.DATA));
                int mediaType = mCursor.getInt(mCursor.getColumnIndex(MediaStore.Files.FileColumns.MEDIA_TYPE));

                if (mediaType == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) {
                    holder.mVideoIconOverlay.setVisibility(View.VISIBLE);
                } else {
                    holder.mVideoIconOverlay.setVisibility(View.GONE);
                }
                Glide.with(FullscreenCameraCaptureActivity.this)
                        .load(holder.mImageFilepath)
                        .centerCrop()
                        .crossFade()
                        .error(R.drawable.invalid_image_file)
                        .into(holder.mImageView);

                if (selected[position]) {
                    Log.d(TAG, "Selected item position in onBindViewHolder " + position);
                    holder.mImageSend.setVisibility(View.VISIBLE);
                    holder.mSelectedBackground.setVisibility(View.VISIBLE);
                } else {
                    holder.mImageSend.setVisibility(View.GONE);
                    holder.mSelectedBackground.setVisibility(View.GONE);
                }


            } catch (Exception e) {

                Log.e(TAG, "Exception with glide " + e.getMessage());
            }


        }

        @Override
        public int getItemCount() {

            if (mCursor != null) {
                return mCursor.getCount();
            }
            return 0;
        }

        public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            // each data item is just a string in this case

            final ImageView mImageView;
            final ImageView mImageSend;
            final View mSelectedBackground;
            String mImageFilepath;
            final ImageView mVideoIconOverlay;

            ViewHolder(View v) {
                super(v);

                mImageView = v.findViewById(R.id.imageViewItem);
                mImageSend = v.findViewById(R.id.imageButtonImageSend);
                mSelectedBackground = v.findViewById(R.id.imageItemBackground);
                mVideoIconOverlay = v.findViewById(R.id.video_icon_overlay);
                ViewGroup.LayoutParams layoutParams = mSelectedBackground.getLayoutParams();
                layoutParams.height = imageHeight;
                layoutParams.width = imageWidth;
                mSelectedBackground.setLayoutParams(layoutParams);

                mImageSend.setOnClickListener(this);
                LinearLayout.LayoutParams ImageLayoutParams = new LinearLayout.LayoutParams(imageWidth, imageHeight);
                mImageView.setLayoutParams(ImageLayoutParams);
                mImageView.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {

                switch (view.getId()) {
                    case R.id.imageViewItem:
                        selected[getAdapterPosition()] ^= true;
                        SelectedMediaDataHolder.add(mImageFilepath);
                        CaptionSetterActivity.start(FullscreenCameraCaptureActivity.this);
                        finish();
                        break;
                    default:
                        break;
                }
            }
        }

        void swapCursor(Cursor cursor) {
            mCursor = cursor;
            if (cursor != null)
                selected = new boolean[cursor.getCount()];
            notifyDataSetChanged();
        }

        public void clearSelection() {
            if (selected != null) {
                for (int i = 0; i < selected.length; i++) {
                    selected[0] = false;
                }
            }
            notifyDataSetChanged();
        }
    }

    private void startConfirmationActivity(String mImageFilepath) {

        Intent intent = new Intent(FullscreenCameraCaptureActivity.this, MediaSendConfirmationActivity.class);
        intent.putExtra("filepath", mImageFilepath);
        intent.putExtra("isMultipleImageEnabled", false);
        startActivity(intent);
        finish();
    }

}
