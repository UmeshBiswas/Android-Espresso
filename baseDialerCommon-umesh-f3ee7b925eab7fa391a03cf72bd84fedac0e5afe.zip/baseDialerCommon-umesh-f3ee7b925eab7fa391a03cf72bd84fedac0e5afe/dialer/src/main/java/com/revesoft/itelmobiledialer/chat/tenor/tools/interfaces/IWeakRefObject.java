package com.revesoft.itelmobiledialer.chat.tenor.tools.interfaces;



import java.lang.ref.WeakReference;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public interface IWeakRefObject<CTX> {

    @Nullable
    CTX getRef();

    @NonNull
    WeakReference<CTX> getWeakRef();

    boolean hasRef();
}
