package com.revesoft.itelmobiledialer.braodcast;

import android.content.Context;
import android.content.Intent;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Ifta on 10/19/2017.
 */

public class QuickBroadCaster {
    private static LocalBroadcastManager localBroadcastManager = null;
    public static void initialize(Context context){
        localBroadcastManager = LocalBroadcastManager.getInstance(context);
    }

    public static void broadcast(Intent intent){
        localBroadcastManager.sendBroadcast(intent);
    }

}
