package com.revesoft.itelmobiledialer.appDatabase.repo;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.LocationRequest;

import java.util.Date;
import java.util.List;

public class LocationRequestRepo {
    private static final LocationRequestRepo ourInstance = new LocationRequestRepo();

    public static LocationRequestRepo get() {
        return ourInstance;
    }

    private LocationRequestRepo() {
    }


    public List<LocationRequest> getAll() {
        return AppDatabase.get().locationRequestDao().getAll();
    }


    public void insertAll(List<LocationRequest> locationRequestList) {
        AppDatabase.get().locationRequestDao().insertAll(locationRequestList);
    }


    public long expireTime(String phoneNumber) {
        return AppDatabase.get().locationRequestDao().expireTime(phoneNumber);
    }

    public long createOrUpdate(String number, long expireTime) {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest._id = 123;
        locationRequest.number = number;
        locationRequest.locationRequestExpireTime = new Date(expireTime);
        return AppDatabase.get().locationRequestDao().insert(locationRequest);
    }
}
