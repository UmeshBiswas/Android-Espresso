package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.DID;

import java.util.List;

public class DIDRepo {
    private static final DIDRepo ourInstance = new DIDRepo();

    public static DIDRepo get() {
        return ourInstance;
    }

    private DIDRepo() {
    }

    public List<DID> getAll() {
        return AppDatabase.get().didDao().getAll();
    }


    public void createUserDidEntry(com.revesoft.itelmobiledialer.did.DID did) {

        AppDatabase.get().didDao().insert(DID.createAppDatabaseDID(did));
    }

    public void removeUserDidEntry(com.revesoft.itelmobiledialer.did.DID did) {
        AppDatabase.get().didDao().delete(DID.createAppDatabaseDID(did));
    }


    public Cursor getUserDIDsCursor() {
        return AppDatabase.get().didDao().getUserDIDsCursor();
    }
}
