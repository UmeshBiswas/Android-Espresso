package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.media.RingtoneManager;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;
import com.revesoft.itelmobiledialer.appDatabase.entities.CustomNotificationParam;
import com.revesoft.itelmobiledialer.notification.AppNotificationManagement;


/**
 * Created By suvo on February 27, 2019
 * Project baseDialerCommon
 **/

public class CustomNotificationParamRepo {
    private static final CustomNotificationParamRepo ourInstance = new CustomNotificationParamRepo();

    private CustomNotificationParamRepo() {
    }

    public static CustomNotificationParamRepo get() {
        return ourInstance;
    }


    public boolean isCustomNotificationEnable(String target) {
        return AppDatabase.get().customNotificationParamsDao().isCustomNotificationEnable(target);
    }

    public boolean isCustomNotificationExists(String target) {
        return AppDatabase.get().customNotificationParamsDao().isCustomNotificationExists(target);
    }


    public CustomNotificationParam getEnabledNotificationParam(String target) {
        if (isCustomNotificationEnable(target))
            return AppDatabase.get().customNotificationParamsDao().getCustomNotificationParam(target);
        else return getDefaultNotificationParam();

    }


    public CustomNotificationParam getCustomNotificationParam(String target) {
        if (isCustomNotificationExists(target))
            return AppDatabase.get().customNotificationParamsDao().getCustomNotificationParam(target);
        else return getDefaultNotificationParam();
    }

    public CustomNotificationParam getDefaultNotificationParam() {
        return AppDatabase.get().customNotificationParamsDao().
                getCustomNotificationParam(AppDatabaseDefault.DEFAULT_CUSTOM_NOTIFICATION_TARGET);
    }


    public void createDefaultNotificationParam() {

        CustomNotificationParam param = CustomNotificationParam.newBuilder().target(AppDatabaseDefault.DEFAULT_CUSTOM_NOTIFICATION_TARGET)
                .callRingTone(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE).toString())
                .callVibrationMode(1)
                .messageRingTone(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION).toString())
                .messageVibrationMode(1)
                .popUpNotification(true)
                .notificationChannelID(AppNotificationManagement.DEFAULT_IM_NOTIFICATION_CHANNEL_ID)
                .build();
        AppDatabase.get().customNotificationParamsDao().insert(param);
    }


    public void update(CustomNotificationParam param) {
        AppDatabase.get().customNotificationParamsDao().update(param);
    }


    public void insert(CustomNotificationParam param) {
        AppDatabase.get().customNotificationParamsDao().insert(param);
    }


}
