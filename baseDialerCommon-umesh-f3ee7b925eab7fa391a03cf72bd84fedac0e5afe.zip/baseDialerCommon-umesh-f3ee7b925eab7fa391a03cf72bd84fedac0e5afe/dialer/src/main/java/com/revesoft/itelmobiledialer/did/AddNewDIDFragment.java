package com.revesoft.itelmobiledialer.did;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.hbb20.CountryCodePicker;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.DIDRepo;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Country;
import com.revesoft.itelmobiledialer.util.CountryInfoProvider;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.res.ResourcesCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static android.content.Context.MODE_PRIVATE;
import static com.revesoft.itelmobiledialer.util.Constants.PHONE;

/**
 * Created by Rahat on 9/14/2017.
 */

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class AddNewDIDFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener, OnDidResponseListener, OnDoNotDisturbListener {

    private static final int INVALID_REQUEST_TYPE = -1;
    private final int SERVICE_TYPE_COUNTRY = 3;
    private final int SERVICE_TYPE_STATES = 4;
    private final int SERVICE_TYPE_CITIES = 5;


    private LinearLayout rootLayout;
    private DIDAvailAbleNumbersAdapter didAvailAbleNumbersAdapter;
    private TextView selectedCountryNameTv;
    private int selectedCountryFlag;
    private String selectedCountryName;
    private ListView availableDIDNumbersListView;
    private String TAG = "AddNewDIDFragment";
    private String[] countryNames;
    private int[] countryFlags;
    private ArrayList<DID> didList;
    private boolean isDialogVisible;
    private int selectedCountryPos = -1;
    private CountryCodePicker ccp;
    View v;
    private boolean didChanged;
    private Spinner spinnerStates, spinnerCity;
    private List<String> statesList = new ArrayList<>();
    private List<String> statesCode = new ArrayList<>();

    private List<String> citiesList = new ArrayList<>();
    private List<String> citiesCode = new ArrayList<>();

    ArrayAdapter<String> dataAdapterStates, dataAdapterCities;
    AddNewDIDFragment addNewDIDFragment;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addNewDIDFragment = this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_add_new_did_number, container, false);
        init(v);
        initListeners();

        if (Util.isNetworkAvailable(getActivity()))
            new DIDAsyncTask(SERVICE_TYPE_COUNTRY, -1, "", getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        else Util.showNoNetworkDialog(getActivity());
        return v;
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: ");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: ");

    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");
    }

    private void initListeners() {
        rootLayout.setOnClickListener(this);
    }

    private void init(View v) {
        rootLayout = v.findViewById(R.id.root_layout);
        selectedCountryNameTv = v.findViewById(R.id.country_name_textview);
        availableDIDNumbersListView = v.findViewById(R.id.buy_number_listview);
        didList = new ArrayList<>();
        didAvailAbleNumbersAdapter = new DIDAvailAbleNumbersAdapter(didList);
        availableDIDNumbersListView.addFooterView(new View(getActivity()), null, true);
        availableDIDNumbersListView.addHeaderView(new View(getActivity()), null, true);
        availableDIDNumbersListView.setAdapter(didAvailAbleNumbersAdapter);

        spinnerCity = v.findViewById(R.id.spinner_city);
        dataAdapterCities = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, citiesList);
        dataAdapterCities.setDropDownViewResource(R.layout.simple_spinner_dropdown_item);
        spinnerCity.setAdapter(dataAdapterCities);

        spinnerStates = v.findViewById(R.id.spinner_state);
        dataAdapterStates = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, statesList);
        dataAdapterStates.setDropDownViewResource(R.layout.simple_spinner_dropdown_item);
        spinnerStates.setAdapter(dataAdapterStates);
        spinnerStates.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                new DIDAsyncTask(SERVICE_TYPE_CITIES, -1, ccp.getSelectedCountryName(), statesCode.get(position),
                        getActivity(), addNewDIDFragment).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                new DIDAsyncTask(2, 2, ccp.getSelectedCountryName(), citiesCode.get(position),
                        getActivity(), addNewDIDFragment).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    @Override
    public void onClick(View view) {

    }

    private boolean hasSufficientBalance(String balance, String didRate) {
        if (TextUtils.isEmpty(balance) || TextUtils.isEmpty(didRate)) return false;

        try {
            Double balanceDbl = Double.parseDouble(balance);
            Double didRateDbl = Double.parseDouble(didRate);
            return balanceDbl > didRateDbl;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void showBuyConfirmationDialog(final DID did) {
        if (isDialogVisible) return;
        isDialogVisible = true;
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.buy_confirmation);
        builder.setPositiveButton(R.string.ok_button, (dialog1, which) -> {
            if (!Util.isNetworkAvailable(getActivity())) {
                Util.showNoNetworkDialog(getActivity());
                return;
            }
            new DIDAsyncTask(2, 5, did, getActivity(), ccp.getSelectedCountryName(), AddNewDIDFragment.this).execute();
            dialog1.dismiss();

        });
        builder.setNegativeButton(R.string.button_cancel, (dialog13, which) -> dialog13.dismiss());
        builder.setOnDismissListener(dialog12 -> isDialogVisible = false);
        builder.create().show();
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        Spinner spinner = (Spinner) adapterView;
    }

    @Override
    public void onCountryListResponse(String[] countryNames, int[] countryFlags) {
        v.findViewById(R.id.ll_states).setVisibility(View.GONE);
        v.findViewById(R.id.ll_city).setVisibility(View.GONE);

        this.countryNames = countryNames;
        this.countryFlags = countryFlags;
        String customCountriesISO = "";
        for (int i = 0; i < countryNames.length; i++) {
            Country country = CountryInfoProvider.countryNameToCountry.get(countryNames[i]);
            if (country != null) {
                if (i != 0) customCountriesISO = customCountriesISO.concat(",");
                customCountriesISO = customCountriesISO.concat(country.isoCode);
            }
        }
        if (TextUtils.isEmpty(customCountriesISO)) {
            v.findViewById(R.id.ccp).setVisibility(View.GONE);
            Toast.makeText(getActivity(), R.string.did_not_available, Toast.LENGTH_LONG).show();
            return;
        }
        didList.clear();
        if (countryNames != null && countryNames.length > 0) {
            handleCountryCodePicker(v, customCountriesISO);
            didAvailAbleNumbersAdapter.notifyDataSetChanged();
//            new DIDAsyncTask(SERVICE_TYPE_STATES, -1,
//                    ccp.getSelectedCountryName(), getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
//            new DIDAsyncTask(2, 2,
//                    ccp.getSelectedCountryName(), getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            Toast.makeText(getActivity(), getActivity().getString(R.string.failed), Toast.LENGTH_SHORT).show();
            getActivity().finish();
        }

    }

    @Override
    public void onStatesListResponse(String[] stateNames, String[] stateCode) {
        if (stateNames != null)
            Log.d(TAG, "Size of statelist: " + stateNames.length);
        if (stateNames != null && stateCode != null) {
            statesList.clear();
            statesCode.clear();
            for (int i = 0; i < stateNames.length; i++) {
                statesList.add(stateNames[i]);
                statesCode.add(stateCode[i]);
            }
            dataAdapterStates.notifyDataSetChanged();
            if (stateNames.length > 0)
                v.findViewById(R.id.ll_states).setVisibility(View.VISIBLE);
            else
                v.findViewById(R.id.ll_states).setVisibility(View.GONE);
        }
//        if(stateCode != null && stateCode.length >0)
//        new DIDAsyncTask(SERVICE_TYPE_CITIES, -1, ccp.getSelectedCountryName(), stateCode[0],
//                getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    @Override
    public void onCityListResponse(String[] cityNames, String[] cityCode) {
        if (cityNames != null)
            Log.d(TAG, "Size of statelist: " + cityNames.length);
        if (cityNames != null && cityCode != null) {
            citiesCode.clear();
            citiesList.clear();
            for (int i = 0; i < cityNames.length; i++) {
                citiesList.add(cityNames[i]);
                citiesCode.add(cityCode[i]);
            }
            dataAdapterCities.notifyDataSetChanged();
        }
        if (cityNames.length > 0)
            v.findViewById(R.id.ll_city).setVisibility(View.VISIBLE);
        else
            v.findViewById(R.id.ll_city).setVisibility(View.GONE);

        if (cityCode != null && cityCode.length > 0)
            new DIDAsyncTask(2, 2, ccp.getSelectedCountryName(), cityCode[0],
                    getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    @Override
    public void onDIDListResponse(ArrayList<DID> dids) {
        if (dids != null) {
            this.didList = dids;
            didAvailAbleNumbersAdapter = new DIDAvailAbleNumbersAdapter(didList);
            availableDIDNumbersListView.setAdapter(didAvailAbleNumbersAdapter);
        } else {
            Toast.makeText(getActivity(), R.string.insufficient_balance, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onUsersDidListResponse(ArrayList<DID> dids) {
    }

    @Override
    public void onBuyUsersDID(DID did) {
        if (did == null) {
            getActivity().finish();
            return;
        }
        SharedPreferences preferences = getActivity().getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
        String userName = UserDataManager.getUserName();
        did.setForwardedNumber(userName);
        Executor.ex(() -> {
            DIDRepo.get().createUserDidEntry(did);
            Gui.get().run(() -> didAvailAbleNumbersAdapter.notifyDataSetChanged());

        });


        preferences.edit().putString(PHONE, did.getDidNumber()).commit();
        preferences.edit().putString(Constants.SELECTED_DID_ID, did.getDidID()).commit();

        unregisterSipProvider();
        SIPProvider.registrationFlag = false;
        restartRegistration();
        Toast.makeText(getActivity(), getString(R.string.called_id_changed) + " " + did.getDidNumber(), Toast.LENGTH_SHORT).show();
        //showCustomizedToast("Called ID changed to: " + didNumber);
        new DIDAsyncTask(SERVICE_TYPE_COUNTRY, -1, selectedCountryName, getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);


        //disabling donotdisturb by default
        new DoNotDisturbAsynctask(7, 1, getActivity(), AddNewDIDFragment.this, did.getDidID(), false).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        //setting own pin as forwarded number
       /* DID newDid = new DID(did.getDidID(), did.getDidOwner(), did.getDidNumber(), userName, did.getExpireDate());
        new DIDAsyncTask(2, 3, newDid, getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);*/
        new DIDAsyncTask(2, 1, "", getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        didChanged = true;

    }

    private void handleCountryCodePicker(View v, String customCountriesISO) {
        ccp = v.findViewById(R.id.ccp);
        ccp.setCustomMasterCountries(customCountriesISO);
        ccp.setCcpDialogShowNameCode(true);
        ccp.setCcpDialogShowPhoneCode(true);
        Typeface typeface = ResourcesCompat.getFont(getActivity(), R.font.harmonia);
        ccp.getTextView_selectedCountry().setTypeface(typeface);
        ccp.setOnCountryChangeListener(() -> {
            if (didList != null) {
                didList.clear();
                didAvailAbleNumbersAdapter.notifyDataSetChanged();
            }
            new DIDAsyncTask(2, 2,
                    ccp.getSelectedCountryName(), getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
//            new DIDAsyncTask(4, -1, ccp.getSelectedCountryName(), getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        });
        if (customCountriesISO.contains("us"))
            ccp.setCountryForNameCode("us");
        else if (customCountriesISO.contains("US"))
            ccp.setCountryForNameCode("US");
        else ccp.setCountryForNameCode(customCountriesISO.split(",")[0]);
    }

    private synchronized void unregisterSipProvider() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.SEND_UNREGISTER, "");
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(i);
    }

    private synchronized void restartRegistration() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.START_REGISTRATION, "");
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(i);
    }

    private synchronized void restartSipProvider() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.START_REGISTRATION, "");
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(i);
    }

    @Override
    public void onUnsubscribeDid(DID selectedDID) {
        didAvailAbleNumbersAdapter.notifyDataSetChanged();

        SharedPreferences pref = getActivity().getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, MODE_PRIVATE);
        if (pref.getString(PHONE, UserDataManager.getUserName()).equals(selectedDID.getDidNumber())) {
            pref.edit().putString(PHONE, UserDataManager.getUserName()).commit();
            restartSipProvider(); // 31-10-2017
        }
    }

    @Override
    public void onForwardedNumberSet(String forwardedNumber) {
        if (forwardedNumber.isEmpty()) {
            Toast.makeText(getActivity(), getString(R.string.call_forwarding_disabled), Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(getActivity(), getString(R.string.call_forwarding_enabled), Toast.LENGTH_SHORT).show();
        }
        new DIDAsyncTask(2, 1, "", getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

    }

    @Override
    public void onEnable(boolean showToast) {

    }

    @Override
    public void onDisable(boolean showToast) {

    }

    @Override
    public void onFailed(boolean showToast) {

    }

    @Override
    public void setSwitchStatus(String status) {
    }

    private class DIDAvailAbleNumbersAdapter extends BaseAdapter {
        private ArrayList<DID> numbers;

        public DIDAvailAbleNumbersAdapter(ArrayList<DID> numbers) {
            this.numbers = numbers;
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return numbers.size();
        }

        @Override
        public DID getItem(int position) {
            // TODO Auto-generated method stub
            return numbers.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View rowView = convertView;
            NumberViewHolder viewHolder;
            if (rowView == null) {

                LayoutInflater inflater = getActivity().getLayoutInflater();
                rowView = inflater.inflate(R.layout.add_new_did_list_item, null);
                viewHolder = new NumberViewHolder();
                viewHolder.numberTv = rowView.findViewById(R.id.did_item_number);
                viewHolder.buyBtn = rowView.findViewById(R.id.btn_did_buy);
                viewHolder.costTv = rowView.findViewById(R.id.did_item_cost);
                rowView.setTag(viewHolder);
            } else {
                viewHolder = (NumberViewHolder) convertView.getTag();
            }
            viewHolder.buyBtn.setOnClickListener(v -> {
                DID did = didList.get(position);
                String currentBalance = SIPProvider.currentBalance;
                String didRate = did.getRate();
                if (hasSufficientBalance(currentBalance, didRate)) {
                    showBuyConfirmationDialog(did);
                } else
                    Toast.makeText(getActivity(), R.string.insuffient_balance_title, Toast.LENGTH_SHORT).show();

            });
            viewHolder.numberTv.setText(didList.get(position).getDidNumber());
            viewHolder.costTv.setText(getString(R.string.cost) + ": " + didList.get(position).getRate());
            if (TextUtils.isEmpty(didList.get(position).getDidNumber()) || didList.get(position).getDidNumber().startsWith("0.0"))
                viewHolder.numberTv.setVisibility(View.GONE);
            else viewHolder.numberTv.setVisibility(View.VISIBLE);
            return rowView;
        }

        private void showUnsubscribeConfirmationDialog(final DID did) {

            if (isDialogVisible) return;

            isDialogVisible = true;
            final Dialog dialog = new Dialog(getActivity());
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.buy_confirmation_dialog);
            TextView number = dialog.findViewById(R.id.number);
            number.setText(did.getDidNumber());
            TextView confirmationText = dialog.findViewById(R.id.title);
            confirmationText.setText("Do you want to unsubscribe the number: ");

            dialog.findViewById(R.id.ok_btn).setOnClickListener(view -> {
                //new DIDAsyncTask(2, 4, did, getActivity(), GlobalNumberFragment.this).ex();
                dialog.dismiss();

            });
            dialog.findViewById(R.id.cancel_btn).setOnClickListener(view -> dialog.dismiss());
            dialog.setOnDismissListener(dialogInterface -> isDialogVisible = false);
            dialog.show();


        }

    }

    private static class NumberViewHolder {

        public TextView numberTv;
        public AppCompatButton buyBtn;
        public TextView costTv;
    }

}

