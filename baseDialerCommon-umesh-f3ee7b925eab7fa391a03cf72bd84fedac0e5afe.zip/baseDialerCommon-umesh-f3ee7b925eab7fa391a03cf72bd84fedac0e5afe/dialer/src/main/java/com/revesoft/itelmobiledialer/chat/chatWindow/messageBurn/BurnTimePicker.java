package com.revesoft.itelmobiledialer.chat.chatWindow.messageBurn;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.BurnMessageInfoRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.customview.Rotate3dAnimation;
import com.revesoft.itelmobiledialer.customview.SmoothScrollLinearLayoutManager;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ScrollManager;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Nazmul  on 10/19/2017.
 * moved to different package by Ifta
 */

public class BurnTimePicker {
    private static int burnTimerSelectionIndex = 0;
    private static float centerX = 0;
    private static float centerY = 0;

    public static void showBurnTimePicker(Context context, String target) {
        final int rowHeight = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, Supplier.getDisplayMetrics());
        final Dialog burnTimerDialog = new Dialog(context);
        burnTimerDialog.setContentView(R.layout.burn_timer_dialog);
        Window window = burnTimerDialog.getWindow();
        if(window!=null){
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
        }
        if (burnTimerDialog.getWindow() != null) {
            burnTimerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        View llOpenSmokeChat = burnTimerDialog.findViewById(R.id.llOpenSmokeChat);
        llOpenSmokeChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Switcher.switchToSendConfideChat(context, Target.target);
                burnTimerDialog.dismiss();
            }
        });

        final RecyclerView mRecyclerView =  burnTimerDialog.findViewById(R.id.burn_timer_list);
        final SmoothScrollLinearLayoutManager mLayoutManager = new SmoothScrollLinearLayoutManager(context);
        mLayoutManager.init(context);
        mRecyclerView.setLayoutManager(mLayoutManager);

        final BurnTimerListAdapter mBurnTimerListAdapter = new BurnTimerListAdapter(context);
        mRecyclerView.setAdapter(mBurnTimerListAdapter);

        Executor.ex(() -> {
            burnTimerSelectionIndex = BurnMessageInfoRepo.get().getBurnTimerIndex(target);
            Gui.get().run(() -> {
                if (burnTimerSelectionIndex == -1) {
                    burnTimerSelectionIndex = Integer.MAX_VALUE / 2;
                }

                mLayoutManager.scrollToPosition(burnTimerSelectionIndex - 1);

                mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                    int currentPosY = 0;
                    boolean positionChanged = false;
                    int yDelta;

                    @Override
                    public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                        super.onScrollStateChanged(recyclerView, newState);
                        if (newState == ScrollManager.SCROLL_STATE_TOUCH_SCROLL || newState == ScrollManager.SCROLL_STATE_FLING && !positionChanged) {
                            ((TextView) mLayoutManager.getChildAt(0)).setTypeface(null, Typeface.NORMAL);
                            ((TextView) mLayoutManager.getChildAt(0)).setTextSize(16f);
                            ((TextView) mLayoutManager.getChildAt(1)).setTypeface(null, Typeface.NORMAL);
                            ((TextView) mLayoutManager.getChildAt(1)).setTextSize(16f);
                            ((TextView) mLayoutManager.getChildAt(2)).setTypeface(null, Typeface.NORMAL);
                            ((TextView) mLayoutManager.getChildAt(2)).setTextSize(16f);
                        }

                        int offset = currentPosY % rowHeight;
                        if (newState == ScrollManager.SCROLL_STATE_IDLE && positionChanged) {
                            if (offset != 0) {
                                if (yDelta < 0) {
                                    if (offset <= -60) {
                                        scrollToPosition(mRecyclerView, -(rowHeight + offset));
                                    } else {
                                        scrollToPosition(mRecyclerView, -offset);
                                    }
                                } else {
                                    if (offset <= 60) {
                                        scrollToPosition(mRecyclerView, -offset);
                                    } else {
                                        scrollToPosition(mRecyclerView, rowHeight - offset);
                                    }
                                }
                            }
                        }
                        positionChanged = false;
                    }

                    private void scrollToPosition(RecyclerView recyclerView, int deltaY) {
                        BurnTimerAnimation btAnim = new BurnTimerAnimation(recyclerView, deltaY);
                        float time = Math.abs(deltaY / 60f);
                        btAnim.setDuration((long) (500 * time));
                        btAnim.setAnimationListener(new Animation.AnimationListener() {
                            @Override
                            public void onAnimationStart(Animation animation) {

                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {
                                ((TextView) mLayoutManager.getChildAt(0)).setTypeface(null, Typeface.NORMAL);
                                ((TextView) mLayoutManager.getChildAt(1)).setTypeface(null, Typeface.BOLD);
                                ((TextView) mLayoutManager.getChildAt(2)).setTypeface(null, Typeface.NORMAL);


                                Rotate3dAnimation rotation1 = new Rotate3dAnimation(0, 10, centerX, centerY, 50f, true);
                                rotation1.setDuration(100);
                                rotation1.setFillAfter(true);
                                mLayoutManager.getChildAt(0).setAnimation(rotation1);

                                Rotate3dAnimation rotation2 = new Rotate3dAnimation(0, 10, centerX, centerY, -50f, true);
                                rotation2.setDuration(100);
                                rotation2.setFillAfter(true);
                                mLayoutManager.getChildAt(1).setAnimation(rotation2);

                                Rotate3dAnimation rotation3 = new Rotate3dAnimation(0, 10, centerX, centerY, 50f, true);
                                rotation3.setDuration(100);
                                rotation3.setFillAfter(true);
                                mLayoutManager.getChildAt(2).setAnimation(rotation3);

                                burnTimerSelectionIndex = (int) mLayoutManager.getChildAt(1).getTag();
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {

                            }
                        });
                        mRecyclerView.startAnimation(btAnim);
                    }

                    @Override
                    public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                        super.onScrolled(recyclerView, dx, dy);
                        yDelta = dy;
                        currentPosY += dy;
                        positionChanged = true;
                        int offset = currentPosY % rowHeight;
                        Log.v("applyTransform", "onScrolled: " + offset);

                        if (centerX == 0 && centerY == 0) {
                            centerX = mLayoutManager.getChildAt(0).getWidth() / 2.0f;
                            centerY = mLayoutManager.getChildAt(0).getHeight() / 2.0f;
                        }
                    }
                });


                Button doneButton = burnTimerDialog.findViewById(R.id.done_button);
                Button cancelButton = burnTimerDialog.findViewById(R.id.cancel_button);

                doneButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        burnTimerDialog.dismiss();
                        String[] displayValue = Supplier.getStringArray(R.array.burn_time_display_value);
                        int burnTime = Integer.parseInt(displayValue[burnTimerSelectionIndex % displayValue.length]);
                        Log.e("burn", String.valueOf(burnTime));
                        PreferenceDataManager.quickPut(Constants.BURN_MESSAGE_TIME, burnTime);
                    }
                });

                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        burnTimerDialog.dismiss();
                    }
                });

                burnTimerDialog.show();

                ViewTreeObserver vto = mRecyclerView.getViewTreeObserver();
                vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        mRecyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        ((TextView) mLayoutManager.getChildAt(0)).setTypeface(null, Typeface.NORMAL);
                        ((TextView) mLayoutManager.getChildAt(0)).setTextSize(16f);
                        ((TextView) mLayoutManager.getChildAt(1)).setTypeface(null, Typeface.BOLD);
                        ((TextView) mLayoutManager.getChildAt(1)).setTextSize(18f);
                        ((TextView) mLayoutManager.getChildAt(2)).setTypeface(null, Typeface.NORMAL);
                        ((TextView) mLayoutManager.getChildAt(2)).setTextSize(16f);
                    }
                });
            });

        });


    }
}
