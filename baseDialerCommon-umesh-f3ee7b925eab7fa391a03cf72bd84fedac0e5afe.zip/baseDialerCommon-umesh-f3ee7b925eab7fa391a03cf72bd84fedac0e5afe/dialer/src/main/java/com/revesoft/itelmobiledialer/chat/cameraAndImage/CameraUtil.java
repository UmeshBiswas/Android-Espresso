package com.revesoft.itelmobiledialer.chat.cameraAndImage;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.PreviewCallback;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.video.VideoParameters;
import com.revesoft.itelmobiledialer.video.encoding.Encoder;
import com.revesoft.itelmobiledialer.video.utility.ColorFormatAndRotationHandler;

import java.io.IOException;

public class CameraUtil {
	public static long lastEncodeFunctionCallTime = -1;
	static Context context;
	public double frameRate = 12;
	public double timeGap = -1;
	static Camera mCamera = null;
	boolean mPreviewRunning = false;
	Encoder encoder;
	SurfaceHolder holder;

	public CameraUtil(Context context) {
		this.context = context;
		frameRate = 12 * 2;
		timeGap = 1000 / frameRate; // in millisecond
	}

	public static boolean isCameraPresent(int camID) {
		CameraInfo ci = new CameraInfo();
		for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
			Camera.getCameraInfo(i, ci);
			if (ci.facing == camID)
				return true;
		}
		return false; // No front-facing camera found
	}

	/**
	 * gets initial camera
	 */
	public static int getDefaultCamera(Context applicationContext) {
		context = applicationContext;
		PackageManager pm = context.getPackageManager();

		// Must have a targetSdk >= 9 defined in the AndroidManifest
		if (pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT))
			return CameraInfo.CAMERA_FACING_FRONT;
		if (pm.hasSystemFeature(PackageManager.FEATURE_CAMERA))
			return CameraInfo.CAMERA_FACING_BACK;
		return -1;
	}

	public boolean setCameraParameters(int width, int height, int imageFormat) {
		try {
			Camera.Parameters p = mCamera.getParameters();
			p.setPreviewSize(width, height);
			p.setPreviewFormat(imageFormat);
			mCamera.setParameters(p);
			ColorFormatAndRotationHandler.setCameraPreviewWidthAndHeight(width,
					height);
			ColorFormatAndRotationHandler
					.setCameraPreviewColorFormat(imageFormat);
			mCamera.setPreviewCallback(new PreviewCallback() {
				@Override
				public void onPreviewFrame(byte[] data, Camera camera) {
					if (encoder == null) {
						Log.e("CameraUtil", "encoder is null");
						return;
					}
					if (data == null) {
						Log.e("CameraUtil", "data is null");
						return;
					}
					if (mPreviewRunning) {
						// if(lastEncodeFunctionCallTime==-1 ||
						// (System.currentTimeMillis() -
						// lastEncodeFunctionCallTime) >= timeGap )
						{
//							Log.i("CameraUtil", "calling encoder");
							// long time1 = System.nanoTime();
							encoder.encode(data);
							/*
							 * long time2 = System.nanoTime(); long timeTaken =
							 * time2 - time1;
							 * Log.i("CameraUtil","Time taken to encode: " +
							 * timeTaken + " ns");
							 */

							lastEncodeFunctionCallTime = System
									.currentTimeMillis();
						}

					}
				}
			});
			return true;
		} catch (RuntimeException e) {
			e.printStackTrace();
			return false;
		}
	}

	/** ======================================================================== */

	public void startCameraPreview() {
		mCamera.startPreview();
		mPreviewRunning = true;
	}

	public void setEncoder(Encoder enc) {
		this.encoder = enc;
	}

	/**
	 * Gets the camera display orientation
	 */
	public static int getCameraDisplayOrientation(int cameraId, int rotation) {
		CameraInfo info = new CameraInfo();
		Camera.getCameraInfo(cameraId, info);
		// int rotation =
		// ((Activity)context).getWindowManager().getDefaultDisplay().getRotation();
		int degrees = 0;
		switch (rotation) {
		case Surface.ROTATION_0:
			degrees = 0;
			break;
		case Surface.ROTATION_90:
			degrees = 90;
			break;
		case Surface.ROTATION_180:
			degrees = 180;
			break;
		case Surface.ROTATION_270:
			degrees = 270;
			break;
		}

		int result; // default
		if (info.facing == CameraInfo.CAMERA_FACING_FRONT) {
			Log.i("CameraInfo", "info.orientation"+ info.orientation);
			result = (info.orientation + degrees) % 360;
			result = (360 - result) % 360; // compensate the mirror
		} else { // back-facing
			result = (info.orientation - degrees + 360) % 360;
		}
		Log.w("CameraInfo", "getCameraDisplayOrientation : "+ result);
		return result;
	}

	public void setPreviewDisplay(SurfaceHolder holder) {
		this.holder = holder;
		try {
			if (mCamera == null) {
				if (Constants.SHOW_LOG)
					Log.e("CameraUtil", "camera null");
				Toast.makeText(context, "camera null", Toast.LENGTH_SHORT)
						.show();
			}
			if (holder == null) {
				if (Constants.SHOW_LOG)
					Log.e("CameraUtil", "hodler null");
				Toast.makeText(context, "holder null", Toast.LENGTH_SHORT)
						.show();
			}
			mCamera.setPreviewDisplay(holder);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean isCameraOpen() {
		return mCamera != null;
	}

	public boolean safeCameraOpen(int id, int rotation, int orientation) {
		try {
			releaseCamera();
			if (Constants.SHOW_LOG)
				Log.d("CameraUtil", "Opening Camera");
			if (!isCameraPresent(id)) {
				if (Constants.SHOW_LOG)
					Log.e("MySurfaceView", "no camera Present!!");
				return false;
			}
			mCamera = Camera.open(id);
			mCamera.setDisplayOrientation(getCameraDisplayOrientation(id, rotation));
//			if(orientation == Configuration.ORIENTATION_PORTRAIT) {
//				Log.i("CameraUtil", "Build.MODEL : "+Build.MODEL);
//				if (id == CameraInfo.CAMERA_FACING_FRONT && Build.MODEL.equals("Nexus 6P")) {
//					mCamera.setDisplayOrientation(270);
//				} else {
//					mCamera.setDisplayOrientation(90);
//				}
//			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mCamera != null;
	}

	public void releaseCamera() {
		if (mCamera != null) {
			if (Constants.SHOW_LOG)
				Log.w("CameraLOG", "releasing Camera");

			mCamera.setPreviewCallback(null);
			mCamera.stopPreview();
			mPreviewRunning = false;
			try {
				mCamera.setPreviewDisplay(null);
			} catch (IOException e1) {
				if (Constants.SHOW_LOG)
					Log.e("cameraLog",
							"error while setting null in setPreviewDisplay of camera");
				e1.printStackTrace();
			}

			mCamera.lock();
			mCamera.release();
			mCamera = null;

		}
	}

	/** ======================================================================== */

	public void pauseCameraPreview() {
		mPreviewRunning = false;
		mCamera.stopPreview();
	}

	public void switchCam(int previewWidth, int previewHeight, int rotation) {

		if (!mPreviewRunning) {
			if (VideoParameters.CURRENT_CAMERA == CameraInfo.CAMERA_FACING_FRONT) {
				if (isCameraPresent(CameraInfo.CAMERA_FACING_BACK)) {
					VideoParameters.CURRENT_CAMERA = CameraInfo.CAMERA_FACING_BACK;
				} else {
					if (Constants.SHOW_LOG)
						Log.e("EncodeDecode",
								"CAMERA switching falied :: Only Front camera available!");
					return;
				}
			} else if (VideoParameters.CURRENT_CAMERA == CameraInfo.CAMERA_FACING_BACK) {
				if (isCameraPresent(CameraInfo.CAMERA_FACING_FRONT)) {
					VideoParameters.CURRENT_CAMERA = CameraInfo.CAMERA_FACING_FRONT;
				} else {
					if (Constants.SHOW_LOG)
						Log.e("EncodeDecode",
								"CAMERA switching falied :: Only Back camera available!");
					return;
				}
			}
		} else {
			try {
				if (mPreviewRunning) {
					mCamera.stopPreview();
					if (Constants.SHOW_LOG)
						Log.e("EncodeDecode", "preview stopped");
				}
				mCamera.setPreviewCallback(null);
				mCamera.release();
				mCamera = null;

				if (VideoParameters.CURRENT_CAMERA == CameraInfo.CAMERA_FACING_FRONT) {
					if (isCameraPresent(CameraInfo.CAMERA_FACING_BACK)) {
						VideoParameters.CURRENT_CAMERA = CameraInfo.CAMERA_FACING_BACK;
					} else {
						if (Constants.SHOW_LOG)
							Log.e("EncodeDecode",
									"CAMERA switching falied :: Only Front camera available!");
						return;
					}
				} else if (VideoParameters.CURRENT_CAMERA == CameraInfo.CAMERA_FACING_BACK) {
					if (isCameraPresent(CameraInfo.CAMERA_FACING_FRONT)) {
						VideoParameters.CURRENT_CAMERA = CameraInfo.CAMERA_FACING_FRONT;
					} else {
						if (Constants.SHOW_LOG)
							Log.e("EncodeDecode",
									"CAMERA switching falied :: Only Back camera available!");
						return;
					}
				} else {
					if (Constants.SHOW_LOG)
						Log.e("EncodeDecode", "CAMERA switching falied!");
					return;
				}

				mCamera = Camera.open(VideoParameters.CURRENT_CAMERA);
				mCamera.setDisplayOrientation(getCameraDisplayOrientation(VideoParameters.CURRENT_CAMERA, rotation));
//				if(orientation == Configuration.ORIENTATION_PORTRAIT) {
//					Log.i("CameraUtil", "Build.MODEL : "+Build.MODEL);
//					if (VideoParameters.CURRENT_CAMERA == CameraInfo.CAMERA_FACING_FRONT && Build.MODEL.equals("Nexus 6P")) {
//						mCamera.setDisplayOrientation(270);
//					} else {
//						mCamera.setDisplayOrientation(90);
//					}
//				}
				Camera.Parameters p = mCamera.getParameters();
				p.setPreviewSize(previewWidth, previewHeight);
				// p.setPreviewFormat(ImageFormat.NV21);
				p.setPreviewFormat(ImageFormat.YV12);
				mCamera.setParameters(p);

				ColorFormatAndRotationHandler.setCameraPreviewWidthAndHeight(
						previewWidth, previewHeight);
				ColorFormatAndRotationHandler
						.setCameraPreviewColorFormat(ImageFormat.YV12);

				mCamera.setPreviewDisplay(holder);
				mCamera.unlock();
				mCamera.reconnect();
				mCamera.setPreviewCallback(new PreviewCallback() {
					@Override
					public void onPreviewFrame(byte[] data, Camera camera) {
						if (encoder == null) {
							Log.e("CameraUtil", "encoder is null");
							return;
						}
						if (data == null) {
							Log.e("CameraUtil", "data is null");
							return;
						}
						if (mPreviewRunning)
							encoder.encode(data);
					}
				});
				mCamera.startPreview();
				mPreviewRunning = true;
			} catch (Exception e) {
				if (Constants.SHOW_LOG)
					Log.e("EncodeDecode", "CAMERA switching falied!");
				e.printStackTrace();
				return;
			}
		}
	}

	/*
	 * public void setCameraOrientation(int rotation) { mCamera.stopPreview();
	 * mCamera
	 * .setDisplayOrientation(getCameraDisplayOrientation(VideoCallFrameActivity
	 * .CURRENT_CAMERA, rotation)); mCamera.startPreview(); }
	 */
	public void setCameraOrientation(int rotation, int previewWidth, int previewHeight, Encoder enc) {

		if (mPreviewRunning) {
			mCamera.stopPreview();
			if (Constants.SHOW_LOG)
				Log.e("EncodeDecode", "preview stopped");
		}
		mCamera.setPreviewCallback(null);
		mCamera.release();
		mCamera = null;
		mCamera = Camera.open(VideoParameters.CURRENT_CAMERA);
		mCamera.setDisplayOrientation(getCameraDisplayOrientation(VideoParameters.CURRENT_CAMERA, rotation));
		Camera.Parameters p = mCamera.getParameters();
		p.setPreviewSize(previewWidth, previewHeight);
		// p.setPreviewFormat(ImageFormat.NV21);
		p.setPreviewFormat(ImageFormat.YV12);
		mCamera.setParameters(p);

		ColorFormatAndRotationHandler.setCameraPreviewWidthAndHeight(
				previewWidth, previewHeight);
		ColorFormatAndRotationHandler
				.setCameraPreviewColorFormat(ImageFormat.YV12);

		try {
			mCamera.setPreviewDisplay(holder);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mCamera.unlock();
		try {
			mCamera.reconnect();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(enc != null){
			encoder = enc;
		}
		mCamera.setPreviewCallback(new PreviewCallback() {
			@Override
			public void onPreviewFrame(byte[] data, Camera camera) {
				if (encoder == null) {
					Log.e("CameraUtil", "encoder is null");
					return;
				}
				if (data == null) {
					Log.e("CameraUtil", "data is null");
					return;
				}
				if (mPreviewRunning)
					encoder.encode(data);
			}
		});
		mCamera.startPreview();
		mPreviewRunning = true;
	}
}
