package com.revesoft.itelmobiledialer.callog.callLogDetails;

import com.revesoft.itelmobiledialer.appDatabase.entities.CallLog;
import com.revesoft.itelmobiledialer.appDatabase.repo.CallLogRepo;

import java.util.ArrayList;
import java.util.List;

import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

public class CallLogDetailsViewModel extends ViewModel {
    LiveData<List<CallLogDetailsCallItem>> data;

    public CallLogDetailsViewModel(String number) {
        data = Transformations.map(CallLogRepo.get().getAllLiveByNumber(number), new Function<List<CallLog>, List<CallLogDetailsCallItem>>() {
            @Override
            public List<CallLogDetailsCallItem> apply(List<CallLog> input) {
                List<CallLogDetailsCallItem> callItems = new ArrayList<>(input.size());
                for(CallLog callLog : input){
                    callItems.add(CallLogDetailsCallItem.from(callLog));
                }
                return callItems;
            }
        });
    }

    public LiveData<List<CallLogDetailsCallItem>> getData() {
        return data;
    }
}
