/*
 *  Created by Ifta on 8/8/18 11:02 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/5/18 3:35 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.typeConverter;

import androidx.room.TypeConverter;
/**
 * @author Ifta at July 30, 2018
 */
public class RoomBoolIntConverter {
    @TypeConverter
    public static boolean toBoolean(int value) {
        return value != 0;
    }

    @TypeConverter
    public static int toInt(boolean value) {
        return value ? 1 : 0;
    }
}
