/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:40 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:40 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.Subscriber;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.SubscriberLookUpRepo;
import com.revesoft.itelmobiledialer.databaseentry.SubscriberEntry;
import com.revesoft.itelmobiledialer.e2eencryption.E2EPublicKeySeedAndPrivateKeyHolder;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.ContactEngine;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface SubscriberDao  extends BaseDao<Subscriber>{


    @Query("SELECT * FROM SUBSCRIBER ORDER BY presencestate ASC, name ASC")
    List<Subscriber> getSubscriber();



    @Query("SELECT * FROM SUBSCRIBER WHERE number LIKE :num LIMIT 1")
    Subscriber getSubscriberByNumber(String num);






    @Query("UPDATE SUBSCRIBER SET buddy_public_key=:publicKey, buddy_seed=:seed WHERE number=:buddy")
    void updateE2EPublicKeyAndSeedForBuddy(String buddy, String publicKey, String seed);



    default boolean isE2EPublicKeyAndSeedAvailableForBuddy(String buddy){
       Subscriber subscriber=getSubscriberByNumber(buddy);
       boolean result=subscriber!=null;
       result=result && (!subscriber.buddyPublicKey.equals("") && !subscriber.buddySeed.equals(""));
       return result;
    }


    default E2EPublicKeySeedAndPrivateKeyHolder getE2EPublicKeySeedAndPrivateKeyHolderForBuddy(String buddy){
        E2EPublicKeySeedAndPrivateKeyHolder e2EPublicKeySeedAndPrivateKeyHolder=new E2EPublicKeySeedAndPrivateKeyHolder();

        Subscriber subscriber=getSubscriberByNumber(buddy);
        if(buddy!=null){
            e2EPublicKeySeedAndPrivateKeyHolder.publicKey=subscriber.buddyPublicKey.equals("") ? null: subscriber.buddyPublicKey;
            e2EPublicKeySeedAndPrivateKeyHolder.seed=subscriber.buddySeed.equals("") ? null : subscriber.buddySeed;
        }
        return e2EPublicKeySeedAndPrivateKeyHolder;
    }


    default boolean checkForSubscriber(String number){
        Subscriber subscriber=getSubscriberByNumber("%"+Util.removePrefixes(number));
        return subscriber!=null;
    }




    @Query("UPDATE SUBSCRIBER SET number=:number,subscriberimagehash='' WHERE number=:number")
    void deleteSubscriberHash(String number);



    @Query("SELECT subscriberimagehash FROM SUBSCRIBER WHERE number=:number")
    String getSubscriberHash(String number);


    default boolean isSubscriber(String number){
        return getSubscriberByNumber(number)!=null;
    }

    default boolean isSubscriber(String nonTranslatedNumber, int countryCode){
        String translatedNumber = Util.translateNumber(nonTranslatedNumber, countryCode);
        return isSubscriber(nonTranslatedNumber) || isSubscriber(translatedNumber);
    }







    @Query("DELETE FROM SUBSCRIBER WHERE number=:number")
    void deleteSubscriberByNumber(String number);




    @Query("UPDATE SUBSCRIBER SET presencestate=:state,presencenote=:note," +
            "last_online_time=:lastOnline WHERE number=:number")
    void updateSubscriber(String number, int state, String note, Long lastOnline);

    @Query("UPDATE SUBSCRIBER SET presencestate=:state," +
            "last_online_time=:lastOnline WHERE number=:number")
    void updateSubscriber(String number, int state, Long lastOnline);


    @Query("UPDATE SUBSCRIBER SET presencenote=' '," +
            "lookup_key=:lookUpKey,subscriberimagehash=:subscriberPicHash WHERE number=:number")
    void updateSubscriber(String number, String lookUpKey, String subscriberPicHash);

    default void updateSubscriber(String number, String subscriberPicHash){
        String lookUp = ContactRepo.get().lookUpKeyByProcessedNumber(number);
        updateSubscriber(number,lookUp,subscriberPicHash);
    }



    @Query("UPDATE SUBSCRIBER SET _id=:id,presencenote=' '," +
            "lookup_key=:lookUp,subscriberimagehash=:subscriberPicHash WHERE number=:number")
    void updateSubscriber(String number,int id, String lookUp, String subscriberPicHash);




    @Query("UPDATE SUBSCRIBER SET lookup_key=:lookUpKey,name=:name WHERE number=:number")
    void updateSubscriberName(String number,String name,String lookUpKey);




    default void checkValidityOfSubscriberNames(){
        List<Subscriber> subscriberList= getSubscriber();
        for(Subscriber subscriber:subscriberList){
            String number=subscriber.number;
            String name=subscriber.name;
            String contactName = ContactRepo.get().getNameByNumber(number);
            if(name==null || name.equalsIgnoreCase(contactName)){
                String lookUpKey = ContactRepo.get().lookUpKeyByProcessedNumber(number);
                updateSubscriberName(number,contactName,lookUpKey);
            }
        }
    }


    default void deleteAllSubscribers(){
        SubscriberLookUpRepo.get().deleteAllSubscribers();
        _deleteAllSubscribers();
    }


    @Query("DELETE FROM SUBSCRIBER")
    void _deleteAllSubscribers();




    default void deleteSubscriber(String number){
        SubscriberLookUpRepo.get().deleteSubscriberLookup(number);
        _deleteSubscriber(number);
    }


    @Query("DELETE FROM SUBSCRIBER WHERE number=:number")
    void _deleteSubscriber(String number);




    @Query("SELECT presencenote FROM SUBSCRIBER WHERE number=:number")
    String presenceNoteByNumber(String number);


    @Query("SELECT * FROM SUBSCRIBER WHERE lookup_key=:key AND number LIKE :number")
    Subscriber checkForSubscriberNumberAndKey(String number,String key);

    default boolean checkForSubscriberNumberAndKey(String number){
        String key = ContactEngine.getContactLookupKey(AppContext.getAccess().getContext(), Util.removePrefixes(number));
        return checkForSubscriberNumberAndKey("%"+number,key)!=null;

    }


    default String getSubscribedNumber(String number){
        String key = ContactEngine.getContactLookupKey(AppContext.getAccess().getContext(), Util.removePrefixes(number));
        return checkForSubscriberNumberAndKey("%"+number,key).number;
    }


    @Query("UPDATE SUBSCRIBER SET presencestate="+SubscriberEntry.PresenceState.OFFLINE)
     void resetSubscriber();


    @Query("SELECT * FROM SUBSCRIBER ORDER BY presencestate ASC, name COLLATE NOCASE ASC")
    Cursor getSubscriberCursor();


    @Query("SELECT * FROM SUBSCRIBER WHERE number LIKE :searchItem OR name LIKE :searchItem " +
            "ORDER BY presencestate ASC, name COLLATE NOCASE ASC")
    Cursor _searchSubscriberCursor(String searchItem);


    default Cursor searchSubscriberCursor(String searchItem){
        return _searchSubscriberCursor("%"+searchItem+"%");

    }



    @Query("SELECT number FROM SUBSCRIBER")
    List<String> getSubscriberNumbers();



    @Query("SELECT * FROM SUBSCRIBER WHERE number IN (:subscriberNumbers) ORDER BY presencestate ASC, name ASC")
    List<Subscriber> getSubscribersHavingSpecifiedNumbers(String[] subscriberNumbers);



    @Query("SELECT * FROM SUBSCRIBER WHERE number NOT IN (:subscriberNumbers) ORDER BY presencestate ASC, name ASC")
    Cursor getSubscribersExcludingSpecifiedNumbers(String[] subscriberNumbers);


//TODO Have to find Solutions here//

//    @Query("SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//            " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//            " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number AND s.buddy_public_key <> '' AND s.buddy_seed <> '' ) as temp " +
//            " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC")
//    Cursor getE2ESubscriber();
    default Cursor getE2ESubscriber(){return null;}


//TODO Error Here in Query//

//    @Query("SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//            " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//            " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number AND s.buddy_public_key <> '' AND s.buddy_seed <> '') as temp " +
//            " WHERE temp.name LIKE  OR temp.subscribed_number LIKE :searchStr" +
//            " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC")
//    Cursor _getE2ESubscriberSearch(String searchStr);

    default Cursor getE2ESubscriberSearch(String searchStr){
        return null;
//        return _getE2ESubscriberSearch("%"+searchStr+"%");
    }

//    @Query("SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//            " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//            " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number) as temp " +
//            " WHERE temp.name LIKE :searchStr OR temp.subscribed_number LIKE :searchStr " +
////					"AND temp.name<>'' and temp.name not null" +
////					" GROUP BY temp.subscribed_number ORDER BY temp.presencestate ASC, temp.name COLLATE LOCALIZED ASC";
//            " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC")
//    Cursor _getSubscriberSearch(String searchStr);


    default Cursor getSubscriberSearch(String searchStr){
        return null;
//        return _getSubscriberSearch("%"+searchStr+"%");
    }

    @Query("SELECT DISTINCT _id,  name,  number, is_favourite, contact_id, lookup_key," +
            " photo_uri, processed_number" +
            " FROM contacts WHERE processed_number not in (SELECT number from subscriber)" +
            " GROUP BY number ORDER BY name COLLATE LOCALIZED ASC")
    Cursor getNonSubscriberContacts();

    @Query("SELECT DISTINCT _id,  name,  number, is_favourite, contact_id, lookup_key," +
            " photo_uri, processed_number" +
            " FROM contacts WHERE (name LIKE :searchStr OR number LIKE :searchStr) AND processed_number not in (SELECT number from subscriber)" +
            " GROUP BY number ORDER BY name COLLATE LOCALIZED ASC")
    Cursor _getNonSubscriberContacts(String searchStr);


    @Query("SELECT last_online_time FROM SUBSCRIBER WHERE number=:number")
    long getLastOnlineTime(String number);


    @Query("SELECT presencenote FROM SUBSCRIBER WHERE number=:number")
    String getPresenceNote(String number);


    @Query("SELECT number FROM SUBSCRIBER WHERE number IN (:numberList)")
    List<String> isSubscriber(List<String> numberList);












}
