package com.revesoft.itelmobiledialer.did;

import androidx.appcompat.app.ActionBar;

import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;

import com.revesoft.material.R;
import com.revesoft.itelmobiledialer.util.BaseActivity;

public class DIDNumberSettingsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_did_number_settings);
        handleToolbar();
        DIDNumberSettingsFragment DIDNumberSettingsFragment = new DIDNumberSettingsFragment();
        DIDNumberSettingsFragment.setArguments(this.getIntent().getExtras());
        getFragmentManager().beginTransaction().add(R.id.container, DIDNumberSettingsFragment, "DIDNumberSettingsFragment").commit();
    }

    private void handleToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.did_all_cap));
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.did_all_cap));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
