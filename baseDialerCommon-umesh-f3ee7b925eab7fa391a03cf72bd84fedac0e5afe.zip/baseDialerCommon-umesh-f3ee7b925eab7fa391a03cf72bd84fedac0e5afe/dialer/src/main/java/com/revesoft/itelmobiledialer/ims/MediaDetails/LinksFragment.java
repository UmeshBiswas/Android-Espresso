package com.revesoft.itelmobiledialer.ims.MediaDetails;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.ims.ChatUtil;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


/**
 * Created by Acer on 6/8/2017.
 */

public class LinksFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>{
    private Context context;
    private LayoutInflater inflater;
    public static final String PAGE_TITLE = "PAGE_TITLE";
    String fragmentName;
    private RecyclerView recyclerView;
    ArrayList<String> linkHeaders = new ArrayList<>();
    ArrayList<String> linkCaptions = new ArrayList<>();
    ArrayList<Message> messageArrayList = new ArrayList<>();
    LinkItemAdapter linkItemAdapter;
    private Activity mActivity;

    public LinksFragment(){
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        this.inflater = inflater;
        View view = inflater.inflate(R.layout.activity_media_detail_link_fragment, null);
        RelativeLayout relativeLayout = view.findViewById(R.id.cont_pager_item_root);
        getLoaderManager().initLoader(2000, null, this);
        recyclerView = view.findViewById(R.id.recyclerView);
        linkItemAdapter = new LinkItemAdapter();
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setAdapter(linkItemAdapter);
        recyclerView.setLayoutManager(layoutManager);
        return view;
    }
    public void updateMessageList() {
        messageArrayList.clear();
        linkHeaders.clear();
        linkCaptions.clear();

        for(int i =0;  getActivity() != null  && i<messageList.size();i++)
        {
            MimeType mimeType = messageList.get(i).mimeType;
            Log.e("LinksFragment", "Mime Type: " +messageList.get(i).mimeType );
            Log.e("media-link", mimeType.toString());
            if(mimeType == MimeType.Link )
            {

                Log.e("LinksFragment", "Link found  ");

                ArrayList<String> urls = ChatUtil.extractUrls(messageList.get(i).content);
                if(urls.size() > 0)
                {
                    for(int j =0; j< urls.size(); j++)
                    {
                        linkHeaders.add(urls.get(j));
                        linkCaptions.add(messageList.get(i).content);
                    }

                }

            }

        }
        Log.e("media-link", Integer.toString(messageArrayList.size()));


//            for(int i =0;  getActivity() != null  && i<messageList.size();i++)
//            {
//
//                MimeType mimeType = messageList.get(i).mimeType;
//                Log.e("media-doc", mimeType.toString());
//                if(mimeType == MimeType.Document )
//                {
//                    File file =  new File(messageList.get(i).filePath);
//                    if(file.exists())
//                    {
//                        messageArrayList.add(messageList.get(i));
//                        messageArrayList.get(messageArrayList.size() -1).fileSize = Double.valueOf(file.length()/1024);
//                    }
//
//                }
//
//            }
//            Log.e("media-doc", Integer.toString(messageArrayList.size()));
//            documentItemAdapter.notifyDataSetChanged();


        linkItemAdapter.notifyDataSetChanged();

    }

    public static LinksFragment getInstance(String pageTitle, int icon){
        LinksFragment item = new LinksFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PAGE_TITLE,pageTitle);
        item.setArguments(bundle);
        return item;
    }

    public void setFragmentName(String fragmentName){
        this.fragmentName = fragmentName;
        Log.e("fragment name",fragmentName);
    }

    boolean isGroup;
    String phoneNumberOrGroupNumber;

    public void setFragmentParams(boolean isGroup, String phoneNumberOrGroupNumber){
        this.isGroup = isGroup;
        this.phoneNumberOrGroupNumber = phoneNumberOrGroupNumber;
        Log.e("fragment param", this.phoneNumberOrGroupNumber);
    }

    public String getFragmentName(){
        return fragmentName;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new SQLiteCursorLoader(getActivity()) {
            @Override
            public Cursor loadInBackground() {

                Log.i("MediaDetailsActivity", "in MESSAGE_QUERY_LOADER");
                Cursor cursor = null;
                try {
                    if (isGroup) {
                        cursor = MessageRepo.get().getImsWithMediaByGroupId(phoneNumberOrGroupNumber);
                    } else {
                        cursor = MessageRepo.get().getImsWithMediaByNumber(phoneNumberOrGroupNumber);
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    this.registerContentObserver(cursor, DatabaseConstants.MESSAGE_URI);
                }

                return cursor;
            }
        };
    }

    private Cursor mediaMessageCursor;
    private ArrayList<Message> messageList = new ArrayList<>();

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null) {
            mediaMessageCursor = data;
        }
        Log.i("--------", "in MESSAGE_QUERY_LOADER_FINISHED_2");
        messageList.clear();
        if (mediaMessageCursor != null) {
            if (mediaMessageCursor.moveToFirst()) {
                do {
                    messageList.add(new Message(mediaMessageCursor));
                }
                while (mediaMessageCursor.moveToNext());

            }
        }
        Log.e("media-link++", Integer.toString(messageList.size()));
        updateMessageList();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        messageList.clear();
        updateMessageList();
    }

    public interface FragmentItemCallback{
        void onPagerItemClick(String message);
    }

    public class LinkItemAdapter extends RecyclerView.Adapter<LinkItemAdapter.LinkItemHolder>{


        @Override
        public LinkItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new LinkItemHolder(inflater.inflate(R.layout.activity_media_detail_link_item, null));
        }

        @Override
        public void onBindViewHolder(LinkItemHolder holder, int position) {
            holder.container.setBackgroundResource(R.drawable.round_layout);
            holder.tvLinkCaption.setText(linkCaptions.get(position));
            holder.tvLinkHeader.setText(linkHeaders.get(position));

        }

        @Override
        public int getItemCount() {
            return linkHeaders.size();
        }

        public class LinkItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
            private RelativeLayout container;
            private ImageView linkImage;
            private TextView tvLinkHeader;
            private TextView tvLinkCaption;

            public LinkItemHolder(View itemView) {
                super(itemView);
                container = itemView.findViewById(R.id.link_item);
                container.setOnClickListener(this);
                linkImage = itemView.findViewById(R.id.linkImage);
                tvLinkHeader = itemView.findViewById(R.id.linkHeader);
                tvLinkCaption = itemView.findViewById(R.id.linkCaption);

            }

            @Override
            public void onClick(View view) {


                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(
                        linkHeaders.get(getAdapterPosition()).startsWith("http")? linkHeaders.get(getAdapterPosition()):
                                "http://" + linkHeaders.get(getAdapterPosition())));
                getActivity().startActivity(browserIntent);
            }
        }
    }
}