package com.revesoft.itelmobiledialer.block;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.revesoft.itelmobiledialer.contact.list.ContactListFragment;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.contact.picker.ContactSelectiontype;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickedListener;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickerActivity;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

/**
 * @author Ifta
 */

public class BlockedContactActivity extends BaseActivity {
    Toolbar toolbar;
    ContactListFragment blockedContactFragment;

    public static void start(Context context) {
        Intent intent = new Intent(context, BlockedContactActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocked_contact_activity_layout);
        handleToolbar();
        blockedContactFragment = ContactListFragment.newInstance(false, ContactType.BLOCKED);
        getSupportFragmentManager().beginTransaction().add(R.id.blockedContactHolder, blockedContactFragment, BlockedContactFragment.getTAG()).commit();
    }

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.blockedContacts));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.blocked_contacts, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_add_to_block_list) {
            ContactPickerActivity.startPicker(BlockedContactActivity.this, ContactType.NOT_BLOCKED, ContactSelectiontype.MULTIPLE_SELECT ,new ContactPickedListener() {
                @Override
                public void onContactPicked(List<String> contacts, List<ContactListItem> contactListItems) {
                    Queue<String> blockContactsQueue = new LinkedList<>();
                    for (String contact : contacts) {
                        blockContactsQueue.add(contact);
                    }
                    if(!blockContactsQueue.isEmpty()) {
                        blockedContactFragment.setBlockContactsQueue(blockContactsQueue);
                        blockedContactFragment.blockNextContactFromQueue();
                    }

                }
            });
        } else if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return false;
    }

    public void unblockContact(String contact)
    {
        blockedContactFragment.unblockContact(contact);
    }
}
