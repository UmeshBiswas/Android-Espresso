package com.revesoft.itelmobiledialer.chat.chatWindow.interfaces;

import java.util.Date;

/**
 * @author Ifta on 22/10/2017.
 */

public interface FutureMessageEditedListener {
    void onEdit(Date editedDate, String editedText);
}
