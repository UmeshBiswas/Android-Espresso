package com.revesoft.itelmobiledialer.chat.chatWindow.messageSender;

import android.content.Context;
import android.location.Location;

import com.revesoft.itelmobiledialer.ims.MyLocationProvider;
import com.revesoft.itelmobiledialer.service.dialerService.MessageBag;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.IntentUtil;

/**
 * @author Ifta on 7/10/2017.
 */

public class LocationSender {
    public static void sendCurrentLocation(final Context context, final String phoneNumber) {
        MyLocationProvider myLocationProvider = new MyLocationProvider();
        myLocationProvider.getLocation(context, new MyLocationProvider.LocationListener() {
            @Override
            public void locationReceived(Location location) {
                String requestData = Constants.LOCATION_PREFIX + location.getLatitude() + "," + location.getLongitude() + Constants.LS_SUFIX;
                MessageBag bag = MessageBag.newBuilder().number(phoneNumber).messageData(requestData).build();
                IntentUtil.Dialer.sendIntentBagToDialer(IntentUtil.IntentType.OUTGOING_MESSAGE,bag);
            }

            @Override
            public void error(String errorMessage) {
                IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.OUTGOING_MESSAGE,phoneNumber,errorMessage);
            }
        });
    }
}
