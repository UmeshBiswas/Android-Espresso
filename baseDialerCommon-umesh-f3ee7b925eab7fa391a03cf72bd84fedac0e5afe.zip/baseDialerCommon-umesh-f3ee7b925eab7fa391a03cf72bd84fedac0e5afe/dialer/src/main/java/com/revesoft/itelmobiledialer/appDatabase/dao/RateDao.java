package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.Rate;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface RateDao extends BaseDao<Rate> {
    @Query("SELECT * FROM RATE_TABLE")
    List<Rate> getAll();

    @Query("SELECT * FROM RATE_TABLE")
    Cursor getRates();

    @Query("DELETE FROM RATE_TABLE")
    void deleteAllRates();
}
