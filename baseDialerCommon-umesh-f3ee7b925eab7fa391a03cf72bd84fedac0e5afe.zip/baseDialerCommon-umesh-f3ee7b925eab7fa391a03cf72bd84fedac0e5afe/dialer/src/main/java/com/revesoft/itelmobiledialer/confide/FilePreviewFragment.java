package com.revesoft.itelmobiledialer.confide;

import android.media.MediaPlayer;
import android.os.Bundle;
;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.bumptech.glide.Glide;

import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * @author Ifta on 2/1/2018.
 */

public class FilePreviewFragment extends Fragment {
    private static final TaggedLogger logger = new TaggedLogger("ConfideChat");
    public static final String TAG = "FilePreviewFragment";
    public static final String KEY_FILE_PATH = "KEY_FILE_PATH";
    private static final int PROGRESS_FACTOR = 100;
    private String filePath = null;
    private static Fragment fragment = null;

    ImageView ivImageVideoPreview;
    ImageView ivAudioPlayPause;
    ImageView ivVideoIndicator;
    ProgressBar pbAudioProgress;
    View imageVideoPreviewHolder;
    View audioPreviewHolder;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments().containsKey(KEY_FILE_PATH)) {
            filePath = getArguments().getString(KEY_FILE_PATH);
            if (TextUtils.isEmpty(filePath)) {
                I.toast(getString(R.string.something_went_wrong));
            }
        } else {
            I.toast(getString(R.string.something_went_wrong));
        }
    }

    public static Fragment getInstance(String filePath) {
        if (fragment == null) {
            fragment = new FilePreviewFragment();
        }
        Bundle bag = new Bundle();
        bag.putString(KEY_FILE_PATH, filePath);
        fragment.setArguments(bag);
        return fragment;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.confide_file_preview_layout, container, false);
    }


    private int playButtonResourceId = 0;
    private int pauseButtonResourceId = 0;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        playButtonResourceId = R.drawable.ic_audio_play;
        pauseButtonResourceId = R.drawable.ic_audio_pause;
        initViews(view);
        MimeType mimeType = MimeTypeUtil.getMimeTypeFromFilePath(filePath);
        logger.log("mime type = " + mimeType.toString());
        switch (mimeType) {
            case Image:
                setImagePreview();
                break;
            case Video:
                setVideoPreview();
                break;
            case Audio:
                setAudioPreview();
                break;
        }
    }

    MediaPlayer mediaPlayer;

    private void setAudioPreview() {
        audioPreviewHolder.setVisibility(View.VISIBLE);
        imageVideoPreviewHolder.setVisibility(View.GONE);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                isPaused = false;
                ivAudioPlayPause.setImageResource(playButtonResourceId);
            }
        });
        ivAudioPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    pauseAudioMessage();
                } else {
                    if (isPaused) {
                        resumeAudioMessage();
                    } else {
                        playAudioMessage();
                    }
                }
            }
        });
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
    }

    private void playAudioMessage() {
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(filePath);
            mediaPlayer.prepare();
            mediaPlayer.start();
            ivAudioPlayPause.setImageResource(pauseButtonResourceId);
            pbAudioProgress.setProgress(0);
            pbAudioProgress.setMax(mediaPlayer.getDuration() / PROGRESS_FACTOR);
            startTimer();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    boolean isPaused = false;

    private void pauseAudioMessage() {
        isPaused = true;
        mediaPlayer.pause();
        ivAudioPlayPause.setImageResource(playButtonResourceId);
        timer.cancel();
    }

    private void resumeAudioMessage() {
        mediaPlayer.start();
        ivAudioPlayPause.setImageResource(pauseButtonResourceId);
        startTimer();
        isPaused = false;
    }

    Timer timer;

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                final int currentPosition = mediaPlayer.getCurrentPosition();
                pbAudioProgress.setProgress(currentPosition / PROGRESS_FACTOR);
            }
        }, 0, PROGRESS_FACTOR);
    }

    private void setVideoPreview() {
        audioPreviewHolder.setVisibility(View.GONE);
        imageVideoPreviewHolder.setVisibility(View.VISIBLE);
        ivAudioPlayPause.setVisibility(View.VISIBLE);
        Glide.with(AppContext.getAccess().getContext())
                .load(filePath)
                .crossFade()
                .centerCrop()
                .error(R.drawable.file_broken)
                .thumbnail(.2f).into(ivImageVideoPreview);
        ivImageVideoPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Switcher.switchToVideoPreview(filePath);
            }
        });
    }

    private void setImagePreview() {
        audioPreviewHolder.setVisibility(View.GONE);
        imageVideoPreviewHolder.setVisibility(View.VISIBLE);
        ivVideoIndicator.setVisibility(View.GONE);
        Glide.with(AppContext.getAccess().getContext())
                .load(filePath)
                .crossFade()
                .centerCrop()
                .error(R.drawable.file_broken)
                .into(ivImageVideoPreview);
        ivImageVideoPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Switcher.switchToImagePreview(filePath);
            }
        });
    }

    private void initViews(View view) {
        ivImageVideoPreview = (ImageView) view.findViewById(R.id.ivImageVideoPreview);
        ivAudioPlayPause = (ImageView) view.findViewById(R.id.ivAudioPlayPause);
        ivVideoIndicator = (ImageView) view.findViewById(R.id.ivVideoIndicator);
        pbAudioProgress = (ProgressBar) view.findViewById(R.id.pbAudioProgress);
        imageVideoPreviewHolder = view.findViewById(R.id.imageVideoPreviewHolder);
        audioPreviewHolder = view.findViewById(R.id.audioPreviewHolder);
    }
}
