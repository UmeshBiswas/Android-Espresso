package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Space;
import android.widget.TextView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.maps.model.LatLng;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatAdapterHelper;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.SeenSender;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageSelection;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.confide.Smoker;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;

/**
 * @author Ifta on 12/12/2017.
 */

public class MediaMessageViewHolder extends RetryAndProgressMessageViewHolder {
    private ImageView ivPreview;
    private ProgressBar progressBar;
    private TextView tvProgress;
    private ImageView ivRetry;
    private ImageView ivPlayButton;
    private ImageView ivSmokeIndicator;
    private Space confideSpace;
    private ShimmerFrameLayout shimmerFrameLayout;
    private ImageView dummyIvPreview;

    public MediaMessageViewHolder(View view) {
        super(view);
        ivPreview = view.findViewById(R.id.ivPreview);
        progressBar = view.findViewById(R.id.pb);
        tvProgress = view.findViewById(R.id.tvProgress);
        ivRetry = view.findViewById(R.id.ivRetry);
        ivPlayButton = view.findViewById(R.id.ivPlayButton);
        ivSmokeIndicator = view.findViewById(R.id.ivSmokeIndicator);
        confideSpace = view.findViewById(R.id.confideSpace);
        shimmerFrameLayout = view.findViewById(R.id.shimmer_view_container);
        dummyIvPreview = view.findViewById(R.id.dummyIvPreview);
    }

    public void bindView(Message message) {
        super.bindView(message);
        if(message.isConfide) return;
        ivPreview.setImageBitmap(null);
        if (message.mimeType == MimeType.GIF) {
            ChatAdapterHelper.Gif.handleGifPreview(message, ivPreview, dummyIvPreview, shimmerFrameLayout);
        } else if (message.mimeType == MimeType.Sticker) {
            ChatAdapterHelper.Sticker.handleStickerPreview(message.content, ivPreview, dummyIvPreview, shimmerFrameLayout);
        } else if (message.mimeType == MimeType.Image || message.mimeType == MimeType.Video) {
            ChatAdapterHelper.Image.handleImagePreview(message, ivPreview);
        } else if (message.mimeType == MimeType.Location) {
            ChatAdapterHelper.Location.handleLocationPreview(message, ivPreview);
        } else if (message.mimeType == MimeType.LocationRequest) {
            ChatAdapterHelper.Location.handleLocationRequestPreview(ivPreview);
        } else if (message.mimeType == MimeType.CallRejectSticker) {
            ChatAdapterHelper.Sticker.handleCallRejectStickerPreview(message.content, ivPreview);
        } else if (message.mimeType == MimeType.StaticSticker) {
            ChatAdapterHelper.Sticker.handleStaticStickerPreview(message.content, ivPreview);
        } else if (message.mimeType == MimeType.Document) {
            ChatAdapterHelper.Document.handleDocumentPreview(message, ivPreview);
        }
        handleClicks(message);
        handleColorFilter(message);
        if (ivSmokeIndicator != null) {
            if (Smoker.needSmoking(message.callerId)) {
                ivSmokeIndicator.animate().alpha(0).setDuration(500).start();
            } else {
                ivSmokeIndicator.setAlpha(1.0f);
            }
        }
        if (message.isConfide && confideSpace != null) {
            if (message.mimeType == MimeType.Deleted) {
                confideSpace.setVisibility(View.GONE);
            } else {
                confideSpace.setVisibility(View.VISIBLE);
            }
        }

    }

    private void handleColorFilter(Message message) {
        if (ivRetry.getVisibility() == View.VISIBLE || progressBar.getVisibility() == View.VISIBLE) {
            if (message.mimeType == MimeType.Video) {
                ivPlayButton.setColorFilter(Color.rgb(123, 123, 123), PorterDuff.Mode.MULTIPLY);
            } else if (message.mimeType == MimeType.Image || message.mimeType == MimeType.Document) {
                ivPreview.setColorFilter(0x99000000);
            }
        } else {
            if (message.mimeType == MimeType.Video) {
                ivPlayButton.setColorFilter(Color.TRANSPARENT);
            } else if (message.mimeType == MimeType.Image || message.mimeType == MimeType.Document) {
                ivPreview.setColorFilter(Color.TRANSPARENT);
            }
        }
    }

    private void handleClicks(final Message message) {
        ivPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MessageSelection.isInSelectionMode) {
                    MessageSelection.addOrRemove(message);
                } else {
                    if (message.mimeType == MimeType.Image && !ChatUtil.isDownloadingNow(message)) {
                            SeenSender.getAccess().sendSeen(message);
                            Switcher.switchToImagePreview(message.filePathLocal);
                    } else if (message.mimeType == MimeType.Video && !ChatUtil.isDownloadingNow(message)) {
                        SeenSender.getAccess().sendSeen(message);
                        Switcher.switchToVideoPreview(message.filePathLocal);
                    } else if (message.mimeType == MimeType.GIF) {
                        SeenSender.getAccess().sendSeen(message);
                        String gifUrl = ChatContentParser.parseGifUrl(message.content);
                        Switcher.switchToGifPreview(gifUrl);
                    } else if (message.mimeType == MimeType.Sticker) {
                        SeenSender.getAccess().sendSeen(message);
                        String stickerUrl = ChatContentParser.parseStickerUrl(message.content);
                        Switcher.switchToStickerPreview(stickerUrl);
                    } else if (message.mimeType == MimeType.Location) {
                        LatLng latLng = ChatContentParser.parseLocation(message.content);
                        Switcher.switchToMapApplication(latLng);
                    } else if (message.mimeType == MimeType.LocationRequest && message.messageType == MessageEntry.MessageType.RECEIVED) {
                        boolean needAction = ChatContentParser.parseLocationRequestActionNeed(message.content);
                        if (needAction) {
                            ChatWindowEventHook.dispatchEvent(ChatWindowEvent.LocationRequestWithCheckingPermission,message);
                        }
                    } else if (message.mimeType == MimeType.Document && !ChatUtil.isDownloadingNow(message)) {
                        Switcher.openDocument(message);

                    } else if (message.mimeType == MimeType.Sticker || message.mimeType == MimeType.StaticSticker) {
                        //TODO nothing
                    } else if (message.mimeType == MimeType.LocationRequest && message.messageType == MessageEntry.MessageType.SEND) {
                        //TODO nothing
                    } else {
                        I.toast(Supplier.getString(R.string.please_wait_attachment_is_downloading));
                    }
                }
            }
        });

        ivPreview.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                MessageSelection.addOrRemove(message);
                return true;
            }
        });


    }


}
