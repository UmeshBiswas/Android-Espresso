package com.revesoft.itelmobiledialer.confide;

import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.bumptech.glide.Glide;
import com.eightbitlab.supportrenderscriptblur.SupportRenderScriptBlur;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.io.IOException;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import eightbitlab.com.blurview.BlurAlgorithm;
import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;

/**
 * @author Ifta on 2/1/2018.
 */

public class PreviewMessageFilePreviewFragment extends Fragment {
    private static final TaggedLogger logger = new TaggedLogger("ConfideChat");
    public static final String TAG = "FilePreviewFragment";
    public static final String KEY_FILE_PATH = "KEY_FILE_PATH";
    private static final int PROGRESS_FACTOR = 100;
    private String filePath = null;
    private static PreviewMessageFilePreviewFragment fragment = null;

    ImageView ivVideoPreview;
    ImageView ivImagePreview;
    ImageView ivAudioPlayPause;

    ProgressBar pbAudioProgress;

    View imagePreviewHolder;
    View videoPreviewHolder;
    View audioPreviewHolder;


    View handle;
    View gap;
    View cover;

    BlurView blurViewTop;
    BlurView blurViewBottom;

//    VideoView videoView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments().containsKey(KEY_FILE_PATH)) {
            filePath = getArguments().getString(KEY_FILE_PATH);
            if (TextUtils.isEmpty(filePath)) {
                I.toast(getString(R.string.something_went_wrong));
            }
        } else {
            I.toast(getString(R.string.something_went_wrong));
        }
    }

    public static PreviewMessageFilePreviewFragment getInstance(String filePath) {
        if (fragment == null) {
            fragment = new PreviewMessageFilePreviewFragment();
            Bundle bag = new Bundle();
            bag.putString(KEY_FILE_PATH, filePath);
            fragment.setArguments(bag);
        } else {
            fragment.getArguments().putString(KEY_FILE_PATH, filePath);
        }

        return fragment;
    }

    public void handleFileWindow(int y) {
        logger.log("handleFileWindow y=" + y);
        if (mimeType == MimeType.Image) {
            if (y == 0) {
                gapOff();
            } else {
                gapOn();
            }
            changeHandle(y);
        }
    }

    public void handleFileWindowClick(int y) {
        logger.log("handleFileWindow y=" + y);
        if (mimeType == MimeType.Image) {
            if (y == 0) {
                gapOff();
            } else {
                gapOn();
            }
            changeHandle(y);
        } else if (mimeType == MimeType.Audio) {
            ivAudioPlayPause.performClick();
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.preview_message_confide_file_preview_layout, container, false);
    }

    MimeType mimeType;
    private int playButtonResourceId = 0;
    private int pauseButtonResourceId = 0;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        playButtonResourceId = R.drawable.ic_audio_play;
        pauseButtonResourceId = R.drawable.ic_audio_pause;
        initViews(view);
        mimeType = MimeTypeUtil.getMimeTypeFromFilePath(filePath);
        logger.log("mime type = " + mimeType.toString());
        switch (mimeType) {
            case Image:
                setImagePreview();
                break;
            case Video:
                setVideoPreview();
                break;
            case Audio:
                setAudioPreview();
                break;
        }
    }

    MediaPlayer mediaPlayer;

    private void setAudioPreview() {
        audioPreviewHolder.setVisibility(View.VISIBLE);
        videoPreviewHolder.setVisibility(View.GONE);
        imagePreviewHolder.setVisibility(View.GONE);

        cover.setVisibility(View.GONE);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                isPaused = false;
                ivAudioPlayPause.setImageResource(playButtonResourceId);
            }
        });
        ivAudioPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    pauseAudioMessage();
                } else {
                    if (isPaused) {
                        resumeAudioMessage();
                    } else {
                        playAudioMessage();
                    }
                }
            }
        });
    }

    private void playAudioMessage() {
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(filePath);
            mediaPlayer.prepare();
            mediaPlayer.start();
            ivAudioPlayPause.setImageResource(pauseButtonResourceId);
            pbAudioProgress.setProgress(0);
            pbAudioProgress.setMax(mediaPlayer.getDuration() / PROGRESS_FACTOR);
            startTimer();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    boolean isPaused = false;

    private void pauseAudioMessage() {
        isPaused = true;
        mediaPlayer.pause();
        ivAudioPlayPause.setImageResource(playButtonResourceId);
        timer.cancel();
    }

    private void resumeAudioMessage() {
        mediaPlayer.start();
        ivAudioPlayPause.setImageResource(pauseButtonResourceId);
        startTimer();
        isPaused = false;
    }

    Timer timer;

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                final int currentPosition = mediaPlayer.getCurrentPosition();
                pbAudioProgress.setProgress(currentPosition / PROGRESS_FACTOR);
            }
        }, 0, PROGRESS_FACTOR);
    }

    private void setVideoPreview() {
        audioPreviewHolder.setVisibility(View.GONE);
        videoPreviewHolder.setVisibility(View.VISIBLE);
        imagePreviewHolder.setVisibility(View.GONE);
        ivAudioPlayPause.setVisibility(View.VISIBLE);
        ImageUtil.setBlurredImage(filePath, ivVideoPreview, ImageUtil.Quality.VERY_LOW);
//        Glide.with(AppContext.get().getContext())
//                .load(filePath)
//                .crossFade()
//                .centerCrop()
//                .error(R.drawable.file_broken)
//                .thumbnail(.2f).into(ivVideoPreview);
        ivVideoPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Switcher.switchToVideoPreview(filePath);
            }
        });
    }

    private void setImagePreview() {
        audioPreviewHolder.setVisibility(View.GONE);
        videoPreviewHolder.setVisibility(View.GONE);
        imagePreviewHolder.setVisibility(View.VISIBLE);
        Glide.with(AppContext.getAccess().getContext())
                .load(filePath)
                .crossFade()
                .error(R.drawable.file_broken)
                .into(ivImagePreview);
//        ivImagePreview.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
//            @Override
//            public void onGlobalLayout() {
//                ivImagePreview.getViewTreeObserver().removeOnGlobalLayoutListener(this);
//                int height = ivImagePreview.getMeasuredHeight();
//                logger.log("height = " + height);
////                height = height - ConfidePreviewActivity.TEXT_HEIGHT;
//                logger.log("height = " + height);
//                ViewGroup.LayoutParams layoutParams = cover.getLayoutParams();
//                layoutParams.height = height;
//                cover.setLayoutParams(layoutParams);
//                ViewGroup.LayoutParams layoutParams1 = imagePreviewHolder.getLayoutParams();
//                layoutParams1.height = height;
//                imagePreviewHolder.setLayoutParams(layoutParams1);
//
//                cover.invalidate();
//                imagePreviewHolder.invalidate();
//            }
//        });
        ivImagePreview.postDelayed(new Runnable() {
            @Override
            public void run() {
                ivImagePreview.measure(0, 0);
                int height = ivImagePreview.getMeasuredHeight();
                logger.log("height = " + height);
//                height = height - ConfidePreviewActivity.TEXT_HEIGHT;
                logger.log("height = " + height);
                ViewGroup.LayoutParams layoutParams = cover.getLayoutParams();
                layoutParams.height = height;
                cover.setLayoutParams(layoutParams);
                ViewGroup.LayoutParams layoutParams1 = imagePreviewHolder.getLayoutParams();
                layoutParams1.height = height;
                imagePreviewHolder.setLayoutParams(layoutParams1);

                cover.invalidate();
                imagePreviewHolder.invalidate();
            }
        }, 2000);
        ivImagePreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Switcher.switchToImagePreview(filePath);
            }
        });
    }

    private void initViews(View view) {
        blurViewTop = view.findViewById(R.id.blurViewTop);
        blurViewBottom = view.findViewById(R.id.blurViewBottom);

        View decorView = Objects.requireNonNull(getActivity()).getWindow().getDecorView();
        //Activity's root View. Can also be root View of your layout (preferably)
        ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);
        //set background, if your root layout doesn't have one
        Drawable windowBackground = decorView.getBackground();
        BlurAlgorithm blurAlgorithm;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            blurAlgorithm = new RenderScriptBlur(getActivity());
        } else {
            blurAlgorithm = new SupportRenderScriptBlur(getActivity());
        }
        blurViewTop.setupWith(rootView)
                .windowBackground(windowBackground)
                .blurAlgorithm(blurAlgorithm)
                .blurRadius(25)
                .setHasFixedTransformationMatrix(false);

        blurViewBottom.setupWith(rootView)
                .windowBackground(windowBackground)
                .blurAlgorithm(blurAlgorithm)
                .blurRadius(25)
                .setHasFixedTransformationMatrix(false);

        ivVideoPreview = (ImageView) view.findViewById(R.id.ivVideoPreview);
        ivImagePreview = (ImageView) view.findViewById(R.id.ivImagePreview);
        ivAudioPlayPause = (ImageView) view.findViewById(R.id.ivAudioPlayPause);
        pbAudioProgress = (ProgressBar) view.findViewById(R.id.pbAudioProgress);
        videoPreviewHolder = view.findViewById(R.id.videoPreviewHolder);
        imagePreviewHolder = view.findViewById(R.id.imagePreviewHolder);
        audioPreviewHolder = view.findViewById(R.id.audioPreviewHolder);
        handle = view.findViewById(R.id.handle);

        gap = view.findViewById(R.id.gap);
        GAP_HEIGHT = gap.getLayoutParams().height;
        logger.log("GAP_HEIGHT = " + GAP_HEIGHT);
        cover = view.findViewById(R.id.cover);
//        ViewGroup.LayoutParams layoutParams = cover.getLayoutParams();
//        layoutParams.height = 700;
//        cover.setLayoutParams(layoutParams);
        changeHandle(5000);
        gapOff();
    }

    private static int GAP_HEIGHT = 99;

    private void changeHandle(int height) {
        ViewGroup.LayoutParams layoutParams = handle.getLayoutParams();
        layoutParams.height = height - GAP_HEIGHT;
        handle.setLayoutParams(layoutParams);
    }

    private void gapOn() {
        gap.setVisibility(View.VISIBLE);
    }

    private void gapOff() {
        gap.setVisibility(View.GONE);
    }
}
