package com.revesoft.itelmobiledialer.did;

import android.app.DialogFragment;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;

import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.hbb20.CountryCodePicker;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Rahat on 12/11/2017.
 */

public class ForwardingNumberSettingFragment extends DialogFragment {
    private CountryCodePicker ccp;
    private Button confirmButton;
    private TextView tvCountryCode;
    private EditText etPhoneNumber;
    private View signup_phone_number_container;
    private static final int MAX_PHONE_LENGTH = 20;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.set_forwarded_number_dialog, container, false);
        initView(v);
        return v;
    }

    private void initView(View view) {
        tvCountryCode = view.findViewById(R.id.signup_country_code);
        etPhoneNumber = view.findViewById(R.id.signup_phone_number);
        confirmButton = view.findViewById(R.id.confirmButton);
        confirmButton.setOnClickListener(v -> requestForwardingNumber(v));
        InputFilter[] filterArray = new InputFilter[1];
        filterArray[0] = new InputFilter.LengthFilter(MAX_PHONE_LENGTH);
        etPhoneNumber.setFilters(filterArray);
        signup_phone_number_container = view.findViewById(R.id.signup_phone_number_container);
        signup_phone_number_container.setBackgroundResource(R.drawable.input_area_background_design);
        etPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {

                String country_code = tvCountryCode.getText().toString();
                String phone_number = etPhoneNumber.getText().toString();
                if (phone_number.startsWith("+"))
                    phone_number = phone_number.substring(1);
                if (phone_number.startsWith(country_code.replaceAll("\\D", "")))
                    phone_number = phone_number.substring(country_code.replaceAll("\\D", "").length());
                if (phone_number.startsWith("0"))
                    phone_number = phone_number.substring(1);

                if (phone_number.length() == 0)
                    signup_phone_number_container.setBackgroundResource(R.drawable.input_area_background_design);
                else {
                    String phoneNumber = country_code + phone_number;
                    String countryISOCode = country_code.replaceAll("\\D", "");
                    if (isValidNumber(phoneNumber, country_code))
                        signup_phone_number_container.setBackgroundResource(R.drawable.input_area_background_design);
                    else
                        signup_phone_number_container.setBackgroundResource(R.drawable.invalid_input_area_background_design);
                }
            }
        });
        ccp = view.findViewById(R.id.ccp);
        ccp.setCcpDialogShowNameCode(true);
        ccp.setCcpDialogShowPhoneCode(true);
        ccp.getTextView_selectedCountry().setTypeface(Typeface.create("sans-sherif-medium", Typeface.NORMAL));
        ccp.setOnCountryChangeListener(() -> tvCountryCode.setText(ccp.getSelectedCountryCodeWithPlus()));
    }

    public void requestForwardingNumber(View view) {
        if (!Util.isNetworkAvailable(getActivity())) {
            Util.showNoNetworkDialog(getActivity());
            return;
        }
        String country_code = tvCountryCode.getText().toString();
        String phone_number = etPhoneNumber.getText().toString();

        if (phone_number.trim().length() == 0) {
            Toast.makeText(getActivity(), R.string.please_enter_number_first, Toast.LENGTH_SHORT).show();
            return;
        }
        if (phone_number.startsWith("+")) phone_number = phone_number.substring(1);
        if (phone_number.startsWith(country_code.replaceAll("\\D", "")))
            phone_number = phone_number.substring(country_code.replaceAll("\\D", "").length());
        if (phone_number.startsWith("0")) phone_number = phone_number.substring(1);
        String phoneNumber = country_code + phone_number;
        if (etPhoneNumber.getText().length() == 0) {
            alert(getString(R.string.empty_number_alert));
        } else if (!isPossibleNumber(phoneNumber, country_code))
            I.toast(getString(R.string.invalidNumber));
        else if (!isValidNumber(phoneNumber, country_code)) {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage(getString(R.string.invalid_phone_number));
            bld.setNegativeButton(R.string.edit, null);
            String finalPhone_number = phone_number;
            bld.setPositiveButton(R.string.continue_button, (dialogInterface, i) -> {
                returnNumber(finalPhone_number);
            });
            bld.create().show();
        } else {
            returnNumber(phoneNumber);
        }
    }

    private void returnNumber(String number) {
        Intent data = new Intent();
        data.setData(Uri.parse(number));
        getActivity().setResult(RESULT_OK, data);
        getActivity().finish();
    }

    public boolean isValidNumber(String number, String countryCode) {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        Phonenumber.PhoneNumber numberProto;
        try {
            numberProto = phoneUtil.parse(number.startsWith("+") ? number : ("+" + number), phoneUtil.getRegionCodeForCountryCode(Integer.parseInt(countryCode.replaceAll("\\D", ""))));
        } catch (Exception e) {
            System.err.println("NumberParseException was thrown: " + e.toString());
            return false;
        }
        return phoneUtil.isValidNumber(numberProto);
    }

    private void alert(String message) {
        try {
            AlertDialog.Builder bld = new AlertDialog.Builder(getActivity());
            bld.setMessage(message);
            bld.setPositiveButton("OK", null);
            bld.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isPossibleNumber(String number, String countryCode) {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        Phonenumber.PhoneNumber numberProto;
        try {
            numberProto = phoneUtil.parse(number.startsWith("+") ? number : ("+" + number), phoneUtil.getRegionCodeForCountryCode(Integer.parseInt(countryCode.replaceAll("\\D", ""))));
        } catch (Exception e) {
            System.err.println("NumberParseException was thrown: " + e.toString());
            return false;
        }
        return phoneUtil.isPossibleNumber(numberProto);
    }
}
