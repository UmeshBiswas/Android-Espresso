package com.revesoft.itelmobiledialer.appDatabase.repo;


import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Rate;


public class RateRepo {
    private static final RateRepo ourInstance = new RateRepo();

    private RateRepo() {
    }

    public static RateRepo get() {
        return ourInstance;
    }

    public Cursor getRates() {
        return AppDatabase.get().rateDao().getRates();
    }

    public void deleteAllRates() {
        AppDatabase.get().rateDao().deleteAllRates();
    }

    public void insertRate(String country, String operator, String rate) {
        Rate rate_entry = Rate.newBuilder().country(country)
                .operator(operator).callRate(rate).build();
        AppDatabase.get().rateDao().insert(rate_entry);
    }


}
