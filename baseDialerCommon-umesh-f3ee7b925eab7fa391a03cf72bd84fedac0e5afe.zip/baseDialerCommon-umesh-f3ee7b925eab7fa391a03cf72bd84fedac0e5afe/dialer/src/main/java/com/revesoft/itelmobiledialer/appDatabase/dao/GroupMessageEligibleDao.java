package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.GroupMessageEligible;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface GroupMessageEligibleDao extends BaseDao<GroupMessageEligible> {
    @Query("SELECT * from group_message_eligible_table")
    List<GroupMessageEligible> getAll();


    @Query("SELECT eligibleCount FROM GROUP_MESSAGE_ELIGIBLE_TABLE WHERE callerid=:callId")
    int eligiblePersonCountByCallId(String callId);


    @Query("SELECT COUNT(*) FROM GROUP_MESSAGE_ELIGIBLE_TABLE WHERE groupid=:groupId AND " +
            "callerid=:callerId AND eligibleCount=:memberCount")
    boolean checkIfDataExists(String groupId, String callerId, int memberCount);

}
