package com.revesoft.itelmobiledialer.appApi;

import android.content.Context;

import com.revesoft.api.fileApi.FileApi;
import com.revesoft.api.fileApi.FileApiError;
import com.revesoft.api.fileApi.fileApiInterfaces.ApiResponseListener;
import com.revesoft.api.fileApi.fileApiInterfaces.FileDownloadListener;
import com.revesoft.api.fileApi.fileApiInterfaces.FileUploadListener;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.api.fileApi.FileApiError;
import com.revesoft.api.fileApi.FileApi;
import com.revesoft.api.fileApi.fileApiInterfaces.ApiResponseListener;
import com.revesoft.api.fileApi.fileApiInterfaces.FileDownloadListener;
import com.revesoft.api.fileApi.fileApiInterfaces.FileUploadListener;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ProfileApi {
    private static final String route = ProfilePicUploadDownloadHelper.profilePictureServerRoute;
    private static final String GET_NONCE_FOR_PROFILE_PICTURE_REQUEST_TYPE = "getNonce";
    private static final String GET_PROFILE_INFO_REQUEST_TYPE = "getProfileInfo";
    private static final String PROFILE_PICTURE_DOWNLOAD_REQUEST_TYPE = "downloadImage";
    private static final String PROFILE_PICTURE_UPLOAD_REQUEST_TYPE = "uploadImage";


    public static void getUserProfileInfo(ApiResponseListener responseListener)
    {
        HashMap<String, String> formDatas = new HashMap<>();
        formDatas.put("requesttype",GET_PROFILE_INFO_REQUEST_TYPE);
        API.getAccess().makeRequest(route, formDatas, getNonceFetchParams(), responseListener);
    }

    public static void updateUserProfileInfo(String fullName, String email,String nationality,String dateOfBirth,ApiResponseListener apiResponseListener)
    {
        HashMap<String, String> formDatas = new HashMap<>();
        formDatas.put("requesttype",GET_NONCE_FOR_PROFILE_PICTURE_REQUEST_TYPE);
        formDatas.put("updateData", "1");
        if(fullName !=null)
        {
            formDatas.put("name",fullName);
        }
        if(email != null)
        {
            formDatas.put("emailID",email);
        }
        if(nationality != null)
        {
            formDatas.put("nationality",nationality);
        }
        if(dateOfBirth != null)
        {
            formDatas.put("dateOfBirth",dateOfBirth);
        }
        API.getAccess().makeRequest(route,formDatas,getNonceFetchParams(),apiResponseListener);
    }

    public static void uploadProfilePicture(String filePath, FileUploadListener fileUploadListener)
    {
        try {
            byte[] profilePicByteArray = ProfilePicUploadDownloadHelper.getByteArrayFromImage(filePath);
            long imageHash = ProfilePicUploadDownloadHelper.computeHash(profilePicByteArray);
            Map<String, String> formDatas = new HashMap<>();
            formDatas.put("requesttype", PROFILE_PICTURE_UPLOAD_REQUEST_TYPE);
            formDatas.put("hash", String.valueOf(imageHash));
            Map<String, File> files = new HashMap<>();
            files.put("imageFile", new File(filePath));
            FileApi.Upload.upload(route,formDatas,files,getNonceFetchParams(),fileUploadListener);
        } catch (IOException e) {
            e.printStackTrace();
            fileUploadListener.onUploadError(new FileApiError(e.getMessage()));
        }
    }


    public static void downloadProfilePicture(Context context, String targetUserName, FileDownloadListener fileDownloadListener)
    {
        File destinationFile = ProfilePicUploadDownloadHelper.getProfilePictureFile(context,targetUserName);
        Map<String, String> formDatas = new HashMap<>();
        formDatas.put("requesttype", PROFILE_PICTURE_DOWNLOAD_REQUEST_TYPE);
        formDatas.put("targetUsername", targetUserName);
        FileApi.Download.download(route, destinationFile, formDatas, getNonceFetchParams(), fileDownloadListener);
    }





    private static HashMap<String,String> getNonceFetchParams()
    {
        HashMap<String, String> nonceFetchParams = new HashMap<>();
        nonceFetchParams.put("username", UserDataManager.getUserName());
        nonceFetchParams.put("requesttype",GET_NONCE_FOR_PROFILE_PICTURE_REQUEST_TYPE);
        return nonceFetchParams;
    }

}
