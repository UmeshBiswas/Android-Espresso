package com.revesoft.itelmobiledialer.databaseentry;

import com.revesoft.itelmobiledialer.signalling.model.CallLog;

public class CallLogEntry {
    public String number;
    public short type = CallLogType.OUTGOING;
    public long id, time;
    public int duration = 0;
    public int callType = CallType.PUSH;
    public boolean callStarted = false;
    public double callRate;
    public boolean isVideoCall;
    public String recordFilePath;
    public String callID;

    public static CallLogEntry from(CallLog callLog) {
        CallLogEntry callLogEntry = new CallLogEntry();
        callLogEntry.callID = callLog.callID;
        callLogEntry.callRate = callLog.callRate;
        callLogEntry.callStarted = callLog.callStarted;
        callLogEntry.callType = (int) callLog.callType;
        callLogEntry.duration =  (int) callLog.duration;
        callLogEntry.id = callLog.id;
        callLogEntry.isVideoCall = callLog.isVideoCall;
        callLogEntry.number = callLog.number;
        callLogEntry.recordFilePath = callLog.recordFilePath;
        callLogEntry.time = callLog.time;
        callLogEntry.type = callLog.type;
        return callLogEntry;
    }

    public static interface CallLogType {
        public static short OUTGOING = 0, INCOMING = 1, MISSED = 2, CALLTHROUGH = 3;
    }

    public static interface CallType {
        public static int PUSH = 0, PAID = 1;
    }
}