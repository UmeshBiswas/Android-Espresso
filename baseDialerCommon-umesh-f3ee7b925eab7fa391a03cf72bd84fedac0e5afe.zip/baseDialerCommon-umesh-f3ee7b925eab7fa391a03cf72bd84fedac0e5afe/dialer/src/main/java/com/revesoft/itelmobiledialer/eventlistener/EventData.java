package com.revesoft.itelmobiledialer.eventlistener;

public abstract class EventData {

}
