package com.revesoft.itelmobiledialer.chat.chatWindow.messageSender;

/**
 * @author Ifta on 12/24/2017.
 */

public class SendingConstants {
    static final String OUT_GOING_TEXT_SINGLE = "outgoingmessage";
    static final String OUT_GOING_TEXT_GROUP = "outgoinggroupmessage";

    public static final String OUT_GOING_QUOTE_TEXT_MESSAGE_SINGLE = "outgoingmessagequote";
    public static final String OUT_GOING_QUOTE_TEXT_MESSAGE_GROUP = "outgoinggroupmessagequote";

    static final String FUTURE_OUT_GOING_TEXT_SINGLE = "outgoingfuturemessage";
    static final String FUTURE_OUT_GOING_TEXT_GROUP = "outgoingfuturegroupmessage";



    public static final String FUTURE_FILE_UPLOAD="outgoingfuturemessage";
    static final String FUTURE_EDITED_TEXT_SINGLE = "editfuturemessage";
    static final String FUTURE_EDITED_TEXT_GROUP = "editfuturegroupmessage";

    static final String SMS = "sendsms";
    public static final String SMS_FROM_GROUP = "sendsmsfromgroup";
    static final String FUTURE_SMS = "sendfuturesms";


    static final String EDITED_TEXT_SINGLE = "editoutgoingmessage";
    static final String EDITED_TEXT_GROUP = "editoutgoinggroupmessage";

    public static final int MAX_IM_LENGTH = 10000;
}
