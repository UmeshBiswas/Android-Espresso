package com.revesoft.itelmobiledialer.account;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.iid.FirebaseInstanceId;
import com.revesoft.itelmobiledialer.Config.Config;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.BaseRepo;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListAdapter;
import com.revesoft.itelmobiledialer.customview.imageListDialog.ImageListItem;
import com.revesoft.itelmobiledialer.data.CommonPreference;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.dialer.DashboardActivity;
import com.revesoft.itelmobiledialer.dialer.SplashScreenActivity;
import com.revesoft.itelmobiledialer.dialer.callForward.CallForwardingSettingsActivity;
import com.revesoft.itelmobiledialer.language.Languages;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.rates.RateListActivity;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.signalling.newMessaging.IMMessageProcessor;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.braodcast.SimpleBroadcaster;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.io.File;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import me.leolin.shortcutbadger.ShortcutBadger;

import static com.revesoft.itelmobiledialer.dialer.DashboardActivity.UPDATE_REGISTRATION_IMAGE;
import static com.revesoft.itelmobiledialer.signalling.sipUtil.Configuration.LAST_CONTACT;
import static com.revesoft.itelmobiledialer.signalling.sipUtil.Configuration.MSG_QUEUE;


/**
 * @author Sayma and ifta
 *         on 5/14/2017.
 */

public class AccountActivity extends BaseActivity {
    Context context;
    Toolbar toolbar;
    ImageView ivProfilePicture;
    TextView tvName, tvStatus, tvOnlineStatus, tvActivationStatus, tvVirtualNumber;
    ImageView ivEdit, tvOnlinePhoto;
    String currentStatus = "Offline";
    LinearLayout balanceLayout;
    TextView tvBalance, tvCallForward, tvLanguage;
    CardView virtualNumberCard;

    public static void startForTesting(Context context) {
        Intent intent = new Intent(context, AccountActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_page);
        context = AccountActivity.this;
        handleToolbar();
        intiViews();
        setViewData();
        IntentFilter intentFilter = new IntentFilter(Constants.SIGNAL_INTENT_FILTER);
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(broadcastReceiver, intentFilter);

        IntentFilter dialpadIntentFilter = new IntentFilter(Constants.DIALPAD_INTENT_FILTER);
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(balanceReceiver, dialpadIntentFilter);

        IntentFilter filter = new IntentFilter(Constants.DASHBOARD_INTENT_FILTER);
        filter.addAction(Constants.DIALPAD_INTENT_FILTER);
        LocalBroadcastManager.getInstance(this).registerReceiver(registrationStatusReceiver, filter);
        sendBalanceRequest();
        Util.getSalamONumberViaReturnID(this);

    }

    private void sendBalanceRequest() {
        if(Config.DIALER_VARIANT == DialerService.DialerVariant.SALAM) {
            Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
            intent.putExtra("update_balance", "");
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
        }
    }

    private void intiViews() {
        ivProfilePicture = findViewById(R.id.ivProfilePicture);
        tvName = findViewById(R.id.tvNameOfQuotee);
        tvStatus = findViewById(R.id.tvStatus);
        tvOnlineStatus = findViewById(R.id.tvOnlineStatus);
        tvOnlinePhoto = findViewById(R.id.tvOnlinePhoto);
        tvActivationStatus = findViewById(R.id.tvActivationStatus);
        ivEdit = findViewById(R.id.ivEdit);
        ivEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(EditProfileActivity.class);
            }
        });

        tvBalance = findViewById(R.id.tvBalance);
        tvCallForward = findViewById(R.id.tvCallForward);
        tvLanguage = findViewById(R.id.tvLanguage);
        virtualNumberCard = findViewById(R.id.virtual_number_card);
        tvVirtualNumber = findViewById(R.id.virtual_number);
        balanceLayout = findViewById(R.id.balance_layout);
        tvName.setOnClickListener(v -> {
//        startActivity(new Intent(this,VirtualNumberRegistrationActivity.class));
        });
    }

    private static String getSizeName(Context context) {
        int screenLayout = context.getResources().getConfiguration().screenLayout;
        screenLayout &= Configuration.SCREENLAYOUT_SIZE_MASK;

        switch (screenLayout) {
            case Configuration.SCREENLAYOUT_SIZE_SMALL:
                return "small";
            case Configuration.SCREENLAYOUT_SIZE_NORMAL:
                return "normal";
            case Configuration.SCREENLAYOUT_SIZE_LARGE:
                return "large";
            case 4: // Configuration.SCREENLAYOUT_SIZE_XLARGE is API >= 9
                return "xlarge";
            default:
                return "undefined";
        }
    }


    private String getDeviceResolution(Context context) {
        int density = context.getResources().getDisplayMetrics().densityDpi;
        switch (density) {
            case DisplayMetrics.DENSITY_MEDIUM:
                return "MDPI";
            case DisplayMetrics.DENSITY_HIGH:
                return "HDPI";
            case DisplayMetrics.DENSITY_LOW:
                return "LDPI";
            case DisplayMetrics.DENSITY_XHIGH:
                return "XHDPI";
            case DisplayMetrics.DENSITY_TV:
                return "TV";
            case DisplayMetrics.DENSITY_XXHIGH:
                return "XXHDPI";
            case DisplayMetrics.DENSITY_XXXHIGH:
                return "XXXHDPI";
            default:
                return "Text";
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        updateUserData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(broadcastReceiver);
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(balanceReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(registrationStatusReceiver);

    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(getString(R.string.account));
        }
    }


    private void updateUserData() {
        setProfilePicture();
        setName();
        setStatus();
        setCurrentStatus();
        setActivationStatus();
        tvLanguage.setText(Languages.getCurrentSelectedLanguage());
        String callForwardStatus;
        boolean isCallForwardEnabled = PreferenceDataManager.quickGet(AccountPreference.Keys.IS_ENABLED_CALL_FORWARDING, false);
        if (isCallForwardEnabled) {
            callForwardStatus = getString(R.string.Enabled);
        } else {
            callForwardStatus = getString(R.string.Disabled);
        }
        tvCallForward.setText(callForwardStatus);
        if(Config.DIALER_VARIANT == DialerService.DialerVariant.SALAM && UserDataManager.getSalamNumberActivated()){
            virtualNumberCard.setVisibility(View.VISIBLE);
            balanceLayout.setVisibility(View.GONE);
            tvBalance.setText(String.format("%s %s", UserDataManager.getBalance(),
                    (Config.DIALER_VARIANT == DialerService.DialerVariant.AZERCELL) &&
                            !TextUtils.isEmpty(SIPProvider.currentCurrency) ? SIPProvider.currentCurrency : ""));
            tvVirtualNumber.setText(Util.formatNumberInLocal(UserDataManager.getSalamNumber()));
        }
        else if(Config.DIALER_VARIANT == DialerService.DialerVariant.SALAM && UserDataManager.getRequestCodeForSalamNumber().length() > 1){
            virtualNumberCard.setVisibility(View.VISIBLE);
            balanceLayout.setVisibility(View.GONE);
            tvBalance.setText(String.format("%s %s", UserDataManager.getBalance(),
                    (Config.DIALER_VARIANT == DialerService.DialerVariant.AZERCELL) &&
                            !TextUtils.isEmpty(SIPProvider.currentCurrency) ? SIPProvider.currentCurrency : ""));
            tvVirtualNumber.setText(getString(R.string.pending));
        }
        else{
            virtualNumberCard.setVisibility(View.GONE);
            balanceLayout.setVisibility(View.GONE);
        }

    }


    private void setViewData() {
        updateUserData();
    }

    public void setCurrentStatus(String newStatus) {
        currentStatus = UserDataManager.getPresenceStatus();
        if (!currentStatus.equals(newStatus)) {
            UserDataManager.setPresenceStatus(newStatus);
            SimpleBroadcaster.sendSignalToDialer(Constants.Broadcast.TYPE_STATUS_CHANGED);
            updateUserData();
        }
    }

    public void changeStatus(View view) {
        ArrayList<ImageListItem> adapterItems = new ArrayList<>();
        adapterItems.add(new ImageListItem(getString(R.string.online), R.drawable.online_round));
        adapterItems.add(new ImageListItem(getString(R.string.away), R.drawable.away_round));
        adapterItems.add(new ImageListItem(getString(R.string.busy), R.drawable.busy_round));
        adapterItems.add(new ImageListItem(getString(R.string.offline), R.drawable.offline_round));

        ImageListAdapter imageListAdapter = new ImageListAdapter(AccountActivity.this, adapterItems, true, R.color.black);
        AlertDialog.Builder builder = new AlertDialog.Builder(AccountActivity.this);
        builder.setAdapter(imageListAdapter,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                        switch (item) {
                            case 0:
                                setCurrentStatus("available");
                                break;
                            case 1:
                                setCurrentStatus("away");
                                break;
                            case 2:
                                setCurrentStatus("busy");
                                break;
                            case 3:
                                setCurrentStatus("offline");
                                break;
                            default:
                                setCurrentStatus("offline");
                                break;
                        }
                        dialog.dismiss();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void setActivationStatus() {
        if (UserDataManager.isActivated()) {
            tvActivationStatus.setText(getString(R.string.activated));
        } else {
            tvActivationStatus.setText(getString(R.string.notActivated));
        }
    }

    private void setCurrentStatus() {
        if (!Util.hasConnection(AccountActivity.this) || !SIPProvider.registrationFlag) {
            tvOnlineStatus.setText(R.string.offline);
            tvOnlinePhoto.setImageResource(R.drawable.offline_round);
        } else {
            currentStatus = UserDataManager.getPresenceStatus();
            if (currentStatus.equalsIgnoreCase("Offline")) {
                tvOnlineStatus.setText(R.string.offline);
            } else if (currentStatus.equalsIgnoreCase("Away")) {
                tvOnlineStatus.setText(R.string.away);
            } else if (currentStatus.equalsIgnoreCase("Busy")) {
                tvOnlineStatus.setText(R.string.busy);
            } else {
                tvOnlineStatus.setText(R.string.online);
            }
            tvStatus.setText(UserDataManager.getPresenceNote());
            setCurrentStatusPhoto();
        }

    }

    private void setCurrentStatusPhoto() {
        if (currentStatus.equalsIgnoreCase("Offline")) {
            tvOnlinePhoto.setImageResource(R.drawable.offline_round);
        } else if (currentStatus.equalsIgnoreCase("Away")) {
            tvOnlinePhoto.setImageResource(R.drawable.away_round);
        } else if (currentStatus.equalsIgnoreCase("Busy")) {
            tvOnlinePhoto.setImageResource(R.drawable.busy_round);
        } else {
            tvOnlinePhoto.setImageResource(R.drawable.online_round);
        }
    }

    private void setStatus() {
        tvStatus.setText(UserDataManager.getPresenceNote());
    }

    private void setName() {
        tvName.setText(UserDataManager.getFullName());
        tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(AccountActivity.this, VirtualNumberRegistrationActivity.class);
//                startActivity(i);
            }
        });
    }

    private void setProfilePicture() {
        String profilePicturePath = UserDataManager.getProfilePicturePath();
        ImageUtil.setImageButDefaultOnException(AccountActivity.this, profilePicturePath, ivProfilePicture, R.drawable.person);
    }



    public void handleLogout(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(getString(R.string.confirm));
        builder.setMessage(getString(R.string.sureLogout));
        builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
//                logout();
                PreferenceDataManager.quickPut(Constants.USER_READY_FOR_NOTIFICATION, false);
                new LogoutAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                dialog.dismiss();
            }
        });
        builder.setNegativeButton(R.string.neverMind, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();

    }

    public class LogoutAsyncTask extends AsyncTask<String, Void, Boolean> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            try {
                pd = ProgressDialog.show(AccountActivity.this, null, "Logging out");
                pd.setCancelable(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected Boolean doInBackground(String... param) {
            logout();
            return true;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            try {
                if (pd != null) {
                    pd.dismiss();
                    pd = null;
                    DashboardActivity.dashboardActivity.finish();
                    Log.e("Logout", "Logging out.. dashboard closed >>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            IntentUtil.stopDialerService(getApplicationContext());
            IntentUtil.sendAppExitMessage(getApplicationContext());
            Log.w("Logout", "Logging out.. on post ex");

            try{
                Thread.sleep(1000);
            } catch (Exception e){
                e.printStackTrace();
            }

            Intent mStartActivity = new Intent(AccountActivity.this, SplashScreenActivity.class);
            mStartActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int mPendingIntentId = 123456;
            PendingIntent mPendingIntent = PendingIntent.getActivity(AccountActivity.this, mPendingIntentId,    mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
            AlarmManager mgr = (AlarmManager)AccountActivity.this.getSystemService(Context.ALARM_SERVICE);
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 300, mPendingIntent);
            Log.w("Logout", "Logging out.. going to sleep");

            System.exit(0);

        }
    }

    private void logout() {
        Log.w("Logout", "Logging out.. logout()");
        UserDataManager.clearAll();
        SIPProvider.currentBalance = "";
        SIPProvider.currentCurrency = "";
        try {
            Log.w("Logout", "Logging out.. deleting instance id");
            FirebaseInstanceId instanceID = FirebaseInstanceId.getInstance();
            instanceID.deleteInstanceId();
            Log.w("Logout", "Logging out.. instance is deleted");
            Thread.sleep(500);
        } catch (Exception e) {
            e.printStackTrace();
        }
        IntentUtil.stopSIPProvider(AccountActivity.this);
        Log.w("Logout", "Logging out.. SIPProvider stopped");
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.w("Logout", "Logging out.. Deleting all table records");
        Executor.ex(() -> {
            BaseRepo.get().deleteAllTableRecords();
        });
        Log.w("Logout", "Logging out.. ALL Table records deleted");
        try {
            deleteLastContactFromFile();
            deleteMessageQueue();
            deleteFile(MSG_QUEUE);
            deleteFile(LAST_CONTACT);
            File file = new File(MSG_QUEUE);
            if (file.exists()) {
                file.delete();
            }
            file = new File(LAST_CONTACT);
            if (file.exists()) {
                file.delete();
            }
            Thread.sleep(500);

            Log.w("Logout", "Logging out.. Logout done");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try{
//            Database.destroy();
//            DatabaseConstants.newInstance(context).destroy();
            ShortcutBadger.applyCount(AppContext.getAccess().getContext(), 0);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void deleteLastContactFromFile() {
        try {
            Log.w("Logout", "Logging out.. deleteLastContactFromFile()");
            if (DialerService.getLastContact() != null) {
                DialerService.getLastContact().clear();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                        openFileOutput(LAST_CONTACT,
                                Context.MODE_PRIVATE));
                objectOutputStream.writeObject(DialerService.getLastContact());
                objectOutputStream.close();
            }
//            if (DialerService.contactMultiMap != null) {
//                DialerService.contactMultiMap.clear();
//            }
            deleteFile(LAST_CONTACT);
            File file = new File(LAST_CONTACT);
            if (file.exists()) {
                boolean isDeleted = file.delete();
                Log.w("Logout", "Logging out.. deleting message queue status: "+isDeleted);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteMessageQueue() {
        try {
            Log.w("Logout", "Logging out.. deleteMessageQueue()");
            if (IMMessageProcessor.messageQueue != null) {
                IMMessageProcessor.messageQueue.clear();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                        openFileOutput(MSG_QUEUE,
                                Context.MODE_PRIVATE));
                objectOutputStream.writeObject(IMMessageProcessor.messageQueue);
                objectOutputStream.close();
                IMMessageProcessor.messageQueue = null;
            }
            deleteFile(MSG_QUEUE);
            File file = new File(MSG_QUEUE);
            if (file.exists()) {
                boolean isDeleted = file.delete();
                Log.w("Logout", "Logging out.. deleting message queue status: "+isDeleted);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleLanguage(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setItems(Languages.getLanguages(), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(which == 2){
                    I.toast(getString(R.string.wip));
                    dialog.dismiss();
                }else{
                    CommonPreference.quickPut(Constants.LANGUAGE, which);
                    dialog.dismiss();
                    showAppRestartDialog();
                }

            }
        });
        builder.create().show();
    }

    private void showAppRestartDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(getString(R.string.areYouSure));
        builder.setMessage(getString(R.string.appRestartRequireToChangeLanguage));
        builder.setPositiveButton(getString(R.string.restart_now), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
//                Util.restartApp(AccountActivity.this);
                dialog.dismiss();
//                Intent mStartActivity = new Intent(AccountActivity.this, SplashScreenActivity.class);
//                mStartActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                int mPendingIntentId = 123456;
//                PendingIntent mPendingIntent = PendingIntent.getActivity(AccountActivity.this, mPendingIntentId,    mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
//                AlarmManager mgr = (AlarmManager)AccountActivity.this.getSystemService(Context.ALARM_SERVICE);
//                mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 300, mPendingIntent);
//
//                IntentUtil.stopDialerService(getApplicationContext());
//                IntentUtil.sendAppExitMessage(getApplicationContext());
                System.exit(0);
            }
        });
        builder.setNegativeButton(getString(R.string.restart_later), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    public void handleAbout(View view) {
        startActivity(AboutActivity.class);
    }

    public void handleSalamShare(View view) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, getString(R.string.invitationText));
        sendIntent.setType("text/plain");
        startActivity(Intent.createChooser(sendIntent, AccountActivity.this.getString(R.string.complete_action_using)));
//        BottomSheetDialogFragment bottomSheetDialogFragment = new InviteBottomSheet();
//        bottomSheetDialogFragment.show(getSupportFragmentManager(), bottomSheetDialogFragment.getTag());
//        startActivity(InviteFriendsActivity.class);
    }

    public void handleCallForward(View view) {

        startActivity(new Intent(this, CallForwardingSettingsActivity.class));
    }

    public void handleCheckRate(View view) {
        startActivity(RateListActivity.class);
    }

    public void handleBalance(View view) {
//        if(Config.DIALER_VARIANT == DialerService.DialerVariant.APP) {
//            Intent i = new Intent(this, BalanceSettingActivity.class);
//            startActivity(i);
//        }
    }

    public void handleSettings(View view) {
        startActivity(SettingsActivity.class);
    }

    private void startActivity(Class<?> targetClass) {
        Intent intent = new Intent(AccountActivity.this, targetClass);
        startActivity(intent);
    }



    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.hasExtra(Constants.Broadcast.TYPE_NETWORK_STATE_CHANGED)) {
                setCurrentStatus();
            }
        }
    };

    BroadcastReceiver balanceReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.hasExtra(DashboardActivity.UPDATE_BALANCE)) {
                updateBalance();
            }
        }
    };

    private void updateBalance() {
    }

    BroadcastReceiver registrationStatusReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
              if (bundle.containsKey(UPDATE_REGISTRATION_IMAGE)) {boolean registration_staus = bundle.getBoolean(UPDATE_REGISTRATION_IMAGE);
                    Log.d("Abhi", "UPDATE_REGISTRATION_IMAGE " + registration_staus );
                  setCurrentStatus();
                }
            }
        }

    };
}
