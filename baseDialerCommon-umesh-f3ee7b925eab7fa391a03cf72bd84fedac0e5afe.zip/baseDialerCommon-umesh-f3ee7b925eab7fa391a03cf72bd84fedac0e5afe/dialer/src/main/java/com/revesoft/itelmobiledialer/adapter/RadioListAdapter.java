package com.revesoft.itelmobiledialer.adapter;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.model.RadioState;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ifta on 5/21/2017.
 */

public class RadioListAdapter extends BaseAdapter{
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<RadioState> data;
    public RadioListAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<RadioState> objects) {
        this.context = context;
        this.layoutInflater = ((Activity)context).getLayoutInflater();
        data = new ArrayList<>(objects);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return data.get(position).hashCode();
    }


    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        Holder holder;
        if(convertView == null){
            view = layoutInflater.inflate(R.layout.custom_radio_button,parent,false);
            holder = new Holder();
            holder.tvRadioText = (TextView) view.findViewById(R.id.tvRadioText);
            holder.radioButton = (RadioButton) view.findViewById(R.id.radioButton);
            view.setTag(holder);
        }else {
            holder = (Holder) view.getTag();
        }

        RadioState radioState = data.get(position);
        holder.tvRadioText.setText(radioState.text);
        holder.radioButton.setChecked(radioState.isChecked);
//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                for(RadioState  rs : data){
//                    rs.isChecked = false;
//                }
//                data.get(position).isChecked = true;
//                notifyDataSetChanged();
//            }
//        });
        return view;
    }

    private class Holder{
        TextView tvRadioText;
        RadioButton radioButton;
    }
}
