/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:20 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:20 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "sms_log")
public class SMSLog {
    @NonNull
    @PrimaryKey(autoGenerate =  true)
    public int _id;

    @NonNull
    public String number = AppDatabaseDefault.number;

    @NonNull
    public Date date = AppDatabaseDefault.date;

    @NonNull
    public String text = "";

    public int type = 0;

    public SMSLog() {
    }

    private SMSLog(Builder builder) {
        _id = builder._id;
        number = builder.number;
        date = builder.date;
        text = builder.text;
        type = builder.type;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private int _id;
        private String number;
        private Date date;
        private String text;
        private int type;

        private Builder() {
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withNumber(String val) {
            number = val;
            return this;
        }

        public Builder withDate(Date val) {
            date = val;
            return this;
        }

        public Builder withText(String val) {
            text = val;
            return this;
        }

        public Builder withType(int val) {
            type = val;
            return this;
        }

        public SMSLog build() {
            return new SMSLog(this);
        }
    }
}
