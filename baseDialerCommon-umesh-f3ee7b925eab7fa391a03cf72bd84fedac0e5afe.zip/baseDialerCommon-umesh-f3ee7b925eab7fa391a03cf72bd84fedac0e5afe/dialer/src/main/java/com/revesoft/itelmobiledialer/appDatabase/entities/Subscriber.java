/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:31 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:31 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "subscriber")
public class Subscriber{

    public Subscriber() {
    }

    public int _id;

    @NonNull
    @PrimaryKey
    public String number = AppDatabaseDefault.number;

    public String name;

    @NonNull
    @ColumnInfo(name = "lookup_key")
    public String lookUpKey = AppDatabaseDefault.lookUpKey;

    @Nullable
    @ColumnInfo(name = "presencestate")
    public int presencesState = 4;

    @Nullable
    @ColumnInfo(name = "presencenote")
    public String presenceNote = "";

    @Nullable
    @ColumnInfo(name = "subscriberimagehash")
    public String subscriberImageHash;

    @Nullable
    @ColumnInfo(name = "last_online_time")
    public Date lastOnlineTime = new Date(0);

    @Nullable
    @ColumnInfo(name = "isfavourite")
    public boolean isFavorite = false;

    @NonNull
    @ColumnInfo(name = "buddy_public_key")
    public String buddyPublicKey = "";

    @NonNull
    @ColumnInfo(name = "buddy_seed")
    public String buddySeed = "";

    private Subscriber(Builder builder) {
        _id = builder._id;
        number = builder.number;
        name = builder.name;
        lookUpKey = builder.lookUpKey;
        presencesState = builder.presencesState;
        presenceNote = builder.presenceNote;
        subscriberImageHash = builder.subscriberImageHash;
        lastOnlineTime = builder.lastOnlineTime;
        isFavorite = builder.isFavorite;
        buddyPublicKey = builder.buddyPublicKey;
        buddySeed = builder.buddySeed;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private int _id;
        private String number = AppDatabaseDefault.number;
        private String name = "";
        private String lookUpKey = AppDatabaseDefault.lookUpKey;
        private int presencesState =4;
        private String presenceNote ="";
        private String subscriberImageHash;
        private Date lastOnlineTime = new Date(0);
        private boolean isFavorite =false;
        private String buddyPublicKey="";
        private String buddySeed="";

        private Builder() {
        }

        public Builder id(long _id) {
            this._id = (int)_id;
            return this;
        }

        public Builder number(String number) {
            this.number = number;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder lookUpKey(String lookUpKey) {
            this.lookUpKey = lookUpKey;
            return this;
        }

        public Builder presencesState(int presencesState) {
            this.presencesState = presencesState;
            return this;
        }

        public Builder presenceNote(String presenceNote) {
            this.presenceNote = presenceNote;
            return this;
        }

        public Builder subscriberImageHash(String subscriberImageHash) {
            this.subscriberImageHash = subscriberImageHash;
            return this;
        }

        public Builder lastOnlineTime(Date lastOnlineTime) {
            this.lastOnlineTime = lastOnlineTime;
            return this;
        }

        public Builder isFavorite(boolean isFavorite) {
            this.isFavorite = isFavorite;
            return this;
        }

        public Builder buddyPublicKey(String buddyPublicKey) {
            this.buddyPublicKey = buddyPublicKey;
            return this;
        }

        public Builder buddySeed(String buddySeed) {
            this.buddySeed = buddySeed;
            return this;
        }

        public Subscriber build() {
            return new Subscriber(this);
        }
    }
}
