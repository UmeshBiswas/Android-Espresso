package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;


import android.view.View;
import android.widget.TextView;


import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDateTimeFormatter;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.material.R;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 12/12/2017.
 */

public class SystemMessageViewHolder extends RecyclerView.ViewHolder {
    private TextView tvDate;
    private TextView tvMessage;
    private TextView tvTime;

    public SystemMessageViewHolder(View view) {
        super(view);
        tvDate = (TextView) view.findViewById(R.id.tvDate);
        tvTime = (TextView) view.findViewById(R.id.tvTime);
        tvMessage = (TextView) view.findViewById(R.id.tvMessage);
    }

    public void bindView(Message message) {
        handleDate(message);
        tvTime.setText(ChatDateTimeFormatter.getMessageTime(message.receivedTime));
        tvMessage.setText(message.content);
    }

    private void handleDate(Message message) {
        if (message.isHeader) {
            tvDate.setVisibility(View.VISIBLE);
            tvDate.setText(ChatDateTimeFormatter.getHeaderDate(message.receivedTime));
        } else {
            tvDate.setVisibility(View.GONE);
        }
    }
}
