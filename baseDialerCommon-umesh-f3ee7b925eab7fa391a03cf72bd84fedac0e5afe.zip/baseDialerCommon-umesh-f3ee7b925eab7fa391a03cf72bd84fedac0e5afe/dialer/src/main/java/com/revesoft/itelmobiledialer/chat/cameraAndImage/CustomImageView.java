package com.revesoft.itelmobiledialer.chat.cameraAndImage;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.widget.ImageView;

public class CustomImageView extends ImageView {

	public CustomImageView(Context context) {
		super(context);
	}

	public CustomImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public CustomImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		try {
			float radiusX, radiusY;

			Path clipPath = new Path();
			RectF rect = new RectF(0, 0, this.getWidth(), this.getHeight());

			// Set radius based upon image size
			radiusX = 0.5f * this.getHeight();
			radiusY = 0.5f * this.getWidth();

			// Log.d("Width and Height", this.getWidth() + " " + this.getHeight());

			// Set radius equal to each other for circular image
			// radiusX = 75.0f;
			// radiusY = 75.0f;

			clipPath.addRoundRect(rect, radiusX, radiusY, Path.Direction.CW);
			canvas.clipPath(clipPath);
			super.onDraw(canvas);
		} catch (Exception e){
			e.printStackTrace();
		}
	}
}
