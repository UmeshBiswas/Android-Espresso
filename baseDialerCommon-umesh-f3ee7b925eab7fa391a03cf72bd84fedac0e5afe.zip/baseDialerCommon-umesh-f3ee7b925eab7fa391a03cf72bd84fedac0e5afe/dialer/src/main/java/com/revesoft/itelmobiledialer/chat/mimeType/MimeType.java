package com.revesoft.itelmobiledialer.chat.mimeType;

/**
 * @author Ifta
 *         on 6/7/2017.
 */

public enum MimeType {
    Audio,
    Video,
    Image,
    GIF,
    Sticker,
    CallRejectSticker,
    StaticSticker,
    Document,
    Contact,
    Link,
    Text,
    Location,
    LocationRequest,
    Call,
    Dummy,
    System,
    Deleted,
    Server
}
