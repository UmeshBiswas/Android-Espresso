package com.revesoft.itelmobiledialer.appDatabase.repo;

public class BaseRepo {
    private static final BaseRepo ourInstance = new BaseRepo();

    private BaseRepo() {
    }

    public static BaseRepo get() {
        return ourInstance;
    }

    public void deleteAllTableRecords() {
        CallLogRepo.get().deleteAll();
        SubscriberRepo.get().deleteAllSubscribers();
        GroupRepo.get().deleteAllGroups();
        MessageRepo.get().deleteAllMessages();


//        db.execSQL("DELETE FROM " + DatabaseConstants.TOP_UP_LOG_TABLE + " where 1=1;");
//        db.execSQL("DELETE FROM " + DatabaseConstants.RECHARGE_TABLE + " where 1=1;");
//        db.execSQL("DELETE FROM " + DatabaseConstants.SUBSCRIBED_PACKAGES_TABLE + " where 1=1;");
//        db.execSQL("DELETE FROM " + DatabaseConstants.GROUP_MESSAGE_ELIGIBLE_TABLE + " where 1=1;");
//        db.execSQL("DELETE FROM " + DatabaseConstants.MESSAGE_STATUS_TABLE + " where 1=1;");
    }
}
