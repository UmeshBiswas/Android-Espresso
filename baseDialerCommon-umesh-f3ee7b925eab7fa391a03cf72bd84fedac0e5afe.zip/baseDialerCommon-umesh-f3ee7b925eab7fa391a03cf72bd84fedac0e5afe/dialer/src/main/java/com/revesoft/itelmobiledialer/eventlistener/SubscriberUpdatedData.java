package com.revesoft.itelmobiledialer.eventlistener;

import com.revesoft.itelmobiledialer.signalling.data.PresenceState;

/**
 * Created By suvo on February 03, 2019
 * Project baseDialerCommon
 **/

public class SubscriberUpdatedData extends EventData {
    private String number;
    private PresenceState state;
    private String note;
    private long lastOnlineTime;

    public SubscriberUpdatedData(String number, PresenceState state, String note, long lastOnlineTime) {
        this.number = number;
        this.state = state;
        this.note = note;
        this.lastOnlineTime = lastOnlineTime;
    }

    public String getNumber() {
        return number;
    }

    public PresenceState getState() {
        return state;
    }

    public String getNote() {
        return note;
    }

    public long getLastOnlineTime() {
        return lastOnlineTime;
    }
}
