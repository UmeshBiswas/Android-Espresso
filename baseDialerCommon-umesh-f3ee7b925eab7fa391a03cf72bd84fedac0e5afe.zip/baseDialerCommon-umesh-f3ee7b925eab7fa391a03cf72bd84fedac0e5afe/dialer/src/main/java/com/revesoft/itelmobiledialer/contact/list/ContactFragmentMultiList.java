package com.revesoft.itelmobiledialer.contact.list;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.revesoft.itelmobiledialer.contact.FavoriteContactsActivity;
import com.revesoft.itelmobiledialer.block.BlockedContactActivity;
import com.revesoft.itelmobiledialer.interfaces.Searchable;
import com.revesoft.material.R;
import com.revesoft.material.databinding.FragmentContactListMultipleTypeBinding;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

public class ContactFragmentMultiList extends Fragment implements Searchable {
    // it is expected to implement this fragment with a view pager. but some how view pager is not working.
    // i am left with very close dead line. so leaving this with some technical debt
    private static Fragment fragment = null;

    public static Fragment getInstance() {
        if (fragment == null) {
            fragment = new ContactFragmentMultiList();
        }
        return fragment;
    }

    private boolean isAppContacts = true;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FragmentContactListMultipleTypeBinding binding = DataBindingUtil.inflate(inflater, R.layout.fragment_contact_list_multiple_type, container, false);
        ContactListFragment allContacts = ContactListFragment.newInstance(false, ContactType.ALL);
        ContactListFragment appContacts = ContactListFragment.newInstance(false, ContactType.APP);
        binding.tvApp.setSelected(true);
        setFragment(appContacts);
        binding.tvApp.setOnClickListener(v -> {
            if (!isAppContacts) {
                binding.tvApp.setSelected(true);
                binding.tvAll.setSelected(false);
                setFragment(appContacts);
                isAppContacts = true;
            }
        });
        binding.tvAll.setOnClickListener(v -> {
            if (isAppContacts) {
                binding.tvApp.setSelected(false);
                binding.tvAll.setSelected(true);
                setFragment(allContacts);
                isAppContacts = false;
            }
        });
        setHasOptionsMenu(true);
        return binding.getRoot();
    }

    private Searchable currentSearchable;

    private void setFragment(ContactListFragment fragment) {
        if (getFragmentManager() != null) {
            if (fragment != null) {
                currentSearchable = fragment;
            }
            getFragmentManager()
                    .beginTransaction()
//                    .setCustomAnimations(isAppContacts ? android.R.anim.slide_out_right : android.R.anim.slide_in_left,
//                            isAppContacts ? android.R.anim.slide_in_left : android.R.anim.slide_out_right)
                    .replace(R.id.frame, fragment)
                    .commit();
        }
    }

    @Override
    public void search(String searchString) {
        currentSearchable.search(searchString);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.contact_list, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.actionBlocked) {
            BlockedContactActivity.start(getActivity());
        } else if (item.getItemId() == R.id.actionFavorite) {
            FavoriteContactsActivity.start(getActivity());
        }
        return super.onOptionsItemSelected(item);
    }
}
