package com.revesoft.itelmobiledialer.chat.cameraAndImage;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.iftalab.runtimepermission.AppPermissionListener;
import com.iftalab.runtimepermission.DangerousPermission;
import com.revesoft.itelmobiledialer.confide.ConfideFileSelectionListener;
import com.revesoft.itelmobiledialer.customview.SquareImageView;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.Log;
import com.revesoft.material.R;

import java.io.File;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

;

/**
 * @author Ifta on 1/1/2018.
 */

public class ImageGalleryFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {
    private static final int CAPTURE_FULLSCREEN_REQUEST = 55;
    private static final String KEY_ALREADY_SELECTED_FILE_PATHS = "KEY_ALREADY_SELECTED_FILE_PATHS";
    public static final String CAMERA = "camera";
    public static final String GALLERY = "gallery";
    ArrayList<String> selectedFilePaths = new ArrayList<>();
    private static Fragment fragment = null;
    private static final int VIDEO_MAX_SIZE = 500; //500 MB video size

    public static Fragment getInstance() {
        if (fragment == null) {
            fragment = new ImageGalleryFragment();
        }
        return fragment;
    }

    public static Fragment getInstance(ArrayList<String> alreadySelectedFilePaths) {
        if (fragment == null) {
            fragment = new ImageGalleryFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putStringArrayList(KEY_ALREADY_SELECTED_FILE_PATHS, alreadySelectedFilePaths);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null &&
                getArguments().containsKey(KEY_ALREADY_SELECTED_FILE_PATHS)) {
            this.selectedFilePaths.addAll(getArguments().getStringArrayList(KEY_ALREADY_SELECTED_FILE_PATHS));
        }
    }

    RecyclerView recyclerView;
    View handle;
    RelativeLayout parent;
    ImageGalleryAdapter imageGalleryAdapter;
    ImageView ivNext;
    TextView tvCount;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.image_gallery_layout, container, false);
        handle = view.findViewById(R.id.handle);
        parent = view.findViewById(R.id.container);
        recyclerView = view.findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3, RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);
        imageGalleryAdapter = new ImageGalleryAdapter();
        recyclerView.setAdapter(imageGalleryAdapter);
        ivNext = view.findViewById(R.id.ivNext);
        tvCount = view.findViewById(R.id.tvCount);
        ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedFilePaths.size() > 0) {
                    for (String filePath : selectedFilePaths) {
                        SelectedMediaDataHolder.add(filePath);
                    }
                    CaptionSetterActivity.start(getActivity());
                }
            }
        });
        ivNext.animate().scaleY(0).scaleX(0).setDuration(10).start();
        tvCount.animate().scaleY(0).scaleX(0).setDuration(10).start();
        tvCount.setText("0");
        return view;
    }

    public void clearSelection() {
        selectedFilePaths.clear();
        tvCount.setText("0");
    }


    private class ImageGalleryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private Cursor cursor;

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_gallery_single_item, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ((ViewHolder) holder).bindView(position);
        }

        @Override
        public int getItemCount() {
            if (cursor == null)
                return 1;
            else return cursor.getCount() + 1;
        }

        public void swapData(Cursor data) {
            this.cursor = data;
            notifyDataSetChanged();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {
            SquareImageView ivPreview;
            AppCompatRadioButton radioButton;
            ImageView ivVideoIndicator;

            public ViewHolder(View itemView) {
                super(itemView);
                ivPreview = (SquareImageView) itemView.findViewById(R.id.ivPreview);
                radioButton = (AppCompatRadioButton) itemView.findViewById(R.id.radioButton);
                ivVideoIndicator = (ImageView) itemView.findViewById(R.id.ivVideoIndicator);
            }

            public void bindView(int position) {
                if (position == 0) {
                    radioButton.setVisibility(View.GONE);
                    ivPreview.setImageResource(R.drawable.blue_gallery_photo);
                    ivPreview.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cameraPermission();
                        }
                    });
                    ivVideoIndicator.setVisibility(View.GONE);
                } else {
                    if (cursor != null && cursor.moveToPosition(position - 1)) {
                        final String filePath = cursor.getString(cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA));
                        String mimeType = cursor.getString(cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE));
                        Glide.with(itemView.getContext())
                                .load(filePath)
                                .centerCrop()
                                .crossFade()
                                .thumbnail(0.2f)
                                .error(R.drawable.invalid_image_file)
                                .into(ivPreview);
                        if (mimeType.contains("image")) {
                            ivVideoIndicator.setVisibility(View.GONE);
                        } else {
                            ivVideoIndicator.setVisibility(View.VISIBLE);
                        }
                        radioButton.setChecked(selectedFilePaths.contains(filePath));
                        radioButton.setClickable(false);
                        ivPreview.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (getActivity() instanceof ConfideFileSelectionListener) {
                                    ((ConfideFileSelectionListener) getActivity()).onFileSelect(filePath);
                                } else {
                                    if (selectedFilePaths.contains(filePath)) {
                                        selectedFilePaths.remove(filePath);
                                        if (selectedFilePaths.size() == 0) {
                                            ivNext.animate().scaleY(0).scaleX(0).setDuration(250).start();
                                            tvCount.animate().scaleY(0).scaleX(0).setDuration(250).start();
                                        }
                                        radioButton.setChecked(false);
                                    } else if (selectedFilePaths.size() == 10) {
                                        I.toast(getString(R.string.youCanSelectTenFiles));
                                        tvCount.animate().scaleY(2).scaleX(2).setDuration(150).start();
                                        tvCount.animate().scaleY(1).scaleX(1).setDuration(150).setStartDelay(150).start();
                                    } else {
                                        selectedFilePaths.add(filePath);
                                        ivNext.animate().scaleY(1).scaleX(1).setDuration(250).start();
                                        tvCount.animate().scaleY(1).scaleX(1).setDuration(250).start();
                                        radioButton.setChecked(true);
                                    }
                                    tvCount.setText(String.valueOf(selectedFilePaths.size()));
                                }
                            }
                        });
                    }
                }
            }
        }
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri queryUri = MediaStore.Files.getContentUri("external");

        String[] projection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.TITLE,
                MediaStore.Files.FileColumns.SIZE
        };

        String selection = "(" + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                + ") AND ("
                + MediaStore.Files.FileColumns.SIZE + " > 0 )";


        return new CursorLoader(
                getActivity(),
                queryUri,
                projection,
                selection,
                null,
                MediaStore.Files.FileColumns.DATE_ADDED + " DESC"
        );
    }


    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null && data.moveToFirst()) {
            imageGalleryAdapter.swapData(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAPTURE_FULLSCREEN_REQUEST) {
            Log.d("tarique", "CAPTURE_FULLSCREEN_REQUEST");
            if (resultCode == Activity.RESULT_OK) {
                String capturedFilePath = data.getStringExtra("resultFilePath");
                Log.d("tarique", "capturedFilePath:" + capturedFilePath);
                if (!TextUtils.isEmpty(capturedFilePath)) {
                    File file = new File(capturedFilePath);
                    long file_size = Long.parseLong(String.valueOf(file.length() / (1024 * 1024)));   //MB size
                    if (file_size < VIDEO_MAX_SIZE) {
                        if (getActivity() instanceof ConfideFileSelectionListener) {
                            ((ConfideFileSelectionListener) getActivity()).onFileSelect(capturedFilePath);
                            return;
                        }
                        getActivity().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(new File(capturedFilePath))));
                        selectedFilePaths.add(capturedFilePath);
                        if (selectedFilePaths.size() > 0) {
                            for (String filePath : selectedFilePaths) {
                                SelectedMediaDataHolder.add(filePath);
                            }
                            CaptionSetterActivity.start(getActivity());
                        }
                    } else {
                        I.toast(getString(R.string.too_big_file));
                    }
                }
            } else {
                I.toast(getString(R.string.cancelled));
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        getLoaderManager().restartLoader(0, null, this);
    }

    private void cameraPermission() {
        DangerousPermission.CameraPermission.getAccess(getActivity()).requestPermission(getActivity(), new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                readWriteStoragePermission(CAMERA);
            }

            @Override
            public void onPermissionRejected() {

            }
        });
    }

    private void readWriteStoragePermission(String cameraGallery) {
        DangerousPermission.StoragePermission.getAccess(getActivity()).requestPermission(getActivity(), new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                Intent i = new Intent(getActivity(), FullscreenCameraCaptureActivity.class);
                startActivityForResult(i, CAPTURE_FULLSCREEN_REQUEST);
            }

            @Override
            public void onPermissionRejected() {

            }
        });
    }
}
