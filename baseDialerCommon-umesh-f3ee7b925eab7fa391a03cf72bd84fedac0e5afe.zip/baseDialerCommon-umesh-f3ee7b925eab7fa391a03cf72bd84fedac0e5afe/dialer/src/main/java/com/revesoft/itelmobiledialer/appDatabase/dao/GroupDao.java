package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.Group;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface GroupDao extends BaseDao<Group> {


    @Query("SELECT * FROM GROUP_TABLE")
    List<Group> getAll();



    @Query("SELECT is_encrypted_group FROM GROUP_TABLE WHERE groupid=:groupId")
    int getGroupE2EValue(String groupId);




    default boolean checkForGroup(String groupId){
        return getGroupById(groupId) != null;
    }



    @Query("SELECT * FROM GROUP_TABLE WHERE groupid=:groupId")
    Group getGroupById(String groupId);

    @Query("SELECT * FROM GROUP_TABLE WHERE groupid=:groupId")
    Cursor getGroupCursorById(String groupId);

    @Query("SELECT groupid FROM GROUP_TABLE")
    List<String> allUniqueGroupIds();






    @Query("UPDATE GROUP_TABLE SET buddy_public_key=:publicKey, buddy_seed=:seed," +
            " group_private_key=:groupPrivateKey, is_encrypted_group=1 WHERE groupid=:groupId")
    void updateE2EPublicKeySeedAndPrivateKeyForGroup(String groupId, String publicKey,
                                                     String seed, String groupPrivateKey);




    @Query("UPDATE GROUP_TABLE SET number=:numbers, groupname=:groupName, creator=:isCreator, member=:isMember," +
            "is_encrypted_group=:e2e WHERE groupid=:groupId")
    void updateGroup(String groupId, String groupName,
                            String numbers, int isCreator, int isMember, int e2e);

    @Query("UPDATE GROUP_TABLE SET creatornumber=:creator WHERE groupid=:groupId")
    void updateGroupCreator(String groupId,String creator);


    @Query("UPDATE GROUP_TABLE SET group_type=:groupType WHERE groupid=:groupId")
    void updateGroupType(String groupId,String groupType);



    @Query("SELECT member FROM GROUP_TABLE WHERE groupid=:groupId")
    int checkIfMember(String groupId);

    @Query("SELECT creator FROM GROUP_TABLE WHERE groupid=:groupId")
    int checkIfCreator(String groupId);



    @Query("UPDATE GROUP_TABLE SET member=:isMember WHERE groupid=:groupId")
    void changeGroupMemberShipStatus(String groupId, int isMember);



    @Query("UPDATE GROUP_TABLE SET number=:groupMembers WHERE groupid=:groupId")
    void updateGroupMembers(String groupId, String groupMembers);



    @Query("SELECT groupname FROM GROUP_TABLE WHERE groupid=:groupId")
    String getGroupName(String groupId);


    @Query("UPDATE GROUP_TABLE SET groupname=:groupName WHERE groupid=:groupId")
    void updateGroupName(String groupId, String groupName);


    @Query("SELECT number FROM GROUP_TABLE WHERE groupid=:groupId")
    String getGroupNumbers(String groupId);


    @Query("DELETE FROM GROUP_TABLE")
    void deleteAllGroups();

    @Query("SELECT * FROM GROUP_TABLE")
    Cursor getAllGroupCursor();


}
