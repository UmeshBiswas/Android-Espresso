package com.revesoft.itelmobiledialer.appDatabase.entities;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "hidden_message")
public class HiddenMessage {


    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "_id")
    public int _id;

    @ColumnInfo(name = "number")
    public String number;


    @ColumnInfo(name = "groupid")
    public String groupId;

    @ColumnInfo(name = "is_encrypted")
    public boolean isEncrypted;

    @ColumnInfo(name = "pin_code")
    public String pin_code;

    @ColumnInfo(name = "is_group_chat")
    public boolean isGroupChat;

    public HiddenMessage() {
    }

    private HiddenMessage(Builder builder) {
        _id = builder._id;
        number = builder.number;
        groupId = builder.groupId;
        isEncrypted = builder.isEncrypted;
        pin_code = builder.pin_code;
        isGroupChat = builder.isGroupChat;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private int _id;
        private String number;
        private String groupId;
        private boolean isEncrypted;
        private String pin_code;
        private boolean isGroupChat;

        private Builder() {
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withNumber(String val) {
            number = val;
            return this;
        }

        public Builder withGroupId(String val) {
            groupId = val;
            return this;
        }

        public Builder withIsEncrypted(boolean val) {
            isEncrypted = val;
            return this;
        }

        public Builder withPin_code(String val) {
            pin_code = val;
            return this;
        }

        public Builder withIsGroupChat(boolean val) {
            isGroupChat = val;
            return this;
        }

        public HiddenMessage build() {
            return new HiddenMessage(this);
        }
    }
}
