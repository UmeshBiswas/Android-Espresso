package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.content.Intent;
import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.entities.BurnMessageInfo;
import com.revesoft.itelmobiledialer.databaseentry.BurnTimerEntry;
import com.revesoft.itelmobiledialer.service.burnmessage.BurnMessageHelper;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.Constants;

import java.util.List;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class BurnMessageInfoRepo {
    private static final BurnMessageInfoRepo ourInstance = new BurnMessageInfoRepo();

    private BurnMessageInfoRepo() {
    }

    public static BurnMessageInfoRepo get() {
        return ourInstance;
    }


    public List<BurnMessageInfo> getAll() {
        return AppDatabase.get().burnMessageInfoDao().getAll();
    }

    public void insertAll(List<BurnMessageInfo> burnMessageInfoList) {
        AppDatabase.get().burnMessageInfoDao().insertAll(burnMessageInfoList);
    }


    public Cursor getAllBurnMessageInfoCursor() {
        return AppDatabase.get().burnMessageInfoDao().getAllBurnMessageInfoCursor();
    }


    public void createBurnTimerEntry(BurnTimerEntry burnTimerEntry) {

        BurnMessageInfo burnMessageInfo = modelToEntity(burnTimerEntry);

        AppDatabase.get().burnMessageInfoDao().insert(burnMessageInfo);
    }


    public void deleteBurnMessageEntryByCallerId(String callerId) {
        AppDatabase.get().burnMessageInfoDao().deleteBurnMessageEntryByCallerId(callerId);
    }

    public int getBurnTimerIndex(String number) {
        return AppDatabase.get().burnMessageInfoDao().getBurnTimerIndex(number);
    }

    public boolean isBurnTimeEntryAvailable(String number) {
        return AppDatabase.get().burnMessageInfoDao().isBurnTimeEntryAvailable(number);
    }

    public void updateBurnTimerEntry(BurnTimerEntry burnTimerEntry) {

        //          if (burnTimerEntry.retryTime <= 0) {
        if (burnTimerEntry.burnTime == -1) {
            AppDatabase.get().burnMessageInfoDao().deleteBurnMessageEntryByNumber(burnTimerEntry.number);
            BurnMessageHelper.removeBurnTimerEntry(burnTimerEntry.number);
        } else {
            BurnMessageInfo burnMessageInfo = modelToEntity(burnTimerEntry);
            AppDatabase.get().burnMessageInfoDao().insert(burnMessageInfo);
        }

        Gui.get().run(() -> {
            Intent mIntent = new Intent(Constants.BURN_TIMER_CHANGE_ACTION);
            LocalBroadcastManager.getInstance(AppContext.getAccess().getContext()).sendBroadcast(mIntent);
        });


    }

    BurnMessageInfo modelToEntity(BurnTimerEntry burnTimerEntry) {
        return BurnMessageInfo.newBuilder().withCallerId(burnTimerEntry.callerId)
                .withNumber(burnTimerEntry.number)
                .withEntryType(burnTimerEntry.entryType)
                .withBurnEntryTime(burnTimerEntry.extactBurnTime)
                .withBurnTime(burnTimerEntry.burnTime)
                .withBurnTimeIndex(burnTimerEntry.burnTimeIndex)
                .withMessageType(burnTimerEntry.messageType).build();

    }
}
