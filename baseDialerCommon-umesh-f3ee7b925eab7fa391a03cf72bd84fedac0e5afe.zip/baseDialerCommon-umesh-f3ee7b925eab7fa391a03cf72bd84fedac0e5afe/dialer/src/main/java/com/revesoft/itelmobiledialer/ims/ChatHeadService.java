package com.revesoft.itelmobiledialer.ims;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.view.WindowManager;

import java.util.HashMap;

public class ChatHeadService extends Service {

    private WindowManager windowManager;
    private static HashMap<String, AnimationHandler> hMapBubbleAnimation = new HashMap<>();
    private String identifierSeperator = "01010101";

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        Log.e("called", "message called");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("called", " on start command  called");

        if (intent != null) {
            Log.d("called", "intent not null");
            String number = intent.getStringExtra("number");
            String groupId = intent.getStringExtra("group_id");
            int e2e = intent.getIntExtra("e2e", 0);
            boolean isCloseCommand = intent.getBooleanExtra("isCloseCommand", false);
            boolean isCloseAllCommand = intent.getBooleanExtra("isCloseAllCommand", false);
            int broadcastId = intent.getIntExtra("broadcastId", -1);

            Log.e(" params", number + "  " + groupId + "  " + isCloseCommand);
            AnimationHandler animationHandler = null;
            String identifer = "";

            if (isCloseAllCommand) {
                stopSelf();
            } else if (groupId != null && groupId.length() != 0) {
                animationHandler = hMapBubbleAnimation.get(groupId);
                identifer = groupId;
            } else {
                animationHandler = hMapBubbleAnimation.get(number + identifierSeperator + e2e);
                identifer = number + identifierSeperator + e2e;
            }
            if (isCloseCommand) {
                if (animationHandler != null)
                    animationHandler.closeAnimation(true);
            } else {
                if (animationHandler == null) {
                    animationHandler = new AnimationHandler(getApplicationContext(), number, groupId, identifer, e2e, this, broadcastId);
                    hMapBubbleAnimation.put(identifer, animationHandler);
                    Log.e("called", " on start command  insider");
                } else {
                    animationHandler.incrementMessageCount();
                }
            }
        }

        return super.onStartCommand(intent, flags, startId);

    }

    private void stopService() {
        this.stopSelf();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//		int size=hMapBubbleAnimation.size();
        for (String key : hMapBubbleAnimation.keySet()) {
            hMapBubbleAnimation.get(key).closeAnimation(false);
        }
        hMapBubbleAnimation.clear();
        /*if (chatHead != null)
            windowManager.removeView(chatHead);
		if(handler!=null)
			handler.removeCallbacks(timedTask);*/
    }

    public void deleteEntry(String number) {
        hMapBubbleAnimation.remove(number);
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Auto-generated method stub
        return null;
    }

    public static void updateGroupProfilePicture() {
        Log.d("AnimationHandler", "updateGroupProfilePicture: called");
        for (String key : hMapBubbleAnimation.keySet()) {
            Log.d("AnimationHandler", "updateGroupProfilePicture: looping on id " + key);
            Log.d("AnimationHandler", "updateGroupProfilePicture: group hit");
            AnimationHandler animationHandler = hMapBubbleAnimation.get(key);
            if (!"".equals(animationHandler.groupId)) {
                animationHandler.setImageInBubble(true);
            }
        }
    }
}