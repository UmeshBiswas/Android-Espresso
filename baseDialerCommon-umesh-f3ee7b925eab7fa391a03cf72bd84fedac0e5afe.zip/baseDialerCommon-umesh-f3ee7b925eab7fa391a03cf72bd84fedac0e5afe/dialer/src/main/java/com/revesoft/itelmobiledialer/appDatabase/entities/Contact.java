package com.revesoft.itelmobiledialer.appDatabase.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
//db.execSQL("CREATE TABLE  IF NOT EXISTS contacts(_id integer primary key autoincrement,
// number text not null,
// name text,
// lookup_key text not null,
// contact_id text not null,
// photo_uri text default null,
// processed_number text ,
// is_favourite integer)");
@Entity(tableName = "contacts")
public class Contact {
    @NonNull
    @PrimaryKey(autoGenerate = true)
    public int _id;

    @NonNull
    public String number ="";

    public String name;
    @NonNull
    @ColumnInfo(name = "lookup_key")
    public String lookupKey="";

    @NonNull
    @ColumnInfo(name = "contact_id")
    public String contactId="";

    @ColumnInfo(name = "photo_uri")
    public String photoUri = null;

    @ColumnInfo(name = "processed_number")
    public String preocessedNumber;

    @ColumnInfo(name = "is_favourite")
    public boolean isFavorite = false;

    public static Builder newBuilder(){
        return new Builder();
    }

    public Contact(){}

    private Contact(Builder builder){
        this.number=builder.number;
        this.name=builder.name;
        this.lookupKey=builder.lookUpKey;
        this.contactId=builder.contact_id;
        this.photoUri=builder.photoUri;
        this.preocessedNumber=builder.processedNumber;
        this.isFavorite=builder.isFavorite;
    }





    public static class Builder{
        String number="";
        String name="";
        String lookUpKey="";
        String contact_id="";
        String photoUri=null;
        String processedNumber="";
        boolean isFavorite=false;
        private Builder(){}


        public Builder setNumber(String number){
            this.number=number;
            return this;
        }
        public Builder setName(String name){
            this.name=name;
            return this;
        }

        public Builder setLookUpKey(String lookUpKey) {
            this.lookUpKey = lookUpKey;
            return this;
        }

        public Builder setContact_id(String contact_id) {
            this.contact_id = contact_id;
            return this;
        }

        public Builder setPhotoUri(String photoUri) {
            this.photoUri = photoUri;
            return this;
        }

        public Builder setProcessedNumber(String processedNumber) {
            this.processedNumber = processedNumber;
            return this;
        }

        public Builder setFavorite(boolean favorite) {
            isFavorite = favorite;
            return this;
        }

        public Contact build(){
            return new Contact(this);
        }
    }

}
