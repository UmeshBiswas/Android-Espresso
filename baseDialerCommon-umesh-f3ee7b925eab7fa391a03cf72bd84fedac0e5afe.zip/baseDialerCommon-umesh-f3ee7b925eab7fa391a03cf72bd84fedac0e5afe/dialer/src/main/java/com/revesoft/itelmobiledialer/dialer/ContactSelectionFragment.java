package com.revesoft.itelmobiledialer.dialer;

import android.app.SearchManager;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.interfaces.SelectionActivity;
import com.revesoft.itelmobiledialer.interfaces.SelectionFragment;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.processor.contactblock.ContactBlockHelper;
import com.revesoft.itelmobiledialer.testunit.TestType;
import com.revesoft.itelmobiledialer.testunit.WhiteBox;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.CallMaker;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.util.TextHighlighter;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.xdatabase.DatabaseUris;
import com.revesoft.material.R;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.revesoft.itelmobiledialer.dialer.ContactSelectionFragment.ContactType.APP;
import static com.revesoft.itelmobiledialer.dialer.ContactSelectionFragment.ContactType.NON_APP;

/**
 * @author Ifta
 */

public class ContactSelectionFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>, SelectionFragment {
    public static final String TAG = "ContactsForInviteFriendsFragmentTag";
    public static final String KEY_CONTACT_TYPE = "KEY_CONTACT_TYPE";
    public static final String KEY_EXCLUTION_CONTACTS = "KEY_EXCEPTION_CONTACTS";
    public static final String KEY_IS_FOR_BLOCKING_LIST = "KEY_IS_FOR_BLOCKING_LIST";
    public static final String KEY_HIDE_TICK_MARK = "KEY_HIDE_TICK_MARK";
    public static final String KEY_HIDE_CALL_ICONS = "KEY_HIDE_CALL_ICONS";


    public static String getTAG() {
        return TAG;
    }

    private static final int LOADER_ID = 123;
    RecyclerView rv;
    RecyclerView.LayoutManager layoutManager;

    ContactAdapter adapter;
    SelectionActivity parentActivity;

    public enum ContactType {
        APP, NON_APP, ALL
    }

    ContactType contactType;
    boolean isForBlockingList = false;
    boolean hideTickMark = false;
    boolean hideCallIcons = false;
    public ContactSelectionFragment() {
    }

    private static Fragment fragment;

    public static Fragment newInstance(ContactType contactType) {
        if (fragment == null) {
            fragment = new ContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static Fragment newInstance(ContactType contactType,boolean hideTickMark) {
        if (fragment == null) {
            fragment = new ContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        bundle.putBoolean(KEY_HIDE_TICK_MARK,hideTickMark);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static Fragment newInstance(ContactType contactType,boolean hideTickMark, boolean isForChatCreation) {
        if (fragment == null) {
            fragment = new ContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        bundle.putBoolean(KEY_HIDE_TICK_MARK,hideTickMark);
        bundle.putBoolean(KEY_HIDE_CALL_ICONS, isForChatCreation);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static Fragment newInstance(boolean isForBlockingList) {
        if (fragment == null) {
            fragment = new ContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, APP);
        bundle.putBoolean(KEY_IS_FOR_BLOCKING_LIST, isForBlockingList);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static Fragment newInstance(ContactType contactType, boolean hideTickMark, boolean hideCallIcons, List<String> excludeContacts) {
        if (fragment == null) {
            fragment = new ContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        bundle.putBoolean(KEY_HIDE_TICK_MARK,hideTickMark);
        bundle.putBoolean(KEY_HIDE_CALL_ICONS, hideCallIcons);
        if(excludeContacts!=null) {
            bundle.putStringArray(KEY_EXCLUTION_CONTACTS,excludeContacts.toArray(new String[excludeContacts.size()]));
        }
        bundle.putBoolean(KEY_IS_FOR_BLOCKING_LIST,false);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static Fragment newInstance(ContactType contactType, String[] exceptionContactNumbers) {
        if (fragment == null) {
            fragment = new ContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        bundle.putStringArray(KEY_EXCLUTION_CONTACTS, exceptionContactNumbers);
        fragment.setArguments(bundle);
        return fragment;
    }


    public static Fragment newInstance(ContactType contactType, String[] exceptionContactNumbers , boolean isForChatCreation) {
        if (fragment == null) {
            fragment = new ContactSelectionFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_CONTACT_TYPE, contactType);
        bundle.putStringArray(KEY_EXCLUTION_CONTACTS, exceptionContactNumbers);
        bundle.putBoolean(KEY_HIDE_CALL_ICONS, isForChatCreation);
        fragment.setArguments(bundle);
        return fragment;
    }

    String[] excludedContacts;
    int highLightColor;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            contactType = (ContactType) getArguments().getSerializable(KEY_CONTACT_TYPE);
            excludedContacts = getArguments().getStringArray(KEY_EXCLUTION_CONTACTS);
            isForBlockingList = getArguments().getBoolean(KEY_IS_FOR_BLOCKING_LIST);
            hideCallIcons = getArguments().getBoolean(KEY_HIDE_CALL_ICONS,false);
            hideTickMark = getArguments().getBoolean(KEY_HIDE_TICK_MARK);
            if (isForBlockingList) {
                excludedContacts = new String[CommonData.blockedNumber.size()];
                int index = 0;
                for (String blockedNumber : CommonData.blockedNumber) {
                    excludedContacts[index++] = blockedNumber;
                }
                searchText = "";
                if (searchView != null) {
                    searchView.setQuery(searchText, true);
                }
            }
        }
        setHasOptionsMenu(true);
        highLightColor = ContextCompat.getColor(getActivity(), R.color.appBlue);
    }

    @Override
    public void onPause() {
        super.onPause();
        searchText = "";
    }

    @Override
    public void onDestroy() {
        searchText = "";
        getLoaderManager().destroyLoader(LOADER_ID);
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.contact_selection_layout, container, false);
        parentActivity = (SelectionActivity) getActivity();
        rv = v.findViewById(R.id.rv);
        layoutManager = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(layoutManager);
        adapter = new ContactAdapter(getActivity());
        rv.setAdapter(adapter);

        v.setFocusableInTouchMode(true);
        v.requestFocus();
        v.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    getActivity().getSupportFragmentManager().popBackStackImmediate();
                    return true;
                }
                return false;
            }
        });
        v.setFocusableInTouchMode(true);
        v.requestFocus();
        v.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    getActivity().finish();
                    return true;
                }
                return false;
            }
        });
        getLoaderManager().initLoader(LOADER_ID, null, this);
        return v;
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        if (id == LOADER_ID) {
            return new SQLiteCursorLoader(getActivity()) {
                @Override
                public Cursor loadInBackground() {
                    Cursor cursor = null;
                    switch (contactType) {
                        case APP:
                            WhiteBox.hit(TestType.APP_CONTACTS_LOADER);
                            if (excludedContacts == null) {
                                cursor = ContactRepo.get().getAppContactsCursor(searchText);
                            } else {
                                cursor = ContactRepo.get().getAppContactsCursorExcludingSome(searchText, excludedContacts);
                            }
                            break;
                        case NON_APP:
                            WhiteBox.hit(TestType.NON_APP_CONTACT_LOADER);
                            cursor = ContactRepo.get().getNonAppContactsCursor(searchText);
                            break;
                        case ALL:
                            WhiteBox.hit(TestType.ALL_CONTACTS_LOADER);
                            cursor = ContactRepo.get().allCursor(searchText);
                            break;
                    }
                    if (cursor != null && cursor.moveToFirst()) {
                        this.registerContentObserver(cursor, DatabaseUris.CONTACTS_URI);
                        return cursor;
                    }
                    return null;
                }
            };

        }
        return null;
    }
    private int totalContactLoaded = 0;
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (loader.getId() == LOADER_ID) {
            totalContactLoaded = data.getCount();
            if (adapter != null) {
                adapter.swapCursor(data);
            }
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    @Override
    public void onDestroyView() {
        getLoaderManager().destroyLoader(LOADER_ID);
        super.onDestroyView();
    }

    private class ContactAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int ITEM_VIEW = 5000;
        private static final int EMPTY_VIEW = 6000;
        Cursor dataCursor = null;
        Context context;

        private ContactAdapter(Context context) {
            this.context = context;
        }

        int swapcount = 0;
        protected void swapCursor(Cursor cursor) {
            dataCursor = cursor;
            notifyDataSetChanged();
            if(swapcount == 0){
                rv.smoothScrollToPosition(0);
                swapcount++;
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v;
            if (viewType == EMPTY_VIEW) {
                v = LayoutInflater.from(parent.getContext()).inflate(R.layout.empty_list_layout, parent, false);
                return new ContactAdapter.EmptyViewHolder(v);
            } else if (viewType == ITEM_VIEW) {
                v = LayoutInflater.from(context).inflate(R.layout.contact_select_single_item, parent, false);
                return new ContactAdapter.ContactViewHolder(v);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof ContactAdapter.EmptyViewHolder) {
                ContactAdapter.EmptyViewHolder vh = (ContactAdapter.EmptyViewHolder) holder;
                vh.tvEmptyTextDescription.setText(getText(R.string.noAppContact));
                vh.ivEmptyListIcon.setImageResource(R.drawable.empty_list_app_icon);
            } else if (holder instanceof ContactAdapter.ContactViewHolder) {
                ContactAdapter.ContactViewHolder vh = (ContactAdapter.ContactViewHolder) holder;
                vh.bindView();
            }
        }

        @Override
        public int getItemCount() {
            if (dataCursor == null || dataCursor.getCount() == 0) {
                return 1;
            }
            return dataCursor.getCount();
        }

        @Override
        public int getItemViewType(int position) {
            if (dataCursor == null || dataCursor.getCount() == 0) {
                return EMPTY_VIEW;
            }
            return ITEM_VIEW;
        }

        class EmptyViewHolder extends RecyclerView.ViewHolder {
            TextView tvEmptyTextDescription;
            ImageView ivEmptyListIcon;

            public EmptyViewHolder(View itemView) {
                super(itemView);
                tvEmptyTextDescription = itemView.findViewById(R.id.tvEmptyListDescription);
                ivEmptyListIcon = itemView.findViewById(R.id.ivEmptyListIcon);
            }
        }

        class ContactViewHolder extends RecyclerView.ViewHolder {
            ImageView ivPhoneContactImage;
            TextView tvName;
            TextView tvPhoneNumber;
            ImageView ivMarked;
            TextView tvSectionChar;
            RelativeLayout rlPhoneContactHeaderHolder;
            ImageView ivAudioCall, ivVideoCall, ivSalamOutCall;
            Button bUnblock;

            private ContactViewHolder(View itemView) {
                super(itemView);
                ivPhoneContactImage = itemView.findViewById(R.id.ivPhoneContactImage);
                tvName = itemView.findViewById(R.id.tvContactName);
                tvPhoneNumber = itemView.findViewById(R.id.tvPhoneNumber);
                ivMarked = itemView.findViewById(R.id.ivMarked);
                tvSectionChar = itemView.findViewById(R.id.tvSectionLetter);
                rlPhoneContactHeaderHolder = itemView.findViewById(R.id.phoneContactHeaderHolder);
                ivAudioCall = itemView.findViewById(R.id.ivAudioCall);
                ivVideoCall = itemView.findViewById(R.id.ivVideoCall);
                ivSalamOutCall = itemView.findViewById(R.id.ivSalamOutCall);
                bUnblock = itemView.findViewById(R.id.bUnblock);
            }
            @SuppressWarnings("unused")
            private boolean isSectionStart(Cursor cursor) {
                if (cursor.getPosition() == 0) {
                    return true;
                }
                String currentName = cursor.getString(cursor.getColumnIndex("tvName"));
                cursor.moveToPrevious();
                String previousName = cursor.getString(cursor.getColumnIndex("tvName"));
                cursor.moveToNext();
                return !currentName.substring(0, 1).toUpperCase().equals(previousName.substring(0, 1).toUpperCase());
            }
            @SuppressWarnings("unused")
            private String getSectionChar(String name) {
                if (name == null) {
                    return "#";
                }
                String sectionChar = name.substring(0, 1);
                if (Util.isNumeric(sectionChar)) {
                    return "#";
                }
                return sectionChar.toUpperCase();
            }

            public void bindView() {
                if (dataCursor == null) {
                    return;
                }
                try {
                    int position = getAdapterPosition();
                    dataCursor.moveToPosition(position);
//                    boolean isSectionStart = isSectionStart(dataCursor);
                    final Contact contact = new Contact(Contact.ContactType.DATABASE_CONTACT_APP, dataCursor);
                    setNameAndNumber(contact);
                    if (contactType != NON_APP) {
                        String profilePicturePath = ProfilePictureDataProvider.getProfilePicturePath(AppContext.getAccess().getContext(), contact.processedNumber);
                        if (profilePicturePath != null) {
                            contact.imageUri = profilePicturePath;
                        }
                    }
                    ImageUtil.setImageButTextImageOnException(getActivity(), contact.imageUri, ivPhoneContactImage, tvName.getText().toString());
//                    UserStatusUtil.setStatus(contact.processedNumber,onlineStatus);

                    if (parentActivity.getSelectionList().contains(contact)) {
                        ivMarked.setVisibility(View.VISIBLE);
                    } else {
                        ivMarked.setVisibility(View.GONE);
                    }

                    itemView.findViewById(R.id.mainContent).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            searchText = "";
                            if (searchView != null) {
                                searchView.setQuery(searchText, true);
                            }
                            if (!CommonData.blockedNumber.contains(contact.processedNumber)) {

                                if (parentActivity.getSelectionList().contains(contact)) {
                                    ivMarked.setVisibility(View.GONE);
                                    parentActivity.removeItemFromSelectionList(contact);
                                } else {
                                    if(!hideTickMark) {
                                        ivMarked.setVisibility(View.VISIBLE);
                                    }
                                    parentActivity.addItemToSelectionList(contact);
                                }
                                if(hideTickMark){
                                    ivMarked.setVisibility(View.GONE);
                                }else {
                                    ivMarked.setVisibility(View.VISIBLE);
                                }
                            }
                        }
                    });


                    if (isForBlockingList) {
                        ivAudioCall.setVisibility(View.GONE);
                        ivVideoCall.setVisibility(View.GONE);
                        ivSalamOutCall.setVisibility(View.GONE);
                        bUnblock.setVisibility(View.GONE);
                    } else {
                        if (CommonData.blockedNumber.contains(contact.processedNumber)) {
                            hideCallButtons();
                            handleUnblockButton(contact.processedNumber);
                        } else {
                            hideUnblockButton();
                            hideCallButtons();
//                            handleCallButtons(contact.processedNumber);

                        }
                    }
                    rlPhoneContactHeaderHolder.setVisibility(View.GONE);
                    if(hideCallIcons)
                    {
                        ivAudioCall.setVisibility(View.GONE);
                        ivVideoCall.setVisibility(View.GONE);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            private void hideUnblockButton() {
                bUnblock.setVisibility(View.GONE);
            }

            private void hideCallButtons() {
                ivAudioCall.setVisibility(View.GONE);
                ivVideoCall.setVisibility(View.GONE);
                ivSalamOutCall.setVisibility(View.GONE);
            }

            private void handleUnblockButton(final String phoneNumber) {
                bUnblock.setVisibility(View.VISIBLE);
                bUnblock.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        I.log("handleUnblockButton onClick");
                        ContactBlockHelper.getAccess().unblock( phoneNumber);
                    }
                });
            }

            private void handleCallButtons(String number) {
                final String translatedNumber = Util.translateNumber(number);
                if (CommonData.subscriberPhoneNumberToLookUpKey.containsKey(translatedNumber)) {
                    ivAudioCall.setVisibility(View.VISIBLE);
                    ivVideoCall.setVisibility(View.VISIBLE);
                    ivSalamOutCall.setVisibility(View.GONE);
                    ivAudioCall.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            CallMaker.handleAudioCall(getActivity(),translatedNumber);
                        }
                    });
                    ivVideoCall.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            CallMaker.makeVideoCall(getActivity(),translatedNumber);
                        }
                    });
                } else {
                    ivAudioCall.setVisibility(View.GONE);
                    ivVideoCall.setVisibility(View.GONE);
                    ivSalamOutCall.setVisibility(View.VISIBLE);
//                    ivSalamOutCall.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            CallMaker.makePaidCall(getActivity(),translatedNumber);
//                        }
//                    });
                }
            }

            private void setNameAndNumber(Contact contact) {
                if (TextUtils.isEmpty(searchText) || searchText.trim().length() < 1) {
                    tvName.setText(contact.name);
                    tvPhoneNumber.setText(contact.phoneNumber);
                } else {
                    SpannableString highlightedName = TextHighlighter.getHighlightedText(contact.name, searchText);
                    tvName.setText(highlightedName);
                    SpannableString highlightedNumber = TextHighlighter.getHighlightedText(contact.phoneNumber, searchText);
                    tvPhoneNumber.setText(highlightedNumber);
                }
            }
        }
    }
    @SuppressWarnings("unused")
    private void changeSearchIcon() {
        ImageView ivSearchIcon = searchView.findViewById(R.id.search_button);
        if (ivSearchIcon != null) {
            ivSearchIcon.setImageResource(R.drawable.ic_menu_search);
        }
    }

    SearchView searchView;
    String searchText = "";

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_invite_friends, menu);
        final MenuItem searchItem = menu.findItem(R.id.app_bar_search_contacts);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
//        I.log("search item null : "+ (searchItem ==null));
//        I.log("search view null : "+ (searchView ==null));
        if (searchView != null) {
//            changeSearchIcon();
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
            searchView.setIconifiedByDefault(true);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    if (TextUtils.isEmpty(newText)) {
                        searchText = "";
                    } else {
                        searchText = newText;
                    }
                    getActivity().getSupportLoaderManager().restartLoader(LOADER_ID, null, ContactSelectionFragment.this);
                    return true;
                }
            });
        }
//        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        // Make sure that we are currently visible
        if (this.isVisible()) {
            // If we are becoming invisible, then...
            if (!isVisibleToUser) {
                if (!searchText.equals("")) {
                    searchText = "";
                    if (searchView != null) {
                        searchView.setQuery("", false);
                    }
                    getLoaderManager().restartLoader(LOADER_ID, null, this);
                }
            }
        }
    }

    @Override
    public void requestUpdateState() {
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public int getTotalContactCount() {
        return totalContactLoaded;
    }

}
