package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.HiddenMessage;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface HiddenMessageDao extends BaseDao<HiddenMessage> {


    @Query("SELECT * FROM hidden_message")
    List<HiddenMessage> getAll();


    @Query("DELETE FROM HIDDEN_MESSAGE")
    void deleteAllHiddenMessage();


    @Query("DELETE FROM HIDDEN_MESSAGE WHERE groupid=:groupId AND is_group_chat=1")
    void deleteByGroupId(String groupId);


    @Query("DELETE FROM HIDDEN_MESSAGE WHERE number=:number")
    void deleteByNumber(String number);

    @Query("SELECT COUNT(*) FROM HIDDEN_MESSAGE WHERE number=:number")
    int checkIfHiddenChatByNumber(String number);


    @Query("SELECT COUNT(*) FROM HIDDEN_MESSAGE WHERE groupid=:groupId")
    boolean checkIfHiddenChatByGroupId(String groupId);


    @Query("SELECT COUNT(*) FROM HIDDEN_MESSAGE WHERE number=:number AND is_encrypted=:isEncrypted")
    boolean checkIfHiddenChatByNumberAndEncryption(String number, int isEncrypted);
}
