package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;



import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Ifta on 2/13/2018.
 */

public class DialerServiceEventHook {
    private static ArrayList<DialerServiceEventListener> listeners = new ArrayList<>();

    public static void attachEventListener(DialerServiceEventListener dialerServiceEventListener) {
        listeners.add(dialerServiceEventListener);
    }

    public static void dispatchEvent(final DialerServiceEvent event, final String data) {
        for (DialerServiceEventListener listener : listeners) {
            if (listener != null) {
                if (listener instanceof AppCompatActivity) {
                    ((AppCompatActivity) listener).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            listener.onDialerServiceEvent(event, data);
                        }
                    });
                }
            }
        }
    }

    public static void dispatchEvent(final DialerServiceEvent event, final HashMap<String,String> data) {
        for (DialerServiceEventListener listener : listeners) {
            if (listener != null) {
                if (listener instanceof AppCompatActivity) {
                    ((AppCompatActivity) listener).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            listener.onDialerServiceEvent(event, data);
                        }
                    });
                }
            }
        }
    }

    public static void free(DialerServiceEventListener listener) {
        listeners.remove(listener);
    }
}
