package com.revesoft.itelmobiledialer.ffmpeg;

public class FFMPEGInterface {
	
	private static FFMPEGInterface ffmpeg = null;
	
	public static final int CODEC_H263 = 0;
	public static final int CODEC_H263p = 1;
	public static final int CODEC_H264 = 2;
	
	static {
		try{
//			System.loadLibrary("ffmpeg");
			System.loadLibrary("ffmpeg_codec");
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private FFMPEGInterface(){}
	
	public static synchronized FFMPEGInterface getInstance(){
		if(ffmpeg == null){
			ffmpeg = new FFMPEGInterface();
			ffmpeg.register();
		}
		return ffmpeg;
	}
	
	private native void register();

	public native int initencoder(int encoder, int width, int height, int fps, int bitrate);

	public native int initdecoder(int encoder, int width, int height);

	public native int encode(byte[] imageData, int imDataLength, byte[] encodedData, int width, int height);

	public native int decode(byte[] encodedData, int encodedDataLen, int[] decodedData);

	public native int getDecodedWidth();

	public native int getDecodedHeight();

	public native void closeencoder();

	public native void closedecoder();
}
