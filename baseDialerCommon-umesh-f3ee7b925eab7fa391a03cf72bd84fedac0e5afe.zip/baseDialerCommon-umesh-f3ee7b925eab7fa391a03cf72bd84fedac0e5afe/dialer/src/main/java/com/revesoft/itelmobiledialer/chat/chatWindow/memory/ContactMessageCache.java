package com.revesoft.itelmobiledialer.chat.chatWindow.memory;

import com.revesoft.itelmobiledialer.chat.chatWindow.ContactMessage;

import java.util.HashMap;

/**
 * Created by Zim on 24-Apr-18.
 */

public class ContactMessageCache {
    private static final int CACHE_SIZE = 2048;

//    <callerid, ContactMessage>
    public static HashMap<String, ContactMessage> cache = new HashMap<>();

    public static ContactMessage findMessage(String callerID){
         if(cache.containsKey(callerID)){
             return cache.get(callerID);
         }
         return null;
    }

    public static boolean containsMessage(String callerID){
        return cache.containsKey(callerID);
    }

    public static boolean putMessage(String callerID, ContactMessage contactMessage){
        if(cache.size() < CACHE_SIZE){
            cache.put(callerID, contactMessage);
            return true;
        }
        return false;
    }



    public static void invalidate(){
        cache.clear();
    }



}
