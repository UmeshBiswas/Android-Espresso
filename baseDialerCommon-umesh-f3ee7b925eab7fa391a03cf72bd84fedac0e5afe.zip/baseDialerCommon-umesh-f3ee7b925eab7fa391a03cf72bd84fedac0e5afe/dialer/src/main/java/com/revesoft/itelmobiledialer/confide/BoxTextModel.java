package com.revesoft.itelmobiledialer.confide;

/**
 * @author Ifta on 2/5/2018.
 */

public class BoxTextModel {
    String text;
    boolean isVisited;
    int row;
    public BoxTextModel(String text, boolean isVisited, int row) {
        this.text = text;
        this.isVisited = isVisited;
        this.row = row;
    }

    @Override
    public String toString() {
        return "BoxTextModel{" +
                "text='" + text + '\'' +
                ", isVisited=" + isVisited +
                ", row=" + row +
                '}';
    }
}
