package com.revesoft.itelmobiledialer.chat.tenor;

import java.util.ArrayList;

/**
 * @author Ifta on 10/30/2017.
 */

public interface TenorLoadListener {
    void onTenorLoad(ArrayList<TenorGif> tenorGifs);
    void onTenorLoadError(String errorInfo);
}
