/*
 *  Created by Ifta on 8/13/18 11:51 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/9/18 1:10 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "rate_table")
public class Rate {
    @PrimaryKey(autoGenerate = true)
    public int _id;
    @NonNull
    public String country = "";
    @NonNull
    public String operator = "";
    @NonNull
    @ColumnInfo(name = "call_rate")
    public String callRate = "";

    public Rate() {
    }

    private Rate(Builder builder) {
        country = builder.country;
        operator = builder.operator;
        callRate = builder.callRate;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private String country= "";
        private String operator= "";
        private String callRate= "";
        private Builder() {
        }
        public Builder country(String country) {
            this.country = country;
            return this;
        }
        public Builder operator(String operator) {
            this.operator = operator;
            return this;
        }
        public Builder callRate(String callRate) {
            this.callRate = callRate;
            return this;
        }
        public Rate build() {
            return new Rate(this);
        }
    }
}
