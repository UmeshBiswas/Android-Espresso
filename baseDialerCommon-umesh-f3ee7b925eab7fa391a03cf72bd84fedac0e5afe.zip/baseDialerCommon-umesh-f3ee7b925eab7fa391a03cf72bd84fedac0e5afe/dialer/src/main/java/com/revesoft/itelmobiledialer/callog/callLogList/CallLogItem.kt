package com.revesoft.itelmobiledialer.callog.callLogList

import android.text.TextUtils
import android.view.View
import com.revesoft.itelmobiledialer.data.CommonData
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider
import com.revesoft.itelmobiledialer.databaseentry.CallLogEntry
import com.revesoft.itelmobiledialer.util.TimeFormat
import com.revesoft.material.R

class CallLogItem {

    var callId: String? = null
        private set
    var name: String? = null
        private set
    var number: String? = null
        private set
    var date: String? = ""
        private set
    var callTypeResourceId = 0
        private set
    var audioVideoIndicatorResourceId = 0
        private set
    var callTime: String? = null
        private set
    var callDuration: String? = null
        private set
    var headerDateVisibility = View.GONE

    var freeCallVisibility = View.VISIBLE

    var paidCallVisibility = View.GONE

    var unblockVisibility = View.GONE

    var imageUrl: String? = null
        private set

    var callType = 0

    var callDate: Long? = 0


    companion object {

        fun from(callLog: QueryItemCallLogList, isHeader: Boolean): CallLogItem {
            val callLogItem = CallLogItem()
            callLogItem.callId = callLog.callId
            callLogItem.name = if (TextUtils.isEmpty(callLog.name)) callLog.processedNumber else callLog.name
            callLogItem.number = callLog.processedNumber
//            if (isHeader) {
                callLogItem.date = TimeFormat.getDateHeader(callLog.date)
//            }

            when (callLog.callLogType.toShort()) {
                CallLogEntry.CallLogType.INCOMING -> callLogItem.callTypeResourceId = R.drawable.ic_calls_incoming
                CallLogEntry.CallLogType.OUTGOING -> callLogItem.callTypeResourceId = R.drawable.ic_calls_outgoing
                CallLogEntry.CallLogType.MISSED -> callLogItem.callTypeResourceId = R.drawable.ic_calls_missed
                CallLogEntry.CallLogType.CALLTHROUGH -> callLogItem.callTypeResourceId = R.drawable.ic_calls_through
            }
            callLogItem.callType = callLog.callType
            callLogItem.audioVideoIndicatorResourceId = if (callLog.isVideoCall) R.drawable.ic_video_call_indicator else R.drawable.ic_audio_call_indicator
            callLogItem.callTime = TimeFormat.getTime(callLog.date.time)
            callLogItem.callDate = callLog.date.time
            callLogItem.callDuration = TimeFormat.formatDuration(callLog.duration)
            callLogItem.unblockVisibility = if (CommonData.blockedNumber.contains(callLog.processedNumber)) View.VISIBLE else View.GONE
            callLogItem.freeCallVisibility = if (callLogItem.unblockVisibility == View.VISIBLE) View.GONE else if (callLog.callType == CallLogEntry.CallType.PAID) View.GONE else View.VISIBLE
            callLogItem.paidCallVisibility = if (callLogItem.unblockVisibility == View.VISIBLE) View.GONE else if (callLog.callType == CallLogEntry.CallType.PAID) View.VISIBLE else View.GONE
            callLogItem.headerDateVisibility = if (isHeader) View.VISIBLE else View.GONE
            callLogItem.imageUrl = ProfilePictureDataProvider.getProfilePicturePath(callLog.processedNumber)
            return callLogItem
        }
    }
}
