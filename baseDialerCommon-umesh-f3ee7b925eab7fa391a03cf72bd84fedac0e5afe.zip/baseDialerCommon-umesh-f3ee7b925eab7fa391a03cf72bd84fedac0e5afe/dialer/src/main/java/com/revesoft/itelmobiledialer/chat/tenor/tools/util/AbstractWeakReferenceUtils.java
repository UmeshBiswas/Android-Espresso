package com.revesoft.itelmobiledialer.chat.tenor.tools.util;



import java.lang.ref.WeakReference;

import androidx.annotation.Nullable;

/**
 * The weak reference utility class
 */
public abstract class AbstractWeakReferenceUtils {

    public static <T> boolean isAlive(@Nullable final WeakReference<T> weakReference) {
        return weakReference != null && weakReference.get() != null;
    }
}
