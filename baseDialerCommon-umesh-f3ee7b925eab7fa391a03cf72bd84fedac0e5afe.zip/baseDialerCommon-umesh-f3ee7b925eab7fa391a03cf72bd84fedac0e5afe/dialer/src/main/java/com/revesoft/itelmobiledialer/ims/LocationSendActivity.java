package com.revesoft.itelmobiledialer.ims;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;


public class LocationSendActivity extends BaseActivity implements OnMapReadyCallback {
    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    private LatLng latestLatLng;
    private SupportMapFragment mapFragment;
    private boolean hasMarked = false;
    private boolean pendingFlag = false;
    private RelativeLayout contentView;
    private RelativeLayout askPermissionView;

    private Handler handler;
    


    public static void start(Context context) {
        Intent intent = new Intent(context, LocationSendActivity.class);
        context.startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_send);
        handleToolbar();
        handler = new Handler();
        FloatingActionButton sendLocation =  findViewById(R.id.imageButtonImageSend);
        FloatingActionButton fabAskLocation =  findViewById(R.id.fabAskLocation);
        if (ChatProperties.isGroupChat) {
            fabAskLocation.setVisibility(View.GONE);
            findViewById(R.id.tvAskLocation).setVisibility(View.GONE);
        }
        FloatingActionButton getCurrentLocation =  findViewById(R.id.getCurrentLocation);
        contentView =  findViewById(R.id.content_view);
        askPermissionView =  findViewById(R.id.ask_permission_view);
        Button askPermissionButton =  findViewById(R.id.accept_button);

        sendLocation.setOnClickListener(v -> {
            if (latestLatLng != null) {
                Sender.getAccess().sendLocation(latestLatLng);
                finish();
            } else {
                Toast.makeText(LocationSendActivity.this, R.string.select_a_location_first, Toast.LENGTH_SHORT).show();
            }
        });

        getCurrentLocation.setOnClickListener(v -> markLocationORenableGPS());
        fabAskLocation.setOnClickListener(v -> sendLocationRequest());
        askPermissionButton.setOnClickListener(v -> {
            if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforLocation(LocationSendActivity.this).length > 0) {
                Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
                requestPermissions(PermissionUtil.getPermissionsforLocation(LocationSendActivity.this), OnFragmentInteractionListener.TYPE_LOCATION);
            }
        });

        isMapLoaded = false;

    }

    private void sendLocationRequest() {
        Sender.getAccess().sendLocationRequest();
        finish();
    }

    private void handleToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        this.setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.sendLocation));
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforLocation(LocationSendActivity.this).length > 0) {
            contentView.setVisibility(View.GONE);
            askPermissionView.setVisibility(View.VISIBLE);
        } else {
            contentView.setVisibility(View.VISIBLE);
            askPermissionView.setVisibility(View.GONE);
            handler.post(mapLoader);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        isMapLoaded = false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private volatile boolean isMapLoaded = false;
    private FragmentManager fmanager = getSupportFragmentManager();
    private Fragment fragment = fmanager.findFragmentById(R.id.map);
    private final Runnable mapLoader = () -> {
        if (!isMapLoaded) {
            isMapLoaded = true;
            fmanager = getSupportFragmentManager();
            fragment = fmanager.findFragmentById(R.id.map);
            SupportMapFragment supportmapfragment = (SupportMapFragment) fragment;
            supportmapfragment.getMapAsync(LocationSendActivity.this);

//                mapFragment = new SupportMapFragment();
//                LocationSendActivity.this.getSupportFragmentManager().beginTransaction().add(R.id.google_map_fragment, mapFragment).commit();
//                mapFragment.getMapAsync(GoogleMapFragment.this);
            if (pendingFlag) {
                markInitialLocation();
            }
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == OnFragmentInteractionListener.TYPE_LOCATION) {
            Log.i("StartupPermissions", "Received response for required permissions makeRequest.");
            if (PermissionUtil.verifyPermissions(grantResults)) {
                Log.i("StartupPermissions", "ALL required permissions have been granted, starting DialerService.");
                contentView.setVisibility(View.VISIBLE);
                askPermissionView.setVisibility(View.GONE);
                handler.post(mapLoader);
            } else {
                Log.i("StartupPermissions", "Permissions were NOT granted. Showing exit dialog");
                contentView.setVisibility(View.GONE);
                askPermissionView.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 23) {
                    showExitOrGrantPermissionAlert();
                }
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void showExitOrGrantPermissionAlert() {
        try {
            AlertDialog.Builder bld = new AlertDialog.Builder(LocationSendActivity.this);
            bld.setMessage("You did not grant required permissions. You can grant them from application settings.");
            bld.setNegativeButton("Cancel", null);
            bld.setPositiveButton("App settings", (dialog, which) -> {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", LocationSendActivity.this.getPackageName(), null));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                dialog.dismiss();
            });
            bld.setCancelable(false);
            bld.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void markInitialLocation() {
//        if (isGPSEnabled()) {
        MyLocationProvider.LocationListener locationResult = new MyLocationProvider.LocationListener() {
            @Override
            public void locationReceived(Location location) {
                if (location != null) {
                    LatLng myLoc = new LatLng(location.getLatitude(), location.getLongitude());
                    latestLatLng = myLoc;
                    mMap.addMarker(new MarkerOptions().position(myLoc).title(getString(R.string.current_location)));
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(myLoc));
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(myLoc, 14.0f));
                } else {
                    handler.post(() -> Toast.makeText(LocationSendActivity.this, R.string.could_not_determine_current_location, Toast.LENGTH_SHORT).show());
                }
                hasMarked = true;
            }

            @Override
            public void error(String errorMessage) {

            }
        };

        MyLocationProvider myLocation = new MyLocationProvider();
        myLocation.getLocation(LocationSendActivity.this, locationResult);
    }

    private void markLocationORenableGPS() {
        if (isGPSEnabled()) {
            markInitialLocation();
        } else {
            new AlertDialog.Builder(LocationSendActivity.this)
                    .setMessage(R.string.gps_turned_off_turn_it_on)
                    .setPositiveButton(android.R.string.yes, (dialog, whichButton) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton(android.R.string.no, null).show();
            pendingFlag = true;
        }
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapClickListener(latLng -> {
            mMap.clear();
            mMap.addMarker(new MarkerOptions().position(latLng).title(getString(R.string.selected_location)));
            CameraUpdate mCameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 14.0f);
            mMap.animateCamera(mCameraUpdate);
            latestLatLng = latLng;
        });
        markInitialLocation();
    }


    private boolean isGPSEnabled() {
        LocationManager locationManager = (LocationManager) LocationSendActivity.this.getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }


}
