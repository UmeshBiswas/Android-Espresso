package com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments;


import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.bumptech.glide.MemoryCategory;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Searchable;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.chat.tenor.TenorAdapter;
import com.revesoft.itelmobiledialer.chat.tenor.TenorClickListener;
import com.revesoft.itelmobiledialer.chat.tenor.TenorDataLoader;
import com.revesoft.itelmobiledialer.chat.tenor.TenorGif;
import com.revesoft.itelmobiledialer.chat.tenor.TenorLoadListener;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

/**
 * @author Ifta on 10/29/2017.
 */

public class TenorFragment extends Fragment implements Searchable {
    private static final TaggedLogger logger = new TaggedLogger("TenorGif");
    public static final String TAG = "TenorFragment";
    private static TenorFragment fragment = null;

    private TenorClickListener tenorClickListener;

    public static TenorFragment getInstance() {
        if (fragment == null) {
            fragment = new TenorFragment();
        }
        return fragment;
    }

    RecyclerView rvGifList;
    TenorAdapter tenorAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Glide.get(getActivity()).setMemoryCategory(MemoryCategory.HIGH);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tenor_fragment_layout, container, false);
        rvGifList = rootView.findViewById(R.id.rvGifList);
        final RecyclerView.LayoutManager layoutManager = new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.HORIZONTAL);
        rvGifList.setLayoutManager(layoutManager);
        tenorAdapter = new TenorAdapter(getActivity());
        rvGifList.setAdapter(tenorAdapter);
        tenorAdapter.attachTenorClickListener(new TenorClickListener() {
            @Override
            public void onTenorClick(TenorGif tenorGif) {
                Sender.getAccess().sendGif(tenorGif);
            }
        });
        loadAndShowTenor(null);
        return rootView;
    }



    @Override
    public void onDestroy() {
        super.onDestroy();
        TenorDataLoader.getAccess().clear();
        Glide.get(getActivity()).setMemoryCategory(MemoryCategory.NORMAL);
    }

    private void loadAndShowTenor(String searchText) {
        ArrayList<TenorGif> placeHolders = new ArrayList<>(20);
        for(int i = 0 ; i < 20 ; i++){
            placeHolders.add(new TenorGif());
        }
        tenorAdapter.refresh(placeHolders);
        TenorDataLoader.getAccess().getNextSet(getActivity(), searchText, new TenorLoadListener() {
            @Override
            public void onTenorLoad(ArrayList<TenorGif> tenorGifs) {
                tenorAdapter.refresh(tenorGifs);
            }
            @Override
            public void onTenorLoadError(String errorInfo) {

            }
        });
    }

    @Override
    public void search(String searchString) {
        if(!TextUtils.isEmpty(searchString)){
            loadAndShowTenor(searchString);
        }
    }
}
