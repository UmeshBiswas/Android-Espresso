package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;

/**
 * @author Ifta on 2/13/2018.
 */

public enum DialerServiceEvent {
    GroupInfoUpdate,
    GroupLeftOrJoined,
    CallRecordInfoUpdated
}
