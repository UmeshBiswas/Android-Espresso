package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.Persistent;

import androidx.room.Dao;

@Dao
public interface PersistentDao extends BaseDao<Persistent> {


}
