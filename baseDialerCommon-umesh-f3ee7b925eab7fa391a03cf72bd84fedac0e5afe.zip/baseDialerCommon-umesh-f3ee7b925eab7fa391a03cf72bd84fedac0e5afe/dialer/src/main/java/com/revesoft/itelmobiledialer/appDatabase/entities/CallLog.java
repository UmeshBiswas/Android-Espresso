/*
 *  Created by Ifta on 8/8/18 11:06 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/5/18 3:35 PM
 *
 */
package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.UriNotifyEventListener;
import com.revesoft.itelmobiledialer.databaseentry.CallLogEntry;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta at July 30, 2018
 */
@Entity(tableName = "log")
public class CallLog extends EntityBase {
    @NonNull
    @PrimaryKey(autoGenerate = true)
    public int _id;

    @NonNull
    public String callId = "";

    @NonNull
    public String number = "Reve";

    @ColumnInfo(name = "type")
    public int callLogType;

    @ColumnInfo(name = "call_type")
    public int callType;

    @ColumnInfo(name = "call_rate")
    public double callRate;


    @ColumnInfo(name = "is_video_call")
    public boolean isVideoCall;

    @NonNull
    @ColumnInfo(name = "date")
    public Date date = new Date(System.currentTimeMillis());

    @ColumnInfo(name = "duration")
    public int duration = 0;

    @ColumnInfo(name = "processed_number")
    public String processedNumber;

    @ColumnInfo(name = "record_file_path")
    public String recorderFilePath;

    public CallLog() {
    }


    private CallLog(Builder builder) {
        _id = builder._id;
        callId = builder.callId;
        number = builder.number;
        callLogType = builder.callLogType;
        callType = builder.callType;
        callRate = builder.callRate;
        isVideoCall = builder.isVideoCall;
        date = builder.date;
        duration = builder.duration;
        processedNumber = builder.processedNumber;
        recorderFilePath = builder.recorderFilePath;
    }


    public static Builder newBuilder() {
        return new Builder();
    }


    public static CallLog createFromCallLogEntry(CallLogEntry callLogEntry) {
        return newBuilder().
                withCallLogType(callLogEntry.type)
                .withCallRate(callLogEntry.callRate)
                .withCallType(callLogEntry.callType)
                .withDate(new Date(callLogEntry.time))
                .withCallId(callLogEntry.callID)
                .withIsVideoCall(callLogEntry.isVideoCall)
                .withDuration(callLogEntry.duration)
                .withProcessedNumber(Util.translateNumber(callLogEntry.number))
                .withRecorderFilePath(callLogEntry.recordFilePath)
                .withNumber(callLogEntry.number)
                .build();
    }


    public CallLogEntry convertCallLogEntry(){
        CallLogEntry callLogEntry=new CallLogEntry();
        callLogEntry.type=(short) callLogType;
        callLogEntry.callRate=callRate;
        callLogEntry.callType=callType;
        callLogEntry.time=date.getTime();
        callLogEntry.callID=callId;
        callLogEntry.isVideoCall=isVideoCall;
        callLogEntry.duration=duration;
        callLogEntry.number=number;
        callLogEntry.recordFilePath=recorderFilePath;
        return callLogEntry;

    }

    public static CallLog forDelete(String callerID) {
        CallLog callLog = new CallLog();
        callLog.callId = callerID;
        return callLog;
    }

    @Override
    public void save(UriNotifyEventListener listener) {
        Executor.ex(() -> {
            long rowId = AppDatabase.get().callLogDao().insert(this);
            if (rowId > 0) {
                listener.notifyUri();
            }
        });
    }

    @Override
    public void delete(UriNotifyEventListener listener) {
        Executor.ex(() -> {
            int deletedRowCount = AppDatabase.get().callLogDao().delete(this);
            if (deletedRowCount > 0) {
                listener.notifyUri();
            }
        });
    }

    @Override
    public void update(UriNotifyEventListener listener) {
        Executor.ex(() -> {
            int updatedRowCount = AppDatabase.get().callLogDao().update(this);
            if (updatedRowCount > 0) {
                listener.notifyUri();
            }
        });
    }


    public static final class Builder {
        private String number;
        private int callLogType;
        private int callType;
        private double callRate;
        private boolean isVideoCall;
        private Date date;
        private int duration;
        private String processedNumber;
        private String recorderFilePath;
        private int _id;
        private String callId;

        private Builder() {
        }

        public Builder withNumber(String number) {
            this.number = number;
            return this;
        }

        public Builder withCallLogType(int callLogType) {
            this.callLogType = callLogType;
            return this;
        }

        public Builder withCallType(int callType) {
            this.callType = callType;
            return this;
        }

        public Builder withCallRate(double callRate) {
            this.callRate = callRate;
            return this;
        }

        public Builder withIsVideoCall(boolean isVideoCall) {
            this.isVideoCall = isVideoCall;
            return this;
        }

        public Builder withDate(Date date) {
            this.date = date;
            return this;
        }

        public Builder withDuration(int duration) {
            this.duration = duration;
            return this;
        }

        public Builder withProcessedNumber(String processedNumber) {
            this.processedNumber = processedNumber;
            return this;
        }

        public Builder withRecorderFilePath(String recorderFilePath) {
            this.recorderFilePath = recorderFilePath;
            return this;
        }

        public CallLog build() {
            return new CallLog(this);
        }

        public Builder with_id(int val) {
            _id = val;
            return this;
        }

        public Builder withCallId(String val) {
            callId = val;
            return this;
        }
    }
}
