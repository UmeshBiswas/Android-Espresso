package com.revesoft.itelmobiledialer.chat.chatWindow.media;

import android.media.MediaMetadataRetriever;

import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDateTimeFormatter;

/**
 * @author Ifta on 12/18/2017.
 */

public class ChatMediaUtil {
    public static String getAudioFileDuration(String filePath) {
        try {
            MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
            try {
                metaRetriever.setDataSource(filePath);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                return "--:--";
            }
            String duration = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            metaRetriever.release();
            if (duration != null) {
                int millSecond = Integer.parseInt(duration);
                return ChatDateTimeFormatter.getDuration(millSecond);
            } else {
                return "--:--";
            }
        } catch (Exception e) {
            return "--:--";
        }

    }
}
