package com.revesoft.itelmobiledialer.chat.chatWindow.helper;

import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.chat.chatWindow.seenSending.SeenSenderThread;
import com.revesoft.itelmobiledialer.util.TaggedLogger;

/**
 * @author Ifta on 2/25/2018.
 */

public class SeenSender {
    private static SeenSender seenSender = null;
    private static SeenSenderThread seenSenderThread;

    public static SeenSender getAccess() {
        if (seenSender == null) {
            seenSender = new SeenSender();
        }
        return seenSender;
    }

    public void initialize(String target, boolean isGroupChat){
        seenSenderThread = new SeenSenderThread(target,isGroupChat);

    }

    public void destroy(){
        if(seenSenderThread!=null) {
            seenSenderThread.finish();
            seenSenderThread = null;
        }
    }

    public void sendSeen(String callId){
        if(seenSenderThread!=null && callId!=null) {
                seenSenderThread.feed(callId);
        }
    }
    TaggedLogger seenLogger = new TaggedLogger("seenSending");
    public void sendSeen(Message message){
        seenLogger.log("trying to send Seen for "+message.callerId);
        if(seenSenderThread!=null && message.messageType == MessageEntry.MessageType.RECEIVED && message.deliveryStatus != MessageEntry.DeliveryStatus.SEEN && message.deliveryStatus != MessageEntry.DeliveryStatus.READY_TO_DOWNLOAD) {
            seenLogger.log("sending Seen for "+message.callerId);
            seenSenderThread.feed(message.callerId);
        }
    }

}
