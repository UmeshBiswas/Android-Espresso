package com.revesoft.itelmobiledialer.dialer.directorySearch;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.revesoft.itelmobiledialer.dialer.ContactSelectionFragment;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.material.R;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;


public class DirectorySearchActivity extends BaseActivity {
    public static final String QUERY_TEXT = "query_text";
    Toolbar toolbar;
    Fragment contactSelectionFragment;
    boolean isAddMoreMemberAction = false;
    String searchText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directory_search);

        handleToolbar();

        searchText = getIntent().getStringExtra("search_text");
        contactSelectionFragment = DirectorySearchContactSelectionFragment.newInstance( searchText);

        getSupportFragmentManager().beginTransaction().add(R.id.contactListHolder, contactSelectionFragment, ContactSelectionFragment.getTAG()).commit();

    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onResume() {


        super.onResume();
        if(contactSelectionFragment != null && ((DirectorySearchContactSelectionFragment)contactSelectionFragment).adapter != null)
        {
            Log.d("Abhi"," " + "called");

            if(((DirectorySearchContactSelectionFragment) contactSelectionFragment).searchView != null)
                ((DirectorySearchContactSelectionFragment)contactSelectionFragment).
                    searchView.setQuery(((DirectorySearchContactSelectionFragment)contactSelectionFragment).
                    searchView.getQuery().toString() ,true);




        }
    }

    private void handleToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home_up);
            if (isAddMoreMemberAction) {
                getSupportActionBar().setTitle("Add a Member");
            } else {
                getSupportActionBar().setTitle(R.string.salam_directory_search);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("Abhi","directorysearch: " + "onactivityresult");
        super.onActivityResult(requestCode, resultCode, data);
    }
}
