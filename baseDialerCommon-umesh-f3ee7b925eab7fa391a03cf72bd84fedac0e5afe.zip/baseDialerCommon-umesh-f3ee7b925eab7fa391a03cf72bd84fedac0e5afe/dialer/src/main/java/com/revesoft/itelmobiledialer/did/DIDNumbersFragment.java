package com.revesoft.itelmobiledialer.did;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.DIDRepo;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Country;
import com.revesoft.itelmobiledialer.util.CountryInfoProvider;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;
import static com.revesoft.itelmobiledialer.util.Constants.PHONE;

/**
 * Created by Rahat on 9/14/2017.
 */

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class DIDNumbersFragment extends Fragment implements OnDidResponseListener, LoaderManager.LoaderCallbacks<Cursor> {
    private static final int INVALID_REQUEST_TYPE = -1;
    private DIDBuyNumberAdapter didBuyNumberAdapter;
    private ListView buyNumberListView;
    private String TAG = "DIDNumbersFragment";
    private SharedPreferences preferences;
    private Cursor cursor = null;
    ArrayList<DID> dids;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getActivity().getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_did_numbers, container, false);
        init(v);
        getLoaderManager().initLoader(0, null, this);
        return v;
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: ");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: ");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");
        if (Util.isNetworkAvailable(getActivity()))
            new DIDAsyncTask(2, 1, "", getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        else
            Util.showNoNetworkDialog(getActivity());
    }

    private void init(View v) {
        buyNumberListView = v.findViewById(R.id.buy_number_listview);
        dids = new ArrayList<>();
        didBuyNumberAdapter = new DIDBuyNumberAdapter(dids);
        buyNumberListView.addFooterView(new View(getActivity()), null, true);
        buyNumberListView.addHeaderView(new View(getActivity()), null, true);
        buyNumberListView.setAdapter(didBuyNumberAdapter);
        v.findViewById(R.id.fab).setOnClickListener(view -> startActivityForResult(new Intent(getActivity(), AddNewDIDActivity.class), 28488));

    }

    @Override
    public void onCountryListResponse(String[] countryNames, int[] countryFlags) {

    }

    @Override
    public void onStatesListResponse(String[] stateNames, String[] stateCode) {

    }

    @Override
    public void onCityListResponse(String[] cityNames, String[] cityCode) {

    }

    @Override
    public void onDIDListResponse(ArrayList<DID> dids) {

    }

    @Override
    public void onUsersDidListResponse(ArrayList<DID> dids) {
        for (int i = 0; i < dids.size(); i++) {
            int finalI = i;
            Executor.ex(() -> {
                DIDRepo.get().createUserDidEntry(dids.get(finalI));
            });
        }

        getLoaderManager().restartLoader(0, null, this);
        if (preferences.getBoolean("first_in_settings", true))
            preferences.edit().putBoolean("first_in_settings", false).commit();
        if (dids.size() == 0)
            Toast.makeText(getActivity(), getString(R.string.did_number_is_not_set), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBuyUsersDID(DID did) {

    }

    @Override
    public void onUnsubscribeDid(DID selectedDID) {

    }

    @Override
    public void onForwardedNumberSet(String forwardedNumber) {

    }


    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        Log.d(TAG, "onCreateLoader: ");
        return new CursorLoader(getActivity(), null, null, null, null, "ASC") {
            @Override
            public Cursor loadInBackground() {
                try {
                    cursor = DIDRepo.get().getUserDIDsCursor();

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    cursor.setNotificationUri(getContext().getContentResolver(), DatabaseConstants.DID_TABLE_URI);
                }
                return cursor;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        dids.clear();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            DID did = new DID(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));
            dids.add(did);
        }
        didBuyNumberAdapter.notifyDataSetChanged();

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        dids.clear();
        didBuyNumberAdapter.notifyDataSetChanged();
    }

    private class DIDBuyNumberAdapter extends BaseAdapter {
        private ArrayList<DID> numbers;

        public DIDBuyNumberAdapter(ArrayList<DID> numbers) {
            this.numbers = numbers;
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return numbers.size();
        }

        @Override
        public DID getItem(int position) {
            // TODO Auto-generated method stub
            return numbers.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View rowView = convertView;
            NumberViewHolder viewHolder;
            if (rowView == null) {

                LayoutInflater inflater = getActivity().getLayoutInflater();
                rowView = inflater.inflate(R.layout.available_did_list_item,
                        null);
                viewHolder = new NumberViewHolder();
                viewHolder.numberTv = rowView
                        .findViewById(R.id.did_item_number);
                viewHolder.nameTv = rowView
                        .findViewById(R.id.did_item_name);
                viewHolder.expDateTv = rowView
                        .findViewById(R.id.did_item_exp_date);
                viewHolder.costTV = rowView.
                        findViewById(R.id.did_item_cost);

                //rahat 08-11-2017
                viewHolder.didLayout = rowView
                        .findViewById(R.id.did_layout);

                rowView.setTag(viewHolder);
            } else {
                viewHolder = (NumberViewHolder) convertView.getTag();
            }


            viewHolder.didLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), DIDNumberSettingsActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("did", numbers.get(position));
                    intent.putExtras(bundle);
                    startActivityForResult(intent, 259385);
                }
            });
            String number = numbers.get(position).getDidNumber();
            viewHolder.numberTv.setText(numbers.get(position).getDidNumber());
            if (!TextUtils.isEmpty(numbers.get(position).getRate()))
                viewHolder.costTV.setText(getString(R.string.cost) + "-" + numbers.get(position).getRate());
            else
                viewHolder.costTV.setVisibility(View.GONE);
            if (!TextUtils.isEmpty(numbers.get(position).getExpireDate()))
                viewHolder.expDateTv.setText(getString(R.string.expiry_date) + "-" +
                        numbers.get(position).getExpireDate().split(" ")[0].trim().replace("-", "/"));
            else
                viewHolder.expDateTv.setVisibility(View.GONE);
            String countryName = getCountryName(numbers.get(position).getDidNumber());

            if (!TextUtils.isEmpty(countryName)) {

                viewHolder.nameTv.setText(countryName);
                viewHolder.nameTv.setVisibility(View.VISIBLE);
            } else viewHolder.nameTv.setVisibility(View.GONE);
            return rowView;
        }

        String getCountryName(String number) {
            if (!number.startsWith("+"))
                number = "+" + number;
            String phoneNumber = Util.translateNumber(number);
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
            try {
                if (phoneUtil.parse(phoneNumber, "AZ") != null) {
                    int cc = phoneUtil.parse(phoneNumber.startsWith("+") ? phoneNumber : "+" + phoneNumber, "AZ").getCountryCode();
                    Country country = CountryInfoProvider.countryDialingCodeToCountry.get(cc + "");
                    if (country != null)
                        return country.name;
                    else return null;
                } else return null;
            } catch (NumberParseException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private static class NumberViewHolder {
        public TextView numberTv;
        public LinearLayout didLayout;
        public TextView nameTv;
        public TextView expDateTv;
        public TextView costTV;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 259385) {
            if (resultCode == RESULT_OK) {
                String didID = data.getData().toString();
                DID selectedDID = null;
                for (int i = 0; i < dids.size(); i++) {
                    if (dids.get(i).getDidID().equalsIgnoreCase(didID)) {
                        selectedDID = dids.get(i);
                        break;
                    }
                }
                if (selectedDID != null) {
                    dids.remove(selectedDID);
                    didBuyNumberAdapter.notifyDataSetChanged();
                    if (preferences.getString(PHONE, "").equalsIgnoreCase(selectedDID.getDidNumber()))
                        preferences.edit().putString(PHONE, UserDataManager.getUserName()).commit();

                    restartSipProvider();
                }
            }

        } else if (requestCode == 28488) {
            if (resultCode == RESULT_OK) {
                if (Util.isNetworkAvailable(getActivity()))
                    new DIDAsyncTask(2, 1, "", getActivity(), this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        }
    }

    private void restartSipProvider() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.START_REGISTRATION, "");
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(i);
    }

}

