package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "group_table")
public class Group {

    public int _id;

    @NonNull
    @PrimaryKey
    @ColumnInfo(name = "groupid")
    public String groupId = AppDatabaseDefault.groupId;

    @ColumnInfo(name = "groupname")
    public String groupName;

    @NonNull
    public String number = AppDatabaseDefault.number;

    @ColumnInfo(name = "creator")
    public boolean isCreator = false;

    @ColumnInfo(name = "member")
    public boolean isMember = true;

    @NonNull
    public String creatorNumber = AppDatabaseDefault.number;

    @ColumnInfo(name = "group_type")
    public int groupType = 1;

    @ColumnInfo(name = "buddy_public_key")
    public String buddyPublicKey = AppDatabaseDefault.number;

    @ColumnInfo(name = "buddy_seed")
    public String buddySeed = AppDatabaseDefault.number;

    @ColumnInfo(name = "group_private_key")
    public String groupPrivateKey = AppDatabaseDefault.number;

    @ColumnInfo(name = "is_encrypted_group")
    public boolean isEncryptedGroup = false;

    public Group() {
    }

    private Group(Builder builder) {
        _id = builder._id;
        groupId = builder.groupId;
        groupName = builder.groupName;
        number = builder.number;
        isCreator = builder.isCreator;
        isMember = builder.isMember;
        creatorNumber = builder.creatorNumber;
        groupType = builder.groupType;
        buddyPublicKey = builder.buddyPublicKey;
        buddySeed = builder.buddySeed;
        groupPrivateKey = builder.groupPrivateKey;
        isEncryptedGroup = builder.isEncryptedGroup;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public com.revesoft.itelmobiledialer.model.Group convertGroupModel(){
        com.revesoft.itelmobiledialer.model.Group group=
                new com.revesoft.itelmobiledialer.model.Group(groupName, groupId, number, creatorNumber, isMember);
       return group;
    }


    public static final class Builder {
        private int _id;
        private String groupId = null;
        private String groupName;
        private String number = "";
        private boolean isCreator = false;
        private boolean isMember = true;
        private String creatorNumber = "";
        private int groupType = 1;
        private String buddyPublicKey = "";
        private String buddySeed = "";
        private String groupPrivateKey = "";
        private boolean isEncryptedGroup = false;

        private Builder() {
        }

        public Builder _id(int _id) {
            this._id = _id;
            return this;
        }

        public Builder groupId(String groupId) {
            this.groupId = groupId;
            return this;
        }

        public Builder groupName(String groupName) {
            this.groupName = groupName;
            return this;
        }

        public Builder number(String number) {
            this.number = number;
            return this;
        }

        public Builder isCreator(boolean isCreator) {
            this.isCreator = isCreator;
            return this;
        }

        public Builder isMember(boolean isMember) {
            this.isMember = isMember;
            return this;
        }

        public Builder creatorNumber(String creatorNumber) {
            this.creatorNumber = creatorNumber;
            return this;
        }

        public Builder groupType(int groupType) {
            this.groupType = groupType;
            return this;
        }

        public Builder buddyPublicKey(String buddyPublicKey) {
            this.buddyPublicKey = buddyPublicKey;
            return this;
        }

        public Builder buddySeed(String buddySeed) {
            this.buddySeed = buddySeed;
            return this;
        }

        public Builder groupPrivateKey(String groupPrivateKey) {
            this.groupPrivateKey = groupPrivateKey;
            return this;
        }

        public Builder isEncryptedGroup(boolean isEncryptedGroup) {
            this.isEncryptedGroup = isEncryptedGroup;
            return this;
        }

        public Group build() {
            return new Group(this);
        }
    }
}
