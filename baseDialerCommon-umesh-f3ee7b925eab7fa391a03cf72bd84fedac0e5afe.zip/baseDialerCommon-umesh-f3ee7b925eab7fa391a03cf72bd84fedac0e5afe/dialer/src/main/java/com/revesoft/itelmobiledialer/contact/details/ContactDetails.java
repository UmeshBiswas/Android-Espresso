package com.revesoft.itelmobiledialer.contact.details;

import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.data.SubscriberStatusProvider;
import com.revesoft.itelmobiledialer.signalling.data.PresenceState;
import com.revesoft.itelmobiledialer.util.AppContext;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ContactDetails {
    private String name;
    private String lastOnline;
    private String imageUrl;
    private Set<String> numbers = new HashSet<>();
    private Set<String> processedNumbers = new HashSet<>();
    private boolean isFavorite;
    private String lookUpKey;

    private ContactDetails(Builder builder) {
        name = builder.name;
        lastOnline = builder.lastOnline;
        imageUrl = builder.imageUrl;
        numbers = builder.numbers;
        processedNumbers = builder.processedNumbers;
        isFavorite = builder.isFavorite;
        lookUpKey = builder.lookUpKey;
    }

    public static ContactDetails from(List<Contact> contacts) {
        Builder builder = new Builder();
        for (Contact contact : contacts) {
            if (!TextUtils.isEmpty(contact.name) && TextUtils.isEmpty(builder.name)) {
                builder.name = contact.name;
            }
            if (!TextUtils.isEmpty(contact.number)) {
                builder.numbers.add(contact.number);
            }
            if (!TextUtils.isEmpty(contact.preocessedNumber)) {
                builder.processedNumbers.add(contact.preocessedNumber);
            }
            if (!builder.isFavorite) {
                builder.isFavorite = contact.isFavorite;
            }
            if (!TextUtils.isEmpty(contact.lookupKey) && TextUtils.isEmpty(builder.lookUpKey)) {
                builder.lookUpKey = contact.lookupKey;
            }
            if (TextUtils.isEmpty(builder.lastOnline)) {
                PresenceState presenceState = SubscriberStatusProvider.getPresenceStatus(contact.preocessedNumber);
                if (presenceState != PresenceState.Offline) {
                    builder.lastOnline = presenceState.name();
                } else {
                    Executor.ex(() -> {
                        String lastOnline = SubscriberStatusProvider.getLastOnlineTime(AppContext.getAccess().getContext(), contact.preocessedNumber);
                        if (lastOnline == null) {
                            builder.lastOnline = PresenceState.Offline.name();
                        } else {
                            builder.lastOnline = lastOnline;
                        }
                    });

                }
            }
            if (TextUtils.isEmpty(builder.imageUrl)) {
                builder.imageUrl = ProfilePictureDataProvider.getProfilePicturePath(contact.preocessedNumber);
            }
        }
        return builder.build();
    }


    public static Builder newBuilder() {
        return new Builder();
    }

    public String getName() {
        return name;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public String getLastOnline() {
        return lastOnline;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Set<String> getNumbers() {
        return numbers;
    }

    public Set<String> getProcessedNumbers() {
        return processedNumbers;
    }

    public String getLookUpKey() {
        return lookUpKey;
    }


    public static final class Builder {
        private String name;
        private String lastOnline;
        private String imageUrl;
        private Set<String> numbers;
        private Set<String> processedNumbers;
        private boolean isFavorite;
        private String lookUpKey;

        private Builder() {
            numbers = new HashSet<>();
            processedNumbers = new HashSet<>();
        }

        public Builder withName(String val) {
            name = val;
            return this;
        }

        public Builder withLastOnline(String val) {
            lastOnline = val;
            return this;
        }

        public Builder withImageUrl(String val) {
            imageUrl = val;
            return this;
        }

        public Builder withNumbers(Set<String> val) {
            numbers = val;
            return this;
        }

        public Builder withProcessedNumbers(Set<String> val) {
            processedNumbers = val;
            return this;
        }

        public Builder withIsFavorite(boolean val) {
            isFavorite = val;
            return this;
        }

        public Builder withLookUpKey(String val) {
            lookUpKey = val;
            return this;
        }


        public ContactDetails build() {
            return new ContactDetails(this);
        }
    }
}
