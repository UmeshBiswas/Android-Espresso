package com.revesoft.itelmobiledialer.chat.chatWindow.media;


import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatSeekBar;

/**
 * @author Ifta on 1/8/2018.
 */

public class AudioMessage {
    String audioMessageId;
    String audioFilePath;
    AppCompatSeekBar seekBar;
    TextView tvPlayDuration;
    ImageView ivPlayPause;

    public AudioMessage(String audioMessageId, String audioFilePath, AppCompatSeekBar seekBar, TextView tvPlayDuration, ImageView ivPlayPause) {
        this.audioMessageId = audioMessageId;
        this.audioFilePath = audioFilePath;
        this.seekBar = seekBar;
        this.tvPlayDuration = tvPlayDuration;
        this.ivPlayPause = ivPlayPause;
    }
}
