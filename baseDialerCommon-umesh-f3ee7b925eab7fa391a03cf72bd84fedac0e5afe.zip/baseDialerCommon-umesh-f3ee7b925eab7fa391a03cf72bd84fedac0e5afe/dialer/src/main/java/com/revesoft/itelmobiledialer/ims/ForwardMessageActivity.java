package com.revesoft.itelmobiledialer.ims;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.dialogues.DialogActivity;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.interfaces.SelectionActivity;
import com.revesoft.itelmobiledialer.model.Contact;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.service.dialerService.BagName;
import com.revesoft.itelmobiledialer.service.dialerService.MessageBag;
import com.revesoft.itelmobiledialer.signalling.sipUtil.TaggedLogger;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.FileTransferViaHTTPHelper;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.TextHighlighter;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.xdatabase.XTableKeys;
import com.revesoft.material.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static android.view.View.GONE;
import static com.revesoft.itelmobiledialer.util.Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR_SPLITTER;


/**
 * @author Ifta
 *         on 3/29/2017.
 */

public class ForwardMessageActivity extends BaseActivity
        implements SelectionActivity, LoaderManager.LoaderCallbacks<Cursor> {
    public static final String SHARE_FILE = "SHARE_FILE";
    public static final String KEY_FORWARDED_MESSAGES = "KEY_FORWARDED_MESSAGES";
    public static final String KEY_IS_GROUP_MESSAGE = "KEY_IS_GROUP_MESSAGE";
    private static final int COMBINED_MESSAGE_LOADER = 1101;
    private static final int SALAM_NAME_LOADER = 1120;
    private static final String GROUP_NAME_IMAGE_PATH_SEPARATOR = "_:::*:::_";
    private static final int GROUP_NAME_LOADER = 1130;
    RecyclerView rvSelectedContacts;
    ImageView bForward;
    SelectionAdapter adapter;
    Toolbar toolbar;
    LinearLayoutManager layoutManager;
    ArrayList<Contact> selectedItems = new ArrayList<>();
    Fragment contactSelectionFragment;
    String[] existingMembersNumber;
    String[] callIds;
    boolean isGroupMessage = false;
    ArrayList<String> newList = new ArrayList<>();
    RecentMessageAdapter rmAdapter;
    AppContactAdapter salamAdapter;
    RecyclerView lvRecentList;
    RecyclerView lvSalamContact;
    TextView tvRecentChat;
    Cursor c = null, p = null;
    ArrayList<Boolean> isselectedList = new ArrayList<>();
    HashMap<String, Integer> numberWithSelectedStatus = new HashMap<>();
    LinearLayoutManager ll, ll2;

    TaggedLogger taggedLogger = new TaggedLogger("forwardMessageLog");
    int loadFinishedCount = 0;
    ProgressDialog pd;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_member_selection_layout_chat);
        if (getIntent().hasExtra(Constants.IMS.EXISTING_GROUP_MEMBER_NUMBERS)) {
            existingMembersNumber = getIntent().getStringArrayExtra(Constants.IMS.EXISTING_GROUP_MEMBER_NUMBERS);
        }
        if (getIntent().hasExtra(KEY_FORWARDED_MESSAGES)) {
            callIds = getIntent().getStringArrayExtra(KEY_FORWARDED_MESSAGES);
        }
        else {
            finish();
        }
        isGroupMessage = getIntent().getBooleanExtra(KEY_IS_GROUP_MESSAGE, false);
        handleToolbar();
        initViews();
        setViewData();
        pd.show();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                getSupportLoaderManager().initLoader(COMBINED_MESSAGE_LOADER, null, ForwardMessageActivity.this);

            }
        },5);
    }

    @Override
    protected void onResume() {
        super.onResume();



    }

    LinearLayoutManager llManager;

    private void initViews() {
        rvSelectedContacts = findViewById(R.id.rvSelectedPeople);
        lvRecentList = findViewById(R.id.recent_chat_list);
        lvSalamContact = findViewById(R.id.salamNumber);
        tvRecentChat = findViewById(R.id.recent_tag);
        bForward = findViewById(R.id.fab);
        switchToNotSelectedView();
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rvSelectedContacts.setLayoutManager(layoutManager);
        adapter = new SelectionAdapter(this);
        rvSelectedContacts.setAdapter(adapter);
        rvSelectedContacts.setVisibility(GONE);
        rmAdapter = new RecentMessageAdapter();
        salamAdapter = new AppContactAdapter();

        llManager = new LinearLayoutManager(ForwardMessageActivity.this);
        ll = new LinearLayoutManager(ForwardMessageActivity.this);
        ll2 = new LinearLayoutManager(ForwardMessageActivity.this);
        lvSalamContact.setAdapter(salamAdapter);
        lvSalamContact.setLayoutManager(ll);

        lvRecentList.setOnTouchListener(new View.OnTouchListener() {

            public boolean onTouch(View v, MotionEvent event) {
//                if (event.getAction() == MotionEvent.ACTION_MOVE) {
//                    return true; // Indicates that this has been handled by you and will not be forwarded further.
//                }

                return false;
            }
        });
        pd = new ProgressDialog(ForwardMessageActivity.this);
        pd.setMessage(getString(R.string.please_wait));




    }


    public void setViewData() {
//        if(selecteds.size() > 0) rvSelectedContacts.setVisibility(View.VISIBLE);
        bForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedItems.size() != 0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(ForwardMessageActivity.this);
                    builder.setTitle(R.string.confirm);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getString(R.string.forward_to) + " ");
                    for (Contact contact : selectedItems) {
                        stringBuilder.append(contact.name == null ? contact.phoneNumber : contact.name);
                        stringBuilder.append(", ");
                    }
                    stringBuilder.delete(stringBuilder.lastIndexOf(","), stringBuilder.length());
                    stringBuilder.append("?");
                    builder.setMessage(stringBuilder.toString());
                    builder.setCancelable(false);
                    builder.setPositiveButton(getString(R.string.ok_button), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ArrayList<String> callIdList = new ArrayList<>(Arrays.asList(callIds));
                            Executor.ex(() -> {
                                Cursor cursor = MessageRepo.get().getMessagesByCallerIdListCursor(callIdList);
                                for (Contact contact : selectedItems) {
                                    if (cursor != null && cursor.moveToFirst() && cursor.getCount() > 0) {
                                        do {
                                            String content = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_MESSAGE_CONTENT));
                                            String filePath = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_FILE_PATH));
                                            String longMessage = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_LONG_MESSAGE));

                                            if (!TextUtils.isEmpty(filePath) && TextUtils.isEmpty(longMessage)) {
                                                String caption = ChatUtil.getCaption(content);
                                                if (!CommonData.subscriberPhoneNumberToLookUpKey.containsKey(contact.phoneNumber)) {
                                                    sendFileToGroupViaHTTP(filePath, contact.phoneNumber, caption);
                                                } else {

                                                    FileTransferViaHTTPHelper.sendFileToContact(ForwardMessageActivity.this, Util.translateNumber(contact.phoneNumber), filePath, caption);
                                                }

                                            } else {
                                                Log.e("sayma", "message sending to" + contact.phoneNumber);
                                                if (!CommonData.subscriberPhoneNumberToLookUpKey.containsKey(contact.phoneNumber)) {
                                                    sendGroupIntentMessageToDialer(BagName.Group.Message, contact.phoneNumber, content, Util.e2e());

                                                } else
                                                    sendIntentMessageToDialer(BagName.SingleIM.Message, Util.translateNumber(contact.phoneNumber), content, Util.e2e());
                                            }
                                        } while (cursor.moveToNext());
                                    }
                                }
                                Gui.get().run(() -> {
                                    I.toast("Forwarded to " + selectedItems.size() + " persons");
                                    dialogInterface.dismiss();
                                    finish();
                                });

                            });


                        }
                    });
                    builder.setNegativeButton(getString(R.string.neverMind), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            I.toast("Canceled!");
                        }
                    });
                    builder.create().show();
                } else {
                    I.toast("Forwarded to nobody");
                    finish();
                }
            }

        });

    }

    private void switchToNotSelectedView() {
        rvSelectedContacts.setVisibility(GONE);
        bForward.setVisibility(GONE);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                getResources().getDimensionPixelSize(R.dimen.standard_48));
        params.setMargins(0, 0, 0, 0);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
    }

    private void switchToSelectedView() {
        rvSelectedContacts.setVisibility(View.VISIBLE);
        bForward.setVisibility(View.VISIBLE);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                getResources().getDimensionPixelSize(R.dimen.standard_48));
        params.setMargins(0, 0, 0, getResources().getDimensionPixelSize(R.dimen.appButtonHeight));
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }


    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.forward);
        }

    }


    @Override
    public ArrayList<Contact> getSelectionList() {
        return selectedItems;
    }

    @Override
    public void removeItemFromSelectionList(Contact item) {
        if (selectedItems.size() == 1) {
            switchToNotSelectedView();
        }else{
            if(selectedTranslated.contains(item.phoneNumber)) {
                selectedTranslated.remove(item.phoneNumber);
                numberWithSelectedStatus.put(item.phoneNumber, null);

            }
            int index = -100;
            for(int i = 0; i< selectedItems.size(); i++){
                if(selectedItems.get(i).phoneNumber.equals(item.phoneNumber)) index = i;
            }
            selectedItems.remove(index);
            adapter.notifyDataSetChanged();
            rmAdapter.notifyDataSetChanged();
            salamAdapter.notifyDataSetChanged();


        }

    }

    @Override
    public void addItemToSelectionList(Contact item) {
        if (selectedItems.size() == 0) {
            switchToSelectedView();

        }
        selectedItems.add(item);

        if (adapter != null) {
            adapter.swapData(selectedItems);
        }
    }

    MenuItem searchItem;
    SearchView searchView;
    private String searchString = "";


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        searchItem = menu.findItem(R.id.app_bar_search);

        SearchManager searchManager = (SearchManager) ForwardMessageActivity.this.getSystemService(Context.SEARCH_SERVICE);

        searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();

        }

        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(ForwardMessageActivity.this.getComponentName()));
            searchView.setIconifiedByDefault(true);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    if (TextUtils.isEmpty(newText)) {
                        searchString = "";

                    } else {
                        searchString = newText;

                    }
//                    getSupportLoaderManager().restartLoader(SALAM_NAME_LOADER, null, ForwardMessageActivity.this);
                    getSupportLoaderManager().restartLoader(COMBINED_MESSAGE_LOADER, null, ForwardMessageActivity.this);
//                    if(rmAdapter.isEmpty()) recentChatLayout.setVisibility(View.GONE);
//                    else recentChatLayout.setVisibility(View.VISIBLE);
                    return true;
                }
            });
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            case R.id.app_bar_search_contacts:
//                Toast.makeText(NewChatActivity.this, "search", Toast.LENGTH_SHORT).show();
                return true;
        }
        return false;
    }

    int done = 0;




    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        if (id == SALAM_NAME_LOADER) {
            return new SQLiteCursorLoader(ForwardMessageActivity.this) {
                @Override
                public Cursor loadInBackground() {
                    Cursor cursor = null;
                    try {
                        cursor = ContactRepo.get().getAppNewContactsCursor(searchString, commonNumbers);
                    } catch (Exception ex) {
                        I.err(ex.getLocalizedMessage());
                        ex.printStackTrace();
                    }
                    return cursor;
                }
            };
        }
        else if (id == COMBINED_MESSAGE_LOADER) {
            return new SQLiteCursorLoader(ForwardMessageActivity.this) {
                @Override
                public Cursor loadInBackground() {
                    Cursor cursor = null;
                    try {
                        if (!TextUtils.isEmpty(searchString)) {
//                            cursor = DatabaseConstants.getInstance(ForwardMessageActivity.this)
//                                    .searchImsSmsAndGroupMessages(searchString);

                        } else {
                            cursor = MessageRepo.get()
                                    .getCombinedMessageLogs();
                        }


                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    return cursor;
                }
            };
        }
//        else if(id == )
        return null;
    }

    ArrayList<String> commonNumbers = new ArrayList<>();


    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (loader.getId() == SALAM_NAME_LOADER) {
            Log.w("Abhi","onLoadFinished Time: " + System.currentTimeMillis());

            if (data != null && !data.isClosed() && data.moveToFirst()) {

                lvSalamContact.setItemAnimator(null);
                salamAdapter.swapCursor(data);
               lvSalamContact.setNestedScrollingEnabled(false);
               salamAdapter.notifyDataSetChanged();
                p = data;

            }
            Log.w("Abhi","onLoadFinished Time: " + System.currentTimeMillis());
            loadFinishedCount++;
            for(int i = 0; i < p.getCount(); i++){
                isselectedList.add(false);
            }

        } else if (loader.getId() == COMBINED_MESSAGE_LOADER) {
            if (data != null && !data.isClosed() && data.moveToFirst()) {
                c = data;
                lvRecentList.setAdapter(rmAdapter);
                lvRecentList.setLayoutManager(ll2);
                rmAdapter.swapCursor(data);
                lvRecentList.setNestedScrollingEnabled(false);

            }
            for(int i = 0; i< c.getCount(); i++){
                if(c.moveToFirst()){
                    c.moveToPosition(i);
                    String number = c.getString(c.getColumnIndex(XTableKeys.KEY_NUMBER));
                    if(number != null) {
                        commonNumbers.add(number);
                        Log.e("for_sayma", number);
                    }
                }

            }

            Log.e("for_sayma", "salam number initialized");
            loadFinishedCount++;
            getSupportLoaderManager().initLoader(SALAM_NAME_LOADER, null, ForwardMessageActivity.this);
        }
        if(loadFinishedCount >= 1 && pd != null &&
                pd.isShowing())
            pd.dismiss();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        rmAdapter.swapCursor(null);
//        salamAdapter.swapCursor(null);
    }



    class SelectionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int ITEM_VIEW = 5000;
        ArrayList<Contact> items = new ArrayList<Contact>();
        Context context;

        private SelectionAdapter(Context context) {
            this.context = context;
        }

        public void swapData(ArrayList<Contact> selectedItems) {
//            items.clear();
//            items.addAll(selectedItems);
            notifyDataSetChanged();
        }


        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v;
            if (viewType == ITEM_VIEW) {
                v = LayoutInflater.from(context).inflate(R.layout.selected_contact_single_item, parent, false);
                return new ViewHolder(v);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ViewHolder vh = (ViewHolder) holder;
            final int currentPosition = position;
            ImageView ivRemoveSelection = vh.itemView.findViewById(R.id.ivRemoveSelection);
            ivRemoveSelection.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeItemFromSelectionList(selectedItems.get(currentPosition));
//                    Log.e("sayma", "remove");
                }
            });
            vh.bindView();
        }


        @Override
        public int getItemCount() {
            return selectedItems.size();
        }

        @Override
        public int getItemViewType(int position) {
            return ITEM_VIEW;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivPhoneContactImage;

            private ViewHolder(View itemView) {
                super(itemView);
                ivPhoneContactImage = itemView.findViewById(R.id.ivPhoneContactImage);

            }

            public void bindView() {
                String name = selectedItems.get(getAdapterPosition()).name;
                String phoneNumber = selectedItems.get(getAdapterPosition()).phoneNumber;
                if(selectedItems.get(getAdapterPosition()).imageUri != null) ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, selectedItems.get(getAdapterPosition()).imageUri, ivPhoneContactImage, name);
                else ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, CommonData.contactNumberToContactImageUri.get(phoneNumber), ivPhoneContactImage, name);
            }
        }
    }
    int updating = 0;


    class RecentMessageAdapter extends RecyclerView.Adapter<RecentMessageAdapter.ContactHolder>{
        private Cursor cursor;

        private void swapCursor(Cursor cursor){
            this.cursor = cursor;
        }

        @Override
        public ContactHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(ForwardMessageActivity.this).inflate(R.layout.contact_holder, parent, false);
            return new ContactHolder(v);
        }

        @Override
        public void onBindViewHolder(final ContactHolder holder, int position) {
            cursor.moveToPosition(position);
            Message message = new Message(cursor);
            String lastMessage = getLastMessage(message);
            String lastMessagePersonName = "";
            int messageTypeDrawableId = ChatUtil.getDrawableIdForMimeType(message.mimeType);
            if (message.messageType == MessageEntry.MessageType.SEND && !lastMessage.startsWith(getString(R.string.you))) {
                lastMessagePersonName = getString(R.string.you_);
            }
            holder.ivMessageType.setImageResource(messageTypeDrawableId);
            lastMessagePersonName = lastMessagePersonName.split(" ")[0];
            if (lastMessagePersonName.length() > 20) {
                lastMessagePersonName = lastMessagePersonName.substring(0, 15);
                lastMessagePersonName += "... :";
            } else if (lastMessagePersonName.length() > 0) {
                lastMessagePersonName += " : ";
            }

            if (!TextUtils.isEmpty(searchString)) {
                holder.tvlastmessage.setText(TextHighlighter.getHighlightedText(lastMessage, searchString));
            }else holder.tvlastmessage.setText(lastMessage);

            final String name = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NAME));
            final String number = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NUMBER));
            final String g = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_GROUP_ID));
            if(g != null){
                if (message.messageType == MessageEntry.MessageType.SEND || message.messageType == MessageEntry.MessageType.SYSTEM) {
                    lastMessagePersonName = "";
                } else {
                    lastMessagePersonName = CommonData.contactNumberToContactName.get(message.number);
                    if (lastMessagePersonName == null) {
                        lastMessagePersonName = message.number + " : ";
                    }
                }
            }

            holder.tvLastMessagePersonName.setText(lastMessagePersonName);
            if(number.equals(getString(R.string.salam))) holder.main_content.setVisibility(GONE);
            else holder.main_content.setVisibility(View.VISIBLE);
            if (name == null) {
                if (!TextUtils.isEmpty(searchString)) {
                    holder.tvName.setText(TextHighlighter.getHighlightedText(number, searchString));
                }else holder.tvName.setText(number);
            }
            else {
                if (!TextUtils.isEmpty(searchString)) {
                    holder.tvName.setText(TextHighlighter.getHighlightedText(name, searchString));
                }
                else holder.tvName.setText(name);
            }
            final String imageUri ;
//
            if(g != null){
                Log.e("shuffle ", "group name : " + name);
                ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, null, holder.ivPP, holder.tvName.getText().toString());
                if(name.contains(GROUP_NAME_IMAGE_PATH_SEPARATOR)){
                    String nameImage[] = name.split(GROUP_NAME_IMAGE_PATH_SEPARATOR_SPLITTER);
                    holder.tvName.setText(nameImage[0]);
                    if(nameImage.length == 2 && !TextUtils.isEmpty(nameImage[1])){
                        File file = new File(ProfilePicUploadDownloadHelper.getReceivedMediaDirectory(), nameImage[1]);
                        if (file.exists()) {
                            imageUri = file.getAbsolutePath();
                            ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, file.getAbsolutePath(), holder.ivPP, holder.tvName.getText().toString());
                        } else imageUri = ProfilePictureDataProvider.getProfilePicturePath(ForwardMessageActivity.this, number);
                    }else imageUri = ProfilePictureDataProvider.getProfilePicturePath(ForwardMessageActivity.this, number);
                }
                else{
                    imageUri = null;
                    ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, null, holder.ivPP, holder.tvName.getText().toString());
                }

            }
            else{
                if(ProfilePictureDataProvider.getProfilePicturePath(ForwardMessageActivity.this, number) == null){
                    imageUri = CommonData.contactNumberToContactImageUri.get(number);
                }else{
                    imageUri = ProfilePictureDataProvider.getProfilePicturePath(ForwardMessageActivity.this, number);
                }
                ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, imageUri, holder.ivPP, holder.tvName.getText().toString());
            }
            final String translatedNumber = Util.translateNumber(number);
            if(numberWithSelectedStatus.get(translatedNumber) != null || numberWithSelectedStatus.get(g) != null) holder.ivTick.setVisibility(View.VISIBLE);
            else holder.ivTick.setVisibility(GONE);
            holder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (g != null) {
                        if (numberWithSelectedStatus.get(g) == null) {
                            holder.ivTick.setVisibility(View.VISIBLE);
                            numberWithSelectedStatus.put(g, 100);
                            selectedTranslated.add(g);
                            Contact contact = new Contact(g);
                            contact.name = holder.tvName.getText().toString();
                            contact.imageUri = imageUri;
                            selectedItems.add(contact);
                            switchToSelectedView();
                        } else {
                            holder.ivTick.setVisibility(GONE);
                            numberWithSelectedStatus.put(g , null);
                            int index = -100;
                            selectedTranslated.remove(g);
                            for (int i = 0; i < selectedItems.size(); i++) {
                                if (selectedItems.get(i).phoneNumber.equalsIgnoreCase(g)) {
                                    index = i;
                                }
                            }
                            if (index > -1) selectedItems.remove(index);
                        }
                    } else {
                        if (numberWithSelectedStatus.get(translatedNumber) == null) {
                            holder.ivTick.setVisibility(View.VISIBLE);
                            numberWithSelectedStatus.put(translatedNumber, 100);
                            selectedTranslated.add(translatedNumber);
                            Contact contact = new Contact(translatedNumber);
                            contact.name = name;
                            contact.imageUri = imageUri;
                            selectedItems.add(contact);
                            switchToSelectedView();
                        } else {
                            holder.ivTick.setVisibility(GONE);
                            numberWithSelectedStatus.put(translatedNumber, null);
                            int index = -100;
                            selectedTranslated.remove(translatedNumber);
                            for (int i = 0; i < selectedItems.size(); i++) {
                                if (selectedItems.get(i).phoneNumber.equalsIgnoreCase(translatedNumber)) {
                                    index = i;
                                }
                            }
                            if (index > -1) selectedItems.remove(index);
                        }
                    }
                    adapter.notifyDataSetChanged();


                }
            });
        }

        @Override
        public int getItemCount() {
            return cursor.getCount();
        }

        public class ContactHolder extends RecyclerView.ViewHolder{
            TextView tvName, tvLastMessagePersonName, tvlastmessage;
            ImageView ivPP, ivTick, ivMessageType;
            LinearLayout parent;
            RelativeLayout main_content;

            public ContactHolder(View view) {
                super(view);
                parent = view.findViewById(R.id.parent);
                tvName = view.findViewById(R.id.name);
                ivPP = view.findViewById(R.id.ivPhoneContactImage);
                ivTick = view.findViewById(R.id.tick);
                tvLastMessagePersonName = view.findViewById(R.id.tvLastMessagePersonName);
                ivMessageType = view.findViewById(R.id.ivMessageType);
                tvlastmessage = view.findViewById(R.id.tvLastMessage);
                main_content = view.findViewById(R.id.main_content);
            }
        }

    }


    ArrayList<String> selectedTranslated = new ArrayList<>();



    private class AppContactAdapter extends RecyclerView.Adapter<AppContactAdapter.ContactViewHolder>{
        Cursor cursor;

        @Override
        public ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(ForwardMessageActivity.this).inflate(R.layout.contact_holder_simple, parent, false);
            return new ContactViewHolder(v);
        }

        @Override
        public void onBindViewHolder(final ContactViewHolder holder, int position) {
            cursor.moveToPosition(position);
            final String name = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_NAME));
            final String number = cursor.getString(cursor.getColumnIndex(XTableKeys.KEY_PROCESSED_NUMBER));
            Log.e("test_sayma", number);
            if(name == null){
                if (!TextUtils.isEmpty(searchString)) {
                    holder.tvName.setText(TextHighlighter.getHighlightedText(number, searchString));
                } else holder.tvName.setText(number);
            }else{
                if (!TextUtils.isEmpty(searchString)) {
                    holder.tvName.setText(TextHighlighter.getHighlightedText(name, searchString));
                }
                else holder.tvName.setText(name);
            }
            if (!TextUtils.isEmpty(searchString)) {
                holder.tvNumber.setText(TextHighlighter.getHighlightedText(number, searchString));
            }
            else holder.tvNumber.setText(number);
            final String imageUri = ProfilePictureDataProvider.getProfilePicturePath(ForwardMessageActivity.this, number);
            final String translatedNumber = Util.translateNumber(number);
            if(imageUri != null){
                ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, imageUri, holder.ivPP, holder.tvName.getText().toString());
            }
            else {
               ImageUtil.setImageButTextImageOnException(ForwardMessageActivity.this, CommonData.contactNumberToContactImageUri.get(translatedNumber), holder.ivPP, holder.tvName.getText().toString());
            }
            if(numberWithSelectedStatus.get(translatedNumber) != null) holder.ivTick.setVisibility(View.VISIBLE);
            else holder.ivTick.setVisibility(GONE);
            holder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    if(ivTick.getVisibility() == View.VISIBLE) ivTick.setVisibility(View.INVISIBLE);
//                    else ivTick.setVisibility(View.VISIBLE);
                    if(numberWithSelectedStatus.get(translatedNumber) == null){
                        holder.ivTick.setVisibility(View.VISIBLE);
                        numberWithSelectedStatus.put(translatedNumber, 100);
                        isselectedList.set(cursor.getPosition(), true);
                        selectedTranslated.add(translatedNumber);
                        Contact contact = new Contact(translatedNumber);
                        if(name != null)contact.name = name;
                        contact.imageUri = imageUri;
                        selectedItems.add(contact);
                        switchToSelectedView();
                    }
                    else {
                        holder.ivTick.setVisibility(GONE);
                        numberWithSelectedStatus.put(translatedNumber, null);
                        isselectedList.set(cursor.getPosition(), false);
                        int index = -100;
                        selectedTranslated.remove(translatedNumber);
                        for(int i = 0 ; i<selectedItems.size(); i++){
                            if(selectedItems.get(i).phoneNumber.equalsIgnoreCase(translatedNumber)){
                                index = i;
                            }
                        }
                        if(index > -1) selectedItems.remove(index);
                    }
//                    rmAdapter.notifyDataSetChanged();
                    adapter.notifyDataSetChanged();

                }
            });
        }

        @Override
        public int getItemCount() {
            if(cursor != null && cursor.getCount() > 0) return cursor.getCount();
            else return 0;
        }

//        @Override
//        public long getItemId(int position){
//            return position;
//        }

        public void swapCursor(Cursor c){
            cursor = c;
        }

        public class ContactViewHolder extends RecyclerView.ViewHolder{
            final TextView tvName, tvNumber;
            final ImageView ivPP, ivTick;
            LinearLayout parent;

            public ContactViewHolder(View view) {
                super(view);
                parent = view.findViewById(R.id.main_content);
                tvName = view.findViewById(R.id.name);
                tvNumber = view.findViewById(R.id.number);
                ivPP = view.findViewById(R.id.ivPhoneContactImage);
                ivTick = view.findViewById(R.id.tick);
            }
        }
    }

    private void sendGroupIntentMessageToDialer(String type, String number, String message, int e2e) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        MessageBag messageBag = MessageBag.newBuilder().messageData(message).groupId(number).e2e(e2e).build();
        intent.putExtra(type,messageBag);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendIntentMessageToDialer(String type, String number, String message, int e2e) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        MessageBag messageBag = MessageBag.newBuilder().messageData(message).number(number).e2e(e2e).build();
        intent.putExtra(type,messageBag);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }



    private void sendFileToGroupViaHTTP(String filePath, String gid, String caption) {
        MessageEntry m = new MessageEntry();
        m.content = FileTransferViaHTTPHelper.SEND_FILE_PREFIX_SENDER + filePath + FileTransferViaHTTPHelper.SEND_FILE_URI_CAPTION_SEPARATOR +
                caption + FileTransferViaHTTPHelper.SEND_FILE_SUFFIX_SENDER;
        m.number = "";
        m.time = System.currentTimeMillis();
        m.type = MessageEntry.MessageType.SEND;
        m.status = MessageEntry.MessageStatus.READ;
        m.delivery_status = MessageEntry.DeliveryStatus.NO_REPLY;
        m.callerId = System.currentTimeMillis() + m.number + Util.random();
        m.filePath = filePath;
        m.groupId = gid;
        m.isEncrypted = 1;
        Executor.ex(() -> MessageRepo.get().createMessageLog(m));
        sendIntentMessageFileUploadToDialer(  gid, filePath, m.callerId, caption, 1);
    }
    private void sendIntentMessageFileUploadToDialer( String groupId, String filePath, String callerId, String caption, int e2e) {
        Log.d("Abhi", "File Transfer" + "sendIntentMessageFileUploadToDialer");
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                        .groupId(groupId)
                        .filePath(filePath)
                        .callId(callerId)
                        .caption(caption)
                        .e2e(e2e).build());
        LocalBroadcastManager.getInstance(ForwardMessageActivity.this).sendBroadcast(intent);
    }

    private void showNoInternetAlert() {
        Intent i = new Intent();
        i.setClass(ForwardMessageActivity.this, DialogActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra(DialogActivity.KEY_DIALOG_TYPE, DialogActivity.DialogType.NO_INTERNET);
        startActivity(i);
    }

    class Message {
        String id, groupId, number, messageContent, name, callId;
        long date;
        short deliveryStatus;
        int unreadCount, messageCount, messageType;
        MimeType mimeType = MimeType.Text;

        public Message(Cursor cursor) {
//            id = cursor.getString(cursor.getColumnIndex("_id"));
            groupId = cursor.getString(cursor.getColumnIndex("groupid"));
            number = cursor.getString(cursor.getColumnIndex("number"));
            name = cursor.getString(cursor.getColumnIndex("name"));
            if (TextUtils.isEmpty(name) && TextUtils.isEmpty(groupId)) {
                name = number;
            }
            messageContent = cursor.getString(cursor.getColumnIndex("messagecontent"));
            messageType = cursor.getInt(cursor.getColumnIndex("messagetype"));
            date = cursor.getLong(cursor.getColumnIndex("date"));
            unreadCount = cursor.getInt(cursor.getColumnIndex("unread_count"));
            messageCount = cursor.getInt(cursor.getColumnIndex("message_count"));
            deliveryStatus = cursor.getShort(cursor.getColumnIndex("deliverystatus"));
            mimeType = MimeTypeUtil.getMimeTypeByName(cursor.getString(cursor.getColumnIndex("mime_type")));
            callId = cursor.getString(cursor.getColumnIndex("callerid"));
        }
    }

    private String getLastMessageExtensionByType(int messageType) {
        if (messageType == MessageEntry.MessageType.SEND) {
            return getString(R.string.send);
        } else {
            return getString(R.string.received);
        }
    }

    private void sendIntentMessageToDialerForIMS(String number, String message, int e2e) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        MessageBag messageBag = MessageBag.newBuilder().messageData(message).number(number).e2e(e2e).build();
        intent.putExtra(BagName.SingleIM.Message,messageBag);
        LocalBroadcastManager.getInstance(ForwardMessageActivity.this).sendBroadcast(intent);
    }

    private String getLastMessage(Message message) {
        if (message.mimeType == MimeType.Text) {
            return message.messageContent;
        } else if (message.mimeType == MimeType.Call) {
            String content =  message.messageContent.replace(Constants.Call.CALL_MESSAGE_PREFIX, "").replace(Constants.Call.CALL_MESSAGE_SUFFIX, "");
            if(content.contains("audio")){
                return getString(R.string.missedAudioCall);
            }else {
                return getString(R.string.missedVideoCall);
            }
        }
        String processedMime = MimeTypeUtil.getHumanReadableMimeType(message.mimeType);
        String processedMessageType = getLastMessageExtensionByType(message.messageType);
        String finalMime = processedMime;
        if (processedMime.equalsIgnoreCase("Image")) {
            finalMime = getString(R.string.image) + " " + processedMessageType;
        } else if (processedMime.equals("Location")) {
            finalMime = getString(R.string.location) + " " + processedMessageType;
        } else if (processedMime.equals("Contact")) {
            finalMime = getString(R.string.contact) + " " + processedMessageType;
        } else if (processedMime.equals("Document")) {
            finalMime = getString(R.string.document) + " " + processedMessageType;
        } else if (processedMime.equals("Audio")) {
            finalMime = getString(R.string.audio) + " " + processedMessageType;
        } else if (processedMime.equals("Video")) {
            finalMime = getString(R.string.video) + " " + processedMessageType;
        }
        return finalMime;
    }

    private void handleDataFromOtherApps() {
        Intent receivedIntent = getIntent();
        String action = receivedIntent.getAction();
        String type = receivedIntent.getType();
        Log.w("DashboardActivity", "received intent: " +
                "type: " + receivedIntent.getType()
                + " actions: " + receivedIntent.getAction());
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {
                Log.w("DashboardActivity", "handleDataFromOtherApps: " + "received text: " +
                        receivedIntent.getStringExtra(Intent.EXTRA_TEXT));

//                handleSendText(intent); // Handle text being sent
            } else if (type.startsWith("image/")) {
                Log.w("DashboardActivity", "handleDataFromOtherApps: " + "received image: " +
                        receivedIntent.getParcelableExtra(Intent.EXTRA_STREAM));
//                handleSendImage(intent); // Handle single image being sent
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type != null) {
            if (type.startsWith("image/")) {
                ArrayList<Uri> imageUris = receivedIntent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                Log.w("DashboardActivity", "handleDataFromOtherApps: " + "received image array: " + imageUris.size());
//                handleSendMultipleImages(intent); // Handle multiple images being sent
            }
        } else {
            // Handle other intents, such as being started from the home screen
        }



    }

}
