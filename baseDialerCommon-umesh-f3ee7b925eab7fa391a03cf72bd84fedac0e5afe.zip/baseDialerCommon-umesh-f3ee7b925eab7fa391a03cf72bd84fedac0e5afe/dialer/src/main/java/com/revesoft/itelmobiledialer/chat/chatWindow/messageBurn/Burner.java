package com.revesoft.itelmobiledialer.chat.chatWindow.messageBurn;

import android.animation.Animator;
import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;


import com.plattysoft.leonids.ParticleSystem;
import com.plattysoft.leonids.modifiers.AlphaModifier;
import com.plattysoft.leonids.modifiers.ScaleModifier;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.BurnerListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders.TextMessageViewHolder;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.util.Timer;
import java.util.TimerTask;

/**
 * @author Ifta on 22/10/2017.
 */

public class Burner {
    private static final TaggedLogger logger = new TaggedLogger("Burner");

    public static void burnMessage(final TextMessageViewHolder holder, final BurnerListener listener) {
        final int DURATION = 3000;
        if (!holder.isBurning) {
            final Handler handler = new Handler(Looper.getMainLooper());
            final Animator.AnimatorListener animatorListener = new Animator.AnimatorListener() {

                @Override
                public void onAnimationStart(Animator animator) {
                    logger.log("onAnimationStart");

                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    listener.onBurnFinished();
                }

                @Override
                public void onAnimationCancel(Animator animator) {

                }

                @Override
                public void onAnimationRepeat(Animator animator) {

                }
            };
            holder.isBurning = true;
            holder.fireAnimationHolder.setVisibility(View.VISIBLE);
            holder.fireAnimationHolder.measure(0, 0);
            Activity activity = (Activity) ChatProperties.getChatWindowContext();

            if (activity != null) {
                final ParticleSystem particleSystem = new ParticleSystem(activity, 48, R.drawable.fire_2, DURATION)
                        .setSpeedByComponentsRange(-0.025f, 0.0f, -0.06f, -0.08f)
                        .setAcceleration(0.00003f, 0)
                        .setInitialRotationRange(30, 45)
                        .addModifier(new AlphaModifier(255, 0, 200, 1000))
                        .addModifier(new ScaleModifier(0.5f, 2f, 0, 1000));
                holder.fireAnimationHolder.post(new Runnable() {
                    @Override
                    public void run() {
                        holder.fireAnimationHolder.measure(0,0);
                        int fireAnimationHolderWidth = holder.fireAnimationHolder.getWidth();
//                    logger.log("fireAnimationHolderWidth = " + fireAnimationHolderWidth);
                        particleSystem.emit(holder.fireSource, 12);
                        holder.fireSource.animate().translationXBy(fireAnimationHolderWidth).setStartDelay(500).setDuration(DURATION).setListener(animatorListener).start();
                        holder.fireSourceController.setPivotX(0);
                        holder.fireSourceController.animate().alpha(1f).scaleX(1f).setDuration(DURATION).start();
                    }
                });

                new Timer().scheduleAtFixedRate(new TimerTask() {
                    int elapsedTime = 0;

                    @Override
                    public void run() {
                        elapsedTime += 300;
                        if (elapsedTime >= DURATION) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    particleSystem.cancel();
                                }
                            });

                            this.cancel();
                        } else {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    particleSystem.updateEmitPoint(holder.fireSource, Gravity.CENTER);
                                }
                            });
                        }
                    }
                }, 100, 300);
            }
        }
    }
}
