package com.revesoft.itelmobiledialer.confide;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

import com.plattysoft.leonids.ParticleSystem;
import com.plattysoft.leonids.modifiers.AlphaModifier;
import com.plattysoft.leonids.modifiers.ScaleModifier;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.SeenSender;
import com.revesoft.itelmobiledialer.customview.TouchableNestedScrollView;
import com.revesoft.itelmobiledialer.data.NameResolver;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author Ifta on 2/1/2018.
 */

public class ConfidePreviewActivity extends AppCompatActivity {
    private static final TaggedLogger logger = new TaggedLogger("ConfideChat");
    public static final String KEY_TARGET = "NUMBER";
    public static final String KEY_TEXT = "KEY_TEXT";
    public static final String KEY_FILE_PATH = "KEY_FILE_PATH";
    public static final String KEY_CALLER_ID = "KEY_CALLER_ID";
    public static final String KEY_IS_PREVIEW = "KEY_IS_PREVIEW";
    private static final String KEY_IS_GROUP = "KEY_IS_GROUP";
    public static int TEXT_HEIGHT = 0;
    //    private static final int TEXT_VIEW_SIZE = 30;
    private static int SCROLL_FACTOR = 40;
    private static final int SCROLL_TIMER_RATE = 150;
    private static int SCREEN_HEIGHT = 0;
    private static int SCREEN_WIDTH = 0;
    private static int BOTTOM_SCROLLING_BARRIER = 0;
    private static int TOP_SCROLLING_BARRIER = 0;
    private static int TOP_SCROLLING_BARRIER_TOP = 0;
    private static int ROW_HEIGHT = 1;
    String text;
    String filePath;
    String from;
    private String groupId;
    boolean isGroup;
    String callerId;
    View filePreviewHolder;
    TouchableNestedScrollView nestedScrollView;
    LinearLayout dummy;

    VideoView videoView;
    View container;

    View ivNext;
    View ivReply;


    private boolean just_entered = true;
    //private boolean hasClickedAttachmentOnce = false;
    Handler handler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        readData();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE); //to stop taking screen shots
        setContentView(R.layout.confide_preview_activity_layout);
        prepareMeasurements();
        initViews();
        handleToolbar();
        loadData();
        setUpRecyclerView();
        handler = new Handler(getMainLooper());
    }


    RecyclerView rvText;

    private void setUpRecyclerView() {
        rvText = findViewById(R.id.rvText);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ConfidePreviewActivity.this, RecyclerView.VERTICAL, false);
        rvText.setLayoutManager(linearLayoutManager);
        rvText.setNestedScrollingEnabled(false);
        adapter = new TextAdapter();
        rvText.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        rvText.setHasFixedSize(true);
        rvText.setItemAnimator(null);
    }

    Toolbar toolbar;
    ActionBar actionBar;
    ArrayList<BoxTextModel> boxTextModels = new ArrayList<>();

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
            setNameInToolBar();

        }
    }

    private void setNameInToolBar() {
        if (TextUtils.isEmpty(from)) {
            actionBar.setTitle(getString(R.string.preview_message));
        } else {
            if (isGroup) {
                actionBar.setTitle(NameResolver.getGroupNameById(from));
            } else {
                actionBar.setTitle(NameResolver.getContactNameFromNumberOrEmail(from));
            }
        }
    }

    private void hideNameInToolBar() {
        actionBar.setTitle(null);

    }

    private void prepareMeasurements() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        SCREEN_HEIGHT = displayMetrics.heightPixels;
        SCREEN_WIDTH = displayMetrics.widthPixels;
        BOTTOM_SCROLLING_BARRIER = (int) (SCREEN_HEIGHT * 0.7);
        TOP_SCROLLING_BARRIER = (int) (SCREEN_HEIGHT * 0.2);
    }

    private void loadData() {
        if (!TextUtils.isEmpty(text)) {
            loadTextData();
        }
        if (!TextUtils.isEmpty(filePath)) {
            loadFileData();
        }

        container.invalidate();
    }

    PreviewMessageFilePreviewFragment filePreviewFragment = null;

    private void loadFileData() {
        filePreviewHolder.setVisibility(View.VISIBLE);
        filePreviewFragment = PreviewMessageFilePreviewFragment.getInstance(filePath);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.filePreviewHolder, filePreviewFragment)
                .commit();
        filePreviewHolder.invalidate();

    }


    SparseArray<ArrayList<BoxTextModel>> data = new SparseArray<>();


    private void loadTextData() {
        ProgressDialog dialog = null;
        if (text.length() > 1500) {
            dialog = new ProgressDialog(ConfidePreviewActivity.this);
            dialog.setMessage(getString(R.string.loadingMessage));
            dialog.show();
        }
        boxTextModels.clear();
        data.clear();

        String[] lines = text.split("\n");
        int lineNumber = 0;
        for (String line : lines) {
            logger.log("line : " + line);
            String[] words = line.split(" ");
            dummy.setVisibility(View.INVISIBLE);
            for (int i = 0; i < words.length; i++) {
                String word = words[i];
                TextView textView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_unvisited_closed_text, dummy, false);
                textView.setText((word));
                dummy.addView(textView);
                dummy.measure(0, 0);
                int width = dummy.getMeasuredWidth();
                ROW_HEIGHT = dummy.getMeasuredHeight();
                boolean gotBigWord = false;
                if (width > SCREEN_WIDTH) {
                    if (dummy.getChildCount() == 1) {
                        gotBigWord = true;
                    } else {
//                        boxTextModels.remove(i);
                        lineNumber++;
                        i--;
                        dummy.removeAllViews();
                        continue;
                    }
                }
                if (!gotBigWord) {
                    boxTextModels.add(i, new BoxTextModel(word, false, lineNumber /*+ childCountInLine.size()*/));
                } else {
                    for (int k = 0; k < word.length(); ) {
                        int characterWeCanTake = 20;
                        textView.setText(null);
                        dummy.removeAllViews();
                        for (int p = k + 10; p < word.length(); p++) {
                            String part = word.substring(k, p) + "-";
                            logger.log(part);
                            textView.setText(part);
                            dummy.addView(textView);
                            dummy.measure(0, 0);
                            int partWidth = dummy.getMeasuredWidth();
                            if (partWidth > SCREEN_WIDTH) {
                                characterWeCanTake = p - 1 - k;
                                break;
                            } else {
                                dummy.removeView(textView);
                            }
                        }
                        String partOfWord;
                        if (k + characterWeCanTake < word.length()) {
                            partOfWord = word.substring(k, k + characterWeCanTake);
                            k += partOfWord.length();
                            boxTextModels.add(i, new BoxTextModel(partOfWord + "-", false, lineNumber));
                            lineNumber++;
                        } else {
                            partOfWord = word.substring(k);
                            k += partOfWord.length();
                            boxTextModels.add(i, new BoxTextModel(partOfWord, false, lineNumber));
                        }
                    }
                }
                logger.log(word + " should be added in row : " + (lineNumber /*+ childCountInLine.size()*/));
                addSpace(dummy);
                width = dummy.getMeasuredWidth();
                if (width > SCREEN_WIDTH) {
                    dummy.removeAllViews();
                }
            }
            dummy.removeAllViews();
            lineNumber++;
        }
//        logger.log("line count = " + childCountInLine.size());
        dummy.setVisibility(View.GONE);
        ArrayList<BoxTextModel> tempList = new ArrayList<>();
        for (int i = 0; i < boxTextModels.size(); i++) {
            BoxTextModel model = boxTextModels.get(i);
            ArrayList<BoxTextModel> rowData = data.get(model.row, new ArrayList<>());
            rowData.add(model);
            data.put(model.row, rowData);
        }

        for (int index = 0; index < data.size(); index++) {
            ArrayList<BoxTextModel> list = data.valueAt(index);
            for (BoxTextModel model : list) {
                logger.log(model.toString());
            }
        }
        TEXT_HEIGHT = ROW_HEIGHT * data.size();
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

//    private void loadTextDataV2() {
//        boxTextModels.clear();
//        data.clear();
//        String[] lines = text.split("\n");
//
//        String[] words = text.split(" ");
//        dummy.setVisibility(View.INVISIBLE);
//
//        for (int i = 0; i < words.length; i++) {
//            String word = words[i];
//            TextView textView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_unvisited_closed_text, dummy, false);
//            textView.setText((word));
//            dummy.addView(textView);
//            dummy.measure(0, 0);
//            int width = dummy.getMeasuredWidth();
//            ROW_HEIGHT = dummy.getMeasuredHeight();
//            logger.log("width = " + width);
//            boxTextModels.add(i, new BoxTextModel(word, false, childCountInLine.size()));
//            if (width > SCREEN_WIDTH) {
//                logger.log("--------------");
//                if (dummy.getChildCount() == 1) {
//                    childCountInLine.add(1);
//                } else {
//                    childCountInLine.add(dummy.getChildCount() - 1);
//                    boxTextModels.remove(i);
//                    i--;
//                }
//                dummy.removeAllViews();
//                continue;
//            }
//            addSpace(dummy);
//            width = dummy.getMeasuredWidth();
//            logger.log("width = " + width);
//            if (width > SCREEN_WIDTH) {
//                dummy.removeAllViews();
//            }
//        }
//
//        logger.log("line count = " + childCountInLine.size());
//        dummy.setVisibility(View.GONE);
//        ArrayList<BoxTextModel> tempList = new ArrayList<>();
//        int currentIndex = 0;
//        for (int i = 0; i < boxTextModels.size(); i++) {
//            BoxTextModel model = boxTextModels.quickGet(i);
//            logger.log(model.toString());
//            if (model.row == currentIndex) {
//                tempList.add(model);
//            } else {
//                data.put(currentIndex, new ArrayList<BoxTextModel>(tempList));
//                tempList.clear();
//                i--;
//                currentIndex++;
//            }
//        }
//        data.put(currentIndex, new ArrayList<BoxTextModel>(tempList));
//        tempList.clear();
//
////        for (int i = 0; i < data.size(); i++) {
////            logger.log("row = " + i);
////            ArrayList<BoxTextModel> models = data.quickGet(i);
////            for (BoxTextModel model : models) {
////                logger.log(model.toString());
////            }
////            logger.log("-----------");
////        }
//        TEXT_HEIGHT = ROW_HEIGHT * data.size();
//    }

    private void processWord(String word) {
    }

    private void addSpace(LinearLayout dummy) {
        TextView spaceView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_opened_text_view, dummy, false);
        spaceView.setText("  ");
        dummy.addView(spaceView);
    }

    TextAdapter adapter;

    MimeType fileMimeType = MimeType.Text;

    private void initViews() {
        nestedScrollView = findViewById(R.id.nestedScrollView);
        nestedScrollView.setOnTouchListener(listener);
        filePreviewHolder = findViewById(R.id.filePreviewHolder);
        filePreviewHolder.setVisibility(View.GONE);
        dummy = findViewById(R.id.dummy);
        container = findViewById(R.id.container);
        videoView = findViewById(R.id.videoView);

        if (fileMimeType == MimeType.Video) {
            DisplayMetrics dm = new DisplayMetrics();
            this.getWindowManager().getDefaultDisplay().getMetrics(dm);
            videoView.setMinimumWidth(dm.widthPixels);
            videoView.setMinimumHeight(dm.heightPixels);
            videoView.setVideoPath(filePath);
            videoView.setAlpha(0);
            container.setAlpha(1);
        } else {
            videoView.setVisibility(View.GONE);
            container.setVisibility(View.VISIBLE);
        }

        ivNext = findViewById(R.id.ivNext);
        ivReply = findViewById(R.id.ivReply);

        if (isPreview) {
            ivNext.setVisibility(View.GONE);
            ivReply.setVisibility(View.GONE);
        } else {
            ivReply.setVisibility(View.VISIBLE);
            if (hasNextMessage) {
                ivNext.setVisibility(View.VISIBLE);
            } else {
                ivNext.setVisibility(View.GONE);
            }
        }
    }

    View.OnTouchListener listener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            v.performClick();
            logger.log(event.toString());
            int x = (int) event.getX();
            int y = (int) event.getY();

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    just_entered = false;
                    hideNameInToolBar();
                    logger.log("touched down");
                    if (y >= BOTTOM_SCROLLING_BARRIER) {
                        startOrKeepScrollingUp();
                    } else if (y < TOP_SCROLLING_BARRIER) {
                        startOrKeepScrollingDown();
                    } else {
                        stopScrolling();
                    }
                    if (getCurrentVisibleRow(y) >= data.size()) {
                        if (filePreviewFragment != null) {
                            if (fileMimeType == MimeType.Video) {
                                if (!videoView.isPlaying()) {
                                    container.setAlpha(0);
                                    videoView.setAlpha(1);
                                    videoView.start();
                                    videoView.invalidate();
                                    hasClickedAttachmentOnce = true;
                                    findViewById(R.id.rootLayout).setBackgroundColor(getResources().getColor(R.color.black));
                                    findViewById(R.id.toolbar).setBackgroundColor(getResources().getColor(R.color.black));
                                }
                            } else {
                                hasClickedAttachmentOnce = true;
                                filePreviewFragment.handleFileWindowClick(getActualY(y) - data.size() * ROW_HEIGHT);
                            }
                            int filePreviewHolderHeight = filePreviewHolder.getHeight();
                            logger.log("filePreviewHolderHeight = " + filePreviewHolderHeight);
                            if (getActualY(y) > (data.size() * ROW_HEIGHT + filePreviewHolderHeight)) {
                                if (ivNext.getVisibility() == View.VISIBLE) {
                                    if (x > SCREEN_WIDTH / 2) {
                                        ivNext.performClick();
                                    } else {
                                        ivReply.performClick();
                                    }
                                } else {
                                    ivReply.performClick();
                                }
                            }
                        } else {
                            if (ivNext.getVisibility() == View.VISIBLE) {
                                if (x > SCREEN_WIDTH / 2) {
                                    ivNext.performClick();
                                } else {
                                    ivReply.performClick();
                                }
                            } else {
                                ivReply.performClick();
                            }
                        }
                    } else if (getCurrentVisibleRow(y) < data.size()) {
                        isActiveMessageIsRead = true;
                        SeenSender.getAccess().sendSeen(activeCallerId);
                        if (filePreviewFragment != null) {
                            filePreviewFragment.handleFileWindow(0);
                        }
                        if (currentVisibleRow != getCurrentVisibleRow(y)) {

                            int oldItem = currentVisibleRow;
                            currentVisibleRow = getCurrentVisibleRow(y);
                            if (adapter != null) {
                                adapter.notifyItemChanged(currentVisibleRow);
                            }
                            logger.log("notifyItemChanged at " + currentVisibleRow);
                            if (oldItem != -1) {
                                if (adapter != null) {
                                    adapter.notifyItemChanged(oldItem);
                                }
                                logger.log("notifyItemChanged at " + oldItem);
                            }
                        }
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    isActiveMessageIsRead = true;
                    SeenSender.getAccess().sendSeen(activeCallerId);
                    if (y >= BOTTOM_SCROLLING_BARRIER) {
                        startOrKeepScrollingUp();
                    } else if (y < TOP_SCROLLING_BARRIER && y > TOP_SCROLLING_BARRIER_TOP) {
                        startOrKeepScrollingDown();
                    } else {
                        stopScrolling();
                    }
                    logger.log(("moving: (" + x + ", " + y + ")"));
                    if (getCurrentVisibleRow(y) >= data.size()) {
                        if (data.size() > 0) {
                            adapter.notifyItemChanged(data.size() - 1);
                        }
                        if (filePreviewFragment != null) {
                            if (fileMimeType == MimeType.Video) {
                                if (!videoView.isPlaying()) {
                                    container.setAlpha(0);
                                    videoView.setAlpha(1);
                                    videoView.start();
                                    videoView.invalidate();
                                    hasClickedAttachmentOnce = true;
                                    findViewById(R.id.rootLayout).setBackgroundColor(getResources().getColor(R.color.black));
                                    findViewById(R.id.toolbar).setBackgroundColor(getResources().getColor(R.color.black));
                                }
                            } else {
                                hasClickedAttachmentOnce = true;
                                filePreviewFragment.handleFileWindow(getActualY(y) - data.size() * ROW_HEIGHT);
                            }
                        }
                    } else if (currentVisibleRow != getCurrentVisibleRow(y)) {
                        int oldItem = currentVisibleRow;
                        currentVisibleRow = getCurrentVisibleRow(y);
                        if (adapter != null) {
                            adapter.notifyItemChanged(currentVisibleRow);
                        }
                        logger.log("notifyItemChanged at " + currentVisibleRow);
                        if (oldItem != -1) {
                            if (adapter != null) {
                                adapter.notifyItemChanged(oldItem);
                            }
                            logger.log("notifyItemChanged at " + oldItem);
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    setNameInToolBar();
                    logger.log("touched up");
                    stopScrolling();

                    findViewById(R.id.rootLayout).setBackgroundColor(getResources().getColor(R.color.white));
                    findViewById(R.id.toolbar).setBackgroundColor(0);
                    int oldItem = currentVisibleRow;
                    currentVisibleRow = -1;
                    if (adapter != null) {
                        adapter.notifyItemChanged(oldItem);
                    }
                    if (filePreviewFragment != null) {
                        if (fileMimeType == MimeType.Video) {
                            if (videoView.getAlpha() == 1) {
                                videoView.pause();
                                container.setAlpha(1);
                                videoView.setAlpha(0);
                                videoView.invalidate();
                            }
                        } else {

                            filePreviewFragment.handleFileWindow(0);
                            filePreviewFragment.handleFileWindowClick(0);
                        }
                    }
                    logger.log("notifyItemChanged at " + oldItem);
                    return true;

            }
            return true;
        }
    };

    private int getCurrentVisibleRow(int y) {
        return getActualY(y) / ROW_HEIGHT;
    }

    public int getActualY(int y) {
        return nestedScrollView.getScrollY() + y;
    }

    private void stopScrolling() {
        logger.log("stopScrolling");
        if (timerScrollUp != null) {
            timerScrollUp.cancel();
            timerScrollUp = null;
        }
        if (timerScrollDown != null) {
            timerScrollDown.cancel();
            timerScrollDown = null;
        }
    }

    Timer timerScrollUp;

    private void startOrKeepScrollingUp() {
        if (timerScrollUp == null) {
            logger.log("startOrKeepScrollingUp");
            timerScrollUp = new Timer();
            timerScrollUp.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    nestedScrollView.smoothScrollBy(0, SCROLL_FACTOR);
                }
            }, 0, SCROLL_TIMER_RATE);
        }

    }

    Timer timerScrollDown;

    private void startOrKeepScrollingDown() {
        if (timerScrollDown == null) {
            logger.log("startOrKeepScrollingDown");
            timerScrollDown = new Timer();
            timerScrollDown.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    nestedScrollView.smoothScrollBy(0, -SCROLL_FACTOR);
                }
            }, 0, SCROLL_TIMER_RATE);
        }

    }

    private boolean isPreview = false;
    private boolean hasNextMessage = false;
    private String activeCallerId;
    private boolean isActiveMessageIsRead = false;

    private void readData() {
        text = null;
        filePath = null;
        readIntentData();
        if (isPreview) {
            if (TextUtils.isEmpty(text) && TextUtils.isEmpty(filePath)) {
                I.toast(getString(R.string.nothingToPreview));
                finish();
            }
        } else {
            if (TextUtils.isEmpty(callerId)) {
                I.toast(getString(R.string.something_went_wrong));
            } else {
                readFromDataBase();
            }
        }

        if (!TextUtils.isEmpty(filePath)) {
            fileMimeType = MimeTypeUtil.getMimeTypeFromFilePath(filePath);
        }
    }

    private void readFromDataBase() {
        Executor.ex(() -> {
            Cursor cursor = MessageRepo.get().getMessageByCallerIdCursor(callerId);
            Gui.get().run(() -> {
                if (cursor != null && cursor.getCount() > 1) {
                    hasNextMessage = true;
                }
                if (cursor != null && cursor.moveToFirst()) {
                    text = cursor.getString(cursor.getColumnIndex("content"));
                    filePath = cursor.getString(cursor.getColumnIndex("file_path"));
                    from = cursor.getString(cursor.getColumnIndex("number"));
                    String longMessage = cursor.getString(cursor.getColumnIndex("long_message"));
                    if (!TextUtils.isEmpty(longMessage) && !TextUtils.isEmpty(filePath))
                        filePath = "";
                    if (isGroup) {
                        groupId = cursor.getString(cursor.getColumnIndex("groupid"));
                    }
                    activeCallerId = callerId;
                    isActiveMessageIsRead = false;
                    if (ChatUtil.isFileContent(text)) {
                        text = ChatContentParser.parseCaption(text);
                    }
                    cursor.close();
                }
                if (TextUtils.isEmpty(filePath) && TextUtils.isEmpty(text)) {
                    I.toast(getString(R.string.wrongMessage));
                    finish();
                }
            });

        });

    }

    @Override
    public void onBackPressed() {
        Log.e("on back ", "pressed called");
        if (isPreview || just_entered) {
            finish();
            return;
        } else {
            if (!hasReadAll()) {
                confirmDeleteAndLeave();
            }
            //if(hasReadAll()){
            else {
                Log.e("on back pressed ", "cause has read all");
                endMessageViewing();
                waitForAnimationAndFinishActivity();
            }
        }
    }

    void confirmDeleteAndLeave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ConfidePreviewActivity.this);
        builder.setTitle(getString(R.string.areYourSureLeave));
        builder.setMessage(getString(R.string.thisMessageWillBeDeleted));
        builder.setPositiveButton(getString(R.string.ok_button), (dialog, which) -> {
            dialog.dismiss();
            endMessageViewing();
            waitForAnimationAndFinishActivity();
        });
        builder.setNegativeButton(getString(R.string.no_button), (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }


    private void endMessageViewing() {
        showAnimation();
        SeenSender.getAccess().sendSeen(activeCallerId);
        Executor.ex(() -> {
            MessageRepo.get().deleteMessageByCallID(activeCallerId);

        });
    }


    private void waitForAnimationAndFinishActivity() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, ANIMATION_DURATION);
    }

    private void waitForAnimationOnly() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
            }
        }, ANIMATION_DURATION);
    }

    private static final int ANIMATION_DURATION = 1000;

    private void showAnimation() {
        for (int i = 0; i < rvText.getChildCount(); i++) {
            LinearLayout row = (LinearLayout) rvText.getChildAt(i);
            for (int j = 0; j < row.getChildCount(); j++) {
                TextView textView = (TextView) row.getChildAt(j);
                if (textView.getText().toString().trim().length() > 0) {
                    TextViewBgType textViewBgType = (TextViewBgType) textView.getTag();
                    smokeIt(textView, textViewBgType);
                    textView.animate().alpha(0).setDuration(1000).start();
                }
            }
        }
        smokeIt(filePreviewHolder, TextViewBgType.VISITED);
        filePreviewHolder.animate().alpha(0).setDuration(1000).start();
    }

    boolean hasClickedAttachmentOnce = false;

    private boolean hasReadAll() {
        boolean hasReadAll = true;
        for (int i = 0; i < rvText.getChildCount(); i++) {
            LinearLayout row = (LinearLayout) rvText.getChildAt(i);
            for (int j = 0; j < row.getChildCount(); j++) {
                TextView textView = (TextView) row.getChildAt(j);
                if (textView.getText().toString().trim().length() > 0) {
                    TextViewBgType textViewBgType = (TextViewBgType) textView.getTag();
                    if (textViewBgType == TextViewBgType.UNVISITED) {
                        hasReadAll = false;
                        break;
                    }
                }
            }
        }
        if (TextUtils.isEmpty(filePath)) {
            hasClickedAttachmentOnce = true;
        }

        return (hasReadAll && hasClickedAttachmentOnce);
    }

    private void smokeIt(View view, TextViewBgType textViewBgType) {
        int smokeResourceId;
        switch (textViewBgType) {
            case UNVISITED:
                smokeResourceId = R.drawable.smoke_graphite_and_all;
                break;
            case NO_BG:
            case VISITED:
            default:
                smokeResourceId = R.drawable.smoke_graphite_and_all;
                break;
        }
        new ParticleSystem(this, 4, smokeResourceId, ANIMATION_DURATION)
                .setSpeedByComponentsRange(-0.025f, 0.025f, -0.06f, -0.08f)
                .setAcceleration(0.00001f, 30)
                .setInitialRotationRange(0, 360)
                .addModifier(new AlphaModifier(255, 0, 1000, ANIMATION_DURATION))
                .addModifier(new ScaleModifier(0.5f, 2f, 0, 1000))
                .oneShot(view, 4);
    }

    void confirmDeleteAndReply() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ConfidePreviewActivity.this);
        builder.setTitle(getString(R.string.areYourSureLeave));
        builder.setMessage(getString(R.string.thisMessageWillBeDeleted));
        builder.setPositiveButton(getString(R.string.ok_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                endMessageViewing();
                waitForAnimationAndFinishActivity();
                if (isGroup) {
                    Switcher.switchToSendConfideChat(ConfidePreviewActivity.this, groupId);
                } else {
                    Switcher.switchToSendConfideChat(ConfidePreviewActivity.this, from);
                }
            }
        });
        builder.setNegativeButton(getString(R.string.no_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    void confirmDeleteAndNext() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ConfidePreviewActivity.this);
        builder.setTitle(getString(R.string.areYourSureLeave));
        builder.setMessage(getString(R.string.thisMessageWillBeDeleted));
        builder.setPositiveButton(getString(R.string.ok_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                endMessageViewing();
                if (hasNextMessage) {
                    waitForAnimationAndFinishActivity();
//                    Switcher.switchToReadConfideChat(ConfidePreviewActivity.this, number);
                } else {
                    waitForAnimationAndFinishActivity();
                }
            }
        });
        builder.setNegativeButton(getString(R.string.no_button), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    private void readIntentData() {
        isPreview = getIntent().getBooleanExtra(KEY_IS_PREVIEW, false);
        if (isPreview) {
            if (getIntent().hasExtra(KEY_TEXT)) {
                text = getIntent().getStringExtra(KEY_TEXT);
            }
            if (getIntent().hasExtra(KEY_FILE_PATH)) {
                filePath = getIntent().getStringExtra(KEY_FILE_PATH);
            }
        } else {
            if (getIntent().hasExtra(KEY_CALLER_ID)) {
                callerId = getIntent().getStringExtra(KEY_CALLER_ID);
            }
            if (getIntent().hasExtra(KEY_IS_GROUP)) {
                isGroup = getIntent().getBooleanExtra(KEY_IS_GROUP, false);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            if (isPreview || just_entered) {
                finish();
                return true;
            } else {
                if (!hasReadAll()) {
                    confirmDeleteAndLeave();
                }
                //if(hasReadAll()){
                else {
                    Log.e("on back pressed ", "cause has read all");
                    endMessageViewing();
                    waitForAnimationAndFinishActivity();
                }
            }
        }
        return true;
    }

    private int currentVisibleRow = -1;

    public void reply(View view) {
        if (isPreview) {
            return;
        }
        if (hasReadAll()) {
            endMessageViewing();
            waitForAnimationAndFinishActivity();
            if (isGroup) {
                Switcher.switchToSendConfideChat(ConfidePreviewActivity.this, groupId);
            } else {
                Switcher.switchToSendConfideChat(ConfidePreviewActivity.this, from);
            }
        } else {
            confirmDeleteAndReply();
        }

    }

    public void next(View view) {
        if (hasReadAll()) {
            endMessageViewing();
            waitForAnimationAndFinishActivity();
        } else {
            confirmDeleteAndNext();
        }
    }


    private class TextAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        int TEXT_HOLDER_VIEW = 50;
//        int MEDIA_HOLDER_VIEW = 51;

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new TextViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.simple_horizontal_linear_layout, parent, false));
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof TextViewHolder) {
                ((TextViewHolder) holder).bindView(position);
            }
//            else if (holder instanceof MediaViewHolder) {
//                ((MediaViewHolder) holder).bindView(position);
//            }
        }

        @Override
        public int getItemCount() {
//            if (!TextUtils.isEmpty(filePath)) {
//                return data.size() + 1;
//            }
            return data.size();
        }

        @Override
        public int getItemViewType(int position) {
//            if (!TextUtils.isEmpty(filePath) && position == data.size()) {
//                return MEDIA_HOLDER_VIEW;
//            }
            return TEXT_HOLDER_VIEW;
        }

        private class TextViewHolder extends RecyclerView.ViewHolder {
            LinearLayout layout;
            TextView openedTextView;
            TextView closedVisitedTextView;
            TextView closedUnvisitedTextView;

            TextViewHolder(View itemView) {
                super(itemView);
                layout = itemView.findViewById(R.id.linearLayout);
                openedTextView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_opened_text_view, dummy, false);
                closedUnvisitedTextView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_unvisited_closed_text, dummy, false);
                closedVisitedTextView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_visited_closed_text, dummy, false);
            }

            public void bindView(final int position) {
                if (data == null) return;
                ArrayList<BoxTextModel> rowData = data.get(position);
                if (rowData == null) return;
                layout.removeAllViews();
                for (int i = 0; i < rowData.size(); i++) {
                    BoxTextModel model = rowData.get(i);
                    TextView textView;
                    if (currentVisibleRow == model.row) {
                        textView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_opened_text_view, dummy, false);
                        textView.setTag(TextViewBgType.NO_BG);
                        model.isVisited = true;
                    } else {
                        if (!model.isVisited) {
                            textView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_unvisited_closed_text, dummy, false);
                            textView.setTag(TextViewBgType.UNVISITED);
                        } else {
                            textView = (TextView) LayoutInflater.from(ConfidePreviewActivity.this).inflate(R.layout.confide_visited_closed_text, dummy, false);
                            textView.setTag(TextViewBgType.VISITED);
                        }
                    }
                    textView.setText(model.text);
                    layout.addView(textView);
                    if (i != rowData.size() - 1) {
                        addSpace(layout);
                    }
                }

                itemView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        v.performClick();
                        return false;
                    }
                });
            }
        }
    }


    private void updateDataRow(int position) {
        ArrayList<BoxTextModel> models = data.get(position);
        for (BoxTextModel model : models) {
            model.isVisited = true;
        }
    }

    private enum TextViewBgType {
        UNVISITED,
        VISITED,
        NO_BG
    }
}
