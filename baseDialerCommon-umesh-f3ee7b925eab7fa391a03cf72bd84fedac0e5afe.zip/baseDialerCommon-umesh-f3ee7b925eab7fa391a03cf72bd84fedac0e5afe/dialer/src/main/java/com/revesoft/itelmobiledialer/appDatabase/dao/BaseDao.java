/*
 *  Created by Ifta on 8/8/18 11:04 AM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/6/18 8:54 AM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.dao;

import java.util.List;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Update;

public interface BaseDao<T> {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(T entity);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    List<Long> insertAll(List<T> entities);
    @Update
    int update(T entity);

    @Delete
    int delete(T entity);


}