/*
 *  @author Ifta
 *  Created by Ifta on 8/2/18 12:41 PM
 *  Copyright (c) 2018 . ALL rights reserved.
 *  Last modified 8/2/18 12:41 PM
 *
 */

package com.revesoft.itelmobiledialer.appDatabase.entities;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabaseDefault;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "subscriber_lookup_table", indices = {@Index(value = {"lookup_key"},unique = true)})
public class SubscriberLookUp {
    @NonNull
    @PrimaryKey(autoGenerate = true)
    public int _id;

    @NonNull
    public String number = AppDatabaseDefault.number;

    @ColumnInfo(name = "lookup_key")
    public String lookUpKey;

    public SubscriberLookUp() {
    }

    private SubscriberLookUp(Builder builder) {
        number = builder.number = AppDatabaseDefault.number;
        lookUpKey = builder.lookUpKey = AppDatabaseDefault.lookUpKey;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private String number;
        private String lookUpKey;

        private Builder() {
        }

        public Builder number(String number) {
            this.number = number;
            return this;
        }

        public Builder lookUpKey(String lookUpKey) {
            this.lookUpKey = lookUpKey;
            return this;
        }

        public SubscriberLookUp build() {
            return new SubscriberLookUp(this);
        }
    }
}
