package com.revesoft.itelmobiledialer.databaseentry;


import android.net.Uri;

import com.revesoft.itelmobiledialer.xdatabase.DatabaseUris;


@SuppressWarnings("all")
public interface DatabaseConstants {
    public static final Uri CALL_LOG_URI = DatabaseUris.CALL_LOG_URI;
    public static final Uri SUBSCRIBER_URI = DatabaseUris.SUBSCRIBER_URI;

    public static final Uri MESSAGE_URI = DatabaseUris.MESSAGE_URI;


    public static final String KEY_THREAD_ID = "key_thread_id";

    public static final Uri MESSAGE_HISTORY_URI = DatabaseUris.MESSAGE_HISTORY_URI;

    public static final Uri TOP_UP_LOG_URI = DatabaseUris.TOP_UP_LOG_URI;

    public static final Uri RECHARGE_URI = DatabaseUris.RECHARGE_URI;

    public static final Uri CONTACTS_URI = DatabaseUris.CONTACTS_URI;

    public static final Uri BLOCK_URI = DatabaseUris.BLOCK_URI;

    public static final Uri RATE_URI = DatabaseUris.RATE_TABLE_URI;

    public static final Uri DID_TABLE_URI = DatabaseUris.DID_TABLE_URI;


    public static final Uri BURN_MESSAGE_INFO_URI = DatabaseUris.BURN_MESSAGE_INFO_URI;
    public static final String KEY_SERVER_FILE_PATH = "server_file_path";




    String READY_CONDITION = " AND is_im_ready_for_view=1 ";


    public static final String CONTACTS_TABLE_TEMP = "contacts_temp";

    public static final String KEY_ENTRY_TYPE = "entry_type";

    public static final String DATABASE_NAME = "reveSoftApp.db";
    public static final int DATABASE_VERSION = 1;
    static final String SUBSCRIBER_TABLE = "subscriber";
    static final String MESSAGE_TABLE = "messages";
    static final String MULTIPART_MESSAGE_TABLE = "multipartmessages";

    static final String GROUP_MESSAGE_TABLE = "messages";
    static final String GROUP_TABLE = "group_table";
    static final String TOP_UP_LOG_TABLE = "topuplog";
    static final String RECHARGE_TABLE = "recharge_table";
    static final String CONTACTS_TABLE = "contacts";
    static final String SUBSCRIBED_PACKAGES_TABLE = "subscribed_packages";

    static final String LOCATION_REQUEST_TABLE = "location_request_table";
    static final String MESSAGE_HISTORY_TIME_TABLE = "message_history_time_table";
    static final String MESSAGE_STATUS_TABLE = "message_status_table";
    static final String GROUP_MESSAGE_ELIGIBLE_TABLE = "group_message_eligible_table";
    static final String CALL_RATE_TABLE = "rate_table";
    public static final String DID_TABLE = "did_table";

    public static final String KEY_ID = "_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_NUMBER = "number";
    public static final String KEY_TYPE = "type";
    public static final String KEY_TIME = "date";
    public static final String KEY_RECV_TIME = "received";
    public static final String KEY_NOTIFICATION = "notification";
    public static final String KEY_DURATION = "duration";
    public static final String KEY_CONTENT = "content";
    public static final String KEY_SUBSCRIPTION_STATE = "subscriptionstate";
    public static final String KEY_PRESENCE_STATE = "presencestate";
    public static final String KEY_PRESENCE_NOTE = "presencenote";
    public static final String KEY_PHONE_LOOKUP = "lookup_key";
    public static final String KEY_MESSAGE_TYPE = "messagetype";
    public static final String KEY_MESSAGE_CALL_ID = "callerid";
    public static final String KEY_MESSAGE_CONTENT = "messagecontent";
    public static final String KEY_MESSAGE_DELIVERY_STATUS = "deliverystatus";
    public static final String KEY_TOP_UP_ID = "topupid";
    public static final String KEY_STATUS = "status";
    public static final String KEY_AMOUNT = "amount";
    public static final String KEY_CALLER_ID = "callerid";
    public static final String KEY_SUBSCRIBER_IMAGE = "subscriberimagehash";
    public static final String KEY_GROUP_ID = "groupid";
    public static final String KEY_GROUP_NAME = "groupname";
    public static final String KEY_IS_CREATOR = "creator";
    public static final String KEY_IS_MEMBER = "member";
    public static final String KEY_CURRENCY_CODE = "currency_code";
    public static final String KEY_TRANSACTION_ID = "transaction_id";
    public static final String KEY_PAYMENT_METHOD = "payment_method";
    public static final String KEY_REFUND_TEXT = "refund_text";
    public static final String KEY_FILE_PATH = "filepath";
    public static final String KEY_IS_EMO_ONLY = "is_emo_only";
    public static final String KEY_LONG_MESSAGE = "long_message";
    public static final String KEY_IS_IM_READY_FOR_VIEW = "is_im_ready_for_view";


    public static final String FILE_RETRY_DELAY = "retry_time_gap";
    public static final String FILE_RETRY_EXACT_TIME = "retry_time";
    public static final String FILE_RETRY_ATTEMPT_COUNT = "retry_count";
    public static final String FILE__RETRY_MESSAGE_TYPE = "message_type";


    public static final String KEY_EDIT_COUNT = "editcount";
    public static final String KEY_FUTURE_SEND_TIME = "futuresendtime";
    public static final String KEY_SEEN_TIME = "seentime";
    public static final String KEY_CREATOR = "creatorNumber";
    public static final String KEY_GROUP_TYPE = "group_type";
    public static final String KEY_LAST_ONLINE_TIME = "last_online_time";
    public static final String KEY_IS_VIDEO_CALL = "is_video_call";
    public static final String KEY_CALL_TYPE = "call_type";
    public static final String KEY_CALL_RATE = "call_rate";
    public static final String KEY_PHOTO_URI = "photo_uri";
    public static final String KEY_IS_FAVOURITE = "is_favourite";
    public static final String KEY_CONTACT_ID = "contact_id";
    public static final String KEY_PROCESSED_NUMBER = "processed_number";
    public static final String KEY_SUBSCRIBED_NUMBER = "subscribed_number";
    public static final String KEY_QUERY_ID = "query_id";
    public static final String KEY_RECORDED_FILE_PATH = "record_file_path";
    public static final String KEY_MIME_TYPE = "mime_type";


    public static final String KEY_IS_ENCRYPTED = "is_encrypted";
    public static final String KEY_IS_DECRYPTED = "is_decrypted";
    public static final String KEY_BUDDY_PUBLIC_KEY = "buddy_public_key";
    public static final String KEY_BUDDY_SEED = "buddy_seed";
    public static final String KEY_GROUP_PRIVATE_KEY = "group_private_key";
    public static final String KEY_IS_ENCRYPTED_GROUP = "is_encrypted_group";
    public static final String KEY_OCID = "ocid";
    public static final String KEY_QUOTE_DATA = "quote_preview_content";
    public static final String KEY_QUOTE_FROM_USER = "quote_from_user";
    public static final String KEY_QCID = "qcid";
    public static final String KEY_QUOTE_FILE_PATH = "quote_file_path";
    public static final String KEY_MESSAGE_DISPLAY_TIME = "display_time";
    public static final String KEY_COUNTRY = "country";
    public static final String KEY_OPERATOR = "operator";


    public static final String KEY_ORIGINAL_FILE_PATH = "original_file_path";
    public static final String KEY_BURN_TIME = "burn_time";
    public static final String KEY_TRUE_TIMESTAMP = "true_timestamp";
    public static final String KEY_SEND_ORIGINAL_TIMESTAMP_FLAG = "send_original_timestamp_flag";
    public static final String KEY_IS_CONFIDE = "is_confide";
    public static final String KEY_QUOTE_MIME_TYPE = "quote_mime_type";
    public static final String KEY_BROADCAST_ID = "broadcast_id";
//    private static final String TAG = "DataBase";


    public static final String KEY_BURN_ENTRY_TIME = "burn_entry_time";
    public static final String KEY_BURN_TIMER_INDEX = "burn_timer_index";

//    private Context context;
//    private static DatabaseConstants instance = null;
//    private DataBaseOpenHelper dOpenHelper;
//    private SQLiteDatabase readableDatabase, writeableDatabase;
//
//    Geocoder geocoder;

//    private DatabaseConstants(Context context) {
//        this.context = context.getApplicationContext();
//        dOpenHelper = new DataBaseOpenHelper(context, DATABASE_NAME, DATABASE_VERSION);
//        I.log("datahelper ready : " + dOpenHelper.getDatabaseName());
//        readableDatabase = dOpenHelper.getReadableDatabase();
//        writeableDatabase = dOpenHelper.getWritableDatabase();
//        AppDatabaseLogger.log("DatabaseConstants e database version = " + writeableDatabase.getVersion());
//        geocoder = new Geocoder(this.context, Locale.getDefault());
//        Database.prepareForOperation(context);
//    }

//    public void destroy() {
//        closeDbOpenHelper();
//        instance = null;
//    }

//    public void closeDbOpenHelper() {
//        if (dOpenHelper != null) {
//            dOpenHelper.close();
//            dOpenHelper = null;
//        }
//        instance = null;
//    }
//
//    public static void prepareForOperation(Context context) {
//        if (PreferenceDataManager.isReadyToCreateDB()) {
//            instance = new DatabaseConstants(context);
//        } else {
//            I.log("datahelper failed to prepare");
//        }
//    }

//    public static synchronized DatabaseConstants reInitializeInstance(Context context) {
//        instance = new DatabaseConstants(context);
//        return instance;
//    }

//    public synchronized static DatabaseConstants getInstance(Context context) {
//        if (instance == null || instance.dOpenHelper == null) {
//            prepareForOperation(context);
//        }
//        return instance;
//    }

//    public synchronized static DatabaseConstants getInstance() {
//        if (instance == null || instance.dOpenHelper == null) {
//            prepareForOperation(AppContext.getAccess().getContext());
//        }
//        return instance;
//    }

//    public void keepLast50Logs() {
//        // SQLiteDatabase db = dOpenHelper.getWritableDatabase();
//        // db.execSQL("delete from " + CALL_LOG_TABLE + " where " + KEY_ID
//        // + " not in ( select " + KEY_ID + " from " + CALL_LOG_TABLE
//        // + " order by " + KEY_TIME + " desc limit 50 )");
//        // db.execSQL("delete from " + SMS_LOG_TABLE + " where " + KEY_ID
//        // + " not in ( select " + KEY_ID + " from " + SMS_LOG_TABLE
//        // + " order by " + KEY_TIME + " desc limit 50 )");
//        // db.execSQL("delete from " + TOP_UP_LOG_TABLE + " where " + KEY_ID
//        // + " not in ( select " + KEY_ID + " from " + TOP_UP_LOG_TABLE
//        // + " order by " + KEY_TIME + " desc limit 50 )");
//        // //db.close();
//    }

//    public void createCallLog(CallLogEntry callLogEntry) {
//        try {
//            CallLog callLog = CallLog.createFromCallLogEntry(callLogEntry);
//            callLog.save(() -> {
//                XUriChangeNotifier.notify(XUriChangeNotifier.UriType.CALL_LOG);
//                handleMissedCallRelatedTasks(callLogEntry);
//            });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getGroupChatHistoryLog(String searchString, boolean isShowingHiddenChat) {
//
////        String filterOuthiddenChatClause = (isShowingHiddenChat == true) ? "" : " WHERE messages.number NOT IN (SELECT number FROM hidden_messages WHERE messages.is_encrypted = hidden_messages.is_encrypted)";
////        String fetchHiddenChatClause = (isShowingHiddenChat == true) ? " OR number IN (SELECT number FROM hidden_messages)" : "";
//        String filterOuthiddenGroupChatClause = (isShowingHiddenChat == true) ? "" : " WHERE group_messages.groupid NOT IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1)";
//        String fetchHiddenGroupChatClause = (isShowingHiddenChat == true) ? " OR groupid IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1)" : "";
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            String rawQueryStr = "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number,sum(notification) as unread ,messagecontent, is_encrypted, messagetype, deliverystatus,groupname as name, broadcast_id, Max(date) as date "
//                    + "FROM ( SELECT * from group_messages LEFT JOIN  group_table ON group_messages.groupid = group_table.groupid" + filterOuthiddenGroupChatClause + " ) WHERE ( number like '%"
//                    + searchString
//                    + "%' OR messagecontent like '%"
//                    + searchString
//                    + "%' OR name like '%"
//                    + searchString
//                    + "%'" + READY_CONDITION + fetchHiddenGroupChatClause
//                    + ") GROUP BY groupid HAVING date = max(date) " +
//                    " ORDER BY date DESC";
//
//            cursor = db.rawQuery(rawQueryStr, null);
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        }
//        return cursor;
//    }


//    public void updateSmsQueryID(String request_id, String query_id) {
//        try {
//                Message message = new Message();
//                message.callerId = request_id;
//                message.queryId = query_id;
//                message.update(() -> {
//                    XUriChangeNotifier.notify(XUriChangeNotifier.UriType.MESSAGE);
//                });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateSmsDeliveryStatus(String query_id, int status) {
//        int deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
//        if (status == SMSProvider.SMS_STATUS_PENDING) {
//            deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
//        } else if (status == SMSProvider.SMS_STATUS_FAILED) {
//            deliveryStatus = MessageEntry.DeliveryStatus.FAILED;
//        } else if (status == SMSProvider.SMS_STATUS_SUCCESSFUL) {
//            deliveryStatus = MessageEntry.DeliveryStatus.SUCCESSFUL;
//        }
//
//        try {
//            Message message = new Message();
//            message.queryId = query_id;
//            message.deliveryStatus = deliveryStatus;
//            message.update(() -> {
//                XUriChangeNotifier.notify(XUriChangeNotifier.UriType.MESSAGE);
//            });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getFailedFileLogForNumber(String number) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(MESSAGE_TABLE, null,
//                    KEY_FILE_PATH + " not null and "
//                            + KEY_NUMBER + "='" + number + "'" + " and "
//                            + KEY_MESSAGE_DELIVERY_STATUS + " = " + MessageEntry.DeliveryStatus.FAILED + " and "
//                            + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.SEND,
//                    null, null, null,
//                    KEY_TIME + " desc");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public void updatePendingFileLogAtStart() {
//        try {
//
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.FAILED);
//            values.put(KEY_MESSAGE_CONTENT, "Failed");
//
//            writeableDatabase.update(MESSAGE_TABLE, values, KEY_FILE_PATH + " not null and " + KEY_MESSAGE_DELIVERY_STATUS + " != " + MessageEntry.DeliveryStatus.SUCCESSFUL, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }


//    public long getMessageReceiveTime(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(MESSAGE_TABLE, new String[]{KEY_RECV_TIME},
//                    KEY_CALLER_ID + "= ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getLong(0);
//            } else {
//                return 0;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public long getGroupMessageRecvTime(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(GROUP_MESSAGE_TABLE, new String[]{KEY_RECV_TIME},
//                    KEY_CALLER_ID + " = ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getLong(0);
//            } else {
//                return 0;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public long getMessageDate(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(MESSAGE_TABLE, new String[]{KEY_TIME},
//                    KEY_CALLER_ID + "= ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getLong(0);
//            } else {
//                return 0;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public long getGroupMessageDate(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(GROUP_MESSAGE_TABLE, new String[]{KEY_TIME},
//                    KEY_CALLER_ID + " = ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getLong(0);
//            } else {
//                return 0;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public void createMessageLog(MessageEntry messageEntry) {
//        if (checkForMessage(messageEntry) || messageEntry.editCount == -1) {
//            return;
//        }
//        try {
//            MimeType mimeType = MimeTypeUtil.getMimeType(messageEntry.content);
//            ContentValues values = new ContentValues();
//            long receivedTime = 0;
//            if (messageEntry.editCount == 0) {
//                receivedTime = System.currentTimeMillis();
//            } else {
//                receivedTime = getMessageReceiveTime(messageEntry.callerId);
//                if (receivedTime == 0) {
//                    receivedTime = System.currentTimeMillis();
//                }
//            }
//            Message message = Message.newBuilder()
//                    .number(messageEntry.number)
//                    .groupId(TextUtils.isEmpty(messageEntry.groupId) ? null : messageEntry.groupId)
//                    .date(new Date(messageEntry.time))
//                    .displayTime(new Date((messageEntry.time - UserDataManager.getTimeAdjustment())))
//                    .notification(messageEntry.status)
//                    .content(messageEntry.content)
//                    .messageType(messageEntry.type)
//                    .callerId(messageEntry.callerId)
//                    .deliveryStatus(messageEntry.delivery_status)
//                    .isEmoOnly(EmojiHelper.containsEmojiOnly(messageEntry.content))
//                    .ocid(messageEntry.ocid)
//                    .qcid(messageEntry.qcid)
//                    .quotePreviewContent(messageEntry.quoteData)
//                    .quoteFromUser(messageEntry.quoteFromUser)
//                    .quoteFilePath(messageEntry.quoteMessageFilePath)
//                    .longMessage(messageEntry.longMessage)
//                    .isReadyToView(messageEntry.getIsReadyForView() == 1)
//                    .received(new Date(receivedTime))
//                    .mimeType(mimeType)
//                    .editCount(messageEntry.editCount)
//                    .filePath(messageEntry.filePath)
//                    .isEncrypted(messageEntry.isEncrypted == 1)
//                    .isDecrypted(messageEntry.isDecrypted == 1)
//                    .burnTimerInSecond((int) messageEntry.burnTimerMillis * 1000)
//                    .build();
//
//            Executor.ex(() -> {
//                long success = MessageRepo.get().insert(message);
//                if (success > 0) {
//                    context.getContentResolver().notifyChange(MESSAGE_URI, null);
//                    context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//                }
//            });
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            AppIconNotification.setCountInAppIcon();
//            UnseenMessageCounter.sendSignalToDashBoard();
//        }
//    }

//    public void createMessageLog(SmsMessage message, int read) {
//        if (checkForSMS(message.getTimestampMillis(), message.getOriginatingAddress(), message.getDisplayMessageBody())) {
//            return;
//        }
//        try {
//            ContentValues values = new ContentValues();
//            String number = message.getOriginatingAddress();
//            values.put(KEY_NUMBER, number != null ? number.replaceAll("[+]", "") : "Text Number");
//            values.put(KEY_TIME, message.getTimestampMillis());
//            values.put(KEY_NOTIFICATION, read);
//            values.put(KEY_MESSAGE_CONTENT, message.getDisplayMessageBody());
//            values.put(KEY_MESSAGE_TYPE, MessageEntry.MessageType.RECEIVED_SMS);
//            values.put(KEY_MESSAGE_CALL_ID, "" + number + System.currentTimeMillis());
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.SUCCESSFUL);
//            values.put(KEY_RECV_TIME, System.currentTimeMillis());
//            values.put(KEY_MESSAGE_DISPLAY_TIME, (message.getTimestampMillis()));
//            Log.d("message inserted", "" + writeableDatabase.replace(MESSAGE_TABLE, null, values));
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        AppIconNotification.setCountInAppIcon();
//        UnseenMessageCounter.sendSignalToDashBoard();
//    }

//    public void createMessageLog(SmsMessage[] message, int read) {
//        String from = message[0].getOriginatingAddress();
//        long time = message[0].getTimestampMillis();
//        StringBuffer body = new StringBuffer();
//        for (SmsMessage m : message) {
//            body.append(m.getDisplayMessageBody());
//        }
//        if (checkForSMS(time, from, body.toString())) {
//            return;
//        }
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, from != null ? from.replaceAll("[+]", "") : "Text Number");
//            values.put(KEY_TIME, time);
//            values.put(KEY_NOTIFICATION, read);
//            StringBuffer sb = new StringBuffer();
//            values.put(KEY_MESSAGE_CONTENT, body.toString());
//            values.put(KEY_MESSAGE_TYPE, MessageEntry.MessageType.RECEIVED_SMS);
//            values.put(KEY_MESSAGE_CALL_ID, "" + from + System.currentTimeMillis());
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.SUCCESSFUL);
//            values.put(KEY_RECV_TIME, System.currentTimeMillis());
//            values.put(KEY_MESSAGE_DISPLAY_TIME, (time));
//
//            Log.d("message inserted", "" + writeableDatabase.replace(MESSAGE_TABLE, null, values));
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            AppIconNotification.setCountInAppIcon();
//            UnseenMessageCounter.sendSignalToDashBoard();
//        }
//    }

//    public void createMessageLog(SMSEngine.SimpleSMS message) {
//        if (checkForSMS(message.time, message.address, message.body)) {
//            return;
//        }
//        try {
//            ContentValues values = new ContentValues();
//            String number = message.address;
//            values.put(KEY_NUMBER, number != null ? number.replaceAll("[+]", "") : "Text Number");
//            values.put(KEY_TIME, message.time);
//            values.put(KEY_NOTIFICATION, message.isRead == 0 ? MessageStatus.UNREAD : MessageStatus.READ);
//            values.put(KEY_MESSAGE_CONTENT, message.body);
//            values.put(KEY_MESSAGE_TYPE, MessageEntry.MessageType.RECEIVED_SMS);
//            values.put(KEY_MESSAGE_CALL_ID, "" + number + message.time);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.SUCCESSFUL);
//            values.put(KEY_RECV_TIME, message.time);
//            values.put(KEY_MESSAGE_DISPLAY_TIME, (message.time));
//            Log.d("message inserted", "" + writeableDatabase.replace(MESSAGE_TABLE, null, values));
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            AppIconNotification.setCountInAppIcon();
//            UnseenMessageCounter.sendSignalToDashBoard();
//        }
//    }


//    public int getMessageType(String callid, boolean isGroup) {
//        int messageType = -1;
//        Cursor cursor = null;
//        try {
//            String table = "";
//            if (isGroup) {
//                table = GROUP_MESSAGE_TABLE;
//            } else {
//                table = MESSAGE_TABLE;
//            }
//            cursor = dOpenHelper.getReadableDatabase().query(table, null, KEY_MESSAGE_CALL_ID + "=?", new String[]{callid}, null, null, null);
//            if (cursor != null && cursor.moveToFirst()) {
//                messageType = cursor.getInt(cursor.getColumnIndex(KEY_MESSAGE_TYPE));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//
//        return messageType;
//    }

//    public void createHistoryFetchingMessageLog(ArrayList<SignallingMessageEntry> messageEntries) {
////		if (checkForMessage(messageEntry))
////			return;
//        for (SignallingMessageEntry signallingMessageEntry : messageEntries) {
//            Log.v("DatabaseConstants", "createMessageLog" + signallingMessageEntry.content + "  " + signallingMessageEntry.editCount);
//            if (signallingMessageEntry.editCount == -1 || signallingMessageEntry.time < Database.MessageHistoryTime.Read.time(signallingMessageEntry.number)) {
//                continue;
//            }
//
//            signallingMessageEntry.content = signallingMessageEntry.content.replaceAll("'", "''");
//
//            StringBuilder query = new StringBuilder();
//            String messageContent = "";
//            try {
//                MimeType mimeType = MimeTypeUtil.getMimeType(signallingMessageEntry.content);
//                ContentValues values = new ContentValues();
//                values.put(KEY_NUMBER, signallingMessageEntry.number);
//                values.put(KEY_TIME, signallingMessageEntry.time);
//                values.put(KEY_NOTIFICATION, signallingMessageEntry.status);
//                values.put(KEY_MESSAGE_CONTENT, signallingMessageEntry.content);
//                values.put(KEY_MESSAGE_TYPE, signallingMessageEntry.type);
//                values.put(KEY_MESSAGE_CALL_ID, signallingMessageEntry.callerId);
//                values.put(KEY_MESSAGE_DELIVERY_STATUS, signallingMessageEntry.delivery_status);
//                values.put(KEY_RECV_TIME, signallingMessageEntry.time);
//                values.put(KEY_MESSAGE_DISPLAY_TIME, (signallingMessageEntry.time - UserDataManager.getTimeAdjustment()));
//                values.put(KEY_EDIT_COUNT, signallingMessageEntry.editCount);
//                values.put(KEY_MIME_TYPE, mimeType.toString());
//                if (!TextUtils.isEmpty(signallingMessageEntry.filePath)) {
//                    values.put(KEY_FILE_PATH, signallingMessageEntry.filePath);
//                }
//
//                Log.d("message inserted",
//                        "" + writeableDatabase.replace(MESSAGE_TABLE, null, values));
//                context.getContentResolver().notifyChange(MESSAGE_URI, null);
//                context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            } catch (Exception e) {
//                e.printStackTrace();
//            } finally {
//                // if (db != null)
//                // db.close();
//            }
//        }
//
//        context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//    }

//    public void createHistoryFetchingGroupMessageLog(ArrayList<SignallingMessageEntry> messageEntries) {
////		if (checkForMessage(messageEntry))
////			return;
//        for (SignallingMessageEntry signallingMessageEntry : messageEntries) {
//            if (signallingMessageEntry.editCount == -1 || signallingMessageEntry.time < Database.MessageHistoryTime.Read.time(signallingMessageEntry.groupId)) {
//                continue;
//            }
//
//            signallingMessageEntry.content = signallingMessageEntry.content.replaceAll("'", "''");
//            StringBuilder query = new StringBuilder();
//            try {
//                MimeType mimeType = MimeTypeUtil.getMimeType(signallingMessageEntry.content);
//                ContentValues values = new ContentValues();
//                values.put(KEY_NUMBER, signallingMessageEntry.number);
//                values.put(KEY_TIME, signallingMessageEntry.time);
//                values.put(KEY_NOTIFICATION, signallingMessageEntry.status);
//                values.put(KEY_MESSAGE_CONTENT, signallingMessageEntry.content);
//                values.put(KEY_MESSAGE_TYPE, signallingMessageEntry.type);
//                values.put(KEY_GROUP_ID, signallingMessageEntry.groupId);
//                values.put(KEY_MESSAGE_CALL_ID, signallingMessageEntry.callerId);
//                values.put(KEY_MIME_TYPE, mimeType.toString());
//                values.put(KEY_EDIT_COUNT, signallingMessageEntry.editCount);
//                if (!TextUtils.isEmpty(signallingMessageEntry.filePath)) {
//                    values.put(KEY_FILE_PATH, signallingMessageEntry.filePath);
//                }
//                values.put(KEY_MESSAGE_DELIVERY_STATUS,
//                        signallingMessageEntry.delivery_status);
//                values.put(KEY_RECV_TIME, signallingMessageEntry.time);
//                values.put(KEY_MESSAGE_DISPLAY_TIME, (signallingMessageEntry.time - UserDataManager.getTimeAdjustment()));
//                Log.d("message inserted",
//                        "" + writeableDatabase.replace(GROUP_MESSAGE_TABLE, null, values));
//            } catch (Exception e) {
//                e.printStackTrace();
//            } finally {
//                // if (db != null)
//                // db.close();
//            }
//        }
//        context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//    }


//    public Cursor getSubsciber() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT _id,  number, name, lookup_key,  presencestate, presencenote, subscriberimagehash from subscriber ORDER BY presencestate ASC, name COLLATE NOCASE ASC", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor SearchSubscriber(String searchString) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT _id,  number, name, lookup_key,  presencestate, presencenote, subscriberimagehash from subscriber where subscriber.number like '%"
//                                    + searchString
//                                    + "%' OR subscriber.name like '%"
//                                    + searchString
//                                    + "%' ORDER BY presencestate ASC, name COLLATE NOCASE ASC",
//                            null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public Cursor getSubscriberLookUp() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT _id,  number,  lookup_key from subscriber_lookup_table", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public void checkValidityOfSubscriberNames() {
//        Cursor c = getSubsciber();
//        if (c != null && c.moveToFirst()) {
//            do {
//                String number = c.getString(c.getColumnIndex(KEY_NUMBER));
//                String name = c.getString(c.getColumnIndex(KEY_NAME));
//                String contactName = ContactEngine.getContactNamefromNumber(
//                        context, number);
//                if (name == null || !name.equalsIgnoreCase(contactName)) {
//
//                }
//                updateSubscriberName(number);
//            } while (c.moveToNext());
//        }
//    }

//    public ArrayList<String> getSubsciberNumbers() {
//        ArrayList<String> result = new ArrayList<>();
//        Cursor cursor = null;
//        String s;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT _id, number from subscriber", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                do {
//                    s = cursor.getString(1);
//                    result.add(s);
//                } while (cursor.moveToNext());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", "getSubsciberNumbers: " + e.getMessage());
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public boolean createSubscriber(String number) {
//        try {
//            createSubscriberLookup(number);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        if (checkForSubscriberNumber(number)) {
//            Log.d("DatabaseConstants", "got Subscriber: returning...");
//            return false;
//        }
//        try {
//            String name = ContactEngine.getContactNamefromNumber(context, number);
//            Subscriber subscriber = Subscriber.newBuilder()
//                    .number(number)
//                    .id(ContactEngine.getContactIDFromNumber(context, number))
//                    .name(name == null ? "" : name)
//                    .presenceNote("")
//                    .lookUpKey(ContactEngine.getContactLookupKey(context, number))
//                    .build();
//
//            Executor.ex(() -> {
//                long count = SubscriberRepo.get().insert(subscriber);
//                if (count > 0) {
//                    context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//                    context.getContentResolver().notifyChange(CONTACTS_URI, null);
//                    Log.i("datahelper", "subsciber added " + number);
//                }
//            });
//            return true;
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", "CreateSubscriber: ", e);
//            return false;
//        }
//    }

//    public void createSubscriberLookup(String number) {
//        if (!Util.isFirstRun()) {
//            context.startService(new Intent(context, CommonDataLoaderService.class));
//        }
//        Cursor cursor = ContactEngine.getContactLookupKeyCursor(context, number);
//        if (cursor != null && cursor.moveToFirst()) {
//            do {
//                try {
//                    String lookup = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.LOOKUP_KEY));
//                    if (!checkForSubscriberLookupInLookupTable(lookup)) {
//                        SubscriberLookUp subscriberLookUp = SubscriberLookUp.newBuilder()
//                                .lookUpKey(lookup)
//                                .number(number)
//                                .build();
//                        Executor.ex(() -> {
//                            try {
//                                SubscriberLookUpRepo.get().insert(subscriberLookUp);
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                        });
//                        context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//                        Log.i("datahelper", "createSubscriberLookup subsciber added " + number);
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            } while (cursor.moveToNext());
//        }
//        if (cursor != null) {
//            cursor.close();
//        }
//    }


//    public void createGroup(String callId, String groupId, String groupName, String numbers, String creator, int isCreator, String groupType, int e2e) {
//        Log.v("DatabaseConstants", "createGroup");
//
//        if (groupName.length() == 0) {
//            groupName = "Group Chat";
//        }
//        try {
//            com.revesoft.itelmobiledialer.appDatabase.entities.Group group = com.revesoft.itelmobiledialer.appDatabase.entities.Group.newBuilder()
//                    .number(numbers)
//                    .groupId(groupId)
//                    .groupName(groupName)
//                    .isCreator(isCreator == 1)
//                    .isMember(true)
//                    .creatorNumber(TextUtils.isEmpty(creator) ? "" : creator)
//                    .groupType(groupType != null && groupType.length() > 0 ? Integer.parseInt(groupType) : 0)
//                    .isEncryptedGroup(e2e == 1)
//                    .build();
////            ContentValues values = new ContentValues();
////            values.put(KEY_NUMBER, numbers);
////            values.put(KEY_GROUP_ID, groupId);
////            values.put(KEY_GROUP_NAME, groupName);
////            values.put(KEY_IS_CREATOR, isCreator);
////            values.put(KEY_IS_MEMBER, 1);
////            if (!TextUtils.isEmpty(creator)) {
////                values.put(KEY_CREATOR, creator);
////            }
////            if (groupType != null && groupType.length() > 0) {
////                values.put(KEY_GROUP_TYPE, groupType);
////            }
////            values.put(KEY_IS_ENCRYPTED_GROUP, e2e);
////            writeableDatabase.replace(GROUP_TABLE, null, values);
//            Executor.ex(() -> {
//                long success = GroupRepo.get().insert(group);
//                if (success > 0) {
//                    context.getContentResolver().notifyChange(MESSAGE_URI, null);
//                    context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//                }
//            });
//
//            Log.i("datahelper", "group added " + groupName);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public boolean checkForSubscriberLookupInLookupTable(String lookup) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.query(SUBSCRIBER_LOOKUP_TABLE, new String[]{KEY_PHONE_LOOKUP},
//                    KEY_PHONE_LOOKUP + " ='" + lookup + "'", null, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public void updateGroup(String callId, String groupId, String groupName,
//                            String numbers, String creator, int isCreator, int isMember, String groupType, int e2e) {
//
//        Log.v("mLatitude", "updateGroup");
//        if (groupName.length() == 0) {
//            groupName = "Group";
//        }
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, numbers);
//            values.put(KEY_GROUP_ID, groupId);
//            values.put(KEY_GROUP_NAME, groupName);
//            values.put(KEY_IS_CREATOR, isCreator);
//            values.put(KEY_IS_MEMBER, isMember);
//            if (!TextUtils.isEmpty(creator)) {
//                values.put(KEY_CREATOR, creator);
//            }
//            if (groupType != null && groupType.length() > 0) {
//                values.put(KEY_GROUP_TYPE, groupType);
//            }
//            values.put(KEY_IS_ENCRYPTED_GROUP, e2e);
//            writeableDatabase.update(GROUP_TABLE, values, KEY_GROUP_ID + "=?",
//                    new String[]{groupId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//            Log.i("datahelper", "group added " + groupName);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void createSystemMessage(String callId, String groupId,
//                                    String message, long timeStamp, short messageStatus) {
//        MessageEntry me = new MessageEntry();
//        me.number = "system";
//        me.groupId = groupId;
//        me.type = MessageEntry.MessageType.SYSTEM;
//        me.time = timeStamp;
//        me.content = message;
//        me.callerId = callId;
//        me.status = messageStatus;
//        createGroupMessageLog(me);
//    }

//    public void createSystemMessage(String callId, String groupId,
//                                    String message, int e2e, long timeStamp) {
//        Log.v("createSystemMessage", message);
//        MessageEntry me = new MessageEntry();
//        me.type = MessageEntry.MessageType.SYSTEM;
//        me.time = timeStamp;
//        me.content = message;
//        me.callerId = callId;
//        me.status = MessageStatus.READ;
//        me.number = "system";
//        me.groupId = groupId;
//        me.isEncrypted = e2e;
//        createSystemGroupMessageLog(me);
//    }


//    public void createSystemGroupMessageLog(MessageEntry messageEntry) {
//        if (checkForMessage(messageEntry))
//            return;
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, messageEntry.number);
//            values.put(XTableKeys.KEY_MIME_TYPE, MimeType.System.toString());
//            values.put(KEY_TIME, messageEntry.time);
//            values.put(KEY_NOTIFICATION, messageEntry.status);
//            values.put(KEY_MESSAGE_CONTENT, messageEntry.content);
//            values.put(KEY_MESSAGE_TYPE, messageEntry.type);
//            values.put(KEY_GROUP_ID, messageEntry.groupId);
//            values.put(KEY_MESSAGE_CALL_ID, messageEntry.callerId);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS,
//                    messageEntry.delivery_status);
//            values.put(KEY_RECV_TIME, System.currentTimeMillis());
//            values.put(KEY_IS_ENCRYPTED, messageEntry.isEncrypted);
//            db = dOpenHelper.getWritableDatabase();
//            Log.d("message inserted",
//                    "" + db.replace(GROUP_MESSAGE_TABLE, null, values));
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(GROUP_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void changeGroupMemberShipStatus(String groupId, int isMember) {
//        try {
//            ContentValues values = new ContentValues();
//
//            values.put(KEY_GROUP_ID, groupId);
//            values.put(KEY_IS_MEMBER, isMember);
//
//            int rowsAffected = writeableDatabase.update(GROUP_TABLE, values, KEY_GROUP_ID
//                    + " = ?", new String[]{groupId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateGroupName(String groupId, String groupName) {
//        Log.d("mLatitude", "updateGroupName");
//        try {
//            ContentValues values = new ContentValues();
//
//            values.put(KEY_GROUP_ID, groupId);
//            values.put(KEY_GROUP_NAME, groupName);
//            int rowsAffected = writeableDatabase.update(GROUP_TABLE, values, KEY_GROUP_ID
//                    + " = ?", new String[]{groupId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//            context.getContentResolver().notifyChange(DatabaseUris.MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public int updateGroupMembers(String groupId, String groupMembers) {
//        int n = 0;
//        try {
//            ContentValues values = new ContentValues();
//
//            values.put(KEY_GROUP_ID, groupId);
//            values.put(KEY_NUMBER, groupMembers);
//
//            n = writeableDatabase.update(GROUP_TABLE, values, KEY_GROUP_ID + " = ?", new String[]{groupId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return n;
//    }
//
//    public String getGroupName(String groupId) {
//        Cursor cursor = null;
//        String result = null;
//        int n = 0;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT groupname FROM group_table where groupid = '" + groupId + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//            cursor.moveToFirst();
//            if (n > 0) {
//                result = cursor.getString(0);
//            }
//            cursor.close();
//        }
//        return result;
//    }

//    public int checkIfCreator(String groupId) {
//        Cursor cursor = null;
//        int n = 0;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT creator FROM group_table where groupid = '" + groupId + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//            cursor.moveToFirst();
//        }
//        return (n == 0) ? 1 : cursor.getInt(0);
//    }

    /**
     * @param groupId groupId
     * @return 1 if user is a member of this group, 0 otherwise
     */
//    public int checkIfMember(String groupId) {
//        Cursor cursor = null;
//        int n = 0;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT member FROM group_table where groupid = '" + groupId + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//            cursor.moveToFirst();
//            n = (n == 0) ? 0 : cursor.getInt(0);
//            cursor.close();
//        }
//        return n;
//    }

//    public String getConcatedGroupNumbers(String groupId) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT number FROM group_table where groupid = '" + groupId + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                int n = cursor.getCount();
//                cursor.moveToFirst();
//                if (n > 0) {
//                    return cursor.getString(0);
//                }
//            }
//        }
//        return null;
//    }

//    public String[] getGroupNumbers(String groupId) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT number FROM group_table where groupid = '" + groupId + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null && cursor.getCount() > 0) {
//                cursor.moveToFirst();
//                return cursor.getString(0).split(";");
//            }
//        }
//        return null;
//    }


//    public void createGroupMessageLog(MessageEntry messageEntry) {
//        I.log("createGroupMessageLog");
//        if (checkForGroupMessage(messageEntry) || messageEntry.editCount == -1) {
//            I.log("createGroupMessageLog never imagined");
//            return;
//        }
//        I.log("createGroupMessageLog >>");
//        try {
//            MimeType mimeType = MimeTypeUtil.getMimeType(messageEntry.content);
//            ContentValues values = new ContentValues();
//            long receivedTime = 0;
//            if (messageEntry.editCount == 0) {
//                receivedTime = System.currentTimeMillis();
//            } else {
//                receivedTime = getMessageReceiveTime(messageEntry.callerId);
//                if (receivedTime == 0) {
//                    receivedTime = System.currentTimeMillis();
//                }
//            }
//            Message message = Message.newBuilder()
//                    .number(messageEntry.number)
//                    .groupId(TextUtils.isEmpty(messageEntry.groupId) ? null : messageEntry.groupId)
//                    .date(new Date(messageEntry.time))
//                    .displayTime(new Date((messageEntry.time - UserDataManager.getTimeAdjustment())))
//                    .notification(messageEntry.status)
//                    .content(messageEntry.content)
//                    .messageType(messageEntry.type)
//                    .callerId(messageEntry.callerId)
//                    .deliveryStatus(messageEntry.delivery_status)
//                    .isEmoOnly(EmojiHelper.containsEmojiOnly(messageEntry.content))
//                    .ocid(messageEntry.ocid)
//                    .qcid(messageEntry.qcid)
//                    .quotePreviewContent(messageEntry.quoteData)
//                    .quoteFromUser(messageEntry.quoteFromUser)
//                    .quoteFilePath(messageEntry.quoteMessageFilePath)
//                    .longMessage(messageEntry.longMessage)
//                    .isReadyToView(messageEntry.getIsReadyForView() == 1)
//                    .received(new Date(receivedTime))
//                    .mimeType(mimeType)
//                    .editCount(messageEntry.editCount)
//                    .filePath(messageEntry.filePath)
//                    .isEncrypted(messageEntry.isEncrypted == 1)
//                    .isDecrypted(messageEntry.isDecrypted == 1)
//                    .burnTimerInSecond((int) messageEntry.burnTimerMillis * 1000)
//                    .build();
//
//            if (messageEntry.type == MessageEntry.MessageType.SEND) {
//                int memberCount = 0;
//                if (CommonData.groupIdToMemberCount.containsKey(messageEntry.groupId)) {
//                    memberCount = CommonData.groupIdToMemberCount.get(messageEntry.groupId);
//                } else {
//                    Group group = GroupMessageAssistant.getGroupById(context, messageEntry.groupId);
//                    memberCount = group.memberCountButMe;
//                }
//                long affectedRows = Database.GroupMessageEligibility.Create.singleEntry(messageEntry.groupId, messageEntry.callerId, memberCount);
//                I.log("affectedRows = " + affectedRows);
//            } else {
//                I.log("received");
//            }
//            Executor.ex(() -> {
//                long success = MessageRepo.get().insert(message);
//                if (success > 0) {
//                    context.getContentResolver().notifyChange(MESSAGE_URI, null);
//                    context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//                }
//            });
//
//        } catch (Exception e) {
//            I.log(e.getLocalizedMessage());
//            e.printStackTrace();
//        } finally {
//            AppIconNotification.setCountInAppIcon();
//            UnseenMessageCounter.sendSignalToDashBoard();
//        }
//    }

//    private boolean checkForGroupMessage(MessageEntry me) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.query(GROUP_MESSAGE_TABLE, new String[]{KEY_ID},
//                    KEY_MESSAGE_CALL_ID + " ='" + me.callerId + "' and "
//                            + KEY_NUMBER + " ='" + me.number + "' and "
//                            + KEY_EDIT_COUNT + " =" + me.editCount + " and "
//                            + KEY_MESSAGE_CONTENT + " =?",
//                    new String[]{me.content}, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public Cursor getCombinedMessageLogs() {
//        Cursor cursor = null;
//        try {
//            String excludeSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                excludeSMS = " AND messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
//            String query = "SELECT m.groupid, m.number, mime_type, messagecontent, callerid, messagetype, deliverystatus, received, " +
//                    "Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count, " +
//                    "CASE when m.groupid is null " +
//                    "then (select name from contacts c where c.processed_number=m.number) " +
//                    "else (select groupname from group_table gt where gt.groupid=m.groupid) END as name, " +
//                    "display_time, long_message, filepath FROM messages m\n" +
//                    "where m.is_im_ready_for_view = 1 " +
//                    excludeSMS
//                    + " GROUP BY IFNULL(m.groupid,m.number) HAVING m.date = max(m.date) ORDER BY received DESC";
//            Log.d("DatabaseConstants", "getCombinedMessageLogs: Query: " + query);
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null && !cursor.isClosed()) {
//                Log.v("DatabaseConstants", "Combined messages count: " + cursor.getCount());
//                if (cursor.moveToLast()) {
//                    context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Context.MODE_PRIVATE).edit().putLong(HistoryFetchingConstants.MAIN_HISTORY_OLDEST_TIMESTAMP, cursor.getLong(cursor
//                            .getColumnIndex(DatabaseConstants.KEY_TIME))).commit();
//                }
//            }
//        }
//        return cursor;
//    }

//    public Cursor getCombinedMessageLogsForForward() {
//        Cursor cursor = null;
//        try {
//            String excludeSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                excludeSMS = " AND messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
//            String query = "SELECT 100 as m._id, m.groupid, m.number, mime_type, messagecontent, callerid, messagetype, deliverystatus, received, " +
//                    "Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count, " +
//                    "CASE when m.groupid is null " +
//                    "then (select name from contacts c where c.processed_number=m.number) " +
//                    "else (select groupname from group_table gt where gt.groupid=m.groupid) END as name, " +
//                    "display_time, long_message, filepath FROM messages m\n" +
//                    "where m.is_im_ready_for_view = 1 " +
//                    excludeSMS
//                    + " GROUP BY IFNULL(m.groupid,m.number) HAVING m.date = max(m.date) ORDER BY received DESC";
//            Log.d("DatabaseConstants", "getCombinedMessageLogs: Query: " + query);
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null && !cursor.isClosed()) {
//                Log.v("DatabaseConstants", "Combined messages count: " + cursor.getCount());
//                if (cursor.moveToLast()) {
//                    context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Context.MODE_PRIVATE).edit().putLong(HistoryFetchingConstants.MAIN_HISTORY_OLDEST_TIMESTAMP, cursor.getLong(cursor
//                            .getColumnIndex(DatabaseConstants.KEY_TIME))).commit();
//                }
//            }
//        }
//        return cursor;
//    }

//    public Cursor getGroupMessageLogs() {
//        Cursor cursor = null;
//        try {
//            String query = "SELECT Max(m._id) as _id, m.groupid, m.number,g.number as allMembersPhoneNo, messagecontent, messagetype, Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count, groupname as name, null as photo_uri, null as lookup_key "
//                    + "FROM messages m LEFT JOIN group_table g ON (m.groupid = g.groupid) GROUP BY m.groupid HAVING m.date = max(m.date)"
//                    + " ORDER BY m.date DESC";
//            Log.d("DatabaseConstants", "getCombinedMessageLogs: Query: " + query);
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                Log.v("DatabaseConstants", "Combined messages count: " + cursor.getCount());
//            }
//        }
//        return cursor;
//    }

//    public Cursor getMessageAndSMSLogs() {
//        Cursor cursor = null;
//        try {
//            String integrateSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                integrateSMS = "where messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
//
//            String query = "SELECT Max(m._id) as _id, null as groupid, m.number, messagecontent, messagetype, Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count,  c.name as name, photo_uri, lookup_key, display_time "
//                    + "FROM messages m LEFT JOIN contacts c ON (m.number = c.processed_number) " + integrateSMS + " GROUP BY m.number HAVING m.date = max(m.date)"
//                    + " ORDER BY date DESC";
//            Log.d("DatabaseConstants", "getCombinedMessageLogs: Query: " + query);
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                Log.v("DatabaseConstants", "Combined messages count: " + cursor.getCount());
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public String getUnseenMessagesCount() {
//        Cursor cursor = null;
//        try {
//            String integrateSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                integrateSMS = "where messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
////            String rawQuery = "SELECT SUM(notification) as unseen_message_count FROM messages " + integrateSMS;
//            String rawQuery = "SELECT SUM(notification) as unseen_message_count " +
//                    "FROM( SELECT notification FROM messages " + integrateSMS + " )";
//            cursor = readableDatabase.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null && cursor.moveToFirst()) {
//                String unseenMessageCount = cursor.getString(cursor.getColumnIndex("unseen_message_count"));
//                Log.d("sayma_unseen", "unseen message count " + unseenMessageCount);
//                cursor.close();
//                return unseenMessageCount;
//            }
//        }
//        return null;
//    }

//    public String getUnseenPersonMessagesCount() {
//        Cursor cursor = null;
//        try {
//            String integrateSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                integrateSMS = "where messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
////            String rawQuery = "SELECT SUM(notification) as unseen_message_count FROM messages " + integrateSMS;
//            String rawQuery = "SELECT SUM(unread) as unseen_message_count " +
//                    "FROM ( SELECT 1 as unread, number, null as groupid FROM messages " + integrateSMS + " GROUP BY number HAVING SUM(notification) > 0" +
//                    " UNION ALL SELECT 1 as unread, null as number, groupid FROM messages GROUP BY groupid  HAVING SUM(notification) > 0)";
////            String rawQuery = "SELECT sum(notification) as unseen_message_count FROM messages group by groupid " ;
//            cursor = readableDatabase.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null && cursor.moveToFirst()) {
//                String unseenMessageCount = cursor.getString(cursor.getColumnIndex("unseen_message_count"));
//                Log.d("sayma_message_count", "total unseen message count : " + unseenMessageCount + "");
//                cursor.close();
//                return unseenMessageCount;
//            }
//        }
//        return null;
//    }

//    public Cursor getMessageLogs() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT Max(_id) as _id, number, messagecontent, messagetype, Max(date) as date "
//                                    + "FROM messages GROUP BY number HAVING messages.date = max(messages.date) ORDER BY date DESC",
//                            null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor getUnDecryptedMultiPartMessagesByNumber(String number) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT * "
//                                    + "FROM multipartmessages  Where  number ='" + number + "' AND is_decrypted = 0 AND is_outgoing = 0 "
//                            , null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//
//        }
//
//        return cursor;
//    }

//    public Cursor getUnDecryptedIncomingMultiPartMessagesByGroupID(String groupID) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT * "
//                                    + "FROM multipartmessages WHERE groupid= '" + groupID + "' AND is_decrypted = 0 AND is_outgoing = 0 "
//                            , null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//
//        }
//
//        return cursor;
//    }

//    public Cursor getMultiPartMessagesByCallerIDLocal(String callerID) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT * "
//                                    + "FROM multipartmessages WHERE calleridlocal= '" + callerID + "'"
//                            , null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//
//        }
//
//        return cursor;
//    }

//    public Cursor searchMessage(String searchString) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT Max(_id) as _id, number, messagecontent, messagetype, Min(date) as date FROM messages where messages.number like '%"
//                                    + searchString
//                                    + "%' OR messages.messagecontent like '%"
//                                    + searchString
//                                    + "%' GROUP BY number ORDER BY date DESC",
//                            null);
//            // Log.v("All messages count", "" + c.getCount());
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public Cursor searchImsSmsAndGroupMessages(String searchString) {
//        Cursor cursor = null;
//        try {
//            String integrateSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                integrateSMS = " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
//
//            String query = "SELECT Max(m._id) as _id, null as groupid,m.callerid as callerid, m.number as number," +
//                    "mime_type, messagecontent, " +
//                    "messagetype, deliverystatus, received, Max(m.date) as date, SUM(m.notification) as unread_count," +
//                    " COUNT(m.messagecontent) as message_count, c.name as name, display_time, long_message, filepath FROM "
//                    + " messages m LEFT JOIN (SELECT * FROM contacts a GROUP BY a.processed_number) c on m.number=c.processed_number" + " WHERE (m.number like '%"
//                    + searchString
//                    + "%' OR m.messagecontent like '%"
//                    + searchString
//                    + "%' OR c.name like '%"
//                    + searchString
//                    + "%' AND m.is_im_ready_for_view = 1) and m.groupid is null"
//                    + integrateSMS
//                    + " GROUP BY m.number HAVING m.date = max(m.date)"
//                    + " UNION "
//                    + "SELECT Max(gm._id) as _id, gm.groupid as groupid,gm.callerid as callerid, gm.number as number ,mime_type, messagecontent, "
//                    + "messagetype, deliverystatus, received, Max(gm.date) as date, SUM(gm.notification) as unread_count, "
//                    + "COUNT(gm.messagecontent) as message_count, gt.groupname as name, display_time, long_message, filepath "
//                    + "FROM messages gm JOIN group_table gt on gm.groupid=gt.groupid"
//                    + " WHERE (gm.number like '%"
//                    + searchString
//                    + "%' OR gm.messagecontent like '%"
//                    + searchString
//                    + "%' OR gt.groupname like '%"
//                    + searchString
//                    + "%'  AND gm.is_im_ready_for_view = 1)"
//                    + " GROUP BY gm.groupid HAVING gm.date = max(gm.date)";
//
//
////            String query = "SELECT Max(m._id) as _id, null as groupid, m.number,m.mime_type, m.messagecontent, " +
////                    "m.messagetype, m.deliverystatus, Max(m.date) as date, SUM(m.notification) as unread_count," +
////                    " COUNT(m.messagecontent) as message_count, c.name as name FROM "
////                    + " messages m LEFT JOIN contacts c on m.number=c.processed_number" + " WHERE (m.number like '%"
////                    + searchString
////                    + "%' OR m.messagecontent like '%"
////                    + searchString
////                    + "%')"
////                    + integrateSMS
////                    + " GROUP BY m.number HAVING m.date = max(m.date)"
////                    + " UNION "
////                    + "SELECT gm.Max(gm._id) as _id, gm.groupid, gm.number,gm.mime_type, gm.messagecontent, "
////                    +"gm.messagetype, gm.deliverystatus, Max(gm.date) as date, SUM(gm.notification) as unread_count, "
////                    +"COUNT(messagecontent) as message_count, messages.groupname as name FROM "
////                    + "FROM messages LEFT JOIN group_table on messages.groupid=group_table.groupid"
////                    + " WHERE (number like '%"
////                    + searchString
////                    + "%' OR messagecontent like '%"
////                    + searchString
////                    + "%')"
////                    + " GROUP BY groupid HAVING messages.date = max(messages.date)";
//
//            Log.i("DatabaseConstants", "SearchImsSmsAndGroupMessages query: " + query);
//
//
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor searchImsSmsAndGroupMessagesForForward(String searchString) {
//        Cursor cursor = null;
//        try {
//            String integrateSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                integrateSMS = " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
//
//            String query = "SELECT Max(m._id) as _id, null as groupid,m.callerid as callerid, m.number as number," +
//                    "mime_type, messagecontent, " +
//                    "messagetype, deliverystatus, received, Max(m.date) as date, SUM(m.notification) as unread_count," +
//                    " COUNT(m.messagecontent) as message_count, c.name as name, display_time, long_message, filepath FROM "
//                    + " messages m LEFT JOIN (SELECT * FROM contacts a GROUP BY a.processed_number) c on m.number=c.processed_number" + " WHERE (m.number like '%"
//                    + searchString
//                    + "%' OR m.messagecontent like '%"
//                    + searchString
//                    + "%' OR c.name like '%"
//                    + searchString
//                    + "%'  AND m.is_im_ready_for_view = 1)"
//                    + integrateSMS
//                    + " GROUP BY m.number HAVING m.date = max(m.date)"
//                    + " UNION "
//                    + "SELECT Max(gm._id) as _id, gm.groupid as groupid,gm.callerid as callerid, gm.number as number ,mime_type, messagecontent, "
//                    + "messagetype, deliverystatus, received, Max(gm.date) as date, SUM(gm.notification) as unread_count, "
//                    + "COUNT(gm.messagecontent) as message_count, gt.groupname as name, display_time, long_message, filepath "
//                    + "FROM messages gm LEFT JOIN group_table gt on gm.groupid=gt.groupid"
//                    + " WHERE (gm.number like '%"
//                    + searchString
//                    + "%' OR gm.messagecontent like '%"
//                    + searchString
//                    + "%' OR gt.groupname like '%"
//                    + searchString
//                    + "%'  AND gm.is_im_ready_for_view = 1 AND gt.member = 1 )"
//                    + " GROUP BY gm.groupid HAVING gm.date = max(gm.date)";
//
//
//            Log.i("DatabaseConstants", "SearchImsSmsAndGroupMessages query: " + query);
//
//
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor searchGroupMessages(String searchString) {
//        Cursor cursor = null;
//
//        try {
//
//            String query = "SELECT Max(_id) as _id, m.groupid, m.number, messagecontent, messagetype, Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count, groupname as name, null as photo_uri, null as lookup_key "
//                    + "FROM messages m LEFT JOIN group_table g ON (m.groupid = g.groupid)"
//                    + " WHERE (name like '%"
//                    + searchString
//                    + "%' OR m.number like '%"
//                    + searchString
//                    + "%')"
//                    + " GROUP BY m.groupid HAVING m.date = max(m.date)";
//
//            Log.i("DatabaseConstants", "SearchImsSmsAndGroupMessages query: " + query);
//
//
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor searchMessagesAndSms(String searchString) {
//        Cursor cursor = null;
//
//        try {
//            String integrateSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                integrateSMS = " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
//
//            String query = "SELECT Max(m._id) as _id, null as groupid, m.number, messagecontent, messagetype, Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count, c.name as name, photo_uri, lookup_key, display_time FROM "
//                    + " messages m LEFT JOIN contacts c ON (m.number = c.processed_number) WHERE (m.number like '%"
//                    + searchString
//                    + "%' OR c.name like '%"
//                    + searchString
//                    + "%')"
//                    + integrateSMS
//                    + " GROUP BY m.number HAVING m.date = max(m.date)";
//
//            Log.i("DatabaseConstants", "searchImsAndSms query: " + query);
//
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor getMessages(String number) {
//        Cursor cursor = null;
//        try {
//
//            cursor = readableDatabase.query(MESSAGE_TABLE, new String[]{KEY_ID, KEY_NUMBER,
//                    KEY_TIME, KEY_MESSAGE_CONTENT, KEY_MESSAGE_TYPE,
//                    KEY_MESSAGE_DELIVERY_STATUS, KEY_MESSAGE_DISPLAY_TIME}, KEY_NUMBER + " ='" + number
//                    + "'", null, null, null, KEY_TIME + " ASC");
//            // Log.v("count messages for " + number, "" + cursor.getCount());
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor getMessages(String number, int count) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("select * from (select * from "
//                    + MESSAGE_TABLE + " where " + KEY_NUMBER + "='" + number
//                    + "' order by " + KEY_TIME + " desc limit " + count
//                    + ") as t order by " + KEY_RECV_TIME + " asc", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//                if (cursor.moveToFirst()) {
//                    context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Context.MODE_PRIVATE).edit().putLong(HistoryFetchingConstants.USER_HISTORY_OLDEST_TIMESTAMP, cursor.getLong(cursor
//                            .getColumnIndex(DatabaseConstants.KEY_TIME))).commit();
//                }
//            }
//        }
//        return cursor;
//    }

//    public Cursor getGroupMessages(String number, int count) {
//        Cursor cursor = null;
//        try {
//            if (count == 0)
//                cursor = readableDatabase.rawQuery("select * from "
//                        + GROUP_MESSAGE_TABLE + " where " + KEY_GROUP_ID
//                        + "='" + number + "' and    ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 ) and  " + KEY_IS_DECRYPTED + "=1" + " order by " + KEY_TIME
//                        + " asc ", null);
//            else
//                cursor = readableDatabase.rawQuery("select * from "
//                        + GROUP_MESSAGE_TABLE + " where " + KEY_GROUP_ID
//                        + "='" + number + "' and " + KEY_IS_DECRYPTED + "=1" + " order by " + KEY_TIME
//                        + " asc limit " + count, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//                if (cursor.moveToFirst()) {
//                    context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Context.MODE_PRIVATE).edit().putLong(HistoryFetchingConstants.USER_HISTORY_OLDEST_TIMESTAMP, cursor.getLong(cursor
//                            .getColumnIndex(DatabaseConstants.KEY_TIME))).commit();
//                }
//            }
//        }
//        return cursor;
//    }

//    public String getLastDialerNumber() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_NUMBER},
//                    null, null, null, null, KEY_TIME + " desc limit 1");
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getString(0);
//            } else {
//                return "";
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public boolean checkForMessage(MessageEntry me) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.query(MESSAGE_TABLE, new String[]{KEY_ID},
//                    KEY_MESSAGE_CALL_ID + " ='" + me.callerId + "' and "
//                            + KEY_NUMBER + " ='" + me.number + "' and "
//                            + KEY_EDIT_COUNT + " =" + me.editCount + " and "
//                            + KEY_MESSAGE_CONTENT + " =?",
//                    new String[]{me.content}, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return result;
//    }

//    public boolean checkForSMS(long time, String number, String content) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.query(MESSAGE_TABLE, new String[]{KEY_ID},
//                    KEY_TIME + " = " + time + " and "
//                            + KEY_NUMBER + " = ? and "
//                            + KEY_MESSAGE_CONTENT + " = ?",
//                    new String[]{number, content}, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return result;
//    }

//    public boolean checkForSubscriberNumberAndKey(String number) {
//        String key = ContactEngine.getContactLookupKey(context, removePrefixes(number));
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase
//                    .query(SUBSCRIBER_TABLE, new String[]{KEY_ID},
//                            KEY_PHONE_LOOKUP + " ='" + key + "' and "
//                                    + KEY_NUMBER + " like '%" + removePrefixes(number) + "'",
//                            null, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return result;
//    }

//    public boolean checkForSubscriberByNumber(String number) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase
//                    .query(SUBSCRIBER_TABLE, new String[]{KEY_ID},
//                            KEY_NUMBER + " like '%" + removePrefixes(number) + "'",
//                            null, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return result;
//    }

//    public boolean checkForSubscriber(String number) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase
//                    .query(SUBSCRIBER_TABLE, new String[]{KEY_ID},
//                            KEY_NUMBER + " like '%" + removePrefixes(number) + "'",
//                            null, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public boolean isSubscriber(String number) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase
//                    .query(SUBSCRIBER_TABLE, new String[]{KEY_NUMBER},
//                            KEY_NUMBER + " = ?",
//                            new String[]{number}, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    /**
//     * @param nonTranslatedNumber you can provide non translated number or translated number. both acceptable.
//     * @param countryCode         provide the country code to help number translation
//     * @return true if the number is of a subscriber.
//     */
//    public boolean isSubscriber(String nonTranslatedNumber, int countryCode) {
//        String translatedNumber = Util.translateNumber(nonTranslatedNumber, countryCode);
//        Cursor cursor = null;
//        String rawQuery = "SELECT * FROM " + SUBSCRIBER_TABLE + " WHERE " + KEY_NUMBER + " = '" + nonTranslatedNumber + "' OR " + KEY_NUMBER + " = '" + translatedNumber + "'";
//        boolean result = false;
//        try {
//            cursor = readableDatabase.rawQuery(rawQuery, null);
//            if (cursor.moveToFirst() && cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }
//
//    public boolean checkForSubscriberLookUp(String key) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.query(SUBSCRIBER_TABLE, new String[]{KEY_ID},
//                    KEY_PHONE_LOOKUP + " ='" + key + "'", null, null, null,
//                    null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public String getSubscribedNumber(String number) {
//        String key = ContactEngine.getContactLookupKey(context, removePrefixes(number));
//        Cursor cursor = null;
//        String result = null;
//        try {
//            cursor = readableDatabase.query(SUBSCRIBER_TABLE, new String[]{KEY_ID,
//                            KEY_NUMBER}, KEY_PHONE_LOOKUP + " ='" + key + "' and "
//                            + KEY_NUMBER + " like '%" + number + "'", null, null, null,
//                    null);
//
//            if (cursor != null && cursor.moveToFirst()) {
//                result = cursor.getString(cursor.getColumnIndex(KEY_NUMBER));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result != null ? result : removePrefixes(number);
//    }

//    /**
//     * This function is a variation of getSubscriber. This takes an array of
//     * subscriber numbers as param and excludes them in the result. This is
//     * useful for situations where we need to filter out some members of
//     * existing group.
//     *
//     * @param subscriberNumbers The array containg the numbers to be excluded.
//     * @return Cursor containing subscriber information
//     */
//    public Cursor getSubsciber(String[] subscriberNumbers) {
//        Cursor cursor = null;
//        try {
//            StringBuilder inClauseBuilder = new StringBuilder();
//            inClauseBuilder.append("(");
//            for (int i = 0; i < subscriberNumbers.length; i++) {
//
//                if (i == 0) {
//                    inClauseBuilder.append("\'").append(subscriberNumbers[i])
//                            .append("\'");
//                } else {
//                    inClauseBuilder.append(", ").append("\'")
//                            .append(subscriberNumbers[i]).append("\'");
//                }
//            }
//            inClauseBuilder.append(")");
//            cursor = readableDatabase.rawQuery("SELECT _id,  number, name, lookup_key,  presencestate, " +
//                            "presencenote from subscriber WHERE number NOT IN "
//                            + inClauseBuilder.toString()
//                            + " ORDER BY presencestate ASC, name ASC",
//                    null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public boolean checkForGroup(String groupId) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.query(GROUP_TABLE, new String[]{KEY_GROUP_ID},
//                    KEY_GROUP_ID + " ='" + groupId + "'", null, null, null,
//                    null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public boolean checkForSubscriberNumber(String number) {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.query(SUBSCRIBER_TABLE, new String[]{KEY_ID},
//                    KEY_NUMBER + " =?", new String[]{number}, null, null, null);
//
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }
//
//    public void updateSubscriber(String number, int state, String note) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, number);
//            values.put(KEY_PRESENCE_STATE, state);
//            values.put(KEY_PRESENCE_NOTE, note);
//            writeableDatabase.update(SUBSCRIBER_TABLE, values, KEY_NUMBER + "='" + number
//                    + "'", null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
////            sendUserStatusUpdateBroadcast(number);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateSubscriber(String number, PresenceState state, String note, Long lastOnline) {
//        try {
//            ContentValues values = new ContentValues();
////            values.put(KEY_NUMBER, number);
//            values.put(KEY_PRESENCE_STATE, state.getValue());
//            values.put(KEY_PRESENCE_NOTE, note);
//            if (lastOnline > 0) {
//                values.put(KEY_LAST_ONLINE_TIME, lastOnline);
//            }
//            int i = writeableDatabase.update(SUBSCRIBER_TABLE, values, KEY_NUMBER + "='" + number + "'"/*+ " OR " + KEY_NUMBER + "='" + number + "'"*/, null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(CALL_LOG_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//            sendUserStatusUpdateBroadcast(number);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    private void sendUserStatusUpdateBroadcast(String number) {
//        Intent intent = new Intent(Constants.DASHBOARD_INTENT_FILTER);
//        intent.putExtra(Constants.Contact.KEY_NUMBER, number);
//        LocalBroadcastManager.getInstance(context.getApplicationContext()).sendBroadcast(intent);
//    }

//    private void updateSubscriberName(String number) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_ID, ContactEngine.getContactIDFromNumber(context, number));
//            String name = ContactEngine.getContactNamefromNumber(context, number);
//
//            values.put(KEY_NAME, name == null ? "" : name);
//            values.put(KEY_PHONE_LOOKUP, ContactEngine.getContactLookupKey(context, number));
//            writeableDatabase.update(SUBSCRIBER_TABLE, values, KEY_NUMBER + "='" + number + "'", null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateSubscriber(String number, String subscriberPicHash) {
//        try {
//            ContentValues values = new ContentValues();
//
//            values.put(KEY_NUMBER, number);
//            values.put(KEY_ID, ContactEngine.getContactIDFromNumber(context, number));
//
//            values.put(KEY_PRESENCE_NOTE, " ");
//            values.put(KEY_PHONE_LOOKUP, ContactEngine.getContactLookupKey(context, number));
//
//            values.put(KEY_SUBSCRIBER_IMAGE, subscriberPicHash);
//
//            int rowsAffected = writeableDatabase.update(SUBSCRIBER_TABLE, values, KEY_NUMBER + " = ?", new String[]{number});
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//            Log.i("Mkhan", "subscriber updated " + number + " rows affected " + rowsAffected);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteSubscriberHash(String number) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, number);
//            values.put(KEY_SUBSCRIBER_IMAGE, "");
//
//            int rowsAffected = writeableDatabase.update(SUBSCRIBER_TABLE, values, KEY_NUMBER + " = ?", new String[]{number});
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//            Log.i("Mkhan", "subscriber updated " + number + " rows affected " + rowsAffected);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public String getSubscriberHash(String number) {
//        String result = null;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(SUBSCRIBER_TABLE,
//                    new String[]{KEY_SUBSCRIBER_IMAGE}, KEY_NUMBER + "="
//                            + number, null, null, null, null);
//            // Log.v("All messages count", "" + c.getCount());
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getString(cursor
//                        .getColumnIndex(KEY_SUBSCRIBER_IMAGE));
//            }
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public synchronized void resetSubscriber() {
//        long st = System.currentTimeMillis();
//        Log.i("DatabaseConstants", "in resetSubscriber time:" + System.currentTimeMillis());
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_PRESENCE_STATE, SubscriberEntry.PresenceState.OFFLINE);
//            int n = writeableDatabase.update(SUBSCRIBER_TABLE, values, "1=1", null);
//            Log.i("DatabaseConstants", "resetSubscriber. Updated rows: " + n + " time: " + (System.currentTimeMillis() - st));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public int getSubscriptionStateByNumber(String number) {
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            cursor = readableDatabase.rawQuery(
//                    "select presencestate from subscriber where number='"
//                            + number + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = 1;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public int getPresenceStateByNumber(String number) {
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            cursor = readableDatabase.rawQuery("select presencestate from subscriber where number='" + number + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getInt(cursor.getColumnIndex(KEY_PRESENCE_STATE));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }
//
//    public void deleteSubscriber(String number) {
//        try {
//            deleteSubscriberLookup(number);
//            writeableDatabase.delete(SUBSCRIBER_TABLE, "number = '" + number + "'", null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteAllSubscribers() {
//        try {
//            writeableDatabase.delete(SUBSCRIBER_LOOKUP_TABLE, "1=1", null);
//            writeableDatabase.delete(SUBSCRIBER_TABLE, "1=1", null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteSubscriberLookup(String number) {
//        context.startService(new Intent(context, CommonDataLoaderService.class));
//        try {
//            writeableDatabase.delete(SUBSCRIBER_LOOKUP_TABLE, "number = '" + number + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateMessageNotification(String number) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NOTIFICATION, MessageStatus.READ);
//            writeableDatabase.update(MESSAGE_TABLE, values, KEY_NUMBER + "='" + number + "'", null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//
//            AppIconNotification.setCountInAppIcon();
//            UnseenMessageCounter.sendSignalToDashBoard();
//            Log.d("sayma_unseen", "called in updatemessagenotification ");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateGroupMessageNotification(String groupId) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NOTIFICATION, MessageStatus.READ);
//            int n = writeableDatabase.update(GROUP_MESSAGE_TABLE, values, KEY_GROUP_ID + "='" + groupId + "'", null);
//
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//
//            AppIconNotification.setCountInAppIcon();
//            UnseenMessageCounter.sendSignalToDashBoard();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public String getGroupCreator(String groupId) {
//        return null;
//    }

//    public Cursor getGroup(String groupId) {
//        Cursor cursor = null;
//        cursor = readableDatabase.rawQuery("SELECT * FROM group_table where groupid = '" + groupId + "'", null);
//        if (cursor.moveToFirst()) {
//            return cursor;
//        }
//        return null;
//    }

//    public Cursor getAllGroupInfo() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT * FROM group_table", null);
//            if (cursor.moveToFirst()) {
//                return cursor;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

//    public Cursor getGroupInfoForForward(String groupName) {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT  groupname , groupid as _id, number, creator FROM group_table where groupname = '"
//                    + groupName + "'", null);
//            if (cursor.moveToFirst()) {
//                I.log(cursor);
//                return cursor;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

//    public int getMessageNotification(String number) {
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            cursor = readableDatabase.rawQuery("select count(notification) as cnt from "
//                    + MESSAGE_TABLE + " where number='" + number + "' and "
//                    + KEY_MESSAGE_TYPE + " ="
//                    + MessageEntry.MessageType.RECEIVED + " and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD, null);
//            // Log.v("count messages for " + number, "" + cursor.getCount());
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getInt(cursor.getColumnIndex("cnt"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public int getGroupMessageNotification(String groupId) {
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            cursor = readableDatabase.rawQuery("select count(notification) as cnt from "
//                    + GROUP_MESSAGE_TABLE + " where groupid='" + groupId
//                    + "' and " + KEY_MESSAGE_TYPE + " <>"
//                    + MessageEntry.MessageType.SEND + " and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD, null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getInt(cursor.getColumnIndex("cnt"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public int getMessageNotificationCount() {
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            cursor = readableDatabase.rawQuery("select count(notification) as cnt from "
//                    + MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE + " ="
//                    + MessageEntry.MessageType.RECEIVED + " and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD, null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getInt(cursor.getColumnIndex("cnt"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public int getCombinedMessageNotificationCount() {
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            String integrateSMS = "";
//            if (!context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                integrateSMS = " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS;
//            }
//
//
//            cursor = readableDatabase.rawQuery("select count(notification) as cnt from  "
//                    + MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE + " <> "
//                    + MessageEntry.MessageType.SEND + integrateSMS + " and "
//                    + KEY_NOTIFICATION + " = "
//                    + MessageStatus.UNREAD + " UNION "
//                    + "select count(notification) as cnt from "
//                    + GROUP_MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE
//                    + " <>" + MessageEntry.MessageType.SEND + " and "
//                    + KEY_NOTIFICATION + " = "
//                    + MessageStatus.UNREAD, null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getInt(cursor.getColumnIndex("cnt"));
//                cursor.moveToNext();
//                result += result = cursor.getInt(cursor.getColumnIndex("cnt")); // BAD
//            }
//        } catch (Exception e) {
//            if (e != null) {
//                e.printStackTrace();
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public boolean checkForIncomingMessage() {
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            cursor = readableDatabase.rawQuery("select notification from subscriber where notification=1", null);
//            if (cursor.getCount() > 0) {
//                result = true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public Cursor getFailedHTTPReceivingSIngleChatMessageLogs(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT   callerid, messagecontent,  deliverystatus, file_path, messagetype "
//                                    + "FROM " + MESSAGE_TABLE + " WHERE  deliverystatus = 404 AND " + " number = " + number + " AND ( messagecontent like '%"
//                                    + FileTransferViaHTTPHelper.SEND_FILE_PREFIX
//                                    + "%' )  ",
//                            null);
//
//
//        } catch (Exception e) {
//            if (e != null) {
//                e.printStackTrace();
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public Cursor getHTTPReceivingSingleChatMessageLogs() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT   callerid,  filepath, deliverystatus "
//                                    + "FROM " + MESSAGE_TABLE + " WHERE  deliverystatus IN(200, 3210) " + " AND messagetype = 1 AND ( messagecontent like '%"
//                                    + FileTransferViaHTTPHelper.SEND_FILE_PREFIX
//                                    + "%' )  ",
//                            null);
//
//
//        } catch (Exception e) {
//            if (e != null) {
//                e.printStackTrace();
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public Cursor getHTTPReceivingGroupMessageLogs() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT   callerid,  deliverystatus, filepath "
//                    + "FROM messages WHERE  deliverystatus IN( 200, 3210 )" + " AND  messagetype = 1 "
//                    + "AND ( messagecontent like '%" + FileTransferViaHTTPHelper.SEND_FILE_PREFIX + "%' )  ", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public void updateGroupMessageDeliveryStatus(String callerId, int deliveryStatus) {
//        Log.v("fileTransfer", "updateGroupMessageDeliveryStatus");
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, deliveryStatus);
//            writeableDatabase.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?", new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateNoReplyUploadingGroupMessageDeliveryStatusToFailed() {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.FAILED);
//            writeableDatabase.update(GROUP_MESSAGE_TABLE, values,
//                    KEY_FILE_PATH + " not null and " + KEY_MESSAGE_DELIVERY_STATUS + " = " +
//                            MessageEntry.DeliveryStatus.NO_REPLY,
//                    null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateReceivingDownloadingGroupMessageDeliveryStatusToFailed() {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.FAILED);
//            writeableDatabase.update(GROUP_MESSAGE_TABLE, values,
//                    KEY_FILE_PATH + " not null and " + KEY_MESSAGE_DELIVERY_STATUS + " = " +
//                            MessageEntry.DeliveryStatus.RECEIVING,
//                    null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateNoReplyUploadingMessageDeliveryStatusToFailed() {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.FAILED);
//            writeableDatabase.update(MESSAGE_TABLE, values,
//                    KEY_FILE_PATH + " not null and " + KEY_MESSAGE_DELIVERY_STATUS + " = " +
//                            MessageEntry.DeliveryStatus.NO_REPLY,
//                    null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateReceivingDownloadingMessageDeliveryStatusToFailed() {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, MessageEntry.DeliveryStatus.FAILED);
//            writeableDatabase.update(MESSAGE_TABLE, values,
//                    KEY_FILE_PATH + " not null and " + KEY_MESSAGE_DELIVERY_STATUS + " = " +
//                            MessageEntry.DeliveryStatus.RECEIVING,
//                    null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateMessageDeliveryStatus(String callerId, int deliveryStatus) {
//        Log.v("Abhi", "fileTransfer" + " " + "updateDeliveryStatus");
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, deliveryStatus);
//            writeableDatabase.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?", new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        Log.v("fileTransfer", "updateDeliveryStatus successful");
//
//    }

//    public Cursor getTopUpLogs() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(TOP_UP_LOG_TABLE,
//                    new String[]{KEY_ID, KEY_TOP_UP_ID, KEY_NUMBER,
//                            KEY_AMOUNT, KEY_STATUS, KEY_TIME}, null, null,
//                    null, null, KEY_TIME + " desc");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public void createTopUpLog(TopUpLogEntry mtuEntry) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_TOP_UP_ID, mtuEntry.topupid);
//            values.put(KEY_NUMBER, mtuEntry.number);
//            values.put(KEY_AMOUNT, mtuEntry.amount);
//            values.put(KEY_TIME, mtuEntry.time);
//            values.put(KEY_STATUS, mtuEntry.status);
//            writeableDatabase.insert(TOP_UP_LOG_TABLE, null, values);
//            context.getContentResolver().notifyChange(TOP_UP_LOG_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public String[] getPendingTopUpID() {
//        Cursor cursor = null;
//        String[] topupids = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT topupid from " + TOP_UP_LOG_TABLE + " WHERE status=2 or status=3", null);
//
//            topupids = new String[cursor.getCount()];
//            int i = 0;
//            if (cursor.moveToFirst()) {
//                do {
//                    topupids[i++] = cursor.getString(0);
//                } while (cursor.moveToNext());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return topupids;
//    }

//    public void updateTopUpLog(int topupid, int status) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_TOP_UP_ID, topupid);
//            values.put(KEY_STATUS, status);
//            int n = writeableDatabase.update(TOP_UP_LOG_TABLE, values, KEY_TOP_UP_ID + "=" + topupid, null);
//            context.getContentResolver().notifyChange(TOP_UP_LOG_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getAppContactsCursor(String searchText) {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            String projection = CONTACTS_TABLE + "." + KEY_NAME + " AS " + KEY_NAME + ", " +
//                    CONTACTS_TABLE + "." + KEY_PROCESSED_NUMBER + " AS " + KEY_PROCESSED_NUMBER + ", " +
//                    CONTACTS_TABLE + "." + KEY_PHONE_LOOKUP + " AS " + KEY_PHONE_LOOKUP + ", " +
//                    CONTACTS_TABLE + "." + KEY_PHOTO_URI + " AS " + KEY_PHOTO_URI;
//            String where = " WHERE (" + CONTACTS_TABLE + "." + KEY_NAME + " LIKE '%" + searchText + "%' OR " + CONTACTS_TABLE + "." + KEY_NUMBER + " LIKE '%" + searchText + "%')" +
//                    " AND " + CONTACTS_TABLE + "." + KEY_NAME + " IS NOT null AND " + CONTACTS_TABLE + "." + KEY_PHONE_LOOKUP + " IS NOT null";
//            String sort = " ORDER BY " + CONTACTS_TABLE + "." + KEY_NAME + " COLLATE LOCALIZED ASC";
//            String rawQuery = "SELECT " + projection + " from " + SUBSCRIBER_TABLE + " LEFT JOIN " + CONTACTS_TABLE + " ON " + SUBSCRIBER_TABLE + ".number = " + CONTACTS_TABLE + ".processed_number" + where + " GROUP BY " + SUBSCRIBER_TABLE + ".number" + sort;
//            cursor = readableDatabase.rawQuery(rawQuery, null);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getAppContactsCursor(String searchText, String[] excludeContactNumbers) {
//        String notInClause = "";
//        if (excludeContactNumbers != null && excludeContactNumbers.length > 0) {
//            StringBuilder stringBuilder = new StringBuilder();
//            stringBuilder.append(" NOT IN (");
//            for (int i = 0; i < excludeContactNumbers.length; i++) {
//                stringBuilder.append("'");
//                stringBuilder.append(excludeContactNumbers[i]);
//                stringBuilder.append("',");
//            }
//            stringBuilder.deleteCharAt(stringBuilder.length() - 1);
//            stringBuilder.append(") ");
//            notInClause = " AND " + CONTACTS_TABLE + "." + KEY_PROCESSED_NUMBER + stringBuilder.toString();
//        }
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            String projection = CONTACTS_TABLE + "." + KEY_NAME + " AS " + KEY_NAME + ", " +
//                    CONTACTS_TABLE + "." + KEY_PROCESSED_NUMBER + " AS " + KEY_PROCESSED_NUMBER + ", " +
//                    CONTACTS_TABLE + "." + KEY_PHONE_LOOKUP + " AS " + KEY_PHONE_LOOKUP + ", " +
//                    CONTACTS_TABLE + "." + KEY_PHOTO_URI + " AS " + KEY_PHOTO_URI;
//            String where = " WHERE (" + CONTACTS_TABLE + "." + KEY_NAME + " LIKE '%" + searchText + "%' OR " + CONTACTS_TABLE + "." + KEY_NUMBER + " LIKE '%" + searchText + "%')" +
//                    " AND " + CONTACTS_TABLE + "." + KEY_NAME + " IS NOT null AND " + CONTACTS_TABLE + "." + KEY_PHONE_LOOKUP + " IS NOT null"
//                    + notInClause;
//
//            String sort = " ORDER BY " + CONTACTS_TABLE + "." + KEY_NAME + " COLLATE LOCALIZED ASC";
//            String rawQuery = "SELECT " + projection + " from " + SUBSCRIBER_TABLE + " LEFT JOIN " + CONTACTS_TABLE + " ON " + SUBSCRIBER_TABLE + ".number = " + CONTACTS_TABLE + ".processed_number" + where + " GROUP BY " + SUBSCRIBER_TABLE + ".number" + sort;
//            cursor = readableDatabase.rawQuery(rawQuery, null);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }


//    public void deleteGroupMessage(String groupID, String callid) {
//        try {
//            writeableDatabase.delete(GROUP_MESSAGE_TABLE, /*"groupid = '" + groupID + "' and "+*/KEY_CALLER_ID + " = '" + callid + "'", null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteGroupMessageWithoutNotify(String groupID, String callid) {
//        try {
//            writeableDatabase.delete(GROUP_MESSAGE_TABLE, /*"groupid = '" + groupID + "' and "+*/KEY_CALLER_ID + " = '" + callid + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getCallLogs() {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "1=1",
//                    null, null, null, KEY_TIME + " desc");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//        }
//        n = n + 1;
//        return cursor;
//    }
//
//    public Cursor getMostCalledLogs(int limit) {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT _id,  number, count(number) as cnt from log group by number ORDER BY cnt DESC limit " + limit, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//        }
//        n = n + 1;
//        return cursor;
//    }

//    public Cursor getVOIPhCallLogs(int count) {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE + "," + CONTACTS_TABLE, new String[]{KEY_ID,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION, KEY_CALL_TYPE, KEY_IS_VIDEO_CALL, KEY_CALL_RATE}, "type != "
//                            + CallLogEntry.CallLogType.CALLTHROUGH, null, null, null,
//                    KEY_TIME + " desc", count > 0 ? ("" + count) : null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//        }
//        n = n + 1;
//        return cursor;
//    }
//
//    public Cursor getCallLogsWithNameAndPic(int count) {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            String rawQuery = "SELECT * from (SELECT l._id as _id, l.number as number, l.type as type, l.call_type as call_type, is_video_call, call_rate, l.date as date, l.duration as duration, c.name as name, c.photo_uri as photo_uri, s.number as subscribed_number, c.lookup_key as lookup_key " +
//                    " FROM log l LEFT JOIN contacts c ON (l.number = c.processed_number OR l.processed_number=c.processed_number) LEFT JOIN subscriber s ON s.number = l.number) temp GROUP BY temp._id ORDER BY temp.date desc ";
//
//            if (count > 0) {
//                rawQuery += " LIMIT " + count;
//            }
//
//            cursor = readableDatabase.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//        }
//        n = n + 1;
//        return cursor;
//    }

//    public Cursor getCallLogsWithNameAndPic(String searchText, int count) {
//        Cursor cursor = null;
//        try {
//            String rawQuery = "SELECT * from (" +
//                    "SELECT l._id as _id, l.number as number, l.type as type, l.call_type as call_type, is_video_call, call_rate, l.date as date, l.duration as duration, c.name as name, c.photo_uri as photo_uri, s.number as subscribed_number, c.lookup_key as lookup_key " +
//                    " FROM log l LEFT JOIN contacts c ON (" +
//                    "l.number = c.processed_number OR l.processed_number=c.processed_number" +
//                    ") LEFT JOIN subscriber s ON s.number = l.number OR s.number = l.processed_number" +
//                    ") temp WHERE temp.name LIKE '%" + searchText + "%' OR temp.number LIKE '%" + searchText + "%' " +
//                    "GROUP BY temp._id ORDER BY temp.date desc ";
//
//            if (count > 0) {
//                rawQuery += " LIMIT " + count;
//            }
//            cursor = SDKDatabase.get().rawQuery(rawQuery);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getCallThroughCallLogs(int count) {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "type = "
//                            + CallLogEntry.CallLogType.CALLTHROUGH, null, null, null,
//                    KEY_TIME + " desc", "" + count);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        n = n + 1;
//        return cursor;
//    }

//    public Cursor getCallLogs(int count) {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "1=1",
//                    null, null, null, KEY_TIME + " desc", "" + count);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//        }
//        n = n + 1;
//        return cursor;
//    }
//
//    public Cursor getLastCallLog() {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "1=1",
//                    null, null, null, KEY_TIME + " desc", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//            Log.d("DatabaseConstants", "Last Call Log found: " + n);
//        }
//        n = n + 1;
//        return cursor;
//    }


//    public Cursor getRecent150CallLogs() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID, KEY_NAME,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "1=1",
//                    null, null, null, KEY_TIME + " desc limit 150");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }
//
//    public Cursor getMissedCallLogs() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID, KEY_NAME,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "type = 2",
//                    null, null, null, KEY_TIME + " desc");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public Cursor getDialedCallLogs() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID, KEY_NAME,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "type = 0",
//                    null, null, null, KEY_TIME + " desc");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor getReceivedCallLogs() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(CALL_LOG_TABLE, new String[]{KEY_ID, KEY_NAME,
//                            KEY_NUMBER, KEY_TYPE, KEY_TIME, KEY_DURATION}, "type = 1",
//                    null, null, null, KEY_TIME + " desc");
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public boolean checkForPhoneNumber(String temp) {
//        long id = ContactEngine.getContactIDFromNumber(context, temp);
//        if (id > 0) {
//            return true;
//        }
//        return false;
//    }

//    public void createDummyCallLog(int number) {
//        try {
//            ContentValues values = null;
//            for (int i = 0; i < number; i++) {
//                values = new ContentValues();
//                values.put(KEY_NUMBER, "01710380938");
//                values.put(KEY_TYPE, i % 3);
//                values.put(KEY_TIME, (System.currentTimeMillis() - (number - i) * 3600 * 24 * 1000));
//                values.put(KEY_DURATION, 558);
//                writeableDatabase.insert(CALL_LOG_TABLE, null, values);
//                i++;
//
//                values = new ContentValues();
//                values.put(KEY_NUMBER, "01710380938");
//                values.put(KEY_TYPE, i % 3);
//                values.put(KEY_TIME, (System.currentTimeMillis() - (number - i) * 3600 * 24 * 1000));
//                values.put(KEY_DURATION, 558);
//                writeableDatabase.insert(CALL_LOG_TABLE, null, values);
//                i++;
//
//                values = new ContentValues();
//                values.put(KEY_NUMBER, "01833316028");
//                values.put(KEY_TYPE, i % 3);
//                values.put(KEY_TIME, (System.currentTimeMillis() - (number - i) * 3600 * 24 * 1000));
//                values.put(KEY_DURATION, 362);
//                writeableDatabase.insert(CALL_LOG_TABLE, null, values);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void createDummySubscriber() {
////        createSubscriber("01710360938");
////        createSubscriber("8801717423733");
////        createSubscriber("8801717799340");
////        createSubscriber("8801718122907");
////        createSubscriber("8801712719389");
//    }

//    public void setMessageDeliveryStatus(String callId, MessageDeliveryStatus messageDeliveryStatus) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, messageDeliveryStatus.getValue());
//            int n = writeableDatabase.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "='" + callId + "'", null);
//
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void setGroupMessageDeliveryStatus(String callId, MessageDeliveryStatus messageDeliveryStatus) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, messageDeliveryStatus.getValue());
//            int n = writeableDatabase.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "='"
//                    + callId + "'", null);
//
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    /**
//     * This function just returns the subscribers having the given numbers as
//     * params. Other subscribers are excluded
//     *
//     * @param subscriberNumbers phone number of subscriber to load
//     * @return cursor containing subscrier info
//     */
//    public Cursor getSubscribersHavingSpecifiedNumbers(String[] subscriberNumbers) {
//        Cursor cursor = null;
//        try {
//            StringBuilder inClauseBuilder = new StringBuilder();
//            inClauseBuilder.append("(");
//            for (int i = 0; i < subscriberNumbers.length; i++) {
//
//                if (i == 0) {
//                    inClauseBuilder.append("\'").append(subscriberNumbers[i])
//                            .append("\'");
//                } else {
//                    inClauseBuilder.append(", ").append("\'")
//                            .append(subscriberNumbers[i]).append("\'");
//                }
//            }
//            inClauseBuilder.append(")");
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT _id,  number, name, lookup_key,  presencestate, presencenote,last_online_time from subscriber WHERE number IN "
//                                    + inClauseBuilder.toString()
//                                    + " ORDER BY presencestate ASC, name ASC",
//                            null);
//            // Log.v("All messages count", "" + cursor.getCount());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor getLastReceivedMessage(String number) {
//        Cursor cursor = null;
//        try {
//            StringBuilder inClauseBuilder = new StringBuilder();
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT received,Max(date)  as date from messages where number = '" + number + "' AND messagetype = '1'",
//                            null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    /**
//     * This function is a variation of getSubscriber. This takes an array of
//     * subscriber numbers as param and excludes them in the result. This is
//     * useful for situations where we need to filter out some members of
//     * existing group.
//     *
//     * @param subscriberNumbers The array containg the numbers to be excluded.
//     * @return Cursor containing subscriber information
//     */
//    public Cursor getSubscibersExcludingSpecifiedNumbers(
//            String[] subscriberNumbers) {
//        Cursor cursor = null;
//        try {
//            StringBuilder inClauseBuilder = new StringBuilder();
//            inClauseBuilder.append("(");
//            for (int i = 0; i < subscriberNumbers.length; i++) {
//
//                if (i == 0) {
//                    inClauseBuilder.append("\'").append(subscriberNumbers[i])
//                            .append("\'");
//                } else {
//                    inClauseBuilder.append(", ").append("\'")
//                            .append(subscriberNumbers[i]).append("\'");
//                }
//            }
//            inClauseBuilder.append(")");
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT _id,  number, name, lookup_key,  presencestate, presencenote from subscriber WHERE number NOT IN "
//                                    + inClauseBuilder.toString()
//                                    + " ORDER BY presencestate ASC, name ASC",
//                            null);
//            // Log.v("All messages count", "" + cursor.getCount());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

    // ////////////////////////

//    /**
//     * As of now a group can contain number that does not belong to a
//     * subscriber. So in this case we are taking the members that are subscriber
//     * through query and then by iterating through the returned cursor we are
//     * determining what numbers are not subscribers. We then add rows to the
//     * cursor so that it can be showed. The added row contains some predefined
//     * info
//     *
//     * @param groupMemberNumbers The array containing group member numbers.
//     * @return cursor containg subscribers ang nonsubscriber members
//     */

//    public Cursor getGroupMembers(String[] groupMemberNumbers) {
//        Cursor cursor = null;
//        MergeCursor mergeCursor = null;
//        MatrixCursor matrixCursor = null;
//        try {
//            ArrayList<String> notSubscriberList = new ArrayList<String>();
//            StringBuilder inClauseBuilder = new StringBuilder();
//            inClauseBuilder.append("(");
//            for (int i = 0; i < groupMemberNumbers.length; i++) {
//
//                // just initializing notSubscriberList. later subscribers are
//                // removed
//                notSubscriberList.add(groupMemberNumbers[i]);
//
//                if (i == 0) {
//                    inClauseBuilder.append("\'").append(groupMemberNumbers[i])
//                            .append("\'");
//                } else {
//                    inClauseBuilder.append(", ").append("\'")
//                            .append(groupMemberNumbers[i]).append("\'");
//                }
//            }
//            inClauseBuilder.append(")");
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT _id,  number, name, lookup_key,  presencestate, presencenote from subscriber WHERE number IN "
//                                    + inClauseBuilder.toString()
//                                    + " ORDER BY presencestate ASC, name ASC",
//                            null);
//            // Log.v("All messages count", "" + cursor.getCount());
//
//            matrixCursor = new MatrixCursor(new String[]{"s_id", "_id",
//                    KEY_NUMBER, KEY_NAME, "lookup_key", "presencestate",
//                    "presencenote"});
//            if (cursor != null) {
//                if (cursor.moveToFirst()) {
//                    do {
//                        String number = cursor.getString(cursor
//                                .getColumnIndex(KEY_NUMBER));
//                        if (notSubscriberList.contains(number)) {
//                            notSubscriberList.remove(number);
//                        }
//                    } while (cursor.moveToNext());
//                }
//
//                for (String memberNumber : notSubscriberList) {
//
//                    matrixCursor.addRow(new Object[]{1001, 1001,
//                            memberNumber, "", memberNumber, 4, ""});
//                }
//                }
//
//                mergeCursor = new MergeCursor(new Cursor[]{cursor,
//                        matrixCursor});
//            } else {
//                for (String memberNumber : notSubscriberList) {
//
//                    matrixCursor.addRow(new Object[]{1001, 1001,
//                            memberNumber, "", memberNumber, 4, ""});
//                }
//
//                mergeCursor = new MergeCursor(new Cursor[]{matrixCursor});
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (mergeCursor != null) {
//                mergeCursor.getCount();
//            }
//        }
//
//        return mergeCursor;
//    }
//
//    public void deleteMessage(String number, long time) {
//        try {
//            writeableDatabase.delete(MESSAGE_TABLE, "number = '" + number + "' and date ="
//                    + time, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteMessage(String number) {
//        try {
//            writeableDatabase.delete(MESSAGE_TABLE, "number = '" + number + "'", null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public boolean deleteGroupMessages(String groupId) {
//        try {
//            writeableDatabase.execSQL("DELETE FROM " + GROUP_MESSAGE_TABLE + " WHERE groupid = '" + groupId + "' AND messagetype <> 2");
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//            return true;
//        } catch (SQLException exception) {
//            exception.printStackTrace();
//            return false;
//        }
//    }

//    public void deleteGroupWithAllMessages(String groupID) {
//        try {
//            writeableDatabase.delete(GROUP_MESSAGE_TABLE, KEY_GROUP_ID + " = ?", new String[]{groupID});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteMessage(String number, String callid) {
//        try {
//            writeableDatabase.delete(MESSAGE_TABLE, /*"number = '" + number + "' and "+*/KEY_CALLER_ID + " = '" + callid + "'", null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteMessageWithoutNotiFiy(String number, String callid) {
//        try {
//            writeableDatabase.delete(MESSAGE_TABLE, /*"number = '" + number + "' and "+*/KEY_CALLER_ID + " = '" + callid + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteCallLog(String number, long time) {
//        try {
//            writeableDatabase.delete(CALL_LOG_TABLE, "number = '" + number + "' and date ="
//                    + time, null);
//            context.getContentResolver().notifyChange(CALL_LOG_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteCallLog(String number, ArrayList<TimeEntry> logs) {
//        try {
//            for (int i = 0; i < logs.size(); i++) {
//                writeableDatabase.delete(CALL_LOG_TABLE, "number = '" + number + "' and date ="
//                        + logs.get(i).time, null);
//            }
//            context.getContentResolver().notifyChange(CALL_LOG_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteCallLogByDelimitedIDs(String IDs) {
//        List<String> callLogIDs = Arrays.asList(IDs.split(","));
//        try {
//            for (int i = 0; i < callLogIDs.size(); i++) {
//                writeableDatabase.delete(CALL_LOG_TABLE, "_id = " + callLogIDs.get(i), null);
//            }
//            context.getContentResolver().notifyChange(CALL_LOG_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void deleteAllCallLogs() {
//        try {
//            writeableDatabase.execSQL("delete from " + CALL_LOG_TABLE);
//            context.getContentResolver().notifyChange(CALL_LOG_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteIMSLogByDelimitedNumbers(String numbers) {
//        List<String> numbersList = Arrays.asList(numbers.split(","));
//        try {
//            for (int i = 0; i < numbersList.size(); i++) {
//                writeableDatabase.delete(MESSAGE_TABLE, "number = " + numbersList.get(i), null);
//            }
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteAllIMSLogs() {
//        try {
//            writeableDatabase.execSQL("delete from " + MESSAGE_TABLE);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteAllGroupMessagesLogs() {
//        try {
//            writeableDatabase.execSQL("delete from " + GROUP_MESSAGE_TABLE);
//
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteGroupMessageLogByDelimitedGroupIDs(String groupIDs) {
//        List<String> gorupIDList = Arrays.asList(groupIDs.split(","));
//        try {
//            for (int i = 0; i < gorupIDList.size(); i++) {
//                writeableDatabase.delete(GROUP_MESSAGE_TABLE,
//                        "groupid = " + gorupIDList.get(i), null);
//            }
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public void deleteAllGroupMessageLogs() {
//        try {
//            writeableDatabase.execSQL("delete from " + GROUP_MESSAGE_TABLE);
//
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteGroupWithAllMessages(String groupID, long time) {
//        try {
//            writeableDatabase.delete(GROUP_MESSAGE_TABLE, "groupid = '" + groupID
//                    + "' and date =" + time, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteGroupWithAllMessages(String groupID, String callid) {
//        try {
//            writeableDatabase.delete(GROUP_MESSAGE_TABLE, /*"groupid = '" + groupID + "' and "+*/KEY_CALLER_ID + " = '" + callid + "'", null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getMostRecentSmsOrIms() {
//        Cursor cursor = null;
//        String query = "SELECT _id, number, max(received) as date, messagecontent, SUM(notification) as unread_count, display_time FROM messages group by number HAVING received = MAX(received) ORDER BY date desc";
//        try {
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        return cursor;
//    }


//    public Cursor getSmsAndImsByContact(String number) {
//        Cursor cursor = null;
//        String query;
//        try {
//            if (context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                query = "SELECT _id , callerid, ocid, qcid, quote_from_user, quote_preview_content, quote_file_path, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, editcount, is_emo_only, display_time, long_message, burn_timer_in_sec FROM messages "
//                        + "where number ='" + number + "'  AND(groupid is null or groupid = '') and  ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 ) and   " + KEY_IS_DECRYPTED + "=1 ORDER BY date";
//            } else {
//                query = "SELECT _id , callerid, ocid, qcid, quote_from_user, quote_preview_content, quote_file_path, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, editcount, is_emo_only, display_time, long_message, burn_timer_in_sec FROM messages "
//                        + "where number ='" + number + "' AND (groupid is null or groupid = '')  AND ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 )   and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " and " + KEY_IS_DECRYPTED + "=1 ORDER BY date";
//            }
//
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        if (cursor != null && cursor.moveToFirst()) {
//            context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Context.MODE_PRIVATE).edit().putLong(HistoryFetchingConstants.USER_HISTORY_OLDEST_TIMESTAMP, cursor.getLong(cursor
//                    .getColumnIndex(DatabaseConstants.KEY_TIME))).commit();
//        }
//        return cursor;
//    }

//    public Cursor getImsWithMediaByContact(String number) {
//        Cursor cursor = null;
//        String query;
//        try {
//            query = "SELECT _id , callerid, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
//                    + "where number ='" + number + "' and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' or mime_type ='Document' or" +
//                    " mime_type ='Link' ) and " + KEY_MESSAGE_DELIVERY_STATUS + " <> " + MessageEntry.DeliveryStatus.FAILED + " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received";
//
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        return cursor;
//    }


//    public Cursor getImsWithMediaByNumberForDetail(String number) {
//        Cursor cursor = null;
//        String query;
//        try {
//
//            query = "SELECT _id , callerid, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
//                    + "where number ='" + number + "' and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' ) and " +
//                    KEY_MESSAGE_DELIVERY_STATUS + " != " + MessageEntry.DeliveryStatus.FAILED + " ORDER BY received";
//
//
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        return cursor;
//    }

//    public Cursor getImsWithMediaByGroup(String number) {
//        Cursor cursor = null;
//        String query;
//        try {
//
//            query = "SELECT _id , callerid, groupid, mime_type, received, date, messagecontent as content, " +
//                    "messagetype as type, deliverystatus, filepath, display_time FROM messages "
//                    + "where groupid ='" + number + "' and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' or mime_type ='Document' or" +
//                    " mime_type ='Link' ) and " + KEY_MESSAGE_DELIVERY_STATUS + " <> " + MessageEntry.DeliveryStatus.FAILED + " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received";
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        return cursor;
//    }

//    public String getCountOfImsWithMediaByGroup(String number) {
//        Cursor cursor = null;
//        String query;
//        long result = 0;
//        try {
//
//            query = "SELECT  COUNT(*) FROM messages "
//                    + "where groupid ='" + number + "' and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' or mime_type ='Document' or" +
//                    " mime_type ='Link' )   and " + KEY_MESSAGE_DELIVERY_STATUS + " <> " + MessageEntry.DeliveryStatus.FAILED + " and  messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received";
//
//            result = DatabaseUtils.longForQuery(readableDatabase, query, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        return String.valueOf(result);
//    }

//    public String getCountOfImsWithMediaByContact(String number) {
//        Cursor cursor = null;
//        String query;
//        long result = 0;
//        try {
//
//            query = "SELECT  COUNT(*) FROM messages "
//                    + "where number ='" + number + "' and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' or mime_type ='Document' or" +
//                    " mime_type ='Link' )   and ( " + KEY_MESSAGE_DELIVERY_STATUS + " = " + MessageEntry.DeliveryStatus.SUCCESSFUL + " or " +
//                    MessageEntry.DeliveryStatus.SEEN + ") and " + "messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received";
//
//            Log.d("Abhi", "Media count Query: " + query);
//            result = DatabaseUtils.longForQuery(readableDatabase, query, null);
//            Log.d("Abhi", "Media count: " + result);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        return String.valueOf(result);
//    }

//    public Cursor getSmsAndImsByContact(String number, String queryText) {
//        Cursor cursor = null;
//        String query;
//        try {
//            if (context.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME, Activity.MODE_PRIVATE).getBoolean(Constants.INTEGRATE_WITH_SMS, Constants.INTEGRATE_WITH_SMS_B_DEF)) {
//                query = "SELECT _id , callerid, number, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
//                        + "where number ='" + number + "'and messagecontent like %" + queryText + "%" + " ORDER BY received";
//            } else {
//                query = "SELECT _id , callerid, number, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
//                        + "where number ='" + number + "'and messagecontent like '%" + queryText + "%'" + " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received";
//            }
//            Log.d("DatabaseConstants", "getSmsAndImsByContact: " + query);
//            cursor = readableDatabase.rawQuery(query, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.d("DatabaseConstants", e.getMessage());
//        }
//        return cursor;
//    }

//    public long insertRechargeEntry(RechargeEntry entry) {
//        long id = -1;
//        try {
//            ContentValues values = new ContentValues();
//
//            values.put(KEY_AMOUNT, entry.rechargeAmount);
//            values.put(KEY_CURRENCY_CODE, entry.currencyCode);
//            values.put(KEY_TRANSACTION_ID, entry.transactionId);
//            values.put(KEY_PAYMENT_METHOD, entry.paymentMethod);
//            values.put(KEY_STATUS, entry.rechargeStatus);
//            if (entry.refundText != null) {
//                values.put(KEY_REFUND_TEXT, entry.refundText);
//            }
//            id = writeableDatabase.insert(RECHARGE_TABLE, null, values);
//            context.getContentResolver().notifyChange(
//                    RECHARGE_URI, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//
//
//        }
//        return id;
//    }


//    public void updateRechargeEntry(long entry_id, RechargeEntry entry) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_AMOUNT, entry.rechargeAmount);
//            values.put(KEY_CURRENCY_CODE, entry.currencyCode);
//            values.put(KEY_TRANSACTION_ID, entry.transactionId);
//            values.put(KEY_PAYMENT_METHOD, entry.paymentMethod);
//            values.put(KEY_STATUS, entry.rechargeStatus);
//            if (entry.refundText != null) {
//                values.put(KEY_REFUND_TEXT, entry.refundText);
//            }
//
//            writeableDatabase.update(RECHARGE_TABLE, values, KEY_ID + "=" + entry_id, null);
//            context.getContentResolver().notifyChange(
//                    RECHARGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getIncompleteRechargeRequests() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(RECHARGE_TABLE, new String[]{
//                    KEY_ID, KEY_AMOUNT, KEY_CURRENCY_CODE, KEY_TRANSACTION_ID, KEY_PAYMENT_METHOD, KEY_STATUS}, "status="
//                    + RechargeEntry.RechargeStatus.PAYMENT_SUCCESSFUL, null, null, null, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return cursor;
//    }

//    public static String removePrefixes(String number) {
//        if (number == null) {
//            return "";
//        }
//
//        String num = number;
//        if (num.startsWith("+")) {
//            num = num.substring(1);
//        } else if (num.startsWith("00")) {
//            num = num.substring(2);
//        } else if (num.startsWith("011")) {
//            num = num.substring(3);
//        } else if (num.startsWith("0")) {
//            num = num.substring(1);
//        }
//        return num;
//    }

//    public void createFileMessageLog(MessageEntry messageEntry) {
//        if (checkForMessage(messageEntry)) {
//            return;
//        }
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, messageEntry.number);
//            values.put(KEY_TIME, messageEntry.time);
//            values.put(KEY_NOTIFICATION, messageEntry.status);
//            values.put(KEY_MESSAGE_CONTENT, messageEntry.content);
//            values.put(KEY_MESSAGE_TYPE, messageEntry.type);
//            values.put(KEY_MESSAGE_CALL_ID, messageEntry.callerId);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, messageEntry.delivery_status);
//            values.put(KEY_RECV_TIME, messageEntry.time);
//            values.put(KEY_MESSAGE_DISPLAY_TIME, (messageEntry.time - UserDataManager.getTimeAdjustment()));
//
//            if (messageEntry.filePath != null) {
//                values.put(KEY_FILE_PATH, messageEntry.filePath);
//            }
//            Log.d("File Log inserted", "" + writeableDatabase.replace(MESSAGE_TABLE, null, values));
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateFileDeliveryStatus(String number, String callerID, int status, String message) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, status);
//            values.put(KEY_MESSAGE_CONTENT, message);
//            writeableDatabase.update(MESSAGE_TABLE, values, KEY_NUMBER + "='" + number + "' and " + KEY_CALLER_ID + " = '" + callerID + "'", null);
//            Log.d("File Log updated", "Number: " + number + " CallerID: " + callerID + " status: " + status);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateFileDeliveryStatus(String callerID, int status, String message) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, status);
//            values.put(KEY_MESSAGE_CONTENT, message);
//            writeableDatabase.update(MESSAGE_TABLE, values, KEY_CALLER_ID + " = '" + callerID + "'", null);
//            Log.d("File Log updated", "CallerID: " + callerID + " status: " + status);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteFailedFileWhileReceiving(String number, String callerID) {
//        try {
//            writeableDatabase.delete(MESSAGE_TABLE, KEY_NUMBER + "='" + number + "' and " + KEY_CALLER_ID + " = '" + callerID + "'", null);
//            Log.d("DatabaseConstants", "Deleted file entry for failed file for callid:" + callerID);
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void deleteFailedFileWhileReceiving() {
//        try {
//            writeableDatabase.delete(MESSAGE_TABLE, KEY_FILE_PATH + " not null and " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.FAILED + " and " + KEY_MESSAGE_TYPE + " = " + MessageEntry.MessageType.RECEIVED, null);
//            Log.d("DatabaseConstants", "all failed files while receiving");
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void reloadFilesTable() {
//        try {
//            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getAppSubsciber() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase
//                    .rawQuery(
//                            "SELECT _id, number, name, lookup_key,  presencestate, presencenote, subscriberimagehash from subscriber where lookup_key <> 'NULL' AND number <> '' group by lookup_key ORDER BY presencestate ASC, name  COLLATE NOCASE",
//                            null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.getCount();
//            }
//        }
//        return cursor;
//    }

//    public Cursor getUnseenMessageCallIDs(String number) {
//        Cursor cursor = null;
//        try {
////            cursor = readableDatabase.rawQuery("SELECT * from " + MESSAGE_TABLE + " WHERE " + KEY_NUMBER + " = '" + number + "' AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + SignallingMessageEntry.DeliveryStatus.SUCCESSFUL
////                    + " AND " + KEY_MESSAGE_TYPE + "=" + SignallingMessageEntry.MessageType.RECEIVED + " AND (" + KEY_FILE_PATH + " is null OR " + KEY_FILE_PATH + " = '')", null);
//            cursor = readableDatabase.rawQuery("SELECT * from " + MESSAGE_TABLE + " WHERE " + KEY_NUMBER + " = '" + number + "'  and  ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 )   AND  is_decrypted = 1 AND is_im_ready_for_view = 1  AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.SUCCESSFUL
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }
//
//    public Cursor getUnseenGroupMessageCallIDs(String groupID) {
//        Cursor cursor = null;
//        try {
////            cursor = readableDatabase.rawQuery("SELECT * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_GROUP_ID + " = '" + groupID + "' AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + SignallingMessageEntry.DeliveryStatus.SUCCESSFUL
////                    + " AND " + KEY_MESSAGE_TYPE + "=" + SignallingMessageEntry.MessageType.RECEIVED + " AND (" + KEY_FILE_PATH + " is null OR " + KEY_FILE_PATH + " = '')", null);
//            cursor = readableDatabase.rawQuery("SELECT * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_GROUP_ID + " = '" + groupID + "'  and  ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 )   AND  is_decrypted = 1 AND is_im_ready_for_view = 1 AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.SUCCESSFUL
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getUnDecyptedGroupMessageCallIDs(String groupID) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_GROUP_ID + " = '" + groupID + "' AND " + KEY_IS_DECRYPTED + "=" + 0 + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getUnDecyptedMessageCallIDs(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + MESSAGE_TABLE + " WHERE " + KEY_NUMBER + " = '" + number + "' AND " + KEY_IS_DECRYPTED + "=" + 0 + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public void updateMessageSeenStatus(String callID, int status) {
//        Log.v("mLatitude", "updateMessageSeenStatus");
//        try {
//            ContentValues values = new ContentValues();
//
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, status);
//            values.put(KEY_SEEN_TIME, System.currentTimeMillis());
//
//            int num = writeableDatabase.update(MESSAGE_TABLE, values, KEY_CALLER_ID + " = ?", new String[]{callID});
//            if (num > 0) {
//                context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            }
//            Log.v("DatabaseConstants", "updateMessageSeenStatus: " + callID + " has been updated to seen");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateGroupMessageSeenStatus(String callID, int status) {
//        Log.v("mLatitude", "updateGroupMessageSeenStatus");
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, status);
//            values.put(KEY_SEEN_TIME, System.currentTimeMillis());
//
//            int num = writeableDatabase.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + " = ?", new String[]{callID});
//            if (num > 0) {
//                context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            }
//            Log.v("DatabaseConstants", "updateGroupMessageSeenStatus: " + callID + " has been updated to seen");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void updateGroupMessageContent(String callerId, String messageContent, int isDecrypted) {
//        Log.v("DatabaseConstants", "updateGroupMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_IS_DECRYPTED, isDecrypted);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void updateGroupMessageContent(String callerId, String messageContent, int isDecrypted, String filePath, String mimeType,
//                                          short deliveryStatus) {
//        Log.v("DatabaseConstants", "updateGroupMessageContent for message with file info");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_IS_DECRYPTED, isDecrypted);
//            values.put(KEY_FILE_PATH, filePath);
//            values.put(KEY_MIME_TYPE, mimeType);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, deliveryStatus);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void updateGroupMessageContent(String callerId, String messageContent, int isDecrypted, String filePath, String mimeType,
//                                          short deliveryStatus, String long_message, int isReadyforView) {
//        Log.v("DatabaseConstants", "updateGroupMessageContent for message with file info");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_IS_DECRYPTED, isDecrypted);
//            values.put(KEY_FILE_PATH, filePath);
//            values.put(KEY_MIME_TYPE, mimeType);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, deliveryStatus);
//            values.put(KEY_IS_IM_READY_FOR_VIEW, isReadyforView);
//            values.put(KEY_LONG_MESSAGE, long_message);
//
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void updateMessageContent(String callerId, String messageContent, int isDecrypted) {
//        Log.v("DatabaseConstants", "updateMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_IS_DECRYPTED, isDecrypted);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void updateMessageContent(String callerId, String messageContent, int isDecrypted, String filePath, String mimeType,
//                                     short deliveryStatus) {
//        Log.v("DatabaseConstants", "updateMessageContent for message with file info");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_IS_DECRYPTED, isDecrypted);
//            values.put(KEY_FILE_PATH, filePath);
//            values.put(KEY_MIME_TYPE, mimeType);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, deliveryStatus);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public MessageEntry getMessageByCallID(String callID) {
//        try {
//            Cursor cursor = readableDatabase.query(MESSAGE_TABLE, null, KEY_CALLER_ID + " = ?", new String[]{callID}, null, null, null);
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                MessageEntry me = new MessageEntry();
//                me.callerId = callID;
//                me.delivery_status = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_DELIVERY_STATUS));
//                me.type = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_TYPE));
//                me.content = cursor.getString(cursor.getColumnIndex(KEY_MESSAGE_CONTENT));
//                me.time = cursor.getLong(cursor.getColumnIndex(KEY_TIME));
//                cursor.close();
//                return me;
//            }
//            cursor = readableDatabase.query(GROUP_MESSAGE_TABLE, null, KEY_CALLER_ID + " = ?", new String[]{callID}, null, null, null);
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                MessageEntry me = new MessageEntry();
//                me.callerId = callID;
//                me.delivery_status = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_DELIVERY_STATUS));
//                me.type = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_TYPE));
//                me.content = cursor.getString(cursor.getColumnIndex(KEY_MESSAGE_CONTENT));
//                me.time = cursor.getLong(cursor.getColumnIndex(KEY_TIME));
//                cursor.close();
//                return me;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

//    public ArrayList<MessageEntry> getNoReplyMessages() {
//        ArrayList<MessageEntry> messages = new ArrayList<>();
//        try {
//            Cursor cursor = readableDatabase.query(MESSAGE_TABLE, null, KEY_MESSAGE_TYPE + " = ? and " + KEY_MESSAGE_DELIVERY_STATUS + " = ?",
//                    new String[]{"" + MessageEntry.MessageType.SEND, "" + MessageEntry.DeliveryStatus.NO_REPLY}, null, null, null);
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                do {
//                    MessageEntry me = new MessageEntry();
//                    me.callerId = cursor.getString(cursor.getColumnIndex(KEY_CALLER_ID));
//                    me.delivery_status = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_DELIVERY_STATUS));
//                    me.type = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_TYPE));
//                    me.content = cursor.getString(cursor.getColumnIndex(KEY_MESSAGE_CONTENT));
//                    me.time = cursor.getLong(cursor.getColumnIndex(KEY_TIME));
//                    me.number = cursor.getString(cursor.getColumnIndex(KEY_NUMBER));
//                    me.editCount = cursor.getInt(cursor.getColumnIndex(KEY_EDIT_COUNT));
//                    me.isGroup = false;
//                    messages.add(me);
//                } while (cursor.moveToNext());
//                cursor.close();
//            }
//            cursor = readableDatabase.query(GROUP_MESSAGE_TABLE, null, KEY_MESSAGE_TYPE + " = ? and " + KEY_MESSAGE_DELIVERY_STATUS + " = ?",
//                    new String[]{"" + MessageEntry.MessageType.SEND, "" + MessageEntry.DeliveryStatus.NO_REPLY}, null, null, null);
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                do {
//                    MessageEntry me = new MessageEntry();
//                    me.callerId = cursor.getString(cursor.getColumnIndex(KEY_CALLER_ID));
//                    me.delivery_status = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_DELIVERY_STATUS));
//                    me.type = cursor.getShort(cursor.getColumnIndex(KEY_MESSAGE_TYPE));
//                    me.content = cursor.getString(cursor.getColumnIndex(KEY_MESSAGE_CONTENT));
//                    me.time = cursor.getLong(cursor.getColumnIndex(KEY_TIME));
//                    me.number = cursor.getString(cursor.getColumnIndex(KEY_NUMBER));
//                    me.editCount = cursor.getInt(cursor.getColumnIndex(KEY_EDIT_COUNT));
//                    me.groupId = cursor.getString(cursor.getColumnIndex(KEY_GROUP_ID));
//                    me.isGroup = true;
//                    messages.add(me);
//                } while (cursor.moveToNext());
//                cursor.close();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return messages;
//    }

//    synchronized public int reloadContactTable(Cursor cursor) {
//
//        int n = 0;
//        String username = UserDataManager.getUserName();
//        int countryCode = UserDataManager.getUserCountryCode();
//        long my_last_sync_time=UserDataManager.getLastContactSyncTime();
//        System.out.println("Contact Update Time : Last Sync Time : "+my_last_sync_time);
//        try {
//            long st = System.currentTimeMillis();
//            writeableDatabase.beginTransaction();
//
//            writeableDatabase.execSQL("initialize table if not exists " + DatabaseConstants.CONTACTS_TABLE_TEMP + "(" +
//                    "_id integer primary key autoincrement, " +
//                    "number text not null, " +
//                    "name text, " +
//                    "lookup_key text not null, " +
//                    "contact_id text not null, " +
//                    "photo_uri text default null, " +
//                    "processed_number text , " +
//                    "is_favourite integer)");
//
//            String sql = "INSERT INTO " + CONTACTS_TABLE_TEMP + " (number, name, lookup_key, contact_id, photo_uri, is_favourite, processed_number) VALUES (?, ?, ?, ?, ?, ?, ?)";
//
//            SQLiteStatement stmt = writeableDatabase.compileStatement(sql);
//
//
//            if (cursor != null && cursor.moveToFirst()) {
//                do {
//                    try {
//                        String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
//                        String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
//                        String lookup_key = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY));
//                        String contact_id = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
//                        int is_favourite = cursor.getInt(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED));
//
//                        Uri photoUri = null;
//                        if (android.os.Build.VERSION.SDK_INT > 10) {
//                            String photoPath = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI));
//                            if (photoPath != null) {
//                                photoUri = Uri.parse(photoPath);
//                            }
//                        } else {
//                            String photoID = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_ID));
//                            if (photoID != null) {
//                                photoUri = ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, Long.parseLong(photoID));
//                            }
//                        }
//
//                        if(android.os.Build.VERSION.SDK_INT > 18){
//                            long update_time=
//                                    cursor.getLong(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_LAST_UPDATED_TIMESTAMP));
//                            System.out.println("Contact Update Time Name="+name+" update time:"+update_time+
//                                    " my_sync:"+my_last_sync_time+" update_needed:"+(update_time>my_last_sync_time));
//                        }
//
//
//                        stmt.bindString(1, number);
//                        stmt.bindString(2, name);
//                        stmt.bindString(3, lookup_key);
//                        stmt.bindString(4, contact_id);
//                        if (photoUri == null) {
//                            stmt.bindString(5, "");
//                        } else {
//                            stmt.bindString(5, photoUri.toString());
//                        }
//                        stmt.bindLong(6, is_favourite);
//                        if (username.length() > 0) {
//                            stmt.bindString(7, Util.translateNumber(number, countryCode));
//                        } else {
//                            stmt.bindString(7, number.replaceAll("\\D", ""));
//                        }
//
//                        stmt.execute();
//                        stmt.clearBindings();
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                    if (n % 250 == 0) {
//                        writeableDatabase.yieldIfContendedSafely();
//                    }
//                    n++;
//                } while (cursor.moveToNext());
//
//                try {
//                    writeableDatabase.execSQL("ALTER TABLE " + CONTACTS_TABLE + " RENAME TO "
//                            + CONTACTS_TABLE_TEMP + "_t;");
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                try {
//                    writeableDatabase.execSQL("ALTER TABLE " + CONTACTS_TABLE_TEMP + " RENAME TO "
//                            + CONTACTS_TABLE + ";");
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                try {
//                    writeableDatabase.execSQL("DROP TABLE " + CONTACTS_TABLE_TEMP + "_t;");
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//
//            stmt.close();
//            Gui.get().run(()->UserDataManager.setLastContactSyncTime(System.currentTimeMillis()));
//            System.out.println("Contact Update Time : Synced Time:"+System.currentTimeMillis());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                writeableDatabase.setTransactionSuccessful();
//                writeableDatabase.endTransaction();
//                Intent intent = new Intent(context, CommonDataLoaderService.class);
//                intent.putExtra(Constants.RELOAD_CONTACT_DATA, true);
//                context.startService(intent);
//                context.getContentResolver().notifyChange(CONTACTS_URI, null);
//                context.getContentResolver().notifyChange(CALL_LOG_URI, null);
//                context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//                context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//
//                if (cursor != null) {
//                    cursor.close();
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//
//        return n;
//    }


//    public Cursor getPhotoUriByPhoneNo(ArrayList<String> allPhoneNo) {
//        StringBuilder sb = new StringBuilder();
//        sb.append(" IN (");
//        for (String phoneNo : allPhoneNo) {
//            sb.append("'");
//            sb.append(phoneNo);
//            sb.append("'");
//            sb.append(",");
//        }
//        sb.deleteCharAt(sb.length() - 1);
//        sb.append(") ");
//        String inClause = sb.toString();
//        String rawQuery = "SELECT " + KEY_PROCESSED_NUMBER + ", " + KEY_PHOTO_URI + " FROM " + CONTACTS_TABLE + " WHERE " + KEY_PROCESSED_NUMBER + inClause;
//        Cursor cursor = readableDatabase.rawQuery(rawQuery, null);
//        if (cursor.moveToFirst()) {
//            return cursor;
//        }
//        return null;
//    }

//    public Cursor getRates() {
//        String rawQuery = "select* from rate_table order by country";
//        Cursor cursor = null;
//        cursor = readableDatabase.rawQuery(rawQuery, null);
//        return cursor;
//
//    }

//    public void insertRate(String country, String operator, String rate) {
//        try {
//            ContentValues cv = new ContentValues();
//            cv.put(KEY_COUNTRY, country);
//            cv.put(KEY_OPERATOR, operator);
//            cv.put(KEY_CALL_RATE, rate);
//            long id = writeableDatabase.insert(CALL_RATE_TABLE, null, cv);
//            context.getContentResolver().notifyChange(RATE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteRate() {
//        try {
//            String rawQuery = "delete from rate_table";
//            writeableDatabase.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public Cursor getAllPhoneNoOfAllGroupsById(ArrayList<String> allGroupId) {
//        StringBuilder sb = new StringBuilder();
//        sb.append("IN (");
//        for (String groupId : allGroupId) {
//            sb.append("'");
//            sb.append(groupId);
//            sb.append("'");
//            sb.append(",");
//        }
//        sb.deleteCharAt(sb.length() - 1);
//        sb.append(")");
//        String inClause = sb.toString();
//        String rawQuery = "SELECT groupid,number FROM group_table where groupid " + inClause;
//        Cursor cursor = readableDatabase.rawQuery(rawQuery, null);
//        if (cursor.moveToFirst()) {
//            return cursor;
//        }
//        return null;
//    }

//    public String getContactNameByNumber(String phoneNo) {
//        String rawQuery = "SELECT name FROM " + DatabaseConstants.CONTACTS_TABLE + " where processed_number = '" + phoneNo + "'";
//        Cursor cursor = readableDatabase.rawQuery(rawQuery, null);
//        if (cursor.moveToFirst()) {
//            return cursor.getString(cursor.getColumnIndex("name"));
//        }
//        return null;
//    }

//    public Cursor getContactsByPhoneNumbers(String[] allPhoneNo) {
//        StringBuilder inClauseBuilder = new StringBuilder();
//        inClauseBuilder.append(" IN (");
//        for (int i = 0; i < allPhoneNo.length; i++) {
//            if (!allPhoneNo[i].equals(UserDataManager.getUserName())) {
//                inClauseBuilder.append("'");
//                inClauseBuilder.append(allPhoneNo[i]);
//                inClauseBuilder.append("'");
//                inClauseBuilder.append(",");
//            }
//        }
//        inClauseBuilder.deleteCharAt(inClauseBuilder.length() - 1);
//        inClauseBuilder.append(" )");
//        String inClause = inClauseBuilder.toString();
//        String rawQuery = "SELECT * FROM " + DatabaseConstants.CONTACTS_TABLE + " WHERE processed_number " + inClause + " GROUP BY processed_number ORDER BY name COLLATE LOCALIZED ASC";
//        Cursor cursor = readableDatabase.rawQuery(rawQuery, null);
//        if (cursor.moveToFirst()) {
//            return cursor;
//        }
//        return null;
//    }

//    public Cursor getAllContacts(String searchText) {
//        Cursor cursor;
//        String sort = " ORDER BY " + CONTACTS_TABLE + "." + KEY_NAME + " COLLATE LOCALIZED ASC";
//        String search = " name like '%" + searchText + "%' OR processed_number like '%" + searchText + "%' ";
//        String groupBy = " group by contact_id ";
//        cursor = readableDatabase.rawQuery("SELECT * FROM " + CONTACTS_TABLE + " where" + search + sort, null);
//        if (cursor.moveToFirst()) {
//            return cursor;
//        }
//        return null;
//    }

//    public long getGroupCreationDate(String groupId) {
//        try {
//            Cursor cursor = readableDatabase.rawQuery("SELECT " + KEY_TIME + " FROM " + GROUP_MESSAGE_TABLE
//                    + " WHERE " + KEY_GROUP_ID + "='" + groupId + "' AND " + KEY_MESSAGE_TYPE + " = 2 ORDER BY " + KEY_TIME + " DESC LIMIT 1", null);
//            if (cursor.moveToFirst() && cursor.getCount() > 0) {
//                long date = cursor.getLong(cursor.getColumnIndex(KEY_TIME));
//                cursor.close();
//                return date;
//            }
//            cursor.close();
//            return -1;
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return -1;
//    }

//    public String getSubscribedPackageNameByID(String id) {
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.query(SUBSCRIBED_PACKAGES_TABLE, new String[]{KEY_ID,
//                            "package_id", "package_name", "package_value",
//                            "package_activation_time", "package_deactivation_time", "group_id", "thumbnail",
//                            "valid_till", "subtitle", "unused_balance", "available_minutes"}, "package_id=?",
//                    new String[]{id}, null, null, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//        }
//        String packageName = "";
//
//        if (cursor != null && cursor.moveToFirst()) {
//            packageName = cursor.getString(cursor.getColumnIndex("package_name"));
//            cursor.close();
//        }
//        return packageName;
//    }

//    public void deleteAllTableRecords() {
//        try {
//            dOpenHelper.deleteAllTableRecords(dOpenHelper.getReadableDatabase());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getSubscriberInfo() {
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT  number,  lookup_key from subscriber group by number order by lookup_key", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        if (cursor != null && cursor.moveToFirst()) {
//            return cursor;
//        }
//        return cursor;
//    }

//    public Cursor searchFavoriteContacts(String searchText) {
//        Cursor cursor;
//        String sort = " ORDER BY " + CONTACTS_TABLE + "." + KEY_NAME + " COLLATE LOCALIZED ASC";
//        String search = " (name like '%" + searchText + "%' OR processed_number like '%" + searchText + "%' )";
//        String groupBy = " group by contact_id ";
//        cursor = readableDatabase.rawQuery("SELECT * FROM " + CONTACTS_TABLE + " where is_favourite=1 AND " + search + groupBy + sort, null);
//        if (cursor != null && cursor.moveToFirst()) {
//            return cursor;
//        }
//        return null;
//    }

//    public boolean shouldShowRateAppDialog() {
//        boolean show = false;
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery("SELECT count(*) as cnt from log where duration > 45000 and type = 0", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        if (cursor != null && cursor.moveToFirst()) {
//            int cnt = cursor.getInt(cursor.getColumnIndex("cnt"));
//            if (cnt >= 5) {
//                show = true;
//            }
//            cursor.close();
//        }
//        return show;
//    }

//    public DataBaseOpenHelper getDatabaseOpenHelper() {
//        return dOpenHelper;
//    }

//    public E2EPublicKeySeedAndPrivateKeyHolder getE2EPublicKeySeedAndPrivateKeyHolderForBuddy(String buddy) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        E2EPublicKeySeedAndPrivateKeyHolder mE2EPublicKeySeedAndPrivateKeyHolder = new E2EPublicKeySeedAndPrivateKeyHolder();
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(SUBSCRIBER_TABLE, null, KEY_NUMBER + "='" + buddy + "' AND " + KEY_BUDDY_PUBLIC_KEY + " != '' AND " + KEY_BUDDY_SEED + " != ''", null, null, null, null);
//            if (cursor != null && cursor.moveToFirst()) {
//                mE2EPublicKeySeedAndPrivateKeyHolder.publicKey = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_BUDDY_PUBLIC_KEY));
//                mE2EPublicKeySeedAndPrivateKeyHolder.seed = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_BUDDY_SEED));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return mE2EPublicKeySeedAndPrivateKeyHolder;
//    }

//    public boolean isE2EPublicKeyAndSeedAvailableForBuddy(String buddy) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(SUBSCRIBER_TABLE, null, KEY_NUMBER + "='" + buddy + "' AND " + KEY_BUDDY_PUBLIC_KEY + " != '' AND " + KEY_BUDDY_SEED + " != ''", null, null, null, null);
//            if (cursor != null && cursor.getCount() > 0) {
//                return true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return false;
//    }

//    public void updateE2EPublicKeyAndSeedForBuddy(String buddy, String publicKey, String seed) {
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_BUDDY_PUBLIC_KEY, publicKey);
//            values.put(KEY_BUDDY_SEED, seed);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(SUBSCRIBER_TABLE, values, KEY_NUMBER + "='" + buddy + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public boolean isE2EPublicKeySeedAndPrivateKeyAvailableForGroup(String groupId) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(GROUP_TABLE, null, KEY_GROUP_ID + "='" + groupId + "' AND " + KEY_BUDDY_PUBLIC_KEY + " != '' AND " + KEY_BUDDY_SEED + " != '' AND " + KEY_GROUP_PRIVATE_KEY + " != ''", null, null, null, null);
//            if (cursor != null && cursor.getCount() > 0) {
//                return true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return false;
//    }

//    public void updateE2EPublicKeySeedAndPrivateKeyForGroup(String groupId, String publicKey, String seed, String groupPrivateKey) {
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_BUDDY_PUBLIC_KEY, publicKey);
//            values.put(KEY_BUDDY_SEED, seed);
//            values.put(KEY_GROUP_PRIVATE_KEY, groupPrivateKey);
//            values.put(KEY_IS_ENCRYPTED_GROUP, 1);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_TABLE, values, KEY_GROUP_ID + "='" + groupId + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public E2EPublicKeySeedAndPrivateKeyHolder getE2EPublicKeySeedAndPrivateKeyHolderForGroup(String groupId) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        E2EPublicKeySeedAndPrivateKeyHolder mE2EPublicKeySeedAndPrivateKeyHolder = new E2EPublicKeySeedAndPrivateKeyHolder();
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(GROUP_TABLE, null, KEY_GROUP_ID + "='" + groupId + "' AND " + KEY_BUDDY_PUBLIC_KEY
//                    + " != '' AND " + KEY_BUDDY_SEED + " != '' AND " + KEY_GROUP_PRIVATE_KEY + " != ''", null, null, null, null);
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                mE2EPublicKeySeedAndPrivateKeyHolder.publicKey = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_BUDDY_PUBLIC_KEY));
//                mE2EPublicKeySeedAndPrivateKeyHolder.seed = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_BUDDY_SEED));
//                mE2EPublicKeySeedAndPrivateKeyHolder.privateKey = cursor.getString(cursor.getColumnIndex(DatabaseConstants.KEY_GROUP_PRIVATE_KEY));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return mE2EPublicKeySeedAndPrivateKeyHolder;
//    }

//    public int getGroupE2EValue(String groupId) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(GROUP_TABLE, null, KEY_GROUP_ID + "='" + groupId + "'", null, null, null, null);
//            if (cursor != null && cursor.getCount() == 1 && cursor.moveToFirst()) {
//                return cursor.getInt(cursor.getColumnIndex(DatabaseConstants.KEY_IS_ENCRYPTED_GROUP));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return 0;
//    }

//    public void createMultiPartMessageEntry(MultipartMessage multiPartMessage) {
//        try {
//            MultiPartMessage mpm = MultiPartMessage.newBuilder()
//                    .callerId(multiPartMessage.getCallerID())
//                    .callerIdLocal(multiPartMessage.getCallerIDLocal())
//                    .number(multiPartMessage.getNumber())
//                    .date(new Date(multiPartMessage.getDate()))
//                    .groupId(multiPartMessage.getGroupID())
//                    .multipartNumber(multiPartMessage.getMultipartNumber())
//                    .messageContent(multiPartMessage.getContent())
//                    .totalParts(multiPartMessage.getTotalParts())
//                    .isDecrypted(multiPartMessage.getIsDeCrypted() == 1)
//                    .isOutgoing(multiPartMessage.getIsOutgoing() == 1)
//                    .build();
//            Executor.ex(() -> SDKDatabase.get().multiPartMessageDao().insert(mpm));
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
//    }

//    public void updateMultipartMessageContentToDecrypted(String CallerID, String content) {
//        Log.v("DatabaseConstants", "updateGroupMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put("is_decrypted", 1);
//            values.put("messagecontent", content);
//            db = dOpenHelper.getWritableDatabase();
//            db.update("multipartmessages", values, "callerid" + "=?",
//                    new String[]{CallerID});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void deleteMultiPartMessage(String callIDLocal, int multipartIndex) {
//        try {
//            writeableDatabase.delete("multipartmessages", "calleridlocal = '" + callIDLocal
//                    + "' and multipart_number >="
//                    + multipartIndex, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void deleteMultiPartMessage(String callIDLocal) {
//        try {
//            writeableDatabase.delete("multipartmessages", "calleridlocal = '" + callIDLocal
//                    + "' ", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public String getlocalCallIDFromTimeStamp(long time) {
//
//        String rawQuery = "SELECT calleridlocal FROM multipartmessages" + " where date = " + time + " LIMIT 1";
//        Cursor cursor = null;
//        try {
//            cursor = readableDatabase.rawQuery(rawQuery, null);
//            if (cursor.moveToFirst()) {
//                return cursor.getString(cursor.getColumnIndex("calleridlocal"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return null;
//    }

//    public HashSet<Integer> getReceivedMultiPartMessageRecvCount(long timestamp) {
//        HashSet<Integer> parts = new HashSet<>();
//        try {
//            String rawQuery = "SELECT multipart_number FROM multipartmessages " + " where date = " + timestamp;
//            Cursor cursor = readableDatabase.rawQuery(rawQuery, null);
//            if (cursor != null && cursor.moveToFirst()) {
//                do {
//                    parts.add(cursor.getInt(cursor.getColumnIndex("multipart_number")));
//                } while (cursor.moveToNext());
//                cursor.close();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return parts;
//    }

//    public void updateGroupMessageFilePath(String callerId, String filePath) {
//        Log.v("DatabaseConstants", "updateGroup message file path:" + "CallerId: " + callerId + " FilePath" + filePath);
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_FILE_PATH, filePath);
//            values.put(KEY_LONG_MESSAGE, "");
//
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public String getMessageFilePath(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = dOpenHelper.getReadableDatabase().query(MESSAGE_TABLE, new String[]{KEY_FILE_PATH},
//                    KEY_CALLER_ID + "= ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getString(0);
//            } else {
//                return null;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public String getGroupMessageFilePath(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = dOpenHelper.getReadableDatabase().query(GROUP_MESSAGE_TABLE, new String[]{KEY_FILE_PATH},
//                    KEY_CALLER_ID + "= ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getString(0);
//            } else {
//                return null;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public void updateMessageFilePath(String callerId, String filePath) {
//        Log.v("DatabaseConstants", "updateMessageDeliveryStatus");
//        System.out.println("DatabaseConstants updateMessageDeliveryStatus: " + callerId);
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_FILE_PATH, filePath);
//            values.put(KEY_LONG_MESSAGE, "");
//
//
//            db = dOpenHelper.getWritableDatabase();
//            db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public Cursor getfailedLongIMGroupMessages(String groupId) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db
//                    .rawQuery("select * from "
//                            + GROUP_MESSAGE_TABLE + " where " + KEY_GROUP_ID
//                            + "='" + groupId + "' and    LENGTH(long_message) > 0 and  deliverystatus = 404  " + " order by " + KEY_TIME
//                            + " asc ", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
//        return cursor;
//    }

//    public Cursor getfailedLongIMMessages(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select * from "
//                            + MESSAGE_TABLE + " where " + KEY_NUMBER
//                            + "='" + number + "' and  LENGTH(long_message)>0   and deliverystatus=404  " + " order by " + KEY_TIME
//                            + " asc ", null);
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        } finally {
//        }
////        int count = cursor.getCount();
//        return cursor;
//    }

//    public String getMessageContent(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = dOpenHelper.getReadableDatabase().query(MESSAGE_TABLE, new String[]{KEY_MESSAGE_CONTENT},
//                    KEY_CALLER_ID + "= ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getString(0);
//            } else {
//                return null;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public String getGroupMessagecontent(String callID) {
//        Cursor cursor = null;
//        try {
//            cursor = dOpenHelper.getReadableDatabase().query(GROUP_MESSAGE_TABLE, new String[]{KEY_MESSAGE_CONTENT},
//                    KEY_CALLER_ID + "= ?", new String[]{callID}, null, null, null);
//
//            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
//                return cursor.getString(0);
//            } else {
//                return null;
//            }
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }

//    public void updateGroupMessageContent(String callerId, String messageContent, MimeType mimeType) {
//        Log.v("DatabaseConstants", "updateGroupMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_MIME_TYPE, mimeType.toString());
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void updateMessageContent(String callerId, String messageContent, MimeType mimeType) {
//        Log.v("DatabaseConstants", "updateMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_MIME_TYPE, mimeType.toString());
//            db = dOpenHelper.getWritableDatabase();
//            db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void deleteMessageByCallId(String callerId) {
//        SQLiteDatabase db = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            int x = db.delete(MESSAGE_TABLE, KEY_CALLER_ID + " = '" + callerId + "'", null);
//            if (x > 0)
//                context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////			if (db != null)
////				db.close();
//        }
//    }

//    public int getEditCountSingleMessage(String callID) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(MESSAGE_TABLE, new String[]{KEY_EDIT_COUNT}, KEY_MESSAGE_CALL_ID + "= ?", new String[]{callID}, null, null, null);
//            if (cursor != null && cursor.moveToFirst())
//                result = cursor.getInt(cursor
//                        .getColumnIndex(KEY_EDIT_COUNT));
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                cursor.close();
//        }
//        return result;
//    }
//
//    public int getEditCountGroupMessage(String callID) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(GROUP_MESSAGE_TABLE, new String[]{KEY_EDIT_COUNT}, KEY_MESSAGE_CALL_ID + "= ?", new String[]{callID}, null, null, null);
//            if (cursor != null && cursor.moveToFirst())
//                result = cursor.getInt(cursor
//                        .getColumnIndex(KEY_EDIT_COUNT));
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                cursor.close();
//        }
//        return result;
//    }

//    public boolean isLongMessage(String callID, boolean isGroup) {
//        Cursor cursor = null;
//        int n = 0;
//        try {
//            if (isGroup)
//                cursor = readableDatabase.rawQuery("SELECT long_message FROM messages where callerid = '" + callID + "' and length(long_message) > 0", null);
//            else
//                cursor = readableDatabase.rawQuery("SELECT long_message FROM messages where callerid = '" + callID + "' and length(long_message) > 0", null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                n = cursor.getCount();
//            }
//            cursor.moveToFirst();
//        }
//        return (n == 0) ? false : true;
//    }

//    public String getnumberFromGroupTablebyCallID(String callerID) {
//        Cursor cursor = null;
//        String number = "";
//        try {
//            cursor = readableDatabase.rawQuery("select number from messages where callerid='" + callerID + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                number = cursor.getString(cursor.getColumnIndex(KEY_NUMBER));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return number;
//    }

//    public long getTimeFromGroupTablebyCallID(String callerID) {
//        Cursor cursor = null;
//        long date = System.currentTimeMillis();
//        try {
//            cursor = readableDatabase.rawQuery("select date from messages where callerid='" + callerID + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                date = cursor.getInt(cursor.getColumnIndex(KEY_TIME));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        if (date < 0)
//            date = System.currentTimeMillis();
//        return date;
//    }

//    public String getgroupIDBycallerID(String callerID) {
//        Cursor cursor = null;
//        String groupID = "";
//        try {
//            cursor = readableDatabase.rawQuery("select groupid from messages where callerid='" + callerID + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                groupID = cursor.getString(cursor.getColumnIndex(KEY_GROUP_ID));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return groupID;
//    }

//    public String getNumberFromMessageTablebyCallID(String callerID) {
//        Cursor cursor = null;
//        String number = "";
//        try {
//            cursor = readableDatabase.rawQuery("select number from messages where callerid='" + callerID + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                number = cursor.getString(cursor.getColumnIndex(KEY_NUMBER));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return number;
//    }

//    public long getTimeFromMessageTablebyCallID(String callerID) {
//        Cursor cursor = null;
//        long date = System.currentTimeMillis();
//        try {
//            cursor = readableDatabase.rawQuery("select date from messages where callerid='" + callerID + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                date = cursor.getInt(cursor.getColumnIndex(KEY_TIME));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        if (date < 0)
//            date = System.currentTimeMillis();
//        return date;
//    }

//    public void updateMessageisReadyForView(String callerId, int isReadyForView) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_IS_IM_READY_FOR_VIEW, isReadyForView);
//            writeableDatabase.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?", new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public void updateGroupMessageisReadyForView(String callerId, int isReadyForView) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_IS_IM_READY_FOR_VIEW, isReadyForView);
//            writeableDatabase.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?", new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//    public Cursor getAllfailedLongIMGroupMessages() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db
//                    .rawQuery("select * from "
//                            + GROUP_MESSAGE_TABLE + " where LENGTH(long_message) > 0 and  deliverystatus = 404  " + " order by " + KEY_TIME
//                            + " asc ", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
//        return cursor;
//    }

//    public Cursor getAllfailedLongIMMessages() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select * from "
//                            + MESSAGE_TABLE + " WHERE  LENGTH(long_message)>0   and deliverystatus=404  " + " order by " + KEY_TIME
//                            + " asc ", null);
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        } finally {
//        }
////        int count = cursor.getCount();
//        return cursor;
//    }

//    public void deleteOriginalCallerIDMessageAndUpdateTempWithTheOriginalInGroupMessage(String callerID) {
//        String originalCallerId = callerID.split(Constants.CID_AND_FALSE_MULTIPART_CID_INDICATOR)[0];
//        writeableDatabase.delete(GROUP_MESSAGE_TABLE, "callerid = '" + originalCallerId + "'", null);
//        ContentValues values = new ContentValues();
//        values.put(KEY_CALLER_ID, originalCallerId);
//        writeableDatabase.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?", new String[]{callerID});
//        context.getContentResolver().notifyChange(MESSAGE_URI, null);
//
//    }

//    public void deleteOriginalCallerIDMessageAndUpdateTempWithTheOriginalInMessage(String callerID) {
//        String originalCallerId = callerID.split(Constants.CID_AND_FALSE_MULTIPART_CID_INDICATOR)[0];
//        writeableDatabase.delete(MESSAGE_TABLE, "callerid = '" + originalCallerId + "'", null);
//        ContentValues values = new ContentValues();
//        values.put(KEY_CALLER_ID, originalCallerId);
//        writeableDatabase.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?", new String[]{callerID});
//        context.getContentResolver().notifyChange(MESSAGE_URI, null);
//
//    }

//    public String getCallerIDOfFirstNewMessageInMessages() {
//        Cursor cursor = null;
//        String result = null;
//        try {
//            cursor = readableDatabase.rawQuery("select  callerid from "
//                    + MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE + " ="
//                    + MessageEntry.MessageType.RECEIVED + " and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD + " LIMIT 1", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getString(cursor.getColumnIndex("callerid"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public String getCallerIDOfFirstNewMessageInGroupMessages() {
//        Cursor cursor = null;
//        String result = null;
//        try {
//            cursor = readableDatabase.rawQuery("select  callerid from "
//                    + GROUP_MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE + " ="
//                    + MessageEntry.MessageType.RECEIVED + " and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD + " LIMIT 1", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getString(cursor.getColumnIndex("callerid"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public int getMessageNotificationCount(String number) {
//        Cursor cursor = null;
//        int result = 0;
//        try {
//            cursor = readableDatabase.rawQuery("select count(notification) as cnt from "
//                    + MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE + " ="
//                    + MessageEntry.MessageType.RECEIVED + " and number='" + number + "' and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD, null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getInt(cursor.getColumnIndex("cnt"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public String getCallerIDOfFirstNewMessageInMessages(String number) {
//        Cursor cursor = null;
//        String result = null;
//        try {
//            cursor = readableDatabase.rawQuery("select  callerid from "
//                    + MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE + " ="
//                    + MessageEntry.MessageType.RECEIVED + " and number='" + number + "' and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD + " LIMIT 1", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getString(cursor.getColumnIndex("callerid"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }

//    public String getCallerIDOfFirstNewMessageInGroupMessages(String groupid) {
//        Cursor cursor = null;
//        String result = null;
//        try {
//            cursor = readableDatabase.rawQuery("select  callerid from "
//                    + GROUP_MESSAGE_TABLE + " where " + KEY_MESSAGE_TYPE + " ="
//                    + MessageEntry.MessageType.RECEIVED + " and groupid='" + groupid + "' and "
//                    + KEY_NOTIFICATION + " ="
//                    + MessageStatus.UNREAD + " LIMIT 1", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                result = cursor.getString(cursor.getColumnIndex("callerid"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return result;
//    }


    //DID Operations
    //added by rahat for DID
    //added by rahat 12-10-2017 // change added did expired date, added update code
//    public void createUserDidEntry(DID did) {
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put("_id", (System.currentTimeMillis() + "").substring(3));
//
//            values.put("did_id", did.getDidID());
//            values.put("didOwner", did.getDidOwner());
//            values.put("didNumber", did.getDidNumber());
//            values.put("forwardedNumber", did.getForwardedNumber());
//            values.put("expiredDate", did.getExpireDate());
//
//            db = dOpenHelper.getWritableDatabase();
//            db.replace(DID_TABLE, null, values);
//            context.getContentResolver().notifyChange(DID_TABLE_URI, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    //added by rahat for DID
//    public void removeUserDidEntry(DID did) {
//        SQLiteDatabase db = null;
//
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            db.delete(DID_TABLE, "did_id = '" + did.getDidID() + "'",
//                    null);
//            context.getContentResolver().notifyChange(DID_TABLE_URI, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    //added by rahat for DID
    //added by rahat 12-10-2017  //change added expireddata in query
//    public Cursor getUserDIDs() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            //cursor = db.rawQuery("select * from "+DatabaseConstants.DID_TABLE,null);
//            cursor = db.query(DID_TABLE, new String[]{"did_id", "didOwner",
//                    "didNumber", "forwardedNumber", "expiredDate"}, null, null, null, null, null);
//            //cursor.setNotificationUri(context.getContentResolver(), DID_TABLE_URI);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return cursor;
//    }

//    public PackageSelectionObject getSubscribedPackageInfoByID(String id) {
//        SQLiteDatabase db = null;
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.query(SUBSCRIBED_PACKAGES_TABLE, new String[]{KEY_ID,
//                            "package_id", "package_name", "package_value",
//                            "package_activation_time", "package_deactivation_time", "group_id", "thumbnail",
//                            "valid_till", "subtitle", "unused_balance", "available_minutes", "package_type", "unused_minutes"}, "package_id=?",
//                    new String[]{id}, null, null, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                n = cursor.getCount();
//            // if (db != null)
//            // db.close();
//        }
//        String packageName = "";
//
//        if (cursor != null && cursor.moveToFirst()) {
//            PackageSelectionObject p = new PackageSelectionObject();
//            p.setPackageID(cursor.getString(cursor.getColumnIndex("package_id")));
//            p.setPackageName(cursor.getString(cursor.getColumnIndex("package_name")));
//            p.setPackageValue(cursor.getString(cursor.getColumnIndex("package_value")));
//            p.setActivationTime(cursor.getString(cursor.getColumnIndex("package_activation_time")));
//            p.setDeactivationTime(cursor.getString(cursor.getColumnIndex("package_deactivation_time")));
//            p.setGroupID(cursor.getString(cursor.getColumnIndex("group_id")));
//            p.setThumbnail(cursor.getString(cursor.getColumnIndex("thumbnail")));
//            p.setValidTill(cursor.getString(cursor.getColumnIndex("valid_till")));
//            p.setSubtitle(cursor.getString(cursor.getColumnIndex("subtitle")));
//            p.setCreditLeft(cursor.getString(cursor.getColumnIndex("unused_balance")));
//            p.setAvailableMins(cursor.getString(cursor.getColumnIndex("available_minutes")));
//            p.setPackageType(cursor.getString(cursor.getColumnIndex("package_type")));
//            p.setUnUsedMinutes(cursor.getString(cursor.getColumnIndex("unused_minutes")));
//            cursor.close();
//            return p;
//        } else
//            return null;
//    }

//    public ArrayList<PackageSelectionObject> getSubscribedPackages() {
//        SQLiteDatabase db = null;
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.query(SUBSCRIBED_PACKAGES_TABLE, new String[]{KEY_ID,
//                            "package_id", "package_name", "package_value",
//                            "package_activation_time", "package_deactivation_time", "group_id", "thumbnail",
//                            "valid_till", "subtitle", "unused_balance", "available_minutes", "package_type", "unused_minutes"}, "1=1",
//                    null, null, null, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                n = cursor.getCount();
//            // if (db != null)
//            // db.close();
//        }
//        ArrayList<PackageSelectionObject> packageSelectionObjects = new ArrayList<>();
//        if (cursor != null && cursor.getCount() != 0) {
//            if (cursor.moveToFirst()) {
//                do {
//                    PackageSelectionObject p = new PackageSelectionObject();
//                    p.setPackageID(cursor.getString(cursor.getColumnIndex("package_id")));
//                    p.setPackageName(cursor.getString(cursor.getColumnIndex("package_name")));
//                    p.setPackageValue(cursor.getString(cursor.getColumnIndex("package_value")));
//                    p.setActivationTime(cursor.getString(cursor.getColumnIndex("package_activation_time")));
//                    p.setDeactivationTime(cursor.getString(cursor.getColumnIndex("package_deactivation_time")));
//                    p.setGroupID(cursor.getString(cursor.getColumnIndex("group_id")));
//                    p.setThumbnail(cursor.getString(cursor.getColumnIndex("thumbnail")));
//                    p.setValidTill(cursor.getString(cursor.getColumnIndex("valid_till")));
//                    p.setSubtitle(cursor.getString(cursor.getColumnIndex("subtitle")));
//                    p.setCreditLeft(cursor.getString(cursor.getColumnIndex("unused_balance")));
//                    p.setAvailableMins(cursor.getString(cursor.getColumnIndex("available_minutes")));
//                    p.setPackageType(cursor.getString(cursor.getColumnIndex("package_type")));
//                    p.setUnUsedMinutes(cursor.getString(cursor.getColumnIndex("unused_minutes")));
//                    packageSelectionObjects.add(p);
//
//                }
//                while (cursor.moveToNext());
//            }
//            cursor.close();
//        }
//        return packageSelectionObjects;
//    }

//    public void deleteSubscribedLogs() {
//        Log.d("DatabaseConstants", "Deleting Subscribed Logs");
//        SQLiteDatabase db = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            db.delete(SUBSCRIBED_PACKAGES_TABLE, null, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void createSubscribedLogs(ArrayList<PackageSelectionObject> arrayListPackageSelectionObject) {
//        SQLiteDatabase db = null;
//        Log.d("DatabaseConstants", "Creating Subscribed Logs");
//
//        try {
//            for (int i = 0; i < arrayListPackageSelectionObject.size(); i++) {
//
//                PackageSelectionObject p = arrayListPackageSelectionObject.get(i);
//                ContentValues values = new ContentValues();
//                values.put("package_id", p.getPackageID());
//                values.put("package_name", p.getPackageName());
//                values.put("package_value", p.getPackageValue());
//                values.put("package_activation_time", p.getActivationTime());
//                values.put("package_deactivation_time", p.getDeactivationTime());
//                values.put("group_id", p.getGroupID());
//                values.put("thumbnail", p.getThumbnail());
//                values.put("valid_till", p.getValidTill());
//                values.put("subtitle", p.getSubtitle());
//                values.put("unused_balance", p.getCreditLeft());
//                values.put("available_minutes", p.getAvailableMins());
//                values.put("package_type", p.getPackageType());
//                values.put("unused_minutes", p.getUnUsedMinutes());
//                Log.d("DatabaseConstants", "Creating Subscribed Logs: unused_minutes: " + p.getUnUsedMinutes());
//                db = dOpenHelper.getWritableDatabase();
//                long res = db.insert(SUBSCRIBED_PACKAGES_TABLE, null, values);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public boolean isGroupMessageSuccessful(String callerId) {
//        //	Log.e("sms", "before"+messageID);
//        SQLiteDatabase db = dOpenHelper.getWritableDatabase();
//        int delivarystaus = -1;
//        String query = "Select * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_CALLER_ID + " = '" + callerId + "'";
//        Cursor cursor = db.rawQuery(query, null);
//
//        if (cursor != null && cursor.moveToFirst()) {
//            delivarystaus = cursor.getInt(cursor.getColumnIndex(KEY_MESSAGE_DELIVERY_STATUS));
//            cursor.close();
//            Log.e("sms", "status" + delivarystaus);
//        }
//        if (delivarystaus == MessageEntry.DeliveryStatus.SUCCESSFUL)
//            return true;
//        return false;
//    }

//    public void updateGroupSMSMessageDeliveryStatus(String callerId, int status) {
//        Log.v("DatabaseConstants", "updateGroupMessageDeliveryStatus");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            int deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
//            if (status == SMSProvider.SMS_STATUS_PENDING) {
//                deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
//            } else if (status == SMSProvider.SMS_STATUS_FAILED) {
//                deliveryStatus = MessageEntry.DeliveryStatus.FAILED;
//                values.put(KEY_FUTURE_SEND_TIME, 0);
//            } else if (status == SMSProvider.SMS_STATUS_SUCCESSFUL) {
//                deliveryStatus = MessageEntry.DeliveryStatus.SUCCESSFUL;
//                values.put(KEY_FUTURE_SEND_TIME, 0);
//            }
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, deliveryStatus);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

    public static final String KEY_SMS_MESSAGE_ID = "query_id";

//    public String getGroupIDByReuestID(String messageID) {
//        //	Log.e("sms", "before"+messageID);
//        SQLiteDatabase db = dOpenHelper.getWritableDatabase();
//        String groupID = "";
//        String query = "Select * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_SMS_MESSAGE_ID + " = '" + messageID + "'";
//        Cursor cursor = db.rawQuery(query, null);
//
//        if (cursor != null && cursor.moveToFirst()) {
//            groupID = cursor.getString(cursor.getColumnIndex(KEY_GROUP_ID));
//            cursor.close();
//            //Log.e("sms","Group"+ groupID);
//        }
//        return groupID;
//    }

//    public void updateSmsLog(String request_id, int status) {
//        Log.e(" fut update", " " + request_id + "  " + status);
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            int deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
//            if (status == SMSProvider.SMS_STATUS_PENDING) {
//                deliveryStatus = MessageEntry.DeliveryStatus.PENDING;
//            } else if (status == SMSProvider.SMS_STATUS_FAILED) {
//                deliveryStatus = MessageEntry.DeliveryStatus.FAILED;
//                values.put(KEY_FUTURE_SEND_TIME, 0);
//            } else if (status == SMSProvider.SMS_STATUS_SUCCESSFUL) {
//                deliveryStatus = MessageEntry.DeliveryStatus.SUCCESSFUL;
//                values.put(KEY_FUTURE_SEND_TIME, 0);
//            }
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, deliveryStatus);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "='" + request_id + "'", null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public Cursor getContacts() {
//        //Test();
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            String rawQuery = " SELECT DISTINCT c._id as _id, c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                    " c.photo_uri as photo_uri, c.processed_number as processed_number, null as subscribed_number, null as presencestate, " +
//                    " null as presencenote FROM contacts c WHERE  c.contact_id NOT IN ( SELECT DISTINCT c.contact_id as cid  FROM contacts c, subscriber s WHERE c.processed_number = s.number)" +
//                    " GROUP BY c.contact_id " +
//                    " UNION " +
//                    "SELECT DISTINCT c._id as _id , c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                    "c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//                    "s.presencenote as presencenote FROM (select * FROM  contacts GROUP BY number )  c, subscriber s WHERE c.processed_number = s.number " +
//                    " ORDER BY name " +
//                    "COLLATE LOCALIZED ASC";
////			cursor = db.query(CONTACTS_TABLE, null, null, null, null, null, KEY_NAME + " COLLATE LOCALIZED ASC");
//            cursor = db.rawQuery(rawQuery, null);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }


//    public Cursor getContactSearch(String searchStr) {
//        SQLiteDatabase db = null;
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            String rawQuery =
//                    " SELECT DISTINCT c._id as _id, c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                            " c.photo_uri as photo_uri, c.processed_number as processed_number, null as subscribed_number, null as presencestate, " +
//                            " null as presencenote FROM contacts c WHERE  c.contact_id NOT IN ( SELECT DISTINCT c.contact_id as cid  FROM contacts c, subscriber s WHERE c.processed_number = s.number)" +
//                            " AND ( c.name LIKE '%" + searchStr + "%' OR c.number LIKE '%" + searchStr + "%' )" +
//                            " GROUP BY c.contact_id " +
//                            " UNION " +
//                            "SELECT DISTINCT c._id as _id , c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                            "c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//                            "s.presencenote as presencenote FROM (select * FROM  contacts GROUP BY number ) c, subscriber s WHERE c.processed_number = s.number " +
//                            " AND ( c.name LIKE '%" + searchStr + "%' OR c.number LIKE '%" + searchStr + "%' )" +
//                            " ORDER BY name " +
//                            "COLLATE LOCALIZED ASC";
//
////			cursor = db.query(CONTACTS_TABLE, null, "name LIKE '%"+searchStr+"%' OR number LIKE '%"+searchStr+"%'", null, null, null, KEY_NAME + " COLLATE LOCALIZED ASC");
//            cursor = db.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getE2ESubsciber() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            String rawQuery = "SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                    " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//                    " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number AND s.buddy_public_key != '' AND s.buddy_seed != '') as temp " +
//                    " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC";
//            cursor = db.rawQuery(rawQuery, null);
//            // Log.v("All messages count", "" + cursor.getCount());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }


//    public Cursor getE2ESubsciberSearch(String searchStr) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            String rawQuery = "SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                    " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//                    " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number AND s.buddy_public_key != '' AND s.buddy_seed != '') as temp " +
//                    " WHERE temp.name LIKE '%" + searchStr + "%' OR temp.subscribed_number LIKE '%" + searchStr + "%' " +
//                    " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC";
//            cursor = db.rawQuery(rawQuery, null);
//            // Log.v("All messages count", "" + cursor.getCount());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getSubsciberSearch(String searchStr) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            String rawQuery = "SELECT * FROM (SELECT c._id as _id, c.is_favourite as is_favourite, c.name as name, c.number as number, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                    " c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//                    " s.presencenote as presencenote, s.name FROM subscriber s, contacts c where s.number = c.processed_number) as temp " +
//                    " WHERE temp.name LIKE '%" + searchStr + "%' OR temp.subscribed_number LIKE '%" + searchStr + "%' " +
////					"AND temp.name<>'' and temp.name not null" +
////					" GROUP BY temp.subscribed_number ORDER BY temp.presencestate ASC, temp.name COLLATE LOCALIZED ASC";
//                    " GROUP BY temp.subscribed_number ORDER BY temp.name COLLATE LOCALIZED ASC";
//            cursor = db.rawQuery(rawQuery, null);
//            // Log.v("All messages count", "" + cursor.getCount());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public void updateMessageNotification(String number, int e2e) {
//        Log.v("DatabaseConstants", "updateMessageNotification");
//        SQLiteDatabase db = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            ContentValues values = new ContentValues();
//            values.put(KEY_NOTIFICATION, MessageStatus.READ);
////			values.put(KEY_MESSAGE_DELIVERY_STATUS, DeliveryStatus.SEEN);
//
////            int n = db.update(MESSAGE_TABLE, values, KEY_NUMBER + "='" + number
////                    + "' and " + KEY_IS_ENCRYPTED + "=" + e2e, null);
//
//            values = new ContentValues();
//            values.put(KEY_SEEN_TIME, System.currentTimeMillis());
//             db.update(MESSAGE_TABLE, values, KEY_NUMBER + "='" + number
//                    + "'" + " AND " + KEY_MESSAGE_CONTENT + " NOT LIKE '" + Constants.SEND_FILE_PREFIX + "%'", null);
//            Log.i(TAG, "updateMessageNotification: ");
////            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            ShortcutBadgerUtil.setUnreadMessageOnIcon();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }


//    public Cursor getGroupNames() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//
//        try {
//            db = dOpenHelper.getWritableDatabase();
//
//            cursor = db.rawQuery("SELECT _id, groupname from groups", null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return cursor;
//    }

//    public Cursor getGroupNamesMatching(String text) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//
//        try {
//            db = dOpenHelper.getWritableDatabase();
//
//            cursor = db.rawQuery("SELECT _id, groupname from groups Where groupname LIKE '%" + text + "%'", null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return cursor;
//    }

//    public ArrayList<String> getGroupContacts(long l_id) {
//        ArrayList<String> result = new ArrayList<>();
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        String s;
//        int id = (int) l_id;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//
//            cursor = db.rawQuery("SELECT _id, number from group_contact where groupid=" + id, null);
//            // Log.v("All messages count", "" + cursor.getCount());
//
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                do {
//                    s = cursor.getString(1);
//                    result.add(s);
//                } while (cursor.moveToNext());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                cursor.close();
//            // if (db != null)
//            // db.close();
//        }
//        return result;
//    }


//    public void createBurnTimerEntry(BurnTimerEntry burnTimerEntry) {
//        Log.v("BurnTimeEntry", "createBurnTimerEntry " + burnTimerEntry.burnTime * 1000);
////		if (burnTimerEntry.retryTime <= 0)
//        if (burnTimerEntry.burnTime <= -1)
//            return;
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_CALLER_ID, burnTimerEntry.callerId);
//            values.put(KEY_NUMBER, burnTimerEntry.number);
//            values.put(KEY_ENTRY_TYPE, burnTimerEntry.entryType);
//            values.put(KEY_MESSAGE_TYPE, burnTimerEntry.messageType);
//            burnTimerEntry.burnTime = burnTimerEntry.burnTime * 1000;
//
//            values.put(KEY_BURN_TIME, burnTimerEntry.burnTime);
//            values.put(KEY_BURN_ENTRY_TIME, burnTimerEntry.burnEntryTime);
//            values.put(KEY_BURN_TIMER_INDEX, burnTimerEntry.burnTimeIndex);
//            db = dOpenHelper.getWritableDatabase();
//            db.insert(BURN_MESSAGE_INFO_TABLE, null, values);
//            BurnMessageHelper.addBurnTimerEntry(burnTimerEntry);
//            Intent mIntent = new Intent(Constants.BURN_TIMER_CHANGE_ACTION);
//            LocalBroadcastManager.getInstance(context).sendBroadcast(mIntent);
//            context.getContentResolver().notifyChange(BURN_MESSAGE_INFO_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void deleteBurnMessageEntry(String callerId) {
//        Log.e("burn", "deleteBurnMessage");
//        SQLiteDatabase db = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            int x = db.delete(BURN_MESSAGE_INFO_TABLE,
//                    "callerid='" + callerId + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public Cursor getBurnTimerEntries() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.query(BURN_MESSAGE_INFO_TABLE, null, null, null, null, null, null);
//            return cursor;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

//    public ArrayList<String> getSmsThreadIdList(String processedNumber) {
//        SQLiteDatabase db = null;
//        ArrayList<String> smsThreadIdList = new ArrayList<>();
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(MESSAGE_TABLE, new String[]{KEY_THREAD_ID},
//                    KEY_NUMBER + "='" + processedNumber + "' AND " + KEY_THREAD_ID + "<>''", null, null, null,
//                    null);
//            if (cursor != null && cursor.moveToFirst()) {
//                do {
//                    String smsThreadId = cursor.getString(cursor.getColumnIndex(KEY_THREAD_ID));
//                    if (smsThreadId != null && smsThreadId.length() > 0) {
//                        smsThreadIdList.add(smsThreadId);
//                    }
//                } while (cursor.moveToNext());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return smsThreadIdList;
//    }

//    public void deleteNativeSmsByThreadIdList(ArrayList<String> smsThreadIdList) {
//        int deletedMessageCount = 0;
//        for (String smsThreadId : smsThreadIdList) {
//            try {
//                deletedMessageCount += context.getContentResolver().delete(
//                        Uri.parse("content://sms/"), "thread_id=?",
//                        new String[]{smsThreadId});
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        if (deletedMessageCount == 0) {
//            Intent intent = new Intent(Constants.NATIVE_SMS_DELETE_FAILED_ACTION);
//            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
//        } else {
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        }
//    }

//    public boolean isBlockContact(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.rawQuery("SELECT _id from block where number='" + number + "'", null);
//
//            if (cursor.moveToFirst()) {
//                do {
//                    result = true;
//                    break;
//                } while (cursor.moveToNext());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                cursor.close();
////          if (db != null)
////              db.close();
//        }
//
//        //Log.v("DatabaseConstants", "DatabaseConstants isBlockContact: " + number + " " + result);
//        return result;
//    }

//    public int checkIfHiddenChatByNumber(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        int n = 0;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db.rawQuery(
//                    "SELECT number FROM hidden_messages where number = '"
//                            + number + "'", null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                n = cursor.getCount();
//            cursor.moveToFirst();
//        }
//
//        return (n == 0) ? 0 : n;
//    }

//    public boolean checkIfHiddenChat(String number, int isEncrypted, String groupid, boolean isGroupChat) {
//        //for a contact check if its chat history is hidden
//        Log.d("DatabaseConstants", "checking chats hiddend status");
//        boolean isFound = false;
//        String foundNumber = "";
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            if (isGroupChat) { //ignore the first two params
//                cursor = db.rawQuery("SELECT * FROM hidden_messages WHERE groupid ='" + groupid + "' ;", null);
//            } else {//ignore the last two paramas
//                cursor = db.rawQuery("SELECT * FROM hidden_messages WHERE number ='" + number + "' AND is_encrypted = " + isEncrypted + ";", null);
//            }
//            if (cursor != null && cursor.moveToFirst()) {
//                if (isGroupChat) {
//                    foundNumber = cursor.getString(cursor.getColumnIndex(KEY_GROUP_ID));
//                    if (foundNumber.equals(groupid))
//                        isFound = true;
//                } else {
//                    foundNumber = cursor.getString(cursor.getColumnIndex(KEY_NUMBER));
//                    if (foundNumber.equals(number))
//                        isFound = true;
//                }
//            }
//        } catch (Exception e) {
//            Log.e("DatabaseConstants", "checking chats hiddend status error " + e.getLocalizedMessage());
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//        return isFound;
//    }

//    public void deleteBroadcastIMLogById(String broadcast_id) {
//        Log.v("DatabaseConstants", "deleteIMSLogByDelimitedNumbers");
//        SQLiteDatabase db = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            db.delete(MESSAGE_TABLE, "broadcast_id = " + broadcast_id, null);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            //removeAllretryEntriesByNumber(numbers);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////          if (db != null)
////              db.close();
//        }
//    }


//    public void deleteIMSLogByDelimitedNumbers(String numbers, int isEncrypted) {
//        Log.v("DatabaseConstants", "deleteIMSLogByDelimitedNumbers" + numbers);
//        SQLiteDatabase db = null;
//        List<String> numbersList = Arrays.asList(numbers.split(","));
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            for (int i = 0; i < numbersList.size(); i++) {
//                db.delete(MESSAGE_TABLE, "number = '" + numbersList.get(i) + "' AND " + KEY_IS_ENCRYPTED + " = " + isEncrypted, null);
//            }
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
////            removeAllretryEntriesByNumber(numbers);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////          if (db != null)
////              db.close();
//        }
//    }

//    public boolean isBurnTimeEntryAvailable(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.query(BURN_MESSAGE_INFO_TABLE, null, KEY_NUMBER + " ='" + number
//                    + "'", null, null, null, null);
//            return (cursor != null && cursor.getCount() == 1);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return false;
//    }

//    private void removeAllretryEntriesByNumber(String number) {
//        RetryFileService.removeRetryEntrybyNumber(number);
//        Intent mIntent = new Intent(Constants.FILE_RETRY_CHANGE_ACTION);
//        LocalBroadcastManager.getInstance(context).sendBroadcast(mIntent);
//
//    }


//    public Cursor getRetryFileEntries() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.query(FILE_RETRY_TABLE, null, null, null, null, null, null);
//            return cursor;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

//    public void updateBurnTimerEntry(BurnTimerEntry burnTimerEntry) {
//        Log.v("BurnTimeEntry", "updateBurnTimerEntry");
//        SQLiteDatabase db = dOpenHelper.getWritableDatabase();
//        ;
//        try {
////          if (burnTimerEntry.retryTime <= 0) {
//            if (burnTimerEntry.burnTime == -1) {
//                db.delete(BURN_MESSAGE_INFO_TABLE, KEY_NUMBER + "=?",
//                        new String[]{burnTimerEntry.number});
//                BurnMessageHelper.removeBurnTimerEntry(burnTimerEntry.number);
//            } else {
//                ContentValues values = new ContentValues();
//                values.put(KEY_NUMBER, burnTimerEntry.number);
//                values.put(KEY_ENTRY_TYPE, burnTimerEntry.entryType);
//                burnTimerEntry.burnTime = burnTimerEntry.burnTime * 1000;
//                values.put(KEY_BURN_TIME, burnTimerEntry.burnTime);
//                //burnTimerEntry.extactRetryTime = BurnMessageHelper.getBurnTimerEntry(burnTimerEntry.number).extactRetryTime;
//                values.put(KEY_BURN_ENTRY_TIME, burnTimerEntry.burnEntryTime);
//                values.put(KEY_BURN_TIMER_INDEX, burnTimerEntry.burnTimeIndex);
//                db.update(BURN_MESSAGE_INFO_TABLE, values, KEY_NUMBER + "=?",
//                        new String[]{burnTimerEntry.number});
//                BurnMessageHelper.addBurnTimerEntry(burnTimerEntry);
//            }
//
//            Intent mIntent = new Intent(Constants.BURN_TIMER_CHANGE_ACTION);
//            LocalBroadcastManager.getInstance(context).sendBroadcast(mIntent);
//            context.getContentResolver().notifyChange(BURN_MESSAGE_INFO_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public Cursor getAllChatHistoryLog() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, null as groupid, number, sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus, null as name, broadcast_id, Max(date) as date "
//                                    + "FROM messages WHERE number NOT IN (SELECT number FROM hidden_messages WHERE messages.is_encrypted = hidden_messages.is_encrypted) " + READY_CONDITION + " GROUP BY number,is_encrypted HAVING messages.date = max(messages.date)"
//                                    + " UNION "
//                                    + "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number, sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus, null as name, broadcast_id, Max(date) as date "
//                                    + "FROM group_messages WHERE groupid NOT IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1) " + READY_CONDITION + " GROUP BY groupid HAVING group_messages.date = max(group_messages.date) ORDER BY date DESC",
//                            null);
//
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getAllChatHistoryLog(String searchString) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT Max(messages._id) as _id, null as groupid, messages.number as number, messagecontent, messagetype, deliverystatus,contacts.name,  Max(date) as date "
//                                    + "FROM messages,contacts WHERE messages.number=contacts.processed_number AND messagetype <3 AND"
//                                    + "( contacts.name like '%"
//                                    + searchString
//                                    + "%' OR messages.messagecontent like '%"
//                                    + searchString
//                                    + "%'"
//                                    + ") GROUP BY messages.number HAVING messages.date = max(messages.date)"
//                                    + " UNION "
//                                    + "SELECT Max(_id) as _id, groupid, number, messagecontent, messagetype, deliverystatus,null as name, Max(date) as date "
//                                    + "FROM group_messages WHERE group_messages.number like '%"
//                                    + searchString
//                                    + "%' OR group_messages.messagecontent like '%"
//                                    + searchString
//                                    + "%'"
//                                    + " GROUP BY groupid HAVING group_messages.date = max(group_messages.date) " +
//                                    " UNION " +
//                                    "SELECT Max(messages._id) as _id, null as groupid, messages.number as number, messagecontent, messagetype, deliverystatus,null as name,  Max(date) as date "
//                                    + "FROM messages WHERE  messagetype>2 AND (messages.number like '%"
//                                    + searchString
//                                    + "%' OR messages.messagecontent like '%"
//                                    + searchString
//                                    + "%'"
//                                    + ") GROUP BY messages.number HAVING messages.date = max(messages.date)" +
//                                    " ORDER BY date DESC",
//                            null);
//            // Log.v("All messages count", "" + c.getCount());
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getAllChatHistoryLog(String searchString, boolean isShowingHiddenChat) {
//
//        String filterOuthiddenChatClause = (isShowingHiddenChat == true) ? "" : " WHERE messages.number NOT IN (SELECT number FROM hidden_messages WHERE messages.is_encrypted = hidden_messages.is_encrypted)";
//        String fetchHiddenChatClause = (isShowingHiddenChat == true) ? " OR number IN (SELECT number FROM hidden_messages)" : "";
//        String filterOuthiddenGroupChatClause = (isShowingHiddenChat == true) ? "" : " WHERE group_messages.groupid NOT IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1)";
//        String fetchHiddenGroupChatClause = (isShowingHiddenChat == true) ? " OR groupid IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1)" : "";
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            String rawQueryStr = "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, null as groupid, number,sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus,name, broadcast_id, Max(date) as date "
//                    + "FROM (SELECT * FROM messages LEFT JOIN contacts ON messages.number=contacts.processed_number" + filterOuthiddenChatClause + ") WHERE "
//                    + "( name like '%"
//                    + searchString
//                    + "%' OR messagecontent like '%"
//                    + searchString
//                    + "%'"
//                    + " OR number like '%"
//                    + searchString
//                    + "%'" + READY_CONDITION + fetchHiddenChatClause
//                    + ") GROUP BY number,is_encrypted HAVING date = max(date)"
//                    + " UNION "
//                    + "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number,sum(notification) as unread ,messagecontent, is_encrypted, messagetype, deliverystatus,groupname as name, broadcast_id, Max(date) as date "
//                    + "FROM ( SELECT * from group_messages LEFT JOIN  group_table ON group_messages.groupid = group_table.groupid" + filterOuthiddenGroupChatClause + " ) WHERE ( number like '%"
//                    + searchString
//                    + "%' OR messagecontent like '%"
//                    + searchString
//                    + "%' OR name like '%"
//                    + searchString
//                    + "%'" + READY_CONDITION + fetchHiddenGroupChatClause
//                    + ") GROUP BY groupid HAVING date = max(date) " +
//                    " ORDER BY date DESC";
//
//            cursor = db.rawQuery(rawQueryStr, null);
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        }
//        return cursor;
//    }


//    public Cursor getAppChatHistoryLog() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, null as groupid, number, sum(notification) as unread, messagecontent, messagetype, is_encrypted, deliverystatus, null as name, broadcast_id, Max(date) as date "
//                                    + "FROM messages WHERE (messagetype!=3 AND messagetype!=4 AND messagetype!=4 AND messagetype!=5) AND number NOT IN (SELECT number FROM hidden_messages WHERE messages.is_encrypted = hidden_messages.is_encrypted) " + READY_CONDITION + " GROUP BY number,is_encrypted HAVING messages.date = max(messages.date)"
//                                    + " UNION "
//                                    + "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number,sum(notification) as unseen,  messagecontent, messagetype, is_encrypted, deliverystatus, null as name, broadcast_id, Max(date) as date "
//                                    + "FROM group_messages WHERE (messagetype!=3 AND messagetype!=4 AND messagetype!=4 AND messagetype!=5) AND groupid NOT IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1) " + READY_CONDITION + " GROUP BY groupid HAVING group_messages.date = max(group_messages.date) ORDER BY date DESC",
//
//                            null);
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        } finally {
//
//            if (cursor != null) {
//                cursor.getCount();
//                if (cursor.moveToLast())
//                    context.getSharedPreferences(Constants.tag, Context.MODE_PRIVATE).edit().putLong(Constants.MAIN_HISTORY_OLDEST_TIMESTAMP, cursor.getLong(cursor
//                            .getColumnIndex(DatabaseConstants.KEY_TIME))).commit();
//            }
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public Cursor getGroupChatHistoryLog() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number, sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus, null as name, broadcast_id, Max(date) as date "
//                                    + "FROM group_messages WHERE groupid NOT IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1) " + READY_CONDITION + " GROUP BY groupid HAVING group_messages.date = max(group_messages.date) ORDER BY date DESC",
//                            null);
//
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getAppChatHistoryLog(String searchString, boolean isShowingHiddenChat) {
//
//        String filterOuthiddenChatClause = (isShowingHiddenChat == true) ? "" : " WHERE messages.number NOT IN (SELECT number FROM hidden_messages WHERE messages.is_encrypted = hidden_messages.is_encrypted)";
//        String fetchHiddenChatClause = (isShowingHiddenChat == true) ? " OR number IN (SELECT number FROM hidden_messages)" : "";
//        String filterOuthiddenGroupChatClause = (isShowingHiddenChat == true) ? "" : " AND group_messages.groupid NOT IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1)";
//        String fetchHiddenGroupChatClause = (isShowingHiddenChat == true) ? " OR groupid IN (SELECT groupid FROM hidden_messages WHERE is_group_chat = 1)" : "";
//
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            String rawQueryStr = "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, null as groupid, number,sum(notification) as unread,  messagecontent, messagetype, is_encrypted,deliverystatus,name, broadcast_id, Max(date) as date "
//                    + "FROM (SELECT * FROM messages LEFT JOIN contacts ON messages.number=contacts.processed_number" + filterOuthiddenChatClause + ") WHERE "
//                    + "(messagetype!=3 AND messagetype!=4 AND messagetype!=4 AND messagetype!=5) AND ( name like '%"
//                    + searchString
//                    + "%' OR messagecontent like '%"
//                    + searchString
//                    + "%'"
//                    + " OR number like '%"
//                    + searchString
//                    + "%'" + READY_CONDITION + fetchHiddenChatClause
//                    + ") GROUP BY number ,is_encrypted HAVING date = max(date)"
//                    + " UNION "
//                    + "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number, sum(notification) as unread,  messagecontent, messagetype, is_encrypted, deliverystatus,groupname as name, broadcast_id, Max(date) as date "
//                    + "FROM ( SELECT * from group_messages LEFT JOIN  group_table ON group_messages.groupid = group_table.groupid WHERE group_type !=2 " + filterOuthiddenGroupChatClause + ") WHERE (messagetype!=3 AND messagetype!=4 AND messagetype!=4 AND messagetype!=5) AND ( number like '%"
//                    + searchString
//                    + "%' OR messagecontent like '%"
//                    + searchString
//                    + "%' OR name like '%"
//                    + searchString
//                    + "%'" + READY_CONDITION + fetchHiddenGroupChatClause
//                    + ") GROUP BY groupid HAVING date = max(date) " +
//                    " ORDER BY date DESC";
//
//            cursor = db.rawQuery(rawQueryStr, null);
//            // Log.v("All messages count", "" + c.getCount());
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        } finally {
//        }
//        return cursor;
//    }

//    public Cursor getFutureChatHistoryLog() {
//
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, null as groupid, number, sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus, null as name, broadcast_id, Max(date) as date, futuresendtime "
//                                    + "FROM messages WHERE messages.futuresendtime > 0 " + READY_CONDITION + " GROUP BY number,is_encrypted HAVING messages.date = max(messages.date)"
//                                    + " UNION "
//                                    + "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number, sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus, null as name, broadcast_id, Max(date) as date, futuresendtime "
//                                    + "FROM group_messages WHERE group_messages.futuresendtime > 0 " + READY_CONDITION + " GROUP BY groupid HAVING group_messages.date = max(group_messages.date) ORDER BY date DESC",
//                            null);
//            // Log.v("All messages count", "" + c.getCount());
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getFutureChatHistoryLog(String searchString) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = db
//                    .rawQuery(
//                            "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, null as groupid, number,sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus,name, broadcast_id, Max(date) as date, futuresendtime "
//                                    + "FROM (SELECT * FROM messages LEFT JOIN contacts ON messages.number=contacts.processed_number) WHERE futuresendtime > 0 AND ( number like '%"
//                                    + searchString
//                                    + "%' OR name like '%"
//                                    + searchString
//                                    + "%' OR messagecontent like '%"
//                                    + searchString
//                                    + "%')" + READY_CONDITION
//                                    + " GROUP BY number,is_encrypted HAVING date = max(date)"
//                                    + " UNION "
//                                    + "SELECT ocid, mime_type, is_confide, Max(_id) as _id, key_thread_id, groupid, number,sum(notification) as unread ,messagecontent, is_encrypted, messagetype, deliverystatus,groupname as name, broadcast_id, Max(date) as date, futuresendtime "
//                                    + "FROM  ( SELECT * from group_messages LEFT JOIN  group_table ON group_messages.groupid = group_table.groupid ) WHERE futuresendtime > 0 AND ( number like '%"
//                                    + searchString
//                                    + "%' OR name like '%" +
//                                    searchString + "%' OR messagecontent like '%"
//                                    + searchString
//                                    + "%' )" + READY_CONDITION
//                                    + " GROUP BY groupid HAVING date = max(date) ORDER BY date DESC",
//                            null);
//            // Log.v("All messages count", "" + c.getCount());
//        } catch (Exception e) {
//            if (e != null)
//                e.printStackTrace();
//        }
//        return cursor;
//    }

//    public int getBurnTimerIndex(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.query(BURN_MESSAGE_INFO_TABLE, new String[]{KEY_BURN_TIMER_INDEX}, KEY_NUMBER + " ='" + number
//                    + "'", null, null, null, null);
//            if (cursor != null && cursor.getCount() == 1 && cursor.moveToFirst()) {
//                return cursor.getInt(cursor.getColumnIndex(KEY_BURN_TIMER_INDEX));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return -1;
//    }


//    public Cursor getAllBlockContact() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.rawQuery("SELECT block._id,block.number,contacts.name,contacts.processed_number,contacts.contact_id,contacts.photo_uri from block LEFT JOIN contacts ON block.number=contacts.processed_number group by block.number", null);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//
//        }
//        return cursor;
//    }

//    public Cursor getAllBlockContactBySearch(String search) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        boolean result = false;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.rawQuery("SELECT * from ( SELECT block._id,block.number,contacts.name,contacts.processed_number,contacts.contact_id,contacts.photo_uri from block LEFT JOIN contacts ON block.number=contacts.processed_number ) WHERE name LIKE '%"
//                    + search
//                    + "%' OR number LIKE '%" + search
//                    + "%' group by number", null);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//
//        }
//        return cursor;
//    }
//
//    public int getBlockContactCount() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        int count = 0;
//        boolean result = false;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            cursor = db.rawQuery("SELECT _id,number from block", null);
//            if (cursor != null)
//                count = cursor.getCount();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return count;
//    }

//    public void createBlockContactEntries(ArrayList<String> blockContacts) {
//        SQLiteDatabase db = null;
//        for (String contact : blockContacts) {
//            try {
//                db = dOpenHelper.getWritableDatabase();
//                ContentValues values = new ContentValues();
//                values.put(KEY_NUMBER, contact);
//                db.insert(BLOCK_TABLE, null, values);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        context.getContentResolver().notifyChange(BLOCK_URI, null);
//        context.getContentResolver().notifyChange(CONTACTS_URI, null);
//    }


//    public ArrayList<PhoneName> getPhoneNumbersById(long _id) {
//        ArrayList<PhoneName> phoneList = new ArrayList<>();
//        SQLiteDatabase db = dOpenHelper.getWritableDatabase();
//
//        Cursor cursor = db.rawQuery("select name,number,is_favourite from contacts where contact_id='" + _id + "'" + " group by number", null);
//        if (cursor != null && cursor.moveToFirst()) {
//            do {
//                PhoneName phnname = new PhoneName();
//                phnname.name = cursor.getString(0);
//                phnname.number = cursor.getString(1);
//                phnname.starred = cursor.getString(2);
//                phnname.state = SubscriberRepo.get().isSubscriber(phnname.number)?1:0;
//                phoneList.add(phnname);
//            }
//            while (cursor.moveToNext());
//        }
//        return phoneList;
//    }

//    public void deleteBlockContactsNotINMap(HashSet<String> numbers) {
//        if (numbers.size() <= 0)
//            return;
//
//        StringBuilder whereClause = new StringBuilder(" number not in (");
//        int i = 0;
//        for (String pin : numbers) {
//            i++;
//            whereClause.append("'").append(pin).append("',");
//        }
//        int len = whereClause.length();
//        whereClause.deleteCharAt(len - 1);
//        whereClause.append(")");
//
//
//        SQLiteDatabase db = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            int deleted = db.delete(BLOCK_TABLE, whereClause.toString(), null);
//            Log.w("DatabaseConstants", deleted + " entries deleted from block table");
//            if (deleted > 0) {
//                context.getContentResolver().notifyChange(BLOCK_URI, null);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }


//    public void updateGroupMessageContent(String callerId, String messageContent) {
//        Log.v("DatabaseConstants", "updateGroupMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }


//    public void updateMessageContent(String callerId, String messageContent) {
//        Log.v("DatabaseConstants", "updateMessageContent, content: " + messageContent + ", callerid: " + callerId);
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            db = dOpenHelper.getWritableDatabase();
//            db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }


//    public Cursor getContactNumbersOnly() {
//
//        Log.d("tarique", "getContactNumbersOnly()");
//
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            String rawQuery = " SELECT DISTINCT c._id as _id, c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                    " c.photo_uri as photo_uri, c.processed_number as processed_number, null as subscribed_number, null as presencestate, " +
//                    " null as presencenote FROM contacts c " +
//                    "WHERE  c.contact_id NOT IN " +
//                    "( SELECT DISTINCT c.contact_id as cid  FROM contacts c, subscriber s WHERE (c.processed_number = s.number OR c.number LIKE '%@%'))" +
//                    " GROUP BY c.contact_id " +
//                    " UNION " +
//                    "SELECT DISTINCT c._id as _id , c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                    "c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//                    "s.presencenote as presencenote FROM (select * FROM  contacts GROUP BY number )  c, subscriber s " +
//                    "WHERE (c.processed_number = s.number AND c.number NOT LIKE '%@%')" +
//                    " ORDER BY name " +
//                    "COLLATE LOCALIZED ASC";
////			cursor = db.query(CONTACTS_TABLE, null, null, null, null, null, KEY_NAME + " COLLATE LOCALIZED ASC");
//            cursor = db.rawQuery(rawQuery, null);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }


//    public Cursor getContactNumbersOnlySearch(String searchStr) {
//        SQLiteDatabase db = null;
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            String rawQuery =
//                    " SELECT DISTINCT c._id as _id, c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                            " c.photo_uri as photo_uri, c.processed_number as processed_number, null as subscribed_number, null as presencestate, " +
//                            " null as presencenote FROM contacts c WHERE  c.contact_id NOT IN ( SELECT DISTINCT c.contact_id as cid  FROM contacts c, subscriber s WHERE c.processed_number = s.number)" +
//                            " AND ( c.name LIKE '%" + searchStr + "%' OR c.number LIKE '%" + searchStr + "%' )" +
//                            "AND c.number NOT LIKE '%@%'" +
//                            " GROUP BY c.contact_id " +
//                            " UNION " +
//                            "SELECT DISTINCT c._id as _id , c.contact_id as cid, c.name as name, c.number as number, c.is_favourite as is_favourite, c.contact_id as contact_id, c.lookup_key as lookup_key, " +
//                            "c.photo_uri as photo_uri, c.processed_number as processed_number, s.number as subscribed_number, s.presencestate as presencestate," +
//                            "s.presencenote as presencenote FROM (select * FROM  contacts GROUP BY number ) c, subscriber s WHERE c.processed_number = s.number " +
//                            " AND ( c.name LIKE '%" + searchStr + "%' OR c.number LIKE '%" + searchStr + "%' ) " +
//                            "AND c.number NOT LIKE '%@%'" +
//                            " ORDER BY name " +
//                            "COLLATE LOCALIZED ASC";
//
////			cursor = db.query(CONTACTS_TABLE, null, "name LIKE '%"+searchStr+"%' OR number LIKE '%"+searchStr+"%'", null, null, null, KEY_NAME + " COLLATE LOCALIZED ASC");
//            cursor = db.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }


//    public Cursor getNonSubscriberContacts() {
//        //Test();
//        SQLiteDatabase db = null;
//        int n = 0;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            String rawQuery = "SELECT DISTINCT _id,  name,  number, is_favourite, contact_id, lookup_key," +
//                    " photo_uri, processed_number" +
//                    " FROM contacts WHERE processed_number not in (SELECT number from subscriber)" +
//                    " GROUP BY number ORDER BY name COLLATE LOCALIZED ASC";
////			cursor = db.query(CONTACTS_TABLE, null, null, null, null, null, KEY_NAME + " COLLATE LOCALIZED ASC");
//            cursor = db.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getNonSubscriberContacts(String searchStr) {
//        //Test();
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            String rawQuery = "SELECT DISTINCT _id,  name,  number, is_favourite, contact_id, lookup_key," +
//                    " photo_uri, processed_number" +
//                    " FROM contacts WHERE (name LIKE '%" + searchStr + "%' OR number LIKE '%" + searchStr + "%') AND processed_number not in (SELECT number from subscriber)" +
//                    " GROUP BY number ORDER BY name COLLATE LOCALIZED ASC";
//            cursor = db.rawQuery(rawQuery, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getAllfailedConfideMessages() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select * from "
//                            + MESSAGE_TABLE + " WHERE  deliverystatus=404  ", null);
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        } finally {
//        }
//////        int count = cursor.getCount();
//        return cursor;
//    }


//    public void updateGroupMessageContent(String callerId, String messageContent, MimeType mimeType) {
//        Log.v("DatabaseConstants", "updateGroupMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_MIME_TYPE, mimeType.toString());
//            db = dOpenHelper.getWritableDatabase();
//            db.update(GROUP_MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }


//    public int checkIfEncryptedChat(String callerID, String groupid, boolean isGroupChat) {
//        //for a contact check if its chat history is hidden
//        Log.e("DatabaseConstants", "checking chats encryption status");
//        int isEncrypted = 0;
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            if (isGroupChat) { //ignore the first two params
//                cursor = db.rawQuery("SELECT * FROM group_messages WHERE callerid ='" + callerID + "' ;", null);
//            } else {//ignore the last two paramas
//                cursor = db.rawQuery("SELECT * FROM messages WHERE callerid ='" + callerID + "'  ;", null);
//            }
//            if (cursor != null && cursor.moveToFirst())
//                return cursor.getInt(cursor.getColumnIndex(KEY_IS_ENCRYPTED));
//        } catch (Exception e) {
//            Log.e("DatabaseConstants", "checking chats hiddend status error " + e.getLocalizedMessage());
//            e.printStackTrace();
//        } finally {
//
//        }
//
//        return 0;
//    }

//    public String getUserFromGroupMessage(String callID) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        String result = "";
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(GROUP_MESSAGE_TABLE, new String[]{KEY_NUMBER}, KEY_MESSAGE_CALL_ID + "= ?", new String[]{callID}, null, null, null);
//            if (cursor != null && cursor.moveToFirst())
//                result = cursor.getString(cursor
//                        .getColumnIndex(KEY_NUMBER));
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                cursor.close();
//        }
//        return result;
//    }


//    public boolean isConfideMessage(String callerID) {
//        Cursor cursor = null;
//        int isConfide = 0;
//        try {
//            cursor = dOpenHelper.getReadableDatabase().rawQuery("select is_confide from messages where callerid='" + callerID + "'", null);
//            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
//                isConfide = cursor.getInt(cursor.getColumnIndex("is_confide"));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//        return isConfide == 1 ? true : false;
//    }


//    public void updateMessageContent(String callerId, String messageContent, MimeType mimeType) {
//        Log.v("DatabaseConstants", "updateMessageContent");
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_MIME_TYPE, mimeType.toString());
//            db = dOpenHelper.getWritableDatabase();
//            db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                    new String[]{callerId});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }


//    public String getUserFromMessage(String callID) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        String result = "";
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.query(MESSAGE_TABLE, new String[]{KEY_NUMBER}, KEY_MESSAGE_CALL_ID + "= ?", new String[]{callID}, null, null, null);
//            if (cursor != null && cursor.moveToFirst())
//                result = cursor.getString(cursor
//                        .getColumnIndex(KEY_NUMBER));
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                cursor.close();
//        }
//        return result;
//    }


//    public void createMultipartMessagesEntry(MultipartMessage multiPartMessage) {
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put("callerid", multiPartMessage.getCallerID());
//            values.put("calleridlocal", multiPartMessage.getCallerIDLocal());
//            values.put("number", multiPartMessage.getNumber());
//            values.put("date", multiPartMessage.getDate());
//            values.put("groupid", multiPartMessage.getGroupID());
//            values.put("multipart_number", multiPartMessage.getMultipartNumber());
//            values.put("messagecontent", multiPartMessage.getContent());
//            values.put("total_parts", multiPartMessage.getTotalParts());
//            values.put("is_decrypted", multiPartMessage.isDeCrypted);
//            values.put("is_outgoing", multiPartMessage.getIsOutgoing());
//            db = dOpenHelper.getWritableDatabase();
//            Log.d("Abhi", "Message Inserted: " +
//                    "" + db.replace(MULTIPART_MESSAGE_TABLE, null, values));
////            context.getContentResolver().notifyChange(MESSAGE_URI, null);
////            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
////            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
//    }

//    public void createNewTimeLineEntryForAllUniqueGroupIDOrUser() {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select group_or_user from messageHistoryTimeline group by group_or_user", null);
//            HashSet<String> groupOrUserSet = new HashSet<>();
//            if (cursor.moveToFirst()) {
//                do {
//                    String groupOrUser = cursor.getString(cursor.getColumnIndex("group_or_user"));
//                    groupOrUserSet.add(groupOrUser);
//                }
//                while (cursor.moveToNext());
//            }
//
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select number from messages where (messagetype = '0' or  messagetype = '1') group by number", null);
//            if (cursor.moveToFirst()) {
//                do {
//                    String groupOrUser = cursor.getString(cursor.getColumnIndex("number"));
//                    if (!groupOrUserSet.contains(groupOrUser))
//                        addEntryInMessageTimeLine(groupOrUser, System.currentTimeMillis(), System.currentTimeMillis(), false);
//                }
//                while (cursor.moveToNext());
//
//            }
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select groupid from group_messages group by groupid", null);
//            if (cursor.moveToFirst()) {
//                do {
//                    String groupOrUser = cursor.getString(cursor.getColumnIndex("groupid"));
//                    if (!groupOrUserSet.contains(groupOrUser))
//                        addEntryInMessageTimeLine(groupOrUser, System.currentTimeMillis(), System.currentTimeMillis(), true);
//                }
//                while (cursor.moveToNext());
//
//            }
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        }
//
//        if (cursor != null)
//            cursor.close();
//
//    }


//    public Cursor getTimeLineItemOrderByUserOrGroupIDAndStartDate() {
//
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery(" select * from messageHistoryTimeline order by group_or_user, from_date", null);
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        }
//        return cursor;
//
//    }

//    public Cursor getTimeLineItemOrderByUserOrGroupIDAndStartDate(HashSet<String> set) {
//
//
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            String domain = "";
//            for (String s : set)
//                domain += "'" + s + "'" + ",";
//            if (domain.length() > 1 && domain.contains(","))
//                domain = domain.substring(0, domain.lastIndexOf(','));
//
//            db = dOpenHelper.getReadableDatabase();
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery(" select * from messageHistoryTimeline WHERE  group_or_user IN (" + domain + ") order by group_or_user, from_date", null);
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        }
//        return cursor;
//
//    }


//    public void deleteSelectedTimeLineEntries(ArrayList<String> list) {
//
//        SQLiteDatabase db = null;
//        try {
//            StringBuilder sb = new StringBuilder();
//            for (int i = 0; i < list.size(); i++)
//                sb.append("'" + list.get(i) + "'" + ",");
//            String domain = sb.toString();
//            if (domain.length() > 1 && domain.contains(","))
//                domain = domain.substring(0, domain.lastIndexOf(','));
//
//            db = dOpenHelper.getWritableDatabase();
//            int i = db.delete(MESSAGE_HISTORY_TIMELINE, " group_or_user IN (" + domain + ")", null);
//            Log.i("Mterminality", "Deleted TimeLine Row: " + i);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }


//    public void updateMessageTimeLine(HashMap<String, IMTimeLineItem> imTimeLineItemHashMap) {
//        try {
//            Iterator it = imTimeLineItemHashMap.entrySet().iterator();
//            while (it.hasNext()) {
//                HashMap.Entry itemHashMap = (HashMap.Entry) it.next();
//                ContentValues values = new ContentValues();
//                values.put("id", System.currentTimeMillis());
//                values.put("group_or_user", ((IMTimeLineItem) itemHashMap.getValue()).getUserIDorGroupID());
//                values.put("from_date", ((IMTimeLineItem) itemHashMap.getValue()).getDateStart());
//                values.put("to_date", ((IMTimeLineItem) itemHashMap.getValue()).getDateEnd());
//                values.put("is_group_chat", ((IMTimeLineItem) itemHashMap.getValue()).isGroup() ? 1 : 0);
//                long numOfRow = dOpenHelper.getWritableDatabase().replace(MESSAGE_HISTORY_TIMELINE, null, values);
//                it.remove(); // avoids a ConcurrentModificationException
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateMessageTimeLine(IMTimeLineItem imTimeLineItem) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put("id", System.currentTimeMillis());
//            values.put("group_or_user", (imTimeLineItem.getUserIDorGroupID()));
//            values.put("from_date", (imTimeLineItem.getDateStart()));
//            values.put("to_date", (imTimeLineItem.getDateEnd()));
//            values.put("is_group_chat", (imTimeLineItem.isGroup() ? 1 : 0));
//            long numOfRow = dOpenHelper.getWritableDatabase().replace(MESSAGE_HISTORY_TIMELINE, null, values);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public void addEntryInMessageTimeLine(String groupOrUser, long fromDate, long toDate,
//                                          boolean isGroupChat) {
//        try {
//            ContentValues values = new ContentValues();
//            values.put("id", System.currentTimeMillis());
//            values.put("group_or_user", groupOrUser);
//            values.put("from_date", fromDate);
//            values.put("to_date", toDate);
//            values.put("is_group_chat", isGroupChat ? 1 : 0);
//            long numOfRow = dOpenHelper.getWritableDatabase().replace(MESSAGE_HISTORY_TIMELINE, null, values);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public void updateEndDateOfLatestTimelineItem(String groupOrUser, long fromDate, long toDate, boolean isGroupChat) {
//        Cursor cursor = null;
//        try {
//
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select id from "
//                            + MESSAGE_HISTORY_TIMELINE + " where  group_or_user = '" + groupOrUser
//                            + "'  order by id desc", null);
//            if (cursor.moveToFirst()) {
//                String id = cursor.getString(cursor.getColumnIndex("id"));
//                ContentValues values = new ContentValues();
//                values.put("to_date", toDate);
//                int n = dOpenHelper.getReadableDatabase().update(MESSAGE_HISTORY_TIMELINE, values, "id  ='" + id
//                        + "'", null);
//            } else
//                addEntryInMessageTimeLine(groupOrUser, fromDate, toDate, isGroupChat);
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        } finally {
//            if (cursor != null)
//                cursor.close();
//        }
//
//    }


//    public void createHistoryFetchingGroupMessageLog(ArrayList<MessageEntry> messageEntries, boolean notifyEnabled) {
//        for (MessageEntry messageEntry : messageEntries) {
//            boolean shouldSkip = defineSkipAndUpdateStatusIfNeeded(messageEntry);
//            if (!shouldSkip) {
//                createGroupMessageLog(messageEntry, notifyEnabled);
//
//            } else {
//                Log.d("localMessage", "createHistoryFetchingMessageLog: skipped");
//            }
//        }
//    }


//    public void createGroup(String callId, String groupId, String groupName,
//                            String numbers, int isCreator, String groupType, int e2e) {
//        Log.v("DatabaseConstants", "createGroup");
//        SQLiteDatabase db = null;
//        if (groupName.length() == 0)
//            groupName = "Group";
//        try {
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, numbers);
//            values.put(KEY_GROUP_ID, groupId);
//            values.put(KEY_GROUP_NAME, groupName);
//            values.put(KEY_IS_CREATOR, isCreator);
//            values.put(KEY_IS_MEMBER, 1);
//            if (groupType != null && groupType.length() > 0) {
//                values.put(KEY_GROUP_TYPE, groupType);
//            }
//            values.put(KEY_IS_ENCRYPTED_GROUP, e2e);
//            db = dOpenHelper.getWritableDatabase();
//            db.replace(IMS_GROUP_TABLE, null, values);
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            context.getContentResolver().notifyChange(GROUP_URI, null);
//            Log.i("datahelper", "group added " + groupName);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//        // if (checkIfMember(groupId) == 0)
//        // createSystemMessage(callId, groupId, "you have added to the group");
//    }


//    private boolean defineSkipAndUpdateStatusIfNeeded(MessageEntry serverMessage) {
//        //gatis start
//        if (serverMessage.isConfide) {
//            return true; //skip confide
//        }
//        if (serverMessage.burnTimeInsec > 0 && serverMessage.time + serverMessage.burnTimeInsec * 1000 < System.currentTimeMillis()) {
//            return true;//skip time passed bund messages
//        }
//        if (serverMessage.futureSendTime > 0 && serverMessage.type != MessageEntry.MessageType.SEND) {
//            return true; //skip fetched future message of others :P
//        }
//
//        //skip if message already in local but just update the status
//        Cursor cursor = null;
//        if (serverMessage.isGroup) {
//            cursor = Database.GroupMessages.Read.byCallId(serverMessage.callerId);
//        } else {
//            cursor = Database.Message.Read.byCallId((serverMessage.callerId));
//        }
//        com.revesoft.itelmobiledialer.chat.chatWindow.Message localMessage = null;
//        if (cursor != null && cursor.moveToFirst()) {
//            localMessage = new com.revesoft.itelmobiledialer.chat.chatWindow.Message(cursor);
//            cursor.close();
//        }
//
//        //status update strategy
//        //1. don't take server status as final status unconditionally
//        //2. if mimeType of local is deleted then don't update
//        //3. if edit count of server message is greater than or equal then local then take server status as final status
//        //4. if edit count of server message is less than local then skip update
//        //5. if edit count from server is -1 then update mime type of local as deleted
//        if (localMessage != null) {
////            Log.d("localMessage", "defineSkipAndUpdateStatusIfNeeded: localMessage found " + count++);
//            if (localMessage.mimeType == MimeType.Deleted) {
//                return true;
//            }
//            if (serverMessage.editCount == -1) {
//                if (localMessage.editCount != -1) {
//                    if (serverMessage.isGroup) {
//                        Database.GroupMessages.Update.markAsDeleted(localMessage.callerId);
//                    } else {
//                        Database.Message.Update.markAsDeleted(localMessage.callerId);
//                    }
//                    return true;
//                }
//            }
//
//            if (serverMessage.editCount >= localMessage.editCount) {
//                if (serverMessage.delivery_status != localMessage.deliveryStatus) {
//                    if (serverMessage.isGroup) {
//                        Database.GroupMessages.Update.deliveryStatus(localMessage.callerId, serverMessage.delivery_status);
//                    } else {
//                        Database.Message.Update.deliveryStatus(localMessage.callerId, serverMessage.delivery_status);
//                    }
//                }
//                return true;
//            }
//            return true;
//        }
//        //gatis end
//        return false;
//    }


//    public void createGroupMessageLog(MessageEntry messageEntry, boolean notifyEnabled) {
//        if (checkForGroupMessage(messageEntry) || messageEntry.editCount == -1) {
//            return;
//        }
//
//        SQLiteDatabase db = null;
//        StringBuilder query = new StringBuilder();
//        try {
//            long currentTime = System.currentTimeMillis();
//            String messageContent = "";
//
//            if (messageEntry.content.startsWith(Constants.LOCATION_PREFIX) && messageEntry.content.endsWith(Constants.LS_SUFIX)) {
//                messageContent = getLocationDescriptionFromMessageContent(messageEntry.content);
//            } else {
//                messageContent = messageEntry.content;
//            }
//
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, messageEntry.number);
//            values.put(KEY_NOTIFICATION, messageEntry.type == MessageEntry.MessageType.SEND ? MessageStatus.READ : messageEntry.status);
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_MESSAGE_TYPE, messageEntry.type);
//            values.put(KEY_GROUP_ID, messageEntry.groupId);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, messageEntry.delivery_status);
//            values.put(KEY_EDIT_COUNT, messageEntry.editCount);
//            values.put(KEY_BROADCAST_ID, messageEntry.broadcastID);
//            if (!TextUtils.isEmpty(messageEntry.filePath)) {
//                values.put(KEY_FILE_PATH, messageEntry.filePath);
//            } else {
//                values.put(KEY_FILE_PATH, "");
//            }
//            values.put(KEY_SEND_ORIGINAL_TIMESTAMP_FLAG, messageEntry.sendOriginalTimestampFlag);
//            values.put(KEY_FUTURE_SEND_TIME, messageEntry.futureSendTime);
//            values.put(KEY_IS_ENCRYPTED, messageEntry.isEncrypted);
//            values.put(KEY_IS_DECRYPTED, messageEntry.isDecrypted);
//            values.put(KEY_TIME, messageEntry.time);
//            values.put(KEY_TRUE_TIMESTAMP, messageEntry.time);
//            values.put(KEY_RECV_TIME, messageEntry.time - UserDataManager.getTimeAdjustment());
//
//            values.put(KEY_MESSAGE_CALL_ID, messageEntry.callerId);
//            values.put(KEY_BURN_TIME, messageEntry.burnTimeInsec);
//            //message quote
//            values.put(KEY_OCID, messageEntry.ocid);
//            values.put(KEY_QCID, messageEntry.qcid);
//            values.put(KEY_QUOTE_DATA, messageEntry.quoteData);
//            values.put(KEY_QUOTE_FROM_USER, messageEntry.quoteFromUser);
//            values.put(KEY_QUOTE_FILE_PATH, messageEntry.quoteMessageFilePath);
//            values.put(KEY_QUOTE_MIME_TYPE, MimeTypeUtil.getMimeType(messageEntry.quoteData).toString());
//            values.put(KEY_LONG_MESSAGE, messageEntry.longMessage);
//            values.put(KEY_IS_IM_READY_FOR_VIEW, messageEntry.getIsReadyForView());
//            values.put(KEY_IS_EMO_ONLY, EmojiHelper.containsEmojiOnly(messageEntry.content) ? 1 : 0);
//            values.put(KEY_IS_CONFIDE, messageEntry.isConfide ? 1 : 0);
//
////            if (!TextUtils.isEmpty(messageEntry.fromTag)) {
////                values.put(KEY_FROM_TAG, messageEntry.fromTag);
////            }
//
//            values.put(XTableKeys.KEY_MIME_TYPE, MimeTypeUtil.getMimeType(messageEntry.content).toString());
//            db = dOpenHelper.getWritableDatabase();
//            long numOfRow = db.replace(GROUP_MESSAGE_TABLE, null, values);
//            if (messageEntry.type == MessageEntry.MessageType.SEND) {
//                int memberCount = 0;
//                if (CommonData.groupIdToMemberCount.containsKey(messageEntry.groupId)) {
//                    memberCount = CommonData.groupIdToMemberCount.get(messageEntry.groupId);
//                } else {
////                    Group group = GroupMessageAssistant.getGroupById(context, messageEntry.groupId);
//                    Cursor cursor = Database.Group.Read.byId(messageEntry.groupId);
//                    com.revesoft.itelmobiledialer.chat.chatWindow.group.Group group = null;
//                    if (cursor != null && cursor.moveToFirst()) {
//                        group = new com.revesoft.itelmobiledialer.chat.chatWindow.group.Group(cursor);
//                    }
//                    memberCount = group.memberCountButMe;
//                }
//                long affectedRows = Database.GroupMessageEligibility.Create.singleEntry(messageEntry.groupId, messageEntry.callerId, memberCount);
//                I.log("affectedRows = " + affectedRows);
//            } else {
//                I.log("received");
//            }
//            if (numOfRow >= 0 && notifyEnabled) {
//                context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public String getLocationDescriptionFromMessageContent(String content) {
//        String messageContent = "";
//        String loc = content.replace(Constants.LOCATION_PREFIX, "");
//        loc = loc.replace(Constants.LS_SUFIX, "");
//        String[] arr = loc.split(",");
//        double lat = 0, lng = 0;
//        try {
//            if (arr.length >= 2) {
//                lat = Double.parseDouble(arr[0].trim());
//                lng = Double.parseDouble(arr[1].trim());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
//        //getting address
//        try {
//            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
//            if (addresses.size() > 0) {
//                String address = addresses.get(0).getAddressLine(0);
//                String city = addresses.get(0).getLocality();
//                String subcity = addresses.get(0).getSubLocality();
//                String substate = addresses.get(0).getSubAdminArea();
//                String state = addresses.get(0).getAdminArea();
//                String country = addresses.get(0).getCountryName();
//                StringBuilder displayableAddress = new StringBuilder();
//                if (address != null) {
//                    displayableAddress.append(address);
//                    if (subcity != null) {
//                        displayableAddress.append(", ").append(subcity);
//                    } else if (city != null) {
//                        displayableAddress.append(", ").append(city);
//                    } else if (substate != null) {
//                        displayableAddress.append(", ").append(substate);
//                    } else if (state != null) {
//                        displayableAddress.append(", ").append(state);
//                    }
//
//                    if (country != null) {
//                        displayableAddress.append(", ").append(country);
//                    }
//
//                    messageContent = new StringBuilder().append(Constants.LOCATION_PREFIX)
//                            .append(lat).append(",").append(lng).append(",")
//                            .append(displayableAddress.toString()).append(Constants.LS_SUFIX).toString()
//                            .replaceAll("'", "''");
//                }
//            } else {
//                messageContent = content;
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//            messageContent = content;
//        }
//        return messageContent;
//    }


//    public void createHistoryFetchingMessageLog(ArrayList<MessageEntry> messageEntries, boolean notifyEnabled) {
//        for (MessageEntry messageEntry : messageEntries) {
//            boolean shouldSkip = defineSkipAndUpdateStatusIfNeeded(messageEntry);
//            if (!shouldSkip) {
//                MessageRepo.get().createMessageLog(messageEntry);
//            } else {
//                Log.d("localMessage", "createHistoryFetchingMessageLog: skipped");
//            }
//        }
//    }


//    public void createMessageLog(MessageEntry messageEntry, boolean notifyEnabled) {
//        if (checkForMessage(messageEntry) || messageEntry.editCount == -1) {
//            return;
//        }
//
//        SQLiteDatabase db = null;
//        StringBuilder query = new StringBuilder();
//        String messageContent = "";
//        try {
//            long currentTime = System.currentTimeMillis();
//
//            if (messageEntry.content.startsWith(Constants.LOCATION_PREFIX) && messageEntry.content.endsWith(Constants.LS_SUFIX)) {
//                messageContent = getLocationDescriptionFromMessageContent(messageEntry.content);
//            } else {
//                messageContent = messageEntry.content;
//            }
//
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, messageEntry.number);
//            values.put(KEY_NOTIFICATION, messageEntry.status);
//            Log.e("printing database entry ", messageContent);
//            values.put(KEY_MESSAGE_CONTENT, messageContent);
//            values.put(KEY_MESSAGE_TYPE, messageEntry.type);
//            values.put(KEY_MESSAGE_DELIVERY_STATUS, messageEntry.delivery_status);
//            values.put(KEY_EDIT_COUNT, messageEntry.editCount);
//            values.put(KEY_BROADCAST_ID, messageEntry.broadcastID);
//            if (!TextUtils.isEmpty(messageEntry.filePath)) {
//                values.put(KEY_FILE_PATH, messageEntry.filePath);
//            } else {
//                values.put(KEY_FILE_PATH, "");
//            }
//            values.put(KEY_SMS_MESSAGE_ID, messageEntry.query_id);
//            values.put(KEY_SEND_ORIGINAL_TIMESTAMP_FLAG, messageEntry.sendOriginalTimestampFlag);
//            values.put(KEY_FUTURE_SEND_TIME, messageEntry.futureSendTime);
//            values.put(KEY_IS_ENCRYPTED, messageEntry.isEncrypted);
//            values.put(KEY_IS_DECRYPTED, messageEntry.isDecrypted);
//            values.put(KEY_LONG_MESSAGE, messageEntry.longMessage);
//            values.put(KEY_IS_IM_READY_FOR_VIEW, messageEntry.getIsReadyForView());
//            values.put(KEY_TIME, messageEntry.time);
//            values.put(KEY_TRUE_TIMESTAMP, messageEntry.time);
//            values.put(KEY_RECV_TIME, messageEntry.time - UserDataManager.getTimeAdjustment());
//
//            values.put(KEY_MESSAGE_CALL_ID, messageEntry.callerId);
//            values.put(KEY_BURN_TIME, messageEntry.burnTimeInsec);
//            values.put(KEY_IS_CONFIDE, messageEntry.isConfide ? 1 : 0);
//
//            //message quote
//            values.put(KEY_OCID, messageEntry.ocid);
//            values.put(KEY_QCID, messageEntry.qcid);
//            values.put(KEY_QUOTE_DATA, messageEntry.quoteData);
//            values.put(KEY_QUOTE_FROM_USER, messageEntry.quoteFromUser);
//            values.put(KEY_QUOTE_FILE_PATH, messageEntry.quoteMessageFilePath);
//            values.put(KEY_QUOTE_MIME_TYPE, MimeTypeUtil.getMimeType(messageEntry.quoteData).toString());
//
//            values.put(KEY_IS_EMO_ONLY, EmojiHelper.containsEmojiOnly(messageContent) ? 1 : 0);
//            values.put(XTableKeys.KEY_MIME_TYPE, MimeTypeUtil.getMimeType(messageContent).toString());
////            if (!TextUtils.isEmpty(messageEntry.fromTag)) {
////                values.put(KEY_FROM_TAG, messageEntry.fromTag);
////            }
//
//            db = dOpenHelper.getWritableDatabase();
//            long numOfRow = db.replace(MESSAGE_TABLE, null, values);
//            if (numOfRow >= 0 && notifyEnabled) {
//                context.getContentResolver().notifyChange(MESSAGE_URI, null);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


//    public void createMultipartMessagesEntry(com.revesoft.itelmobiledialer.signalling.newMessaging.MultipartMessage multiPartMessage) {
//        SQLiteDatabase db = null;
//        try {
//            ContentValues values = new ContentValues();
//            values.put("callerid", multiPartMessage.getCallerID());
//            values.put("calleridlocal", multiPartMessage.getCallerIDLocal());
//            values.put("number", multiPartMessage.getNumber());
//            values.put("date", multiPartMessage.getDate());
//            values.put("groupid", multiPartMessage.getGroupID());
//            values.put("multipart_number", multiPartMessage.getMultipartNumber());
//            values.put("messagecontent", multiPartMessage.getContent());
//            values.put("total_parts", multiPartMessage.getTotalParts());
//            values.put("is_decrypted", multiPartMessage.isDeCrypted);
//            values.put("is_outgoing", multiPartMessage.getIsOutgoing());
////            if (!TextUtils.isEmpty(multiPartMessage.getFromTag())) {
////                values.put(KEY_FROM_TAG, multiPartMessage.getFromTag());
////            }
//            db = dOpenHelper.getWritableDatabase();
//            Log.d("Abhi", "Message Inserted: " +
//                    "" + db.replace(MULTIPART_MESSAGE_TABLE, null, values));
////            context.getContentResolver().notifyChange(MESSAGE_URI, null);
////            context.getContentResolver().notifyChange(SUBSCRIBER_URI, null);
////            context.getContentResolver().notifyChange(MESSAGE_HISTORY_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
//    }

//
//    public Cursor getTimeLineItemByUserOrGroupID(String userOrGroupId) {
//
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = dOpenHelper.getReadableDatabase()
//                    .rawQuery("select * from messageHistoryTimeline where group_or_user = '" + userOrGroupId + "'  order by to_date desc", null);
//        } catch (Exception e) {
//            I.err(e);
//            e.printStackTrace();
//        }
//        return cursor;
//
//    }


//    public void updateFutureMessageSendTime(ArrayList<com.revesoft.itelmobiledialer.chat.chatWindow.Message> messageArrayList) {
//        Log.v("DatabaseConstants", "updateMessageContent");
//        SQLiteDatabase db = null;
//        for (int i = 0; i < messageArrayList.size(); i++) {
//            try {
//                ContentValues values = new ContentValues();
//                values.put(KEY_FUTURE_SEND_TIME, 0);
//                values.put(KEY_TIME, messageArrayList.get(i).futureTime);
//                db = dOpenHelper.getWritableDatabase();
//                long row = db.update(MESSAGE_TABLE, values, KEY_CALLER_ID + "=?",
//                        new String[]{messageArrayList.get(i).callerId});
//            } catch (Exception e) {
//                e.printStackTrace();
//            } finally {
//                // if (db != null)
//                // db.close();
//            }
//        }
//        context.getContentResolver().notifyChange(MESSAGE_URI, null);
//
//    }


//    public Cursor getUnDecyptedGroupMessages(String groupID) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_GROUP_ID + " = '" + groupID + "'   AND  ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 )    AND " + KEY_IS_DECRYPTED + "=" + 0 + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getUnDecryptedMessages(String number, int securityMode) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + MESSAGE_TABLE + " WHERE " + KEY_NUMBER + " = '" + number + "'   AND  ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 )    AND " + KEY_IS_ENCRYPTED + " = " + securityMode + " and " + KEY_IS_DECRYPTED + "=" + 0
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////   if (cursor != null)
////    cursor.close();
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }


//    public Cursor getPendingGroupSMS(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_GROUP_ID + " = '" + number + "' AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.PENDING
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.SMS, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////   if (cursor != null)
////    cursor.close();
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//
//    }

//
//    public Cursor getUnseenGroupMessages(String groupID) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + GROUP_MESSAGE_TABLE + " WHERE " + KEY_GROUP_ID + " = '" + groupID +
//                    "'   AND  ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 )   " +
//                    "AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.SUCCESSFUL
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED + " AND (" +
//                    KEY_MIME_TYPE + "='Text' OR " +
//                    KEY_MIME_TYPE + "='Deleted' OR " +
//                    KEY_MIME_TYPE + "='Link' OR " +
//                    KEY_MIME_TYPE + "='Location' OR " +
//                    KEY_MIME_TYPE + "='StaticSticker' OR " +
//                    KEY_MIME_TYPE + "='LocationRequest') " +
//                    " AND " + KEY_IS_CONFIDE + "=0 ", null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cursor;
//    }

//    public Cursor getUnseenMessagesCallerIdLive(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + MESSAGE_TABLE + " WHERE " + KEY_NUMBER + " = '" + number + "' AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.SUCCESSFUL
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////   if (cursor != null)
////    cursor.close();
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public Cursor getUnseenMessagesCallerIdLive(String number, int securityMode) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + MESSAGE_TABLE + " WHERE " + KEY_NUMBER + " = '" + number + "'   AND  ( (messagetype = 1 AND (long_message is null or long_message = '' or long_message = 'null' )) OR messagetype != 1 )    AND " + KEY_IS_ENCRYPTED + " = " + securityMode + " and " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.SUCCESSFUL
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.RECEIVED + " AND (" +
//                    KEY_MIME_TYPE + "='Text' OR " +
//                    KEY_MIME_TYPE + "='Deleted' OR " +
//                    KEY_MIME_TYPE + "='Link' OR " +
//                    KEY_MIME_TYPE + "='Location' OR " +
//                    KEY_MIME_TYPE + "='StaticSticker' OR " +
//                    KEY_MIME_TYPE + "='LocationRequest') " +
//                    " AND " + KEY_IS_CONFIDE + "=0", null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////   if (cursor != null)
////    cursor.close();
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }
//
//    public Cursor getPendingSMS(String number) {
//        SQLiteDatabase db = null;
//        Cursor cursor = null;
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT * from " + MESSAGE_TABLE + " WHERE " + KEY_NUMBER + " = '" + number + "' AND " + KEY_MESSAGE_DELIVERY_STATUS + "=" + MessageEntry.DeliveryStatus.PENDING
//                    + " AND " + KEY_MESSAGE_TYPE + "=" + MessageEntry.MessageType.SMS, null);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////   if (cursor != null)
////    cursor.close();
//            // if (db != null)
//            // db.close();
//        }
//        return cursor;
//    }

//    public boolean createOrUpdatePersistantSettingsEntry(String key, String value) {
//        ContentValues values = new ContentValues();
//        values.put(PS_KEY, key);
//        values.put(PS_VALUE, value);
//
//        SQLiteDatabase db = null;
//
//        try {
//            String tempValue = getValuefromPersistantSettings(key);
//            db = dOpenHelper.getWritableDatabase();
//            if (!TextUtils.isEmpty(tempValue)) {
//                db.update(DatabaseConstants.PERSISTANT_SETTINGS, values, "", null);
//            } else {
//                db.insert(DatabaseConstants.PERSISTANT_SETTINGS, null, values);
//            }
//            return true;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }

//    public String getValuefromPersistantSettings(String key) {
//        Cursor cursor = null;
//        SQLiteDatabase db = null;
//
//        try {
//            db = dOpenHelper.getReadableDatabase();
//            cursor = db.rawQuery("SELECT value from " + DatabaseConstants.PERSISTANT_SETTINGS + " where id = '" + key + "';", null);
//            if (cursor.moveToFirst() && cursor.getCount() > 0) {
//                return cursor.getString(cursor.getColumnIndex(DatabaseConstants.PS_VALUE));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

//    public void updateChatHiddenStatus(String number, int isEncrypted, boolean willBeHidden) {
//        Log.e("DatabaseConstants", "update chats hiddend status");
//        SQLiteDatabase db = null;
//
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, number);
//            values.put(KEY_GROUP_ID, "");
//            values.put(KEY_IS_ENCRYPTED, isEncrypted);
//            values.put(KEY_PIN_CODE, "");
//            values.put(KEY_IS_GROUP_CHAT, 0);
//            if (willBeHidden)
//                db.insert(HIDDEN_MESSAGE_TABLE, null, values);
//            else //willBeHidden == false
//                db.delete(HIDDEN_MESSAGE_TABLE, KEY_NUMBER + "=? AND " + KEY_IS_ENCRYPTED + "=?", new String[]{number, Integer.toString(isEncrypted)});
//            //db.update(HIDDEN_MESSAGE_TABLE, values, KEY_NUMBER + " = ? AND " + KEY_IS_ENCRYPTED + " = ?", new String[]{number, isEncrypted});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }

//    public void updateGroupChatHiddenStatus(String groupID, int isEncrypted, boolean willBeHidden) {
//        Log.v("DatabaseConstants", "update group chats hiddend status");
//        SQLiteDatabase db = null;
//        try {
//            db = dOpenHelper.getWritableDatabase();
//            ContentValues values = new ContentValues();
//            values.put(KEY_NUMBER, "");
//            values.put(KEY_GROUP_ID, groupID);
//            values.put(KEY_IS_ENCRYPTED, isEncrypted);
//            values.put(KEY_PIN_CODE, "");
//            values.put(KEY_IS_GROUP_CHAT, 1);
//            if (willBeHidden)
//                db.insert(HIDDEN_MESSAGE_TABLE, null, values);
//            else //willBeHidden == false
//                db.delete(HIDDEN_MESSAGE_TABLE, KEY_GROUP_ID + "=?", new String[]{groupID});
//            //db.update(HIDDEN_MESSAGE_TABLE, values, KEY_NUMBER + " = ? AND " + KEY_IS_ENCRYPTED + " = ?", new String[]{number, isEncrypted});
//            context.getContentResolver().notifyChange(MESSAGE_URI, null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // if (db != null)
//            // db.close();
//        }
//    }



}