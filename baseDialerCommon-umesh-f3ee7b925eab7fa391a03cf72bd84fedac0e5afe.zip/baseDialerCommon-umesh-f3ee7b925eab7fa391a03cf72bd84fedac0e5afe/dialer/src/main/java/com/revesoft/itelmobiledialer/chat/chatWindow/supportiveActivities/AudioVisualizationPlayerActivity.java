package com.revesoft.itelmobiledialer.chat.chatWindow.supportiveActivities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.plattysoft.leonids.ParticleSystem;
import com.plattysoft.leonids.modifiers.ScaleModifier;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.ims.imhelper.TimePickerDoneClickListner;
import com.revesoft.itelmobiledialer.ims.imhelper.TimePickerHelper;
import com.revesoft.itelmobiledialer.theme.Theme;
import com.revesoft.itelmobiledialer.theme.ThemeManager;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.FileUtil;
import com.revesoft.material.R;

import java.io.IOException;
import java.math.BigDecimal;


/**
 * @author ashikee on 10/30/16.
 * modified by Ifta on 28 Feb, 2018
 */
public class AudioVisualizationPlayerActivity extends BaseActivity implements TimePickerDoneClickListner, AudioManager.OnAudioFocusChangeListener {

    public static void startAudioVisualization(Context context, String filePath, boolean isPlayOnlyMode) {
        Intent audioPlayActivityIntent = new Intent(context, AudioVisualizationPlayerActivity.class);
        audioPlayActivityIntent.putExtra("filePath", filePath);
        audioPlayActivityIntent.putExtra("isPlayOnlyMode", isPlayOnlyMode);
        audioPlayActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        audioPlayActivityIntent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        context.startActivity(audioPlayActivityIntent);
    }

    public Context c;
    public Dialog d;
    public AudioVisualizationPlayerActivity cd;
    ImageView ivPlayPause;
    boolean isPlaying;
    String filePath;
    AudioMessage audioMessage = new AudioMessage(filePath);
    AudioPlayer audioPlayer;
    CountDownTimer audioPlayerTimer = null;
    ParticleSystem particleSystem, particleSystemTwo, particleSystemThree;

    boolean isPlayOnlyMode;
    Activity activity;
    ImageView ivSend, ivSendInFuture;
    private int playButtonResourceId = 0;
    private int pauseButtonResourceId = 0;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.audio_preview_activity_layout);

        if (getIntent().hasExtra("filePath")) {
            filePath = this.getIntent().getStringExtra("filePath");
            isPlayOnlyMode = this.getIntent().getBooleanExtra("isPlayOnlyMode", false);

        } else {
            finish();
        }

        if (filePath == null) {
            finish();
        }
        Theme theme = ThemeManager.getTheme();
        switch (theme) {
            case Bounty:
                playButtonResourceId = R.drawable.ic_play_bounty;
                pauseButtonResourceId = R.drawable.ic_pause_bounty;
                break;
            case Blue:
            case Graphite:
            default:
                playButtonResourceId = R.drawable.ic_play_black;
                pauseButtonResourceId = R.drawable.ic_audio_pause;
                break;
        }

        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying) {
                    audioPlayer.stop();
                }
                finish();
            }
        });


        ivSend = (ImageView) findViewById(R.id.image_audio_send);
        ivSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying) {
                    audioPlayer.stop();
                }
                Sender.getAccess().sendFile(filePath);
                finish();
            }
        });
        ivSendInFuture = (ImageView) findViewById(R.id.image_audio_send_in_future);
        ivSendInFuture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying) {
                    audioPlayer.stop();
                }
                TimePickerHelper timePickerHelper = new TimePickerHelper(AudioVisualizationPlayerActivity.this, AudioVisualizationPlayerActivity.this);
                timePickerHelper.showDateTimePicker();
            }
        });


        if (isPlayOnlyMode) {
            ivSend.setVisibility(View.GONE);
            ivSendInFuture.setVisibility(View.GONE);
        }

        audioMessage = new AudioMessage(filePath);
        audioMessage.setPlayPauseIconImageView((ImageView) findViewById(R.id.imageViewPlayPause));
        audioMessage.setDurationTextView((TextView) findViewById(R.id.tv_timer));
        audioMessage.seekbar = (SeekBar) findViewById(R.id.seekBar);
        audioMessage.seekbar.setMax((int) audioMessage.duration);
        audioMessage.seekbar.setProgress(0);
        audioMessage.seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                audioMessage.setCurrentPosition(seekBar.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (isPlaying) {
                    isPlaying = false;
                    stopVisualization();
                    audioPlayer.playOrResumeAudio(audioMessage);
                }

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                audioMessage.setCurrentPosition(seekBar.getProgress());
                if (!isPlaying) {
                    isPlaying = true;
                    audioPlayer.playOrResumeAudio(audioMessage);
                    startVisualization();
                } else {
                    isPlaying = false;
                    audioPlayer.playOrResumeAudio(audioMessage);
                    stopVisualization();

                }

            }
        });

        audioMessage.seekbar.setEnabled(true);
        audioPlayer = new AudioPlayer();
        this.isPlaying = false;

        ivPlayPause = (ImageView) findViewById(R.id.imageViewPlayPause);
        ivPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAudioFocus();
                if (!isPlaying) {
                    isPlaying = true;
                    audioPlayer.playOrResumeAudio(audioMessage);
                    startVisualization();
                } else {
                    isPlaying = false;
                    stopVisualization();
                    audioPlayer.playOrResumeAudio(audioMessage);
                }

            }
        });
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startPlaying();
            }
        }, 500);


    }

    private void checkAudioFocus() {
        AudioManager mAudioManager = (AudioManager) AppContext.getAccess().getContext().getSystemService(AUDIO_SERVICE);
        if (mAudioManager.isMusicActive()) {
            int result = mAudioManager.requestAudioFocus(AudioVisualizationPlayerActivity.this, AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN);
        }
    }



    private void startPlaying() {
        isPlaying = true;
        audioPlayer.playOrResumeAudio(audioMessage);
        startVisualization();
    }

    private void stopVisualization() {
        if (particleSystem != null &&
                particleSystemTwo != null &&
                particleSystemThree != null
                ) {
            try {
                particleSystem.cancel();
                particleSystemTwo.cancel();
                particleSystemThree.cancel();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isPlaying) {
            audioPlayer.stop();
        }
        finish();
    }

    @Override
    public void onDoneClick(long time) {
        Sender.getAccess().sendFutureFile(filePath, time, false);
        finish();
    }

    private void startVisualization() {
        boolean shouldPlayFireWorks = PreferenceDataManager.quickGet(Constants.VISUALIZATION_OF_VOICE_MESSAGES, true);
        if (!shouldPlayFireWorks) return;
        int timeToLive = 1100;
        View anchor = findViewById(R.id.visualizerViewCenter);
        particleSystem = new ParticleSystem(this, 100, R.drawable.star_bounty, timeToLive);
        particleSystem.setScaleRange(0.7f, 1.3f);
        particleSystem.setSpeedRange(0.1f, 0.25f);
        particleSystem.setRotationSpeedRange(90, 180);
        particleSystem.setFadeOut(200, new AccelerateInterpolator());
        particleSystem.addModifier(new ScaleModifier(0.5f, 1.5f, 0, timeToLive));
        particleSystem.emit(anchor, 35);

        particleSystemTwo = new ParticleSystem(this, 100, R.drawable.star_blue, timeToLive);
        particleSystemTwo.setScaleRange(0.7f, 1.3f);
        particleSystemTwo.setSpeedRange(0.1f, 0.25f);
        particleSystemTwo.setRotationSpeedRange(90, 180);
        particleSystemTwo.setFadeOut(200, new AccelerateInterpolator());
        particleSystem.addModifier(new ScaleModifier(0.5f, 1.5f, 0, timeToLive));
        particleSystemTwo.emit(anchor, 35);

        particleSystemThree = new ParticleSystem(this, 100, R.drawable.star_graphite, timeToLive);
        particleSystemThree.setScaleRange(0.7f, 1.3f);
        particleSystemThree.setSpeedRange(0.1f, 0.25f);
        particleSystemThree.setRotationSpeedRange(90, 180);
        particleSystemThree.setFadeOut(200, new AccelerateInterpolator());
        particleSystem.addModifier(new ScaleModifier(0.5f, 1.5f, 0, timeToLive));
        particleSystemThree.emit(anchor, 35);
    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        Log.d("AudioManager", "get audio focus");
    }


    /**
     * Wrapper class of android's MediaPlayer API. This class should only be
     * used to play the audio files sent/recieved on IM.
     */
    class AudioPlayer extends MediaPlayer {
        /**
         * last audio message the player was playing
         * <p>
         * when a new play request comes while the player is already playing,
         * player will call the pause function of the previous request, start
         * processing the request, remove the previous request from the
         * variable, and store the new message in the var
         * </p>
         */
        AudioMessage currentlyPlaying = null;

        AudioPlayer() {
            super();
            setScreenOnWhilePlaying(true);
            setAudioStreamType(AudioManager.STREAM_MUSIC);
        }

        /**
         * The player puts its current streaming to pause and plays/resumes the
         * audioMessage
         *
         * @param audioMessage : AudioMessage to play/resume
         */
        public void playOrResumeAudio(final AudioMessage audioMessage) {
            try {
                if (isPlaying()) {
                    pauseAudio(currentlyPlaying);
                    return;
                }
                currentlyPlaying = audioMessage;
//                setDataSource(audioMessage.getFilePath());
                setDataSource(AudioVisualizationPlayerActivity.this, FileUtil.getContentUri(audioMessage.getFilePath()));
                setOnCompletionListener(new OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        reset();
                        audioMessage.setCurrentPosition(0);
                        audioMessage.changeViewsWhenPaused();
                        audioMessage
                                .setDurationText(audioMessage.getDuration());
                        audioMessage.seekbar.setProgress(0);
                        stopVisualization();
                        isPlaying = false;
                    }
                });
                audioPlayer.prepare();

                // resume from previous pause
                final int currentPosition = audioMessage.getCurrentPosition();
                audioPlayer.seekTo(currentPosition);

                audioPlayer.start();

                // cancel previous timers
                if (audioPlayerTimer != null) {
                    audioPlayerTimer.cancel();
                }
                // start new timer
                audioPlayerTimer = new CountDownTimer(
                        audioMessage.getDuration() - currentPosition, 100) {
                    long current = currentPosition;

                    @Override
                    public void onTick(long l) {
                        current += 100;
                        audioMessage.setCurrentPosition(getCurrentPosition());
                        audioMessage.seekbar.setProgress((int) current);
                    }

                    @Override
                    public void onFinish() {
                    }
                }.start();
                audioMessage.changeViewsPlayed();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ArithmeticException ae) {
                ae.printStackTrace();
            }

        }

        /**
         * Pauses the audioMessage
         *
         * @param audioMessage : which AudioMessage to pause
         */
        public void pauseAudio(AudioMessage audioMessage) {
            audioMessage.setCurrentPosition(getCurrentPosition());
            pause();
            reset();
            audioMessage.setIsCurrentlyPlaying(false);
            audioMessage.changeViewsWhenPaused();
            audioPlayerTimer.cancel();
        }
    }

    class AudioMessage {
        long duration;
        long currentPosition = 0;
        String filePath;
        boolean isCurrentlyPlaying = false;
        ImageView playPauseIcon;
        TextView playPauseTextView;
        TextView durationTextView;
        SeekBar seekbar;

        /**
         * Constructor.
         *
         * @param filepath : absolute path of the audio file.
         */
        public AudioMessage(String filepath) {
            filePath = filepath;
            duration = getDurationInMilliSeconds(filePath);

        }

        /**
         * Extracts the duration from the given filepath.
         *
         * @param filePath : absulate path of the audio file.
         * @return : duration of the audio file in milliseconds long
         */
        private long getDurationInMilliSeconds(String filePath) {
            try {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD) {
                    MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                    try {
                        metaRetriever.setDataSource(filePath);
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        return 0;
                    }
                    String duration = metaRetriever
                            .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    Log.d("Asif", "Duration before parsing - " + duration);
                    metaRetriever.release();
                    return Long.parseLong(duration);
                } else {
                    return 0;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return 0;
            }
        }

        /**
         * Changes the necessary UI when the streaming of this audio message is
         * played
         */
        public void changeViewsPlayed() {
            isCurrentlyPlaying = true;
            playPauseIcon.setImageResource(pauseButtonResourceId);
//            playPauseTextView.setText(getResources().getString(
//                    R.string.pause_audio_im));
        }

        /**
         * Changes the necessary UI when the streaming of this audio message is
         * paused
         */
        public void changeViewsWhenPaused() {
            isCurrentlyPlaying = false;
            playPauseIcon.setImageResource(playButtonResourceId);
//            playPauseTextView.setText(getResources().getString(
//                    R.string.play_audio_im));
        }

        /**
         * Parses the millisecond duration to a readable minute:seconds string
         * structure
         *
         * @param milliseconds : duration in long
         * @return : readable duration in String
         */
        public String parseDuration(long milliseconds) {
            if (milliseconds <= 0)
                return "0:00";
            String out = "";
            int sec = (int) (milliseconds % 60000) / 1000;
            int min = (int) milliseconds / 60000;
            String seconds = (sec < 10) ? ("0" + sec) : (sec + "");
            out = min + ":" + seconds;
            Log.d("Asif", "Duration after parsing - " + out);
            return out;
        }

        // getter setters
        // duration
        public long getDuration() {
            return duration;
        }

        public void setDuration(long duration) {
            this.duration = duration;
        }

        // filepath
        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        // current position
        public int getCurrentPosition() throws ArithmeticException {
            return new BigDecimal(currentPosition).intValueExact();
        }

        /**
         * Sets the Current position in the streaming
         *
         * @param currentPosition
         */
        public void setCurrentPosition(long currentPosition) {
            this.currentPosition = currentPosition;
            setDurationText(currentPosition);
        }

        /**
         * Checks if this audio message is currently playing or not
         *
         * @return true if currently playing, otherwise false
         */
        public boolean isCurrentlyPlaying() {
            return isCurrentlyPlaying;
        }

        /**
         * Sets if this audio message is currently streaming or not
         *
         * @param isCurrentlyPlaying
         */
        public void setIsCurrentlyPlaying(boolean isCurrentlyPlaying) {
            this.isCurrentlyPlaying = isCurrentlyPlaying;
        }

        // playPause Icon
        public ImageView getPlayPauseIcon() {
            return playPauseIcon;
        }

        public void setPlayPauseIconImageView(ImageView playPauseIcon) {
            this.playPauseIcon = playPauseIcon;
            this.playPauseIcon.setImageResource(playButtonResourceId);
        }

        public void setPlayPauseIcon(Context context, int id) {
            this.playPauseIcon.setImageDrawable(getResources().getDrawable(id));
        }

        // play pause text view
        public TextView getPlayPauseTextView() {
            return playPauseTextView;
        }

        public void setPlayPauseTextView(TextView playPauseTextView) {
            this.playPauseTextView = playPauseTextView;
            this.playPauseTextView.setText(R.string.play_audio_im);
        }

        public void setPlayPauseTextViewText(String text) {
            this.playPauseTextView.setText(text);
        }

        // duration textview
        public void setDurationTextView(TextView textView) {
            this.durationTextView = textView;
            this.durationTextView.setText("   (" + getDuration(filePath) + ")   ");
        }

        private String getDuration(String filePath) {
            // load data file
            try {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD) {
                    MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                    try {
                        metaRetriever.setDataSource(filePath);
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        return "00:00";
                    }

                    String out = "";

                    // convert duration to minute:seconds
                    String duration = metaRetriever
                            .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    Log.d("Asif", "Duration before parsing - " + duration);
                    long dur = Long.parseLong(duration);
                    int sec = (int) (dur % 60000) / 1000;
                    int min = (int) dur / 60000;
                    // String seconds = String.valueOf((dur % 60000) / 1000);
                    //
                    // String minutes = String.valueOf(dur / 60000);
                    String seconds = (sec < 10) ? ("0" + sec) : (sec + "");
                    out = min + ":" + seconds;
                    /*
                     * if (seconds.length() == 1) { txtTime.setText("0" + minutes + ":0"
                     * + seconds); }else { txtTime.setText("0" + minutes + ":" +
                     * seconds); }
                     */
                    Log.d("Asif", "Duration after parsing - " + out);
                    // close object
                    metaRetriever.release();
                    return out;
                } else {
                    return "00:00";
                }
            } catch (Exception e) {
                return "00:00";
            }
        }

        /**
         * Sets the duration in the durationTextView
         *
         * @param duration
         */
        public void setDurationText(long duration) {
            durationTextView.setText(parseDuration(duration));
        }
    }


    @Override
    public void onBackPressed() {
        this.audioPlayer.stop();
        super.onBackPressed();
    }
}
