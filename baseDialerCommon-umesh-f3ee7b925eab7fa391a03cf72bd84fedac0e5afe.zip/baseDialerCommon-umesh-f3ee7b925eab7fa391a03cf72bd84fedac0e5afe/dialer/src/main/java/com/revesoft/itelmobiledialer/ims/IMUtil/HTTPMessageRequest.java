package com.revesoft.itelmobiledialer.ims.IMUtil;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.material.R;

import java.io.File;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * Created by Acer on 4/16/2017.
 */

public class HTTPMessageRequest {

    private Context context;
    public HTTPMessageRequest(Context context)
    {
        this.context=context;
    }

    public void sendFileViaHTTPRetry(String callerId, String filePath, String number, boolean isGroupChat, String groupId)
    {
        File file=new File(filePath);
        Log.e("HTTP"," file size: "+file.length());
        if(file!= null && file.length()> Constants.FILE_SIZE_THRESHOLD)
        {
            showtooBigFileDialog(context.getString(R.string.too_big_file));
        }
        else {
            Log.e(" normal group file path", " " + filePath);

            filePath=filePath.replace(IMConstants.SEND_FILE_PREFIX, "").replace(IMConstants.SEND_FILE_SUFFIX, "");
            if (isGroupChat) {
                sendIntentMessageFileUploadToDialer(Constants.COMMAND_FILE_UPLOARD_RETRY, "", groupId, filePath, callerId);
                // DatabaseConstants.getInstance(context).createGroupMessageLog(m);
            } else {
                sendIntentMessageFileUploadToDialer(Constants.COMMAND_FILE_UPLOARD_RETRY, number, "", filePath,callerId);
                //DatabaseConstants.getInstance(context).createMessageLog(m);
            }
        }
    }
    private void sendIntentMessageFileUploadToDialer(String fileUpload, String number, String groupId, String filePath, String callerId) {
        Log.d("Abhi", "File Transfer"+"sendIntentMessageFileUploadToDialer");
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(fileUpload, new String[] { number, groupId,filePath,callerId });
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }
    private void showtooBigFileDialog(String message) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.alert_message_max_length);
        TextView tv = dialog.findViewById(R.id.tv_text);
        tv.setText(message);

        Button btnOk = dialog.findViewById(R.id.dialog_ok_button);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });


        dialog.setCancelable(false);
        dialog.show();
    }
}
