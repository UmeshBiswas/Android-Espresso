package com.revesoft.itelmobiledialer.dialogues;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

/**
 * Created by dpaul on 4/2/15.
 */
public class AlertDialogActivity extends Activity {
    public static final String MESSAGE = "message";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String message = getIntent().getStringExtra(MESSAGE);
        if(message == null){
            finish();
            return;
        }

        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        bld.setMessage(message);
        bld.setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        Log.d("RateFragment", "Showing alert dialog: " + message);
        AlertDialog dlg = bld.create();
        dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                finish();
            }
        });
        dlg.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                finish();
            }
        });
        dlg.show();
    }

//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.dialog_notificaion);
//
//        String message = getIntent().getStringExtra(MESSAGE);
//        if(message != null){
//            ((TextView)findViewById(R.id.message)).setText(message);
//        } else {
//            finish();
//        }
//
//        findViewById(R.id.buttonOK).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//    }
//
//    @Override
//    protected void onNewIntent(Intent intent) {
//        super.onNewIntent(intent);
//
//        if(intent == null)
//            return;
//
//        String message = intent.getStringExtra(MESSAGE);
//        if(message != null){
//            ((TextView)findViewById(R.id.message)).setText(message);
//        } else {
//            finish();
//        }
//
//    }
}
