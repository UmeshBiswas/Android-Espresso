package com.revesoft.itelmobiledialer.chat.chatList;

import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModel;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;
import androidx.paging.LivePagedListBuilder;
import androidx.paging.PagedList;

public class ChatListViewModel extends FilterableViewModel<ChatListItem> {

    @Override
    protected LiveData<PagedList<ChatListItem>> prepareFilteredData() {
        DataSource.Factory<Integer, QueryItemChatList> dataSourceMessage = MessageRepo.get().getPagedChatHistoryListWithFilter(searchFilter);
        DataSource.Factory<Integer, ChatListItem> dataSourceChatList = dataSourceMessage.mapByPage(input -> {
            List<ChatListItem> list = new ArrayList<>();
            for (int i = 0; i < input.size(); i++) {
                QueryItemChatList message = input.get(i);
                list.add(ChatListItem.from(message));
            }
            return list;
        });
        return new LivePagedListBuilder<>(dataSourceChatList, 10).build();
    }
}
