package com.revesoft.itelmobiledialer.hack;

import com.revesoft.itelmobiledialer.signup.SignUpType;

public class Hack {
    private static final Hack HACK = new Hack();

    public static Hack hack() {
        return HACK;
    }

    public SignUpType getSignUpType(){
        return SignUpType.FIREBASE___NUMBER;
    }

}
