package com.revesoft.itelmobiledialer.ims;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.revesoft.material.R;
import com.revesoft.itelmobiledialer.util.BaseActivity;

import java.io.File;
import java.net.MalformedURLException;

public class AudioPlayerActivity extends BaseActivity {

    String filePath = "";
    ProgressBar mProgress;
    ImageView playPauseButton;
    TextView audioFileName;
    int currentPostion = -1;
    MediaPlayer audioPlayer;
    CountDownTimer timer = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_player);

        mProgress = (ProgressBar) findViewById(R.id.audio_progress_bar);
        playPauseButton = (ImageView) findViewById(R.id.play_pause_imageview);
        audioFileName = (TextView) findViewById(R.id.audio_file_name_text_view);

        filePath = getIntent().getStringExtra("AUDIO_FILE_PATH");

        if(filePath==null || filePath.length()==0)
        {
            finish();
            Toast.makeText(this, "Audio file not found!", Toast.LENGTH_LONG).show();
            return;
        }

        File file = new File(filePath);
        if(!file.exists() || !determineFileMimeType(file).contains("audio"))
        {
            finish();
            Toast.makeText(this, "Unsupported types!", Toast.LENGTH_LONG).show();
            return;
        }

        audioFileName.setText(file.getName());
        playPauseButton.setImageResource(R.drawable.ic_message_audio_pause);

        playPauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                try
                {
                    if(audioPlayer.isPlaying())
                    {
                        playPauseButton.setImageResource(R.drawable.ic_message_audio_play);
                        currentPostion = audioPlayer.getCurrentPosition();
                        audioPlayer.pause();
                        if(timer != null)
                            timer.cancel();
                    }
                    else
                    {
                        playPauseButton.setImageResource(R.drawable.ic_message_audio_pause);
                        audioPlayer.seekTo(currentPostion);
                        audioPlayer.start();
                        if(timer != null)
                            timer.cancel();
                        timer = new CountDownTimer(audioPlayer.getDuration() - currentPostion + 300, 200) {
                            @Override
                            public void onTick(long millisUntilFinished) {
                                mProgress.getHandler().post(new Runnable() {
                                    @Override
                                    public void run() {
                                        mProgress.setProgress(audioPlayer.getCurrentPosition() * 100 / audioPlayer.getDuration());
                                    }
                                });
                            }

                            @Override
                            public void onFinish() {

                            }
                        };
                        timer.start();
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        });

        try {
            audioPlayer = new MediaPlayer();
//            audioPlayer.setScreenOnWhilePlaying(true);
//            audioPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            audioPlayer.setDataSource(filePath);
            audioPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    finish();
                }
            });
            Log.w("Asif", "AudioPlayerActivity before prepare");
            audioPlayer.prepare();
            audioPlayer.start();
            Log.w("Asif", "AudioPlayerActivity after start");
            timer = new CountDownTimer(audioPlayer.getDuration() + 300, 200) {
                @Override
                public void onTick(long millisUntilFinished) {
                    mProgress.setProgress(audioPlayer.getCurrentPosition() * 100 / audioPlayer.getDuration());
                }

                @Override
                public void onFinish() {

                }
            };
            timer.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String determineFileMimeType(File file) {
        String mimeType = null;
        try {
            String fileUrl = file.toURI().toURL().toString();
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(fileUrl).toLowerCase();
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
        } catch (MalformedURLException e) {

            Log.e("Mkhan", "Exception in determineFileMimeType");
            e.printStackTrace();
        } catch (NullPointerException e) {

            e.printStackTrace();
            Log.e("Mkhan", "Exception in determineFileMimeType");
        }

        return mimeType;

    }

    @Override
    protected void onPause() {
        super.onPause();
        if(audioPlayer!=null && audioPlayer.isPlaying())
        {
            playPauseButton.setImageResource(R.drawable.ic_message_audio_play);
            currentPostion = audioPlayer.getCurrentPosition();
            audioPlayer.pause();
            if(timer != null)
                timer.cancel();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(timer != null)
            timer.cancel();
        if(audioPlayer!=null)
        {
            audioPlayer.stop();
            audioPlayer.release();
        }
    }
}
