package com.revesoft.itelmobiledialer.chat.chatWindow.bridge;

import com.revesoft.itelmobiledialer.chat.chatWindow.Message;

/**
 * @author Ifta on 2/26/2018.
 */

public interface ChatWindowEventListener {
    void onChatWindowEvent(ChatWindowEvent event);
    void onChatWindowEvent(ChatWindowEvent event, String data);
    void onChatWindowEvent(ChatWindowEvent event, int data);
    void onChatWindowEvent(ChatWindowEvent event, Message message);
}
