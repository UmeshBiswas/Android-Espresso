package com.revesoft.itelmobiledialer.account;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.GridView;

import com.revesoft.itelmobiledialer.adapter.ChatBackgroundImageGridAdapter;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.ViewSetup;
import com.revesoft.material.R;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;


/**
 * @author Ifta
 * on 12/18/2016.
 */

public class ChatBackgroundSelectionActivity extends BaseActivity {
    GridView gv;
    Toolbar toolbar;
    Integer[] backgrounds = new Integer[]{R.drawable.bg0, R.drawable.bg1, R.drawable.bg2};
    String key;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ims_background_selection_layout);
        handleToolbar();
        key = getIntent().getStringExtra(Constants.IMS.CHAT_BACKGROUND_PICK_FOR);
        if (key == null) {
            key = Constants.IMS.DEFAULT_BACKGROUND_KEY;
        }
        key += Constants.CHAT_BACKGROUND;
        gv = findViewById(R.id.gvBackgroundDisplay);
        ChatBackgroundImageGridAdapter adapter = new ChatBackgroundImageGridAdapter(this, 0, backgrounds);
        gv.setAdapter(adapter);
        gv.setOnItemClickListener((adapterView, view, position, id) -> {
            PreferenceDataManager.quickPut(key, backgrounds[position]);
            ChatWindowEventHook.dispatchEvent(ChatWindowEvent.BackgroundChanged);
            finish();
        });
    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        ViewSetup.setUpToolbar(this, toolbar, getString(R.string.background), true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.background_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.actionBackgroundRemove:
                PreferenceDataManager.quickPut(key + Constants.CHAT_BACKGROUND, 0);
                ChatWindowEventHook.dispatchEvent(ChatWindowEvent.BackgroundChanged);
                finish();
                return true;

            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return false;
    }
}
