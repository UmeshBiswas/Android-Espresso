package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.CallLog;
import com.revesoft.itelmobiledialer.callog.callLogList.QueryItemCallLogList;
import com.revesoft.itelmobiledialer.databaseentry.CallLogEntry;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;
import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface CallLogDao extends BaseDao<CallLog> {
    @Query("SELECT * FROM log")
    List<CallLog> getAll();

    @Query("SELECT * FROM log WHERE number=:number")
    List<CallLog> getAllByNumber(String number);

    @Query("SELECT * FROM log WHERE number=:number")
    LiveData<List<CallLog>> getAllLiveByNumber(String number);

    @Query("SELECT * FROM LOG WHERE number=:number ORDER BY _id DESC")
    List<CallLog> getCallLogByNumber(String number);

    @Query("SELECT * FROM log order by date desc")
    LiveData<List<CallLog>> getAllLive();

    @Query("SELECT * FROM log order by date desc")
    DataSource.Factory<Integer, CallLog> getAllLivePaged();

    @Query("SELECT callId,c.number as number,l.processed_number as processedNumber,c.name as name," +
            "type, date, duration, call_type,call_rate,is_video_call FROM log l left join contacts c " +
            "on (l.processed_number=c.processed_number) " +
            "where l.number like :filter OR l.processed_number like :filter or name like :filter " +
            "group by callId order by date desc")
    DataSource.Factory<Integer, QueryItemCallLogList> getAllLivePagedFiltered(String filter);


    @Query("DELETE FROM log WHERE callId=:id")
    void DeleteByCallID(String id);


    @Query("SELECT count(*) AS cnt FROM LOG WHERE duration > :specificDuration and type = 0")
    int callLogCountOverSpecificDuration(long specificDuration);



    @Query("SELECT number FROM LOG LIMIT 1")
    String lastDialerNumber();



    @Query("SELECT * FROM LOG WHERE type="+CallLogEntry.CallLogType.MISSED)
    List<CallLog> getMissedCall();


    @Query("DELETE FROM LOG WHERE _id=:callLogId")
    void deleteById(int callLogId);

    @Query("DELETE FROM LOG")
    void deleteAll();

    @Query("SELECT  _id,  number, count(number) AS cnt FROM LOG GROUP BY number ORDER BY cnt DESC LIMIT :limit ")
    Cursor getMostCalledLogs(int limit);





}
