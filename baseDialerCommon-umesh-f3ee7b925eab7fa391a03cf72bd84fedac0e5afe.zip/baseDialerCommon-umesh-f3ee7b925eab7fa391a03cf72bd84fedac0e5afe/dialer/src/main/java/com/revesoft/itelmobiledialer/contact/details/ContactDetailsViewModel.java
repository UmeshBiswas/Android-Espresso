package com.revesoft.itelmobiledialer.contact.details;

import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;

import java.util.List;

import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

public class ContactDetailsViewModel extends ViewModel {
    LiveData<ContactDetails> contactDetailsLiveData;

    public ContactDetailsViewModel(String contactId) {
        contactDetailsLiveData = Transformations.map(ContactRepo.get().getByContactId(contactId), new Function<List<Contact>, ContactDetails>() {
            @Override
            public ContactDetails apply(List<Contact> contacts) {
                return ContactDetails.from(contacts);
            }
        });
    }

    LiveData<ContactDetails> getContactDetailsLiveData() {
        return contactDetailsLiveData;
    }

}
