package com.revesoft.itelmobiledialer.did;

import android.app.LoaderManager;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.database.SQLException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.DIDRepo;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.signalling.SIPProvider;
import com.revesoft.itelmobiledialer.topup.TopUpLogReportActivity;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Country;
import com.revesoft.itelmobiledialer.util.CountryInfoProvider;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import java.util.ArrayList;

import androidx.appcompat.widget.Toolbar;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static com.revesoft.itelmobiledialer.util.Constants.PHONE;
import static com.revesoft.itelmobiledialer.util.Constants.UNKNOWN_CALLER_ID;


public class CallerIDSelectionActivity extends BaseActivity implements LoaderManager.LoaderCallbacks<Cursor>, View.OnClickListener, OnDidResponseListener {
    public static final String SELECTED_DID_ID = "did_id";

    private String selectedCallerID;
    private SharedPreferences preferences;
    private int selectedCallerIdPosition = 0;
    private String TAG = "CallerIDSelectionActivity";
    private ListView listView;
    private DidListAdapter didListAdapter;
    private ArrayList<String> didIdsArrayList;
    private Cursor cursor = null;

    private boolean isDialogVisible;


    private Handler handler;

    public static void startForTesting(Context context) {
        Intent intent = new Intent(context, CallerIDSelectionActivity.class);
        context.startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_callerid_selection);
        handler = new Handler(getMainLooper());
        handleToolbar();
        initView();
        didListAdapter = new DidListAdapter(null);
        listView.setAdapter(didListAdapter);
        getLoaderManager().initLoader(0, null, this);
        preferences = getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);

        if (preferences.getBoolean("first_in_settings", true)) {

            preferences.edit().putBoolean("first_in_settings", false).commit();

            new DIDAsyncTask(2, 1, "", this, this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

        }
        selectedCallerID = preferences.getString(PHONE, UserDataManager.getUserName());
        Log.d(TAG, "onCreate: " + selectedCallerID);
        if (selectedCallerID.equals(UserDataManager.getUserName())) {
            selectedCallerIdPosition = 0;
        } else {
            selectedCallerIdPosition = -1;
        }


    }

    private void handleToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.caller_id));
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.caller_id));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    private void initView() {
        listView = findViewById(R.id.listView);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public Loader onCreateLoader(int i, Bundle bundle) {
        Log.d(TAG, "onCreateLoader: ");
        didIdsArrayList = new ArrayList<>();
        return new CursorLoader(this, null, null, null, null, "ASC") {
            @Override
            public Cursor loadInBackground() {

                try {
                    cursor = DIDRepo.get().getUserDIDsCursor();
                    while (cursor.moveToNext()) {
                        didIdsArrayList.add(cursor.getString(0));
                    }

                    Log.d(TAG, "loadInBackground: " + didIdsArrayList.size());


                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (cursor != null) {
                    cursor.setNotificationUri(getContext().getContentResolver(), DatabaseConstants.DID_TABLE_URI);
                }

                return cursor;
            }
        };

    }

    @Override
    public void onLoadFinished(Loader loader, Cursor data) {
        Log.d(TAG, "onLoadFinished: ");

        MatrixCursor extras = new MatrixCursor(new String[]{"_id", "didOwner", "didNumber"});
        extras.addRow(new String[]{"-1", "-1", getString(R.string.sign_up_number)});
        Cursor[] cursors = {extras, data};
        Cursor extendedCursor = new MergeCursor(cursors);
        Log.d(TAG, "onLoadFinished: " + data.getCount());
        didListAdapter.swapCursor(extendedCursor);
    }

    @Override
    public void onLoaderReset(Loader loader) {
        didListAdapter.swapCursor(null);
    }

    public void onCancel(View view) {
        onBackPressed();
    }

    @Override
    public void onClick(View view) {
    }

    public void buyDID(View view) {
        startActivity(new Intent(this, DIDNumbersActivity.class));
    }


    private class DidListAdapter extends CursorAdapter {

        private LayoutInflater mInflater;


        public DidListAdapter(Cursor c) {
            super(CallerIDSelectionActivity.this, c, false);
            mInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            ViewHolder holder = new ViewHolder();
            View view = mInflater.inflate(
                    R.layout.did_selection_item, null);
            holder.textViewNumber = view.findViewById(R.id.did_item_number);
            holder.textviewName = view.findViewById(R.id.did_item_name);
            holder.radioButton = view.findViewById(R.id.radioButton);
            holder.root = view.findViewById(R.id.root_layout);
            view.setTag(holder);

            return view;
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {

            final ViewHolder holder = (ViewHolder) view.getTag();
            final int position = cursor.getPosition();
            final String didNumber = cursor.getString(2);

            //added by rahat 25-09-2017
            final String didID = cursor.getString(0);


            if (didNumber.equals(selectedCallerID)) {

                selectedCallerIdPosition = position;
            }

            if (!didNumber.endsWith(getString(R.string.sign_up_number)))
                holder.textViewNumber.setText(didNumber);
            else
                holder.textViewNumber.setText("+" + UserDataManager.getUserName());

            if (position == selectedCallerIdPosition)
                holder.radioButton.setChecked(true);
            else
                holder.radioButton.setChecked(false);
            if (!didNumber.endsWith(getString(R.string.sign_up_number))) {
                String countryName = getCountryName(didNumber);
                if (!TextUtils.isEmpty(countryName))
                    holder.textviewName.setText(countryName);
                else
                    holder.textviewName.setText(" ");
            } else
                holder.textviewName.setText(R.string.sign_up_number);
            holder.root.setOnClickListener(view1 -> {
                Log.d(TAG, "onClick: " + selectedCallerIdPosition);
                if (position == selectedCallerIdPosition) {

                } else {
                    if (selectedCallerIdPosition != -1)
                        ((RadioButton) getViewByPosition(selectedCallerIdPosition, listView).findViewById(R.id.radioButton)).setChecked(false);
                    selectedCallerIdPosition = position;
                    holder.radioButton.setChecked(true);
                    changeCurrentCallerId(didNumber, position, didID);
                    notifyDataSetChanged();
                }
            });

        }
    }

    String getCountryName(String number) {
        if (!number.startsWith("+"))
            number = "+" + number;
        String phoneNumber = Util.translateNumber(number);
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        try {
            if (phoneUtil.parse(phoneNumber, "AZ") != null) {
                int cc = phoneUtil.parse(phoneNumber.startsWith("+") ? phoneNumber : "+" + phoneNumber, "AZ").getCountryCode();
                Country country = CountryInfoProvider.countryDialingCodeToCountry.get(cc + "");
                if (country != null)
                    return country.name;
                else return null;
            } else return null;
        } catch (NumberParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public View getViewByPosition(int pos, ListView listView) {
        final int firstListItemPosition = listView.getFirstVisiblePosition();
        final int lastListItemPosition = firstListItemPosition + listView.getChildCount() - 1;

        if (pos < firstListItemPosition || pos > lastListItemPosition) {
            return listView.getAdapter().getView(pos, null, listView);
        } else {
            final int childIndex = pos - firstListItemPosition;
            return listView.getChildAt(childIndex);
        }
    }

    private void changeCurrentCallerId(String didNumber, int position, String didID) {

        selectedCallerID = didNumber;

        if (position == 0) {
            preferences.edit().putString(PHONE, UserDataManager.getUserName()).commit();
            preferences.edit().putString(SELECTED_DID_ID, "-1").commit();

            //Toast.makeText(getActivity(), "Called ID removed", Toast.LENGTH_SHORT).show();
        } else {
            preferences.edit().putString(PHONE, didNumber).commit();
            preferences.edit().putString(SELECTED_DID_ID, didID).commit();
            showCustomizedToast("Called ID changed to: " + didNumber);
            //Toast.makeText(getActivity(), "Called ID changed to: " + didNumber, Toast.LENGTH_SHORT).show();


        }
        // 12-12-2017
        unregisterSipProvider();
        SIPProvider.registrationFlag = false;
        restartRegistration();


        Log.d(TAG, "changeCurrentCallerId: " + preferences.getString(PHONE, UNKNOWN_CALLER_ID));

    }

    private synchronized void unregisterSipProvider() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.SEND_UNREGISTER, "");
        LocalBroadcastManager.getInstance(this).sendBroadcast(i);
    }

    private synchronized void restartRegistration() {
        Intent i = new Intent(Constants.DIALER_INTENT_FILTER);
        i.putExtra(Constants.START_REGISTRATION, "");
        LocalBroadcastManager.getInstance(this).sendBroadcast(i);
    }


    private void showCustomizedToast(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.show();
    }

    public static class ViewHolder {
        public TextView textViewNumber;
        private TextView textviewName;
        public RadioButton radioButton;
        public View root;
    }

    @Override
    public void onCountryListResponse(String[] countryNames, int[] countryFlags) {
    }

    @Override
    public void onStatesListResponse(String[] stateNames, String[] stateCode) {
    }

    @Override
    public void onCityListResponse(String[] cityNames, String[] cityCode) {
    }

    @Override
    public void onDIDListResponse(ArrayList<DID> dids) {
    }

    @Override
    public void onUsersDidListResponse(ArrayList<DID> dids) {
        Log.d(TAG, "onUsersDidListResponse: " + dids.size());
        Executor.ex(() -> {
            for (int i = 0; i < dids.size(); i++)
                DIDRepo.get().createUserDidEntry(dids.get(i));
        });

        getLoaderManager().restartLoader(0, null, this);
    }

    @Override
    public void onBuyUsersDID(DID did) {

    }

    @Override
    public void onUnsubscribeDid(DID selectedDID) {

    }

    @Override
    public void onForwardedNumberSet(String forwardedNumber) {

    }

}
