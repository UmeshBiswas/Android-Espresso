package com.revesoft.itelmobiledialer.chat.chatWindow.viewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.iftalab.runtimepermission.DangerousPermission;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.FileProgressHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.util.AppContext;
import com.revesoft.material.R;

import java.io.File;

/**
 * Created by Zim on 15-Apr-18.
 */

public class RetryAndProgressMessageViewHolder extends TextMessageViewHolder {

    private ProgressBar progressBar;
    private TextView tvProgress;
    private ImageView ivRetry;

    public RetryAndProgressMessageViewHolder(View view) {
        super(view);
        progressBar =  view.findViewById(R.id.pb);
        tvProgress =  view.findViewById(R.id.tvProgress);
        ivRetry =  view.findViewById(R.id.ivRetry);
    }

    @Override
    public void bindView(Message message) {
        super.bindView(message);
        ivRetry.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);
        tvProgress.setVisibility(View.GONE);

        switch (message.mimeType){
            case Text:
            case GIF:
            case Sticker:
            case Location:
            case LocationRequest:
            case StaticSticker:
                return;
        }


        handleClicks(message);
        handleRetryButton(message);
        handleProgressViews(message);
    }

    private void handleClicks(Message message){
        ivRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
				ivRetry.setVisibility(View.GONE);
                if (message.messageType == MessageEntry.MessageType.RECEIVED) {
                    Sender.getAccess().sendIntentMessageFileDownloadRetryToDialer(message);
                } else {
                    //Sender.get().sendFile(message.filePathLocal, ChatContentParser.parseCaption(message.content));
                    File f = new File(message.filePathLocal);
                    if(!f.exists()){
                        Sender.getAccess().sendIntentMessageFileDownloadRetryToDialer(message);
                    }
                    else{
                        Executor.ex(() -> MessageRepo.get().deleteMessageByCallID(message.callerId));
                        if(message.futureTime == 0){
                            if(message.isConfide){
                                Sender.getAccess().sendConfideFile(message.filePathLocal,ChatContentParser.parseCaption(message.content));
                            }else {
                                Sender.getAccess().sendFile(message.filePathLocal, ChatContentParser.parseCaption(message.content));
                            }
                        }
                        else{
                            String caption = ChatContentParser.parseCaption(message.content);
                            Sender.getAccess().sendFutureFile(message.filePathLocal, caption, message.futureTime,
                                    message.sendOriginalTimestampFlag == 1);
                        }
                    }
                }
            }
        });
    }


    private void handleProgressViews(Message message) {
        if(message.mimeType == MimeType.Deleted){
            progressBar.setVisibility(View.GONE);
            tvProgress.setVisibility(View.GONE);
            return;
        }
        if (ChatUtil.isUploadingOrDownloadingNow(message)) {
            if (message.messageType == MessageEntry.MessageType.RECEIVED) {
                progressBar.setVisibility(View.VISIBLE);
                tvProgress.setVisibility(View.VISIBLE);
                FileProgressHook.watchProgressWith(tvProgress, message.callerId);
            } else {
                if (message.deliveryStatus == MessageEntry.DeliveryStatus.SUCCESSFUL) {
                    progressBar.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                } else if (message.deliveryStatus == MessageEntry.DeliveryStatus.FAILED) {
                    progressBar.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                } else if (message.deliveryStatus == MessageEntry.DeliveryStatus.PENDING) {
                    progressBar.setVisibility(View.VISIBLE);
                    tvProgress.setVisibility(View.VISIBLE);
                    FileProgressHook.watchProgressWith(tvProgress, message.callerId);
                } else if (message.deliveryStatus == MessageEntry.DeliveryStatus.NO_REPLY) {
                    progressBar.setVisibility(View.VISIBLE);
                    tvProgress.setVisibility(View.VISIBLE);
                    FileProgressHook.watchProgressWith(tvProgress, message.callerId);
                } else {
                    progressBar.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                }
            }
        } else {
            progressBar.setVisibility(View.GONE);
            tvProgress.setVisibility(View.GONE);
        }
    }

    private void handleRetryButton(final Message message) {
        if (DangerousPermission.StoragePermission.getAccess(AppContext.getAccess().getContext()).hasPermission()) {
            if (message.mimeType == MimeType.Deleted) {
                ivRetry.setVisibility(View.GONE);
                return;
            }
            if (message.messageType == MessageEntry.MessageType.RECEIVED && message.deliveryStatus == MessageEntry.DeliveryStatus.FAILED) {
                ivRetry.setVisibility(View.VISIBLE);
            } else if (message.messageType == MessageEntry.MessageType.RECEIVED) { //for downloading an image/attachment if it is deleted from the local filepath
                if (!ChatUtil.isDownloadingNow(message)) {
                    File file = new File(message.filePathLocal);
                    if (!file.exists()) {
                        ivRetry.setVisibility(View.VISIBLE);
                    }
                }
            } else if (message.messageType == MessageEntry.MessageType.SEND) {
                if (!ChatUtil.isSendingNow(message)) {
                    File file = new File(message.filePathLocal);
                    if (!file.exists()) {
                        ivRetry.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (message.deliveryStatus == MessageEntry.DeliveryStatus.FAILED) {
                        ivRetry.setVisibility(View.VISIBLE);
                    }
                }
            } else {
                ivRetry.setVisibility(View.GONE);
            }

        }else {
            ivRetry.setVisibility(View.GONE);
        }
    }
}
