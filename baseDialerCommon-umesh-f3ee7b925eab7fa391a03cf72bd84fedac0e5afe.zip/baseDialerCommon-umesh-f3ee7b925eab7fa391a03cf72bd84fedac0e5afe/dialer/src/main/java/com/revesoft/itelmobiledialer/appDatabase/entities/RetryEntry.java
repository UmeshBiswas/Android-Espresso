package com.revesoft.itelmobiledialer.appDatabase.entities;

import org.jetbrains.annotations.NotNull;

import java.util.Date;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Created By suvo on January 31, 2019
 * Project baseDialerCommon
 */

@Entity(tableName = "retry")
public class RetryEntry {


    @NotNull
    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "callerid")
    public String callerId;


    @ColumnInfo(name = "number")
    public String number;


    @ColumnInfo(name = "exact_retry_time")
    public Date exactRetryTime;


    @ColumnInfo(name = "retry_time")
    public int retryTime;


    @ColumnInfo(name = "retry_count")
    public int retryCount;


    @ColumnInfo(name = "type")
    public int type;

    @ColumnInfo(name = "id")
    public String id = "temp";

    public RetryEntry() {
    }

    private RetryEntry(Builder builder) {
        callerId = builder.callerId;
        number = builder.number;
        exactRetryTime = builder.exactRetryTime;
        retryTime = builder.retryTime;
        retryCount = builder.retryCount;
        type = builder.type;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public interface BurnTimerEntryType {
        short SINGLE_CHAT = 0, GROUP_CHAT = 1;
    }

    public static final class Builder {
        private String callerId;
        private String number;
        private Date exactRetryTime;
        private int retryTime;
        private int retryCount;
        private int type;

        private Builder() {
        }

        public Builder callerId(String val) {
            callerId = val;
            return this;
        }

        public Builder number(String val) {
            number = val;
            return this;
        }


        public Builder exactRetryTime(Date val) {
            exactRetryTime = val;
            return this;
        }


        public Builder retryTime(int val) {
            retryTime = val;
            return this;
        }

        public Builder retryCount(int val) {
            retryCount = val;
            return this;
        }


        public Builder type(int val) {
            type = val;
            return this;
        }

        public RetryEntry build() {
            return new RetryEntry(this);
        }
    }
}
