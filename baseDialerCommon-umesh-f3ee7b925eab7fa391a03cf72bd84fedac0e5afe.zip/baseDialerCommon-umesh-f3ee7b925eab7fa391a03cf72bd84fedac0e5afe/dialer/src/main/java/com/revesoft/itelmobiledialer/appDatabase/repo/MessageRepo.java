package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;
import android.telephony.SmsMessage;
import android.text.TextUtils;
import android.util.Log;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.entities.HiddenMessage;
import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.chat.chatList.QueryItemChatList;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeTypeUtil;
import com.revesoft.itelmobiledialer.data.UnseenMessageCounter;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.ims.IMUtil.RetryInfo;
import com.revesoft.itelmobiledialer.signalling.data.MessageDeliveryStatus;
import com.revesoft.itelmobiledialer.signalling.model.SignallingMessageEntry;
import com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants;
import com.revesoft.itelmobiledialer.util.AppIconNotification;
import com.revesoft.itelmobiledialer.util.FileTransferViaHTTPHelper;
import com.revesoft.itelmobiledialer.util.GroupMessageUtil;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.SMSEngine;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;

public class MessageRepo {
    private static final MessageRepo ourInstance = new MessageRepo();

    public static MessageRepo get() {
        return ourInstance;
    }

    private MessageRepo() {
    }

    public List<Message> getAll() {
        return AppDatabase.get().messageDao().getAll();
    }

    public void insertAll(List<Message> messageList) {
        AppDatabase.get().messageDao().insertAll(messageList);
    }

    public Message[] getmessageToBurn() {
        return AppDatabase.get().messageDao().getmessageToBurn();
    }

    public Message[] getSentMessageByCallerID(String cid) {
        return AppDatabase.get().messageDao().getSentMessageByCallerID(cid);
    }

    public Message[] getReceivedMessageByCallerID(String cid) {
        return AppDatabase.get().messageDao().getReceivedMessageByCallerID(cid);
    }

    public Message[] getScheduledBurnMessage(long currentSystemTime) {
        return AppDatabase.get().messageDao().getScheduledBurnMessage(currentSystemTime);
    }


    public Message[] getNextBurnMessage() {
        return AppDatabase.get().messageDao().getNextBurnMessage();
    }

    public List<Message> getReceivedBurnedMessagesWhereBurnTImeInMilliesNotSet(List<String> callIDs) {
        return AppDatabase.get().messageDao().getReceivedBurnedMessagesWhereBurnTImeInMilliesNotSet(callIDs);
    }

    public List<Message> getMessagesWithPendingDataUsageRestrictedFiles(){
        return AppDatabase.get().messageDao().getMessagesWithPendingDataUsageRestrictedFiles();
    }

    public Message getMessageWithPendingDataUsageRestrictedFile(String callerId){
        return AppDatabase.get().messageDao().getMessageWithPendingDataUsageRestrictedFile(callerId);
    }


    public long getBurnTimer(String cid) {
        return AppDatabase.get().messageDao().getBurnTimer(cid);
    }


    public Cursor getMessagesWithFailedFileTransfer(String number) {
        return AppDatabase.get().messageDao().getMessagesWithFailedFileTransfer(number);
    }


    public DataSource.Factory<Integer, QueryItemChatList> getPagedChatHistoryListWithFilter(String filter) {
        return AppDatabase.get().messageDao().getPagedChatHistoryListWithFilter(filter);
    }


    public DataSource.Factory<Integer, Message> getAllRegularLivedPagedSingleMessage(String number) {
        return AppDatabase.get().messageDao().getAllRegularLivedPagedSingleMessage(number);
    }


    public DataSource.Factory<Integer, Message> getAllRegularLivedPagedGroupMessage(String groupId) {
        return AppDatabase.get().messageDao().getAllRegularLivedPagedGroupMessage(groupId);
    }


    public DataSource.Factory<Integer, Message> getAllRegularLivedPagedSingleFutureMessage(String number) {
        return AppDatabase.get().messageDao().getAllRegularLivedPagedSingleFutureMessage(number);
    }


    public DataSource.Factory<Integer, Message> getAllRegularLivedPagedGroupFutureMessage(String groupId) {
        return AppDatabase.get().messageDao().getAllRegularLivedPagedGroupFutureMessage(groupId);
    }


    public long deleteMessageByGroupId(String gid) {
        return AppDatabase.get().messageDao().deleteByGroupId(gid);
    }


    public long deleteMessageByNumber(String num) {
        return AppDatabase.get().messageDao().deleteByNumber(num);
    }

    public int clearChatByGroupId(String groupId) {
        return AppDatabase.get().messageDao().clearChatByGroupId(groupId);
    }


    public void updateReceivingDownloadingMessageDeliveryStatusToFailed() {
        AppDatabase.get().messageDao().updateReceivingDownloadingMessageDeliveryStatusToFailed();
    }


    public void updateNoReplyUploadingMessageDeliveryStatusToFailed() {
        AppDatabase.get().messageDao().updateNoReplyUploadingMessageDeliveryStatusToFailed();
    }


    public void updateMessageDeliveryStatus(String callerId, int deliveryStatus) {
        AppDatabase.get().messageDao().updateMessageDeliveryStatus(callerId, deliveryStatus);
    }


    public long getMessageDate(String callID) {
        return AppDatabase.get().messageDao().getMessageByCallId(callID).date.getTime();
    }


    public void deleteMessageByCallID(String callid) {
        List<String> ids = new ArrayList<>();
        ids.add(callid);
        deleteMessageByCallIdList(ids);
    }

    public void deleteMessageByCallIdList(List<String> callerIdList) {
        AppDatabase.get().messageDao().deleteMessageByCallIdList(callerIdList);
    }


    public void updateMessageSeenStatus(String callID, int status, long currentTime) {
        AppDatabase.get().messageDao().updateMessageSeenStatus(callID, status, currentTime);
    }


    public void createHistoryFetchingMessageLog(ArrayList<SignallingMessageEntry> messageEntries) {
        List<Message> messages = new ArrayList<>();
        for (SignallingMessageEntry entry : messageEntries) {
            MimeType mimeType = MimeTypeUtil.getMimeType(entry.content);
            String _file_path = TextUtils.isEmpty(entry.filePath) ? null : entry.filePath;
            Message message = Message.newBuilder().number(entry.number).date(new Date(entry.time)).notification(entry.status)
                    .content(entry.content).messageType(entry.type).callerId(entry.callerId).deliveryStatus(entry.delivery_status)
                    .received(new Date(entry.time)).displayTime(new Date(entry.time - UserDataManager.getTimeAdjustment()))
                    .editCount(entry.editCount).mimeType(mimeType).filePath(_file_path).build();
            messages.add(message);
        }
        AppDatabase.get().messageDao().insertAll(messages);
    }


    public int getEditCount(String callID) {
        return AppDatabase.get().messageDao().getEditCount(callID);
    }


    public void createMessageLog(MessageEntry messageEntry) {
        if (messageEntry.isGroup || messageEntry.groupId.length() != 0)
            createGroupMessageLog(messageEntry);
        else createSingleMessageLog(messageEntry);
    }

    private void createSingleMessageLog(MessageEntry messageEntry) {
        if (checkForMessage(messageEntry) || messageEntry.editCount == -1) {
            return;
        }
        try {
            Message message = Message.createFromMessageEntry(messageEntry);
            AppDatabase.get().messageDao().insert(message);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            AppIconNotification.setCountInAppIcon();
            UnseenMessageCounter.sendSignalToDashBoard();
        }
    }


    private void createGroupMessageLog(MessageEntry messageEntry) {
        I.log("createGroupMessageLog");
        if (checkForMessage(messageEntry) || messageEntry.editCount == -1) {
            I.log("createGroupMessageLog never imagined");
            return;
        }
        I.log("createGroupMessageLog >>");
        try {
            Message message = Message.createFromMessageEntry(messageEntry);
            AppDatabase.get().messageDao().insert(message);

        } catch (Exception e) {
            I.log(e.getLocalizedMessage());
            e.printStackTrace();
        } finally {
            AppIconNotification.setCountInAppIcon();
            UnseenMessageCounter.sendSignalToDashBoard();
        }
    }

    private void createGroupMessageLog(MessageEntry messageEntry, boolean notifyEnabled) {
        I.log("createGroupMessageLog");
        if (checkForMessage(messageEntry) || messageEntry.editCount == -1) {
            I.log("createGroupMessageLog never imagined");
            return;
        }
        I.log("createGroupMessageLog >>");
        try {
            Message message = Message.createFromMessageEntry(messageEntry);
            AppDatabase.get().messageDao().insert(message);

        } catch (Exception e) {
            I.log(e.getLocalizedMessage());
            e.printStackTrace();
        } finally {
            AppIconNotification.setCountInAppIcon();
            UnseenMessageCounter.sendSignalToDashBoard();
        }
    }

    private boolean checkForMessage(MessageEntry me) {
        return AppDatabase.get().messageDao().checkForMessage(me.callerId, me.number, me.editCount, me.content);
    }


    public Date getMessageReceiveTime(String callID) {
        return AppDatabase.get().messageDao().getMessageReceiveTime(callID);
    }


    public void createSystemMessage(String callId, String groupId,
                                    String message, long timeStamp, short messageStatus) {
        MessageEntry me = new MessageEntry();
        me.number = "system";
        me.groupId = groupId;
        me.type = MessageEntry.MessageType.SYSTEM;
        me.time = timeStamp;
        me.content = message;
        me.callerId = callId;
        me.status = messageStatus;
        createMessageLog(me);
    }


    public void createSystemMessage(String callId, String groupId,
                                    String message, int e2e, long timeStamp) {
        MessageEntry me = new MessageEntry();
        me.type = MessageEntry.MessageType.SYSTEM;
        me.time = timeStamp;
        me.content = message;
        me.callerId = callId;
        me.status = MessageEntry.MessageStatus.READ;
        me.number = "system";
        me.groupId = groupId;
        me.isEncrypted = e2e;
        createMessageLog(me);

    }


    public void createMessageLog(SMSEngine.SimpleSMS message) {
        if (AppDatabase.get().messageDao().checkForSMS(message.time, message.address, message.body)) {
            return;
        }

        String number = message.address;
        Message dMessage = Message.newBuilder().number(number != null ? number.replaceAll("[+]", "") : "Text Number")
                .date(new Date(message.time))
                .notification(message.isRead == 0 ? MessageEntry.MessageStatus.UNREAD : MessageEntry.MessageStatus.READ)
                .content(message.body)
                .messageType(MessageEntry.MessageType.RECEIVED_SMS)
                .callerId("" + number + message.time)
                .received(new Date(message.time))
                .deliveryStatus(MessageEntry.DeliveryStatus.SUCCESSFUL)
                .displayTime(new Date(message.time))
                .build();
        AppDatabase.get().messageDao().insert(dMessage);
    }


    public void createMessageLog(SmsMessage[] message, int read) {
        String from = message[0].getOriginatingAddress();
        long time = message[0].getTimestampMillis();
        StringBuffer body = new StringBuffer();
        for (SmsMessage m : message) {
            body.append(m.getDisplayMessageBody());
        }
        if (AppDatabase.get().messageDao().checkForSMS(time, from, body.toString())) {
            return;
        }
        try {
            Message message1 = Message.newBuilder()
                    .number(from != null ? from.replaceAll("[+]", "") : "Text Number")
                    .date(new Date(time))
                    .notification(read)
                    .content(body.toString())
                    .messageType(MessageEntry.MessageType.RECEIVED_SMS)
                    .callerId("" + from + System.currentTimeMillis())
                    .deliveryStatus(MessageEntry.DeliveryStatus.SUCCESSFUL)
                    .received(new Date(System.currentTimeMillis()))
                    .displayTime(new Date(time))
                    .build();
            AppDatabase.get().messageDao().insert(message1);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            AppIconNotification.setCountInAppIcon();
            UnseenMessageCounter.sendSignalToDashBoard();
        }
    }


    public void setMessageDeliveryStatus(String callId, int messageDeliveryStatus) {
        AppDatabase.get().messageDao().setMessageDeliveryStatus(callId, messageDeliveryStatus);
    }

    public void setMessageDeliveryStatus(String callId, MessageDeliveryStatus messageDeliveryStatus) {
        setMessageDeliveryStatus(callId, messageDeliveryStatus.getValue());
    }


    public Message getMessageByCallId(String callID) {
        return AppDatabase.get().messageDao().getMessageByCallId(callID);
    }

    public MessageEntry getMessageEntryByCallId(String callID) {
        return getMessageByCallId(callID).convertMessageEntry();
    }


    public List<Message> getNoReplyMessages() {
        return AppDatabase.get().messageDao().getNoReplyMessages();
    }


    public ArrayList<MessageEntry> getNoReplyMessageEntries() {
        List<Message> no_reply_messages = getNoReplyMessages();
        ArrayList<MessageEntry> messageEntries = new ArrayList<>();
        for (Message message : no_reply_messages) messageEntries.add(message.convertMessageEntry());
        return messageEntries;
    }


    private boolean defineSkipAndUpdateStatusIfNeeded(MessageEntry serverMessage) {
        //gatis start
        if (serverMessage.isConfide) {
            return true; //skip confide
        }
        if (serverMessage.burnTimeInsec > 0 && serverMessage.time + serverMessage.burnTimeInsec * 1000 < System.currentTimeMillis()) {
            return true;//skip time passed bund messages
        }
        if (serverMessage.futureSendTime > 0 && serverMessage.type != MessageEntry.MessageType.SEND) {
            return true; //skip fetched future message of others :P
        }

        //skip if message already in local but just update the status
        Cursor cursor = getMessageByCallerIdCursor((serverMessage.callerId));
//        if (serverMessage.isGroup) {
//            cursor = Database.GroupMessages.Read.byCallId(serverMessage.callerId);
//        } else {
//            cursor = getMessageByCallerIdCursor((serverMessage.callerId));
//        }
        com.revesoft.itelmobiledialer.chat.chatWindow.Message localMessage = null;
        if (cursor != null && cursor.moveToFirst()) {
            localMessage = new com.revesoft.itelmobiledialer.chat.chatWindow.Message(cursor);
            cursor.close();
        }


        //status update strategy
        //1. don't take server status as final status unconditionally
        //2. if mimeType of local is deleted then don't update
        //3. if edit count of server message is greater than or equal then local then take server status as final status
        //4. if edit count of server message is less than local then skip update
        //5. if edit count from server is -1 then update mime type of local as deleted
        if (localMessage != null) {
//            Log.d("localMessage", "defineSkipAndUpdateStatusIfNeeded: localMessage found " + count++);
            if (localMessage.mimeType == MimeType.Deleted) {
                return true;
            }
            if (serverMessage.editCount == -1) {
                if (localMessage.editCount != -1) {
//                    if (serverMessage.isGroup) {
//                        Database.GroupMessages.Update.markAsDeleted(localMessage.callerId);
//                    } else {
//                        Database.Message.Update.markAsDeleted(localMessage.callerId);
//                    }
                    com.revesoft.itelmobiledialer.chat.chatWindow.Message finalLocalMessage = localMessage;
                    Executor.ex(() -> {
                        MessageRepo.get().markAsDeleted(finalLocalMessage.callerId);
                    });
                    return true;
                }
            }

            if (serverMessage.editCount >= localMessage.editCount) {
                if (serverMessage.delivery_status != localMessage.deliveryStatus) {
//                    if (serverMessage.isGroup) {
//                        Database.GroupMessages.Update.deliveryStatus(localMessage.callerId, serverMessage.delivery_status);
//                    } else {
//                        Database.Message.Update.deliveryStatus(localMessage.callerId, serverMessage.delivery_status);
//                    }
                    com.revesoft.itelmobiledialer.chat.chatWindow.Message finalLocalMessage1 = localMessage;
                    Executor.ex(() -> {
                        setMessageDeliveryStatus(finalLocalMessage1.callerId, (int) serverMessage.delivery_status);
                    });
                }
                return true;
            }
            return true;
        }
        //gatis end
        return false;
    }


    public void createHistoryFetchingMessageLog(ArrayList<MessageEntry> messageEntries, boolean notifyEnabled) {
        for (MessageEntry messageEntry : messageEntries) {
            boolean shouldSkip = defineSkipAndUpdateStatusIfNeeded(messageEntry);
            if (!shouldSkip) {
                createGroupMessageLog(messageEntry, notifyEnabled);

            } else {
                Log.d("localMessage", "createHistoryFetchingMessageLog: skipped");
            }
        }
    }


    public void dummyWithDate(String phoneNumber, long lastMessageDate) {
        MessageEntry messageEntry = new MessageEntry();
        messageEntry.time = lastMessageDate;
        messageEntry.number = phoneNumber;
        messageEntry.type = MessageEntry.MessageType.SEND;
        messageEntry.status = MessageEntry.MessageStatus.READ;
        messageEntry.content = "";
        createSingleMessageLog(messageEntry);
    }


    public void dummyWithDateForGroup(String groupId, long lastMessageDate) {
        MessageEntry messageEntry = new MessageEntry();
        messageEntry.time = lastMessageDate;
        messageEntry.number = "";
        messageEntry.groupId = groupId;
        messageEntry.type = MessageEntry.MessageType.SEND;
        messageEntry.status = MessageEntry.MessageStatus.READ;
        messageEntry.content = "";
        createSingleMessageLog(messageEntry);
    }


    public Cursor getMessagesByCallerIdListCursor(List<String> callerIdList) {
        return AppDatabase.get().messageDao().readMessagesByCallerIdList(callerIdList);
    }

    public Cursor getMessageByCallerIdCursor(String callerId) {
        List<String> idList = new ArrayList<>();
        idList.add(callerId);
        return getMessagesByCallerIdListCursor(idList);
    }

    public Cursor getMessageByNumber(String number, String searchText, boolean isFuture, boolean isEncrypted) {
        if (isFuture)
            return AppDatabase.get().messageDao().readMessageByNumberIsFuture(number, "%" + searchText + "%", isEncrypted);
        else
            return AppDatabase.get().messageDao().readMessageByNumberNotInFuture(number, "%" + searchText + "%", isEncrypted);
    }


    public Cursor getMessageByGroupId(String groupId, String searchText, boolean isFuture) {
        if (isFuture)
            return AppDatabase.get().messageDao().readMessageByGroupIdIsFuture(groupId, "%" + searchText + "%");
        else
            return AppDatabase.get().messageDao().readMessageByGroupIdNotInFuture(groupId, "%" + searchText + "%");
    }

    public Cursor getMessageByGroupId(String groupId, String searchText, boolean isFuture, String callerId) {
        if (isFuture)
            return AppDatabase.get().messageDao().readMessageByGroupIdIsFuture(groupId, "%" + searchText + "%", callerId);
        else
            return AppDatabase.get().messageDao().readMessageByGroupIdNotInFuture(groupId, "%" + searchText + "%", callerId);
    }


    public boolean checkIfContainsReceivedMessages(List<String> callIds) {
        Cursor cursor = getMessagesByCallerIdListCursor(callIds);
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
            do {
                int type = cursor.getInt(cursor.getColumnIndex("messagetype"));
                if (type == MessageEntry.MessageType.RECEIVED) {
                    return true;
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return false;
    }


    public long lastMessageDate(String phoneNumber) {
        return AppDatabase.get().messageDao().lastMessageDate(phoneNumber);
    }

    public long lastMessageDateForGroup(String groupId) {
        return AppDatabase.get().messageDao().lastMessageDateForGroup(groupId);
    }

    public List<String> allActiveMessageParticipantPhoneNumbers() {
        return AppDatabase.get().messageDao().allActiveMessageParticipantPhoneNumbers();
    }

    public List<String> allActiveGroupMessageGroupId() {
        return AppDatabase.get().messageDao().allActiveGroupMessageGroupId();
    }

    public Cursor getMessagesByOCID(String ocid) {
        return AppDatabase.get().messageDao().readMessagesByOCID(ocid);
    }
    public Message getMessagesByOcid(String ocid) {
        return AppDatabase.get().messageDao().getMessagesByOCID(ocid);
    }

    public void clearUnreadNormalIMCount(String target) {
        AppDatabase.get().messageDao().clearUnreadNormalIMCount(target);
    }

    public void clearUnreadNormalGroupCount(String groupId) {
        AppDatabase.get().messageDao().clearUnreadNormalGroupCount(groupId);
    }

    public void clearUnreadEncryptedIMCount(String target) {
        AppDatabase.get().messageDao().clearUnreadEncryptedIMCount(target);
    }

    public void clearUnreadEncryptedGroupCount(String groupId) {
        AppDatabase.get().messageDao().clearUnreadEncryptedGroupCount(groupId);
    }

    public void markAsDeleted(List<String> callIds) {
        AppDatabase.get().messageDao().markAsDeleted(callIds, MimeType.Deleted.toString());
    }

    public void markAsDeleted(String callerID) {
        List<String> ids = new ArrayList<>();
        ids.add(callerID);
        markAsDeleted(ids);
    }

    public int deleteAllMessages() {
        return AppDatabase.get().messageDao().deleteAllMessages();
    }

    int getMessageTypeByCallerId(String callerId) {
        return AppDatabase.get().messageDao().getMessageByCallId(callerId).messageType;
    }


    public RetryInfo getFileMessageByCallerId(String callerId) {
        Message msg = getMessageByCallId(callerId);
        RetryInfo retryInfo = null;
        if (msg != null) {
            String content = msg.content;
            int type = msg.messageType;
            String message = "";
            if (type == MessageEntry.MessageType.SMS) {
                message = content;
            } else {
                String filePathLocal = msg.filePath;
                Log.e("fileretry", " fileMessage:  " + content + " " + filePathLocal);
                GroupMessageUtil groupMessageUtil = new GroupMessageUtil();
                message = groupMessageUtil.getGroupForwardPendingMessage(content, filePathLocal);
            }

            long futureTime = msg.futureSendTime;

            retryInfo = new RetryInfo(message, type, futureTime);
        }
        return retryInfo;
    }




    public Cursor getPendingSMS(String number) {
        return AppDatabase.get().messageDao().getPendingSMS(number);
    }


    public LiveData<List<String>> getUnseenMessagesByNumber(String number, boolean isEncrypted) {
        return AppDatabase.get().messageDao().getUnseenMessagesCallerIdLive(number, isEncrypted);
    }

    public Cursor getUnseenMessagesByNumber(String number) {
        return AppDatabase.get().messageDao().getUnseenMessagesCallerIdLive(number);
    }

    public Cursor getUnseenMessagesByGroupId(String groupId) {
        return AppDatabase.get().messageDao().getUnseenMessagesCallerIdLive(groupId);
    }


    public Cursor getUnDecryptedMessages(String number, int isEncrypted) {
        return AppDatabase.get().messageDao().getUnDecryptedMessages(number, isEncrypted);
    }

    Cursor getUnDecryptedMessagesByNumber(String number) {
        return AppDatabase.get().messageDao().getUnDecryptedMessagesByNumber(number);
    }

    Cursor getUnDecryptedMessagesByGroupId(String groupId) {
        return AppDatabase.get().messageDao().getUnDecryptedMessagesByGroupId(groupId);
    }


    public void updateFutureMessageSendTime(ArrayList<com.revesoft.itelmobiledialer.chat.chatWindow.Message> messageArrayList) {
        for (com.revesoft.itelmobiledialer.chat.chatWindow.Message message : messageArrayList) {
            AppDatabase.get().messageDao().updateFutureMessageSendTime(message.callerId, message.futureTime);
        }
    }


    public void updateMessageContent(String callerID, String content) {
        AppDatabase.get().messageDao().updateMessageContent(callerID, content);
    }

    public void updateMessageContentAndDecryption(String callerID, String content, int isDecrypted) {
        AppDatabase.get().messageDao().updateMessageContentAndDecryption(callerID, content, isDecrypted);
    }

    public void updateMessageContent(String callerId, String content, int isDecrypted, String filePath,
                                     String mimeType, short deliveryStatus) {
        AppDatabase.get().messageDao().updateMessageContent(callerId, content, isDecrypted, filePath, mimeType, deliveryStatus);
    }


    public void updateMessageContentAndMimeType(String callerID, String content, MimeType mimeType) {
        AppDatabase.get().messageDao().updateMessageContentAndMimeType(callerID, content, mimeType);
    }

    public String getMessageFilePath(String callID) {
        return AppDatabase.get().messageDao().getMessageFilePath(callID);
    }

    public void updateMessageFilePath(String callerId, String filePath) {
        AppDatabase.get().messageDao().updateMessageFilePath(callerId, filePath);
    }


    public void deleteEveryHiddenMessageFromHistory() {
        AppDatabase.get().messageDao().deleteHiddenMessageByGroupID();
        AppDatabase.get().messageDao().deleteHiddenMessageByNumber();
        AppDatabase.get().hiddenMessageDao().deleteAllHiddenMessage();
    }


    public void updateGroupChatHiddenStatus(String number, String groupId, int isEncrypted, boolean willBeHidden) {
        boolean isGroupChat = groupId == null || groupId.isEmpty();
        if (number == null) number = "";
        if (groupId == null) groupId = "";
        if (willBeHidden) {
            AppDatabase.get().hiddenMessageDao().insert(HiddenMessage.newBuilder()
                    .withNumber(number)
                    .withGroupId(groupId)
                    .withIsEncrypted(isEncrypted == 1)
                    .withPin_code("")
                    .withIsGroupChat(isGroupChat)
                    .build());
        } else {
            if (isGroupChat) AppDatabase.get().hiddenMessageDao().deleteByGroupId(groupId);
            else AppDatabase.get().hiddenMessageDao().deleteByNumber(number);
        }
    }


    public Cursor getGroupChatHistoryLog(String searchString, boolean isShowingHiddenChat) {
        if (isShowingHiddenChat) {
            return AppDatabase.get().messageDao().getGroupChatHistoryLogWithGroupHiddenChat("%" + searchString + "%");
        } else
            return AppDatabase.get().messageDao().getGroupChatHistoryLogWithOutGroupHiddenChat("%" + searchString + "%");
    }







    public Cursor getCombinedMessageLogs() {
        return AppDatabase.get().messageDao().getCombinedMessageLogs();
    }


    public Cursor getGroupMessageLogs() {
        return AppDatabase.get().messageDao().getGroupMessageLogs();
    }


    public Cursor searchGroupMessages(String searchString) {
        return AppDatabase.get().messageDao().searchGroupMessages("%" + searchString + "%");
    }


    public void updateMessageNotificationAsReadByNumber(String number) {
        AppDatabase.get().messageDao().clearUnreadEncryptedIMCount(number);
        AppDatabase.get().messageDao().clearUnreadNormalIMCount(number);
    }

    public void updateMessageNotificationAsReadByGroupID(String groupId) {
        AppDatabase.get().messageDao().clearUnreadEncryptedGroupCount(groupId);
        AppDatabase.get().messageDao().clearUnreadNormalGroupCount(groupId);
    }


    public int getGroupMessageNotificationByGroupId(String groupId) {
        return AppDatabase.get().messageDao().getGroupMessageNotificationByGroupId(groupId);
    }


    public int getMessageNotificationCount() {
        return AppDatabase.get().messageDao().getMessageNotificationCount();
    }

    public int getUnseenPersonMessagesCount() {
        return AppDatabase.get().messageDao().getUnseenPersonMessagesCount();
    }

    public Cursor getHTTPReceivingMessageLogs() {
        return AppDatabase.get().messageDao().getHTTPReceivingMessageLogs("%" + FileTransferViaHTTPHelper.SEND_FILE_PREFIX + "%");
    }


    public Cursor getLastReceivedMessage(String number) {
        return AppDatabase.get().messageDao().getLastReceivedMessage(number);
    }


    public boolean isLongMessage(String callID) {
        return AppDatabase.get().messageDao().isLongMessage(callID);
    }


    public void updateMessageIsReadyForView(String callerId, int isReadyForView) {
        AppDatabase.get().messageDao().updateMessageIsReadyForView(callerId, isReadyForView);
    }


    public Cursor getAppChatHistoryLog() {
        return AppDatabase.get().messageDao().getAppChatHistoryLog();
    }


    public Cursor getGroupChatHistoryLog() {
        return AppDatabase.get().messageDao().getGroupChatHistoryLog();
    }


    public Cursor getFutureChatHistoryLog() {
        return AppDatabase.get().messageDao().getFutureChatHistoryLog();
    }


    public Cursor getImsWithMediaByNumber(String number) {
        return AppDatabase.get().messageDao().getImsWithMediaByNumber(number);
    }


    public Cursor getImsWithMediaByNumberForDetail(String number) {
        return AppDatabase.get().messageDao().getImsWithMediaByNumberForDetail(number);
    }


    public Cursor getImsWithMediaByGroupId(String groupId) {
        return AppDatabase.get().messageDao().getImsWithMediaByGroupId(groupId);
    }


    public Cursor getImsWithMediaByGroupIdForDetail(String groupId) {
        return AppDatabase.get().messageDao().getImsWithMediaByGroupIdForDetail(groupId);
    }


    public List<String> getOnlyNumberList() {
        return AppDatabase.get().messageDao().getOnlyNumberList();
    }


    public List<String> getOnlyGroupIdList() {
        return AppDatabase.get().messageDao().getOnlyGroupIdList();
    }


    public void deleteOriginalCallerIDMessageAndUpdateTempWithTheOriginalInGroupMessage(String callerID) {
        String originalCallerId = callerID.split(IMConstants.CID_AND_FALSE_MULTIPART_CID_INDICATOR)[0];
        List<String> callerIdList = new ArrayList<>();
        callerIdList.add(originalCallerId);
        AppDatabase.get().messageDao().deleteMessageByCallIdList(callerIdList);
        Message message = Message.newBuilder().callerId(originalCallerId).build();
        AppDatabase.get().messageDao().insert(message);
    }


    public void updateMessageNotification(String number, int e2e) {
        if (e2e == 1) clearUnreadEncryptedIMCount(number);
        else clearUnreadNormalIMCount(number);
        AppDatabase.get().messageDao().updateSeenTime(number, System.currentTimeMillis(), IMConstants.SEND_FILE_PREFIX + "%");
    }


    public Cursor getFailedLongMessagesByGroupId(String groupId) {
        return AppDatabase.get().messageDao().getFailedLongMessagesByGroupId(groupId);
    }


    public Cursor getFailedLongMessagesByNumber(String number) {
        return AppDatabase.get().messageDao().getFailedLongMessagesByNumber(number);
    }


    public Cursor getAllFailedLongMessages() {
        return AppDatabase.get().messageDao().getAllFailedLongMessages();
    }


    public int getCountOfImsWithMediaByGroupId(String groupId) {
        return AppDatabase.get().messageDao().getCountOfImsWithMediaByGroupId(groupId);
    }


    public int getCountOfImsWithMediaByNumber(String number) {
        return AppDatabase.get().messageDao().getCountOfImsWithMediaByNumber(number);
    }


    public void deleteMessageByDelimitedNumbers(String numbers, int is_encrypted) {
        AppDatabase.get().messageDao().deleteMessageByNumberArray(numbers.split(","), is_encrypted);
    }




    public Cursor getConfinedChatHistory() {
        return AppDatabase.get().messageDao().getConfinedChatHistory();
    }


    public Cursor getSentConfinedMessageCountByNumber(String number) {
        return AppDatabase.get().messageDao().getSentConfinedMessageCountByNumber(number);
    }


    public Cursor getReceivedConfinedMessageCountByNumber(String number) {
        return AppDatabase.get().messageDao().getReceivedConfinedMessageCountByNumber(number);
    }


    public long getFutureSendTime(String callerID) {
        return AppDatabase.get().messageDao().getFutureSendTime(callerID);
    }
    public int getSendingOriginalTimeStamp(String callerID)
    {
        return AppDatabase.get().messageDao().getSendingOriginalTimeStampFlag(callerID);
    }

}
