package com.revesoft.itelmobiledialer.chat.mimeType;

import android.text.TextUtils;

import com.revesoft.itelmobiledialer.chat.chatWindow.ChatUtil;
import com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.arch.Supplier;
import com.revesoft.material.R;
import java.util.HashMap;

/**
 * @author Ifta on 6/7/2017.
 */

public class MimeTypeUtil {
    private static HashMap<String, MimeType> mimeTypeMap = new HashMap<>(MimeType.values().length);

    static {
        for (MimeType mimeType : MimeType.values()) {
            mimeTypeMap.put(mimeType.toString(), mimeType);
        }
    }

    public static MimeType getMimeTypeByName(String mimeTypeName) {
        if(TextUtils.isEmpty(mimeTypeName)){
            return MimeType.Text;
        }
        if (mimeTypeMap.containsKey(mimeTypeName)) {
            return mimeTypeMap.get(mimeTypeName);
        }
        return MimeType.Text;
    }

    public static MimeType getMimeType(String content) {
        if(content == null) {
            return MimeType.Text;
        }else if(ChatUtil.isStaticSticker(content)){
            return MimeType.StaticSticker;
        }else if(ChatUtil.isCallRejectSticker(content)){
            return MimeType.CallRejectSticker;
        } else if (ChatUtil.isCallContent(content)) {
            return MimeType.Call;
        } else if (ChatUtil.isFileContent(content)) {
            return getMimeTypeForFile(content);
        } else if (ChatUtil.isLocationContent(content)) {
            return MimeType.Location;
        } else if (ChatUtil.isLocationRequestContent(content)) {
            return MimeType.LocationRequest;
        } else if (ChatUtil.isSticker(content)) {
            return MimeType.Sticker;
        } else if (ChatUtil.isGifAnimation(content)) {
            return MimeType.GIF;
        } else if (ChatUtil.isCallRejectSticker(content)) {
            return MimeType.CallRejectSticker;
        } else if (ChatUtil.isLinkContent(content)) {
            return MimeType.Link;
        } else if (ChatUtil.isContactContent(content)) {
            return MimeType.Contact;
        }
        return MimeType.Text;
    }

    private static MimeType getMimeTypeForFile(String content) {
        if (!ChatUtil.isFileContent(content)) {
            return MimeType.Text;
        }
        String fileExtension = content.replace(IMConstants.SEND_FILE_PREFIX, "")
                .replace(IMConstants.SEND_FILE_SUFFIX, "")
                .replace(IMConstants.SEND_FILE_PREFIX_SENDER, "")
                .replace(Constants.SEND_FILE_SUFFIX_SENDER, "");
        fileExtension = fileExtension.split(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR)[0];
        if (!fileExtension.contains(".")) {
            return MimeType.Text;
        } else {
            fileExtension = fileExtension.substring(fileExtension.lastIndexOf('.')).replace(".", "").toLowerCase();
        }
        if (fileExtension.equalsIgnoreCase("gif")) {
            return MimeType.GIF;
        } else if (arrayContains(IMAGE_FILE_FORMAT, fileExtension)) {
            return MimeType.Image;
        } else if (arrayContains(VIDEO_FILE_FORMAT, fileExtension)) {
            return MimeType.Video;
        } else if (arrayContains(AUDIO_FILE_FORMATS, fileExtension)) {
            return MimeType.Audio;
        } else if (arrayContains(CONTACT_FILE_FORMAT, fileExtension)) {
            return MimeType.Contact;
        }
        return MimeType.Document;
    }


    public static MimeType getMimeTypeFromFilePath(String filePath){
        String fileExtension ="";
        if (!filePath.contains(".")) {
            return MimeType.Text;
        } else {
            fileExtension = filePath.substring(filePath.lastIndexOf('.')).replace(".", "").toLowerCase();
        }
        if (fileExtension.equalsIgnoreCase("gif")) {
            return MimeType.GIF;
        } else if (arrayContains(IMAGE_FILE_FORMAT, fileExtension)) {
            return MimeType.Image;
        } else if (arrayContains(VIDEO_FILE_FORMAT, fileExtension)) {
            return MimeType.Video;
        } else if (arrayContains(AUDIO_FILE_FORMATS, fileExtension)) {
            return MimeType.Audio;
        } else if (arrayContains(CONTACT_FILE_FORMAT, fileExtension)) {
            return MimeType.Contact;
        }
        return MimeType.Document;
    }

    private static final String[] IMAGE_FILE_FORMAT = {"jpg", "jpeg", "png", "bmp", "tiff", "jfif","webp"};
    private static final String[] VIDEO_FILE_FORMAT = {"mp4", "mov", "avi", "wmv", "flv", "asf", "avchd", "swf","webm"};
    private static final String[] AUDIO_FILE_FORMATS = {"m4a", "mp3", "aac", "wav", "ogg", "wma", "pcm", "aiff", "flac", "alac"};
    private static final String[] CONTACT_FILE_FORMAT = {"vcf"};

    private static boolean arrayContains(String[] searchingSource, String toBeSearched) {
        for (String item : searchingSource) {
            if (item.equals(toBeSearched)) {
                return true;
            }
        }
        return false;
    }

    public static String getHumanReadableMimeType(MimeType mimeType) {
        if(mimeType == MimeType.StaticSticker){
            return Supplier.getString(R.string.sticker);
        }
        if (mimeType == MimeType.LocationRequest) {
            String unreadableMime = mimeType.toString();
            String readableMime = unreadableMime.charAt(0) + "";
            for (int i = 1; i < unreadableMime.length(); i++) {
                if (Character.isUpperCase(unreadableMime.charAt(i))) {
                    readableMime += " " + Character.toLowerCase(unreadableMime.charAt(i));
                } else {
                    readableMime += unreadableMime.charAt(i);
                }
            }
            return readableMime;
        }
        return mimeType.toString();
    }
}
