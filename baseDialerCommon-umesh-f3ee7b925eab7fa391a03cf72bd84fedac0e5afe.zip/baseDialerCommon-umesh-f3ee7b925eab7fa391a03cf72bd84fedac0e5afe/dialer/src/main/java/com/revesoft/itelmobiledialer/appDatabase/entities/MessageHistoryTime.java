package com.revesoft.itelmobiledialer.appDatabase.entities;

import org.jetbrains.annotations.NotNull;

import java.util.Date;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author Ifta
 */
@Entity(tableName = "message_history_time_table")
public class MessageHistoryTime {

    @NotNull
    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "id")
    public long id;

    @ColumnInfo(name = "group_or_user")
    public String groupOrUser;

    @ColumnInfo(name = "from_date")
    public Date fromDate;

    @ColumnInfo(name = "to_date")
    public Date toDate;

    @ColumnInfo(name = "is_group_chat")
    public boolean isGroupChat;

    public MessageHistoryTime() {
    }

    private MessageHistoryTime(Builder builder) {
        id = System.currentTimeMillis();
        groupOrUser = builder.groupOrUser;
        fromDate = builder.fromDate;
        toDate = builder.toDate;
        isGroupChat = builder.isGroupChat;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private String groupOrUser;
        private Date fromDate;
        private Date toDate;
        private boolean isGroupChat;

        private Builder() {
        }

        public Builder withGroupOrUser(String val) {
            groupOrUser = val;
            return this;
        }

        public Builder withFromDate(Date val) {
            fromDate = val;
            return this;
        }

        public Builder withToDate(Date val) {
            toDate = val;
            return this;
        }

        public Builder withIsGroupChat(boolean val) {
            isGroupChat = val;
            return this;
        }

        public MessageHistoryTime build() {
            return new MessageHistoryTime(this);
        }
    }
}
