package com.revesoft.itelmobiledialer.did;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;

import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Rahat on 9/25/2017.
 */

public class DoNotDisturbAsynctask extends AsyncTask {
    int json = 1, csv = 0;
    int responseType = json;
    private final String DID_BASE_URL = DialerService.BILLING_URL + "/api/v2/did.jsp?";
    private final String userName, password, urlWithUserAndPass, urlWithUser;
    private String TAG = "DoNotDisturb";
    private int requestType;
    private int status;
    private Activity activity;
    private OnDoNotDisturbListener onDoNotDisturbListener;
    private ProgressDialog blockDialog;
    private String did_id;
    private boolean showToast;

    public DoNotDisturbAsynctask(int requestType, int status, Activity activity, OnDoNotDisturbListener onDoNotDisturbListener, String did_id, boolean showToast) {
        this.requestType = requestType;
        this.status = status;
        this.activity = activity;
        this.onDoNotDisturbListener = onDoNotDisturbListener;
        blockDialog = new ProgressDialog(activity);
        blockDialog.setMessage(activity.getString(R.string.please_wait));
        this.did_id = did_id;
        this.showToast = showToast;

        SharedPreferences preferences = activity.getSharedPreferences(Constants.COMMON_PREFERENCE_NAME,
                MODE_PRIVATE);
        userName = UserDataManager.getUserName();
        password = UserDataManager.getUserPassword();

        urlWithUserAndPass = DID_BASE_URL + "user=" + userName + "&pass=" + "";
        urlWithUser = DID_BASE_URL + "user=" + userName;

    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        blockDialog.show();
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        if (!isInternetAvailable()) {
            return "-1";
        }
        String firstUrl = buildFirstUrl(requestType);
        Log.d(TAG, "doInBackground: firstUrl: " + firstUrl);

        String nonceReceived = connectUrlAndReadStream(firstUrl, true);
        String md5 = createMD5Password(nonceReceived, userName, password);
        Log.e(TAG, "md5= " + md5);
        String secondUrl = buildSecondUrl(md5, nonceReceived, requestType);
        Log.d(TAG, "doInBackground: secondUrl: " + secondUrl);
        String secondResponse = connectUrlAndReadStream(secondUrl, false);
        Log.d(TAG, "doInBackground: secondresponse " + secondResponse);
        if (responseType == csv) {
            String[] responses = secondResponse.split("<br/>");
            String errorCode = getErrorCode(responses);
            Log.d(TAG, "doInBackground: error_code: " + errorCode);

            if (requestType == 6) { //get status
                return parseStatus(responses);
            }
            return errorCode;
        } else {
            String errorcode = "-1";
            try {
                JSONObject jsonObject = new JSONObject(secondResponse);
                errorcode = jsonObject.getString("status_code");
                if (requestType == 6)
                    return parseStatusJson(secondResponse);


            } catch (JSONException e) {
                e.printStackTrace();
            }
            return errorcode;
        }


    }

    private String parseStatusJson(String secondResponse) {

        String status = null;
        try {
            JSONObject jsonObject = new JSONObject(secondResponse);
            status = jsonObject.getString("status");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return status;
    }

    private String parseStatus(String[] responses) {
        if (responses.length > 1) {
            String firstResponse = responses[1];
            String[] statusArray = firstResponse.split("=");
            if (statusArray.length > 1) {
                return statusArray[1];

            }
        }
        return "";
    }

    private String getErrorCode(String[] responses) {
        if (responses.length > 0) {
            String firstResponse = responses[0];
            String[] errorCodeResponseArray = firstResponse.split("=");
            if (errorCodeResponseArray.length > 1) {
                return errorCodeResponseArray[1];

            }
        }
        return "";
    }

    private String buildSecondUrl(String md5, String nonceReceived, int requestType) {
        if (requestType == 6) { //get status
            return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&request_type=" + requestType + "&did_id=" + did_id;

        } else { //change status
            return urlWithUser + "&pass=" + md5 + "&nonce=" + nonceReceived + "&request_type=" + requestType + "&status=" + status + "&did_id=" + did_id;
        }

    }

    private String connectUrlAndReadStream(String urlStr, boolean isFirstUrl) {
        URL url = null;

        try {
            url = new URL(urlStr);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();


            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            if (isFirstUrl) {
                return readStreamFirstRequest(in);
            } else {
                return readStreamSecondRequest(in);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return "";
    }

    private String readStreamFirstRequest(InputStream content) {
        BufferedReader buffer = new BufferedReader(new InputStreamReader(content));

        String s, response = "", nonceReceived = "";
        try {
            while ((s = buffer.readLine()) != null) {
                response += s;
            }
            Log.d(TAG, "readStreamFirstRequest: " + response);
            if (responseType == csv) {
                String[] tmp = response.split(";");
                String status = tmp[0].replaceAll("[^0-9]", "");
                if (!status.equals("110") || tmp[1] == null) {
                    return null;
                }
                nonceReceived = tmp[1].substring(tmp[1].indexOf("=") + 1);
                Log.e("Thread :101 ", "Nonce= " + nonceReceived);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status_code").trim();
                    nonceReceived = jsonObject.getString("nonce").trim();
                    if (!status.equals("110") || nonceReceived == null) {
                        return null;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                Log.e("Thread :101 ", "Nonce= " + nonceReceived);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return nonceReceived;
    }

    private String readStreamSecondRequest(InputStream content) {
        BufferedReader buffer = new BufferedReader(new InputStreamReader(content));
        //response for req type 6: error_code=0<br/>status=0 in a single line

        String response = "";
        try {
            String s = "";
            while ((s = buffer.readLine()) != null) {

                if (!s.isEmpty()) {
                    // s = s.replaceAll("<br/>", "");
                    Log.d(TAG, "doInBackground:  buffer " + s);
//                    response += s + ",";
                    response += s;
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }

    private String buildFirstUrl(int requestType) {
        return urlWithUserAndPass + "&request_type=" + requestType;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        if (o instanceof String) {

            // rahat 06-11-2017
            if (((String) o).equals("-1")) {
                blockDialog.dismiss();
                Util.showNoNetworkDialog(activity);
                return;
            }

            if (requestType == 7) {
                String errorCode = (String) o;
                if (errorCode.equals("0")) {
                    if (status == 1) {
                        onDoNotDisturbListener.onDisable(showToast);

                    } else {
                        onDoNotDisturbListener.onEnable(showToast);
                    }
                } else {
                    onDoNotDisturbListener.onFailed(showToast);
                }
            } else if (requestType == 6) {
                //get status

                String status = (String) o;
                onDoNotDisturbListener.setSwitchStatus(status);
            }
        }

        blockDialog.dismiss();
    }

    private boolean isInternetAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }

    private String createMD5Password(String nonce, String username, String password) {

        String md5String = nonce + username + password;

        Log.d(TAG, "String to be md5 " + md5String);
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
            md.update(md5String.getBytes("UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        byte[] mdbytes = md.digest();
        // convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < mdbytes.length; i++) {
            sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
        }
        return sb.toString();

    }
}
