package com.revesoft.itelmobiledialer.chat.chatWindow.interfaces;

import com.revesoft.itelmobiledialer.phonebook.Contact;

import java.util.ArrayList;

/**
 * @author Ifta on 12/31/2017.
 */

public interface ContactSelector {
    void onContactClick(Contact contact);
    ArrayList<Contact> getSelectedContacts();
}
