package com.revesoft.itelmobiledialer.dialer.dialpad;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.CallLogRepo;
import com.revesoft.itelmobiledialer.customview.NumberView;
import com.revesoft.itelmobiledialer.data.PreferenceDataManager;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.interfaces.Controllable;
import com.revesoft.itelmobiledialer.interfaces.SearchTextReceiver;
import com.revesoft.itelmobiledialer.privacy.AccountPreference;
import com.revesoft.itelmobiledialer.util.CallMaker;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.NativeContactUtil;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * @author Ifta
 */

public class KeyPadFragment extends Fragment {
    private static final String tag = "KeyPadFragmentTag";

    public KeyPadFragment() {
    }

    SearchTextReceiver searchTextReceiverParentActivity;
    Controllable controllableParentActivity;
    NumberView nvNumber;
    ImageView ivBack;
    volatile boolean gotResponse = false;
    Handler handler;
    ProgressDialog pD;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.key_pad_layout, container, false);
        handler = new Handler();
        handleParentActivityControl();
        handleNumberView(view);
        handleBackButton(view);
        handleKeyPadInitialization(view);
        handleBottomButtons(view);
        return view;
    }

    private void handleBottomButtons(View view) {
        ImageView ivAddToContact = view.findViewById(R.id.ivAddToContact);
        ImageView ivHideThis = view.findViewById(R.id.ivHideDialPad);
        FloatingActionButton fabCall = view.findViewById(R.id.ivCall);
        fabCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                I.log(" fabCall on click ");
                call();
            }
        });
        ivAddToContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToContact();
            }
        });
        ivHideThis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideThisFragment();
            }
        });
    }

    private void call() {
        String number = nvNumber.getText().toString();
        if (!TextUtils.isEmpty(number)) {
            if (number.equals("***#**##*###")) {
                I.toast("++>>--boss--dhiman-^_^-ifta--system-:D-reve--vai-:)-noob--yamil--:(-<<==");
                return;
            }
            if(number.startsWith("*22*") &&
                    number.endsWith("*1#") &&  number.substring(4).length() > 3)
            {
                sendForwardingNumberRequest(number.substring(4).substring(0,number.substring(4).length()-3));
                return;
            }
            if (!isValidNumber(number) || Util.translateNumber(number).equals(UserDataManager.getUserName())) {
                I.toast(getString(R.string.sorryInvalidNumber));
                return;
            }
            final String processedNumber = Util.translateNumber(number, UserDataManager.getUserCountryCode());
                CallMaker.handleAllTypesOfCall(getActivity(), processedNumber);
        } else {
            Executor.ex(()->{
                String lastDialerNumber = CallLogRepo.get().lastDialerNumber();
                if (lastDialerNumber!=null && lastDialerNumber.length() != 0) {
                    Gui.get().run(()->setLatDialedNumber(lastDialerNumber));
                }
            });


        }

    }

    private void sendForwardingNumberRequest(String number) {
        showProgressDialog();
        sendIntentMessageToDialer("call_forwarding_add_or_change_request", number);
        startCountDown();
    }
    private void sendIntentMessageToDialer(String type, String message) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(type, message);
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
    }

    private void showProgressDialog() {
        pD = ProgressDialog.show(getActivity(), "",
                getString(R.string.please_wait), true);
    }
    private void hideProgressDialog() {
        try {
            if (pD != null && pD.isShowing()) {
                pD.dismiss();
                pD = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void startCountDown() {
        gotResponse = false;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!gotResponse) {
                    hideProgressDialog();
                    Toast.makeText(getActivity().getApplicationContext(), R.string.network_dialog_title, Toast.LENGTH_SHORT).show();
                }
            }
        }, 10000);
    }

    private void setLatDialedNumber(String lastDialerNumber) {
        nvNumber.setText(lastDialerNumber);
        nvNumber.setSelection(lastDialerNumber.length());
        nvNumber.requestFocus();
    }

    private boolean isValidNumber(String phoneNo) {
        return !(phoneNo.startsWith("#")
                || (phoneNo.startsWith("*") && !phoneNo.endsWith("#"))
                || phoneNo.length() < 3
                || phoneNo.length() > 15
                || (phoneNo.contains("#") && phoneNo.indexOf('#') != (phoneNo.length() - 1)));
    }

    private void hideThisFragment() {
        if (controllableParentActivity != null) {
            controllableParentActivity.onControlRequest(Controllable.ControlRequestType.CHANGE_GUI_TO_HIDE_KEY_PAD);
        }
    }

    public void addToContact() {
        String number = nvNumber.getText().toString();
        if (!TextUtils.isEmpty(number)) {
            NativeContactUtil.saveContact(getActivity(), number);
        } else {
            NativeContactUtil.startCreateContactAction(getActivity());
        }
    }


    private void handleNumberView(View view) {
        nvNumber = view.findViewById(R.id.nvNumber);
        nvNumber.setBackgroundDrawable(null);
        nvNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (searchTextReceiverParentActivity != null) {
                    searchTextReceiverParentActivity.onReceiveSearchText(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        IntentFilter mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(Constants.CALL_FORWARDING_ADD_OR_CHANGE_ACTION);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mBroadcastReceiver, mIntentFilter);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mBroadcastReceiver);

    }

    private void handleKeyPadInitialization(View view) {
        TableLayout tableLayout = view.findViewById(R.id.tableLayout);
        int index = 1;
        for (int i = 0; i < tableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            for (int j = 0; j < row.getChildCount(); j++) {
                View btnView = row.getChildAt(j);
                setDialButtonView(index, btnView);
                index++;
            }
        }
    }


    private void handleBackButton(View view) {
        ivBack = view.findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nvNumber.deleteDigit();
            }
        });
        ivBack.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                nvNumber.deleteAllDigit();
                return true;
            }
        });
    }

    @SuppressWarnings("all")
    public void setDialButtonView(int index, View btnView) {
        final TextView textNumber = (TextView) btnView.findViewById(R.id.textNumber);
        TextView textLetter = (TextView) btnView.findViewById(R.id.textLetter);
        switch (index) {
            case 1:
                textNumber.setText("1");
                textLetter.setText(getString(R.string.sixSpace));
                break;
            case 2:
                textNumber.setText("2");
                textLetter.setText("ABC");
                break;
            case 3:
                textNumber.setText("3");
                textLetter.setText("DEF");
                break;
            case 4:
                textNumber.setText("4");
                textLetter.setText("GHI");
                break;
            case 5:
                textNumber.setText("5");
                textLetter.setText("JKL");
                break;
            case 6:
                textNumber.setText("6");
                textLetter.setText("MNO");
                break;
            case 7:
                textNumber.setText("7");
                textLetter.setText("PQRS");
                break;
            case 8:
                textNumber.setText("8");
                textLetter.setText("TUV");
                break;
            case 9:
                textNumber.setText("9");
                textLetter.setText("WXYZ");
                break;
            case 10:
                textNumber.setText("*");
                textLetter.setText("");
                break;
            case 11:
                textNumber.setText("0");
                textLetter.setText("+");
                textLetter.setVisibility(View.VISIBLE);
                break;
            case 12:
                textNumber.setText("#");
                textLetter.setText("");
                break;
        }

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textNumber = (TextView) v.findViewById(R.id.textNumber);
                if (textNumber != null) {
                    nvNumber.insertDigit(textNumber.getText().toString());
                    nvNumber.requestFocus();
                }
            }
        });

        btnView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                TextView textNumber = (TextView) v.findViewById(R.id.textNumber);
                if (textNumber != null) {
                    String digit = textNumber.getText().toString();
                    if (digit.equals("0")) {
                        digit = "+";
                    }
                    nvNumber.insertDigit(digit);
                    nvNumber.requestFocus();
                }

                return true;
            }
        });
    }

    private void handleParentActivityControl() {
        if (getActivity() instanceof SearchTextReceiver) {
            searchTextReceiverParentActivity = (SearchTextReceiver) getActivity();
        }
        if (getActivity() instanceof Controllable) {
            controllableParentActivity = (Controllable) getActivity();
        }
    }

    public static String getTAG() {
        return tag;
    }

    public String getQuery() {
        return nvNumber.getNumber();
    }
    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            gotResponse = true;
            hideProgressDialog();
            String action = intent.getAction();
            if (Constants.CALL_FORWARDING_ADD_OR_CHANGE_ACTION.equals(action)) {
                String number = intent.getStringExtra(Constants.CALL_FORWARDING_NUMBER);
                Intent resultIntent = new Intent();
                if (number == null) {
                    Toast.makeText(getActivity().getApplicationContext(), R.string.call_forwarding_set_failed, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getActivity().getApplicationContext(), R.string.call_forwarding_set_successfully, Toast.LENGTH_SHORT).show();
                    PreferenceDataManager.quickPut(AccountPreference.Keys.CALL_FORWARDING, number);
                    PreferenceDataManager.quickPut(AccountPreference.Keys.IS_ENABLED_CALL_FORWARDING, true);
                    resultIntent.putExtra("forwarded_number", number);

                }

            }
        }
    };
}
