package com.revesoft.itelmobiledialer.chat.chatWindow;

import android.net.Uri;
import android.text.TextUtils;

import com.google.android.gms.maps.model.LatLng;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatContentParser;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.signalling.newMessaging.IMConstants;
import com.revesoft.itelmobiledialer.signalling.sipUtil.ByteArray;
import com.revesoft.itelmobiledialer.util.Constants;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Ifta on 6/6/2017.
 */

public class ChatUtil {
    public static boolean isFileContent(String content) {
        return (content.startsWith(IMConstants.SEND_FILE_PREFIX) && content.endsWith(IMConstants.SEND_FILE_SUFFIX)) ||
                (content.startsWith(IMConstants.SEND_FILE_PREFIX_SENDER) && content.endsWith(Constants.SEND_FILE_SUFFIX_SENDER));
    }

    public static boolean isContactContent(String content) {
        return content.startsWith(Constants.CONTACT_MESSAGE_PREFIX) && content.endsWith(Constants.CONTACT_MESSAGE_SUFFIX);
    }

    public static boolean isLocationContent(String content) {
        return content.startsWith(Constants.LOCATION_PREFIX) && content.endsWith(Constants.LS_SUFIX);
    }

    public static boolean isLocationRequestContent(String content) {
        return content.startsWith(Constants.ASK_LOCATION_MESSAGE_PREFIX) && content.endsWith(Constants.ASK_LOCATION_MESSAGE_SUFFIX);
    }

    public static boolean isLinkContent(String content) {
        return extractUrls(content).size() > 0;
    }

    public static String getFilePathFromContent(String content) {
        String filePath = null;
        if (isFileMessage(content)) {
            int firstSubStringEndIndex = content.indexOf(IMConstants.SEND_FILE_URI_CAPTION_SEPARATOR);
            if (firstSubStringEndIndex == -1) {
                firstSubStringEndIndex = content.indexOf(IMConstants.SEND_FILE_SUFFIX);
            }
            filePath = content.substring(0, firstSubStringEndIndex).replace(IMConstants.SEND_FILE_PREFIX, "").replace(IMConstants.SEND_FILE_PREFIX_SENDER, "");
//            I.log("file path after 1st strip : "+filePath);
        }
        return filePath;
    }

    //        public static final String SEND_FILE_SUFFIX = "}}}";
//        public static final String SEND_FILE_PREFIX_SENDER = "senderSendFILESender:{{{";
//        public static final String SEND_FILE_SUFFIX_SENDER = "}}}";
//        public static final String SEND_FILE_URI_CAPTION_SEPARATOR = ":::::";
//        public static final String FILE_SEEN_MESSAGE_PREFIX = "_remoteFile_remoteCallID{{";
    public static String getRemoteCallId(String content) {
        final String REMOTE_CALL_ID_START = "remoteCallID{{";
        final String REMOTE_CALL_ID_END = "}}";
        String remoteCallId = null;
        if (content.contains(REMOTE_CALL_ID_START)) {
            remoteCallId = content.substring(content.indexOf(REMOTE_CALL_ID_START))
                    .replace(REMOTE_CALL_ID_START, "");
            remoteCallId = remoteCallId.substring(0, remoteCallId.indexOf(REMOTE_CALL_ID_END)).replace(REMOTE_CALL_ID_END, "");
        }
        return remoteCallId;
    }

    public static boolean isFileMessage(String content) {
        return (content.startsWith(IMConstants.SEND_FILE_PREFIX) || content.startsWith(IMConstants.SEND_FILE_PREFIX_SENDER)) && content.endsWith(IMConstants.SEND_FILE_SUFFIX);
    }

    public static boolean isSendingFile(String content) {
        return content.startsWith(IMConstants.SEND_FILE_PREFIX_SENDER) && content.endsWith(Constants.SEND_FILE_SUFFIX_SENDER);
    }

    public static boolean isGifAnimation(String content) {
        return content.startsWith(Constants.GIF_PREFIX) && content.endsWith(Constants.GIF_SUFFIX);
    }

    public static boolean isSticker(String content) {
        return content.startsWith(Constants.STICKER_PREFIX) && content.endsWith(Constants.STICKER_SUFFIX);
    }

    public static boolean isCallRejectSticker(String content) {
        return content.startsWith(Constants.CALL_REJECT_STICKER_PREFIX) && content.endsWith(Constants.CALL_REJECT_STICKER_SUFFIX);
    }

    //    public static  String getCaption(String messageContent) {
//        String caption = "";
//        if (messageContent.contains(Constants.SEND_FILE_URI_CAPTION_SEPARATOR)) {
//            caption = messageContent.substring(messageContent.indexOf(Constants.SEND_FILE_URI_CAPTION_SEPARATOR))
//                    .replace(Constants.SEND_FILE_URI_CAPTION_SEPARATOR, "");
//            if (caption.contains(Constants.SEND_FILE_URI_REMOTE_CALL_ID)) {
//                caption = caption.substring(0, caption.indexOf(Constants.SEND_FILE_URI_REMOTE_CALL_ID))
//                        .replace(Constants.SEND_FILE_URI_CAPTION, "")
//                        .replace(Constants.SEND_FILE_URI_RECEIVED_FILE_CAPTION_PREFIX, "")
//                        .replace(Constants.SEND_FILE_URI_RECEIVED_FILE_CAPTION_SUFFIX, "");
//            } else {
//                caption = caption.replace(Constants.SEND_FILE_PREFIX, "")
//                        .replace(Constants.SEND_FILE_PREFIX_SENDER, "")
//                        .replace(Constants.SEND_FILE_SUFFIX, "");
//            }
//        }
//        return caption;
//    }
    private static ArrayList<String> extractUrls(String input) {
        ArrayList<String> result = new ArrayList<>();
        input = input.toLowerCase();
        Pattern pattern = Pattern.compile(
                "\\b(((ht|f)tp(s?)\\:\\/\\/|~\\/|\\/)|www.)" +
                        "(\\w+:\\w+@)?(([-\\w]+\\.)+(com|org|net|gov" +
                        "|mil|biz|info|mobi|name|aero|jobs|museum" +
                        "|travel|[a-z]{2}))(:[\\d]{1,5})?" +
                        "(((\\/([-\\w~!$+|.,=]|%[a-f\\d]{2})+)+|\\/)+|\\?|#)?" +
                        "((\\?([-\\w~!$+|.,*:]|%[a-f\\d{2}])+=?" +
                        "([-\\w~!$+|.,*:=]|%[a-f\\d]{2})*)" +
                        "(&(?:[-\\w~!$+|.,*:]|%[a-f\\d{2}])+=?" +
                        "([-\\w~!$+|.,*:=]|%[a-f\\d]{2})*)*)*" +
                        "(#([-\\w~!$+|.,*:=]|%[a-f\\d]{2})*)?\\b");

        Matcher matcher = pattern.matcher(input);
        while (matcher.find()) {
            result.add(matcher.group());
        }
        return result;
    }


//    private static HashMap<MimeType,Integer> mimeTypeDrawableMap = new HashMap<>(MimeType.values().length);
//    static {
//        mimeTypeDrawableMap.put(MimeType.Audio, R.drawable.ic_audio_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Video, R.drawable.ic_video_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Contact, R.drawable.ic_contact_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Document, R.drawable.ic_document_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Location, R.drawable.ic_location_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Image, R.drawable.ic_gallery_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Link, R.drawable.ic_link_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Call, R.drawable.ic_calls_missed);
//        mimeTypeDrawableMap.put(MimeType.LocationRequest, R.drawable.ic_location_chat_history);
//        mimeTypeDrawableMap.put(MimeType.Text, 0);
//    }

//    static int getDrawableIdForMimeType(MimeType mimeType){
//        if( mimeTypeDrawableMap.containsKey(mimeType)){
//           return mimeTypeDrawableMap.quickGet(mimeType);
//        }
//        return 0;
//    }
//    static int getLastMessageStatusDrawableId(MessagesFragmentCombined.MessageListAdapter.Message message){
//        int messageDeliveryStatusDrawableId = 0;
//        if (message.messageType == MessageEntry.MessageType.SEND) {
//            switch (message.deliveryStatus) {
//                case MessageEntry.DeliveryStatus.FAILED:
//                    messageDeliveryStatusDrawableId = R.drawable.ic_error_chat_history;
//                    break;
//                case MessageEntry.DeliveryStatus.NO_REPLY:
//                    messageDeliveryStatusDrawableId = R.drawable.ic_chat_clock;
//                    break;
//                case MessageEntry.DeliveryStatus.PENDING:
//                    messageDeliveryStatusDrawableId = R.drawable.ic_chat_send;
//                    break;
//                case MessageEntry.DeliveryStatus.RECEIVING:
//                    break;
//                case MessageEntry.DeliveryStatus.SEEN:
//                    messageDeliveryStatusDrawableId = R.drawable.ic_chat_seen;
//                    break;
//                case MessageEntry.DeliveryStatus.SUCCESSFUL:
//                    messageDeliveryStatusDrawableId = R.drawable.ic_chat_delevered;
//                    break;
//            }
//        }
//        return messageDeliveryStatusDrawableId;
//    }

    public static boolean isCurrentTimeWithin24Hours(long time) {
        return System.currentTimeMillis() - time < 24 * 60 * 60 * 1000;
    }

    public static boolean isCallContent(String content) {
        return content.startsWith(Constants.Call.MISSED_CALL_MESSAGE_PREFIX) && content.endsWith(Constants.Call.MISSED_CALL_MESSAGE_SUFFIX);
    }

    public static Uri getMapPreviewUri(String content) {
        LatLng latLng = ChatContentParser.parseLocation(content);
        if (latLng != null) {
            String mapUri = "https://maps.googleapis.com/maps/api/staticmap?zoom=14&size=240x180&markers=size:mid|color:red|"
                    + latLng.latitude
                    + ","
                    + latLng.longitude
                    + "&sensor=false";
            return Uri.parse(mapUri);
        }
        return null;
    }


    public static boolean isUploadingOrDownloadingNow(Message message) {
        return message.content.startsWith(IMConstants.SEND_FILE_PREFIX_SENDER) && message.content.endsWith(Constants.SEND_FILE_SUFFIX_SENDER)
                || message.deliveryStatus == MessageEntry.DeliveryStatus.RECEIVING;
    }

    public static boolean isDownloadingNow(Message message) {
        return (message.content.startsWith(IMConstants.SEND_FILE_PREFIX_SENDER) && message.content.endsWith(Constants.SEND_FILE_SUFFIX_SENDER) && message.messageType == MessageEntry.MessageType.RECEIVED)
                || (message.deliveryStatus == MessageEntry.DeliveryStatus.RECEIVING && message.messageType == MessageEntry.MessageType.RECEIVED);
    }

    public static boolean isSendingNow(Message message) {
        return (message.content.startsWith(IMConstants.SEND_FILE_PREFIX_SENDER) && message.content.endsWith(Constants.SEND_FILE_SUFFIX_SENDER) && message.messageType == MessageEntry.MessageType.SEND)
                || (message.deliveryStatus == MessageEntry.DeliveryStatus.PENDING && message.messageType == MessageEntry.MessageType.SEND);
    }

    public static boolean isStaticSticker(String content) {
        return !TextUtils.isEmpty(content) && content.startsWith(Constants.STATIC_STICKER_PREFIX) && content.endsWith(Constants.STATIC_STICKER_SUFFIX);
    }

    public static String getQuoteMessageData(com.revesoft.itelmobiledialer.appDatabase.entities.Message messageToQuote) {
       return getQuoteMessageData(messageToQuote.content);
    }
    public static String getQuoteMessageData(String textString) {
        ByteArray text =  new ByteArray(textString);
        if(textString.length() <= Constants.MAX_QUOTE_LIMIT || textString.contains(IMConstants.SEND_FILE_PREFIX))
            return text.toString();
        byte[] bytes = text.getBytes();
        int currentBeginPosition = 0;
        ByteArray part = new ByteArray(bytes, currentBeginPosition,  Constants.MAX_QUOTE_LIMIT );
        String tempString = part.toString();

        CharsetDecoder decoder = Charset.forName("UTF-8").newDecoder();
        decoder.onMalformedInput(CodingErrorAction.REPORT);
        decoder.onUnmappableCharacter(CodingErrorAction.REPORT);

        if ( tempString.length() > 25) {
            ByteArray temp = new ByteArray(part);
            boolean decoded = false;
            int counter = 20;
            CharBuffer parsed = null;
            while (!decoded && counter >= 0) {
                try {
                    ByteBuffer bb = ByteBuffer.wrap(temp.getBytes());
                    parsed = decoder.decode(bb);
                    decoded = true;
                } catch (Exception e) {
                    decoded = false;
                    counter--;
                    temp.length--;
                }
            }
            String tempShorten;
            if (parsed == null) {
                tempShorten = part.toString();
            } else {
                tempShorten = parsed.toString();
            }
            return  tempShorten;
        }
        return part.toString() ;
    }
}
