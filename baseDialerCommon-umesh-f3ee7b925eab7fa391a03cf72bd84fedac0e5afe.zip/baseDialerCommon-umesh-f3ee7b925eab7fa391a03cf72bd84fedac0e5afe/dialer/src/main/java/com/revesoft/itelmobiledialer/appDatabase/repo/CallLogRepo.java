package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;
import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.CallLog;
import com.revesoft.itelmobiledialer.callog.callLogList.QueryItemCallLogList;
import com.revesoft.itelmobiledialer.data.MissedCallCounter;
import com.revesoft.itelmobiledialer.databaseentry.CallLogEntry;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.TimeFormat;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;

public class CallLogRepo {
    private static final CallLogRepo ourInstance = new CallLogRepo();

    public static CallLogRepo get() {
        return ourInstance;
    }

    private CallLogRepo() {
    }


    public List<CallLog> getAll() {
        return AppDatabase.get().callLogDao().getAll();
    }


    public LiveData<List<CallLog>> getAllLiveByNumber(String number) {
        return AppDatabase.get().callLogDao().getAllLiveByNumber(number);
    }


    private List<CallLog> getCallLogByNumber(String number) {
        return AppDatabase.get().callLogDao().getCallLogByNumber(number);
    }


    public LiveData<List<CallLog>> getAllLive() {
        return AppDatabase.get().callLogDao().getAllLive();
    }


    public DataSource.Factory<Integer, CallLog> getAllLivePaged() {
        return AppDatabase.get().callLogDao().getAllLivePaged();
    }


    public DataSource.Factory<Integer, QueryItemCallLogList> getAllLivePagedFiltered(String filter) {
        return AppDatabase.get().callLogDao().getAllLivePagedFiltered(filter);
    }


    public void DeleteByCallID(String id) {
        AppDatabase.get().callLogDao().DeleteByCallID(id);
    }


    public boolean shouldShowRateAppDialog() {
        return callLogCountOverSpecificDuration(4500) >= 5;
    }


    private int callLogCountOverSpecificDuration(long duration) {
        return AppDatabase.get().callLogDao().callLogCountOverSpecificDuration(duration);
    }


    public void createCallLog(CallLogEntry callLogEntry) {
        CallLog callLog = CallLog.createFromCallLogEntry(callLogEntry);
        AppDatabase.get().callLogDao().insert(callLog);
        handleMissedCallRelatedTasks(callLogEntry);

    }


    private void handleMissedCallRelatedTasks(CallLogEntry callLogEntry) {
        if (callLogEntry.callType == CallLogEntry.CallLogType.MISSED) {
            MissedCallCounter.incrementCount();
            MissedCallCounter.sendSignalToDashBoard();
            MessageEntry messageEntry = getMessageEntryForCallByCallLog(callLogEntry);
            MessageRepo.get().createMessageLog(messageEntry);
        }
    }


    private MessageEntry getMessageEntryForCallByCallLog(CallLogEntry callLogEntry) {
        MessageEntry messageEntry = new MessageEntry();
        messageEntry.number = callLogEntry.number;
        messageEntry.time = callLogEntry.time;
        messageEntry.status = MessageEntry.MessageStatus.READ;
        String callType;

        if (callLogEntry.isVideoCall) {
            if (callLogEntry.type == CallLogEntry.CallLogType.MISSED) {
                callType = "Missed video call";
            } else if (callLogEntry.type == CallLogEntry.CallLogType.INCOMING) {
                callType = "Incoming video call";
            } else if (callLogEntry.type == CallLogEntry.CallLogType.OUTGOING) {
                callType = "Outgoing video call";
            } else {
                callType = "Call through video call";
            }
        } else {
            if (callLogEntry.type == CallLogEntry.CallLogType.MISSED) {
                callType = "Missed audio call";
            } else if (callLogEntry.type == CallLogEntry.CallLogType.INCOMING) {
                callType = "Incoming audio call";
            } else if (callLogEntry.type == CallLogEntry.CallLogType.OUTGOING) {
                callType = "Outgoing audio call";
            } else {
                callType = "Call through audio call";
            }
        }
        messageEntry.content = Constants.Call.CALL_MESSAGE_PREFIX + callType + Constants.Call.CALL_MESSAGE_SUFFIX;
        messageEntry.type = MessageEntry.MessageType.RECEIVED;
        messageEntry.callerId = callLogEntry.number + System.currentTimeMillis() + Util.random();
        messageEntry.delivery_status = MessageEntry.DeliveryStatus.SUCCESSFUL;
        messageEntry.filePath = null;
        return messageEntry;
    }


    private List<CallLogEntry> convertToEntryList(List<CallLog> callLogs) {
        List<CallLogEntry> callLogEntries = new ArrayList<>();
        for (CallLog callLog : callLogs) callLogEntries.add(callLog.convertCallLogEntry());
        return callLogEntries;
    }


    public String lastDialerNumber() {
        return AppDatabase.get().callLogDao().lastDialerNumber();
    }


    private List<CallLog> getMissedCall() {
        return AppDatabase.get().callLogDao().getMissedCall();
    }

    public List<CallLogEntry> getMissedCallEntry() {

        return convertToEntryList(getMissedCall());
    }


    public List<CallLog> getCallLogByDate(String number, long date) {
        String convertedRefDate = "";
        if (date > 0) convertedRefDate = TimeFormat.getDateHeader(date);
        List<CallLog> callLogs = getCallLogByNumber(number);
        List<CallLog> callLogListByDate = new ArrayList<>();
        for (CallLog callLog : callLogs) {
            String convertedDate = TimeFormat.getDateHeader(callLog.date.getTime());
            if (!TextUtils.isEmpty(convertedDate) && convertedDate.equalsIgnoreCase(convertedRefDate))
                callLogListByDate.add(callLog);
        }
        return callLogListByDate;
    }

    public List<CallLogEntry> getCallLogEntryByDate(String number, long date) {
        return convertToEntryList(getCallLogByDate(number, date));
    }


    public void deleteById(int callLogId) {
        AppDatabase.get().callLogDao().deleteById(callLogId);
    }


    public void deleteAll() {
        AppDatabase.get().callLogDao().deleteAll();
    }

    public void deleteCallLogByDelimitedIds(String delimitedCallLogIds) {
        String[] callLogIds = delimitedCallLogIds.split(",");
        for (String callLogId : callLogIds) deleteById(Integer.parseInt(callLogId));
    }


    public Cursor getMostCalledLogs(int limit) {
        return AppDatabase.get().callLogDao().getMostCalledLogs(limit);
    }


    public Cursor getCallLogsWithNameAndPic(String searchText, int count) {
        Cursor cursor = null;
        try {
            String rawQuery = "SELECT * from (" +
                    "SELECT l._id as _id, l.number as number, l.type as type, l.call_type as call_type, is_video_call, call_rate, l.date as date, l.duration as duration, c.name as name, c.photo_uri as photo_uri, s.number as subscribed_number, c.lookup_key as lookup_key " +
                    " FROM log l LEFT JOIN contacts c ON (" +
                    "l.number = c.processed_number OR l.processed_number=c.processed_number" +
                    ") LEFT JOIN subscriber s ON s.number = l.number OR s.number = l.processed_number" +
                    ") temp WHERE temp.name LIKE '%" + searchText + "%' OR temp.number LIKE '%" + searchText + "%' " +
                    "GROUP BY temp._id ORDER BY temp.date desc ";

            if (count > 0) {
                rawQuery += " LIMIT " + count;
            }
            cursor = AppDatabase.get().rawQuery(rawQuery);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cursor;
    }
}
