package com.revesoft.itelmobiledialer.chat.chatWindow.theWindow;

import android.app.Dialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.iftalab.runtimepermission.AppPermissionListener;
import com.iftalab.runtimepermission.DangerousPermission;
import com.revesoft.itelmobiledialer.Config.Features;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.TaskFinishListener;
import com.revesoft.itelmobiledialer.appDatabase.entities.Group;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.FullscreenCameraCaptureActivity;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.ImageGalleryFragment;
import com.revesoft.itelmobiledialer.chat.cameraAndImage.SelectedMediaDataHolder;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatConstants;
import com.revesoft.itelmobiledialer.chat.chatWindow.ChatDialogs;
import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.chat.chatWindow.Switcher;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.EmoGifStickerFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.GoogleMapFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.ImportFileFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.SoundRecorderFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.StaticStickerFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.StickeroidFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bottomFragments.TenorFragment;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.ChatWindowEventListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.DialerServiceEvent;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.DialerServiceEventHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.DialerServiceEventListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.bridge.FileProgressHook;
import com.revesoft.itelmobiledialer.chat.chatWindow.futureMessage.FutureMessageTimeDialogs;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.DraftManager;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.SeenSender;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.Target;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Controllable;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.MessageSelectionInteractionListener;
import com.revesoft.itelmobiledialer.chat.chatWindow.interfaces.Searchable;
import com.revesoft.itelmobiledialer.chat.chatWindow.media.ChatMediaPlayer;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageCache;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageHighlighter;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageQuoteInfo;
import com.revesoft.itelmobiledialer.chat.chatWindow.memory.MessageSelection;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageBurn.BurnTimePicker;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.ContactSender;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.Sender;
import com.revesoft.itelmobiledialer.chat.chatWindow.messageSender.SendingConstants;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.jetPack.ChatWindowSupportingViewModel;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.jetPack.ChatWindowViewModel;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.jetPack.ChatWindowViewModelFactory;
import com.revesoft.itelmobiledialer.chat.chatWindow.theWindow.quote.MessageQuoteFragment;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;
import com.revesoft.itelmobiledialer.chat.share.ShareActivity;
import com.revesoft.itelmobiledialer.confide.Smoker;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickerActivity;
import com.revesoft.itelmobiledialer.contact.picker.ContactSelectiontype;
import com.revesoft.itelmobiledialer.customview.SQLiteCursorLoader;
import com.revesoft.itelmobiledialer.data.CommonData;
import com.revesoft.itelmobiledialer.data.NameResolver;
import com.revesoft.itelmobiledialer.data.SubscriberStatusProvider;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.databaseentry.DatabaseConstants;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.e2eencryption.E2EPublicKeySeedAndPrivateKeyHolder;
import com.revesoft.itelmobiledialer.e2eencryption.End2EndEncryption;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.FileUtils;
import com.revesoft.itelmobiledialer.ims.LocationSendActivity;
import com.revesoft.itelmobiledialer.ims.group.MessageStatusDetailsActivityGroup;
import com.revesoft.itelmobiledialer.jetPackHelpers.viewModel.FilterableViewModelOwner;
import com.revesoft.itelmobiledialer.multipartHelper.MultipartViaFileHandler;
import com.revesoft.itelmobiledialer.processor.historyfetching.HistoryFetchRequestSender;
import com.revesoft.itelmobiledialer.processor.historyfetching.IMHistorySyncHelper;
import com.revesoft.itelmobiledialer.sdkdb.repository.MessageHistoryTimeRepo;
import com.revesoft.itelmobiledialer.service.DialerService;
import com.revesoft.itelmobiledialer.util.AppIconNotification;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.Delayer;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.LanguageManager;
import com.revesoft.itelmobiledialer.util.TaggedLogger;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.itelmobiledialer.wrappres.CallMaker;
import com.revesoft.itelmobiledialer.xdatabase.DatabaseUris;
import com.revesoft.material.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.paging.PagedList;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import hani.momanii.supernova_emoji_library.Actions.EmojIconActions;
import hani.momanii.supernova_emoji_library.Helper.EmojiconEditText;

import static com.revesoft.itelmobiledialer.xdatabase.DatabaseUris.MESSAGE_URI;



/**
 * @author Ifta on 12/7/2017.
 */


public class ChatWindowActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>, Controllable, DialerServiceEventListener, ChatWindowEventListener, FilterableViewModelOwner {
    private final TaggedLogger logger = new TaggedLogger("ChatWindow");
    public static final String TOP_BAR_INFO_CHANGED = "TOP_BAR_INFO_CHANGED";
    private boolean isGroupChat = false;
    private boolean isSMSChat = false;
    private boolean isBroadCastIM = false;
    private String target;
    private final String searchText = "";
    private boolean isEncrypted = false;
    private boolean isInSearchingMode = false;
    private static Dialog dialog;
    private static AlertDialog.Builder builder;
    private Message messageTobeEdit;


    private boolean failedLongImRetryFlag = true;

    @Override
    protected void onStart() {
        super.onStart();
        ChatProperties.start();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startDialerServiceIfNotRunning();
        readBundleInfo(getIntent());
        DialerServiceEventHook.attachEventListener(this);
        logger.log("onCreate");
        ChatProperties.setChatWindowContext(this);
        LanguageManager.initLanguage();
        setContentView(R.layout.chat_window_layout);
        chatWindowViewModel = ViewModelProviders.of(
                ChatWindowActivity.this,
                new ChatWindowViewModelFactory(JetPackChatAdapter.MessageType.REGULAR, target, isGroupChat)).get(ChatWindowViewModel.class);
        initViews();

        /*Comment to make change*/
        handleMoreButtonVisibility();
        prepareDialogForChatWindow();
        removeNotifications();
        MessageQuoteInfo.clear();
        restrictMessageOptionsForCases();
        updateLastOnlineInfo();
        loadGroup(() -> {
            setupEnvironment();
            setUpInitialData();
            loadChat();
            initHistorySync();
            getPublicKeys();
            registerChatWindowBroadcastReceiver();
            handleShareByIntent(getIntent());
            determineFeatureToShow();
            MessageSelection.exitSelection();
        });
    }

    private static Group group;

    public static Group getGroup() {
        return group;
    }

    private void loadGroup(TaskFinishListener taskFinishListener) {
        if (isGroupChat) {
            Executor.ex(() -> {
                group = GroupRepo.get().getGroupById(target);
                Gui.get().run(taskFinishListener::onTaskFinished);
            });
        } else {
            Gui.get().run(taskFinishListener::onTaskFinished);
        }
    }


    private void determineFeatureToShow() {
        if (!Features.hasBurnMessage()) {
            findViewById(R.id.ivBurnMessage).setVisibility(View.GONE);
        }
        if (!Features.hasFutureMessage()) {
            findViewById(R.id.ivSendInFuture).setVisibility(View.GONE);
        }
    }

    private void initHistorySync() {
        boolean val = HistoryFetchRequestSender.isInUserOrGroupIDToHistoryCheckedHashMap(target);
        if (val) return;
        Executor.ex(() -> {
            Cursor cursor = MessageHistoryTimeRepo.get().getTimeLineItemByUserOrGroupID(target);
            if (cursor != null && cursor.moveToFirst()) {
                long toDate = cursor.getLong(cursor.getColumnIndex("to_date"));
                IMHistorySyncHelper.sendUserOrGroupHistoryRequest(target, isGroupChat, toDate);
                HistoryFetchRequestSender.setUserOrGroupIDToHistoryCheckedHashMap(target, true);
            }
        });

    }

    boolean hasServerMessagesInThread = false;

    private void restrictMessageOptionsForCases() {
        if ((!Util.isValidEmail(Util.getProperEmail(target)) && Util.containsAlpha(target)) || hasServerMessagesInThread) {
            messageSendingLayout.setVisibility(View.GONE);
            mediaOptionsHolder.setVisibility(View.GONE);
            chatInfoHolder.setOnClickListener(null);
            ivMore.setVisibility(View.GONE);
            ivAudioCall.setVisibility(View.GONE);
            ivVideoCall.setVisibility(View.GONE);
            tvLastOnline.setVisibility(View.GONE);
            if (isSMSChat) {
                tvSMSIndicator.setText(getString(R.string.senderDoesNotSupportReply));
            }
        }
    }


    private void getPublicKeys() {

    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        logger.log("onNewIntent");
        finish();
        startActivity(intent);
    }

    @Override
    protected void onPause() {
        logger.log("onPause");
        super.onPause();
        Executor.ex(AppIconNotification::setCountInAppIcon);
        ChatMediaPlayer.getInstance().pauseAudioMessage();
        ChatProperties.destroy();
        DraftManager.saveDraft();
    }

    @Override
    protected void onResume() {
        logger.log("onResume");
        super.onResume();
        loadGroup(() -> {
            if (chatWindowViewManager == null) {
                chatWindowViewManager = new ChatWindowViewManager(ChatWindowActivity.this, target, isGroupChat);
            }
            chatWindowViewManager.changeBackGround(ivBackGround);
            DraftManager.restoreDraft();
            controlGroupFeatures();
            Target.updateGroupState();
            setDataInTopView();
            ChatWindowEventHook.attachEventListener(this);
            ChatProperties.setChatWindowContext(this);
        });
        SelectedMediaDataHolder.clear();
        MessageSelection.setIsInMessageEditMode(false);
    }

    @SuppressWarnings("EmptyMethod")
    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        getSupportLoaderManager().destroyLoader(MESSAGE_LOADER_ID);
        getSupportLoaderManager().destroyLoader(UN_DECRYPTED_MESSAGE_LOADER);
        getSupportLoaderManager().destroyLoader(PENDING_SMS_LOADER);
        getSupportLoaderManager().destroyLoader(FAILED_LONG_IM_FILE_DOWNLOAD_LOADER);
        MessageHighlighter.invalidateHighLighterInfo();
        unregisterChatWindowBroadcastReceiver();
        ChatMediaPlayer.getInstance().finish();
        DialerServiceEventHook.free(this);
        FileProgressHook.clearAll();
        ocidToHighlight = null;
    }

    @Override
    public void onBackPressed() {
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            handleBackOption();
        }
        return super.onKeyDown(keyCode, event);
    }

    private void setUpInitialData() {
        if (isGroupChat) {
            if (isEncrypted) {
                Executor.ex(() -> MessageRepo.get().clearUnreadEncryptedGroupCount(target));
            } else {
                Executor.ex(() -> MessageRepo.get().clearUnreadNormalGroupCount(target));
            }
        } else {
            if (isEncrypted) {
                Executor.ex(() -> MessageRepo.get().clearUnreadEncryptedIMCount(target));
            } else {
                Executor.ex(() -> MessageRepo.get().clearUnreadNormalIMCount(target));
            }
        }
        setDataInTopView();
    }


    private void handleBackOption() {
        if (lastActiveFragment != null) {
            hideBottomFragment();
        } else if (MessageSelection.isInSelectionMode) {
            MessageSelection.exitSelection();
            chatAdapter.notifyDataSetChanged();
            futureChatAdapter.notifyDataSetChanged();
        } else if (MessageSelection.isIsInMessageEditMode()) {
            exitEditMode();
        } else {
            finish();
        }

    }

    private void handleSeenSending() {
        SeenSender.getAccess().initialize(Target.target, ChatProperties.isGroupChat);
        ChatWindowSupportingViewModel chatWindowSupportingViewModel = ViewModelProviders.of(ChatWindowActivity.this).get(ChatWindowSupportingViewModel.class);
        chatWindowSupportingViewModel.getUnseenMessageCallerIds().observe(ChatWindowActivity.this, unseenMessageCallerIds -> {
            for (String callerId : unseenMessageCallerIds) {
                SeenSender.getAccess().sendSeen(callerId);
            }
        });

    }

    private void prepareDialogForChatWindow() {
        dialog = new Dialog(ChatWindowActivity.this);
        builder = new AlertDialog.Builder(ChatWindowActivity.this);
    }

    ChatWindowViewModel chatWindowViewModel;

    private void loadChat() {
//        getSupportLoaderManager().initLoader(MESSAGE_LOADER_ID, null, this);

        watchViewModel();
        if (isEncrypted) {
            getSupportLoaderManager().initLoader(UN_DECRYPTED_MESSAGE_LOADER, null, this);
        }
        getSupportLoaderManager().initLoader(PENDING_SMS_LOADER, null, this);
        //getSupportLoaderManager().initLoader(FUTURE_MESSAGE_LOADER_ID, null, this);
        getSupportLoaderManager().initLoader(FAILED_LONG_IM_FILE_DOWNLOAD_LOADER, null, this);


    }


    private String ocidToHighlight = null;

    public static void start(Context context, String number, String groupId, boolean isSMSChat,
                             boolean isBroadCast, boolean isEncrypted, String ocid) {
        Intent starter = new Intent(context, ChatWindowActivity.class);
        starter.putExtra(ChatConstants.KEY_NUMBER, number);
        starter.putExtra(ChatConstants.KEY_GROUP_ID, groupId);
        starter.putExtra(ChatConstants.KEY_IS_SMS_CHAT, isSMSChat);
        starter.putExtra(ChatConstants.KEY_IS_BROADCAST, isBroadCast);
        starter.putExtra(ChatConstants.KEY_IS_ENCRYPTED, isEncrypted);
        starter.putExtra(ChatConstants.KEY_OCID_ID, ocid);
        context.startActivity(starter);
    }
    public static void simpleTestStart(Context context, String number) {
        Intent starter = new Intent(context, ChatWindowActivity.class);
        starter.putExtra(ChatConstants.KEY_NUMBER, number);
        starter.putExtra(ChatConstants.KEY_GROUP_ID, "");
        starter.putExtra(ChatConstants.KEY_IS_SMS_CHAT, false);
        starter.putExtra(ChatConstants.KEY_IS_BROADCAST, false);
        starter.putExtra(ChatConstants.KEY_IS_ENCRYPTED, false);
        starter.putExtra(ChatConstants.KEY_OCID_ID, "");
        starter.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(starter);
    }

    private void startDialerServiceIfNotRunning() {
        if (!Util.isServiceRunning(this, DialerService.class)) {
            Intent intent = new Intent(this, DialerService.class);
            startService(intent);
        }
    }

    private void readBundleInfo(Intent intent) {
        String number = intent.getStringExtra(ChatConstants.KEY_NUMBER);
        String groupId = intent.getStringExtra(ChatConstants.KEY_GROUP_ID);
        boolean fromBubble = intent.getBooleanExtra("KEY_FROM_BUBBLE", false);
        NotificationManager notificationManager;
        notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        //fromBubble = false; //for check
        if (fromBubble) {
            if (notificationManager != null) {
                notificationManager.cancel(ChatConstants.NOTIF_ID_IM); //to disable the existing alert notifications
            }
        }

        isGroupChat = !TextUtils.isEmpty(groupId);
        target = isGroupChat ? groupId : number;
        isSMSChat = intent.getBooleanExtra(ChatConstants.KEY_IS_SMS_CHAT, false);
        isBroadCastIM = intent.getBooleanExtra(ChatConstants.KEY_IS_BROADCAST, false);
        isEncrypted = intent.getBooleanExtra(ChatConstants.KEY_IS_ENCRYPTED, false);

        //ChatProperties.isEncryptedChat = isEncrypted;

        ocidToHighlight = intent.getStringExtra(ChatConstants.KEY_OCID_ID);
        logger.log("readBundleInfo isGroupChat=" + isGroupChat);
        logger.log("readBundleInfo target=" + target);
        logger.log("readBundleInfo isSMSChat=" + isSMSChat);
        logger.log("readBundleInfo isEncrypted : " + isEncrypted);
        logger.log("readBundleInfo isBroadCastIM : " + isBroadCastIM);
        logger.log("readBundleInfo ocidToHighlight : " + ocidToHighlight);

    }


    private void handleShareByIntent(Intent intent) {
        try {
            int intentType = 0;
            if (getIntent() != null) {
                intentType = getIntent().getIntExtra(ChatConstants.INTENT_TYPE, -1);
            }
            if (intentType > 0 && getIntent() != null) {
                if (intentType == ShareActivity.FLAG_INTENT_SINGLE_TEXT) {
                    String messageToSend = intent.getStringExtra(ChatConstants.INTENT_VALUES);
                    Sender.getAccess().sendTextMessage(messageToSend);
                } else if (intentType == ShareActivity.FLAG_INTENT_SINGLE_FILE) {
                    Uri uri = getIntent().getParcelableExtra(ChatConstants.INTENT_VALUES);
//                Uri uri = getIntent().getStringExtra(ChatConstants.INTENT_VALUES);
//                Uri uri = getIntent().getData();
                    String filePath = FileUtils.getPath(this, uri);
                    Sender.getAccess().sendFile(filePath);
                } else if (intentType == ShareActivity.FLAG_INTENT_MULTIPLE_FILES) {
                    ArrayList<Uri> listUri = getIntent().getParcelableArrayListExtra(ChatConstants.INTENT_VALUES);
                    if (listUri != null) {
                        for (int i = 0; i < listUri.size(); i++) {
                            String filePath = FileUtils.getPath(this, listUri.get(i));
                            Sender.getAccess().sendFile(filePath);
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e);
        }

    }

    private ChatWindowViewManager chatWindowViewManager;

    private void setupEnvironment() {
        chatWindowViewManager = new ChatWindowViewManager(ChatWindowActivity.this, target, isGroupChat);
        Sender.getAccess().getConfiguration()
                .target(target)
                .isGroupChat(isGroupChat)
                .group(ChatWindowActivity.getGroup())
                .isSMSChat(isSMSChat)
                .isEncryptedChat(isEncrypted)
                .configure();
        Target.setUpTarget(isGroupChat, target);
        ChatProperties.setUpChatProperties(isGroupChat, isEncrypted, isSMSChat, Constants.GROUP_TYPE_PUBLIC);
        handleSeenSending();
        DraftManager.prepare(etMessage, isEncrypted);
        MessageSelection.attachListener(selectionInteractionListener);
    }

    private void handleMoreButtonVisibility() {
        if (isBroadCastIM
                || (isSMSChat && !CommonData.subscriberPhoneNumberToLookUpKey.containsKey(target))
                || (isGroupChat && ChatProperties.isEncryptedChat && !Target.group.isCreator)) {
            ivMore.setVisibility(View.INVISIBLE);
        } else {
            ivMore.setVisibility(View.VISIBLE);
        }
    }

    private View chatWindow;

    private void initViews() {
        chatWindow = findViewById(R.id.chatWindow);
        initTopBar();
        initRecyclerView();
        initBottomPart();
        initEmoji();
        initFutureMessageView();
        initBackground();

    }

    private ImageView ivBackGround;

    private void initBackground() {
        ivBackGround = findViewById(R.id.ivBackGround);
    }

    private TextView tvFutureMessageCount;
    private CardView cvFutureMessageHolder;

    private void initFutureMessageView() {
        initFutureRecyclerView();
        tvFutureMessageCount = findViewById(R.id.tvFutureMessageCount);
        cvFutureMessageHolder = findViewById(R.id.cvFutureMessageHolder);
    }

    private ImageView ivFalseEmojiButton;
    private EmojIconActions emojIconActions;
    public static final String CAMERA = "camera";
    public static final String GALLERY = "gallery";
    public static final String SOUND = "sound";

    private void removeNotifications() {
        // TODO: 1/2/19 remove notification for this chat
    }

    private void initEmoji() {
        ivFalseEmojiButton = findViewById(R.id.ivFalseEmojiButton);
        emojIconActions = new EmojIconActions(ChatWindowActivity.this, chatWindow, etMessage, ivFalseEmojiButton);
        emojIconActions.setUseSystemEmoji(true);
        emojIconActions.ShowEmojIcon();

        emojIconActions.setKeyboardListener(new EmojIconActions.KeyboardListener() {
            @Override
            public void onKeyboardOpen() {
                if (!(lastActiveFragment instanceof EmoGifStickerFragment) && !(lastActiveFragment instanceof Searchable)) {
                    hideBottomFragment();
                    rvFutureMessages.setVisibility(View.GONE);
                    //emojIconActions.getPopup().getContentView().findViewById(R.id.emojis_tab).setVisibility(View.GONE);
//                    emojIconActions.closeEmojIcon();
                }
            }

            @Override
            public void onKeyboardClose() {
            }
        });
    }

    private TextView tvTypingMessage;
    private EmojiconEditText etMessage;
    private ImageView ivEmoticons;
    private FloatingActionButton ivSendInFuture;
    private FloatingActionButton ivSend;
    private ImageView ivCamera;
    private ImageView ivAttachment;
    private ImageView ivVoiceMessage;
    private ImageView ivLocationShare;
    private View bottomOptionsHolder;
    private View messageQuoteHolder;
    private View messageSendingLayout;
    private View mediaOptionsHolder;
    private View editModeViewHolder;
    private View editModeCancelButton;
    TextView tvSMSIndicator;

    private void initBottomPart() {
        MessageSelection.setIsInMessageEditMode(false);
        MessageSelection.setIsInMessageEditMode(false);
        messageSendingLayout = findViewById(R.id.messageSendingLayout);
        mediaOptionsHolder = findViewById(R.id.mediaOptionsHolder);
        bottomOptionsHolder = findViewById(R.id.bottomOptionsHolder);
        bottomOptionsHolder.setVisibility(View.VISIBLE);
        ivSendInFuture = findViewById(R.id.ivSendInFuture);
        ivSend = findViewById(R.id.ivSend);
        tvTypingMessage = findViewById(R.id.tv_typing_message);
        etMessage = findViewById(R.id.etMessage);
        tvSMSIndicator = findViewById(R.id.tvSMSIndicator);
        messageQuoteHolder = findViewById(R.id.messageQuoteHolder);
        editModeViewHolder = findViewById(R.id.ll_edit_message_view);
        editModeViewHolder.setVisibility(View.GONE);
        editModeCancelButton = findViewById(R.id.ivEditModeCancel);


        View.OnClickListener mediaOptionsClickListener = v -> {
            hideKeyBoard();
            try {
                emojIconActions.closeEmojIcon();
            } catch (Exception e) {
                e.printStackTrace();
            }
            switch (v.getId()) {
                case R.id.ivEmoticons:
                    handleEmojiButtonClick();
                    break;
                case R.id.ivBurnMessage:
                    BurnTimePicker.showBurnTimePicker(ChatWindowActivity.this, target);
                    break;
                case R.id.ivCamera:
                    cameraPermission();
                    break;
                case R.id.ivAttachment:
                    DangerousPermission.StoragePermission.getAccess(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
                        @Override
                        public void onPermissionGranted() {
                            showBottomFragment(ImportFileFragment.newInstance());
                        }

                        @Override
                        public void onPermissionRejected() {

                        }
                    });
                    break;
                case R.id.ivVoiceMessage:
                    DangerousPermission.MicrophonePermission.getAccess(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
                        @Override
                        public void onPermissionGranted() {
//                            showBottomFragment(SoundRecorderFragment.getInstance());
                            readWriteStoragePermission(SOUND);
                        }

                        @Override
                        public void onPermissionRejected() {

                        }
                    });

                    break;
                case R.id.ivContactShare:
                    DangerousPermission.ContactsPermission.getAccess(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
                        @Override
                        public void onPermissionGranted() {
                            hideBottomFragment();
                            handleContactShare();
//                            startActivity(new Intent(ChatWindowActivity.this, ContactShareActivity.class));
                        }

                        @Override
                        public void onPermissionRejected() {

                        }
                    });
                    break;
                case R.id.ivLocationShare:
                    DangerousPermission.LocationPermission.getAccess(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
                        @Override
                        public void onPermissionGranted() {
                            hideBottomFragment();
                            LocationSendActivity.start(ChatWindowActivity.this);
                        }

                        @Override
                        public void onPermissionRejected() {

                        }
                    });

                    break;
                case R.id.ivEditModeCancel:
                    exitEditMode();
                    break;
            }
        };

        ivSend.setOnClickListener(v -> {
            if (isInSearchingMode) {
                if (lastActiveFragment instanceof Searchable) {
                    String searchString = etMessage.getText().toString().trim();
                    etMessage.setText(null);
                    ((Searchable) lastActiveFragment).search(searchString);
                }
            } else {
                sendMessage();
            }
        });

        ivSendInFuture.setOnClickListener(v -> {
            if (isInSearchingMode) {
                etMessage.setText(null);
                hideBottomFragment();
            } else {
                sendFutureMessage();
            }
        });

        ivEmoticons = findViewById(R.id.ivEmoticons);
        ImageView ivBurnMessage = findViewById(R.id.ivBurnMessage);
        ivCamera = findViewById(R.id.ivCamera);
        ivAttachment = findViewById(R.id.ivAttachment);
        ivVoiceMessage = findViewById(R.id.ivVoiceMessage);
        ImageView ivContactShare = findViewById(R.id.ivContactShare);
        ivLocationShare = findViewById(R.id.ivLocationShare);
        ivEmoticons.setOnClickListener(mediaOptionsClickListener);
        ivBurnMessage.setOnClickListener(mediaOptionsClickListener);
        ivCamera.setOnClickListener(mediaOptionsClickListener);
        ivAttachment.setOnClickListener(mediaOptionsClickListener);
        ivVoiceMessage.setOnClickListener(mediaOptionsClickListener);
        ivContactShare.setOnClickListener(mediaOptionsClickListener);
        ivLocationShare.setOnClickListener(mediaOptionsClickListener);
        editModeCancelButton.setOnClickListener(mediaOptionsClickListener);

        if (isBroadCastIM) {
            messageSendingLayout.setVisibility(View.GONE);
            mediaOptionsHolder.setVisibility(View.GONE);
        }
        if (isSMSChat) {
            tvSMSIndicator.setVisibility(View.VISIBLE);
            mediaOptionsHolder.setVisibility(View.GONE);
            tvLastOnline.setVisibility(View.GONE);
            //ivSendInFuture.setVisibility(View.GONE);
        } else {
            tvSMSIndicator.setVisibility(View.GONE);
            if (!isBroadCastIM) {
                mediaOptionsHolder.setVisibility(View.VISIBLE);
                ivSendInFuture.setVisibility(View.VISIBLE);
            }
        }

        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() > 0 && !isSMSChat) {
                    if (!CommonData.blockedNumber.contains(target)) {
                        Sender.getAccess().sendTypingMessageToDialer();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    private void handleContactShare() {
        ContactPickerActivity.startPicker(ChatWindowActivity.this,
                ContactType.ALL,
                ContactSelectiontype.MULTIPLE_SELECT,
                (contacts, contactListItems) -> {
                    if (contactListItems.size() > 0) {
                        ContactSender.getInstance(ChatWindowActivity.this).sendContacts(contactListItems);
                    } else {
                        I.toast(getString(R.string.no_contacts_selected));
                    }
                });
    }


    private void cameraPermission() {
        DangerousPermission.CameraPermission.getAccess(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                readWriteStoragePermission(CAMERA);
            }

            @Override
            public void onPermissionRejected() {

            }
        });
    }


    void readWriteStoragePermission(String cameraGallerySound) {
        DangerousPermission.StoragePermission.getAccess(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
            @Override
            public void onPermissionGranted() {
                if (cameraGallerySound.compareTo(CAMERA) == 0) {
                    Intent i = new Intent(ChatWindowActivity.this, FullscreenCameraCaptureActivity.class);
                    startActivity(i);
                } else {
                    showBottomFragment(SoundRecorderFragment.getInstance());
                }
            }

            @Override
            public void onPermissionRejected() {

            }
        });
    }


    private void handleEmojiButtonClick() {
        if (lastActiveFragment instanceof EmoGifStickerFragment) {
            hideBottomFragment();
        } else {
            hideKeyBoard();
            showBottomFragment(EmoGifStickerFragment.getInstance());
            emojIconActions.ShowEmojIcon();
        }
    }

    private Fragment lastActiveFragment;

    private void showBottomFragment(Fragment fragment) {
        logger.log("showBottomFragment");
        bottomOptionsHolder.setVisibility(View.VISIBLE);
        if (fragment == null) return;
        if (lastActiveFragment instanceof ImageGalleryFragment) {
            ((ImageGalleryFragment) lastActiveFragment).clearSelection();
        }
        lastActiveFragment = fragment;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.bottomOptionsHolder, fragment)
                .commit();
        isInSearchingMode = lastActiveFragment instanceof Searchable;
        handleSendingAndSearchingViews();
        handleBottomOptionSelectionStates(fragment);
    }

    private void handleBottomOptionSelectionStates(Fragment fragment) {
        deselectAllBottomOptions();
        if (fragment == null) {
            return;
        }
        if (fragment instanceof ImageGalleryFragment) {
            ivCamera.setSelected(true);
        } else if (fragment instanceof EmoGifStickerFragment) {
            ivEmoticons.setSelected(true);
        } else if (fragment instanceof ImportFileFragment) {
            ivAttachment.setSelected(true);
        } else if (fragment instanceof SoundRecorderFragment) {
            ivVoiceMessage.setSelected(true);
        } else if (fragment instanceof GoogleMapFragment) {
            ivLocationShare.setSelected(true);
        }
    }

    private void deselectAllBottomOptions() {
        ivCamera.setSelected(false);
        ivEmoticons.setSelected(false);
        ivAttachment.setSelected(false);
        ivVoiceMessage.setSelected(false);
        ivLocationShare.setSelected(false);
    }


    private void hideBottomFragment() {
        if (lastActiveFragment instanceof ImageGalleryFragment) {
            ((ImageGalleryFragment) lastActiveFragment).clearSelection();
        }
        bottomOptionsHolder.setVisibility(View.GONE);
        if (lastActiveFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .remove(lastActiveFragment)
                    .commit();
            lastActiveFragment = null;
        }
        isInSearchingMode = false;
        handleSendingAndSearchingViews();
        deselectAllBottomOptions();
    }

    private void handleSendingAndSearchingViews() {
        if (isInSearchingMode) {
            ivSend.setImageResource(R.drawable.ic_search);
            ivSendInFuture.setImageResource(R.drawable.ic_close);
            etMessage.setHint(getString(R.string.search));
        } else {
            ivSend.setImageResource(R.drawable.ic_send);
            ivSendInFuture.setImageResource(R.drawable.ic_scheduled_message);
            etMessage.setHint(getString(R.string.type_a_message_here));
        }
    }


    private void sendFutureMessage() {
        final String messageToSend = etMessage.getText().toString().trim();
        if (messageToSend.length() > SendingConstants.MAX_IM_LENGTH) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        if (!TextUtils.isEmpty(messageToSend)) {
            FutureMessageTimeDialogs.showDateTimePicker(ChatWindowActivity.this,(formattedDateTime, isSendingCurrentTimeStamp) -> {
                if (formattedDateTime.getTime() < System.currentTimeMillis()) {
                    showInfo(getString(R.string.future_error_message_time));
                } else {
                    if (this.isSMSChat) {
                        Sender.getAccess().sendFutureTextSMS(messageToSend, formattedDateTime, isSendingCurrentTimeStamp);
                    } else {
                        Sender.getAccess().sendFutureTextMessage(messageToSend, formattedDateTime.getTime(), isSendingCurrentTimeStamp);
                    }
                    etMessage.setText(null);
                }
            });
        }
        DraftManager.clearDraft();
    }

    private void sendMessage() {
        String messageToSend = etMessage.getText().toString().trim();
        if (messageToSend.length() > SendingConstants.MAX_IM_LENGTH) {
            I.toast(getString(R.string.text_length_is_too_big));
            return;
        }
        etMessage.setText(null);
        if (!TextUtils.isEmpty(messageToSend)) {
            if (MessageSelection.isIsInMessageEditMode()) {
                Sender.getAccess().sendEditedTextMessage(messageToSend, messageTobeEdit);
                exitEditMode();
            } else {
                if (this.isSMSChat) {
                    Sender.getAccess().sendTextSMS(messageToSend);
                } else {
                    Sender.getAccess().sendTextMessage(messageToSend);
                }
            }

        }


        DraftManager.clearDraft();
    }

    private JetPackChatAdapter chatAdapter;
    private RecyclerView rvMessages;
    private LinearLayoutManager recyclerViewLayoutManager;

    private void initRecyclerView() {
        rvMessages = findViewById(R.id.rvMessages);
        chatAdapter = new JetPackChatAdapter(isEncrypted, JetPackChatAdapter.MessageType.REGULAR);
        MessageHighlighter.createHighLighterInfo(chatAdapter);
        recyclerViewLayoutManager = new LinearLayoutManager(ChatWindowActivity.this);
        recyclerViewLayoutManager.setStackFromEnd(true);
        recyclerViewLayoutManager.setSmoothScrollbarEnabled(true);
        recyclerViewLayoutManager.setSmoothScrollbarEnabled(true);
        rvMessages.setLayoutManager(recyclerViewLayoutManager);
        rvMessages.setAdapter(chatAdapter);
        rvMessages.setOnClickListener(v -> hideKeyBoard());
    }

    private JetPackChatAdapter futureChatAdapter;
    private RecyclerView rvFutureMessages;

    private void initFutureRecyclerView() {
        rvFutureMessages = findViewById(R.id.rvFutureMessages);
        futureChatAdapter = new JetPackChatAdapter(isEncrypted, JetPackChatAdapter.MessageType.FUTURE);
        LinearLayoutManager layoutManager = new LinearLayoutManager(ChatWindowActivity.this, RecyclerView.VERTICAL, false);
        layoutManager.setStackFromEnd(false);
        rvFutureMessages.setLayoutManager(layoutManager);
        rvFutureMessages.setAdapter(futureChatAdapter);
        rvFutureMessages.setVisibility(View.GONE);
    }


    private ImageView ivProfileImage;
    private ImageView ivPresenceState;
    private TextView tvName;
    private TextView tvNumber;
    TextView tvLastOnline;
    private View normalToolBar;
    private View actionToolBar;

    private ImageView ivQuote;
    private ImageView ivCopy;
    private ImageView ivEdit;
    private ImageView ivMessageInfo;
    private ImageView ivForwardByOtherApp;
    private ImageView ivForwardByBubbleTone;

    private ImageView ivMore;
    ImageView ivAudioCall;
    ImageView ivVideoCall;
    View chatInfoHolder;

    private void initTopBar() {
        normalToolBar = findViewById(R.id.chatNormalToolbar);
        actionToolBar = findViewById(R.id.chatActionToolbar);
        View futureMessageHandle = findViewById(R.id.futureMessageHandle);
        ImageView ivBack = findViewById(R.id.ivBack);
        ivProfileImage = findViewById(R.id.ivProfileImage);
        ivPresenceState = findViewById(R.id.iv_presence_state);
        ivAudioCall = findViewById(R.id.ivAudioCall);
        ivVideoCall = findViewById(R.id.ivVideoCall);
        ivMore = findViewById(R.id.ivMore);
        chatInfoHolder = findViewById(R.id.chatInfoHolder);
        View.OnClickListener topBarOnClickListener = v -> {
            switch (v.getId()) {
                case R.id.ivBack:
                    handleBackOption();
                    break;
                case R.id.chatInfoHolder:
                    Switcher.switchToChatDetails(ChatWindowActivity.this, target, isGroupChat, isSMSChat);
                    break;
                case R.id.ivAudioCall:
                    phonePermission(1);
                    break;
                case R.id.ivVideoCall:
                    phonePermission(2);
                    break;
                case R.id.ivMore:
                    ChatDialogs.showOptionsMenuDialog(ChatWindowActivity.this, findViewById(R.id.overFlowMenuAnchor));
                    break;
                case R.id.futureMessageHandle:
                    if (rvFutureMessages.getVisibility() == View.VISIBLE) {
                        rvFutureMessages.setVisibility(View.GONE);
                    } else {
                        rvFutureMessages.setVisibility(View.VISIBLE);
                    }
                    break;

            }
        };
        ivBack.setOnClickListener(topBarOnClickListener);
        ivAudioCall.setOnClickListener(topBarOnClickListener);
        ivVideoCall.setOnClickListener(topBarOnClickListener);
        ivMore.setOnClickListener(topBarOnClickListener);
        chatInfoHolder.setOnClickListener(topBarOnClickListener);
        futureMessageHandle.setOnClickListener(topBarOnClickListener);

        tvName = findViewById(R.id.tvName);
        tvNumber = findViewById(R.id.tvNumber);
        tvLastOnline = findViewById(R.id.tvLastOnline);
        tvLastOnline.setSelected(true);

        // don't know the necessity of this if block
        if (isBroadCastIM || isGroupChat || !CommonData.subscriberPhoneNumberToLookUpKey.containsKey(target)) {
            ivAudioCall.setVisibility(View.GONE);
            ivVideoCall.setVisibility(View.GONE);
            tvLastOnline.setVisibility(View.GONE);
        }

        if ((isSMSChat && !CommonData.subscriberPhoneNumberToLookUpKey.containsKey(target)) || isGroupChat || isBroadCastIM) {
            ivAudioCall.setVisibility(View.GONE);
            ivVideoCall.setVisibility(View.GONE);
            tvLastOnline.setVisibility(View.GONE);
        } else {
            ivAudioCall.setVisibility(View.VISIBLE);
            ivVideoCall.setVisibility(View.VISIBLE);
            tvLastOnline.setVisibility(View.VISIBLE);
        }

        ivQuote = findViewById(R.id.ivQuote);
        ivCopy = findViewById(R.id.ivCopy);
        ImageView ivDelete = findViewById(R.id.ivDelete);
        ivEdit = findViewById(R.id.ivEdit);
        ivMessageInfo = findViewById(R.id.ivMessageInfo);
        ivForwardByOtherApp = findViewById(R.id.ivShare);
        ivForwardByBubbleTone = findViewById(R.id.ivForward);

        ivQuote.setOnClickListener(actionButtonListener);
        ivCopy.setOnClickListener(actionButtonListener);
        ivDelete.setOnClickListener(actionButtonListener);
        ivEdit.setOnClickListener(actionButtonListener);
        ivMessageInfo.setOnClickListener(actionButtonListener);
        ivForwardByOtherApp.setOnClickListener(actionButtonListener);
        ivForwardByBubbleTone.setOnClickListener(actionButtonListener);
//        if (isEncrypted) {
//            confideInfoHolder.setVisibility(View.VISIBLE);
//        } else {
//            confideInfoHolder.setVisibility(View.GONE);
//        }

        if (isSMSChat) {
            ivQuote.setVisibility(View.GONE);
            ivEdit.setVisibility(View.GONE);
        }
        ivQuote.setVisibility(View.GONE);

    }


    private void setDataInTopView() {
        chatWindowViewManager.setProfileImage(ivProfileImage);
        if (isBroadCastIM) {
            chatWindowViewManager.setBroadcastImage(ivProfileImage);
        }
        chatWindowViewManager.setName(tvName);
        chatWindowViewManager.setNumber(tvNumber);
//        int presence_state = DatabaseConstants.getInstance().getPresenceStateByNumber(target);
//        chatWindowViewManager.setPresenceStatus(presence_state, ivPresenceState);
    }

    private static final int MESSAGE_LOADER_ID = 22;
    private static final int FUTURE_MESSAGE_LOADER_ID = 24;
    private static final int PENDING_SMS_LOADER = 4;
    private static final int UN_DECRYPTED_MESSAGE_LOADER = 5;
    private static final int FAILED_LONG_IM_FILE_DOWNLOAD_LOADER = 6;


    @SuppressWarnings("all")
    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Log.e("on create loader ", "chat window");
        switch (id) {
            case MESSAGE_LOADER_ID:
                return new SQLiteCursorLoader(ChatWindowActivity.this) {
                    @Override
                    public Cursor loadInBackground() {
                        Cursor cursor = null;
                        try {
                            if (isGroupChat) {
                                cursor = MessageRepo.get().getMessageByGroupId(target, searchText, false);
                            } else {
                                cursor = MessageRepo.get().getMessageByNumber(target, searchText, false, isEncrypted);
                            }
                        } catch (Exception ex) {
                            logger.log(ex.getLocalizedMessage());
                            return null;
                        }
                        if (cursor != null) {
                            this.registerContentObserver(cursor, MESSAGE_URI);
                        }
                        return cursor;
                    }
                };
            case FUTURE_MESSAGE_LOADER_ID:
                return new SQLiteCursorLoader(ChatWindowActivity.this) {
                    @Override
                    public Cursor loadInBackground() {
                        Cursor cursor = null;
                        try {
                            if (isGroupChat) {
                                cursor = MessageRepo.get().getMessageByGroupId(target, searchText, true);
                            } else {
                                cursor = MessageRepo.get().getMessageByNumber(target, searchText, true, isEncrypted);
                            }
                        } catch (Exception ex) {
                            logger.log(ex.getLocalizedMessage());
                            return null;
                        }
                        if (cursor != null) {
                            this.registerContentObserver(cursor, MESSAGE_URI);
                        }
                        return cursor;
                    }
                };
            case UN_DECRYPTED_MESSAGE_LOADER:
                return new SQLiteCursorLoader(ChatWindowActivity.this) {
                    @Override
                    public Cursor loadInBackground() {

                        Cursor cursor = null;
                        try {
//                            if (isGroupChat && target != null) {
//                                cursor = DatabaseConstants.getInstance().getUnDecyptedGroupMessages(target);
//                            } else {
//                                cursor = DatabaseConstants.getInstance().getUnDecryptedMessages(target, isEncrypted ? 1 : 0);
//                            }
                            cursor = MessageRepo.get().getUnDecryptedMessages(target, isEncrypted ? 1 : 0);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                        return cursor;
                    }
                };
            case PENDING_SMS_LOADER:
                return new SQLiteCursorLoader(ChatWindowActivity.this) {
                    @Override
                    public Cursor loadInBackground() {

                        Cursor cursor = null;
                        try {

//                            if (isGroupChat) {
//                                cursor = DatabaseConstants.getInstance().getPendingGroupSMS(target);
//                            } else {
//                                cursor = DatabaseConstants.getInstance().getPendingSMS(target);
//                            }
                            cursor = MessageRepo.get().getPendingSMS(target);

                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                        if (cursor != null && !cursor.isClosed()) {
                            this.registerContentObserver(cursor, DatabaseUris.MESSAGE_URI);
                        }

                        return cursor;
                    }
                };

            case FAILED_LONG_IM_FILE_DOWNLOAD_LOADER:
                return new SQLiteCursorLoader(ChatWindowActivity.this) {
                    @Override
                    public Cursor loadInBackground() {
                        Cursor cursor = null;
                        if (failedLongImRetryFlag == false)
                            return cursor;
                        try {
                            if (isGroupChat)
                                cursor = MessageRepo.get().getFailedLongMessagesByGroupId(target);
                            else
                                cursor = MessageRepo.get().getFailedLongMessagesByNumber(target);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                        if (cursor != null && !cursor.isClosed()) {
                            this.registerContentObserver(cursor, DatabaseConstants.MESSAGE_URI);
                        }

                        return cursor;
                    }
                };
        }
        return null;
    }

    private void enterEditMode() {
        messageTobeEdit = MessageSelection.getAll().get(0);
        if (messageTobeEdit.mimeType != MimeType.Text) {
            messageTobeEdit = null;
            return;
        }
        String currentMessage = messageTobeEdit.content;
        editModeViewHolder.setVisibility(View.VISIBLE);
        etMessage.setText(currentMessage);
        if (!TextUtils.isEmpty(currentMessage)) {
            etMessage.setSelection(currentMessage.length() - 1);
        }
        MessageSelection.setIsInMessageEditMode(true);
        MessageSelection.exitSelection();
    }

    private void exitEditMode() {
        MessageSelection.setIsInMessageEditMode(false);
        editModeViewHolder.setVisibility(View.GONE);
        messageTobeEdit = null;
        etMessage.setText(null);
        DraftManager.restoreDraft();
    }

    private int lastMessageCount = 0;
    private int lastFutureMessageCount = 0;

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        switch (loader.getId()) {
            case MESSAGE_LOADER_ID:
//                chatAdapter.s(data);
                checkHasServerMessagesInThread(data);

//                logger.log("ocidToHighlight=" + ocidToHighlight);
                if (ocidToHighlight == null) {
                    int currentCount = data.getCount();
                    if (currentCount > lastMessageCount) {
                        lastMessageCount = currentCount;
                        rvMessages.scrollToPosition(chatAdapter.getItemCount() - 1);
                    }
                } else {
                    MessageHighlighter.highLight(ocidToHighlight);
                }
                break;
            case FUTURE_MESSAGE_LOADER_ID:
                /*if (data == null || data.getCount() == 0) {
                    cvFutureMessageHolder.setVisibility(View.GONE);
                } else {
                    cvFutureMessageHolder.setVisibility(View.VISIBLE);
                    tvFutureMessageCount.setText(String.format(Locale.ENGLISH, "%d", data.getCount()));
                    ArrayList<Message> messageArrayList = new ArrayList<>();
                    long futuresendTime = 0;
                    data.moveToFirst();
                    do {
                        futuresendTime = data.getLong(data.getColumnIndex(DatabaseConstants.KEY_FUTURE_SEND_TIME));
                        long realTime = System.currentTimeMillis() + UserDataManager.getTimeAdjustment();
                        if (futuresendTime < realTime) {
                            Message message = new Message(data);
                            messageArrayList.add(message);
                        }
                    } while (data.moveToNext());
                    if (messageArrayList.size() != 0) {
                        Executor.ex(() -> {
                            MessageRepo.get().updateFutureMessageSendTime(messageArrayList);
                        });
                    }
                    futureChatAdapter.swapCursor(data);
                    int currentCount = data.getCount();
                    if (currentCount > lastFutureMessageCount) {
                        lastFutureMessageCount = currentCount;
                        rvFutureMessages.scrollToPosition(futureChatAdapter.getItemCount() - 1);
                    }
                }*/
                break;

            case UN_DECRYPTED_MESSAGE_LOADER:
                if (!data.isClosed() && data.moveToFirst()) {
                    Executor.ex(() -> {
                        if (isGroupChat && !TextUtils.isEmpty(target) && GroupRepo.get().isE2EPublicKeySeedAndPrivateKeyAvailableForGroup(target)) {
                            E2EPublicKeySeedAndPrivateKeyHolder mE2EPublicKeySeedAndPrivateKeyHolder =
                                    GroupRepo.get().getE2EPublicKeySeedAndPrivateKeyHolderForGroup(target);
                            do {
                                if (mE2EPublicKeySeedAndPrivateKeyHolder.privateKey != null && mE2EPublicKeySeedAndPrivateKeyHolder.seed != null) {
                                    String text = data.getString(data.getColumnIndex(DatabaseConstants.KEY_MESSAGE_CONTENT));
                                    String callID = data.getString(data.getColumnIndex(DatabaseConstants.KEY_CALLER_ID));
                                    byte[] encryptedMessage = text.getBytes();
                                    text = new String(End2EndEncryption.decrypt(encryptedMessage, mE2EPublicKeySeedAndPrivateKeyHolder.privateKey, mE2EPublicKeySeedAndPrivateKeyHolder.seed));
                                    MessageRepo.get().updateMessageContentAndDecryption(callID, text, 1);
                                }
                            } while (data.moveToNext());
                        }
                    });

                }
                break;
            case FAILED_LONG_IM_FILE_DOWNLOAD_LOADER:
                failedLongImRetryFlag = false;
                MultipartViaFileHandler.reUploadOrDownloadFailedLongIM(ChatWindowActivity.this, data, isGroupChat, target);
                break;

        }
    }

    private void checkHasServerMessagesInThread(Cursor data) {
        if (data != null && data.moveToFirst()) {
            for (int i = 0; i < data.getCount(); i++) {
                Message message = MessageCache.findMessage(i, data);
                if (message != null) {
                    hasServerMessagesInThread = message.mimeType == MimeType.Server;
                }
                if (hasServerMessagesInThread) {
                    restrictMessageOptionsForCases();
                    break;
                }
            }
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    private void hideKeyBoard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        }
    }

    private void showKeyBoard() {
        etMessage.requestFocus();
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (inputMethodManager != null) {
                inputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
            }
        }
    }

    private void showInfo(String data) {
        Snackbar.make(chatWindow, data, Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public void onControlRequest(RequestType requestType) {
        switch (requestType) {
            case HideBottomFragments:
                hideBottomFragment();
                break;
            case ShowLocation:
                showBottomFragment(GoogleMapFragment.newInstance());
                break;
            case ShowEmojiKeyboard:
                ivFalseEmojiButton.callOnClick();
                break;
            case ShowStickers:
                emojIconActions.closeEmojIcon();
                hideBottomFragment();
                showBottomFragment(StickeroidFragment.getInstance());
                showKeyBoard();
                break;
            case ShowBubbleToneStickers:
                hideKeyBoard();
                emojIconActions.closeEmojIcon();
                hideBottomFragment();
                showBottomFragment(StaticStickerFragment.getInstance());
                break;
            case ShowGif:
                emojIconActions.closeEmojIcon();
                hideBottomFragment();
                showBottomFragment(TenorFragment.getInstance());
                showKeyBoard();
                break;
            case ExitQuoteMode:
                if (MessageQuoteInfo.isInQuoteMode) {
                    removeQuotedMessage();
                    MessageQuoteInfo.clear();
                }
            default:
                break;
        }
    }

    private void registerChatWindowBroadcastReceiver() {
        IntentFilter messageIntentFilter = new IntentFilter();
        messageIntentFilter.addAction(Constants.PRESENCE_INTENT_FILTER);
        LocalBroadcastManager.getInstance(this).registerReceiver(chatWindowMessageReceiver, messageIntentFilter);
    }


    private void unregisterChatWindowBroadcastReceiver() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(chatWindowMessageReceiver);
    }


    private void removeQuotedMessage() {
        Fragment fragmentToRemove = getSupportFragmentManager().findFragmentByTag(MessageQuoteFragment.getTAG());
        if (fragmentToRemove != null) {
            getSupportFragmentManager().beginTransaction().remove(fragmentToRemove).commitAllowingStateLoss();
        }
        messageQuoteHolder.setVisibility(View.GONE);
        if (!isSMSChat && Features.hasFutureMessage()) {
            ivSendInFuture.setVisibility(View.VISIBLE);
        }

    }

    public static Dialog getDialog() {
        return dialog;
    }

    public static AlertDialog.Builder getAlertDialogBuilder() {
        return builder;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == ChatConstants.REQUEST_GET_SMS_NUMBER) {
                if (data != null) {
                    String number = data.getStringExtra("send_sms");
                    Switcher.switchToSingleSMSSendingActivityFromGroupChat(number);
                }
            } else if (requestCode == ChatConstants.GOOGLE_DRIVE_PICKER) {
                if (lastActiveFragment != null && lastActiveFragment instanceof ImportFileFragment) {
                    lastActiveFragment.onActivityResult(requestCode, resultCode, data);
                }
            } else if (requestCode == ChatConstants.MULTIPLE_MESSAGE_FORWARD_REQUEST_CODE) {
                if (data != null) {
                    String selectedNumber = data.getStringExtra(Constants.KEY_NUMBER);
                    String selectedGroupId = data.getStringExtra(Constants.KEY_GROUP_ID);
                    if (selectedGroupId != null) {
                        Executor.ex(() -> {
                            Group group = GroupRepo.get().getGroupById(selectedGroupId);
                            runOnUiThread(() -> {
                                if (group.groupType == Constants.GROUP_TYPE_SMS) {
                                    if (MessageSelection.containsAnythingThanText()) {
                                        I.toast(getString(R.string.cannotSendAsSMS));
                                        MessageSelection.exitSelection();
                                        return;
                                    } else {
                                        MessageSelection.sendSelectedMessagesAsSMS(selectedGroupId, true);
                                    }
                                }
                            });
                        });

                    } else if (!CommonData.subscriberPhoneNumberToLookUpKey.containsKey(Util.translateNumber(selectedNumber))) {
                        logger.log("Util.translateNumber(selectedNumber) = " + Util.translateNumber(selectedNumber));
                        if (MessageSelection.containsAnythingThanText()) {
                            I.toast(getString(R.string.cannotSendAsSMS));
                            MessageSelection.exitSelection();
                        } else {
                            MessageSelection.sendSelectedMessagesAsSMS(selectedNumber, false);
                        }
                        return;
                    }
                    target = selectedGroupId == null ? selectedNumber : selectedGroupId;
                    boolean isEncrypted = data.getIntExtra(Constants.KEY_MESSAGE_SECURITY_MODE, 0) == 1;
                    MessageSelection.sendSelectedMessages(target, selectedGroupId != null, isEncrypted);
                }
            }
        } else {
            showInfo(getString(R.string.cancelled));
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void info() {
        if (MessageSelection.getCount() == 0) {
            I.toast(getString(R.string.pleaseSelectAtLeastOneMessageToSeeInfo));
            return;
        }
        Message message = MessageSelection.getAll().get(0);
//        Cursor cursor = Database.GroupMessages.Read.byCallId(MessageSelection.getAll().quickGet(0).callerId);
        if (message != null) {
            if (message.messageType == MessageEntry.MessageType.RECEIVED) {
                I.toast(getString(R.string.infoNotAvailableForReceivedMessage));
                MessageSelection.exitSelection();
            } else if (message.messageType == MessageEntry.MessageType.SEND) {
                showMessageInfo(message.callerId, target);
                MessageSelection.exitSelection();
            }
        }
    }

    private void showMessageInfo(String callId, String groupId) {
        Intent intent = new Intent(this, MessageStatusDetailsActivityGroup.class);
        intent.putExtra(MessageStatusDetailsActivityGroup.KEY_CALL_ID, callId);
        if (isGroupChat) {
            intent.putExtra(MessageStatusDetailsActivityGroup.KEY_GROUP_ID, groupId);
        } else {
            intent.putExtra(MessageStatusDetailsActivityGroup.KEY_GROUP_ID, MessageStatusDetailsActivityGroup.KEY_FAKE_GROUP_ID);
        }
        startActivity(intent);
//        getActivity().overridePendingTransition(R.anim.activity_in, R.anim.activity_out);
    }


    private void quote() {
        if (MessageSelection.getCount() == 0) {
            I.toast(getString(R.string.pleaseSelectAtLeastOneMessageToDelete));
            return;
        }
        Message message = MessageSelection.getAll().get(0);
        if (message != null) {
            int deliveryStatus = message.deliveryStatus;
            MessageQuoteInfo.quoteMessageOriginatorCallId = message.ocid;
            if (deliveryStatus == MessageEntry.DeliveryStatus.FAILED || deliveryStatus == MessageEntry.DeliveryStatus.NO_REPLY || deliveryStatus == MessageEntry.DeliveryStatus.PENDING) {
                I.toast(getString(R.string.sorryNotReadyYet));
                return;
            }
        }

        MessageQuoteInfo.isInQuoteMode = true;
        ivSendInFuture.setVisibility(View.GONE);
        String quoteMessageCallId = MessageSelection.getAll().get(0).callerId;
        messageQuoteHolder.setVisibility(View.VISIBLE);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.messageQuoteHolder, MessageQuoteFragment.newInstance(quoteMessageCallId), MessageQuoteFragment.getTAG())
                .commit();
        MessageSelection.exitSelection();
    }

    private final View.OnClickListener actionButtonListener = v -> {
        switch (v.getId()) {
            case R.id.ivMessageInfo:
                info();
                break;
            case R.id.ivQuote:
                quote();
                break;
            case R.id.ivCopy:
                MessageSelection.copySelectionToClipBoard(ChatWindowActivity.this);
                break;
            case R.id.ivDelete:
                MessageSelection.deleteSelectedMessage(ChatWindowActivity.this);
                break;
            case R.id.ivEdit:
                enterEditMode();
                break;
            case R.id.ivShare:
                MessageSelection.forwardByOtherApp(ChatWindowActivity.this);
                break;
            case R.id.ivForward:
                goToForwardByBubbleToneActivityAndReceiveResult();
                break;
        }
    };


    private final MessageSelectionInteractionListener selectionInteractionListener = new MessageSelectionInteractionListener() {
        @Override
        public void onSelectOrDeselect() {
            if (MessageSelection.isInSelectionMode) {
                normalToolBar.setVisibility(View.GONE);
                actionToolBar.setVisibility(View.VISIBLE);
                handleActionItemVisibility();
            } else {
                normalToolBar.setVisibility(View.VISIBLE);
                actionToolBar.setVisibility(View.GONE);
            }
            chatAdapter.notifyDataSetChanged();
            futureChatAdapter.notifyDataSetChanged();
        }
    };

    private void handleActionItemVisibility() {
        if (MessageSelection.getCount() == 1) {
            if (isSMSChat) {
                ivQuote.setVisibility(View.GONE);
                ivEdit.setVisibility(View.GONE);
                ivMessageInfo.setVisibility(View.GONE);
            } else {
//                if (isGroupChat) {
//                    ivMessageInfo.setVisibility(View.VISIBLE);
//                } else {
//                    ivMessageInfo.setVisibility(View.GONE);
//                }
                ivMessageInfo.setVisibility(View.VISIBLE);
                ivQuote.setVisibility(View.VISIBLE);
                if (MessageSelection.containsAnythingThanText()) {
                    logger.log("containsAnythingThanText");
                    ivEdit.setVisibility(View.GONE);
                } else if (MessageSelection.hadReceivedMessage()) {
                    logger.log("hadReceivedMessage");
                    ivEdit.setVisibility(View.GONE);
                } else if (MessageSelection.hasQuoteMessage()) {
                    logger.log("hasQuoteMessage");
                    ivEdit.setVisibility(View.GONE);
                } else {
                    ivEdit.setVisibility(View.VISIBLE);
                }
            }
            if (MessageSelection.containsFile()) {
                ivCopy.setVisibility(View.GONE);
            } else {
                ivCopy.setVisibility(View.VISIBLE);
            }
        } else {
            ivMessageInfo.setVisibility(View.GONE);
            ivQuote.setVisibility(View.GONE);
            ivEdit.setVisibility(View.GONE);
            ivCopy.setVisibility(View.GONE);
        }
        if (MessageSelection.containsAnythingThanTextAndFile()) {
            ivForwardByOtherApp.setVisibility(View.GONE);
        } else {
            ivForwardByOtherApp.setVisibility(View.VISIBLE);
        }

        if (isEncrypted) {
            ivCopy.setVisibility(View.GONE);
            ivForwardByBubbleTone.setVisibility(View.GONE);
            ivForwardByOtherApp.setVisibility(View.GONE);
        }

        if (isBroadCastIM) {
            ivQuote.setVisibility(View.GONE);
        }

        if (MessageSelection.containsSMS()) {
            ivForwardByBubbleTone.setVisibility(View.GONE);
            ivForwardByOtherApp.setVisibility(View.GONE);
            ivEdit.setVisibility(View.GONE);
            ivMessageInfo.setVisibility(View.GONE);
            ivQuote.setVisibility(View.GONE);
        }
        if (MessageSelection.hasConfide()) {
            ivMessageInfo.setVisibility(View.GONE);
            ivCopy.setVisibility(View.GONE);
            ivQuote.setVisibility(View.GONE);
            ivForwardByBubbleTone.setVisibility(View.GONE);
            ivForwardByOtherApp.setVisibility(View.GONE);
            if (MessageSelection.getCount() == 1) {
                Message message = MessageSelection.getAll().get(0);
                if (message.messageType == MessageEntry.MessageType.SEND && message.mimeType == MimeType.Text) {
                    ivEdit.setVisibility(View.VISIBLE);
                }
            } else {
                ivEdit.setVisibility(View.GONE);
            }
        }
        if (!MessageSelection.doesNotHaveAlreadyDeletedMessage()) {
            ivCopy.setVisibility(View.GONE);
            ivQuote.setVisibility(View.GONE);
            ivForwardByBubbleTone.setVisibility(View.GONE);
            ivMessageInfo.setVisibility(View.GONE);
            ivForwardByOtherApp.setVisibility(View.GONE);
            ivEdit.setVisibility(View.GONE);
        }

        if (MessageSelection.hasFutureMessage() || MessageSelection.hasReceivedMessage()) {
            ivMessageInfo.setVisibility(View.GONE);
        }
    }


    TaggedLogger confideLogger = new TaggedLogger("confideLogger");
    public static final String STATUS_CHANGED = "status_changed";
    private final BroadcastReceiver chatWindowMessageReceiver = new BroadcastReceiver() {
        @SuppressWarnings("SpellCheckingInspection")
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle extras = intent.getExtras();
            if (extras != null) {
                if (extras.containsKey(STATUS_CHANGED) /*&& extras.getString(STATUS_CHANGED,"").equals(mGroupID)*/) {
                    updateLastOnlineInfo();
                } else if (extras.containsKey(TOP_BAR_INFO_CHANGED)) {
                    updateLastOnlineInfo();
                }
                if (extras.containsKey("typing_mesage")) {
                    String num = extras.getString("typing_mesage");
                    String gID = extras.getString("groupID");
                    int e2e = extras.getInt("e2e", 0);
                    boolean isE2e = e2e > 0;
                    logger.log("num = " + num + ", gID = " + gID + ", e2e = " + e2e);
                    String name = NameResolver.getContactNameFromNumberOrEmail(num);
                    if (!CommonData.blockedNumber.contains(num)) {
                        if (isGroupChat) {
                            if (gID != null && gID.equals(target)) {
                                chatWindowViewManager.showTyping(tvTypingMessage, name + " " + getString(R.string.is_typing));
                            }
                        } else if (num != null && num.equals(target)) {
                            if (gID == null) {
                                if (isEncrypted) {
                                    if (isE2e) {
                                        chatWindowViewManager.showTyping(tvTypingMessage, name + " " + getString(R.string.is_typing));
                                    }
                                } else {
                                    if (!isE2e) {
                                        chatWindowViewManager.showTyping(tvTypingMessage, name + " " + getString(R.string.is_typing));
                                    }
                                }
                            }
                        }
                    }
                } else if (extras.containsKey(Constants.CALLER_ID) && extras.containsKey(Constants.MESSAGE_TYPE)) {
                    //message needs to be burnt
                    String callerId = extras.getString(Constants.CALLER_ID);
                    short messageType = extras.getShort(Constants.MESSAGE_TYPE);
                    Log.e("BurnChat", "burn message callerID: " + callerId + " type: " + messageType);
                    chatAdapter.notifyDataSetChanged();
                } else if (extras.containsKey(Constants.CALLER_ID) && extras.containsKey(Constants.SMOKE_ANIMATION_INDICATION)) {
                    final String callerId = extras.getString(Constants.CALLER_ID);
                    confideLogger.log("Received intent to smoke a message with call id = " + callerId);
                    int pos = MessageHighlighter.getPositionFor(callerId); //works cause ocid = callerId for sent messages
                    confideLogger.log("position found = " + pos);
                    Smoker.prepareForSmoking(callerId);
                    chatAdapter.notifyItemChanged(pos);

                }


            }
        }
    };

    @Override
    public void onDialerServiceEvent(DialerServiceEvent event, String data) {
        switch (event) {
            case GroupInfoUpdate:
                logger.log("GroupInfoUpdate");
                Target.updateGroupState();
                if (data.equals("")) {//there is no groupId for group profile pic download callback
                    chatWindowViewManager.updateGroupState(Target.target);
                } else {
                    chatWindowViewManager.updateGroupState(data);
                }


                setDataInTopView();
                break;
            case GroupLeftOrJoined:
                logger.log("GroupLeftOrJoined");
                chatWindowViewManager.updateGroupState(data);
                Target.updateGroupState();
                chatWindowViewManager.setNumber(tvNumber);
                controlGroupFeatures();
                break;
        }
    }

    @Override
    public void onDialerServiceEvent(DialerServiceEvent event, HashMap<String, String> data) {

    }

    private void updateLastOnlineInfo() {

        Executor.ex(() -> {
            try {
                if (SubscriberStatusProvider.isOnline(target)) {
                    Gui.get().run(() -> {
                        tvLastOnline.setText(getString(R.string.online));
                        ivPresenceState.setBackgroundResource(R.drawable.online_circle_border);
                    });


                } else {
                    String lastOnlineTime = SubscriberStatusProvider.getLastOnlineTime(ChatWindowActivity.this, target);
                    Gui.get().run(() -> {
                        ivPresenceState.setBackgroundResource(R.drawable.offline_circle_border);
                        if (lastOnlineTime != null) {
                            tvLastOnline.setText((lastOnlineTime));
                        } else {
                            tvLastOnline.setText(getString(R.string.offline));
                        }
                    });

                }
            } catch (Exception e) {
                I.err(e.getLocalizedMessage());
                e.printStackTrace();
            }
        });

    }

    private void controlGroupFeatures() {


        Executor.ex(() -> {
            logger.log("controlGroupFeatures");
            if (Target.group != null) {
                logger.log("controlGroupFeatures target group found");
                if (GroupRepo.get().checkIfMember(target) == 1) {
                    Gui.get().run(() -> {
                        logger.log("controlGroupFeatures target group is member is true");
                        bottomOptionsHolder.setVisibility(View.VISIBLE);
                        messageSendingLayout.setVisibility(View.VISIBLE);
                        if (isSMSChat) {
                            mediaOptionsHolder.setVisibility(View.GONE);
                        } else if (!isBroadCastIM) {
                            mediaOptionsHolder.setVisibility(View.VISIBLE);
                        }
                        if (isBroadCastIM
                                || (isSMSChat && !CommonData.subscriberPhoneNumberToLookUpKey.containsKey(target))
                                || (isGroupChat && ChatProperties.isEncryptedChat && !Target.group.isCreator)) {
                            ivMore.setVisibility(View.INVISIBLE);
                        } else {
                            ivMore.setVisibility(View.VISIBLE);
                        }
                    });

                } else {
                    Gui.get().run(() -> {
                        logger.log("controlGroupFeatures target group is member is false");
                        bottomOptionsHolder.setVisibility(View.GONE);
                        messageSendingLayout.setVisibility(View.GONE);
                        mediaOptionsHolder.setVisibility(View.GONE);
                        ivMore.setVisibility(View.INVISIBLE);
                    });

                }
            }
        });


    }

    private void goToForwardByBubbleToneActivityAndReceiveResult() {
        I.toast("to do");
    }

    @Override
    public void onChatWindowEvent(ChatWindowEvent event) {
        switch (event) {
            case ExitQuoteMode:
                removeQuotedMessage();
                MessageQuoteInfo.clear();
                break;
            case HideBottomFragment:
                hideBottomFragment();
                hideKeyBoard();
                break;
            case ContactShowingCheckingPermission:
                if (chatAdapter != null) {
                    chatAdapter.notifyDataSetChanged();
                }
                if(futureChatAdapter !=null)
                {
                    futureChatAdapter.notifyDataSetChanged();
                }
                break;
            case BackgroundChanged:
                chatWindowViewManager.changeBackGround(ivBackGround);
                break;

        }
    }

    @Override
    public void onChatWindowEvent(ChatWindowEvent event, Message message) {
        switch (event) {
            case LocationRequestWithCheckingPermission:
                DangerousPermission.LocationPermission.getAccess(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
                    @Override
                    public void onPermissionGranted() {
                        ChatDialogs.showLocationRequestResponseDialog(message);
                    }

                    @Override
                    public void onPermissionRejected() {

                    }
                });
                break;
        }
    }

    @Override
    public void onChatWindowEvent(ChatWindowEvent event, int data) {
        if (event == ChatWindowEvent.Highlight) {
            logger.log("ChatWindowEvent.Highlight");
            recyclerViewLayoutManager.scrollToPosition(data);
            chatAdapter.notifyItemChanged(data);
            futureChatAdapter.notifyDataSetChanged();
        } else if (event == ChatWindowEvent.UnHighlight) {
            logger.log("ChatWindowEvent.UnHighlight");
            chatAdapter.notifyItemChanged(data);
            futureChatAdapter.notifyDataSetChanged();
        } else if (event == ChatWindowEvent.MakeCallWithCheckingPermission) {
            // TODO: 10/3/2018 handle the permission checking please
            phonePermission(data);
        }
    }

//    private void locationPermission(int data) {
//        DangerousPermission.LocationPermission.get(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
//                cameraPermission(data);
//            }
//
//            @Override
//            public void onPermissionRejected() {
//                cameraPermission(data);
//            }
//        });
//    }

//
//    private void cameraPermission(int data) {
//        DangerousPermission.CameraPermission.get(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
//                microPhonePermission(data);
//            }
//
//            @Override
//            public void onPermissionRejected() {
//
//            }
//        });
//    }

//    private void microPhonePermission(int data) {
//        DangerousPermission.MicrophonePermission.get(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
//                phonePermission(data);
//            }
//
//            @Override
//            public void onPermissionRejected() {
//
//            }
//        });
//    }

//    private void phonePermission(int data) {
//        DangerousPermission.PhonePermission.get(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
//                switch (data){
//                    case 0:
//                        CallMaker.makePaidCall(target);
//                        break;
//                    case 1:
//                        CallMaker.makeAudioCall(target);
//                        break;
//                    case 2:
//                        CallMaker.makeVideoCall(target);
//                        break;
//                }
//            }
//
//            @Override
//            public void onPermissionRejected() {
//
//            }
//        });
//    }

    private void phonePermission(int data) {
//        DangerousPermission.PhonePermission.get(ChatWindowActivity.this).requestPermission(ChatWindowActivity.this, new AppPermissionListener() {
//            @Override
//            public void onPermissionGranted() {
        switch (data) {
            case 0:
                CallMaker.makePaidCall(target);
                break;
            case 1:
                CallMaker.makeAudioCall(target);
                break;
            case 2:
                CallMaker.makeVideoCall(target);
                break;
        }
//            }

//            @Override
//            public void onPermissionRejected() {
//
//            }
//        });
    }

    @Override
    public void onChatWindowEvent(ChatWindowEvent event, String data) {

    }

    @Override
    public void watchViewModel() {
        chatWindowViewModel.getRegularMessages().observe(ChatWindowActivity.this, messages -> {
            chatAdapter.submitList(messages);
            if (messages.size() != 0) {
                Delayer.get().runInGUIAfter(() -> rvMessages.smoothScrollToPosition(chatAdapter.getItemCount() - 1), 100);
            }
        });

        chatWindowViewModel.getFutureMessages().observe(ChatWindowActivity.this, messages -> {
            futureChatAdapter.submitList(messages);
            if (messages.size() != 0) {
                tvFutureMessageCount.setText(messages.size()+"");
                cvFutureMessageHolder.setVisibility(View.VISIBLE);
                Delayer.get().runInGUIAfter(() -> rvFutureMessages.smoothScrollToPosition(futureChatAdapter.getItemCount() - 1), 100);
            }
            else
            {
                cvFutureMessageHolder.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void search(String searchString) {
        //chatWindowViewModel.filter(ChatWindowActivity.this, searchString);
    }
}
