package com.revesoft.itelmobiledialer.ims;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.revesoft.itelmobiledialer.account.ChatBackgroundSelectionActivity;
import com.revesoft.itelmobiledialer.account.NotificationSettingsActivity;
import com.revesoft.itelmobiledialer.appDatabase.Executor;
import com.revesoft.itelmobiledialer.appDatabase.Gui;
import com.revesoft.itelmobiledialer.appDatabase.repo.ContactRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.GroupRepo;
import com.revesoft.itelmobiledialer.appDatabase.repo.MessageRepo;
import com.revesoft.itelmobiledialer.contact.details.ContactDetailsActivity;
import com.revesoft.itelmobiledialer.contact.list.ContactListItem;
import com.revesoft.itelmobiledialer.contact.list.ContactType;
import com.revesoft.itelmobiledialer.contact.picker.ContactPickerActivity;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.fileAndMediaUtil.ImageUtil;
import com.revesoft.itelmobiledialer.ims.MediaDetails.MediaDetailsActivity;
import com.revesoft.itelmobiledialer.model.Group;
import com.revesoft.itelmobiledialer.permissions.PermissionUtil;
import com.revesoft.itelmobiledialer.profile.ProfilePicUploadDownloadHelper;
import com.revesoft.itelmobiledialer.service.dialerService.BagName;
import com.revesoft.itelmobiledialer.service.dialerService.MessageBag;
import com.revesoft.itelmobiledialer.util.BaseActivity;
import com.revesoft.itelmobiledialer.util.CameraUtils;
import com.revesoft.itelmobiledialer.util.Constants;
import com.revesoft.itelmobiledialer.util.I;
import com.revesoft.itelmobiledialer.util.IntentUtil;
import com.revesoft.itelmobiledialer.util.KeyBoard;
import com.revesoft.itelmobiledialer.util.SwapDeleteWizard;
import com.revesoft.itelmobiledialer.util.Util;
import com.revesoft.material.R;
import com.revesoft.material.databinding.GroupDetailsLayoutBinding;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.databinding.DataBindingUtil;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


/**
 * @author Ifta
 */
@SuppressWarnings("unused")
public class GroupDetailsActivity extends BaseActivity implements View.OnClickListener {
    private static final int REQUEST_SELECT_PEOPLE_FOR_ADD = 420;
    private static final String TAG = "GroupDetailsActivity";
    Toolbar toolbar;
    TextView tvGroupMemberCount;
    LinearLayout addMemberToGroup;
    EditText etGroupName;
    LinearLayout editGroupNameHolder;
    List<ContactListItem> groupMembers = new ArrayList<>();
    TextView tvDeleteOrExit;
    View whiteCover;
    ImageView ivGroupImage;
    ImageView ivDone;
    String groupId;
    NestedScrollView sv;
    TextView tvMediaCount;
    private boolean hasLeftGroup = false;

    enum GroupContentType {
        MEDIA,
        VOICE,
        LINK
    }

    GroupDetailsLayoutBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.group_details_layout);
        initViews();
        handleToolbar();
        groupId = getIntent().getStringExtra(Constants.IMS.GROUP_ID);
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(broadcastReceiver, new IntentFilter(Constants.MESSAGE_INTENT_FILTER));
        if (groupId != null) {
            loadAndSetGroupData();
        } else {
            finish();
        }
        IntentFilter messageIntentFilter = new IntentFilter();
        messageIntentFilter.addAction(Constants.MESSAGE_INTENT_FILTER);
        messageIntentFilter.addAction(Constants.PROGRESS_INTENT_FILTER);
        LocalBroadcastManager.getInstance(GroupDetailsActivity.this).registerReceiver(fileUploadStatusReceiver, messageIntentFilter);
        sendQueryGroupInfoToDialer(groupId);
    }

    private void sendQueryGroupInfoToDialer(String groupid) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(Constants.QUERY_GROUP_INFO, groupid);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(Constants.IMS.KEY_GROUP_LEFT)) {
                    I.log("broadcast KEY_GROUP_LEFT");
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            loadAndSetGroupData();
                        }
                    }, 100);
                } else if (bag.containsKey(Constants.IMS.KEY_GROUP_MEMBER_ADDED)) {
                    loadAndSetGroupData();
                } else if (bag.containsKey("update_group_name")) {
                    Executor.ex(() -> {
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        loadAndSetGroupData();
                    });

                } else if (bag.containsKey(Constants.Broadcast.TYPE_CHAT_BACKGROUND_CHANGED)) {

                } else if (bag.containsKey(Constants.Broadcast.TYPE_SOMEONE_HAS_CHANGED_PROFILE_PICTURE)) {
                    loadAndSetGroupData();
                }
            }
        }
    };

    private void setGroupName() {
        binding.collapsingToolBar.setTitle(group.name);
    }

    private void setGroupImage(String groupImagePath) {
        if (groupImagePath != null && !"null".equals(groupImagePath)) {
            File file = new File(ProfilePicUploadDownloadHelper.getReceivedMediaDirectory(), groupImagePath);
            if (ProfilePicUploadDownloadHelper.checkIfImageAvailable(file)) {
                //bad code warning : if dialer service started downloading the image, the file would exist. but setting image from this file would get exception.
                //so i am showing loading image. sorry for bad code!
                ImageUtil.setImageButDefaultOnException(GroupDetailsActivity.this, file.getAbsolutePath(), ivGroupImage, R.drawable.loader_animation);
            } else {
                ImageUtil.setImageButTextImageOnException(GroupDetailsActivity.this, null, ivGroupImage, group.name);
            }
        } else {
            ImageUtil.setImageButTextImageOnException(GroupDetailsActivity.this, null, ivGroupImage, group.name);
        }
    }


    private void updateViewBasedOnUserBeingAdmin() {
        if (isUserIsAdmin()) {
            tvDeleteOrExit.setVisibility(View.GONE);
        }
    }

    private void updateViewsBasedOnGroupLeftStatus() {
        if (hasLeftGroup) {
            adapter.update();
            tvDeleteOrExit.setText(getString(R.string.deleteGroup));
            addMemberToGroup.setVisibility(View.GONE);
            ivGroupImage.setEnabled(false);
        } else {
            addMemberToGroup.setVisibility(View.VISIBLE);
            tvDeleteOrExit.setText(getString(R.string.exitGroup));
            ivGroupImage.setEnabled(true);
        }
    }

    int totalAppUserContactCount = 0;

    private void setupViewData() {
        if (group != null) {
            setupGroupMemberCountData();
            setUpMediaCountData();
        }
    }


    private void setUpMediaCountData() {
        Executor.ex(() -> {
            int count = MessageRepo.get().getCountOfImsWithMediaByGroupId(groupId);
            Gui.get().run(() -> tvMediaCount.setText(count + ""));
        });

    }

    private void setupGroupMemberCountData() {
        Executor.ex(() -> {
            Cursor cursor = ContactRepo.get().getAppContactsCursor("");
            Gui.get().run(() -> {
                if (cursor != null && cursor.moveToFirst()) {
                    totalAppUserContactCount = cursor.getCount();
                    if (groupMembers.size() > totalAppUserContactCount) {
                        totalAppUserContactCount = groupMembers.size();//(devil)
                    }
                    tvGroupMemberCount.setText(String.valueOf(groupMembers.size()) + " " + getMemberTranslation(groupMembers.size()));
                } else {
                    tvGroupMemberCount.setText(String.valueOf(groupMembers.size()) + " " + getMemberTranslation(groupMembers.size()));
                }
            });

        });

    }

    public String getMemberTranslation(int number) {
        if (number <= 4) return getResources().getString(R.string.members1);
        else return getResources().getString(R.string.members);
    }

    GroupMemberAdapter adapter;
    RecyclerView rvGroupMember;

    private void setUpRecyclerView() {
        rvGroupMember = findViewById(R.id.rvGroupMember);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(GroupDetailsActivity.this);
        rvGroupMember.setLayoutManager(linearLayoutManager);
        adapter = new GroupMemberAdapter(GroupDetailsActivity.this);
        rvGroupMember.setAdapter(adapter);
    }

    private void resetScrollView() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                sv.scrollTo(0, 0);
            }
        }, 100);
    }

    private void loadAndSetGroupData() {
        Executor.ex(() -> {
            group = GroupMessageAssistant.getGroupById(GroupDetailsActivity.this, groupId);
            if (group == null) {
                return;
            }
            I.log(group.toString());
            hasLeftGroup = GroupRepo.get().hasLeftGroup(groupId);
            List<com.revesoft.itelmobiledialer.appDatabase.entities.Contact> contacts = ContactRepo.get().getContactsByNumber(group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber);
            for (com.revesoft.itelmobiledialer.appDatabase.entities.Contact contact : contacts) {
                ContactListItem contactListItem = ContactListItem.from(contact, false);
                if (!groupMembers.contains(contactListItem)) groupMembers.add(contactListItem);
            }
            for (ContactListItem contact : groupMembers) {
                if (contact.getProcessedNumber().equals(group.creatorsNumber)) {
                    groupCreatorName = contact.getName();
                }
            }
            if (groupCreatorName.length() == 0) {
                groupCreatorName = group.creatorsNumber;
            }
            Gui.get().run(() -> {
                setGroupName();
                setGroupImage(group.groupImagePath);
                setUpRecyclerView();
                setupViewData();
                updateViewsBasedOnGroupLeftStatus();
                updateViewBasedOnUserBeingAdmin();
                resetScrollView();
                if (updateGroupNameProgressDialog != null) {
                    updateGroupNameProgressDialog.dismiss();
                }
                if (isUserIsAdmin()) {
                    addMemberToGroup.setVisibility(View.VISIBLE);
                } else {
                    addMemberToGroup.setVisibility(View.GONE);
                }
            });

        });
    }

    private void handleToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.addMemberToGroup:
                handleAddMember();
                break;
            case R.id.ivGroupImage:
                showChangePictureDialog();
                break;
            default:
                break;
        }
    }

    private void initViews() {
        sv = findViewById(R.id.sv);
        ivGroupImage = findViewById(R.id.ivGroupImage);
        etGroupName = findViewById(R.id.etGroupName);
        tvDeleteOrExit = findViewById(R.id.tvDeleteOrExit);
        tvGroupMemberCount = findViewById(R.id.tvGroupMemberCount);
        addMemberToGroup = findViewById(R.id.addMemberToGroup);
        tvMediaCount = findViewById(R.id.tvMediaCount);
        editGroupNameHolder = findViewById(R.id.groupNameEditor);
        ivDone = findViewById(R.id.ivDone);
        addMemberToGroup.setOnClickListener(this);
        ivGroupImage.setOnClickListener(this);
        ivDone.setOnClickListener(this);
    }

    private void exitGroupNameEditMode() {
        KeyBoard.hideKeyBoard(GroupDetailsActivity.this, etGroupName);
        editGroupNameHolder.setVisibility(View.GONE);

    }

    private void openGroupContent(GroupContentType content_type) {
        I.toast("Not implemented yet");
    }

    private void handleAddMember() {

        ContactPickerActivity.startPicker(GroupDetailsActivity.this,
                ContactType.APP, Arrays.asList(group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber),
                (contacts, contactList) -> {
                    ArrayList<String> selectedNumbers = new ArrayList<>(contacts);
                    String semicolonSeparatedNumber = Util.join(";", selectedNumbers.toArray(new String[selectedNumbers.size()]));
                    IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.ADD_MEMBER_TO_GROUP, groupId, semicolonSeparatedNumber);
                });
//        Intent intent = new Intent(GroupDetailsActivity.this, ChatMemberSelectionActivity.class);
//        intent.putExtra(Constants.IMS.EXISTING_GROUP_MEMBER_NUMBERS, group.numberOfGroupMembersIncludingMyNumberAndCreatorsNumber);
//        startActivityForResult(intent, REQUEST_SELECT_PEOPLE_FOR_ADD);
    }

    private void handleDeleteGroup() {
        AlertDialog.Builder bld = new AlertDialog.Builder(GroupDetailsActivity.this);
        bld.setMessage(getString(R.string.do_you_want_to_delete_this_conversation));
        bld.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Executor.ex(() -> {
                    MessageRepo.get().deleteMessageByGroupId(groupId);
                });
                finish();
            }
        });
        bld.setNegativeButton(R.string.neverMind, null);
        bld.create().show();
    }

    private void handleExitGroup() {
        AlertDialog.Builder bld = new AlertDialog.Builder(GroupDetailsActivity.this);
        bld.setMessage(getString(R.string.areyouSureToLeaveGroup));
        bld.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.LEAVE_GROUP, groupId);
            }
        });
        bld.setNegativeButton(R.string.neverMind, null);
        bld.create().show();
    }

    private void handleClearChat() {
        boolean hasDeleted = GroupMessageAssistant.clearChat(GroupDetailsActivity.this, groupId);
        if (hasDeleted) {
            I.toast(getString(R.string.successful));
        } else {
            I.toast(getString(R.string.failed));
        }
    }

    ProgressDialog updateGroupNameProgressDialog;

    private void changeGroupName(String groupName) {
//        I.log(groupName);
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
        updateGroupNameProgressDialog = new ProgressDialog(GroupDetailsActivity.this);
        updateGroupNameProgressDialog.setMessage(getString(R.string.updating));
        updateGroupNameProgressDialog.show();

        IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.CHANGE_GROUP_NAME, groupId, groupName);
    }

    private boolean isUserIsAdmin() {
        return group != null && group.creatorsNumber.equals(UserDataManager.getUserName());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private class GroupMemberAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements SwapDeleteWizard.SwapDeletableAdapter {
        Context context;

        public void update() {
            notifyDataSetChanged();
        }

        private GroupMemberAdapter(Context context) {
            this.context = context;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.group_details_group_member_single_item, parent, false);
            return new ContactViewHolder(v);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof ContactViewHolder) {
                final int pos = position;
                ContactViewHolder vh = (ContactViewHolder) holder;
                vh.itemView.setOnClickListener(v -> Executor.ex(() -> {
                    String contactId = ContactRepo.get().getContactIdByFlatNumber(groupMembers.get(position).getProcessedNumber());
                    Gui.get().run(() -> ContactDetailsActivity.start(GroupDetailsActivity.this,
                            contactId,
                            groupMembers.get(position).getProcessedNumber()
                    ));

                }));
                vh.bindView();
            }
        }

        @Override
        public int getItemCount() {
            return groupMembers.size();
        }

        @Override
        public int getItemViewType(int position) {
            return super.getItemViewType(position);
        }

        @Override
        public void remove(int position) {
            if (groupMembers.size() > 3) {
                final ContactListItem contact = groupMembers.get(position);
                if (contact.getProcessedNumber().equals(group.creatorsNumber)) {
                    I.toast(getString(R.string.sorryYouCantRemoveYourself));
                    adapter.notifyDataSetChanged();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(GroupDetailsActivity.this);
                    builder.setTitle(getString(R.string.removeGroupMember));
                    builder.setMessage(getString(R.string.areYouSureToRemove) + " " + contact.getName());
                    builder.setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.REMOVE_MEMBER_FROM_GROUP, groupId, contact.getProcessedNumber());
                            adapter.notifyDataSetChanged();
                            dialog.dismiss();
                        }
                    });
                    builder.setNegativeButton(getString(R.string.neverMind), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            adapter.notifyDataSetChanged();
                            dialog.dismiss();
                        }
                    });
                    builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            adapter.notifyDataSetChanged();
                        }
                    });
                    builder.create().show();
                }
            } else {
                I.toast(getString(R.string.aGroupMustHaveThree));
                adapter.notifyDataSetChanged();
            }
        }

        class ContactViewHolder extends RecyclerView.ViewHolder {
            ImageView ivPhoneContactImage;
            ImageView ivContactImageCircularBorder;
            TextView tvName;
            TextView tvAdmin;
            ImageView ivRemoveMember;

            private ContactViewHolder(View itemView) {
                super(itemView);
                ivPhoneContactImage = itemView.findViewById(R.id.ivPhoneContactImage);
                tvName = itemView.findViewById(R.id.tvGroupMemberName);
                ivContactImageCircularBorder = itemView.findViewById(R.id.onlineStatus);
                tvAdmin = itemView.findViewById(R.id.tvAdmin);
                ivRemoveMember = itemView.findViewById(R.id.ivRemoveMember);
            }

            public void bindView() {
                if (groupMembers == null || groupMembers.size() == 0) {
                    return;
                }
                final int position = getAdapterPosition();
                ContactListItem contact = groupMembers.get(position);


                if (contact.getProcessedNumber().equals(UserDataManager.getUserName())) {
                    tvName.setText(getString(R.string.you_));
                    ImageUtil.setImageButTextImageOnException(GroupDetailsActivity.this, UserDataManager.getProfilePicturePath(), ivPhoneContactImage, "Y");
                } else {
                    tvName.setText(contact.getName());
                    ImageUtil.setImageButTextImageOnException(GroupDetailsActivity.this, contact.getImagePath(), ivPhoneContactImage, tvName.getText().toString());
                }
//                ivContactImageCircularBorder.setBackgroundResource(R.drawable.circular_border_red);
//                UserStatusUtil.setStatus(contact.processedNumber,ivContactImageCircularBorder);
                if (contact.getProcessedNumber().equals(group.creatorsNumber)) {
                    tvAdmin.setVisibility(View.VISIBLE);
                    ivRemoveMember.setVisibility(View.GONE);
                } else {
                    tvAdmin.setVisibility(View.GONE);
                    if (hasLeftGroup) {
                        ivRemoveMember.setVisibility(View.GONE);
                    } else {
                        ivRemoveMember.setVisibility(View.VISIBLE);
                        ivRemoveMember.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                remove(position);
                            }
                        });
                    }
                }
                if (isUserIsAdmin() && !contact.getProcessedNumber().equals(group.creatorsNumber)) {
                    ivRemoveMember.setVisibility(View.VISIBLE);
                } else {
                    ivRemoveMember.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(GroupDetailsActivity.this).unregisterReceiver(broadcastReceiver);
        LocalBroadcastManager.getInstance(GroupDetailsActivity.this).unregisterReceiver(fileUploadStatusReceiver);
    }

    Group group;
    String groupCreatorName = "";

    private void enterGroupNameEditMode() {


        AlertDialog.Builder alertDialog = new AlertDialog.Builder(GroupDetailsActivity.this);
        alertDialog.setTitle("Change Group Name");
        final EditText groupNameEditText = new EditText(GroupDetailsActivity.this);
        groupNameEditText.setText(group.name);

        alertDialog.setView(groupNameEditText);
//        alertDialog.setIcon(R.drawable.icon);
        alertDialog.setPositiveButton("Change",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String groupName = groupNameEditText.getText().toString();
                        if (TextUtils.isEmpty(groupName) || groupName.trim().length() < 1) {
                            I.toast(getString(R.string.invalidGroupName));
                        } else if (!groupName.equals(group.name)) {
                            changeGroupName(groupName + Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR + group.groupImagePath);
                            dialog.dismiss();
                        }
                    }
                });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();


    }


    public void clearChat(View view) {
        clearChat();
    }

    public void exitOrDeleteGroup(View view) {
        if (hasLeftGroup) {
            handleDeleteGroup();
        } else {
            handleExitGroup();
        }
    }

    public void showMediaDetails(View view) {
        Executor.ex(() -> {
            int mediaCount = MessageRepo.get().getCountOfImsWithMediaByGroupId(groupId);
            Gui.get().run(() -> {
                if (Integer.valueOf(mediaCount) == 0) {
                    Toast.makeText(this, getString(R.string.no_media_shared), Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(this, MediaDetailsActivity.class);
                intent.putExtra(Constants.Contact.CONTACT_NUMBER, group.id);
                intent.putExtra(Constants.Contact.CONTACT_NAME, group.name);
                intent.putExtra("is_group", true);


                startActivity(intent);
            });

        });

    }

    public void handleCustomNotification(View view) {
        Intent intent = new Intent(GroupDetailsActivity.this, NotificationSettingsActivity.class);
        intent.putExtra(NotificationSettingsActivity.TARGET_KEY, groupId);
        intent.putExtra(NotificationSettingsActivity.TARGET_NAME_KEY, group.name);
        startActivity(intent);


    }

    public void changeBackgroundImage(View view) {
        Intent intent = new Intent(GroupDetailsActivity.this, ChatBackgroundSelectionActivity.class);
        intent.putExtra(Constants.IMS.CHAT_BACKGROUND_PICK_FOR, groupId);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.group_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        } else if (item.getItemId() == R.id.actionChangeImage) {
            showChangePictureDialog();

        } else if (item.getItemId() == R.id.actionChangeName) {
            enterGroupNameEditMode();
        }
        return false;
    }

    BroadcastReceiver fileUploadStatusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bag = intent.getExtras();
            if (bag != null) {
                if (bag.containsKey(Constants.PROGRESS)) {
                    String percentage = bag.getString(Constants.PROGRESS);
                    int progress = Integer.parseInt(percentage.substring(0, percentage.length() - 1));
                    if (progressDialog != null) {
                        progressDialog.setProgress(progress);

                        if (progress == 100) {
                            progressDialog.setMessage(getString(R.string.uploadFinishAndVerify));
                        }
                    }
                } else if (bag.containsKey(Constants.IMS.GROUP_CHAT_GROUP_IMAGE_PATH)) {
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                    }
                    String filePath = bag.getString(Constants.IMS.GROUP_CHAT_GROUP_IMAGE_PATH);
                    if (Constants.IMS.FAILED.equals(filePath)) {
                        I.toast(getString(R.string.somethingWentWrong));
                    } else {
                        changeGroupNameToReflectChangeOfGroupImage(filePath);
                    }
                }
            }
        }
    };

    private void changeGroupNameToReflectChangeOfGroupImage(String filePath) {
        group = GroupMessageAssistant.getGroupById(GroupDetailsActivity.this, groupId);
        String groupNameWithProfilePicture = group.name + Constants.IMS.GROUP_NAME_IMAGE_PATH_SEPARATOR + filePath;
        changeGroupName(groupNameWithProfilePicture);
    }


    //=========================================================================================================================//
    private Uri photoUri = null;
    private static final int REQUEST_IMAGE_CAPTURE = 50;
    private static final int PICK_IMAGE_REQUEST = 52;

    private void showChangePictureDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(GroupDetailsActivity.this);
        builder.setTitle(getString(R.string.chooseMethod));
        ArrayList<String> methods = new ArrayList<String>();
        methods.add(getString(R.string.takeNewPhoto));
        methods.add(getString(R.string.selectFromGallery));
        if (!TextUtils.isEmpty(group.groupImagePath) && !group.groupImagePath.equalsIgnoreCase("null"))
            methods.add(getString(R.string.seePhoto));

        ListAdapter adapter = new ArrayAdapter<String>(GroupDetailsActivity.this, android.R.layout.simple_list_item_1, methods);
        builder.setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        handleCameraCapture();
                        break;
                    case 1:
                        handleGallerySelection();
                        break;
                    case 2:
                        seePhoto();
                        break;
                    default:
                        break;
                }
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private void seePhoto() {
        try {
            File tempDest = new File(ProfilePicUploadDownloadHelper.getReceivedMediaDirectory(), group.groupImagePath);
            Intent intent = new Intent(this, ImageDialog.class);
            intent.putExtra("FILE_PATH", tempDest.getAbsolutePath());
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("Asif", "Exception in opening image file");
        }
    }

    private void handleCameraCapture() {
        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforCamera(this).length > 0) {
            Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
            ActivityCompat.requestPermissions(this, PermissionUtil.getPermissionsforCamera(this), OnFragmentInteractionListener.TYPE_IMAGE_VIDEO);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        photoUri = CameraUtils.getOutputMediaFileUri(CameraUtils.MediaFileType.IMAGE, GroupDetailsActivity.this);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } else {
            I.toast(getString(R.string.noDefaultCameraFound));
        }
    }

    private void handleGallerySelection() {
        if ((Build.VERSION.SDK_INT >= 23) && PermissionUtil.getPermissionsforGallery(this).length > 0) {
            Log.i("StartupPermissions", "Required permissions not granted. Requesting permissions.");
            ActivityCompat.requestPermissions(this, PermissionUtil.getPermissionsforGallery(this), OnFragmentInteractionListener.TYPE_GALLERY_IMAGE);
        } else {
            openGallery();
        }
    }

    private void openGallery() {
        Intent intent = new Intent();
        // Show only images, no videos or anything else
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        // Always show the chooser (if there are multiple options available)
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    private Uri selectedImageUri;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SELECT_PEOPLE_FOR_ADD) {
            if (resultCode == RESULT_OK) {
                ArrayList<String> selectedNumbers = data.getStringArrayListExtra(Constants.IMS.SELECTED_NUMBERS);
                String semicolonSeparatedNumber = Util.join(";", selectedNumbers.toArray(new String[selectedNumbers.size()]));
                IntentUtil.Dialer.sendIntentMessageToDialer(IntentUtil.IntentType.ADD_MEMBER_TO_GROUP, groupId, semicolonSeparatedNumber);

            }
        } else if (requestCode == REQUEST_IMAGE_CAPTURE) {
            if (resultCode == RESULT_OK) {
                if (photoUri != null) {
                    selectedImageUri = photoUri;
                    if (performCrop(photoUri)) {
                        Log.d(TAG, "Crop supported");
                    } else {
                        uploadGroupPicToServer(selectedImageUri);
                    }
                    deleteTempFile(GroupDetailsActivity.this, photoUri);
                } else {
                    I.toast(getString(R.string.error_no_image_selected));
                }
            }
        } else if (requestCode == PICK_IMAGE_REQUEST) {
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    Uri uri = data.getData();
                    if (uri != null) {
                        selectedImageUri = uri;
                        if (performCrop(uri)) {
                            Log.d(TAG, "Crop supported");
                        } else {
                            uploadGroupPicToServer(selectedImageUri);
                        }
                    } else {
                        I.toast(getString(R.string.error_no_image_selected));
                    }
                }
            }
        } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            try {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == Activity.RESULT_OK) {
                    Uri croppedFileUri = result.getUri();
                    selectedImageUri = croppedFileUri;
                    if (croppedFileUri != null) {
                        uploadGroupPicToServer(croppedFileUri);
                    } else {
                        I.toast(getString(R.string.error_image_cropping_failed));
                        Log.d(TAG, "Cropped uri  null ");
                    }

                } else if (resultCode == Activity.RESULT_CANCELED) {
                    Log.d(TAG, "Cropping was canceled ");
                    Toast.makeText(GroupDetailsActivity.this, R.string.error_no_image_selected, Toast.LENGTH_SHORT).show();
                }
                deleteTempFile(GroupDetailsActivity.this, selectedImageUri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void sendIntentMessageFileUploadToDialer(String groupId, String filePath, String callerId) {
        Intent intent = new Intent(Constants.DIALER_INTENT_FILTER);
        intent.putExtra(BagName.File.Upload, MessageBag.newBuilder()
                .groupId(groupId)
                .isGroup(true)
                .filePath(filePath)
                .callId(callerId).build());
        LocalBroadcastManager.getInstance(GroupDetailsActivity.this).sendBroadcast(intent);
    }

    ProgressDialog progressDialog;

    private void uploadGroupPicToServer(Uri selectedImageUri) {
        String filePath = (new File(selectedImageUri.getPath())).getAbsolutePath();
        progressDialog = new ProgressDialog(GroupDetailsActivity.this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle(getString(R.string.please_wait));
        progressDialog.setMessage(getString(R.string.uploading));
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setMax(100);
        progressDialog.show();
        sendIntentMessageFileUploadToDialer(groupId, filePath, Constants.IMS.GROUP_PROFILE_PICTURE_INDICATOR + System.currentTimeMillis());
    }

    private boolean deleteTempFile(Context context, Uri uri) {
        int deleted = 0;
        try {
            deleted = context.getContentResolver().delete(uri, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted > 0;
    }

    private boolean performCrop(Uri picUri) {
        boolean supportsCrop;
        try {
            Uri targetFileUri = null;

            try {
                targetFileUri = Uri.fromFile(Util.createImageFile(this));
//                targetFileUri = FileProvider.getUriForFile(ProfileInfoUpdateActivity.this, getString(R.string.file_provider_authority), Util.createImageFile(this));
            } catch (IOException e) {
                Log.e(TAG, "Exception creating Image File in performCrop - " + e);
                e.printStackTrace();
            }

            CropImage.activity(picUri)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setOutputUri(targetFileUri)
                    .setOutputCompressQuality(100)
                    .setOutputCompressFormat(Bitmap.CompressFormat.JPEG)
                    .setRequestedSize(500, 500)
                    .setAspectRatio(1, 1)
                    .setFixAspectRatio(true)
                    .start(GroupDetailsActivity.this);

            supportsCrop = true;
        } catch (Exception e) {
            supportsCrop = false;
            e.printStackTrace();
            I.toast(getString(R.string.error_image_cropping_not_supported));
        }

        return supportsCrop;
    }

    private void clearChat() {

        AlertDialog.Builder bld = new AlertDialog.Builder(GroupDetailsActivity.this);
        bld.setMessage(R.string.are_you_sure_you_want_to_clear_chat);
        bld.setPositiveButton(R.string.clear, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Executor.ex(() -> {
                    long lastMessageDate = MessageRepo.get().lastMessageDateForGroup(groupId);
                    if (lastMessageDate > 0) {
                        if (MessageRepo.get().deleteMessageByGroupId(groupId) > 0) {
                            MessageRepo.get().dummyWithDateForGroup(groupId, lastMessageDate);
//                            Database.MessageHistoryTime.Update.update(groupId);
                            Gui.get().run(() -> I.toast(getString(R.string.successful)));
                        } else {
                            Gui.get().run(() -> I.toast(getString(R.string.failed)));
                            I.log("deletion failed");
                        }
                    } else {
                        I.log("clear chat failed...");
                    }
                });

                dialogInterface.dismiss();
            }
        });
        bld.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        bld.create().show();
    }
}
