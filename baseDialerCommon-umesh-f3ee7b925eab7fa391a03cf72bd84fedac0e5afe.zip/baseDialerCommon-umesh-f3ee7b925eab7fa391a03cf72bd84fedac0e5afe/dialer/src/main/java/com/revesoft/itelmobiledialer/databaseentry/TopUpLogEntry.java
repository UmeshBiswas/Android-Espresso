package com.revesoft.itelmobiledialer.databaseentry;

public class TopUpLogEntry {
	public int topupid;
	public String number;
	public String amount;
	public int status;
	public long time;
}
