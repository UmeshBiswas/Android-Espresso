package com.revesoft.itelmobiledialer.appDatabase.dao;

import com.revesoft.itelmobiledialer.appDatabase.entities.CustomNotificationParam;

import androidx.room.Dao;
import androidx.room.Query;

/**
 * Created By suvo on February 27, 2019
 * Project baseDialerCommon
 **/
@Dao
public interface CustomNotificationParamsDao extends BaseDao<CustomNotificationParam> {


    @Query("SELECT * FROM CUSTOM_NOTIFICATION_PARAM WHERE target=:target")
    CustomNotificationParam getCustomNotificationParam(String target);


    @Query("SELECT COUNT(*) FROM CUSTOM_NOTIFICATION_PARAM WHERE target=:target AND custom_notification_enable=1")
    boolean isCustomNotificationEnable(String target);


    @Query("SELECT COUNT(*) FROM CUSTOM_NOTIFICATION_PARAM WHERE target=:target")
    boolean isCustomNotificationExists(String target);

    @Query("SELECT notification_id FROM CUSTOM_NOTIFICATION_PARAM WHERE target=:target")
    String getChannelId(String target);


    @Query("UPDATE custom_notification_param SET custom_notification_enable=1 WHERE target=:target")
    void enableCustomNotification(String target);

    @Query("UPDATE custom_notification_param SET custom_notification_enable=0 WHERE target=:target")
    void disableCustomNotification(String target);

    @Query("UPDATE CUSTOM_NOTIFICATION_PARAM SET notification_id=:notificationChannelID WHERE target=:target")
    void updateNotificationChannelID(String target, String notificationChannelID);

    @Query("UPDATE CUSTOM_NOTIFICATION_PARAM SET call_ring_tone=:callRingTone WHERE target=:target")
    void updateCallRingTone(String target, String callRingTone);

    @Query("UPDATE CUSTOM_NOTIFICATION_PARAM SET call_vibration=:callVibrationMode WHERE target=:target")
    void updateCallVibrationMode(String target, int callVibrationMode);


    @Query("UPDATE CUSTOM_NOTIFICATION_PARAM SET notification_id=:notificationChannelID,message_ring_tone=:messageRingTone WHERE target=:target")
    void updateMessageRingTone(String target, String messageRingTone, String notificationChannelID);


    @Query("UPDATE CUSTOM_NOTIFICATION_PARAM SET notification_id=:notificationChannelID,message_vibration=:messageVibrationMode WHERE target=:target")
    void updateMessageVibrationMode(String target, int messageVibrationMode, String notificationChannelID);

    @Query("UPDATE CUSTOM_NOTIFICATION_PARAM SET message_vibration=:messageVibrationMode,message_ring_tone=:messageRingTone WHERE target=:target")
    void updateMessageNotification(String target, String messageRingTone, int messageVibrationMode);


    @Query("UPDATE CUSTOM_NOTIFICATION_PARAM SET popup_notification=:isPopupEnable WHERE target=:target")
    void updatePopUpNotification(String target, boolean isPopupEnable);


}
