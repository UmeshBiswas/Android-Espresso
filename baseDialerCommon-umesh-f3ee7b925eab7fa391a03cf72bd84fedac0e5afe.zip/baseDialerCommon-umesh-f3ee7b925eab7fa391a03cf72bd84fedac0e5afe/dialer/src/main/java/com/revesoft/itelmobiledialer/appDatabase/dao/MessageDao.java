package com.revesoft.itelmobiledialer.appDatabase.dao;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.appDatabase.entities.Message;
import com.revesoft.itelmobiledialer.chat.chatList.QueryItemChatList;
import com.revesoft.itelmobiledialer.databaseentry.MessageEntry;
import com.revesoft.itelmobiledialer.chat.mimeType.MimeType;

import java.util.Date;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;
import androidx.room.Dao;
import androidx.room.Query;

/**
 * @author Ifta
 */
@Dao
public interface MessageDao extends BaseDao<Message> {


    String READY_CONDITION = " AND is_im_ready_for_view=1 ";


    @Query("SELECT * FROM messages")
    List<Message> getAll();


    @Query("SELECT * FROM  messages Where burn_timer_in_sec > 0 AND ((messagetype = 0 AND deliverystatus = 200) OR (messagetype = 1 AND deliverystatus = 3210)) ")
    Message[] getmessageToBurn();

    @Query("SELECT * FROM messages where callerid = :cid  AND messagetype = 0 LIMIT 1")
    Message[] getSentMessageByCallerID(String cid);

    @Query("SELECT * FROM messages where callerid = :cid AND messagetype = 1 LIMIT 1")
    Message[] getReceivedMessageByCallerID(String cid);

    @Query("SELECT * FROM messages where  (burn__scheduled_timestamp > 0 AND burn__scheduled_timestamp <= :currentSystemTime) ORDER BY burn__scheduled_timestamp  LIMIT 1 ")
    Message[] getScheduledBurnMessage(long currentSystemTime);


    @Query("SELECT * FROM messages where  burn__scheduled_timestamp > 0 ORDER BY burn__scheduled_timestamp  LIMIT 1 ")
    Message[] getNextBurnMessage();

    @Query("SELECT * FROM messages where burn_timer_in_sec > 0 AND burn__scheduled_timestamp = -1 AND callerid  IN (:callIDs)")
    List<Message> getReceivedBurnedMessagesWhereBurnTImeInMilliesNotSet(List<String> callIDs);


    @Query("SELECT burn_timer_in_sec FROM messages where callerid = :cid")
    long getBurnTimer(String cid);


    @Query("SELECT futuresendtime FROM messages where callerid = :cid")
    long getFutureSendTime(String cid);

    @Query("SELECT send_original_timestamp FROM messages where callerid = :cid")
    int getSendingOriginalTimeStampFlag(String cid);

    @Query("select * from messages where number=:number" +
            " and filepath not null" +
            " and deliverystatus=" + MessageEntry.DeliveryStatus.FAILED +
            " and messagetype=" + MessageEntry.MessageType.SEND)
    Cursor getMessagesWithFailedFileTransfer(String number);


    @Query("select * from messages where filepath not null" +
            " and deliverystatus=" + MessageEntry.DeliveryStatus.READY_TO_DOWNLOAD +
            " and messagetype=" + MessageEntry.MessageType.RECEIVED)
    List<Message> getMessagesWithPendingDataUsageRestrictedFiles();

    @Query("select * from messages where filepath not null" +
            " and deliverystatus=" + MessageEntry.DeliveryStatus.READY_TO_DOWNLOAD +
            " and messagetype=" + MessageEntry.MessageType.RECEIVED +
            " and callerid = :callerId LIMIT 1")
    Message getMessageWithPendingDataUsageRestrictedFile(String callerId);


//    @Query("SELECT m.groupid, m.number, mime_type, messagecontent, callerid, messagetype, deliverystatus, received, " +
//            "Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count, " +
//            "CASE when m.groupid is null then (select name from contacts c where c.processed_number=m.number)" +
//            "else (select groupname from group_table gt where gt.groupid=m.groupid) END as name," +
//            "display_time, long_message, filepath FROM messages m where m.is_im_ready_for_view = 1 " +
//            "GROUP BY IFNULL(m.groupid,m.number) HAVING m.date = max(m.date) ORDER BY received DESC")
//    DataSource.Factory<Integer, QueryItemChatList> getPagedChatHistoryList();

    @Query("SELECT m.groupid, m.number, mime_type, messagecontent, callerid, messagetype, deliverystatus, received, " +
            "Max(date) as date, SUM(notification) as unread_count, COUNT(messagecontent) as message_count, " +
            "CASE when m.groupid is null then (select name from contacts c where c.processed_number=m.number)" +
            "else (select groupname from group_table gt where gt.groupid=m.groupid ) END as name," +
            "display_time, long_message, filepath FROM messages m where m.is_im_ready_for_view = 1 " +
            "and (messagecontent like :filter OR name like :filter)" +
            "GROUP BY IFNULL(m.groupid,m.number) HAVING m.date = max(m.date) ORDER BY received DESC")
    DataSource.Factory<Integer, QueryItemChatList> getPagedChatHistoryListWithFilter(String filter);

    @Query("SELECT * FROM messages where number=:number AND groupid is null AND futuresendtime<=0 order by received")
    DataSource.Factory<Integer, Message> getAllRegularLivedPagedSingleMessage(String number);

    @Query("SELECT * FROM messages where groupid=:groupId AND futuresendtime<=0  order by received")
    DataSource.Factory<Integer, Message> getAllRegularLivedPagedGroupMessage(String groupId);

    @Query("SELECT * FROM messages where number=:number AND groupid is null AND futuresendtime> 0 order by received")
    DataSource.Factory<Integer, Message> getAllRegularLivedPagedSingleFutureMessage(String number);

    @Query("SELECT * FROM messages where groupid=:groupId AND futuresendtime>0  order by received")
    DataSource.Factory<Integer, Message> getAllRegularLivedPagedGroupFutureMessage(String groupId);


    @Query("DELETE FROM messages WHERE groupid=:gid")
    int deleteByGroupId(String gid);

    @Query("DELETE FROM messages WHERE groupid=:groupId AND messagetype<>2")
    int clearChatByGroupId(String groupId);


    @Query("DELETE FROM messages WHERE number=:num")
    int deleteByNumber(String num);

    @Query("DELETE FROM messages WHERE query_id=:queryId")
    int deleteByQueryId(String queryId);

    @Query("UPDATE messages SET deliverystatus=" + MessageEntry.DeliveryStatus.FAILED +
            "  WHERE filepath IS NOT NULL AND deliverystatus=" + MessageEntry.DeliveryStatus.RECEIVING)
    void updateReceivingDownloadingMessageDeliveryStatusToFailed();


    @Query("UPDATE messages SET deliverystatus=" + MessageEntry.DeliveryStatus.FAILED +
            "  WHERE filepath IS NOT NULL AND deliverystatus=" + MessageEntry.DeliveryStatus.NO_REPLY)
    void updateNoReplyUploadingMessageDeliveryStatusToFailed();


    @Query("UPDATE messages SET query_id=:queryId WHERE callerid=:callerId")
    void updateQueryIdByCallerId(String callerId, String queryId);


    @Query("UPDATE messages SET deliverystatus=:deliveryStatus WHERE filepath IS NOT NULL AND callerid=:callerId")
    void updateMessageDeliveryStatus(String callerId, int deliveryStatus);

    @Query("UPDATE messages SET deliverystatus=:deliveryStatus WHERE query_id=:queryId")
    void updateMessageDeliveryStatusByQueryId(String queryId, int deliveryStatus);


    @Query("UPDATE messages SET deliverystatus=:deliveryStatus,futuresendtime=:futureSendTime WHERE query_id=:queryId")
    void updateMessageDeliveryStatusAndFutureSendTimeByQueryId(String queryId, int deliveryStatus, int futureSendTime);

    @Query("UPDATE messages SET futuresendtime=:futureSendTime WHERE  callerid=:callerId")
    void updateFutureSendTime(String callerId, int futureSendTime);


//    @Query("SELECT date FROM messages WHERE callerid=:callID")
//    long getMessageDate(String callID);


    @Query("DELETE FROM messages WHERE callerid IN (:callIds)")
    void deleteMessageByCallIdList(List<String> callIds);


    @Query("UPDATE messages SET deliverystatus=:status, seentime=:currentTime where callerid=:callID")
    void updateMessageSeenStatus(String callID, int status, long currentTime);


    @Query("SELECT editcount FROM messages WHERE callerid=:callID")
    int getEditCount(String callID);


    @Query("SELECT * FROM messages WHERE callerid=:callID AND number=:number AND " +
            "editcount=:editCount AND messagecontent=:messageContent")
    boolean checkForMessage(String callID, String number, int editCount, String messageContent);


    @Query("SELECT received FROM messages WHERE callerid=:callID")
    Date getMessageReceiveTime(String callID);


    @Query("SELECT COUNT(*) FROM messages WHERE date=:time AND number=:number AND messagecontent=:content")
    boolean checkForSMS(long time, String number, String content);


    @Query("UPDATE messages SET deliverystatus=:messageDeliveryStatus WHERE callerid=:callId")
    void setMessageDeliveryStatus(String callId, int messageDeliveryStatus);


    @Query("SELECT deliverystatus FROM messages WHERE callerid=:callerId")
    int getMessageDeliveryStatusByCallerId(String callerId);


    @Query("SELECT * FROM messages WHERE callerid=:callID")
    Message getMessageByCallId(String callID);


    @Query("SELECT * FROM messages WHERE messagetype=" + MessageEntry.MessageType.SEND +
            " AND deliverystatus=" + MessageEntry.DeliveryStatus.NO_REPLY)
    List<Message> getNoReplyMessages();


    @Query("SELECT * FROM messages WHERE callerid IN (:callerIdList) ORDER BY date")
    Cursor readMessagesByCallerIdList(List<String> callerIdList);


    @Query("SELECT * FROM messages WHERE futuresendtime>0  AND is_encrypted=:isEncrypted AND number=:number " +
            "AND (messagetype=1 AND (long_message IS NULL OR long_message='' OR long_message='null') OR messagetype !=1) " +
            "AND messagecontent LIKE :searchText ORDER BY date ASC")
    Cursor readMessageByNumberIsFuture(String number, String searchText, boolean isEncrypted);


    @Query("SELECT * FROM messages WHERE futuresendtime>0  AND  groupid=:groupId " +
            "AND (messagetype=1 AND (long_message IS NULL OR long_message='' OR long_message='null') OR messagetype !=1) " +
            "AND messagecontent LIKE :searchText ORDER BY date ASC")
    Cursor readMessageByGroupIdIsFuture(String groupId, String searchText);

    @Query("SELECT * FROM messages WHERE futuresendtime>0  AND  groupid=:groupId AND callerid=:callerId " +
            "AND (messagetype=1 AND (long_message IS NULL OR long_message='' OR long_message='null') OR messagetype !=1) " +
            "AND messagecontent LIKE :searchText ORDER BY date ASC")
    Cursor readMessageByGroupIdIsFuture(String groupId, String searchText, String callerId);


    @Query("SELECT * FROM messages WHERE futuresendtime==0  AND is_encrypted=:isEncrypted AND number=:number " +
            "AND (messagetype=1 AND (long_message IS NULL OR long_message='' OR long_message='null') OR messagetype !=1) " +
            "AND messagecontent LIKE :searchText ORDER BY date ASC")
    Cursor readMessageByNumberNotInFuture(String number, String searchText, boolean isEncrypted);


    @Query("SELECT * FROM messages WHERE futuresendtime==0  AND groupid=:groupId " +
            "AND (messagetype=1 AND (long_message IS NULL OR long_message='' OR long_message='null') OR messagetype !=1) " +
            "AND messagecontent LIKE :searchText ORDER BY date ASC")
    Cursor readMessageByGroupIdNotInFuture(String groupId, String searchText);


    @Query("SELECT * FROM messages WHERE futuresendtime==0  AND groupid=:groupId AND callerid=:callerId " +
            "AND (messagetype=1 AND (long_message IS NULL OR long_message='' OR long_message='null') OR messagetype !=1) " +
            "AND messagecontent LIKE :searchText ORDER BY date ASC")
    Cursor readMessageByGroupIdNotInFuture(String groupId, String searchText, String callerId);


    @Query("SELECT MAX(date) FROM messages WHERE number=:phoneNumber")
    long lastMessageDate(String phoneNumber);

    @Query("SELECT MAX(date) FROM messages WHERE groupid=:groupId")
    long lastMessageDateForGroup(String groupId);

    @Query("SELECT received,MAX(date)  as date from messages where number = :number AND messagetype = '1'")
    Cursor getLastReceivedMessage(String number);

    @Query("SELECT number FROM messages WHERE messagetype IN (0,1)")
    List<String> allActiveMessageParticipantPhoneNumbers();

    @Query("SELECT groupid FROM messages WHERE messagetype IN (0,1)")
    List<String> allActiveGroupMessageGroupId();

    @Query("SELECT * FROM messages WHERE ocid=:ocid")
    Cursor readMessagesByOCID(String ocid);

    @Query("SELECT * FROM messages WHERE ocid=:ocid")
    Message getMessagesByOCID(String ocid);

    @Query("UPDATE messages SET notification=" + MessageEntry.MessageStatus.READ + " WHERE number=:number AND groupid IS NULL AND groupid IS NULL AND is_encrypted=0")
    void clearUnreadNormalIMCount(String number);

    @Query("UPDATE messages SET notification=" + MessageEntry.MessageStatus.READ + " WHERE groupid=:groupId AND is_encrypted=0")
    void clearUnreadNormalGroupCount(String groupId);


    @Query("UPDATE messages SET notification=" + MessageEntry.MessageStatus.READ + " WHERE number=:number  AND groupid IS NULL AND is_encrypted=1")
    void clearUnreadEncryptedIMCount(String number);

    @Query("UPDATE messages SET notification=" + MessageEntry.MessageStatus.READ + " WHERE groupid=:groupId AND is_encrypted=1")
    void clearUnreadEncryptedGroupCount(String groupId);

    @Query("UPDATE messages SET seentime=:seenTime WHERE number=:number AND messagecontent NOT LIKE :fileSendPrefix")
    void updateSeenTime(String number, long seenTime, String fileSendPrefix);


    @Query("UPDATE messages SET mime_type=:mimeType,messagecontent='' WHERE callerid IN (:callIds) ")
    void markAsDeleted(List<String> callIds, String mimeType);


    @Query("DELETE FROM messages")
    int deleteAllMessages();


    @Query("DELETE FROM messages WHERE number in (:numberList) AND is_encrypted=:is_encrypted ")
    void deleteMessageByNumberArray(String[] numberList, int is_encrypted);


    @Query("SELECT * FROM messages WHERE query_id=:query_id LIMIT 1")
    Message getMessageByQueryId(String query_id);


    @Query("SELECT * FROM messages WHERE number=:number AND deliverystatus=" + MessageEntry.DeliveryStatus.PENDING +
            " AND messagetype=" + MessageEntry.MessageType.SMS)
    Cursor getPendingSMS(String number);


    @Query("SELECT groupid FROM messages WHERE callerid=:callerId")
    String getGroupIdByCallerId(String callerId);


    @Query("select callerid from messages where number=:number and is_encrypted=:isEncrypted and messagetype=1 and deliverystatus=200 " +
            "and mime_type in ('Text', 'Deleted', 'Link', 'Location', 'LocationRequest', 'StaticSticker')")
    LiveData<List<String>> getUnseenMessagesCallerIdLive(String number, boolean isEncrypted);


    @Query("SELECT * FROM messages WHERE number=:number AND (messagetype=1 AND (long_message IS NULL " +
            "OR long_message='' OR long_message='null') OR messagetype!=1)" +
            "AND messagetype=" + MessageEntry.MessageType.RECEIVED + " AND (" +
            "mime_type= 'Text' OR mime_type='Deleted' OR mime_type='Link' OR mime_type='Location'" +
            "OR mime_type='StaticSticker' OR mime_type='LocationRequest') AND is_confined=0")
    Cursor getUnseenMessagesCallerIdLive(String number);


    @Query("SELECT * FROM messages WHERE groupid=:groupId AND (messagetype=1 AND (long_message IS NULL " +
            "OR long_message='' OR long_message='null') OR messagetype!=1)" +
            "AND messagetype=" + MessageEntry.MessageType.RECEIVED + " AND (" +
            "mime_type= 'Text' OR mime_type='Deleted' OR mime_type='Link' OR mime_type='Location'" +
            "OR mime_type='StaticSticker' OR mime_type='LocationRequest') AND is_confined=0")
    Cursor getUnseenMessagesByGroupId(String groupId);


    @Query("SELECT * FROM messages WHERE number=:number AND (messagetype=1 AND (long_message IS NULL " +
            "OR long_message='' OR long_message='null') OR messagetype!=1) AND is_encrypted=:securityMode " +
            "AND messagetype=" + MessageEntry.MessageType.RECEIVED + " AND is_decrypted=0")
    Cursor getUnDecryptedMessages(String number, int securityMode);


    @Query("SELECT * FROM messages WHERE number=:number AND (messagetype=1 AND (long_message IS NULL " +
            "OR long_message='' OR long_message='null') OR messagetype!=1)" +
            "AND messagetype=" + MessageEntry.MessageType.RECEIVED + " AND is_decrypted=0")
    Cursor getUnDecryptedMessagesByNumber(String number);


    @Query("SELECT * FROM messages WHERE groupid=:groupId AND (messagetype=1 AND (long_message IS NULL " +
            "OR long_message='' OR long_message='null') OR messagetype!=1)" +
            "AND messagetype=" + MessageEntry.MessageType.RECEIVED + " AND is_decrypted=0")
    Cursor getUnDecryptedMessagesByGroupId(String groupId);

    @Query("UPDATE messages SET futuresendtime=:futureTime WHERE callerid=:callerID")
    void updateFutureMessageSendTime(String callerID, long futureTime);


    @Query("UPDATE messages SET messagecontent=:content WHERE callerid=:callerID")
    void updateMessageContent(String callerID, String content);

    @Query("UPDATE messages SET messagecontent=:content,is_decrypted=:isDecrypted WHERE callerid=:callerID")
    void updateMessageContentAndDecryption(String callerID, String content, int isDecrypted);


    @Query("UPDATE messages SET messagecontent=:content,is_decrypted=:isDecrypted,is_decrypted=:isDecrypted," +
            "deliverystatus=:deliveryStatus,mime_type=:mimeType,filepath=:filePath WHERE callerid=:callerId")
    void updateMessageContent(String callerId, String content, int isDecrypted, String filePath,
                              String mimeType, short deliveryStatus);

    @Query("UPDATE messages SET messagecontent=:content, mime_type=:mimeType WHERE callerid=:callerID")
    void updateMessageContentAndMimeType(String callerID, String content, MimeType mimeType);


    @Query("SELECT filepath FROM messages WHERE callerid=:callID")
    String getMessageFilePath(String callID);


    @Query("UPDATE messages SET filepath=:filePath WHERE callerid=:callerId")
    void updateMessageFilePath(String callerId, String filePath);


    @Query("DELETE FROM messages WHERE number IN (SELECT number FROM HIDDEN_MESSAGE)")
    void deleteHiddenMessageByNumber();


    @Query("DELETE FROM messages WHERE groupid in (SELECT groupid FROM HIDDEN_MESSAGE WHERE is_group_chat=1)")
    void deleteHiddenMessageByGroupID();


    @Query("SELECT * FROM messages WHERE number=:number AND deliverystatus=" + MessageEntry.DeliveryStatus.PENDING + " " +
            "AND messagetype=" + MessageEntry.MessageType.SMS)
    Cursor getPendingSMSByNumber(String number);


    @Query("SELECT * FROM messages WHERE groupid=:groupId AND deliverystatus=" + MessageEntry.DeliveryStatus.PENDING + " " +
            "AND messagetype=" + MessageEntry.MessageType.SMS)
    Cursor getPendingSMSByGroupId(String groupId);


    @Query("SELECT ocid, mime_type, is_confined, MAX(_id) AS _id, groupid, number, SUM(notification) AS " +
            "unread, messagecontent, is_encrypted, messagetype, deliverystatus, groupname AS name, " +
            "MAX(date) AS date " +
            "FROM(SELECT * FROM messages LEFT JOIN GROUP_TABLE ON messages.groupid=GROUP_TABLE.groupid " +
            "WHERE messages.groupid NOT IN(SELECT groupid FROM HIDDEN_MESSAGE WHERE is_group_chat=1))" +
            "WHERE (number LIKE :searchString OR messagecontent LIKE :searchString OR name LIKE :searchString " +
            "AND is_im_ready_for_view=1)" +
            "GROUP BY groupid HAVING date=MAX(date) ORDER BY DATE DESC")
    Cursor getGroupChatHistoryLogWithOutGroupHiddenChat(String searchString);


    @Query("SELECT ocid, mime_type, is_confined, MAX(_id) AS _id, groupid, number, SUM(notification) AS " +
            "unread, messagecontent, is_encrypted, messagetype, deliverystatus, groupname AS name, " +
            "MAX(date) AS date " +
            "FROM(SELECT * FROM messages LEFT JOIN GROUP_TABLE ON messages.groupid=GROUP_TABLE.groupid)" +
            "WHERE (number LIKE :searchString OR messagecontent LIKE :searchString OR name LIKE :searchString " +
            "AND is_im_ready_for_view=1 OR groupid IN(SELECT groupid FROM HIDDEN_MESSAGE WHERE is_group_chat=1))" +
            "GROUP BY groupid HAVING date=MAX(date) ORDER BY DATE DESC")
    Cursor getGroupChatHistoryLogWithGroupHiddenChat(String searchString);


    @Query("SELECT m.groupid, m.number, mime_type, messagecontent, callerid, messagetype, deliverystatus, received, " +
            "Max(date) AS date, SUM(notification) AS unread_count, COUNT(messagecontent) AS message_count, " +
            "CASE WHEN m.groupid IS NULL " +
            "THEN (SELECT name FROM CONTACTS c WHERE c.processed_number=m.number) " +
            "ELSE (SELECT groupname FROM GROUP_TABLE gt WHERE gt.groupid=m.groupid) END AS name, " +
            "display_time, long_message, filepath FROM messages m\n" +
            "WHERE m.is_im_ready_for_view = 1 "
            + " GROUP BY IFNULL(m.groupid,m.number) HAVING m.date = max(m.date) ORDER BY received DESC")
    Cursor getCombinedMessageLogs();


    @Query("SELECT Max(m._id) AS _id, m.groupid, m.number,g.number AS allMembersPhoneNo," +
            " messagecontent, messagetype, Max(date) AS date, SUM(notification) AS unread_count," +
            " COUNT(messagecontent) AS message_count, groupname AS name, NULL AS photo_uri, NULL" +
            " AS lookup_key "
            + "FROM messages m LEFT JOIN GROUP_TABLE g ON (m.groupid = g.groupid) GROUP BY m.groupid " +
            "HAVING m.date = max(m.date)"
            + " ORDER BY m.date DESC")
    Cursor getGroupMessageLogs();


    @Query("SELECT Max(m._id) AS _id, m.groupid, m.number, messagecontent, messagetype, Max(date) AS date," +
            " SUM(notification) AS unread_count, COUNT(messagecontent) AS message_count, groupname AS name," +
            " NULL AS photo_uri, NULL AS lookup_key " +
            "FROM messages m LEFT JOIN GROUP_TABLE g ON (m.groupid = g.groupid)" +
            " WHERE (name LIKE :searchString OR m.number LIKE :searchString) " +
            " GROUP BY m.groupid HAVING m.date = max(m.date)")
    Cursor searchGroupMessages(String searchString);


    @Query("SELECT COUNT(notification) FROM messages WHERE groupid=:groupId AND messagetype<>" + MessageEntry.MessageType.SEND + " " +
            "AND notification=" + MessageEntry.MessageStatus.UNREAD)
    int getGroupMessageNotificationByGroupId(String groupId);


    @Query("SELECT COUNT(notification) FROM messages WHERE messagetype<>" + MessageEntry.MessageType.SEND + " " +
            "AND notification=" + MessageEntry.MessageStatus.UNREAD)
    int getMessageNotificationCount();

    @Query("SELECT SUM(notification) FROM messages")
    int getUnseenPersonMessagesCount();


    @Query("SELECT callerid,  filepath, deliverystatus FROM messages  WHERE  deliverystatus IN(200, 3210)" +
            " AND messagetype = 1 AND ( messagecontent LIKE :sendFileHttpPrefix)")
    Cursor getHTTPReceivingMessageLogs(String sendFileHttpPrefix);


    @Query("SELECT COUNT(*) FROM messages WHERE callerid=:callID AND LENGTH(long_message)>0")
    boolean isLongMessage(String callID);


    @Query("UPDATE messages SET is_im_ready_for_view=:isReadyForView WHERE callerid=:callerId")
    void updateMessageIsReadyForView(String callerId, int isReadyForView);


    @Query("SELECT ocid, mime_type,is_confined, Max(_id) as _id, null as groupid, number, sum(notification) as unread, messagecontent, messagetype, is_encrypted, deliverystatus, null as name, Max(date) as date "
            + "FROM messages WHERE (messagetype!=3 AND messagetype!=4 AND messagetype!=4 AND messagetype!=5) AND number NOT IN (SELECT number FROM hidden_message WHERE messages.is_encrypted = hidden_message.is_encrypted) " + READY_CONDITION + " GROUP BY number,is_encrypted HAVING messages.date = max(messages.date)"
            + " UNION "
            + "SELECT ocid, mime_type, is_confined, Max(_id) as _id, groupid, number,sum(notification) as unseen,  messagecontent, messagetype, is_encrypted, deliverystatus, null as name, Max(date) as date "
            + "FROM messages WHERE (messagetype!=3 AND messagetype!=4 AND messagetype!=4 AND messagetype!=5) AND groupid NOT IN (SELECT groupid FROM hidden_message WHERE is_group_chat = 1) " + READY_CONDITION + " GROUP BY groupid HAVING messages.date = max(messages.date) ORDER BY date DESC")
    Cursor getAppChatHistoryLog();

    @Query("SELECT ocid, mime_type, is_confined, Max(_id) as _id, groupid, number, sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus, null as name, Max(date) as date "
            + "FROM messages WHERE groupid NOT IN (SELECT groupid FROM hidden_message WHERE is_group_chat = 1) " + READY_CONDITION + " GROUP BY groupid HAVING messages.date = max(messages.date) ORDER BY date DESC")
    Cursor getGroupChatHistoryLog();

    @Query("SELECT ocid, mime_type, is_confined, Max(_id) as _id, null as groupid, number, sum(notification) as unread, messagecontent, is_encrypted, messagetype, deliverystatus, null as name, Max(date) as date, futuresendtime "
            + "FROM messages WHERE messages.futuresendtime > 0 " + READY_CONDITION + " GROUP BY number,is_encrypted HAVING messages.date = max(messages.date)")
    Cursor getFutureChatHistoryLog();


    @Query("SELECT _id , callerid, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
            + "where number =:number  and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' or mime_type ='Document' or" +
            " mime_type ='Link' ) and deliverystatus <> " + MessageEntry.DeliveryStatus.FAILED + " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received")
    Cursor getImsWithMediaByNumber(String number);


    @Query("SELECT _id , callerid, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
            + "where number =:number and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' ) and deliverystatus != " + MessageEntry.DeliveryStatus.FAILED + " ORDER BY received")
    Cursor getImsWithMediaByNumberForDetail(String number);


    @Query("SELECT _id , callerid, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
            + "where number =:groupId  and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' or mime_type ='Document' or" +
            " mime_type ='Link' ) and deliverystatus <> " + MessageEntry.DeliveryStatus.FAILED + " and messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received")
    Cursor getImsWithMediaByGroupId(String groupId);


    @Query("SELECT _id , callerid, number, mime_type, received, date, messagecontent as content, messagetype as type, deliverystatus, 0 as sms, filepath, display_time FROM messages "
            + "where number =:groupId and  ( mime_type ='Audio' or mime_type ='Video' or mime_type ='Image' ) and deliverystatus != " + MessageEntry.DeliveryStatus.FAILED + " ORDER BY received")
    Cursor getImsWithMediaByGroupIdForDetail(String groupId);


    @Query("SELECT DISTINCT number FROM messages WHERE messagetype=0 OR messagetype=1")
    List<String> getOnlyNumberList();


    @Query("SELECT DISTINCT groupid FROM messages")
    List<String> getOnlyGroupIdList();


    @Query("SELECT * FROM messages WHERE groupid=:groupId AND LENGTH(long_message)>0 AND " +
            "deliverystatus=404 ORDER BY date ASC")
    Cursor getFailedLongMessagesByGroupId(String groupId);


    @Query("SELECT * FROM messages WHERE number=:number AND LENGTH(long_message)>0 AND " +
            "deliverystatus=404 ORDER BY date ASC")
    Cursor getFailedLongMessagesByNumber(String number);


    @Query("SELECT * FROM messages WHERE LENGTH(long_message)>0 AND deliverystatus=404 ORDER BY date ASC")
    Cursor getAllFailedLongMessages();


    @Query("SELECT  COUNT(*) FROM messages "
            + "WHERE groupid =:groupId AND  ( mime_type ='Audio' OR mime_type ='Video' OR mime_type ='Image' or mime_type ='Document' OR" +
            " mime_type ='Link' )   AND deliverystatus   <> " + MessageEntry.DeliveryStatus.FAILED + " AND  messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received")
    int getCountOfImsWithMediaByGroupId(String groupId);


    @Query("SELECT  COUNT(*) FROM messages "
            + "WHERE number =:number AND  ( mime_type ='Audio' OR mime_type ='Video' OR mime_type ='Image' or mime_type ='Document' OR" +
            " mime_type ='Link' )   AND deliverystatus   <> " + MessageEntry.DeliveryStatus.FAILED + " AND  messagetype != " + MessageEntry.MessageType.RECEIVED_SMS + " ORDER BY received")
    int getCountOfImsWithMediaByNumber(String number);


    @Query("SELECT number,messagetype,deliverystatus,date,sum(notification) as unread FROM messages " +
            "WHERE is_confined=1 AND (messagetype=1 AND deliverystatus=" + MessageEntry.DeliveryStatus.SUCCESSFUL + ") " +
            "GROUP BY number ORDER BY date DESC")
    Cursor getConfinedChatHistory();

    @Query("SELECT COUNT(*) FROM messages WHERE is_confined=1 AND number=:number AND messagetype=0")
    Cursor getSentConfinedMessageCountByNumber(String number);

    @Query("SELECT COUNT(*) FROM messages WHERE is_confined=1 AND number=:number AND messagetype=1")
    Cursor getReceivedConfinedMessageCountByNumber(String number);


}
