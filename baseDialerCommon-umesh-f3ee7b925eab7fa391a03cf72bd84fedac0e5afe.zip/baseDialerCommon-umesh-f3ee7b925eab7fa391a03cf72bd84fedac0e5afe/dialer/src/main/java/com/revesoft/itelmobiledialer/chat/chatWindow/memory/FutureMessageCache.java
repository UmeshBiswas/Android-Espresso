package com.revesoft.itelmobiledialer.chat.chatWindow.memory;

import android.database.Cursor;

import com.revesoft.itelmobiledialer.chat.chatWindow.Message;
import com.revesoft.itelmobiledialer.util.TaggedLogger;

/**
 * @author Ifta on 12/14/2017.
 */

public class FutureMessageCache {
    private static final TaggedLogger logger = new TaggedLogger("ChatWindow");
    private static final int CACHE_SIZE = 512;
    private static final Message[] cache = new Message[CACHE_SIZE];

    private static boolean put(int positionAsKey, Message message) {
        if (positionAsKey >= CACHE_SIZE) {
            return false;
        }
        cache[positionAsKey] = message;
        return true;
    }


    public static Message findMessage(int position, Cursor cursor) {
        if (position < CACHE_SIZE) {
            Message message = cache[position];
            if (message == null && cursor != null && cursor.moveToPosition(position)) {
                message = new Message(cursor);
                put(position, message);
            }
            return message;
        } else if (cursor != null && cursor.moveToPosition(position)) {
            return new Message(cursor);
        }
        return null;
    }

    public static void invalidate() {
        for (int i = 0; i < CACHE_SIZE; i++) {
            cache[i] = null;
        }
    }
}
