package com.revesoft.itelmobiledialer.contact.list;

import android.text.TextUtils;
import android.view.View;

import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.data.ProfilePictureDataProvider;
import com.revesoft.itelmobiledialer.util.Log;

import androidx.annotation.Nullable;

public class ContactListItem {
    private String contactId;
    private String lookUpKey;
    private String number;
    private String processedNumber;
    private String name;
    private int headerTextVisibility;
    private String imagePath;
    private String headingLetter = "^";

    public static ContactListItem from(Contact contact, boolean isHeader) {
        ContactListItem item = new ContactListItem();
        item.contactId = contact.contactId;
        item.lookUpKey = contact.lookupKey;
        item.name = TextUtils.isEmpty(contact.name) ? contact.number : contact.name;
        item.number = contact.number;
        item.processedNumber = contact.preocessedNumber;
        item.headerTextVisibility = isHeader ? View.VISIBLE : View.GONE;
        if (isHeader) {
            item.headingLetter = String.valueOf(item.name.charAt(0)).toUpperCase();
        }
        item.imagePath = ProfilePictureDataProvider.getProfilePicturePath(contact.preocessedNumber);

        return item;
    }

    public String getContactId() {
        return contactId;
    }

    public String getLookUpKey() {
        return lookUpKey;
    }

    public String getNumber() {
        return number;
    }

    public String getProcessedNumber() {
        return processedNumber;
    }

    public String getHeadingLetter() {
        return headingLetter;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getName() {
        return name;
    }

    public int getHeaderTextVisibility() {
        return headerTextVisibility;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (obj instanceof ContactListItem) {
            ContactListItem secondItem = ((ContactListItem) obj);
            return !TextUtils.isEmpty(secondItem.processedNumber) && !TextUtils.isEmpty(this.processedNumber) && secondItem.processedNumber.equals(this.processedNumber);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return processedNumber.hashCode();
    }
}
