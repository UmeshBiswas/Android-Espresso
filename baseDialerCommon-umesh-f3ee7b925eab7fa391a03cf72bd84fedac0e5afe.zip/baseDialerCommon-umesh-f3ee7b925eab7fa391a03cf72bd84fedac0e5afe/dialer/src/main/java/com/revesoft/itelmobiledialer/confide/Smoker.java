package com.revesoft.itelmobiledialer.confide;

import android.app.Activity;
import android.view.View;

import com.plattysoft.leonids.ParticleSystem;
import com.plattysoft.leonids.modifiers.AlphaModifier;
import com.plattysoft.leonids.modifiers.ScaleModifier;
import com.revesoft.itelmobiledialer.chat.chatWindow.helper.ChatProperties;
import com.revesoft.material.R;

import java.util.ArrayList;

public class Smoker {
    private static ArrayList<String> smokingNeeded = new ArrayList<>();
    private static ArrayList<String> smokingStarted = new ArrayList<>();

    public static boolean isSmoking(String callerId) {
        return smokingStarted.contains(callerId);
    }

    public static void smoke(String callerId, View view) {
        view.post(new Runnable() {
            @Override
            public void run() {
                if (smokingStarted.contains(callerId)) return;
                smokingStarted.add(callerId);
                final int DURATION = 2900;
                Activity activity = (Activity) ChatProperties.getChatWindowContext();
                if (activity != null) {
                    new ParticleSystem(activity, 10, R.drawable.smoke_graphite_and_all, DURATION)
                            .setSpeedByComponentsRange(-0.025f, 0.025f, -0.06f, -0.08f)
                            .setAcceleration(0.00001f, 30)
                            .setInitialRotationRange(0, 360)
                            .addModifier(new AlphaModifier(255, 0, 1000, DURATION))
                            .addModifier(new ScaleModifier(0.5f, 2f, 0, 1000))
                            .oneShot(view, 10);
                }
            }
        });

    }

    public static void prepareForSmoking(String callId) {
        smokingNeeded.add(callId);
    }

    public static boolean needSmoking(String callerId) {
        return smokingNeeded.contains(callerId);
    }
}
