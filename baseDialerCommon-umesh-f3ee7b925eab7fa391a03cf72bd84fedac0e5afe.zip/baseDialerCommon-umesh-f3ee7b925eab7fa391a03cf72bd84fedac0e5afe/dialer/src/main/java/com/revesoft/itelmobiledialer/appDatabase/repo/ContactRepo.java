package com.revesoft.itelmobiledialer.appDatabase.repo;

import android.database.Cursor;
import android.text.TextUtils;

import com.revesoft.itelmobiledialer.appDatabase.AppDatabase;
import com.revesoft.itelmobiledialer.appDatabase.entities.Contact;
import com.revesoft.itelmobiledialer.data.UserDataManager;
import com.revesoft.itelmobiledialer.util.Util;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.paging.DataSource;

public class ContactRepo {
    private static final ContactRepo ourInstance = new ContactRepo();

    public static ContactRepo get() {
        return ourInstance;
    }

    private ContactRepo() {
    }


    public List<Contact> getAll() {
        return AppDatabase.get().contactDao().getAll();
    }


    public DataSource.Factory<Integer, Contact> getAllLivePagedFiltered(String filter) {
        return AppDatabase.get().contactDao().getAllLivePagedFiltered(filter);
    }


    public DataSource.Factory<Integer, Contact> getAppLivePagedFiltered(String filter) {

        return AppDatabase.get().contactDao().getAppLivePagedFiltered(filter);
    }


    public DataSource.Factory<Integer, Contact> getFavoriteLivePagedFiltered(String filter) {
        return AppDatabase.get().contactDao().getFavoriteLivePagedFiltered(filter);
    }


    public DataSource.Factory<Integer, Contact> getBlockedLivePagedFiltered(String filter) {
        return AppDatabase.get().contactDao().getBlockedLivePagedFiltered(filter);
    }

    public DataSource.Factory<Integer, Contact> getNotBlockedLivePagedFiltered(String filter) {
        return AppDatabase.get().contactDao().getNotBlockedLivePagedFiltered(filter);
    }


    public LiveData<List<Contact>> getByContactId(String contactId) {
        return AppDatabase.get().contactDao().getByContactId(contactId);
    }


    public List<Contact> getByContactBytId(String contactId) {
        return AppDatabase.get().contactDao().getByContactBytId(contactId);
    }


    public String getContactIdByFlatNumber(String processedNumber) {
        return AppDatabase.get().contactDao().getContactIdByFlatNumber(processedNumber);
    }

    List<Contact> getContactsByFlatNumber(List<String> processedNumbers) {
        return AppDatabase.get().contactDao().getContactsByFlatNumber(processedNumbers);
    }


    public String getNameByNumber(String num) {
        return AppDatabase.get().contactDao().getNameByNumber(num);
    }


    public String getContactIdByNumber(String num) {
        return AppDatabase.get().contactDao().getContactIdByNumber(num);
    }


    public String lookUpKeyByProcessedNumber(String processedNumber) {
        return AppDatabase.get().contactDao().lookUpKeyByProcessedNumber(processedNumber);
    }


    public List<Contact> getAllContactsByLookUpKey(String lookUpKey) {
        return AppDatabase.get().contactDao().getAllContactsByLookUpKey(lookUpKey);
    }


    public List<Contact> getAllContacts() {
        return AppDatabase.get().contactDao().getAllContacts();
    }


    public List<Contact> all(String searchText) {
        if (TextUtils.isEmpty(searchText)) {
            return getAllContacts();
        } else
            return AppDatabase.get().contactDao().searchContact(UserDataManager.getUserName(), "%" + searchText + "%");
    }


    public Cursor allCursor(String searchText) {
        if (TextUtils.isEmpty(searchText)) {
            return AppDatabase.get().contactDao().getAllContactsCursor();
        } else
            return AppDatabase.get().contactDao().searchContactCursor(UserDataManager.getUserName(), "%" + searchText + "%");
    }


    public Cursor allGrouped(String searchText) {
        return AppDatabase.get().contactDao().searchAllGroupedContact("%" + searchText + "%");
    }


    public List<Contact> favorite(String searchText) {
        return AppDatabase.get().contactDao().searchAllFavoriteContact("%" + searchText + "%");
    }


    public boolean isContact(String nonTranslatedNumber) {
        String translatedNumber = Util.translateNumber(nonTranslatedNumber, UserDataManager.getUserCountryCode());
        return AppDatabase.get().contactDao().isContact(translatedNumber);

    }


    public boolean isContactExistsByContactId(String contact_id) {
        return AppDatabase.get().contactDao().isContactExistsByContactId(contact_id);
    }

    public boolean isContactExistsByProcessedNumber(String processedNumber) {
        return AppDatabase.get().contactDao().isContactExistsByProcessedNumber(processedNumber);
    }


    public void replaceModifiedContact(String name, String number, String lookUpKey, String contact_id,
                                       String photo_uri, String processed_number, int is_fav) {
        AppDatabase.get().contactDao().replaceModifiedContact(name, number, lookUpKey, contact_id, photo_uri, processed_number, is_fav);
    }


    public Cursor favoriteCursor(String searchText) {
        return AppDatabase.get().contactDao().favoriteCursor(searchText);
    }


    public Cursor byProcessedNumbers(String[] numberOfContactsToRead) {
        return AppDatabase.get().contactDao().byProcessedNumbers(numberOfContactsToRead);
    }


    public Cursor getAppContactsCursor(String searchText) {
        return AppDatabase.get().contactDao().getAppContactsCursor("%" + searchText + "%");
    }


    public Cursor getAppNewContactsCursor(String searchText, List<String> commonNumbers) {
        if (commonNumbers.size() > 0) {
            return AppDatabase.get().contactDao().getAppContactsCursorExcludingSome("%" + searchText + "%", (String[]) commonNumbers.toArray());
        } else return AppDatabase.get().contactDao().getAppContactsCursor("%" + searchText + "%");
    }


    public Cursor getAppContactsCursorExcludingSome(String searchText, String[] excludeContactNumbers) {
        return AppDatabase.get().contactDao().getAppContactsCursorExcludingSome("%" + searchText + "%", excludeContactNumbers);
    }


    public Cursor getNonAppContactsCursor(String searchText) {
        return AppDatabase.get().contactDao()._getNonAppContactsCursor("%" + searchText + "%");
    }


    public void deleteContactByLookUpKey(String lookUpKey) {
        AppDatabase.get().contactDao().deleteContactByLookUpKey(lookUpKey);
    }


    public void deleteContactByProcessedNumber(String processedNumber) {
        AppDatabase.get().contactDao().deleteContactByProcessedNumber(processedNumber);
    }


    public void removeFromFavoriteListByLookUpKey(String lookUpKey) {
        AppDatabase.get().contactDao().removeFromFavoriteListByLookUpKey(lookUpKey);
    }


    public void addToFavoriteByLookUpKey(String lookUpKey) {
        AppDatabase.get().contactDao().addToFavoriteByLookUpKey(lookUpKey);
    }


    public void deleteContactByContactIdsNotFound(List<String> foundContactId) {
        List<String> appContactId = AppDatabase.get().contactDao().getAllAppContactId();

        List<String> notFoundIdList = new ArrayList<>();
        for (String id : appContactId) if (!foundContactId.contains(id)) notFoundIdList.add(id);


        for (int i = 0; i < notFoundIdList.size(); i += 10) {
            AppDatabase.get().contactDao().deleteContactByContactIdsNotFound(notFoundIdList.subList(i, Math.min(i + 10, notFoundIdList.size() - 1)));
        }
    }


    public Cursor searchFavoriteContacts(String searchText) {
        return AppDatabase.get().contactDao().searchFavoriteContacts("%" + searchText + "%");
    }

    public void insert(Contact contact) {
        AppDatabase.get().contactDao().insert(contact);
    }

    public List<Contact> getContactsByNumber(String[] numbers) {
        return AppDatabase.get().contactDao().getContactsByNumber(numbers);
    }


}
