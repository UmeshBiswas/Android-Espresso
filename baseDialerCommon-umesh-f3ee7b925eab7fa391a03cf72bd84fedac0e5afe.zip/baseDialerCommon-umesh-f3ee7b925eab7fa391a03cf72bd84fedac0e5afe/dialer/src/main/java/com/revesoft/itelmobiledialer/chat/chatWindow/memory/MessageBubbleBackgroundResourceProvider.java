package com.revesoft.itelmobiledialer.chat.chatWindow.memory;

import com.revesoft.itelmobiledialer.theme.Theme;
import com.revesoft.itelmobiledialer.theme.ThemeManager;
import com.revesoft.material.R;

/**
 * @author Ifta on 3/20/2018.
 */

public class MessageBubbleBackgroundResourceProvider {
    private static int corneredBubbleDrawableId = 0;
    private static int cornerLessBubbleDrawableId = 0;

    public static int getCorneredDrawable() {
        if (corneredBubbleDrawableId == 0) {
            Theme theme = ThemeManager.getTheme();
            switch (theme) {
                case Graphite:
                    corneredBubbleDrawableId = R.drawable.cb_cornered_graphite;
                    break;
                case Bounty:
                    corneredBubbleDrawableId = R.drawable.cb_cornered_bounty;
                    break;
                case Blue:
                default:
                    corneredBubbleDrawableId = R.drawable.cb_cornered_blue;
                    break;
            }
        }
        return corneredBubbleDrawableId;

    }

    public static int getCornerLessDrawable() {
        if (cornerLessBubbleDrawableId == 0) {
            Theme theme = ThemeManager.getTheme();
            switch (theme) {
                case Graphite:
                    cornerLessBubbleDrawableId = R.drawable.cb_cornerless_graphite;
                    break;
                case Bounty:
                    cornerLessBubbleDrawableId = R.drawable.cb_cornerless_bounty;
                    break;
                case Blue:
                default:
                    cornerLessBubbleDrawableId = R.drawable.cb_cornerless_blue;
                    break;
            }
        }
        return cornerLessBubbleDrawableId;
    }
}
